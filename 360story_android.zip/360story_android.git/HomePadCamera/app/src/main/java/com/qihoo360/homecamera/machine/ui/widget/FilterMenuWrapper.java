package com.qihoo360.homecamera.machine.ui.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageButton;

import com.qihoo360.homecamera.mobile.R;

public class FilterMenuWrapper extends SpaceTouchDetectorFrameLayout{

    private View mFilterMenuView;

    private ImageButton mFilterMenuIconButton;

    public FilterMenuListener getFilterMenuListener() {
        return filterMenuListener;
    }

    public void setFilterMenuListener(FilterMenuListener filterMenuListener) {
        this.filterMenuListener = filterMenuListener;
    }

    private FilterMenuListener filterMenuListener;

    public interface  FilterMenuListener{
        public void onToggle(boolean showing);
    }

    public FilterMenuWrapper(Context context) {
        super(context);
    }

    public FilterMenuWrapper(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        mEnableDetect = true;
        mFilterMenuView = findViewById(R.id.filter_menu);
    }

    @Override
    public void onSpaceTouch() {
        super.onSpaceTouch();
        if (isShowing()) {
            hide();
        }
    }

    public void setFilterMenuIconButton(ImageButton filterMenuIconButton) {
        mFilterMenuIconButton = filterMenuIconButton;
    }

    public void show() {
        mFilterMenuView.setVisibility(View.VISIBLE);
        mFilterMenuIconButton.setScaleY(-1);
        this.setClickable(true);
        this.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hide();
            }
        });
        if (filterMenuListener != null) {
            filterMenuListener.onToggle(isShowing());
        }
    }

    public void hide() {
        mFilterMenuView.setVisibility(View.GONE);
        mFilterMenuIconButton.setScaleY(1);
        this.setClickable(false);
        if (filterMenuListener != null) {
            filterMenuListener.onToggle(isShowing());
        }
    }

    public void toggle() {
        if (isShowing()) {
            hide();
        } else {
            show();
        }
        mFilterMenuIconButton.setScaleY(isShowing() ? -1 : 1);
    }

    public boolean isShowing() {
        return mFilterMenuView.getVisibility() == View.VISIBLE;
    }
}
