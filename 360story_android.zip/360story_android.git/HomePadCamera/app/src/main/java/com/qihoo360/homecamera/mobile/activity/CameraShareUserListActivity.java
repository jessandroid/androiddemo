
package com.qihoo360.homecamera.mobile.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.adapter.CameraShareUserAdapter;
import com.qihoo360.homecamera.mobile.callback.ShareUserCallback;
import com.qihoo360.homecamera.mobile.entity.Camera;
import com.qihoo360.homecamera.mobile.entity.Head;
import com.qihoo360.homecamera.mobile.entity.ShareCode;
import com.qihoo360.homecamera.mobile.entity.ShareUser;
import com.qihoo360.homecamera.mobile.entity.ShareUserList;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.utils.imageloader.ImageLoaderHelper;
import com.qihoo360.homecamera.mobile.widget.CamAlertDialog;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.List;

public class CameraShareUserListActivity extends BaseActivity implements ShareUserCallback {

    private static final int MSG_WHAT_DELSHARE_USER = 2;
    private static final int MSG_WHAT_REF = 3;
    protected ListView shareUserList;
    private final CamAlertDialog.Builder builder = null;
    protected CameraShareUserAdapter shareAdapter;
    protected View loadView;
    private List<ShareUser> userList;
    private View addView;
    private Camera camera;
    private View view;
    private MyHandler myHandler;
    private ProgressDialog progressDialog;
    private final ListView lv = null;
    private final List<HashMap<String, Object>> mapLists = null;
    private final SimpleAdapter adapter = null;
    //    private IWXAPI api;
    private ImageView refBtn;
    LinearLayout linearLayout;
    private DisplayImageOptions options;

    protected static final int DEL_CODE = 100;
    protected static final int DEL_CODE_SUCC = 200;
    protected static final int REMARK_NAME = 300;

    private static final int MSG_WHAT_GETSHARE_CODE = 1;
    private EditText mContent;
    private Button sure;
    private Button cancle;
    private CamAlertDialog camAlertDialog;
    private TextView mCount;
    private ImageView delicon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        try {
            camera = bundle.getParcelable("camera");
            userList = bundle.getParcelableArrayList("shareList");
        } catch (Exception e) {
            e.printStackTrace();
            finish();
            return;
        }
        setContentView(R.layout.share_user_layout);
        options = new DisplayImageOptions.Builder().cloneFrom(ImageLoaderHelper.DEFAULT_DISPLAY_OPTIONS)
                .showImageForEmptyUri(R.drawable.user_defalut).showImageOnFail(R.drawable.user_defalut).build();
        ShareUser shareUser = new ShareUser();
        userList.add(0, shareUser);
        myHandler = new MyHandler(this);
        initView();
        new LoadDataTask().execute();
    }

    void initView() {
        loadView = findViewById(R.id.loading_user);
        loadView.setVisibility(View.GONE);

        shareAdapter = new CameraShareUserAdapter(this, userList, options, camera);
        shareUserList = (ListView) findViewById(R.id.shareUserList);
        shareUserList.setAdapter(shareAdapter);
        findViewById(R.id.btn_back).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private int dp2px(int dp) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, getResources()
                .getDisplayMetrics());
    }

    private void add(final int postion) {

        Intent intent = new Intent(this, ShareCameraActivity.class);
        intent.putExtra("camera", camera);
        startActivityForResult(intent, 1000);
    }

    public void showShareDialog(final ShareCode shareCode) {

//        LayoutInflater inflater = LayoutInflater.from(Utils.getContext());
//        View viewDialog = inflater.inflate(R.layout.dialog, null);
//
//        final CamAlertDialog camAlertDialog = new CamAlertDialog(this, R.style.Dialog_Fullscreen);
//        camAlertDialog.setContentView(viewDialog);
//        camAlertDialog.show();
//        linearLayout = (LinearLayout) viewDialog.findViewById(R.id.share_wechat_layout);
//        linearLayout.setOnClickListener(new OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                ShareToWeChatAndWeibo shareToWeChatAndWeibo = GlobalManager.getInstance().getShareToWeChatAndWeibo();
//                shareToWeChatAndWeibo.sendCamToWechatFriend(shareCode, new ShareCameraActivity.ShareWxCallBack() {
//                    @Override
//                    public void succ() {
//                        new Thread(new Runnable() {
//                            @Override
//                            public void run() {
//                                try {
//                                    JSONObject jsonObject = new JSONObject();
//                                    jsonObject.put("sn", camera.getSN());
//                                    jsonObject.put("shareCode", shareCode.getShareCode());
//                                    CameraHttpApi cameraHttpApi = new CameraHttpApi();
//
//                                    Head head = cameraHttpApi.doCommonRequest(jsonObject,
//                                            CameraHttpApi.URL_SHARE_UPDATE_CODE, Head.class);
//                                    if (head.errorCode == 0) {
//                                        Message message = new Message();
//                                        message.what = MSG_WHAT_REF;
//                                        myHandler.sendMessage(message);
//                                    }
//                                } catch (JSONException e) {
//                                    e.printStackTrace();
//                                }
//
//                            }
//                        }).start();
//                    }
//
//                    @Override
//                    public void failed(String shareCode) {
//
//                    }
//                });
//
//                camAlertDialog.dismiss();
//            }
//        });

    }

    @Override
    public void onDelShare(final ShareUser shareUser, final int postion) {

    }

    @Override
    public void onRemarkNick(final ShareUser shareUser, final int position) {
        camAlertDialog = new CamAlertDialog(this, R.style.dialog_custom, false);
        View optionsView = LayoutInflater.from(this).inflate(R.layout.remark_name_layout, null);
        camAlertDialog.setContentView(optionsView);
        camAlertDialog.setCancelable(true);
        camAlertDialog.show();
        mContent = (EditText) optionsView.findViewById(R.id.remark_edit);
        setKeyboardFocus(mContent);
        mContent.addTextChangedListener(mTextWatcher);
        sure = (Button) optionsView.findViewById(R.id.sure);
        mCount = (TextView) optionsView.findViewById(R.id.textcount);
        delicon = (ImageView) optionsView.findViewById(R.id.del_icon);

        String nick = Utils.getString(R.string.modify_remarks_prompt);
        if (shareUser.getNameType() == 1) {
            nick = TextUtils.isEmpty(shareUser.getNickName()) ? shareUser.getNickName() : shareUser.getNickName();
        } else {
            nick = TextUtils.isEmpty(shareUser.getNickName()) ? Utils.getString(R.string.modify_remarks_prompt) : shareUser.getNickName();
        }

        String hint = nick;
        if (TextUtils.isEmpty(hint)) {
            hint = Utils.getString(R.string.modify_remarks_prompt);
        }

        mContent.setHint(hint);
        final String finalHint = hint;
        delicon.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                mContent.setText("");
                mContent.setHint(finalHint);
            }
        });
        sure.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
//                if (!TextUtils.isEmpty(mContent.getText().toString()) && !TextUtils.isEmpty(mContent.getText().toString().trim()))
                {//首先判断不空，然后判断去掉空格后的为空。
                    /* else {
                    CameraToast.showToast(CameraShareUserListActivity.this, "请输入备注名称");
                }*/
                }
            }
        });
        cancle = (Button) optionsView.findViewById(R.id.cancle);
        cancle.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                camAlertDialog.dismiss();
            }
        });

    }

    class MyHandler extends Handler {

        WeakReference<CameraShareUserListActivity> mActivityReference;

        public MyHandler(CameraShareUserListActivity context) {
            mActivityReference = new WeakReference<CameraShareUserListActivity>(context);
        }

        @Override
        public void handleMessage(Message message) {
            super.handleMessage(message);
            if (mActivityReference.get() != null) {
                switch (message.what) {
                    case MSG_WHAT_DELSHARE_USER:
                        Head head = (Head) message.obj;
                        if (head.errorCode == 0) {
                            if (userList.size() < 5 && view.getVisibility() != View.VISIBLE) {
                                view.setVisibility(View.VISIBLE);
                            }
                        } else {
                            CameraToast.show(mActivityReference.get(), head.errorMsg, Toast.LENGTH_SHORT);
                        }
                        break;
                    case MSG_WHAT_REF:
                        new LoadDataTask().execute();
                        break;
                    case DEL_CODE_SUCC:
                        Head head1 = (Head) message.obj;
                        if (head1.errorCode == 0) {
                            new LoadDataTask().execute();
                        } else {
                            CameraToast.show(mActivityReference.get(), head1.errorMsg, Toast.LENGTH_SHORT);
                        }
                        break;
                    case REMARK_NAME: {
                        Head reMarkHead = (Head) message.obj;
                        if (reMarkHead.errorCode == 0) {
                            camAlertDialog.dismiss();
                            hintKeyboard();
                            new LoadDataTask().execute();
                        } else {
                            CameraToast.showToast(mActivityReference.get(), Utils.getString(R.string.modify_remarks_fail_prompt));
//                            CameraToast.showToast(mActivityReference.get(), Utils.getString(R.string.modify_remarks_fail_prompt));
                        }
                        break;
                    }
                    default:
                        break;
                }
            }
            // progressDialog.dismiss();
        }
    }

    class LoadDataTask extends AsyncTask<Void, Void, ShareUserList> {

        @Override
        protected ShareUserList doInBackground(Void... arg0) {
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("sn", camera.sn);
            } catch (JSONException e) {
                e.printStackTrace();
                CLog.e(e.getMessage());
            }
            return null;
        }

        @Override
        protected void onPostExecute(ShareUserList result) {
            super.onPostExecute(result);
            if (result != null) {
                setUser(result);
            }
            shareAdapter.updateData(userList);
        }
    }

    public void setUser(ShareUserList result) {
        userList.clear();
        ShareUser shareUserTitle = new ShareUser();
        userList.add(shareUserTitle);
        if (result.getShareUsers() != null && result.getShareUsers().size() > 0) {
            userList.addAll(result.getShareUsers());
            shareAdapter.notifyDataSetChanged();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        new LoadDataTask().execute();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    Handler selfHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (msg.what == 1) {
                Head head = (Head) msg.obj;
                if (head.errorCode == 0) {
                    CameraToast.show(CameraShareUserListActivity.this,
                            R.string.del_share_camera_user_success, Toast.LENGTH_LONG);
                    new LoadDataTask().execute();
                } else {
                    CameraToast.show(CameraShareUserListActivity.this,
                            R.string.del_share_camera_user_fail, Toast.LENGTH_LONG);
                }
            }
        }
    };

    // region 字数管理

    private final long length = 10;
    private final TextWatcher mTextWatcher = new TextWatcher() {

        private int editStart;

        private int editEnd;

        @Override
        public void afterTextChanged(Editable s) {
            editStart = mContent.getSelectionStart();
            editEnd = mContent.getSelectionEnd();

            // 先去掉监听器，否则会出现栈溢出
            mContent.removeTextChangedListener(mTextWatcher);

            // 注意这里只能每次都对整个EditText的内容求长度，不能对删除的单个字符求长度
            // 因为是中英文混合，单个字符而言，calculateLength函数都会返回1
            // while (s.toString().length() > length) {
            while (calculateLength(s.toString()) > length) { // 当输入字符个数超过限制的大小时，进行截断操作
                if (editStart == 0) {
                    break;
                }
                s.delete(editStart - 1, editEnd);
                editStart--;
                editEnd--;
            }
            // mEditText.setText(s);将这行代码注释掉就不会出现后面所说的输入法在数字界面自动跳转回主界面的问题了
            mContent.setSelection(editStart);

            // 恢复监听器
            mContent.addTextChangedListener(mTextWatcher);
            setDelVis();
            setLeftCount();
            /*  if (isSingleType) {
                setDelVis();
            } else {
                setLeftCount();
            }*/
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }
    };

    /**
     * 计算分享内容的字数，一个汉字=两个英文字母，一个中文标点=两个英文标点 注意：该函数的不适用于对单个字符进行计算，因为单个字符四舍五入后都是1
     */
    private long calculateLength(CharSequence c) {
        double len = 0;
        for (int i = 0; i < c.length(); i++) {
            int tmp = c.charAt(i);
            if (tmp > 0 && tmp < 127) {
                len += 0.5;
            } else {
                len++;
            }
        }
        return Math.round(len);
    }

    /*private long calculateLength(String s) {
        s = s.replaceAll("[^\\x00-\\xff]", "**");
        long length = s.length();
        return length;
    }
    */

    /**
     * 实时刷新字数
     */
    private void setLeftCount() {
        long count = getInputCount();
        mCount.setText(String.format("%s / %s", count, length));
    }

    private void setDelVis() {
        if (mContent.getText().length() > 0) {
            delicon.setVisibility(View.VISIBLE);
        } else {
            delicon.setVisibility(View.INVISIBLE);
        }
    }

    /**
     * 获取用户输入的分享内容字数
     *
     * @return
     */
    private long getInputCount() {
        return calculateLength(mContent.getText().toString());
    }

    private void hintKeyboard() {
        if (mContent != null) {
            CLog.d("login hideSoftInputFromWindow");
            mContent.clearFocus();
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(mContent.getWindowToken(), 0); // 强制隐藏键盘
        }
    }

    private void setKeyboardFocus(final EditText primaryTextField) {
        (new Handler()).postDelayed(new Runnable() {
            @Override
            public void run() {
                MotionEvent motionDown = MotionEvent.obtain(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(),
                        MotionEvent.ACTION_DOWN, 0, 0, 0);
                MotionEvent motionUp = MotionEvent.obtain(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(),
                        MotionEvent.ACTION_UP, 0, 0, 0);

                primaryTextField.dispatchTouchEvent(motionDown);
                primaryTextField.dispatchTouchEvent(motionUp);

                motionDown.recycle();
                motionUp.recycle();

                primaryTextField.setSelection(primaryTextField.length());
            }
        }, 100);
    }
}
