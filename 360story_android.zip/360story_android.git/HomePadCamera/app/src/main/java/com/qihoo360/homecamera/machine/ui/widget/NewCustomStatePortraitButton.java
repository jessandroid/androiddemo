
package com.qihoo360.homecamera.machine.ui.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.utils.CLog;

/**
 * Created by zhaojunbo on 2015/11/3.
 * desc:
 */
public class NewCustomStatePortraitButton extends LinearLayout {

    private float textSize;
    private ImageView mChangeBtn;
    private TextView textView;
    private String textValue;
    private int textColor;
    private Drawable imgBg;
    private Drawable img;
    private Context mContext;

    private final int WRAP_WIDTH = 300;
    private final int WRAP_HEIGHT = 350;

    private static final int DEFAULT_VIEW_WIDTH = 100;
    private static final int DEFAULT_VIEW_HEIGHT = 100;
    private View view;

    public final static int MIC_NORMAL = 0;
    public final static int MIC_PRESS = 1;
    public final static int MIC_DISABLE = 2;

    public final static int PHONE_NORMAL = 3;
    public final static int PHONE_PRESS = 4;
    public final static int PHONE_DISABLE = 5;

    public final static int PHONE2MIC = 6;
    public final static int MIC2PHONE = 7;

    public final static int HANGUP = 8;

    public final static int PHONE_NOT_SUPPORT = 0;
    public final static int CAMERA_NOT_SUPPORT = 1;
    public final static int FIRMWORK_NEED_UPDATE = 2;
    public final static int IS_DEMO_CAMERA = 3;

    public int phoneStat = -1;
    private ClickCallback clickCallBack;

    public NewCustomStatePortraitButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        mContext = context;
        TypedArray typedArray = context.obtainStyledAttributes(attrs,
                R.styleable.NewCustomStatePortraitButton);

        textValue = typedArray.getString(R.styleable.NewCustomStatePortraitButton_txt_new);
        textColor = typedArray.getColor(R.styleable.NewCustomStatePortraitButton_txtColor, Color.parseColor("#000000"));
        textSize = typedArray.getDimension(R.styleable.NewCustomStatePortraitButton_txtSize, 9.0f);
        img = typedArray.getDrawable(R.styleable.NewCustomStatePortraitButton_image);
        imgBg = typedArray.getDrawable(R.styleable.NewCustomStatePortraitButton_image_bg);

        typedArray.recycle();

        initView();

    }

    public void initView() {
        LayoutInflater inflater = LayoutInflater.from(mContext);
        view = inflater.inflate(R.layout.new_custom_state_button, null);
        mChangeBtn = (ImageView) view.findViewById(R.id.iv_change);
        textView = (TextView) view.findViewById(R.id.show_text);
        textView.setText(textValue);
        textView.setTextSize(textSize);
        textView.setTextColor(textColor);
        mChangeBtn.setBackgroundDrawable(imgBg);
        mChangeBtn.setImageDrawable(img);
        mChangeBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        addView(view);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int widthMode = MeasureSpec.getMode(widthMeasureSpec);
        int height = MeasureSpec.getSize(heightMeasureSpec);
        int heightMode = MeasureSpec.getMode(heightMeasureSpec);

        if (widthMode == MeasureSpec.AT_MOST && heightMode == MeasureSpec.AT_MOST) {
            setMeasuredDimension(WRAP_WIDTH, WRAP_HEIGHT);
        } else if (widthMode == MeasureSpec.AT_MOST) {
            setMeasuredDimension(view.getWidth(), height);
        } else if (heightMode == MeasureSpec.AT_MOST) {
            setMeasuredDimension(width, WRAP_HEIGHT);
        }

        CLog.d("widthMode:" + widthMode + "   width:" + width);
        CLog.d("heightMode:" + heightMode + "   height:" + height);

    }

    protected int measureDimension(int defaultSize, int measureSpec) {

        int result = defaultSize;

        int specMode = MeasureSpec.getMode(measureSpec);
        int specSize = MeasureSpec.getSize(measureSpec);
        if (specMode == MeasureSpec.EXACTLY) {
            result = specSize;
        } else if (specMode == MeasureSpec.AT_MOST) {
            result = Math.min(defaultSize, specSize);
        } else {
            result = defaultSize;
        }

        return result;
    }

    private void changeButtonType(int type) {
        int tempPhoneState = -1;
        switch (type) {
            case MIC_NORMAL: {
                mChangeBtn.setImageResource(R.drawable.micnormal);
                mChangeBtn.setBackgroundResource(R.drawable.hang_up_normal_bg);
                textView.setText("按住通话");
                tempPhoneState = 1;
                break;
            }
            case MIC_PRESS: {
                mChangeBtn.setImageResource(R.drawable.micpress);
                mChangeBtn.setBackgroundResource(R.drawable.hang_up_active_bg);
                textView.setText("按住通话");
                tempPhoneState = 1;
                break;
            }
            case MIC_DISABLE: {
                mChangeBtn.setImageResource(R.drawable.micdisable);
                mChangeBtn.setBackgroundResource(R.drawable.hang_up_disable_bg);
                textView.setText("按住通话");
                tempPhoneState = -1;
                break;
            }

            case PHONE_NORMAL: {
                mChangeBtn.setImageResource(R.drawable.phone_normal);
                mChangeBtn.setBackgroundResource(R.drawable.btn_push_talk_normal);
                textView.setText("点击通话");
                tempPhoneState = 1;
                break;
            }
            case PHONE_PRESS: {
                mChangeBtn.setImageResource(R.drawable.phone_press);
                mChangeBtn.setBackgroundResource(R.drawable.btn_push_talk_pressed);
                textView.setText("点击通话");
                tempPhoneState = 1;
                break;
            }
            case PHONE_DISABLE: {
                mChangeBtn.setImageResource(R.drawable.phone_disable);
                mChangeBtn.setBackgroundResource(R.drawable.btn_push_talk_disabled);
                textView.setText("点击通话");
                break;
            }
            case HANGUP: {
                mChangeBtn.setImageResource(R.drawable.hang_up_phone);
                mChangeBtn.setBackgroundResource(R.drawable.hang_up_red);
                textView.setText("挂断");
                tempPhoneState = 0;
                break;
            }
        }
        phoneStat = tempPhoneState;
    }

    public void setClickCallBack(ClickCallback clickCallback) {
        this.clickCallBack = clickCallback;
        clickCallback.changState(phoneStat);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN: {
                if (phoneStat == PHONE_NORMAL) {
                    mChangeBtn.setImageResource(R.drawable.phone_press);
                    mChangeBtn.setBackgroundResource(R.drawable.btn_push_talk_pressed);
                    textView.setText("点击通话");
                }
                if (phoneStat == HANGUP) {
                    mChangeBtn.setImageResource(R.drawable.hang_up_phone);
                    mChangeBtn.setBackgroundResource(R.drawable.hang_up_red);
                    textView.setText("挂断");
                }
            }
            case MotionEvent.ACTION_UP: {
                mChangeBtn.setImageResource(R.drawable.hang_up_phone);
                mChangeBtn.setBackgroundResource(R.drawable.hang_up_red);
                textView.setText("挂断");
            }
        }
        return true;

    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        super.onLayout(changed, l, t, r, b);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
    }

    public interface ClickCallback {

        public void changState(int state);
    }

}
