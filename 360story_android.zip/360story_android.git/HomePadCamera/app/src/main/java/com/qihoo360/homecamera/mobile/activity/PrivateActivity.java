package com.qihoo360.homecamera.mobile.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.widget.SettingItem;

/**
 * Created by zhaojunbo on 2016/9/5.
 * desc:
 */
public class PrivateActivity extends BaseActivity implements View.OnClickListener, ActionListener {

    private TextView mTitleTv;
    private SettingItem remote_view;
    private SettingItem small_video;
    private Button bt_bind_finish;
    private String mQid;
    private String mSn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_private);
        mQid = getIntent().getStringExtra("qid");
        mSn = getIntent().getStringExtra("sn");
        mTitleTv = (TextView) findViewById(R.id.title_string);
        mTitleTv.setText("权限设置");
        remote_view = (SettingItem) findViewById(R.id.remote_view);
        small_video = (SettingItem) findViewById(R.id.small_video);
        ImageView backImg = (ImageView) findViewById(R.id.back_zone);
        Utils.ensureVisbility(View.GONE, backImg);
        bt_bind_finish = (Button) findViewById(R.id.bt_bind_finish);
        bt_bind_finish.setOnClickListener(this);
        GlobalManager.getInstance().getPadSettingManager().registerActionListener(this);
    }

    @Override
    protected void onDestroy() {
        GlobalManager.getInstance().getPadSettingManager().removeActionListener(this);
        super.onDestroy();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.bt_bind_finish:
                showTipsDialog("正在设置，请稍后...", R.drawable.icon_loading, true);
                GlobalManager.getInstance().getPadSettingManager().asyncSetAcl(mQid,
                        mSn, String.format("{\"capture_video\": \"%1$s\",\"remote_view\": \"%2$s\"}",
                                small_video.getChecked() ? "1" : "0", remote_view.getChecked() ? "1" : "0"));
                break;
        }
    }

    @Override
    public Object actionPerformed(int actionCode, Object... args) {
        switch (actionCode) {
            case Actions.PadSetting.SET_ACL_SUCCESS: {
                hideTipsDialog();
                CameraToast.show("设置成功", Toast.LENGTH_SHORT);
                finish();
                return Boolean.TRUE;
            }
            case Actions.PadSetting.SET_ACL_FAIL: {
                hideTipsDialog();
                CameraToast.show((String) args[0], Toast.LENGTH_SHORT);
                return Boolean.TRUE;
            }
        }
        return null;
    }

    @Override
    public int getProperty() {
        return 0;
    }
}
