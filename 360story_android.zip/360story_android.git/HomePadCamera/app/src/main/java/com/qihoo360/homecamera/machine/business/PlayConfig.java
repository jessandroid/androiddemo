package com.qihoo360.homecamera.machine.business;

import android.text.TextUtils;

/**
 * Created by zhangtao-iri on 2016/12/22.
 */
public class PlayConfig {

    //播放相关指令类型
    public class CommandType {
        //app主动发起
        public static final String PLAYCONTROL = "360StoryPlayControl";     //播放控制指令
        public static final String GETPLAYSTATUS = "360StoryGetPlayStatus"; //获取播放状态指令
        public static final String GETPLAYLIST = "360StoryGetPlayList";      //获取某种类型列表的详情
        public static final String DOFAVOR = "360StoryFavor";                 //收藏指令
        public static final String DOLOCALSETTING = "360StoryLocalSetting";  //进行本地设置
        public static final String GETLOCALSETTING = "360StoryGetLocalSetting";//获取本地设置指令
        public static final String GETDEVICEINFO = "360StoryGetDeviceInfo";//获取故事机固件端信息
        public static final String NOTIFYFMUPGRADE = "360StoryFMUpgrade";//通知故事机固件进行升级

        //设备端主动发起
        public static final String GETPLAYLISTRESULT = "360StoryPlayListResult";//得到某个列表的信息
        public static final String GETFLAVORRESULT = "360StoryFavorResult";//固件端返回收藏结果
        public static final String GETDEVICEINFORESULT = "360StoryGetDeviceInfoResult";//固件端返回固件信息
        public static final String GETFMUPGRADERESULT = "360StoryFMUpgradeResult";//固件升级返回
    }

    //故事机各种列表类型
    public class ListType{

        //在线数据 1xx
        public static final int SONGLIST = 101;            //儿歌
        public static final int STORYLIST = 102;           //故事
        public static final int CHINESELIST = 103;         //国学
        public static final int ENGLISHLIST = 104;         //英语
        public static final int SLEEPSTORYLIST = 105;      //睡前故事
        public static final int ANCHORLIST = 106;          //主播
        public static final int DIFFAGELIST = 107;         //分龄

        public static final int SONGTOPLIST = 121;         //儿歌TOP
        public static final int STORYTOPLIST = 122;        //故事TOP
        public static final int CHINESETOPLIST = 123;      //国学TOP
        public static final int ENGLISHTOPLIST = 124;      //英语TOP
        public static final int SLEEPSTORYTOPLIST = 125;   //睡前故事TOP
        public static final int ANCHORTOPLIST = 126;       //热门主播TOP
        public static final int DIFFAGETOPLIST = 127;      //热门分龄TOP

        //预置数据 2xx
        public static final int PRESETSONGLIST = 201;      //预置儿歌
        public static final int PRESETSTORYLIST = 202;     //预置故事
        public static final int PRESETCHINESELIST = 203;   //预置国学
        public static final int PRESETENGLISHLIST = 204;   //预置英语

        //导入数据 3xx
        public static final int INSERTLIST = 301;           //故事机导入列表

        //语音点播
        public static final int VOICEPLAYLIST = 401;        //语音点播列表

        //收藏数据 9xx
        public static final int FAVORLIST = 999;           //收藏列表

    }

    public static boolean isOnlineType(int type){
        try{
            if(String.valueOf(type).startsWith("1")){
                return true;
            }
        }catch (Exception e){
            return false;
        }
        return false;
    }

    //是否是语音搜索出来的
    public static boolean isVoiceType(int type){
        try{
            if(type==401){
                return true;
            }
        }catch (Exception e){
            return false;
        }
        return false;
    }

    public static boolean isTopType(int type){
        try{
            if(String.valueOf(type).startsWith("12")){
                return true;
            }
        }catch (Exception e){
            return false;
        }
        return false;
    }

    //儿歌播放类型
    public class PlayType{
        public static final String PLAYSONG = "play";
        public static final String PAUSESONG = "pause";
        public static final String RESUMESONG = "resume";
        public static final String PRESONG = "prev";
        public static final String NEXTSONG = "next";
    }

    //收藏操作类型
    public class FavorType{
        public static final String ADDSONG = "add";//收藏
        public static final String DELSONG = "del";//取消收藏
    }

    //儿歌播放循环类型
    public class CircleType{
        public static final String SINGLECIRCLE = "single";//单曲循环
        public static final String LISTCIRCLE = "list";    //列表内循环播放
    }

    //童锁开关类型
    public class LockType{
        public static final int LOCK = 1;   //锁定
        public static final int UNLOCK = 0; //解锁
    }

    //播放还是暂停（不播也是一种暂停状态）
    public final static int STATE_PLAY = 1;
    public final static int STATE_PAUSE = 0;

    /**
     * status转化为state
     * @param status
     * @return
     */
    public static int status2state(String status) {
        int state = PlayConfig.STATE_PAUSE;
        if(!TextUtils.isEmpty(status)) {
            if(TextUtils.equals(status, PlayType.PLAYSONG) || TextUtils.equals(status, PlayType.RESUMESONG)){
                state = PlayConfig.STATE_PLAY;
            }else{
                state = PlayConfig.STATE_PAUSE;
            }
        }
        return state;
    }

    //发送指令的来源
    public static class CmdFrom{
        public final static String MAINPAGE = "main_page";//H5页面,storylibraryfragment
        public final static String LISTPAGE = "list_page";//儿歌列表页/收藏列表页
        public final static String PLAYPAGE = "play_page";//播放页面
        public final static String SETINGPAGE = "setting_page";//设置页面
        public final static String MACHINEINFOPAGE = "machine_info_page";//故事机信息页面
        public final static String MACHINEMAINPAGE = "machine_main_page";//故事机主页，machinemainfragment
    }

    //收藏列表的专辑标识
    public final static String FAVORUNIQUE = "collect";

}
