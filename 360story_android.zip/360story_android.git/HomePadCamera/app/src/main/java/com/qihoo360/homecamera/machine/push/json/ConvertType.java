package com.qihoo360.homecamera.machine.push.json;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(value = ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface ConvertType {
	/**
	 * {@link com.google.gson.JsonObject} <br>
	 * {@link com.google.gson.JsonArray} <br>
	 * {@link com.google.gson.JsonNull}
	 *
	 * @return
	 */
	public Class<?> oriType() default com.google.gson.JsonObject.class;
}
