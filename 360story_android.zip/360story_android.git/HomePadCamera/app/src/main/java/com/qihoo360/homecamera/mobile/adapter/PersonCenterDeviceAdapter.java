package com.qihoo360.homecamera.mobile.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.entity.DeviceInfo;
import com.qihoo360.homecamera.machine.config.MachineDebugConfig;
import com.qihoo360.homecamera.mobile.utils.Preferences;
import com.qihoo360.homecamera.mobile.widget.SettingItem;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by yanggang on 2016/6/13.
 */
public class PersonCenterDeviceAdapter extends RecyclerView.Adapter<PersonCenterDeviceAdapter.ViewHolder> {

    private List<DeviceInfo> deviceInfoList;
    private Context mctx;
    private OnViewClick onViewClick;

    public PersonCenterDeviceAdapter(List<DeviceInfo> deviceInfoList, Context context) {
        this.deviceInfoList = deviceInfoList;
        this.mctx = context;
    }

    public void setOnViewClick(OnViewClick onViewClick) {
        this.onViewClick = onViewClick;
    }

    public void setData(List<DeviceInfo> data) {
        List<DeviceInfo> tmp = data;
        deviceInfoList = tmp;
        notifyDataSetChanged();
    }

    @Override
    public long getItemId(int position) {
        return super.getItemId(position);
    }

    @Override
    public int getItemViewType(int position) {
        return super.getItemViewType(position);
    }

    @Override
    public void onViewRecycled(ViewHolder holder) {
        super.onViewRecycled(holder);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.person_center_device_item_view, parent, false);
        ButterKnife.bind(this, view);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final DeviceInfo device = deviceInfoList.get(position);
        if (position == deviceInfoList.size() - 1) {
            holder.siDeviceItem.hideDivideLine();
        }
        if (device != null && device.isStoryMachine()) {
            holder.siDeviceItem.setmLeftTv("管理"+(TextUtils.isEmpty(device.title) ? "宝贝" : device.title) + "的故事机");
            holder.siDeviceItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onViewClick.click(device);
                }
            });
            if(device.getRole()==1 && Preferences.getFmUp(device.getSn())){
                holder.siDeviceItem.showRightImage(R.drawable.has_new);
            }else{
                holder.siDeviceItem.hideRightImage();
            }
        } else {
            if (device != null) {
                holder.siDeviceItem.setmLeftTv("管理"+(TextUtils.isEmpty(device.title) ? "宝贝" : device.title) + "的机器人");
                holder.siDeviceItem.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onViewClick.click(device);
                    }
                });
                holder.siDeviceItem.hideRightImage();
            }
        }

    }

    @Override
    public int getItemCount() {
        return deviceInfoList.size();
    }

    public DeviceInfo getItem(int po) {
        if (po < deviceInfoList.size()) {
            return deviceInfoList.get(po);
        }
        return null;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        @Bind(R.id.si_device_item)
        SettingItem siDeviceItem;

        public ViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    public interface OnViewClick {
        public void click(DeviceInfo deviceInfo);
    }
}

