
package com.qihoo360.homecamera.machine.entity;

import com.google.gson.annotations.SerializedName;

/**
 * Created by wdynetposa on 2015/4/21.
 * secure=安防 
 * secure_work=安防时间
 * secure_both=安防双开
 * record=卡录 
 * face=人脸 
 * playurl=点读机 
 * public=是否允许公开
 * cloud=云录
 * voice_ptt=语音双工
 *
 * 默认为固件是否支持
 * 硬件是否支持 增加"_hd"
 * 例如：voice_ppt_hd=语音双工（硬件）
 */
public class CameraSupport {
    public int secure;
    public int secure_work;
    public int secure_both = 0;
    public int record;
    public int face;
    public int playurl = 0;
    @SerializedName("public")
    public int supportPublic = 0;
    @SerializedName("ir")
    public int infrared = 0;
    @SerializedName("ir_hd")
    public int infrared_hd = 0;
    public int cloud_hd = 0;
    public int cloud = 0;
    public int voice_ppt_hd = 0;
    public int voice_ppt = 0;
    public int soft_switch = 0;
    public int soft_switch_hd = 0;
    public int video = 0;
    public int video_hd = 0;//视频监控
    // leave video message
    public int video_msg_hd = 0;
    public int video_msg = 0;
    public int stream_v2 = 1;
    public int family_face = 0;
    public int face_video = 0;
    public int face_video_hd = 0;
    public int family_face_hd = 0;
    public int noice_detect = 0;
    public int noice_detect_hd = 0;
    public int motion_elder = 0;//无人形报警固件支持
    public int motion_elder_hd = 0;//无人形报警硬件支持
    public int motion_split = 0;//安防-分步设置
    public int batch_cmd = 0;//是否支持组合命令

    //是否支持双目
    public int huajiao = 0;

    public int p2p;

    public int stream_ts = 0; // 1: with timestamp show in stream

    public boolean isP2PSupported() {
        return p2p == 1;
    }

    public boolean withTimeShowInStream() {
        return stream_ts == 1;
    }

}
