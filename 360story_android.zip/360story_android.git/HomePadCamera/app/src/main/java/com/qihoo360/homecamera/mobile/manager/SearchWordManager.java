package com.qihoo360.homecamera.mobile.manager;

import android.app.Application;
import android.text.TextUtils;

import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionPublisherWithThreadPoolBase;
import com.qihoo360.homecamera.mobile.core.manager.workpool.PoolThreadFactory;
import com.qihoo360.homecamera.mobile.core.net.Api;
import com.qihoo360.homecamera.mobile.entity.SearchWordEntity;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.util.Date;
import java.util.concurrent.Executors;

/**
 * Created by zhaojunbo on 2016/3/21.
 * desc:
 */
public class SearchWordManager extends ActionPublisherWithThreadPoolBase {

    private final String mPoolNameHighPriority, mPoolNameLowPriority;
    private final Application mApp;

    public SearchWordManager(Application app) {
        this.mApp = app;
        mPoolNameHighPriority = "SearchWordManager-high-priority-" + Utils.DATE_FORMAT_3.format(new Date());
        mPoolNameLowPriority = "SearchWordManager-low-priority-" + Utils.DATE_FORMAT_3.format(new Date());
        mThreadPool.initPool(mPoolNameHighPriority, Executors.newFixedThreadPool(3));
        mThreadPool.initPool(mPoolNameLowPriority,
                Executors.newCachedThreadPool(new PoolThreadFactory(mPoolNameLowPriority)));
    }

    public void asyncSearchWord(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("SearchWord", args));
    }

    public void asyncDoSearch(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("DoSearch", args));
    }

    @Override
    protected void asyncDoNamedJob(String jobName, Object... args) {
        if (TextUtils.equals(jobName, "SearchWord")) {
            doSearchWord((String) args[0]);
        } else if (TextUtils.equals(jobName, "DoSearch")) {
            doSearch((String) args[0]);
        }
    }

    public void doSearchWord(String key) {
        SearchWordEntity searchWordEntity = Api.SearchWord.postSearchWord(key);
        if (searchWordEntity == null) {
            publishAction(Actions.SearchWord.SEARCH_WORD_KEY_FAIL);
        } else if (searchWordEntity.errorCode != 0) {
            publishAction(Actions.SearchWord.SEARCH_WORD_KEY_FAIL, searchWordEntity.errorMsg);
        } else {
//            publishAction(Actions.SearchWord.SEARCH_WORD_KEY_SUCCESS, searchWordEntity);
            publishAction(Actions.SearchWord.SEARCH_WORD_KEY_SUCCESS, searchWordEntity);
        }
    }

    public void doSearch(String key) {
        SearchWordEntity searchWordEntity = Api.SearchWord.postSearch(key);
        if (searchWordEntity == null) {
            publishAction(Actions.SearchWord.SEARCH_WORD_KEY_FAIL);
        } else if (searchWordEntity.errorCode != 0) {
            publishAction(Actions.SearchWord.SEARCH_WORD_KEY_FAIL, searchWordEntity.errorMsg);
        } else {
//            publishAction(Actions.SearchWord.SEARCH_WORD_KEY_SUCCESS, searchWordEntity);
            publishAction(Actions.SearchWord.SEARCH_WORD_KEY_SUCCESS, searchWordEntity);
        }
    }

}
