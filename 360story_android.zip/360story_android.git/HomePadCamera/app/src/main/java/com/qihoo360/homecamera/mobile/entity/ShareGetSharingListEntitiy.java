package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

/**
 * Created by zhaojunbo on 2016/1/22.
 * desc:
 */
public class ShareGetSharingListEntitiy extends Head {

    public Data data;

    public static class Data {
        public ArrayList<ShareGetSharingEntity> data = new ArrayList<ShareGetSharingEntity>();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        out.writeValue(data);
    }

    public static final Parcelable.Creator<ShareGetSharingListEntitiy> CREATOR = new Parcelable.Creator<ShareGetSharingListEntitiy>() {
        @Override
        public ShareGetSharingListEntitiy createFromParcel(Parcel source) {
            return new ShareGetSharingListEntitiy(source);
        }

        @Override
        public ShareGetSharingListEntitiy[] newArray(int size) {
            return new ShareGetSharingListEntitiy[size];
        }
    };

    private ShareGetSharingListEntitiy(Parcel in) {
        data = (Data) in.readValue(Data.class.getClassLoader());
    }


}
