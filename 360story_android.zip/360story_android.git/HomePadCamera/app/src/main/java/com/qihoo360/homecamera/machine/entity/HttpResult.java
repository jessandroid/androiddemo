/**
 * 
 */

package com.qihoo360.homecamera.machine.entity;

import com.google.gson.JsonElement;
import com.qihoo360.homecamera.mobile.entity.Head;

/**
 * @author changxiao-qhwl
 *
 */
public class HttpResult extends Head {
    public JsonElement data;
}
