package com.qihoo360.homecamera.machine.entity;

import com.qihoo360.homecamera.mobile.entity.Head;

public class BindResult extends Head {
    private static final long serialVersionUID = -3856446602644530512L;

    public Data data;

    public class Data{
        public String sn;
        public String imgUrl;  //已被其他人绑定时返回
        public String nickName;//已被其他人绑定时返回
    }

}
