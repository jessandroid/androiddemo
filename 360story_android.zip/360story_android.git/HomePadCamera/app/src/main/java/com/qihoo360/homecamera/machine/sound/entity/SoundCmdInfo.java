package com.qihoo360.homecamera.machine.sound.entity;

import com.qihoo360.homecamera.machine.sound.manager.SoundTask;

/**
 * @author chengxiangyu
 * 服务器返回的值
 */
public class SoundCmdInfo {
	public int state = SoundTask.SOUND_STOP;
	public String md5 = "";
	public String url = "";
	public long key = 0;//为了屏蔽过时的回复
	public int isquery = 0;//区分查询和正常的返回
}
