package com.qihoo360.homecamera.mobile.adapter;

import android.content.Context;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.entity.Story;
import com.qihoo360.homecamera.mobile.entity.UploadToken;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.TimeUtilNew;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/3/16
 * Time: 11:43
 * To change this template use File | Settings | File Templates.
 */

public class StoryHistoryFailAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<UploadToken> list = new ArrayList<>();
    private Context context;
    private OnItemOption onItemOption;
    private int itemCount = 0;
    public List<UploadToken> checkedList = new ArrayList<>();
    private boolean onBind;

    private static final int TYPE_HEADER = 0;
    private static final int TYPE_ITEM = 1;
    private static final int TYPE_FOOTER = 2;
    private int totalCount = 0;


    public StoryHistoryFailAdapter(Context context, List<UploadToken> list, OnItemOption onItemOption, int itemCount) {
        this.context = context;
        this.list = list;
        this.onItemOption = onItemOption;
        this.itemCount = itemCount;
    }

    public boolean getCheckModel() {
        return onItemOption.isCheckModel();
    }

    public List<UploadToken> getCheckedStoryList() {
        return checkedList;
    }

    public void dataChanage(List data) {
        this.list = data;
        notifyDataSetChanged();
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == TYPE_ITEM) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_linear_layout, parent, false);
            return new ViewHolderItem(view, list);
        } else if (viewType == TYPE_HEADER) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.sotry_list_head, parent, false);
            return new ViewHolderHead(view);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        if (holder instanceof ViewHolderItem) {
            int temp = position;
            if (itemCount == 3) {
                temp -= 1;
            }
            CLog.d(temp);
            ViewHolderItem viewHolder = (ViewHolderItem) holder;
            if (getCheckModel()) {
                viewHolder.retryView.setVisibility(View.GONE);
                viewHolder.ch.setVisibility(View.VISIBLE);
            } else {
                viewHolder.ch.setVisibility(View.GONE);
                viewHolder.retryView.setVisibility(View.VISIBLE);
                checkedList.clear();
            }

            final int finalTemp = temp;
            viewHolder.card_item.setTag(viewHolder.card_item.getId(), list.get(finalTemp));
            viewHolder.card_item.setTag(viewHolder.info_text.getId(), finalTemp);

            viewHolder.retryView.setTag(viewHolder.retryView.getId(), list.get(finalTemp));
            viewHolder.retryView.setTag(viewHolder.info_text.getId(), finalTemp);

            viewHolder.ch.setTag(viewHolder.ch.getId(), list.get(finalTemp));
            viewHolder.ch.setTag(viewHolder.info_text.getId(), finalTemp);
            if (list.get(temp) != null) {
                viewHolder.ch.setChecked(list.get(temp).checked);
            }
            viewHolder.story_time_long.setText(list.get(temp).duration);
            viewHolder.info_text.setText(list.get(temp).name);
            viewHolder.creat_time.setVisibility(View.GONE);
            Glide.clear(viewHolder.image_head);
            Glide.with(context).load(TextUtils.isEmpty(list.get(temp).cover) ? list.get(temp).cover : list.get(temp).cover)
                    .placeholder(R.drawable.moren_icon)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .error(R.drawable.moren_icon)
                    .priority(Priority.LOW)
                    .crossFade().into(viewHolder.image_head);
        } else {
            CLog.d("the type is :" + position);
            ViewHolderHead viewHolderHead = (ViewHolderHead) holder;
            String exchange = context.getResources().getString(R.string.story_with_sound_all, list.size());
            viewHolderHead.textView.setText(Html.fromHtml(exchange));
            viewHolderHead.mView.setVisibility(View.VISIBLE);
            if (list.size() == 0) {
                viewHolderHead.mView.setVisibility(View.GONE);
            }
        }
    }

    @Override
    public void onDetachedFromRecyclerView(RecyclerView recyclerView) {
        super.onDetachedFromRecyclerView(recyclerView);

    }

    public String getDateFormate(String date){
        long time = TimeUtilNew.convertDataTimeToLong(date,"yyyy-MM-dd hh:mm:ss");
        return context.getResources().getString(R.string.upload_date_formate, date);
    }

    @Override
    public int getItemCount() {
        int count = list.size();
        if (isPositionFooter(0)) {
            count += 1;
        }
        if (isPositionHeader(0)) {
            count += 1;
        }
        return count;
    }

    public boolean isHeader(int position) {
        if (position == 0 && itemCount == 3)
            return true;
        else
            return false;
    }

    public void setTotalCount(int total) {
        totalCount = total;
        if (itemCount == 3) {
            notifyItemChanged(0);
        }
    }

    public class ViewHolderItem extends RecyclerView.ViewHolder implements CompoundButton.OnCheckedChangeListener, View.OnClickListener {
        public View mView;
        public TextView info_text;
        public ImageView image_head;
        public CardView card_item;
        public TextView story_time_long;
        public CheckBox ch;
        public List<UploadToken> list;
        public TextView creat_time;
        public TextView story_time_;
        public ImageView retryView;

        public ViewHolderItem(View view, List<UploadToken> list) {
            super(view);
            mView = view;
            this.list = list;
            info_text = (TextView) view.findViewById(R.id.info_text);
            card_item = (CardView) view.findViewById(R.id.card_item);
            story_time_long = (TextView) view.findViewById(R.id.story_time_long);
            image_head = (ImageView) view.findViewById(R.id.image_head);
            ch = (CheckBox) view.findViewById(R.id.checkbox);
            creat_time = (TextView) view.findViewById(R.id.creat_time);
            retryView= (ImageView) view.findViewById(R.id.retry);
            retryView.setVisibility(View.VISIBLE);

            ch.setOnClickListener(this);
            card_item.setOnClickListener(this);
            retryView.setOnClickListener(this);
        }

        @Override
        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
            CLog.d("the b is :"+b);
            if (onBind) {
                notifyDataSetChanged();
            }
        }

        @Override
        public void onClick(View v) {
            int finalTmp = 0;
            UploadToken ut = null;
            if(v instanceof ImageView){
                ut = (UploadToken)v.getTag(retryView.getId());
                finalTmp = (int)v.getTag(info_text.getId());
            } else if(v instanceof CheckBox){
                ut = (UploadToken)v.getTag(ch.getId());
                finalTmp = (int)v.getTag(info_text.getId());
            } else if(v instanceof CardView){
                ut = (UploadToken)v.getTag(card_item.getId());
                finalTmp = (int)v.getTag(info_text.getId());
            }
            onItemOption.clickStory(finalTmp, ut);
        }
    }


    public class ViewHolderHead extends RecyclerView.ViewHolder {
        public final View mView;
        public TextView textView;

        public ViewHolderHead(View view) {
            super(view);
            mView = view.findViewById(R.id.story_sound_all);
            textView = (TextView) view.findViewById(R.id.story_sound_title);
        }

    }


    @Override
    public int getItemViewType(int position) {
        if (isPositionHeader(position)) {
            return TYPE_HEADER;
        } else if (isPositionFooter(position)) {
            return TYPE_FOOTER;
        }
        return TYPE_ITEM;
    }


    private boolean isPositionHeader(int position) {
        if (itemCount == 3) {
            return position == 0;
        } else {
            return false;
        }
    }

    private boolean isPositionFooter(int position) {
        return position == list.size() + 1;
    }


    public interface OnItemOption {

        public void clickStory(int po, UploadToken st);

        public boolean isCheckModel();

        public List<Story> checkedStory();
    }


  /*  @Override
    public void onViewDetachedFromWindow(RecyclerView.ViewHolder holder) {
        super.onViewDetachedFromWindow(holder);
        if (holder instanceof ViewHolderItem) {
            Glide.clear(((ViewHolderItem) holder).image_head);
        }
    }

*/
}

