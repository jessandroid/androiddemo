package com.qihoo360.homecamera.mobile.activity;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.adapter.PushStoryOutsideAdapter;
import com.qihoo360.homecamera.mobile.entity.Story;

import java.util.List;

/**
 * Created by zhaojunbo on 2016/3/26.
 * desc:
 */
public class ListenStoryActivity extends BaseActivity {

    private RecyclerView list;
    private PushStoryOutsideAdapter storyTwoAdapter;
    private List<Story> stroyList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listen_story);

        list = (RecyclerView) findViewById(R.id.list);
        storyTwoAdapter =  new PushStoryOutsideAdapter(this);
        if (stroyList != null && stroyList.size() > 0) {
            storyTwoAdapter.setDetailData(stroyList);
        }
        list.setAdapter(storyTwoAdapter);
        list.setLayoutManager(new LinearLayoutManager(this));
    }
}
