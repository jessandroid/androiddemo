package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by yanggang on 2016/5/1.
 */
public class ShareMessageInfoEntity implements Parcelable {
    public String type;
    public String time;
    public String message;
    public ImageInfoEntity data;
    public String device;


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.type);
        dest.writeString(this.time);
        dest.writeString(this.message);
        dest.writeParcelable(this.data, flags);
        dest.writeString(this.device);
    }

    public ShareMessageInfoEntity() {
    }

    protected ShareMessageInfoEntity(Parcel in) {
        this.type = in.readString();
        this.time = in.readString();
        this.message = in.readString();
        this.data = in.readParcelable(ImageInfoEntity.class.getClassLoader());
        this.device = in.readString();
    }

    public static final Creator<ShareMessageInfoEntity> CREATOR = new Creator<ShareMessageInfoEntity>() {
        @Override
        public ShareMessageInfoEntity createFromParcel(Parcel source) {
            return new ShareMessageInfoEntity(source);
        }

        @Override
        public ShareMessageInfoEntity[] newArray(int size) {
            return new ShareMessageInfoEntity[size];
        }
    };
}
