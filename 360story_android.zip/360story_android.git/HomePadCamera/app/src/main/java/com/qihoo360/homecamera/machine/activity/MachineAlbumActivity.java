package com.qihoo360.homecamera.machine.activity;

import android.content.Context;
import android.content.Intent;
import android.support.v4.app.FragmentTransaction;
import android.os.Bundle;
import android.text.TextUtils;

import com.qihoo360.homecamera.device.config.StoryMachineConsts;
import com.qihoo360.homecamera.machine.fragment.SongListFragment;
import com.qihoo360.homecamera.machine.manager.MachinePlayInfoManager;
import com.qihoo360.homecamera.mobile.R;

/**
 * 专辑界面
 */
public class MachineAlbumActivity extends MachineBaseActivity {

    private SongListFragment songListFragment;

    public String unique;//专辑唯一标识
    public String albumTitle;//儿歌\专辑\收藏
    public int listType;//儿歌\专辑\收藏
    public int songTotal;
    public String coverUrl;
    public int type;
    public boolean isOnline;
    public String device_type;

    public static final String UNIQUEKEY = "unique_key";
    public static final String LISTTYPEKEY = "listtype_key";
    public static final String ALBUMTITLE = "title_key";
    public static final String SONGTOTAL = "total_key";
    public static final String ALBUMCOVER = "cover_key";
    public static final String TYPE = "type_key";
    public static final String ONLINESTATE = "type_online";


    public static final int SONGLIST = 1;
    public static final int ALBUMLIST = 2;
    public static final int FAVORLIST = 3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_machine_songlist);

        if(getIntent()!=null && getIntent().hasExtra(LISTTYPEKEY)){
            listType = getIntent().getIntExtra(LISTTYPEKEY, 0);
        }

        if(getIntent()!=null && getIntent().hasExtra(ONLINESTATE)){
            isOnline = getIntent().getBooleanExtra(ONLINESTATE , false);
        }

        if(listType != FAVORLIST) {
            if (getIntent() != null && getIntent().hasExtra(UNIQUEKEY)) {
                unique = getIntent().getStringExtra(UNIQUEKEY);
            }

            if (getIntent() != null && getIntent().hasExtra(ALBUMTITLE)) {
                albumTitle = getIntent().getStringExtra(ALBUMTITLE);
            }

            if (getIntent() != null && getIntent().hasExtra(SONGTOTAL)) {
                songTotal = getIntent().getIntExtra(SONGTOTAL, 0);
            }

            if (getIntent() != null && getIntent().hasExtra(ALBUMCOVER)) {
                coverUrl = getIntent().getStringExtra(ALBUMCOVER);
            }

            if (getIntent() != null && getIntent().hasExtra(TYPE)) {
                type = getIntent().getIntExtra(TYPE, 0);
            }
            if (getIntent() != null && getIntent().hasExtra(StoryMachineConsts.KEY_SET_DEVICE_TYPE)) {
                device_type = getIntent().getStringExtra(StoryMachineConsts.KEY_SET_DEVICE_TYPE);
            }

        }

        FragmentTransaction beginTransaction = getSupportFragmentManager().beginTransaction();
        songListFragment = SongListFragment.newInstance();
        Bundle bundle = new Bundle();
        bundle.putString(StoryMachineConsts.KEY_SET_DEVICE_TYPE,device_type);
        songListFragment.setArguments(bundle);
        beginTransaction.replace(R.id.common_fragment, songListFragment).commitAllowingStateLoss();

    }

    public static void startMachineAlbumActivity(Context context, boolean isOnline, String unique, int listType, String title, int total, String coverUrl, int type, String deviceType){
        Intent intent = new Intent(context, MachineAlbumActivity.class);
        intent.putExtra(ONLINESTATE, isOnline);
        intent.putExtra(UNIQUEKEY, unique);
        intent.putExtra(LISTTYPEKEY, listType);
        intent.putExtra(ALBUMTITLE, title);
        intent.putExtra(SONGTOTAL, total);
        intent.putExtra(ALBUMCOVER, coverUrl);
        intent.putExtra(TYPE, type);
        intent.putExtra(StoryMachineConsts.KEY_SET_DEVICE_TYPE,deviceType);
        context.startActivity(intent);
    }

    public static void startMachineAlbumActivity2(Context context,  boolean isOnline, int listType, String deviceType){
        Intent intent = new Intent(context, MachineAlbumActivity.class);
        intent.putExtra(ONLINESTATE, isOnline);
        intent.putExtra(LISTTYPEKEY, listType);
        intent.putExtra(StoryMachineConsts.KEY_SET_DEVICE_TYPE,deviceType);
        context.startActivity(intent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

}
