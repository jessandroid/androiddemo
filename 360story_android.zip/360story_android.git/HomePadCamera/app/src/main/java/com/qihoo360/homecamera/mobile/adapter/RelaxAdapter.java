package com.qihoo360.homecamera.mobile.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.qihoo360.homecamera.mobile.R;

import java.util.List;

/**
 * Created by zhaojunbo on 2016/4/22.
 * desc:
 */
public class RelaxAdapter extends BaseAdapter{
    Context context;
    private List<Integer> mUnselectedList;
    private List<Integer> mSelectedList;
    private List<String> mTagList;
    private int mSelectIndex = -1;

    public RelaxAdapter(Context context, List<Integer> selectedList, List<Integer> unSelectedList, List<String> tagList) {
        this.context = context;
        mSelectedList = selectedList;
        mUnselectedList = unSelectedList;
        mTagList = tagList;
    }

    public void setSelectedIndex(int index) {
        mSelectIndex = index;
        notifyDataSetChanged();
    }

    public int getmSelectIndex() {
        return mSelectIndex;
    }

    @Override
    public int getCount() {
        return mSelectedList.size();
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return mSelectedList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @SuppressWarnings({"", "ResourceType"})
    @Override
    public View getView(final int position, View convertView,
                        ViewGroup parent) {
        Holder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_relax, parent, false);
            holder = new Holder();
            holder.itemIv = (ImageView) convertView.findViewById(R.id.iv_item);
            holder.itemTv = (TextView) convertView.findViewById(R.id.tv_item);
            convertView.setTag(holder);
        } else {
            holder = (Holder) convertView.getTag();
        }
        holder.itemIv.setImageResource(mSelectIndex != position ? mUnselectedList.get(position) : mSelectedList.get(position));
        holder.itemTv.setText(mTagList.get(position));
        return convertView;
    }

    class Holder {
        ImageView itemIv;
        TextView itemTv;
    }
}
