package com.qihoo360.homecamera.machine.entity;

import com.google.gson.annotations.SerializedName;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.entity.Head;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.util.List;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2015/7/29
 * Time: 14:40
 * To change this template use File | Settings | File Templates.
 */
public class SearchTip extends Head {
    private static final long serialVersionUID = 4804286476425963089L;

    @SerializedName("search_tips")
    public String searchTips = Utils.getString(R.string.live_search_tip);

    @SerializedName("search_kw")
    public List<String> searchKeyWord;
}
