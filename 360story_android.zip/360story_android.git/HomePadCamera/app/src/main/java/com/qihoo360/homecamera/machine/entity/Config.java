package com.qihoo360.homecamera.machine.entity;

import android.text.TextUtils;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

@SuppressWarnings("serial")
public class Config extends SearchTip {

    public PublicVoteInfo public_vote;
    public int check_shine; // 1: check; 0: do not;
    public String jsonFullString;
    @SerializedName("mobile")
    public MobileI mobileI;
    public P2PConfig p2p;

    public static class PublicVoteInfo {
        public GlobalInfo global;
        public ResInfo res;

        @Override
        public boolean equals(Object o) {
            if (o != null && o instanceof PublicVoteInfo) {
                PublicVoteInfo real = (PublicVoteInfo) o;
                if (global != null) {
                    if (!global.equals(real.global)) {
                        return false;
                    } else {
                        // pass
                    }
                } else {
                    if (real.global != null) {
                        return false;
                    } else {
                        // pass
                    }
                }
                if (res != null) {
                    if (res.equals(real.res)) {
                        // pass
                    } else {
                        return false;
                    }
                } else {
                    if (real.res != null) {
                        return false;
                    } else {
                        // pass
                    }
                }
            } else {
                return false;
            }
            return true;
        }

        @Override
        public String toString() {
            return String.format("PublicVoteInfo{global:%s, res:%s}", global, res);
        }
    }

    public static class ResInfo {
        public String url;
        public String md5;

        @Override
        public boolean equals(Object o) {
            if (o != null && o instanceof ResInfo) {
                ResInfo real = (ResInfo) o;
                return TextUtils.equals(url, real.url) && TextUtils.equals(md5, real.md5);
            }
            return false;
        }

        @Override
        public String toString() {
            return String.format("ResInfo{url:%s, md5:%s}", url, md5);
        }
    }

    public static class GlobalInfo {
        public int flag;

        @Override
        public boolean equals(Object o) {
            if (o != null && o instanceof GlobalInfo) {
                GlobalInfo real = (GlobalInfo) o;
                return real.flag == flag;
            }
            return false;
        }

        @Override
        public String toString() {
            return String.format("GlobalInfo{flag:%d}", flag);
        }
    }

    public boolean isCheckShineOn() {
        return check_shine == 1;
    }

    public boolean isValid() {
        return statusCode == 200;
    }

    @Override
    public boolean equals(Object o) {
        if (o != null && o instanceof Config) {
            Config realB = (Config) o;
            if (TextUtils.equals(jsonFullString, realB.jsonFullString)) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    @Override
    public String toString() {
        return String.format("Config{statusCode:%d, public_vote:%s, check_shine:%d, jsonFullString:%s, p2p:%s}",
                statusCode, public_vote, check_shine, jsonFullString, p2p);
    }

    public static class MobileI {

        public int flag;
        public String desc;

        public int getFlag() {
            return flag;
        }

        public void setFlag(int flag) {
            this.flag = flag;
        }

        public String getDesc() {
            return desc;
        }

        public void setDesc(String desc) {
            this.desc = desc;
        }

        @Override
        public String toString() {
            Gson gson = new Gson();
            return gson.toJson(this);
        }
    }

    public static class P2PConfig {
        // connection timeout
        public int conn_ts = 501; // ms

        @Override
        public String toString() {
            return "P2PConfig{" +
                    "conn_ts=" + conn_ts +
                    '}';
        }
    }
}
