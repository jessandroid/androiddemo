
package com.qihoo360.homecamera.mobile.entity;

import android.text.TextUtils;

import com.nostra13.universalimageloader.core.ImageLoader;

import java.io.File;
import java.io.Serializable;

/**
 * Created by Administrator on 2014/11/11.
 */
public class AlbumInfo implements Serializable {
    // region Data
    private static final long serialVersionUID = 4131840882181956626L;

    /**
     * 媒体文件类型:0-图片,1-GIF图
     */
    public enum DataType {
        IMAGE, GIF
    }

    /**
     * 文件分享类型:
     * 0-正常直接分享,
     * 1-IMAGE-魔拍分享
     */
    public enum ShareType {
        None, NORMAL, EDIT
    }

    public enum ShareDataTypes {
        Text, Image, Gif,MESSAGE_HTML
    }

    public enum ShareDicTypes {
        WXCircle, WXFriend, Weibo, QQ, QQZone, MORE
    }

    private DataType dataType;
    public ShareType shareType = ShareType.NORMAL;

    private String localPath;
    private String urlPath;
    private String defaultPath;
    private int defaultDraw;

    private String title;
    private long createTime;

    public Object relationObj;

    // region Share

    public class AlbumShareInfo {
        public String sourceUrl;

        public ShareDataTypes shareDataType = ShareDataTypes.Image;
        public ShareDicTypes shareDicType;
        public String shareUrl;
        public String shareKey;
        public String WeiboText;
        public String WXCircleText;
        public String WXFriendTitle;
        public String WXFriendDescription;
        public String QQText;
        public String path;

        public void setShareImage(String path){
            this.path = path;
        }

        @SuppressWarnings("deprecation")
        public String getSharePath() {
            if (shareDataType == ShareDataTypes.Gif && shareDicType == ShareDicTypes.Weibo) {
                return ImageLoader.getInstance().getDiskCache().get(defaultPath).getPath();
                // return String.format("http://p0.qhimg.com/%s.gif", shareKey);
            }

            return localPath;
        }
    }

    private AlbumShareInfo mShareInfo;

    public AlbumShareInfo getShareInfo() {
        if (mShareInfo == null) {
            mShareInfo = new AlbumShareInfo();
        }
        return mShareInfo;
    }

    // endregion

    public DataType getDataType() {
        return dataType;
    }

    public void setDataType(DataType dataType) {
        this.dataType = dataType;
    }

    public ShareType getShareType() {
        return shareType;
    }

    public void setShareType(ShareType shareType) {
        this.shareType = shareType;
    }

    public String getLocalPath() {
        return localPath;
    }

    public void setLocalPath(String path) {
        this.localPath = path;
    }

    public String getUrlPath() {
        return urlPath;
    }

    public void setUrlPath(String urlPath) {
        this.urlPath = urlPath;
    }

    public String getDefaultPath() {
        return defaultPath;
    }

    public void setDefaultPath(String defaultPath) {
        this.defaultPath = defaultPath;
    }

    public int getDefaultDraw() {
        return defaultDraw;
    }

    public void setDefaultDraw(int defaultDraw) {
        this.defaultDraw = defaultDraw;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public boolean isLocalExist() {
        return !TextUtils.isEmpty(localPath) && new File(localPath).exists();
    }

    // endregion
}
