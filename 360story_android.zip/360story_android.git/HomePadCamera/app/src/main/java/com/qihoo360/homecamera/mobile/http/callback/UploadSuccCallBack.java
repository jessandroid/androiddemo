package com.qihoo360.homecamera.mobile.http.callback;

import com.qihoo360.homecamera.mobile.entity.UploadToken;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/3/2
 * Time: 16:15
 * To change this template use File | Settings | File Templates.
 */
public interface UploadSuccCallBack {

    public void succ(String string,UploadToken uploadToken);

    public void fail(String rs,int step,UploadToken uploadToken);

    public void progress(int step,int progress);

}
