package com.qihoo360.homecamera.machine.ui.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;

import com.qihoo360.homecamera.mobile.R;

public class AngleView extends View {

    private static int ANGLE = 50;
    private Point centerPoint;
    private float degrees;
    private Bitmap bitmap;
    private Paint paint;

    public AngleView(Context context, AttributeSet attrs) {
        super(context, attrs);
        bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.dot_video_angleview_machine);
        paint = new Paint();
        paint.setAntiAlias(true);
    }

    @Override
    protected void onDetachedFromWindow() {
         if (bitmap != null && !bitmap.isRecycled()) {
         bitmap.recycle();
         }
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (centerPoint == null) {
            int y = 120 * getWidth() / 262;
            centerPoint = new Point(getWidth() / 2, y);
        }

        if (bitmap != null && !bitmap.isRecycled()) {
            canvas.save();
            canvas.rotate(degrees, centerPoint.x, centerPoint.y);
            Rect rect = new Rect();
            rect.left = 0;
            rect.top = 0;
            rect.right = getWidth();
            rect.bottom = getHeight();
            canvas.drawBitmap(bitmap, null, rect, paint);
            canvas.restore();
        }
    }

    public void setProgress(int progress) {
        degrees = progress * ANGLE / 100 - ANGLE / 2;
        invalidate();
    }

    public void reset() {
        degrees = 0;
        invalidate();
    }
}
