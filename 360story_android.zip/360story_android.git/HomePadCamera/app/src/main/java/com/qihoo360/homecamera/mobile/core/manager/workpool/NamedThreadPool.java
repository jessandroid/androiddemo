
package com.qihoo360.homecamera.mobile.core.manager.workpool;


import java.util.Hashtable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

import com.qihoo360.homecamera.mobile.utils.CLog;

public class NamedThreadPool {
    private final Hashtable<String, ExecutorService> mPoolMap = new Hashtable<String, ExecutorService>();
    private final static Object mutex = new Object();
    private final static String Tag = "named-pool";
    private final static NamedThreadPool sInstance = new NamedThreadPool();

    public static NamedThreadPool getInstance() {
        return sInstance;
    }

    private NamedThreadPool() {

    }

    public void initPool(String name, ExecutorService pool) {
        synchronized (mutex) {
            if (mPoolMap.get(name) == null) {
                mPoolMap.put(name, pool);
                CLog.d(Tag, "Created pool " + name + " with excutor service " + pool.getClass().getSimpleName());
            }
        }
    }

    public void destroyPool(String name) {
        ExecutorService service = mPoolMap.remove(name);
        if (service != null) {
            CLog.d(Tag, "Shuting down pool:" + name);
            service.shutdownNow();
        }
    }

    public boolean hasPoolInited(String name) {
        return mPoolMap.get(name) != null;
    }

    public void initPool(String name, int threadCount) {
        synchronized (mutex) {
            if (mPoolMap.get(name) == null) {
                mPoolMap.put(name, Executors.newFixedThreadPool(threadCount));
                CLog.d(Tag, "Created pool " + name + " with thread count of " + threadCount);
            }
        }
    }

    public void submit(String poolName, Runnable job) {
        ExecutorService pool = mPoolMap.get(poolName);
        if (pool == null) {
            CLog.d(Tag, "pool " + poolName + " has not inited yet, init first before submiting jobs to it");
            return;
        }

        if (!pool.isShutdown() && !pool.isTerminated()) {
            pool.submit(job);
        }
    }

    public static class NamedThreadFactor implements ThreadFactory {
        private final String name;
        private int index;

        public NamedThreadFactor(String name) {
            this.name = name;
            this.index = 0;
        }

        @Override
        public Thread newThread(Runnable r) {
            return new Thread(name + "-" + (index++));
        }

    }
}
