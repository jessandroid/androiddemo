package com.qihoo360.homecamera.mobile.activity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.entity.SearchWordEntity;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.widget.EditTextWithFont;
import com.qihoo360.homecamera.mobile.widget.TagCloudView;
import com.qihoo360.homecamera.mobile.widget.TextViewWithFont;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;



/**
 * Created by zhaojunbo on 2016/3/16.
 * desc:
 */
public class SearchSongActivity extends BaseActivity implements TagCloudView.OnTagClickListener ,View.OnClickListener, ActionListener {

    private TextViewWithFont mTvCancel;
    private EditTextWithFont mEtSearch;
    private TagCloudView mTagCloudView;
    private ListView mTipsLv;
    private List<HashMap<String,Object>> data;
    private SearchWordEntity searchWordEntity;
    private boolean mSelectTag =false;
    private ImageView mDeleteIv;
    private ImageView mSearchIv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_song);
        mTvCancel = (TextViewWithFont) findViewById(R.id.tv_cancel);
        mTvCancel.setOnClickListener(this);
        mTipsLv = (ListView) findViewById(R.id.lv_search_tips);
        data = new ArrayList<HashMap<String,Object>>();
        SimpleAdapter adapter = new SimpleAdapter(this, data, R.layout.item_key_word, new String[]{"key"}, new int[]{R.id.tv_item});
        mTipsLv.setAdapter(adapter);
        mTipsLv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                mEtSearch.setText(searchWordEntity.data.data.get(position));
            }
        });
        mDeleteIv = (ImageView) findViewById(R.id.iv_delete);
        mDeleteIv.setOnClickListener(this);
        mEtSearch = (EditTextWithFont) findViewById(R.id.et_search);
        GlobalManager.getInstance().getSearchWordManager().registerActionListener(this);
        mEtSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!mSelectTag) {
                    if (!TextUtils.isEmpty(s.toString())) {
                        GlobalManager.getInstance().getSearchWordManager().asyncSearchWord(s.toString());
                    } else {
                        mTipsLv.setVisibility(View.INVISIBLE);
                    }
                } else {
                    mSelectTag = false;
                }
                mDeleteIv.setVisibility(s.length() > 0 ? View.VISIBLE : View.INVISIBLE);
            }
        });
        mTagCloudView = (TagCloudView) findViewById(R.id.tag_cloud_view);
        List<String> tags = new ArrayList<>();
        for (int i = 0; i < 20; i++) {
            tags.add("标签" + i);
        }
        TagCloudView tagCloudView8 = (TagCloudView) findViewById(R.id.tag_cloud_view);
        tagCloudView8.setTags(tags);
        tagCloudView8.setOnTagClickListener(this);
        tagCloudView8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CameraToast.showToast(getApplicationContext(), "TagView onClick");
//                CameraToast.showToast(getApplicationContext(), "TagView onClick",
//                        Toast.LENGTH_SHORT).show();
            }
        });
        mSearchIv = (ImageView) findViewById(R.id.iv_search);
        mSearchIv.setOnClickListener(this);
    }

    @Override
    public void onTagClick(int position, String tag) {
        if (position == -1) {
            CameraToast.showToast(getApplicationContext(), "点击末尾文字");
        } else {
            CameraToast.showToast(getApplicationContext(), "点击 position : " + position + "," + tag);
            mSelectTag = true;
            mEtSearch.setText(tag);
            mEtSearch.setSelection(tag.length());
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_cancel:
                finish();
                break;
            case R.id.iv_delete:
                mEtSearch.setText("");
                break;
            case R.id.iv_search:
                GlobalManager.getInstance().getSearchWordManager().asyncDoSearch(mEtSearch.getText().toString());
                break;
        }
    }

    @Override
    public Object actionPerformed(int actionCode, Object... args) {
        switch (actionCode) {
            case Actions.SearchWord.SEARCH_WORD_KEY_SUCCESS: {
                data.clear();
                searchWordEntity = (SearchWordEntity) args[0];
                for (int i = 0;i < searchWordEntity.data.data.size();i++) {
                    CLog.e("searchword", searchWordEntity.data.data.get(i));
                    HashMap<String,Object>map = new HashMap<String,Object>();
                    map.put("key", searchWordEntity.data.data.get(i));
                    data.add(map);
                }
                mTipsLv.setVisibility(searchWordEntity.data.data.size() > 0 ? View.VISIBLE : View.INVISIBLE);
                return Boolean.TRUE;
            }
            case Actions.SearchWord.SEARCH_WORD_KEY_FAIL: {
                if (args == null || args.length == 0) {
//                    CameraToast.showErrorToast(this, "请求失败");
                } else {
                    CameraToast.showErrorToast((String) args[0]);
                }
                mTipsLv.setVisibility(View.INVISIBLE);
                return Boolean.TRUE;
            }
            case Actions.SearchWord.SEARCH_WORD_SUCCESS: {
                SearchWordEntity searchWordEntity = (SearchWordEntity) args[0];
                for (int i = 0;i < searchWordEntity.data.data.size();i++) {
                    CLog.e("searchword", searchWordEntity.data.data.get(i));

                }
                return Boolean.TRUE;
            }
            case Actions.SearchWord.SEARCH_WORD_FAIL: {
                if (args == null || args.length == 0) {
                    CameraToast.showErrorToast(this, "请求失败");
                } else {
                    CameraToast.showErrorToast((String) args[0]);
                }
                return Boolean.TRUE;
            }

        }
        return null;
    }

    @Override
    public int getProperty() {
        return 0;
    }
}
