package com.qihoo360.homecamera.mobile.exception;

public class CameraAesException extends CameraException{

	/**
	 *Des加解密 异常
	 */
	private static final long serialVersionUID = 1L;
	public CameraAesException(String message) {
		super(message);
	}
}
