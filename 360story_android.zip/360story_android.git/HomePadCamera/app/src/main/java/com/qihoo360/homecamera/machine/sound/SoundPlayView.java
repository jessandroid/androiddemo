
package com.qihoo360.homecamera.machine.sound;

import android.animation.Animator;
import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.qihoo360.homecamera.machine.sound.entity.SoundPlayInfo;
import com.qihoo360.homecamera.machine.sound.entity.SoundPlayInfo.SoundInfo;
import com.qihoo360.homecamera.machine.sound.manager.ConnectManager;
import com.qihoo360.homecamera.machine.sound.manager.SoundInfoManager;
import com.qihoo360.homecamera.machine.sound.manager.SoundTask;
import com.qihoo360.homecamera.machine.ui.widget.MarqueeTextView;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.SysConfig;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.imageloader.ImageLoaderHelper;
import com.qihoo360.homecamera.mobile.widget.listview.PullToRefreshBase;
import com.qihoo360.homecamera.mobile.widget.listview.PullToRefreshBase.Mode;
import com.qihoo360.homecamera.mobile.widget.listview.PullToRefreshListView;

/**
 * @author chengxiangyu
 */
public class SoundPlayView extends RelativeLayout implements ActionListener,
        OnClickListener {
    private static final int BASE_ID = 300000;

    private Context mContext;
    private LayoutInflater inflater;
    private DisplayImageOptions options;
//    public ButtonLayoutNew mSnapshotBtn;// 截屏按钮
//    public ButtonLayoutNew mRecordBtn;// 录像按钮
//    public ButtonLayoutNew mBeautyBtn;// 魔拍按钮
//    private ButtonLayoutNew mCloseBtn;// 关闭按钮

    private SoundIconView mSoundIconView;
    private ImageView imageControl;
    private ImageView imageList;

    private MarqueeTextView mtextTitle;

    private PullToRefreshListView listView;
    private MyListAdapter mAdapter;

    private SoundInfoManager mSoundInfoManager;
    private SoundPlayInfo mSoundPlayInfo = null;

    private boolean isVideoPlay = false;

    private View lastView = null;// 记录最后一次的view
    private int lastPosition = -1;// 记录最后一次的play位置

    private String mSn = "123";

    public SoundPlayView(Context context) {
        super(context);
        init(context);
    }

    public SoundPlayView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public void setSn(String sn) {
        mSn = sn;
        mSoundInfoManager = SoundInfoManager.getInstance(mSn);
        CLog.d("mSn ==1== " + mSn);
        mSoundInfoManager.registerActionListener(this);
        if (mSoundInfoManager.getSoundPlayInfo() != null
                && mSoundInfoManager.getSoundPlayInfo().data != null
                && mSoundInfoManager.getSoundPlayInfo().data.size() > 0) {
            CLog.d("有数据，用缓存");
            mSoundPlayInfo = mSoundInfoManager.getSoundPlayInfo();// 此时可以保证SoundPlayInfo和data不为空
            initPlayView(mSoundInfoManager.playNum, true);
        }
    }

    private void init(Context context) {
        mContext = context;
        inflater = LayoutInflater.from(mContext);
        mInflater = LayoutInflater.from(mContext);
        inflater.inflate(R.layout.sound_play_view, this);

        if (options == null) {
            options = new DisplayImageOptions.Builder()
                    .cloneFrom(ImageLoaderHelper.DEFAULT_LOCAL_DISPLAY_OPTIONS)
                    .showImageForEmptyUri(R.drawable.sound_item_icon_default)
                    .showImageOnFail(R.drawable.sound_item_icon_default)
                    .showImageOnLoading(R.drawable.sound_item_icon_default)
                    .build();
        }

//        mSnapshotBtn = (ButtonLayoutNew) findViewById(R.id.btn_snap_ll);
//        mSnapshotBtn.setOnClickListener(this);
//
//        mRecordBtn = (ButtonLayoutNew) findViewById(R.id.btn_record_ll);
//        mRecordBtn.setOnClickListener(this);
//
//        mBeautyBtn = (ButtonLayoutNew) findViewById(R.id.btn_beauty_ll);
//        mBeautyBtn.setOnClickListener(this);

//        mCloseBtn = (ButtonLayoutNew) findViewById(R.id.btn_close_ll);
//        mCloseBtn.setOnClickListener(this);

        mSoundIconView = (SoundIconView) findViewById(R.id.sound_play_icon_view);

        imageControl = (ImageView) findViewById(R.id.image_sound_play_control);
        imageControl.setOnClickListener(this);

        imageList = (ImageView) findViewById(R.id.image_sound_play_list);
        imageList.setOnClickListener(this);

        mtextTitle = (MarqueeTextView) findViewById(R.id.text_sound_play_title);

        listView = (PullToRefreshListView) findViewById(R.id.sound_list);

        setListView();
    }

    private void setListView() {
        listView.setMode(Mode.DISABLED);
        mAdapter = new MyListAdapter();
        listView.setAdapter(mAdapter);

        listView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {

                if (!ConnectManager.getInstance(mContext).getConnect()) {
                    // 如果断网则提示
                    CameraToast.show(mContext, R.string.sound_play_disconnect,
                            Toast.LENGTH_LONG);
                    return;
                }

                if (!isVideoPlay) {
                    // 如果视频显示不正常，屏蔽所有操作。后续可能添加提示
                    CameraToast.show(mContext,
                            R.string.sound_play_connect_play_error,
                            Toast.LENGTH_LONG);
                    return;
                }
                if (position < 1) {
                    return;
                } else {
                    position = position - 1;
                }
                // TODO 统计
                //AccUtil.getInstance().rtick.addStat(mSn, Stat.MY_CAMERA_PLAY_SONG);
                if (mSoundPlayListener != null && mSoundPlayInfo != null
                        && mSoundPlayInfo.data != null
                        && mSoundPlayInfo.data.size() > position) {
                    initPlayView(position, false);
                    mSoundPlayListener.onPlay(
                            mSoundPlayInfo.data.get(position),
                            SoundTask.SOUND_PLAY);
                }
                try {
                    if (lastView.getId() == BASE_ID + lastPosition) {
                        // 如果id不相等，则说明之前记录的itemview 已经刷新出了屏幕，则不需要刷新了
                        try {
                            mAdapter.getView(lastPosition, lastView, listView);
                        } catch (Exception e) {
                        }
                    }
                    mAdapter.getView(position, view, parent);
                } catch (Exception e) {
                }
                if (mSoundPlayListener != null) {
                    mSoundPlayListener.onRefresh(1);
                }
            }
        });
    }

    private void initPlayView(int pos, boolean isNeedSelection) {
        CLog.d("initPlayView = " + pos);
        if (pos >= 0) {
            mSoundInfoManager.playNum = pos;
        } else {
            pos = 0;
        }
        if (mSoundPlayInfo != null && mSoundPlayInfo.data != null
                && mSoundPlayInfo.data.size() > pos) {
            mSoundInfoManager.mSoundInfo = mSoundPlayInfo.data.get(pos);
            if (isNeedSelection) {
                listView.getRefreshableView().setSelection(pos + 1);
                mSoundInfoManager.isNeedSelection = false;
            }

            setIcon(mSoundInfoManager.mSoundInfo.getSongImg());
            if (!isVideoPlay) {
                // 如果摄像头离线或者缓冲，则变成停止状态
                stopTmpAni(mSn);
            } else {
                if (SoundInfoManager.getInstance(mSn).playState == SoundTask.SOUND_PAUSE) {
                    stopAni(mSn);
                } else if (SoundInfoManager.getInstance(mSn).playState == SoundTask.SOUND_STOP) {
                    reSetAni(mSn);
                } else if (SoundInfoManager.getInstance(mSn).playState == SoundTask.SOUND_PLAY) {
                    startAni(mSn);
                }
            }
        } else {
            // 没有获取到时显示,暂时不存在
        }

    }

    public SoundInfo getPlaySoundInfo() {
        return mSoundInfoManager.mSoundInfo;
    }

    public void onDestroy() {
        if (mSoundInfoManager != null) {
            mSoundInfoManager.removeActionListener(this);
        }
    }

    /**
     * @return 是不是在播放
     */
    public int getPlayingState() {
        if (mSoundInfoManager != null) {
            return mSoundInfoManager.playState;
        } else
            return SoundTask.SOUND_STOP;
    }

    /**
     * 设置光盘图片
     *
     * @param url 图片地址
     */
    public void setIcon(String url) {
        String tagUrl = null;
        try {
            tagUrl = (String) mSoundIconView.getTag();
        } catch (Exception e) {
        }
        if (TextUtils.isEmpty(tagUrl) || TextUtils.isEmpty(url)
                || !url.equals(tagUrl)) {
            ImageLoader.getInstance()
                    .displayImage(url, mSoundIconView, options);
            mSoundIconView.setTag(url);
        }

    }

    public void onClick(View v) {
        if (!ConnectManager.getInstance(mContext).getConnect()) {
            // 如果断网则提示
            CameraToast.show(mContext, R.string.sound_play_disconnect,
                    Toast.LENGTH_LONG);
            return;
        }

        if (!isVideoPlay) {
            // 如果视频显示不正常，屏蔽所有操作。并提示
            CameraToast.show(mContext, R.string.sound_play_connect_play_error,
                    Toast.LENGTH_LONG);
            return;
        }
        switch (v.getId()) {
//            case R.id.btn_snap_ll:
//                // 截屏
//                break;
//            case R.id.btn_record_ll:
//                // 录像
//                break;
//            case R.id.btn_beauty_ll:
//                // 魔拍
//                break;
//            case R.id.btn_close_ll:
//                break;
            case R.id.image_sound_play_control:
                mAdapter.notifyDataSetChanged();
                break;
            case R.id.image_sound_play_list:

                break;
        }
        if (mSoundPlayListener != null) {
            mSoundPlayListener.onClick(v);
        }
    }

    public void update(String sn, int type, boolean isVideoPlay) {
        if (mSoundInfoManager == null) {
            mSn = sn;
            mSoundInfoManager = SoundInfoManager.getInstance(mSn);
            mSoundPlayInfo = mSoundInfoManager.getSoundPlayInfo();// 此时可以保证SoundPlayInfo和data不为空
        }

        this.isVideoPlay = isVideoPlay;
        if (lastView != null && lastPosition >= 0) {
            // 如果能找到对应界面，先刷新对应界面
            if (lastView.getId() == BASE_ID + lastPosition) {
                // 如果id不相等，则说明之前记录的itemview 已经刷新出了屏幕，则不需要刷新了
                try {
                    mAdapter.getView(lastPosition, lastView, listView);
                } catch (Exception e) {
                }
            }
        } else {
            mAdapter.notifyDataSetChanged();
        }
        initPlayView(mSoundInfoManager.playNum, true);
    }

    /**
     * 退出动画
     *
     * @param duration
     */
    public void animatorOut(int duration) {
        ViewPropertyAnimator animator = animate();
        animator.setDuration(duration);
        animator.translationX(SysConfig.BASE_SCREEN_WIDTH);
        animator.setListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {

            }

            @Override
            public void onAnimationEnd(Animator animation) {
                View v = (View) getParent();
                if (v != null) {
                    v.setVisibility(View.GONE);
                }
            }

            @Override
            public void onAnimationCancel(Animator animation) {

            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }
        });
        animator.start();
    }

    @Override
    public void setVisibility(int visibility) {
        super.setVisibility(visibility);
        View v = (View) getParent();
        if (v != null) {
            v.setVisibility(visibility);
        }
    }

    /**
     * 进入动画
     *
     * @param duration
     */
    public void animatorIn(int duration) {
        setVisibility(View.VISIBLE);
        ViewPropertyAnimator animator = animate();
        animator.setDuration(duration);
        animator.x(SysConfig.BASE_SCREEN_WIDTH);
        animator.translationX(0);
        animator.setListener(null);
        animator.start();
    }

    public boolean isShowed() {
        if (getParent() != null) {
            View v = (View) getParent();
            return v.getVisibility() == View.VISIBLE;
        }
        return false;
    }

    /**
     * 开始动画
     */
    public void startAni(String sn) {
        if (mSoundInfoManager == null) {
            mSn = sn;
            mSoundInfoManager = SoundInfoManager.getInstance(mSn);
            mSoundPlayInfo = mSoundInfoManager.getSoundPlayInfo();// 此时可以保证SoundPlayInfo和data不为空
        }
        mSoundInfoManager.playState = SoundTask.SOUND_PLAY;
        if (mSoundInfoManager != null && mSoundInfoManager.mSoundInfo != null) {
            mtextTitle.setText(mSoundInfoManager.mSoundInfo.getSongName()
                    + mContext.getResources().getString(
                    R.string.sound_play_title_add));
        }
        imageControl.setImageResource(R.drawable.sound_btn_pause_bg);
        mSoundIconView.startAni();
        if (mSoundPlayListener != null) {
            mSoundPlayListener.onPlayStateChange(SoundTask.SOUND_PLAY);
        }
    }

    /**
     * 停止动画
     */
    public void stopAni(String sn) {
        if (mSoundInfoManager == null) {
            mSn = sn;
            mSoundInfoManager = SoundInfoManager.getInstance(mSn);
            mSoundPlayInfo = mSoundInfoManager.getSoundPlayInfo();// 此时可以保证SoundPlayInfo和data不为空
        }
        mSoundInfoManager.playState = SoundTask.SOUND_PAUSE;
        if (mSoundInfoManager != null && mSoundInfoManager.mSoundInfo != null) {
            mtextTitle.setText(mSoundInfoManager.mSoundInfo.getSongName());
        } else {
            mtextTitle.setText(mtextTitle
                    .getText()
                    .toString()
                    .replace(
                            mContext.getResources().getString(
                                    R.string.sound_play_title_add),
                            ""));
        }
        imageControl.setImageResource(R.drawable.sound_btn_play_bg);
        mSoundIconView.stopAni();
        if (mSoundPlayListener != null) {
            mSoundPlayListener.onPlayStateChange(SoundTask.SOUND_PAUSE);
        }
    }

    /**
     * 临时性停止动画 由于有些卡顿或者离线需要停止播放，但不卡顿了，还需要改回原来的状态
     */
    private void stopTmpAni(String sn) {
        if (mSoundInfoManager == null) {
            mSn = sn;
            mSoundInfoManager = SoundInfoManager.getInstance(mSn);
            mSoundPlayInfo = mSoundInfoManager.getSoundPlayInfo();// 此时可以保证SoundPlayInfo和data不为空
        }
        if (mSoundInfoManager != null && mSoundInfoManager.mSoundInfo != null) {
            mtextTitle.setText(mSoundInfoManager.mSoundInfo.getSongName());
        } else {
            mtextTitle.setText(mtextTitle
                    .getText()
                    .toString()
                    .replace(
                            mContext.getResources().getString(
                                    R.string.sound_play_title_add),
                            ""));
        }
        imageControl.setImageResource(R.drawable.sound_btn_play_bg);
        mSoundIconView.stopAni();
        if (mSoundPlayListener != null) {
            mSoundPlayListener.onPlayStateChange(SoundTask.SOUND_PAUSE);
        }
    }

    /**
     * 重制动画
     */
    public void reSetAni(String sn) {
        if (mSoundInfoManager == null) {
            mSn = sn;
            mSoundInfoManager = SoundInfoManager.getInstance(mSn);
            mSoundPlayInfo = mSoundInfoManager.getSoundPlayInfo();// 此时可以保证SoundPlayInfo和data不为空
        }
        mSoundInfoManager.playState = SoundTask.SOUND_STOP;
        if (mSoundInfoManager != null && mSoundInfoManager.mSoundInfo != null) {
            mtextTitle.setText(mSoundInfoManager.mSoundInfo.getSongName());
        } else {
            mtextTitle.setText(mtextTitle
                    .getText()
                    .toString()
                    .replace(
                            mContext.getResources().getString(
                                    R.string.sound_play_title_add),
                            ""));
        }
        imageControl.setImageResource(R.drawable.sound_btn_play_bg);
        mSoundIconView.stopAni();
        if (mSoundPlayListener != null) {
            mSoundPlayListener.onPlayStateChange(SoundTask.SOUND_STOP);
        }
    }

    private LayoutInflater mInflater;

    public class MyListAdapter extends BaseAdapter {
        public MyListAdapter() {
        }

        @Override
        public int getCount() {
            if (mSoundPlayInfo == null) {
                return 0;
            } else
                return mSoundPlayInfo.data.size();
        }

        @Override
        public Object getItem(int position) {
            if (mSoundPlayInfo == null
                    || position >= mSoundPlayInfo.data.size()) {
                return null;
            } else
                return mSoundPlayInfo.data.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (mSoundPlayInfo == null
                    || position >= mSoundPlayInfo.data.size()) {
                return convertView;
            }
            ViewHolder viewHolder = null;
            if (convertView == null) {
                convertView = mInflater.inflate(R.layout.sound_play_list_item,
                        null);
                viewHolder = new ViewHolder();
                viewHolder.icon = (SoundIconView) convertView
                        .findViewById(R.id.sound_play_icon_view);// 图标
                viewHolder.icon.setLayer(true);
                viewHolder.waveView = (SoundWaveView) convertView
                        .findViewById(R.id.sound_play_wave_view);// 歌声波浪
                viewHolder.waveView.setSelfAni(false);
                viewHolder.title = (MarqueeTextView) convertView
                        .findViewById(R.id.text_sound_play_title);// 歌曲名字
                viewHolder.source = (MarqueeTextView) convertView
                        .findViewById(R.id.text_sound_play_source);// 来源
                viewHolder.control = (ImageView) convertView
                        .findViewById(R.id.image_sound_play_control);
//                viewHolder.line = convertView.findViewById(R.id.line);
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }
            convertView.setId(BASE_ID + position);
            SoundInfo info = mSoundPlayInfo.data.get(position);
            viewHolder.title.setText(info.getSongName());
            if (TextUtils.isEmpty(viewHolder.iconStr)
                    || TextUtils.isEmpty(info.getSongImg())
                    || !viewHolder.iconStr.equals(info.getSongImg())) {
                ImageLoader.getInstance().displayImage(info.getSongImg(),
                        viewHolder.icon, options);
            }

            if (!TextUtils.isEmpty(info.getSongSingerName())) {
                viewHolder.source.setText(info.getSongSingerName());
            } else {
                viewHolder.source.setText(R.string.sound_play_unknow_src);
            }
            if (mSoundInfoManager != null
                    && position == mSoundInfoManager.playNum
                    && SoundInfoManager.getInstance(mSn).playState != SoundTask.SOUND_STOP) {
                viewHolder.waveView.setVisibility(View.VISIBLE);
                if (SoundInfoManager.getInstance(mSn).playState == SoundTask.SOUND_PAUSE
                        || !isVideoPlay) {
                    viewHolder.waveView.stopAni();
                    viewHolder.title.setFocused(false);
                } else if (SoundInfoManager.getInstance(mSn).playState == SoundTask.SOUND_PLAY) {
                    viewHolder.title.setFocused(true);
                    viewHolder.waveView.startAni();
                }
                viewHolder.control.setVisibility(View.GONE);
                viewHolder.title.setTextColor(0xFF6692f7);
                viewHolder.source.setTextColor(0xFF6692f7);
                convertView.setBackgroundColor(0xFFe9e9eb);
                lastView = convertView;// 记录历史状态
                lastPosition = position;
            } else {
                viewHolder.waveView.setVisibility(View.GONE);
                viewHolder.waveView.stopAni();
                viewHolder.control.setVisibility(View.VISIBLE);
                viewHolder.title.setTextColor(0xFF0d0015);
                viewHolder.title.setFocused(false);
                viewHolder.source.setTextColor(0xFFa4a5ab);
                convertView.setBackgroundColor(0xFFf5f6f8);
            }
            return convertView;
        }

        class ViewHolder {
            public SoundIconView icon;// 图标
            public String iconStr = null;// 用于缓存图片地址，如果地址一样，则不刷新
            public SoundWaveView waveView;// 歌声波浪
            public MarqueeTextView title;// 歌曲名字
            public MarqueeTextView source;// 来源
            public ImageView control;
//            public View line;
        }

    }

    @Override
    public Object actionPerformed(int actionCode, Object... args) {
        final int sectionCode = actionCode & Actions.SECTION_MASK;
        switch (sectionCode) {
            case Actions.Sound.SECTION_BASE:
                return handleSoundAction(actionCode, args);
        }
        return Actions.ACTION_NOT_PROCESSED;
    }

    private Object handleSoundAction(int actionCode, Object[] args) {
        switch (actionCode) {
            case Actions.Sound.SOUND_LIST: {
                mSoundPlayInfo = mSoundInfoManager.getSoundPlayInfo();// 此时可以保证SoundPlayInfo和data不为空
                mAdapter.notifyDataSetChanged();
                initPlayView(mSoundInfoManager.playNum, true);
                if (mSoundPlayListener != null) {
                    mSoundPlayListener.onRefresh(0);
                }
            }
            return true;
            /*
             * case Actions.Sound.SOUND_REFRESH:{
             * initPlayView(mSoundInfoManager.playNum,true);
             * if(mSoundPlayListener != null){ mSoundPlayListener.onRefresh(0);
             * } } break;
             */
            case Actions.Sound.SOUND_PUSH: {
                try {
                    int state = (Integer) args[0];// 获取到push信息

                    switch (state) {
                        case SoundTask.SOUND_PLAY:
                            // 1播放音乐的状态;
                        case SoundTask.SOUND_PAUSE:
                            // 2暂停播放的状态
                        case SoundTask.SOUND_CONTINUE:
                            // 3继续播放的状态
                        case SoundTask.SOUND_STOP:
                            // 3结束播放的状态
                            mAdapter.notifyDataSetChanged();
                            initPlayView(mSoundInfoManager.playNum,
                                    mSoundInfoManager.isNeedSelection);
                            if (mSoundPlayListener != null) {
                                mSoundPlayListener.onRefresh(0);
                            }
                            break;
                        case SoundTask.SOUND_SHOW_CAMERA_NET_SLOW:
                            CameraToast.show(mContext,
                                    R.string.sound_play_camera_net_slow,
                                    Toast.LENGTH_LONG);
                            break;
                        default:
                            break;
                    }
                } catch (Exception e) {
                }
            }
            return true;
            case Actions.Sound.SOUND_ERROR: {
                CLog.d("SOUND_LIST 失败");
                if (mSoundPlayListener != null) {
                    mSoundPlayListener.onRefresh(2);
                }
            }
            return true;
        }
        return Actions.ACTION_NOT_PROCESSED;
    }

    /**********************
     * begin 控件事件回调类
     ********************/
    private SoundPlayListener mSoundPlayListener = null;

    public interface SoundPlayListener {
        public void onClick(View v);

        public void onPlay(SoundInfo info, int state);

        /**
         * @param type 0:播放列表或摄像头回馈刷新，1：item点击刷新，2：联网失败（播放列表或摄像头回馈）刷新
         */
        public void onRefresh(int type);// 刷新数据

        public void onPlayStateChange(int state);// 刷新数据
    }

    /**
     * @param listener 事件回调监听
     */
    public void setSoundPlayListener(SoundPlayListener listener) {
        mSoundPlayListener = listener;
    }

    @Override
    public int getProperty() {
        // TODO Auto-generated method stub
        return 0;
    }

    /********************** end 控件事件回调类 ********************/
}
