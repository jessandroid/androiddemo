
package com.qihoo360.homecamera.machine.play.audio;

import android.os.Build;
import android.text.TextUtils;

import com.qihoo360.homecamera.machine.entity.VoiceConf;
import com.qihoo360.homecamera.machine.preferences.Preferences;
import com.qihoo360.homecamera.machine.util.JSONUtils;
import com.qihoo360.homecamera.mobile.config.Const;
import com.qihoo360.homecamera.mobile.utils.CLog;

public class VqeLookupTable {

    public static class AudioSource {
        public static int VOICE_COMMUNICATION = 1;
        public static int VOICE_RECOGNITION = 2;
        public static int MIC = 3;
    }

    public static class FarAgc {
        public static int LEVEL0 = 0; // Disable
        public static int LEVEL1 = 1;
        public static int LEVEL2 = 2;
        public static int LEVEL3 = 3;
    }

    public static class NearNs {
        public static int LEVEL0 = 0; // Disable
        public static int LEVEL1 = 1;
        public static int LEVEL2 = 2;
        public static int LEVEL3 = 3;
    }

    public static class NearVad {
        public static int LEVEL0 = 0; // Disable
        public static int LEVEL1 = 1;
        public static int LEVEL2 = 2;
    }

    public static class VqeConfig {
        public String mBrand = null;
        public String mModel = null;
        public int mAudioSource = AudioSource.MIC;
        public boolean mEnableAEC = false;
        public int mFarCacheSizeInMs = 400; // 400 ms.
        public int mFarADJ = 10;
        public int mNearNs = NearNs.LEVEL3;
        public int mNearAdj = 10;
        public int mNearVad = NearVad.LEVEL0;

        public VqeConfig(String brand, String model) {
            mBrand = brand.toLowerCase();
            mModel = model.toLowerCase();
        }

        public VqeConfig(String brand, String model, int audioSource, boolean enableAEC, int farCacheSize,
                int farADJ, int nearNs, int nearAdj, int nearVad) {
            mBrand = brand.toLowerCase();
            mModel = model.toLowerCase();
            mAudioSource = audioSource;
            mEnableAEC = enableAEC;
            mFarCacheSizeInMs = farCacheSize;
            mFarADJ = farADJ;
            mNearNs = nearNs;
            mNearAdj = nearAdj;
            mNearVad = nearVad;
        }
    }

    public static VqeConfig getVqeConfig() {
        VqeConfig config = VqeLookupTable.getServerConfig();
        if (config == null && Const.DEBUG) {
            config = VoIPConfig.getVqeConfig();
            CLog.i("Load vqe config from voip config file.");
        }
        return config;
    }

    private static VqeConfig getServerConfig() {
        String conf = Preferences.getVoiceConf();
        if (TextUtils.isEmpty(conf) || TextUtils.equals("null",conf)) {
            return null;
        }

        VoiceConf voiceConf = JSONUtils.fromJson(VoiceConf.class, conf);
        VqeConfig config = new VqeConfig(Build.BRAND, Build.MODEL,
                voiceConf.mic_type,
                voiceConf.enable_aec,
                voiceConf.far_cache_size,
                voiceConf.far_adj,
                voiceConf.near_ns,
                voiceConf.near_adj,
                voiceConf.near_vad);
        return config;
    }

    public static boolean isSupport() {
        String conf = Preferences.getVoiceConf();
        if (Const.DEBUG) {
            return !TextUtils.isEmpty(conf) || VoIPConfig.isSupport();
        }
        return !TextUtils.isEmpty(conf);
    }
}
