package com.qihoo360.homecamera.mobile.interfaces;

import com.qihoo360.homecamera.mobile.entity.DeviceInfo;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/1/25
 * Time: 15:10
 * To change this template use File | Settings | File Templates.
 */
public interface CameraSettingCallBack {
    void setting(DeviceInfo camera);

    void del(DeviceInfo camera);
}
