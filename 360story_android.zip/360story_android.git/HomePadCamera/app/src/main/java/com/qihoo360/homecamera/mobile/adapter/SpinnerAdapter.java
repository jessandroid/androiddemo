package com.qihoo360.homecamera.mobile.adapter;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.qihoo360.homecamera.mobile.R;

import java.util.List;
import java.util.Map;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/4/13
 * Time: 17:42
 * To change this template use File | Settings | File Templates.
 */
public class SpinnerAdapter extends BaseAdapter {


    private List<Map<String, Object>> mData;
    private Context mContext;

    public SpinnerAdapter(Context mContext, List<Map<String, Object>> mData) {
        this.mContext = mContext;
        this.mData = mData;
    }

    @Override
    public int getCount() {
        return this.mData.size();
    }

    @Override
    public Object getItem(int position) {
        return this.mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View view = LayoutInflater.from(mContext).inflate(R.layout.pop_setting_layout, parent, false);
        TextView title = (TextView) view.findViewById(R.id.txt_item);
        ImageView itemLogo = (ImageView) view.findViewById(R.id.head);
        ImageView checkedImage = (ImageView) view.findViewById(R.id.checkedImage);
        checkedImage.setVisibility(View.GONE);
        Map<String, Object> map = mData.get(position);
        title.setText((String) map.get("title"));
        itemLogo.setImageDrawable((Drawable) map.get("img"));
        return view;
    }

}




