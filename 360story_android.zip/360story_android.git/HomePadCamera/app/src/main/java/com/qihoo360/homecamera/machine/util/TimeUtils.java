package com.qihoo360.homecamera.machine.util;

import java.util.Calendar;

/**
 * HomePadCamera
 * Description: 时间工具类
 * Created by liujunbin
 * on 2017/6/19.
 */

public class TimeUtils {

    /**
     * 获取当前时间
     *
     * @return
     */
    public static String getCurrentTime() {
        String currentTime = "";
        Calendar ca = Calendar.getInstance();
        int hour = ca.get(Calendar.HOUR_OF_DAY);
        int minute = ca.get(Calendar.MINUTE);
        String hourStr = hour + "";
        String minuteStr = minute + "";
        if (hour < 10 && hour > 0) {
            hourStr = "0" + hour;
        }
        if (minute < 10 && minute > 0) {
            minuteStr = "0" + minute;
        }
        currentTime = hourStr + ":" + minuteStr;
        return currentTime;
    }


}
