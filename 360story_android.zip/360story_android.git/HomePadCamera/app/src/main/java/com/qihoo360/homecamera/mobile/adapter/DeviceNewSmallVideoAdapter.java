package com.qihoo360.homecamera.mobile.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.drawable.GlideDrawable;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.entity.ImageInfoEntity;
import com.qihoo360.homecamera.mobile.utils.ImageCache;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/4/21
 * Time: 15:58
 * To change this template use File | Settings | File Templates.
 */
public class DeviceNewSmallVideoAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<ImageInfoEntity> list = new ArrayList<>();
    private Context context;
    private static final int TYPE_HEADER = 0;
    private static final int TYPE_ITEM = 1;
    private static final int TYPE_FOOTER = 2;
    private int totalCount = 0;
    private OnItemClick onItemClick;

    //首页下 小视频列表显示10 + 1(更多)
    private static final int SHOW_VIDEO_SUM = 10 + 1;

    public DeviceNewSmallVideoAdapter(Context context, List<ImageInfoEntity> list, OnItemClick onItemClick) {
        this.context = context;
        this.list = list;
        this.onItemClick = onItemClick;
    }


    public void dataChanage(List data) {
        this.list = data;
        notifyDataSetChanged();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.new_device_video_item, parent, false);
        return new ViewHolderItem(view, list);

    }


    @Override
    public long getItemId(int position) {
        return position;
    }


    public ImageInfoEntity getItem(int position) {
        return list.get(position);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        ViewHolderItem viewHolder = (ViewHolderItem) holder;
        ImageInfoEntity imageInfoEntity = list.get(position);
        if (imageInfoEntity.preview != null) {
            Glide.clear(viewHolder.image_head);
            String url = TextUtils.isEmpty(imageInfoEntity.preview.url) ? "" : imageInfoEntity.preview.url + "&Authorization=" + imageInfoEntity.preview.token;
            if (position == SHOW_VIDEO_SUM - 1) {
                if (list.size() >= 10) {
                    viewHolder.show_more.setVisibility(View.VISIBLE);
                    viewHolder.info_text.setVisibility(View.GONE);
                    doLoadImageSB(imageInfoEntity, url, viewHolder);
                } else {
                    doLoadImage(imageInfoEntity, url, viewHolder);
                    viewHolder.show_more.setVisibility(View.GONE);
                    viewHolder.info_text.setVisibility(View.VISIBLE);
                }
            } else {
                doLoadImage(imageInfoEntity, url, viewHolder);
                viewHolder.show_more.setVisibility(View.GONE);
                viewHolder.info_text.setVisibility(View.VISIBLE);
            }


            viewHolder.show_more.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onItemClick.onGrayClick(position);
                }
            });

            viewHolder.image_head.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onItemClick.onItemClick(position);
                }
            });
            viewHolder.info_text.setText(imageInfoEntity.getDateString());
        }
    }

    @Override
    public int getItemCount() {
        //首页
        if (list.size() >= SHOW_VIDEO_SUM) {
            return SHOW_VIDEO_SUM;
        }
        return list.size();
    }


    public class ViewHolderItem extends RecyclerView.ViewHolder {
        public View mView;
        public TextView info_text;
        public ImageView image_head;
        public View show_more;

        public ViewHolderItem(View view, List<ImageInfoEntity> list) {
            super(view);
            mView = view;
            info_text = (TextView) view.findViewById(R.id.video_long);
            image_head = (ImageView) view.findViewById(R.id.image_head);
            show_more = view.findViewById(R.id.show_more);
        }
    }

    public interface OnItemClick {
        public void onGrayClick(int i);

        public void onItemClick(int i);
    }


    public void doLoadImage(final ImageInfoEntity imageInfoEntity, String url, ViewHolderItem viewHolder) {
        String filePath = ImageCache.getInstance().checkCache(imageInfoEntity.fileName, ImageCache.THUMBNAIL);
        if (!TextUtils.isEmpty(filePath) && !Utils.isNetworkAvailable(context)) {
            Glide.with(context)
                    .load(new File(filePath))
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .error(R.drawable.video_default)
                    .into(viewHolder.image_head);

        } else {
            Glide.with(context)
                    .load(url)
                    .thumbnail(0.1f)
                    .placeholder(R.drawable.small_video_home)
                    .error(R.drawable.small_video_home)
                    .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                    .error(R.drawable.video_default)
                    .listener(new RequestListener<String, GlideDrawable>() {
                        @Override
                        public boolean onException(Exception e, String model, Target<GlideDrawable> target, boolean isFirstResource) {
                            return false;
                        }

                        @Override
                        public boolean onResourceReady(GlideDrawable resource, String model, Target<GlideDrawable> target, boolean isFromMemoryCache, boolean isFirstResource) {
                            ImageCache.getInstance().cacheImage(imageInfoEntity, ImageCache.THUMBNAIL);
                            return false;
                        }
                    })
                    .into(viewHolder.image_head);
        }

    }


    public void doLoadImageSB(final ImageInfoEntity imageInfoEntity, String url, ViewHolderItem viewHolder) {

        String filePath = ImageCache.getInstance().checkCache(imageInfoEntity.fileName, ImageCache.THUMBNAIL);

        if (!TextUtils.isEmpty(filePath)) {
            Glide.with(context)
                    .load(new File(filePath))
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .error(R.drawable.video_default)
                    .into(viewHolder.image_head);

        } else {
            Target target = Glide.with(context)
                    .load(url)
                    .thumbnail(0.1f)
                    .placeholder(R.drawable.small_video_home)
                    .skipMemoryCache(false)
                    .error(R.drawable.small_video_home)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .error(R.drawable.video_default)
                    .listener(new RequestListener<String, GlideDrawable>() {
                        @Override
                        public boolean onException(Exception e, String model, Target<GlideDrawable> target, boolean isFirstResource) {
                            return false;
                        }

                        @Override
                        public boolean onResourceReady(GlideDrawable resource, String model, Target<GlideDrawable> target, boolean isFromMemoryCache, boolean isFirstResource) {
                            //加载成功后 若为视频类型 则显示视频黑条
                            boolean isVideo = (imageInfoEntity.ftype == 1);

                            ImageCache.getInstance().cacheImage(imageInfoEntity, ImageCache.THUMBNAIL);

                            return false;
                        }
                    })
                    .into(viewHolder.image_head);
        }


    }

}
