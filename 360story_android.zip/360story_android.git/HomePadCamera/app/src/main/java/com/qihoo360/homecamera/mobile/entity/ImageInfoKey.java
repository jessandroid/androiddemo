package com.qihoo360.homecamera.mobile.entity;

/**
 * Created by zhaojunbo on 2016/3/29.
 * desc:
 */
public class ImageInfoKey {

    public String key;
    public boolean isChecked;

    public ImageInfoKey(String key) {
        this.key = key;
        this.isChecked = isChecked;
    }
}
