
package com.qihoo360.homecamera.mobile.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.SysConfig;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.entity.Contacts;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.ContactsHelper;
import com.qihoo360.homecamera.mobile.utils.ContactsIndexHelper;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.widget.contact.ContactsOperationView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by wdynetposa on 2015/3/13.
 */
public class ChooseContactActivity extends BaseActivity
        implements
        ContactsHelper.OnContactsLoad,
        ContactsOperationView.OnContactsOperationView {

    private EditText mSearchEt;
    private ContactsOperationView mContactsOperationView;
    private ImageView chooseContactBg;
    private Bitmap chooseBgBmp;
    private ImageView mBackBtn;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_contact);
        setTintManagerQWork(true);
        tintManager.setStatusBarTintColor(Color.parseColor("#00000000"));
        initView();
        initData();
        initListener();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        mContactsOperationView.updateContactsList();
    }

    @Override
    public void onDestroy() {
        if (chooseBgBmp != null) {
            chooseBgBmp.recycle();
            chooseBgBmp = null;
        }
        super.onDestroy();

        mSearchEt.setText("");
        ContactsHelper.getInstance().parseQwertyInputSearchContacts(null);

        List<Contacts> selectedContactsList = new ArrayList<Contacts>();
        selectedContactsList.addAll(ContactsHelper.getInstance().getSelectedContacts().values());
        CLog.i("onDestroy() selectedContactsList.size()=" + selectedContactsList.size());

        mContactsOperationView.clearSelectedContacts();
        ContactsHelper.getInstance().clearSelectedContacts();
        ContactsHelper.getInstance().setContactsChanged(true);
    }

    private void initView() {
        chooseContactBg = (ImageView) findViewById(R.id.choose_contact_bg);
        chooseContactBg.setMaxWidth(SysConfig.BASE_SCREEN_WIDTH);
        chooseContactBg.setMaxHeight(SysConfig.BASE_SCREEN_HEIGHT);
        chooseBgBmp = Utils.getBitmap(R.drawable.add_share_word_bg);
        chooseContactBg.setImageResource(R.drawable.add_share_word_bg);
        mSearchEt = (EditText) findViewById(R.id.contact_search_edit);
        mContactsOperationView =
                (ContactsOperationView) findViewById(R.id.contacts_operation_layout);
        mContactsOperationView.setOnContactsOperationView(this);
        mBackBtn = (ImageView) findViewById(R.id.btn_back);
        mBackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void initData() {
        ContactsHelper.getInstance().setOnContactsLoad(this);
        boolean startLoad = ContactsHelper.getInstance().startLoadContacts();
        if (true == startLoad) {
            mContactsOperationView.contactsLoading();
        }
    }

    private void initListener() {
        mSearchEt.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // TODO Auto-generated method stub

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // TODO Auto-generated method stub

            }

            @Override
            public void afterTextChanged(Editable s) {
                String curCharacter = s.toString().trim();

                if (TextUtils.isEmpty(curCharacter)) {
                    ContactsHelper.getInstance().parseQwertyInputSearchContacts(null);
                } else {
                    ContactsHelper.getInstance().parseQwertyInputSearchContacts(curCharacter);
                }
                mContactsOperationView.updateContactsList();

            }
        });
    }

    /* start:OnContactsLoad */
    @Override
    public void onContactsLoadSuccess() {
        ContactsHelper.getInstance().parseQwertyInputSearchContacts(null);
        mContactsOperationView.contactsLoadSuccess();

        // just background printing contacts information
        // ContactsHelper.getInstance().showContactsInfo();
        ContactsIndexHelper.getInstance().praseContacts(
                ContactsHelper.getInstance().getBaseContacts());
        // ContactsIndexHelper.getInstance().showContactsInfo();
    }

    @Override
    public void onContactsLoadFailed() {
        mContactsOperationView.contactsLoadFailed();
    }

    /* end:OnContactsLoad */

    /* start:OnContactsOperationView */
    @Override
    public void onListItemClick(Contacts contacts, int position) {
        /*
         * if(null!=contacts){ Intent intent=new Intent(mContext, ContactDetailActivity.class);
         * Bundle bundle=new Bundle(); bundle.putInt(ContactsOperationView.CONTACTS_INDEX,
         * position); intent.putExtras(bundle); mContext.startActivity(intent); }
         */
        InputMethodManager imm =
                (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm.isActive()) {
            imm.hideSoftInputFromWindow(mSearchEt.getWindowToken(), 0);
        }

        String phoneNum = contacts.getPhoneNumber();
        String realNum = "";
        try {
            realNum = phoneNum;//Utils.checkPhoneNum(phoneNum);
            List<String> phoneNumberList = new ArrayList<>();
            phoneNumberList.add(realNum);
            contacts.setPhoneNumberList(phoneNumberList);
        } catch (Exception e) {
            e.printStackTrace();
        }
//        int error = InputChecker.isPhoneNumberValid(realNum);
//        if (error == 0) {
            Intent intent = new Intent();
            intent.putExtra("contact", contacts);
            setResult(Constants.PHONE_LIST, intent);
            finish();
//        } else {
//            mSearchEt.setText("");
//            ContactsHelper.getInstance().parseQwertyInputSearchContacts(null);
//            mContactsOperationView.updateContactsList();
//            CameraToast.show(this, getString(R.string.choose_phone_number), Toast.LENGTH_SHORT);
//        }
    }

    @Override
    public void onScrollStateChanged() {
        InputMethodManager imm =
                (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm.isActive()) {
            imm.hideSoftInputFromWindow(mSearchEt.getWindowToken(), 0);
        }
    }
    /* end:OnContactsOperationView */
}
