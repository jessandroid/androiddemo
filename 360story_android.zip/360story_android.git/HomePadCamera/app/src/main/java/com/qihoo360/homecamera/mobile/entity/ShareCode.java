package com.qihoo360.homecamera.mobile.entity;

/**
 * @author  Tomcat
 * share camera to other person
 * server will response a json code
 *
 */
public class ShareCode extends Head {
    private static final long serialVersionUID = 4893891535459858808L;
    private String shareCode;
	private long expired;


	public String getShareCode() {
		return shareCode;
	}

	public void setShareCode(String shareCode) {
		this.shareCode = shareCode;
	}

	public long getExpired() {
		return expired;
	}
	public void setExpired(long expired) {
		this.expired = expired;
	}
	
	
	

}
