
package com.qihoo360.homecamera.mobile.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.qihoo.sdk.report.QHStatAgent;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.utils.CLog;


/**
 * 注册界面
 * 
 * @author lvpeng-s
 */
public class RegisterActivity extends Activity {
    private Context mContext;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = RegisterActivity.this;
        setContentView(R.layout.register);
        Button button = (Button) findViewById(R.id.btn);
        button.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, MainActivity.class);
                startActivity(intent);
                CLog.e("check", "RegisterActivity");
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        QHStatAgent.onResume(this);
        QHStatAgent.onPageStart(this, "RegisterActivity");
        CLog.i("yanggang", "RegisterActivity onPageStart");
    }

    @Override
    protected void onPause() {
        super.onPause();
        QHStatAgent.onPause(this);
        QHStatAgent.onPageEnd(this, "RegisterActivity");
        CLog.i("yanggang", "RegisterActivity onPageEnd");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN && event.getKeyCode() == KeyEvent.KEYCODE_BACK) {

        }
        return super.onKeyDown(keyCode, event);
    }

}
