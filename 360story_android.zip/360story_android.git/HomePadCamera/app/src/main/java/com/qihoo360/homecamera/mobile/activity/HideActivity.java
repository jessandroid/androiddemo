package com.qihoo360.homecamera.mobile.activity;

import android.app.NotificationManager;
import android.content.Intent;
import android.os.Bundle;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.entity.CommonMessageEntity;

/**
 * Created by zhaojunbo on 2016/4/27.
 * desc:
 */
public class HideActivity extends BaseActivity {

    private NotificationManager mNotifyManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.empty);
        mNotifyManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
    }

    @Override
    protected void onResume() {
        consumeMessage();
        super.onResume();
    }

    private void consumeMessage() {
        boolean hasMessage = false;
        for (int i = 0; i < Constants.CommonMessageList.size(); i++) {
            CommonMessageEntity commonMessageEntity = Constants.CommonMessageList.get(i);
            if (!commonMessageEntity.hasShow) {
                processMessage(commonMessageEntity);
                mNotifyManager.cancel(commonMessageEntity.getId());
                hasMessage = true;
            }
        }
        if (!hasMessage) {
            finish();
        }
    }

    private void processMessage(CommonMessageEntity commonMessageEntity) {
        switch (commonMessageEntity.messageType) {
            case CommonMessageEntity.FAMILY_BIND:
                showFamilyRequest(commonMessageEntity);
                break;
            case CommonMessageEntity.FRIEND_BIND:
                showFriendRequest(commonMessageEntity);
                break;
            case CommonMessageEntity.MASTER_AGREE:
            case CommonMessageEntity.MASTER_ADD:
            case CommonMessageEntity.CANCEL_SHARE:
            case CommonMessageEntity.KIBOT_UNBIND:
            case CommonMessageEntity.ALREADY_BIND:
                if(commonMessageEntity.messageType == CommonMessageEntity.MASTER_AGREE){
                    Intent i = new Intent(HideActivity.this, MainActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                }
                showCommonMessageDialog(commonMessageEntity);
                break;
            case CommonMessageEntity.MASTER_REFUSE:
                showMasterRefuse(commonMessageEntity);
                break;
            case CommonMessageEntity.FRIEND_AGREE:
                showFriendAgree(commonMessageEntity);
                break;
            case CommonMessageEntity.FRIEND_REJECT:
                showFriendReject(commonMessageEntity);
                break;
            case CommonMessageEntity.FRIEND_CANCEL:
                showFriendCancel(commonMessageEntity);
                break;
        }
    }

    @Override
    public void close() {
//        int leftCount = 0;
//        for (int i = 0; i < Constants.CommonMessageList.size(); i++) {
//            if (Constants.CommonMessageList.get(i).consumeState == 2 && Constants.CommonMessageList.get(i).messageType == CommonMessageEntity.FAMILY_BIND) {
//                leftCount++;
//            }
//            if (leftCount == 0) {
//                finish();
//            }
//        }
        if (mCamAlertDialogMap.size() == 0) {
            finish();
        }
    }
}
