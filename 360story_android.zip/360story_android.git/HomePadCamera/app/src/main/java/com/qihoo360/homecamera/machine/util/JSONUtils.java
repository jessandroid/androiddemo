
package com.qihoo360.homecamera.machine.util;

import com.google.gson.Gson;
import com.google.gson.JsonElement;

public class JSONUtils {
    public static Gson gson = new Gson();

    public static <T> T fromJson(Class<T> type, String source) {
        try {
            T result = gson.fromJson(source, type);
            return result;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static <T> T fromJson(Class<T> type, JsonElement source) {
        try {
            T result = gson.fromJson(source.toString(), type);
            return result;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static <T> String toJson(T obj) {
        String result = gson.toJson(obj);
        return result;
    }
}
