package com.qihoo360.homecamera.mobile.adapter;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import java.util.List;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/3/12
 * Time: 15:07
 * To change this template use File | Settings | File Templates.
 */
public class StoryPagerAdapter extends FragmentPagerAdapter {

    public final int COUNT = 2;
    private String[] titles = new String[]{"故事配音", "推送故事"};
    private Context context;
    private List<Fragment> fragments;

    public StoryPagerAdapter(FragmentManager fm, Context context,List<Fragment> fragments) {
        super(fm);
        this.context = context;
        this.fragments = fragments;
    }

    @Override
    public Fragment getItem(int position) {
        return fragments.get(position);
    }

    @Override
    public int getCount() {
        return fragments.size();
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return titles[position];
    }
}
