package com.qihoo360.homecamera.mobile.entity;


import android.os.Parcel;

import com.qihoo360.homecamera.device.config.DeviceConsts;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * Created by zhaojunbo on 2016/1/20.
 * desc:
 */
public class DeviceInfoList extends Head {

    public Data data = new Data();



    public static class Data {
        public ArrayList<DeviceInfo> device = new ArrayList<DeviceInfo>();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel out, int flags) {
        out.writeValue(data);
    }

    /**
     * 移除脏数据（不支持的设备）
     */
    public void removeDirtyData() {
        Iterator<DeviceInfo> iterator = data.device.iterator();
        while (iterator.hasNext()) {
            DeviceInfo deviceInfo = iterator.next();
            // 如果是不支持的设备类型则，移除
            if(deviceInfo == null || !DeviceConsts.Support.isDeviceTypeSupport(deviceInfo.deviceType)) {
                iterator.remove();
            }
        }
    }
}
