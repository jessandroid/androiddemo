package com.qihoo360.homecamera.machine.videoplay;

import android.graphics.SurfaceTexture;
import android.opengl.GLUtils;

import com.qihoo360.homecamera.mobile.utils.CLog;

import java.util.concurrent.atomic.AtomicBoolean;

import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.egl.EGLDisplay;
import javax.microedition.khronos.egl.EGLSurface;

public class GLProducerThread extends Thread {

    private AtomicBoolean mShouldRender;
    private SurfaceTexture mSurfaceTexture;
    private GLRenderer mRenderer;

    private EGL10 mEgl;
    private EGLDisplay mEglDisplay = EGL10.EGL_NO_DISPLAY;
    private EGLContext mEglContext = EGL10.EGL_NO_CONTEXT;
    private EGLSurface mEglSurface = EGL10.EGL_NO_SURFACE;

    private static final int EGL_CONTEXT_CLIENT_VERSION = 0x3098;
    private static final int EGL_OPENGL_ES2_BIT = 4;

    private boolean mMakeCurrentDone;

    public interface GLRenderer {
        public void drawFrame();
    }

    public GLProducerThread(SurfaceTexture surfaceTexture, GLRenderer renderer, AtomicBoolean shouldRender) {
        mSurfaceTexture = surfaceTexture;
        mRenderer = renderer;
        mShouldRender = shouldRender;
    }

    private void initGL() {
        mMakeCurrentDone = false;

        mEgl = (EGL10) EGLContext.getEGL();
        CLog.e("GLProducerThread2", "initGL start : " + Thread.currentThread());
        mEglDisplay = mEgl.eglGetDisplay(EGL10.EGL_DEFAULT_DISPLAY);
        if (mEglDisplay == EGL10.EGL_NO_DISPLAY) {
            CLog.e("GLProducerThread2", "eglGetdisplay failed : " +
                    GLUtils.getEGLErrorString(mEgl.eglGetError()));
            throw new RuntimeException("eglGetdisplay failed : " +
                    GLUtils.getEGLErrorString(mEgl.eglGetError()));
        }

        int[] version = new int[2];
        if (!mEgl.eglInitialize(mEglDisplay, version)) {
            CLog.e("GLProducerThread2", "eglInitialize failed : " +
                    GLUtils.getEGLErrorString(mEgl.eglGetError()));
            throw new RuntimeException("eglInitialize failed : " +
                    GLUtils.getEGLErrorString(mEgl.eglGetError()));
        }

        int[] configAttribs = {
                EGL10.EGL_BUFFER_SIZE, 32,
                EGL10.EGL_ALPHA_SIZE, 8,
                EGL10.EGL_BLUE_SIZE, 8,
                EGL10.EGL_GREEN_SIZE, 8,
                EGL10.EGL_RED_SIZE, 8,
                EGL10.EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,
                EGL10.EGL_SURFACE_TYPE, EGL10.EGL_WINDOW_BIT,
                EGL10.EGL_NONE
        };

        int[] numConfigs = new int[1];
        EGLConfig[] configs = new EGLConfig[1];
        if (!mEgl.eglChooseConfig(mEglDisplay, configAttribs, configs, 1, numConfigs)) {
            CLog.e("GLProducerThread2", "eglChooseConfig failed : " +
                    GLUtils.getEGLErrorString(mEgl.eglGetError()));
            throw new RuntimeException("eglChooseConfig failed : " +
                    GLUtils.getEGLErrorString(mEgl.eglGetError()));
        }

        int[] contextAttribs = {
                EGL_CONTEXT_CLIENT_VERSION, 2,
                EGL10.EGL_NONE
        };
        while ((mEglContext == EGL10.EGL_NO_CONTEXT || mEglSurface == EGL10.EGL_NO_SURFACE || !mMakeCurrentDone)
                && mShouldRender != null && mShouldRender.get() != false && !isInterrupted()) {

            if (mEglContext == EGL10.EGL_NO_CONTEXT) {
                mEglContext = mEgl.eglCreateContext(mEglDisplay, configs[0], EGL10.EGL_NO_CONTEXT, contextAttribs);
                if (mEglContext == EGL10.EGL_NO_CONTEXT) {
                    int error = mEgl.eglGetError();
                    String msg = "mEglContext == EGL10.EGL_NO_CONTEXT " + error;
                    CLog.e("GLProducerThread2", msg);
                    continue;
                }
            }
            if (mEglSurface == EGL10.EGL_NO_SURFACE) {
                mEglSurface = mEgl.eglCreateWindowSurface(mEglDisplay, configs[0], mSurfaceTexture, null);
                if (mEglSurface == EGL10.EGL_NO_SURFACE) {
                    int error = mEgl.eglGetError();
                    if (error == EGL10.EGL_BAD_NATIVE_WINDOW) {
                        CLog.e("GLProducerThread2", "eglCreateWindowSurface returned  EGL_BAD_NATIVE_WINDOW. ");
                    }
                    String msg = "eglCreateWindowSurface failed : eglError:" +
                            GLUtils.getEGLErrorString(mEgl.eglGetError()) + " configs:" + configs[0] + " mSurfaceTexture:" + mSurfaceTexture;
                    CLog.e("GLProducerThread2", msg);
                    continue;
                }
            }

            if (!mEgl.eglMakeCurrent(mEglDisplay, mEglSurface, mEglSurface, mEglContext)) {
                CLog.e("GLProducerThread2", "eglMakeCurrent failed : " +
                        GLUtils.getEGLErrorString(mEgl.eglGetError()));
                mMakeCurrentDone = false;
                continue;
            } else {
                mMakeCurrentDone = true;
            }
        }
    }

    private void destoryGL() {
        CLog.e("GLProducerThread2", "destoryGL " + Thread.currentThread());
        mEgl.eglMakeCurrent(mEglDisplay, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_CONTEXT);
        if (mEglContext != EGL10.EGL_NO_CONTEXT) {
            mEgl.eglDestroyContext(mEglDisplay, mEglContext);
        }
        if (mEglSurface != EGL10.EGL_NO_SURFACE) {
            mEgl.eglDestroySurface(mEglDisplay, mEglSurface);
        }
        mEglContext = EGL10.EGL_NO_CONTEXT;
        mEglSurface = EGL10.EGL_NO_SURFACE;
        mEgl.eglTerminate(mEglDisplay);
    }

    public void run() {
        CLog.e("GLProducerThread", "initGL and start draw");
        synchronized (GLProducerThread.class) {
            initGL();

            if (mRenderer != null) {
                ((GLRendererImpl) mRenderer).initGL();
            }

            while (mShouldRender != null && mShouldRender.get() != false && !isInterrupted()) {
                if (mRenderer != null) {
                    mRenderer.drawFrame();
                }
                mEgl.eglSwapBuffers(mEglDisplay, mEglSurface);
            }

            destoryGL();
        }
    }

    public void stopRender() {
        mShouldRender.set(false);
    }
}
