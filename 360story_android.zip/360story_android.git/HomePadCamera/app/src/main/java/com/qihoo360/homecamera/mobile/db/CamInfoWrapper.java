package com.qihoo360.homecamera.mobile.db;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

import com.qihoo360.homecamera.mobile.entity.CamInfo;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.utils.CLog;

/**
 * Created by zhaojunbo on 2016/5/5.
 * desc:
 */
public class CamInfoWrapper extends AbstractWrapper {

    public static final String TABLE_NAME = "cam_info";
    private static CamInfoWrapper mInstance;

    public static CamInfoWrapper getInstance() {
        if (mInstance == null) {
            synchronized (CamInfoWrapper.class) {
                if (mInstance == null) {
                    mInstance = new CamInfoWrapper();

                }
            }
        }
        return mInstance;
    }

    public void setCamInfoImg(String sn, String coverPath, String timeStamp) {
        SQLiteDatabase sqLiteDatabase = GlobalManager.getInstance().config().db.getWritableDatabase();
        if (existQidPadInfo(sn)) {
            updatePadInfo(sqLiteDatabase, sn, coverPath, timeStamp);
        } else {
            insertPadInfo(sqLiteDatabase, sn, coverPath, timeStamp);
        }
    }

    private long insertPadInfo(SQLiteDatabase sqLiteDatabase, String sn, String coverPath, String timeStamp) {
        long effectCount = 0;
        ContentValues values = new ContentValues();
        values.put(Field.KEY_SN, sn);
        values.put(Field.KEY_SCREEN_PATH, coverPath);
        values.put(Field.KEY_CREATE_TIME, timeStamp);
        effectCount = sqLiteDatabase.insert(TABLE_NAME, "", values);
        return effectCount;
    }


    private int updatePadInfo(SQLiteDatabase sqLiteDatabase, String sn, String coverPath, String timeStamp) {
        int effectCount = 0;
        ContentValues values = new ContentValues();
        values.put(Field.KEY_SN, sn);
        values.put(Field.KEY_SCREEN_PATH, coverPath);
        values.put(Field.KEY_CREATE_TIME, timeStamp);
        effectCount = sqLiteDatabase.update(TABLE_NAME, values, "sn=?", new String[]{
                sn
        });
        return effectCount;
    }

    private boolean existQidPadInfo(String sn) {
        long count = 0;
        SQLiteDatabase db = GlobalManager.getInstance().config().db.getReadableDatabase();
        StringBuffer sb = new StringBuffer("");
        sb.append("select count(_id) from ");
        sb.append(TABLE_NAME);
        sb.append(" where sn='" + sn + "'");
        try {
            SQLiteStatement statement = db.compileStatement(sb.toString());
            count = statement.simpleQueryForLong();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }
        return count > 0;
    }

    public CamInfo getCamInfoBySn(String sn) {
        SQLiteDatabase sqLiteDatabase = GlobalManager.getInstance().config().db.getWritableDatabase();
        CamInfo camInfo = new CamInfo();
        Cursor cursor = null;
        try {
            cursor = sqLiteDatabase.query(TABLE_NAME, null, "sn = ? ", new String[]{sn}, null, null, null);
            while (cursor.moveToNext()) {
                camInfo.sn = sn;
                camInfo.createTime = cursor.getLong(cursor.getColumnIndex(Field.KEY_CREATE_TIME));
                camInfo.screenPath = cursor.getString(cursor.getColumnIndex(Field.KEY_SCREEN_PATH));
            }
        } catch (Exception e) {
            CLog.e(e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return camInfo;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int toVersion) {

    }

    @Override
    public void onOpen(SQLiteDatabase db) {

    }


    private static final class Field {
        public static final String KEY_SN = "sn";
        public static final String KEY_SCREEN_PATH = "screen_path";
        public static final String KEY_CREATE_TIME = "create_time";
    }
}
