
package com.qihoo360.homecamera.mobile.adapter;

import java.util.List;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import com.qihoo360.homecamera.mobile.utils.ArrayUtil;

/**
 * 首页的ViewPager：负责添加view和title
 * 
 * @author lvpeng-s
 */
public class MainViewPagerAdapter extends FragmentPagerAdapter {

    private final List<Fragment> fragments;

    public MainViewPagerAdapter(FragmentManager fm, List<Fragment> fragments) {
        super(fm);
        this.fragments = fragments;
    }

    /**
     * 得到每个页面
     */
    @Override
    public Fragment getItem(int position) {
        return ArrayUtil.isAvailable(fragments) ? fragments.get(position)
                : null;
    }

    /**
     * 得到页面总数
     */
    @Override
    public int getCount() {
        return ArrayUtil.isAvailable(fragments) ? fragments.size() : 0;
    }

}
