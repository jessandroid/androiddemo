
package com.qihoo360.homecamera.mobile.core.manager.workpool;

import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

public class PoolThreadFactory implements ThreadFactory {
    private final ThreadFactory mPoolThreadFactory;
    private final String name;
    private int index = 0;

    public PoolThreadFactory(String name) {
        mPoolThreadFactory = Executors.defaultThreadFactory();
        this.name = name;
    }

    @Override
    public Thread newThread(Runnable r) {
        Thread thread = mPoolThreadFactory.newThread(r);
        thread.setName(name + "-pool-thread-" + index++);
        return thread;
    }

}
