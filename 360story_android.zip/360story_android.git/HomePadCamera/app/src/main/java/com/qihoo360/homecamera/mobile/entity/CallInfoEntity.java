package com.qihoo360.homecamera.mobile.entity;

/**
 * Created by zhaojunbo on 2016/3/17.
 * desc:
 */
public class CallInfoEntity {
    public String phone;
    public int state;

    public CallInfoEntity(String phone, int state) {
        this.phone = phone;
        this.state = state;
    }
}
