package com.qihoo360.homecamera.machine.ui.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.qihoo360.homecamera.machine.entity.BindBannerEntity;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.ui.storyui.holder.Holder;

import static com.bumptech.glide.load.DecodeFormat.PREFER_ARGB_8888;

public class BannerSubItemHolderView implements Holder<BindBannerEntity.Banner> {

    private ImageView imageView;

    private View mContainer;

    private View mClickCell;

    @Override
    public View createView(Context context, int position) {
        mContainer = LayoutInflater.from(context).inflate(R.layout.banner_holder_view, null);
        imageView = (ImageView) mContainer.findViewById(R.id.banner_img);
        return mContainer;
    }

    @Override
    public void UpdateUI(Context context, int position, BindBannerEntity.Banner data) {

        Glide.with(context)
                .load(data.imgUrl).asBitmap().format(PREFER_ARGB_8888)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .priority(Priority.HIGH)
                .error(R.drawable.badilong_black)
                .into(imageView);

        if(data.action==2){
            mContainer.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //TODO  需要用跳转浏览器打开网页

                }
            });
        }
    }
}
