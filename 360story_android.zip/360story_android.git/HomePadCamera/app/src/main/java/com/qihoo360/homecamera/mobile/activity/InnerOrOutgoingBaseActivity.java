package com.qihoo360.homecamera.mobile.activity;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaScannerConnection;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.justalk.cloud.lemon.MtcCall;
import com.justalk.cloud.lemon.MtcCallConstants;
import com.justalk.cloud.lemon.MtcMdm;
import com.justalk.cloud.lemon.MtcMedia;
import com.justalk.cloud.lemon.MtcMediaConstants;
import com.justalk.cloud.lemon.MtcUser;
import com.justalk.cloud.lemon.MtcUserConstants;
import com.justalk.cloud.zmf.ZmfAudio;
import com.qihoo360.homecamera.mobile.BuildConfig;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.config.Const;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.entity.DeviceInfo;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.FileUtil;
import com.qihoo360.homecamera.mobile.utils.QHStatAgentHelper;
import com.qihoo360.homecamera.mobile.utils.Statistics;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.utils.VibratorUtil;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Created by zhaojunbo on 2016/5/20.
 * desc:
 */
public abstract class InnerOrOutgoingBaseActivity extends BaseActivity implements ActionListener{

    protected HeadsetPlugReceiver headsetPlugReceiver;
    private WifiStateReceiver mWifiReceiver;
    private BroadcastReceiver mNotifyEndCallReceiver;   //小视频通知时，结束通话的Receiver
    private Animation mSnapshotAni_Alpha;// 定义动画
    protected TelephonyManager mTelephonyManager;
    protected PhoneListener mPhoneListener;
    protected int mCallId = -1;
    protected AudioManager mAudioManager;
    protected DeviceInfo mDeviceInfo;
    protected FrameLayout mShotFrameLayout;
    protected ImageView mCommonPreviewImg;
    protected Handler mTimerHandler = new Handler();
    protected Runnable mVideoShotRunnable;
    protected boolean mIsRecording = false;
    protected ImageView mRecordingIv;
    protected String mVideoSavePath = "";
    protected boolean mHasNoVideo = false;
    protected Runnable mToolAreaDelayDismissRunnable;
    protected int mRecordingSecond = 0;
    protected ImageView mRecordBtnIv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mAudioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        registerBaseReceiver();
        initVoice();
    }

    @Override
    protected void onDestroy() {
        unRegisterBaseReceiver();
        if (mSnapshotAni_Alpha != null) {
            mSnapshotAni_Alpha.cancel();
        }
        mTelephonyManager.listen(mPhoneListener, PhoneStateListener.LISTEN_NONE);
        try {
            if (mMediaPlayer != null) {
                if (mMediaPlayer.isPlaying()) {
                    mMediaPlayer.stop();
                }
                mMediaPlayer.release();
                mMediaPlayer = null;
            }
        } catch (IllegalStateException e) {
            e.printStackTrace();
        }
        super.onDestroy();
    }

    protected void registerBaseReceiver() {
        headsetPlugReceiver = new HeadsetPlugReceiver();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.HEADSET_PLUG");
        registerReceiver(headsetPlugReceiver, intentFilter);

        mWifiReceiver = new WifiStateReceiver(this);
        IntentFilter filter = new IntentFilter();
        filter.addAction(WifiManager.RSSI_CHANGED_ACTION);
        filter.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
        filter.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
        registerReceiver(mWifiReceiver, filter);

        mNotifyEndCallReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                preFinish();
            }
        };
        registerReceiver(mNotifyEndCallReceiver, new IntentFilter(Const.BROADCAST_NOTIFY_END_CALLING));
        GlobalManager.getInstance().getCommonManager().registerActionListener(this);
    }

    @Override
    public Object actionPerformed(int actionCode, Object... args){
        if (actionCode == Actions.Common.EXIT){
            finish();
            return Boolean.TRUE;
        }
        return Actions.ACTION_NOT_PROCESSED;
    }

    @Override
    public int getProperty(){return 0;}

    protected void unRegisterBaseReceiver() {
        try {
            if (headsetPlugReceiver != null) {
                unregisterReceiver(headsetPlugReceiver);
            }
            if (mWifiReceiver != null) {
                unregisterReceiver(mWifiReceiver);
            }
            if (mNotifyEndCallReceiver != null) {
                unregisterReceiver(mNotifyEndCallReceiver);
            }
            GlobalManager.getInstance().getCommonManager().removeActionListener(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public class HeadsetPlugReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.hasExtra("state")) {
                if (intent.getIntExtra("state", 0) == 0) {
                    switchMode(true);
                } else if (intent.getIntExtra("state", 0) == 1) {
                    switchMode(false);
                }
            }
        }
    }

    protected class PhoneListener extends PhoneStateListener {
        @Override
        public void onCallStateChanged(int state, String incomingNumber) {
            super.onCallStateChanged(state, incomingNumber);

            switch (state) {
                case TelephonyManager.CALL_STATE_RINGING://来电状态
                    preFinish();
                    break;
                case TelephonyManager.CALL_STATE_OFFHOOK://接听状态
                    preFinish();
                    break;
                case TelephonyManager.CALL_STATE_IDLE://挂断后回到空闲状态

                    break;

                default:
                    break;
            }
        }
    }

    protected void initReceiver() {
        mTelephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        mPhoneListener = new PhoneListener();
        mTelephonyManager.listen(mPhoneListener, PhoneStateListener.LISTEN_CALL_STATE);
    }

    protected void initVoice() {
        pauseMusic();
        switchModeDefault();
    }

    public class WifiStateReceiver extends BroadcastReceiver {

        Context context;

        public WifiStateReceiver(Context context) {
            this.context = context;
        }

        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(WifiManager.NETWORK_STATE_CHANGED_ACTION)) {
                NetworkInfo info = intent.getParcelableExtra(WifiManager.EXTRA_NETWORK_INFO);
                if (Utils.isMoblieNetwork(Utils.getContext())) {
                    changeTo3G();
                } else if (info.getState().equals(NetworkInfo.State.DISCONNECTED)) {//如果断开连接
                    wifiDisconnect();
                }
            } else if (intent.getAction().equals(WifiManager.WIFI_STATE_CHANGED_ACTION)) {
                int wifistate = intent.getIntExtra(WifiManager.EXTRA_WIFI_STATE, WifiManager.WIFI_STATE_DISABLED);
                if (Utils.isMoblieNetwork(Utils.getContext())) {
                    changeTo3G();
                } else if (wifistate == WifiManager.WIFI_STATE_DISABLED) {//如果关闭
                    wifiDisconnect();
                }
            }

        }
    }

    protected int getStreamType() {
        return ZmfAudio.outputGetStreamType(MtcMdm
                .Mtc_MdmGetAndroidAudioOutputDevice());
    }

    protected void saveCoverImg() {
//        String sn = MtcCall.Mtc_CallGetPeerName(mCallId);
//        String fileName = FileUtil.getInstance().getCoverImgFile() + "/" + sn + ".jpg";
//        MtcCall.Mtc_CallRenderSnapshot(mCallId, fileName);
//        CamInfoWrapper.getInstance().setCamInfoImg(sn, fileName, System.currentTimeMillis() * 0.001 + "");
    }

    public void showSnapShotEffect(final View mSnapshotSplash) {
        if (mSnapshotAni_Alpha == null) {
            mSnapshotAni_Alpha = new AlphaAnimation(1.0f, 0.0f);
            mSnapshotAni_Alpha.setDuration(500);
            mSnapshotAni_Alpha.setAnimationListener(new Animation.AnimationListener() {
                @Override
                public void onAnimationStart(Animation animation) {
                    if (mSnapshotSplash != null) {
                        mSnapshotSplash.setVisibility(View.VISIBLE);
                    }
                }

                @Override
                public void onAnimationEnd(Animation animation) {
                    if (mSnapshotSplash != null) {
                        mSnapshotSplash.setVisibility(View.INVISIBLE);
                    }
                }

                @Override
                public void onAnimationRepeat(Animation animation) {

                }
            });
        }
        runOnUiThread(new Runnable() {
            public void run() {
                if (mSnapshotSplash != null) {
                    mSnapshotSplash.startAnimation(mSnapshotAni_Alpha);
                }
            }
        });
    }

    protected void takeShot() {
        mShotFrameLayout.setVisibility(View.VISIBLE);
        SimpleDateFormat format = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss", Locale.getDefault());
        String fileName = FileUtil.getInstance().getSnapshotFile() + "/" + format.format(new Date()) + ".jpg";
        MtcCall.Mtc_CallRenderSnapshot(mCallId, fileName);
        try {
            FileInputStream fis = new FileInputStream(fileName);
            Bitmap bitmap = BitmapFactory.decodeStream(fis);
            mCommonPreviewImg.setImageBitmap(bitmap);
            MediaScannerConnection.scanFile(this, new String[]{fileName}, null, null);
            if (mTimerHandler != null && mVideoShotRunnable != null) {
                mTimerHandler.removeCallbacks(mVideoShotRunnable);
                mTimerHandler.postDelayed(mVideoShotRunnable, 5000);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        showCustomToast(getString(R.string.shot_save), Toast.LENGTH_SHORT);
        QHStatAgentHelper.commitCommonEvent("call_capture");
        if (BuildConfig.DEBUG) {
            CLog.justalkFile("qdas", "====拍照===");
        }
    }

    @Override
    public void finish() {
        if (mTimerHandler != null) {
            mTimerHandler.removeCallbacksAndMessages(null);
        }
        super.finish();
    }

    protected void pauseMusic() {
        AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
//        if (true) {
        am.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT);
//        } else {
//            am.abandonAudioFocus(null);
//        }
    }

    private Statistics mStatistics;

    protected void showState() {
        RelativeLayout sessionContainer = (RelativeLayout) findViewById(R.id.rl_rate_area);
        if (mStatistics == null && sessionContainer != null) {
            mStatistics = new Statistics(getApplicationContext(), mCallId);
            sessionContainer.addView(mStatistics, RelativeLayout.LayoutParams.MATCH_PARENT,
                    RelativeLayout.LayoutParams.MATCH_PARENT);
        } else {
            Statistics.sSessionId = mCallId;
        }
        if (mStatistics != null) {
            if (mStatistics.isShow()) {
                mStatistics.hideStat();
            } else {
                mStatistics.showStat(true);
            }
        }
    }

    protected void startRecordDoodleVideo(int callId, String filePath) {

        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put(MtcMedia.MtcMediaVideoRecordOptionKey, MtcMediaConstants.EN_MTC_MFILE_MP4_H264);
            jsonObject.put(MtcMedia.MtcMediaVideoFillModeKey, MtcMediaConstants.EN_MTC_VIDEO_RECORD_BOTH);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        MtcCall.Mtc_CallRecRecvVideoStart(callId, filePath, 360, 640,jsonObject.toString());


        //MtcCall.Mtc_CallRecRecvVideoStart(callId, filePath, (short) MtcMediaConstants.EN_MTC_MFILE_MP4_H264, 360, 640, MtcMediaConstants.EN_MTC_VIDEO_RECORD_BOTH);
    }

    protected void stopRecordDoodleVideo(int callId) {
        MtcCall.Mtc_CallRecRecvVideoStop(callId);
    }

    protected void clearCallMode() {
        if (mAudioManager == null) {
            return;
        }
        synchronized (this) {
            ZmfAudio.inputStopAll();
            ZmfAudio.outputStopAll();
        }
        mAudioManager.abandonAudioFocus(null);
        if (AudioManager.MODE_NORMAL != mAudioManager.getMode()) {
            mAudioManager.setMode(AudioManager.MODE_NORMAL);
        }
    }

    protected void setCallMode() {
        int mode = MtcMdm.Mtc_MdmGetAndroidAudioMode();
        if (mode != mAudioManager.getMode()) {
            mAudioManager.setMode(mode);
        }
        mAudioManager.requestAudioFocus(null, AudioManager.STREAM_VOICE_CALL, AudioManager.AUDIOFOCUS_GAIN);
        audioStart();
    }

    protected void callJustalk(final int callType) {
        new Thread(new Runnable() {
            @SuppressLint("DefaultLocale")
            @Override
            public void run() {
                String uri = MtcUser.Mtc_UserFormUri(MtcUserConstants.EN_MTC_USER_ID_USERNAME, mDeviceInfo.getSn());//13221690634//401000000017
                JSONObject jsonObject = new JSONObject();
                try {
                    jsonObject.put(MtcCall.MtcCallInfoHasVideoKey, true);
                    jsonObject.put(MtcCall.MtcCallInfoDisplayNameKey, "dddd");
                    jsonObject.put(MtcCall.MtcCallInfoPeerDisplayNameKey, "bbb");
                    jsonObject.put(MtcCallConstants.MtcCallInfoServerUserDataKey, String.format("{\"callType\":\"%d\"}", callType));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                int result = MtcCall.Mtc_CallJ(uri, 0, jsonObject.toString());
                mCallId = result;
                QHStatAgentHelper.startCallStick(result + "", "call_outgoing", callType + "", mDeviceInfo.getRelationTitle(), mDeviceInfo.getSn());
                CLog.justalkFile("拨打：callType：" + callType + "，jsonObject：" + jsonObject.toString() + ",uri:" + uri + ",number:" + result);
                CLog.e("phone_call", "监控拨打" + jsonObject.toString() + ",uri:" + uri + ",number:" + result);
            }
        }).start();
    }

    protected MediaPlayer mMediaPlayer = new MediaPlayer();
    private boolean mIsPlayRing = false;

    protected void startAlarm(boolean isNeedVibrate) {
        if (!mIsPlayRing) {
//            mMediaPlayer.setAudioStreamType(AudioManager.STREAM_RING);
//            mMediaPlayer = MediaPlayer.create(this, R.raw.ring_back_new);
            float volumn = (float) mAudioManager.getStreamVolume(AudioManager.STREAM_RING) / (float) mAudioManager.getStreamMaxVolume(AudioManager.STREAM_RING);
            switch (mAudioManager.getRingerMode()) {
                case AudioManager.RINGER_MODE_NORMAL:
                    if (isNeedVibrate) {
                        VibratorUtil.Vibrate(InnerOrOutgoingBaseActivity.this, 100);
                    }
                    break;
                case AudioManager.RINGER_MODE_SILENT:
                    volumn = 0;
                    break;
                case AudioManager.RINGER_MODE_VIBRATE:
                    if (isNeedVibrate) {
                        VibratorUtil.Vibrate(InnerOrOutgoingBaseActivity.this, 100);
                    }
                    volumn = 0;
                    break;
            }
//            try {
//                mMediaPlayer.setVolume(volumn, volumn);
//                mMediaPlayer.setLooping(true);
//                mMediaPlayer.start();
//                mIsPlayRing = true;
//            } catch (IllegalStateException e) {
//                e.printStackTrace();
//            }
            if (mMediaPlayer.isPlaying()) {
                mMediaPlayer.stop();
            }
            Uri uri = Uri.parse("android.resource://"+getPackageName()+"/"+R.raw.ring_back_new);
            try {
                mMediaPlayer.reset();
                mMediaPlayer.setDataSource(this, uri);
                mMediaPlayer.setAudioStreamType(AudioManager.STREAM_RING);
                mMediaPlayer.setVolume(volumn, volumn);
                mMediaPlayer.setLooping(true);
                mMediaPlayer.prepare();
            } catch (Exception e) {
                e.printStackTrace();
            }
            mMediaPlayer.start();
        }
    }

    protected void stopAlarm() {
        VibratorUtil.stopVibrate();
        if (mMediaPlayer != null) {
            try {
                mMediaPlayer.stop();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    protected void recordVideo() {
        if (mIsRecording) {
            mRecordBtnIv.setImageResource(R.drawable.vcr_selector);
            mRecordingIv.setVisibility(View.INVISIBLE);
            mRecordingIv.clearAnimation();
            showCustomToast(getString(R.string.record_save, mVideoSavePath), Toast.LENGTH_SHORT);
            mRecordingSecond = 0;
            stopRecordDoodleVideo(mCallId);
            MediaScannerConnection.scanFile(this, new String[]{mVideoSavePath}, null, null);
        } else {
            if (FileUtil.getInstance().getAvailableSpare() < 100) {
                showCustomToast(getResources().getString(R.string.space_less), Toast.LENGTH_SHORT);
                cancelDismissHandler();//发生点击事件取消消失
                return;
            } else if (mHasNoVideo) {
                showCustomToast(getResources().getString(R.string.other_cam_failed), Toast.LENGTH_SHORT);
                cancelDismissHandler();//发生点击事件取消消失
                return;
            }
            Animation anim = AnimationUtils.loadAnimation(this, R.anim.shape);
            mRecordingIv.startAnimation(anim);
            mRecordBtnIv.setImageResource(R.drawable.btn_recording);
            mRecordingIv.setVisibility(View.VISIBLE);
            SimpleDateFormat format = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss", Locale.getDefault());
            mVideoSavePath = FileUtil.getInstance().getRecordFile() + "/" + format.format(new Date()) + ".mp4";
            startRecordDoodleVideo(mCallId, mVideoSavePath);
            mTimerHandler.removeCallbacks(mToolAreaDelayDismissRunnable);
            QHStatAgentHelper.commitCommonEvent("call_record");
            if (BuildConfig.DEBUG) {
                CLog.justalkFile("qdas", "====录像===");
            }
        }
        mIsRecording = !mIsRecording;
    }

    protected void audioStart() {
    }

    protected void cancelDismissHandler(){}

    protected abstract void changeTo3G();

    protected abstract void wifiDisconnect();

    protected abstract void preFinish();
}
