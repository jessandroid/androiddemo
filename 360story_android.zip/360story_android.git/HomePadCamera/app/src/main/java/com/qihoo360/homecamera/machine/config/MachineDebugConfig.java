package com.qihoo360.homecamera.machine.config;

/**
 * Created by lixin3-s on 2016/11/5.
 */
public class MachineDebugConfig {
    public static final boolean DEBUG = true;
}
