
package com.qihoo360.homecamera.mobile.interfaces;

public interface CommandMessageInterface {
	 void onMessage(int msg, Object... args);
}
