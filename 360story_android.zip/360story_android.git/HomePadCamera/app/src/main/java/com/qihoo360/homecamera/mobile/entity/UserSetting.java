package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by yanggang on 2016/4/27.
 */
public class UserSetting extends Head {
    public Data data;

    public static class Data implements Parcelable {
        public String val;

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(this.val);
        }

        public Data() {
        }

        protected Data(Parcel in) {
            this.val = in.readString();
        }

        public static final Creator<Data> CREATOR = new Creator<Data>() {
            @Override
            public Data createFromParcel(Parcel source) {
                return new Data(source);
            }

            @Override
            public Data[] newArray(int size) {
                return new Data[size];
            }
        };
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(this.data, flags);
    }

    public UserSetting() {
    }

    protected UserSetting(Parcel in) {
        this.data = in.readParcelable(Data.class.getClassLoader());
    }

    public static final Creator<UserSetting> CREATOR = new Creator<UserSetting>() {
        @Override
        public UserSetting createFromParcel(Parcel source) {
            return new UserSetting(source);
        }

        @Override
        public UserSetting[] newArray(int size) {
            return new UserSetting[size];
        }
    };
}
