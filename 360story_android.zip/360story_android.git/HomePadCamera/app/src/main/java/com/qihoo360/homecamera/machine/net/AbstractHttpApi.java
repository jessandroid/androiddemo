package com.qihoo360.homecamera.machine.net;

import com.qihoo360.homecamera.mobile.exception.CameraAesException;
import com.qihoo360.homecamera.mobile.exception.CameraException;

import org.apache.http.NameValuePair;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

public interface AbstractHttpApi {

//  /**
//   *
//   * @param httpRequest http请求对象，可以是post或get对象
//   * @param clazz bean.class
//   * @return bean对象
//   */
//  abstract public <T extends Head> T doHttpRequest(HttpRequestBase httpRequest,
//      Class<? extends T> clazz);
//
//  /**
//   *  异步请求
//   * @param url 请求地址
//   * @param params 请求参数
//   * @param clazz bean.class
//   * @return bean对象
//   * @throws CameraAesException
//   * @throws JSONException
//   */
//  abstract public <T extends Head> T doAysnHttpRequest(String url, JSONObject params,
//      Class<? extends T> clazz) throws CameraAesException, JSONException;

    /**
     * 创建 HttpGet
     *
     * @param url            请求URL
     * @param nameValuePairs 参数键值对
     * @return org.apache.http.client.methods.HttpGet
     */
    abstract public HttpGet createHttpGet(String url, NameValuePair... nameValuePairs)
            throws CameraException;

    /**
     * 创建 HttpPost
     *
     * @param url            请求URL
     * @param params 参数键值对
     * @return org.apache.http.client.methods.HttpPost
     */
    abstract public HttpPost createHttpPost(String url, JSONObject params, boolean cookies) throws JSONException,
            CameraAesException;

    /**
   /*  * 创建 HttpPost
     *
     * @param url 请求URL
     * @param params 参数键值对
     * @param cookies
     * @return org.apache.http.client.methods.HttpPost
     *//*
    abstract public HttpPost createHttpPost(String url, JSONObject params, boolean cookies) throws JSONException,
            CameraAesException;
*/
    /**
     * 当需要上传图片等内容时，用于创建HttpURLConnection
     *
     * @param url
     * @param boundary
     * @return java.net.HttpURLConnection
     * @throws IOException
     */
    abstract public HttpURLConnection createHttpURLConnectionPost(URL url, String boundary)
            throws IOException;

}
