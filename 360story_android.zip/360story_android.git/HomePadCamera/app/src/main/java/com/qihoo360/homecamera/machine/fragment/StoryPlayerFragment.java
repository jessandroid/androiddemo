package com.qihoo360.homecamera.machine.fragment;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.nineoldandroids.animation.ObjectAnimator;
import com.nineoldandroids.animation.ValueAnimator;
import com.qihoo360.homecamera.machine.business.JsonManager;
import com.qihoo360.homecamera.machine.business.PlayConfig;
import com.qihoo360.homecamera.machine.business.SettingTask;
import com.qihoo360.homecamera.machine.business.TaskExecutor;
import com.qihoo360.homecamera.machine.entity.FavorResultEntity;
import com.qihoo360.homecamera.machine.entity.LocalSetting;
import com.qihoo360.homecamera.machine.entity.MachinePlaySingle;
import com.qihoo360.homecamera.machine.entity.MachineSong;
import com.qihoo360.homecamera.machine.entity.SongEntity;
import com.qihoo360.homecamera.machine.entity.SongListResponse;
import com.qihoo360.homecamera.machine.manager.MachinePlayInfoManager;
import com.qihoo360.homecamera.machine.popwin.AutoShutdownPopWin;
import com.qihoo360.homecamera.machine.popwin.BaseDialog;
import com.qihoo360.homecamera.machine.popwin.DefaultDialog;
import com.qihoo360.homecamera.machine.popwin.StoryPlayerPopWin;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.db.MachineSongWrapper;
import com.qihoo360.homecamera.mobile.image.my.GlideCircleTransform;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.ui.fragment.BaseFragment;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.Preferences;
import com.qihoo360.homecamera.mobile.utils.QHStatAgentHelper;
import com.qihoo360.homecamera.mobile.utils.Utils;
import org.json.JSONException;
import org.json.JSONObject;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.WeakHashMap;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

public class StoryPlayerFragment extends BaseFragment implements View.OnClickListener, ActionListener, StoryPlayerPopWin.StoryPopWinInterface{
    private View rootView;
    private ImageView mImageViewShowList;
    private StoryPlayerPopWin mStoryPlayerPopWin;
    private AutoShutdownPopWin mAutoShutdownPopWin;
    private ImageView mImageViewBack;
    private DefaultDialog mLockSwitchDialog;
    private ImageView mImageViewTime;//定时开关
    private TextView mTextViewTiming;//定时时间
    private ImageView mImageViewChildLock;//儿童锁
    private ImageView mImageViewCollect;//收藏
    private ImageView mImageViewLoop;   //循环模式
    private RelativeLayout coverBg;//封面图背景
    private ImageView mImageViewCover;  //封面图
    private ImageView srcLogo;          //来源
    private TextView mTextViewTitle;   //歌曲名称

    private RelativeLayout loopZone;
    private RelativeLayout lockZone;
    private RelativeLayout favorZone;
    private RelativeLayout timerZone;
    private RelativeLayout listZone;

    private boolean mPlaying = false;
    private String currentLoop = PlayConfig.CircleType.LISTCIRCLE;//默认是分类循环
    private boolean isCollected = false;

    private ObjectAnimator objectAnimator;

    private WeakHashMap<Integer, Drawable> mDrawbleCache;

    private ImageView mBtnPlay;//播放暂停
    private ImageView mPrePlayBtn;//上一首
    private ImageView mNextPlayBtn;//下一首

    private String snString;//设备号
    private LocalSetting settinginfo;//设置信息

    private MachinePlaySingle playSingle;
    private ArrayList<SongEntity> songList = new ArrayList<>();

    private int currentPage;//播放的儿歌属于第几页
    private int loadMorePage;//记录分页加载的pageid
    private String unique;  //专辑标识
    private String preUniqueId;
    private int totalSize;//歌曲总数

    private static final String NULLSTRING = "";
    private static final int NULLINT = -1000;
    private int currentCloseTime = -1;

    private MyHandler handler = new MyHandler(this);
    private boolean isOnline = false;

    private long preTime = 0;
    private MyRunnable runnable;

    private boolean timeSetting = false;//定时设置中
    private boolean loopSetting = true; //循环模式设置中

    private String coverurl;

    private Context mContext;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if(context==null){
            return;
        }else{
            mContext = context;
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.machine_player_controller, container, false);
        initViews();
        MachinePlayInfoManager.getInstance().registerActionListener(this);
        GlobalManager.getInstance().getMachineManager().registerActionListener(this);
        return rootView;
    }

 	private void initData() {
        setUnableStatus(false);
        snString = Preferences.getSelectedPad();
        mDrawbleCache = new WeakHashMap<>();
        //获取播放信息
        getPlayInfo();

        //获取本地设置
        doGetSetingCmd();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        initData();
    }

    @Override
    public void onDestroyView() {
        GlobalManager.getInstance().getMachineManager().removeActionListener(this);
        MachinePlayInfoManager.getInstance().removeActionListener(this);
        if(objectAnimator!=null){
            objectAnimator.cancel();
        }
        super.onDestroyView();
    }

    @Override
    public boolean onTabSwitched() {
        return false;
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_back:     //goBack
                getActivity().finish();
                getActivity().overridePendingTransition(0, R.anim.down_out);
                break;

            case R.id.list_zone: //查看播放列表
                showStoryList();
                break;

            case R.id.timer_zone:  //定时开关
                noNetTip();
                showAutoShutdown();
                break;

            case R.id.lock_zone:  //童锁开关
                noNetTip();
                if(settinginfo!=null){
                    if(settinginfo.localSettings.getChildlock()==1){
                        //之前是锁定，下次点，直接解锁
                        doLocalSettingCmd(NULLSTRING, PlayConfig.LockType.UNLOCK, NULLINT);
                    }else{
                        showLockSwitchDialog();
                    }
                }else{
                    showLockSwitchDialog();
                }
                break;

            case R.id.favor_zone:  //收藏，取消收藏
                noNetTip();
                onCollectBtnClick();
                break;

            case R.id.loop_zone:  //切换播放模式
                //TODO 进行本地设置操作
                noNetTip();
                loopSetting = true;
                doLocalSettingCmd(getNextLoop(currentLoop), NULLINT, NULLINT);
                break;

            case R.id.btn_play:     //播放、暂停
                noNetTip();
                onPlayBtnClick();
                break;

            case R.id.btn_previous:  //上一首
                noNetTip();
                doPrevOrNextCmd(PlayConfig.PlayType.PRESONG);
                break;

            case R.id.btn_next:      //下一首
                noNetTip();
                doPrevOrNextCmd(PlayConfig.PlayType.NEXTSONG);
                break;
        }
    }

    private String getNextLoop(String loopType){
        String nextType = "";
        if(TextUtils.equals(loopType, PlayConfig.CircleType.LISTCIRCLE)){
            nextType = PlayConfig.CircleType.SINGLECIRCLE;
        }else if(TextUtils.equals(loopType, PlayConfig.CircleType.SINGLECIRCLE)){
            nextType = PlayConfig.CircleType.LISTCIRCLE;
        }
        return nextType;
    }

    // override from ActionListener
    @Override
    public Object actionPerformed(int actionCode, Object... args) {

        switch (actionCode) {

            case Actions.MachinePlayInfo.NOTIFY_SINGLEPLAY_LIST: {
                handlePlaySingleChange((MachinePlaySingle) args[0], (String)args[1], (String)args[2]);
                return true;
            }

            case Actions.MachinePlayInfo.NOTIFY_LIST_UPDATE: {
                handleListUpdate((int)args[0],(String)args[1], (String)args[2]);
                return true;
            }

            case Actions.MachinePlayInfo.NOTIFY_MACHINE_BUSY:{
                handleBusy((String)args[0], (String)args[1]);
                return true;
            }

            case Actions.MachinePlayInfo.NOTIFY_LOCAL_SETTING_UPDATE:{
                String sn = (String)args[1];
                if(TextUtils.equals(sn, Preferences.getSelectedPad())){
                    handlerLocalSetting((LocalSetting) args[0]);
                }
                return true;
            }

            case Actions.GlobalActionCode.GET_SONGLIST_LIST: {
                int token = (int)args[1];
                if(mStoryPlayerPopWin!= null){
                    mStoryPlayerPopWin.setLoadingComplete();
                }
                if(token==1){
                    SongListResponse response = (SongListResponse)args[0];
                    if(response.errorCode==0){
                        coverurl = response.coverurl;
                        totalSize = response.total;
                        mStoryPlayerPopWin.totalPage = (response.total % response.pageSize == 0) ? response.total/response.pageSize : (response.total/response.pageSize + 1);
                        mStoryPlayerPopWin.setPlaySum(response.total);
                        handleFirstLoadOnlineList(response.data);
                        //加载封面图
                        Glide.with(getActivity())
                                .load(coverurl)
                                .diskCacheStrategy(DiskCacheStrategy.ALL)
                                .priority(Priority.HIGH)
                                .transform(new GlideCircleTransform(Utils.context))
                                .error(R.drawable.player_default_bg)
                                .into(mImageViewCover);

                    }else{
                        //TODO 获取列表失败
                    }
                }else if(token==2){
                    SongListResponse response = (SongListResponse)args[0];
                    if(response.errorCode==0){
                        handleLoadMoreOnlineList(response.data);
                    }else{
                        //TODO 获取列表失败
                    }

                }
                return true;
            }

            case Actions.MachinePlayInfo.NATIVE_NOTIFY_FAVOR_LIST_UPDATE:{
                if(playSingle!=null){
                    Observable.create(new Observable.OnSubscribe<Boolean>() {
                        @Override
                        public void call(Subscriber<? super Boolean> subscriber) {
                            subscriber.onNext(MachineSongWrapper.getInstance().isSongFavor(Preferences.getSelectedPad(), playSingle.getMediaInfo().getUniqueid()));
                            subscriber.onCompleted();
                        }
                    }).subscribeOn(Schedulers.io())
                            .observeOn(AndroidSchedulers.mainThread())
                            .subscribe(new Action1<Boolean>() {
                                @Override
                                public void call(Boolean aBoolean) {
                                    setCollectBtnState(aBoolean);
                                }
                            });
                }
                return true;
            }

            case Actions.MachinePlayInfo.NOTIFY_FAVOR_RESULT_UPDATE:{
                handlerFavorResult((FavorResultEntity)args[0], (String)args[1]);
                return true;
            }

            //导入列表有更新
            case Actions.MachinePlayInfo.NATIVE_NOTIFY_INSERT_LIST_UPDATE: {
                //TODO 处理导入列表有更新的push,只在播放导入列表的时候需要做处理
                if (playSingle.getMediaInfo().getType() == PlayConfig.ListType.INSERTLIST) {
                    Observable.create(new Observable.OnSubscribe<ArrayList<MachineSong>>() {
                        @Override
                        public void call(Subscriber<? super ArrayList<MachineSong>> subscriber) {
                            subscriber.onNext(MachineSongWrapper.getInstance().getMachineSongList(Preferences.getSelectedPad(), PlayConfig.ListType.INSERTLIST, playSingle.getUnique()));
                            subscriber.onCompleted();
                        }
                    }).subscribeOn(Schedulers.io())
                      .observeOn(AndroidSchedulers.mainThread())
                      .subscribe(new Action1<ArrayList<MachineSong>>() {
                          @Override
                          public void call(ArrayList<MachineSong> machineSongs) {
                              songList.clear();
                              for (MachineSong song : machineSongs) {
                                  songList.add(song);
                              }
                              mStoryPlayerPopWin.setData(songList, playSingle);
                              mStoryPlayerPopWin.setSectedSong(playSingle.getMediaInfo().getUniqueid());
                          }
                      });
                }
                return true;
            }

            //故事机闲着
            case Actions.MachinePlayInfo.NOTIFY_MACHINE_IS_FREE: {
                //TODO 故事机闲着，播放页面需要做一些处理
                setUnableStatus(false);
                return true;
            }

            case Actions.MachinePlayInfo.NOTIFY_PLAY_LIST_EMPTY:{
                //TODO 播放列表为空
                mBtnPlay.setImageResource(R.drawable.btn_play_gray);
                mPrePlayBtn.setImageResource(R.drawable.btn_play_pre_gray);
                mNextPlayBtn.setImageResource(R.drawable.btn_play_next_gray);
                Utils.ensureUnableClick(mBtnPlay, mPrePlayBtn, mNextPlayBtn);
                return true;
            }

            //故事机的在线状态发生变化
            case Actions.MachinePlayInfo.NOTIFY_MACHINE_ONLINE_STATE_CHANGED:{

                isOnline = (int)args[0] == 1;
                //播放过程中，故事机离线了（网络出了问题或者关机了）
                if(!isOnline){
                    rotateCover(false);
                    setUnableStatus(true);
                }
                return true;
            }

        }

        return null;
    }

    // override from ActionListener
    @Override
    public int getProperty() {
        return 0;
    }

    private void initViews() {
        mImageViewShowList = (ImageView) rootView.findViewById(R.id.list_switch);
        mImageViewTime = (ImageView) rootView.findViewById(R.id.time_switch);
        mImageViewBack= (ImageView) rootView.findViewById(R.id.btn_back);
        mImageViewBack.setOnClickListener(this);
        mImageViewChildLock = (ImageView) rootView.findViewById(R.id.lock_switch);
        coverBg = (RelativeLayout) rootView.findViewById(R.id.cover_bg);
        mImageViewCover = (ImageView) rootView.findViewById(R.id.album_cover);
        mBtnPlay = (ImageView) rootView.findViewById(R.id.btn_play);
        mPrePlayBtn = (ImageView) rootView.findViewById(R.id.btn_previous);
        mNextPlayBtn = (ImageView) rootView.findViewById(R.id.btn_next);
        mImageViewCollect = (ImageView) rootView.findViewById(R.id.collect_btn);
        mTextViewTitle = (TextView) rootView.findViewById(R.id.frag_title);
        mImageViewLoop = (ImageView) rootView.findViewById(R.id.mode_switch);
        mTextViewTiming = (TextView) rootView.findViewById(R.id.text_open_timing);
        srcLogo =  (ImageView) rootView.findViewById(R.id.src_logo);

        loopZone = (RelativeLayout) rootView.findViewById(R.id.loop_zone);
        lockZone = (RelativeLayout) rootView.findViewById(R.id.lock_zone);
        favorZone = (RelativeLayout) rootView.findViewById(R.id.favor_zone);
        timerZone = (RelativeLayout) rootView.findViewById(R.id.timer_zone);
        listZone = (RelativeLayout) rootView.findViewById(R.id.list_zone);

        objectAnimator = ObjectAnimator.ofFloat(mImageViewCover, "rotation", 0.0f,360.0f);
        objectAnimator.setInterpolator(new LinearInterpolator());
        objectAnimator.setRepeatMode(ValueAnimator.RESTART);
        objectAnimator.setRepeatCount(Animation.INFINITE);
        objectAnimator.setDuration(10000);

        if (mStoryPlayerPopWin == null) {//初始化播放列表
            mStoryPlayerPopWin = new StoryPlayerPopWin(this, mImageViewShowList, this);
        }
    }

    /**
     * 更新播放状态
     */
    private void updatePlayStatus() {
        if(playSingle!=null){
            Utils.ensuerSetOnclick(this, listZone, timerZone, lockZone, mBtnPlay, mPrePlayBtn, mNextPlayBtn, favorZone, loopZone);
            mTextViewTitle.setText(playSingle.getMediaInfo().getTitle());
            //加载来源图
            Glide.with(getActivity())
                    .load(playSingle.getMediaInfo().getSrclogo())
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .priority(Priority.HIGH)
                    .error(R.drawable.srclogo_default)
                    .into(srcLogo);
            //设置播放状态
            switch (PlayConfig.status2state(playSingle.getStatus())){
                case PlayConfig.STATE_PAUSE:
                    stopPlay();
                    break;

                case PlayConfig.STATE_PLAY:
                    startPlay();
                    break;
            }

            //设置是否收藏
            Observable.create(new Observable.OnSubscribe<Boolean>() {
                @Override
                public void call(Subscriber<? super Boolean> subscriber) {
                    subscriber.onNext(MachineSongWrapper.getInstance().isSongFavor(Preferences.getSelectedPad(), playSingle.getMediaInfo().getUniqueid()));
                    subscriber.onCompleted();
                }
            }) .subscribeOn(Schedulers.io())
               .observeOn(AndroidSchedulers.mainThread()).subscribe(new Action1<Boolean>() {
                @Override
                public void call(Boolean aBoolean) {
                    setCollectBtnState(aBoolean);
                }
            });

            mImageViewShowList.setImageResource(R.drawable.btn_show_list);
            mPrePlayBtn.setImageResource(R.drawable.btn_previous_track);
            mNextPlayBtn.setImageResource(R.drawable.btn_next_track);

            //加载专辑封面图
        }
    }

    /**
     * 更新设置状态
     */
    private void updateSettingStatus() {
        if(settinginfo!=null){
            setLoopBtnState(settinginfo.localSettings.getCirculation());
            setLockBtnState(settinginfo.localSettings.getChildlock()==1);//童锁状态
            setAutoShutDownBtnState(settinginfo.localSettings.getShutdownDelaySeconds());//定时状态
        }
    }

    //更新播放列表
    private void updatePlayList(){
        if (mStoryPlayerPopWin == null) {//初始化播放列表
            mStoryPlayerPopWin = new StoryPlayerPopWin(this, mImageViewShowList, this);
        }
        mStoryPlayerPopWin.setData(songList, playSingle);
        mStoryPlayerPopWin.setSectedSong(playSingle.getMediaInfo().getUniqueid());
    }

    //根据专辑ID加载列表
    private void loadFirstOnlinePlayList(String unique, int page){
        GlobalManager.getInstance().getMachineManager().asyncGetAblum(unique, page, 1);
    }

    //根据专辑ID加载列表更多数据
    private void loadMoreOnlinePlayList(String unique, int page){
        GlobalManager.getInstance().getMachineManager().asyncGetAblum(unique, page, 2);
    }

    //弹出设置童锁弹窗
    private void showLockSwitchDialog() {
        if (mLockSwitchDialog == null) {
            mLockSwitchDialog = new DefaultDialog(this, mImageViewChildLock, false, R.layout.child_lock_remind_popwin);
            mLockSwitchDialog.setButton("开启", "取消", new BaseDialog.ButtonClickListener() {
                @Override
                public void onClick(boolean isOk) {
                    mLockSwitchDialog.dismiss();
                    if(isOk){
                        //点击开启时，进行本地设置操作
                        doLocalSettingCmd(NULLSTRING, PlayConfig.LockType.LOCK, NULLINT);
                    }
                }
            });
        }
        if (mLockSwitchDialog.isShowing()) {
            mLockSwitchDialog.dismiss();
        } else {
            mLockSwitchDialog.showPopWin();
        }
    }

    //弹出设置定时弹窗
    private void showAutoShutdown() {
        if (mAutoShutdownPopWin == null) {
            mAutoShutdownPopWin = new AutoShutdownPopWin(this, mImageViewTime);
            mAutoShutdownPopWin.setOnSelectedTimeListener(new AutoShutdownPopWin.OnSelectedTimeListener() {
                @Override
                public void onSelectedTime(int minutes) {
                }

                @Override
                public void onSure(int minutes) {
                    mAutoShutdownPopWin.dismiss();
                    //TODO 进行本地设置操作
                    timeSetting = true;
                    doLocalSettingCmd(NULLSTRING, NULLINT, minutes);
                }
            });
        }
        mAutoShutdownPopWin.setCurrentSected(currentCloseTime);
        if (mAutoShutdownPopWin.isShowing()) {
            mAutoShutdownPopWin.dismiss();
        } else {
            mAutoShutdownPopWin.showPopWin();
        }
    }

    /**
     * 显示故事列表
     */
    private void showStoryList() {
        if(songList!=null &&  songList.size()>0){
            if (mStoryPlayerPopWin.isShowing()) {
                mStoryPlayerPopWin.dismiss();
            } else {
                mStoryPlayerPopWin.showPopWin();
            }
        }else{
            //TODO 播放列表为空  提示播放列表暂时为空
            CameraToast.show(getString(R.string.no_player_list), Toast.LENGTH_SHORT);
        }
    }

    //设置正在播放状态
    private void startPlay() {
        rotateCover(true);
        setPlayBtnState(false);//按钮改为暂停
        mPlaying = true;
    }

    //设置播放暂停状态
    private void stopPlay() {
        rotateCover(false);
        setPlayBtnState(true);//按钮改为播放
        mPlaying = false;
    }

    /**
     * 播放音乐时的封面旋转动画控制
     * @param rotate 是否旋转
     */
    @TargetApi(Build.VERSION_CODES.KITKAT)
    private void rotateCover(boolean rotate) {
        if(rotate){
            if(!objectAnimator.isRunning()){
                objectAnimator.start();
            }
        }else{
            if(objectAnimator.isRunning()){
                objectAnimator.end();
            }
        }
    }

    /**
     * 设置收藏按钮状态
     * @param isCollect 是否收藏
     */
    private void setCollectBtnState(boolean isCollect) {
        int resId = isCollect ? R.drawable.btn_collected : R.drawable.btn_collect;
        Drawable drawable = getDrawableFromCache(resId);
        mImageViewCollect.setImageDrawable(drawable);
        isCollected = isCollect;
    }

    /**
     * 设置童锁按钮状态
     * @param isLocked 是否开启锁
     */
    private void setLockBtnState(boolean isLocked) {
        int resId = isLocked ? R.drawable.btn_childlock_locked : R.drawable.btn_childlock_unlock;
        Drawable drawable = getDrawableFromCache(resId);
        mImageViewChildLock.setImageDrawable(drawable);
    }

    /**
     * 设置循环状态
     * @param loopType 当前循环模式
     */
    private void setLoopBtnState(String loopType) {
        int resId = 0;
        String toastString = "";
        if(TextUtils.equals(loopType, PlayConfig.CircleType.LISTCIRCLE)){
            resId = R.drawable.btn_loop;
            toastString = getString(R.string.list_loop_tip);
        }else if(TextUtils.equals(loopType, PlayConfig.CircleType.SINGLECIRCLE)){
            resId = R.drawable.btn_single_loop;
            toastString = getString(R.string.single_loop_tip);
        }
        Drawable drawable = getDrawableFromCache(resId);
        mImageViewLoop.setImageDrawable(drawable);
        currentLoop = loopType;
        //TODO 提示当前循环模式
        if(loopSetting){
            loopSetting = false;
            CameraToast.show(getActivity(), toastString, Toast.LENGTH_SHORT);
        }
    }

    /**
     * 设置播放按钮状态
     * @param isPlaying 是否播放
     */
    private void setPlayBtnState(boolean isPlaying) {
        int resId = isPlaying ? R.drawable.btn_start_play : R.drawable.btn_pause_play;
        Drawable drawable = getDrawableFromCache(resId);
        mBtnPlay.setImageDrawable(drawable);
    }
    /**
     * 设置定时关闭按钮
     * @param minutes 自动关闭的时间
     */
    private void setAutoShutDownBtnState(long minutes) {
        int resId = (minutes == -1 || minutes==0) ? R.drawable.btn_close_timing : R.drawable.btn_open_timing;
        Drawable drawable = getDrawableFromCache(resId);
        mImageViewTime.setImageDrawable(drawable);
        //TODO 该版本暂时不显示关机时间
        if (minutes != -1 && minutes!=0) {
//            Utils.ensureVisbility(mTextViewTiming, View.VISIBLE);
//            mTextViewTiming.setText(minutes/60 + "min");
            currentCloseTime = (int)minutes/60;
        } else {
//            Utils.ensureVisbility(mTextViewTiming, View.GONE);
//            mTextViewTiming.setText("");
            currentCloseTime = -1;
        }
        if(timeSetting && minutes>0){
            timeSetting = false;
            //提示用户关机时间
            CameraToast.show(String.format(getString(R.string.machine_close_tip), (int)(minutes/60)), Toast.LENGTH_SHORT);
        }
    }

    /**
     * 从缓存获取drawable,如果不存在则加载进内存
     * @param resId
     * @return
     */
    private Drawable getDrawableFromCache(int resId) {
        Drawable drawable = mDrawbleCache.get(resId);
        if (drawable == null) {
            drawable = getResources().getDrawable(resId);
            mDrawbleCache.put(resId, drawable);
        }
        return drawable;
    }

    /**
     * 播放暂停按钮点击操作
     */
    private void onPlayBtnClick() {
        doPlayCmd(!mPlaying);
    }

    /**
     * 收藏按钮点击操作
     */
    private void onCollectBtnClick() {
        doFavorCmd(!isCollected);
    }

    private void handlerNewPlayinfo(){
        preUniqueId = playSingle.getMediaInfo().getUniqueid();
        currentPage = playSingle.getPageId();
        unique = playSingle.getUnique();
        updatePlayStatus();
    }

    private void loadPlayList(){
        if(TextUtils.equals(PlayConfig.FAVORUNIQUE, playSingle.getUnique())){
            //从固件端拉取该页数据
            String md5 = MachineSongWrapper.getInstance().getLisMd5(Preferences.getSelectedPad(), PlayConfig.ListType.FAVORLIST, playSingle.getUnique());
            doGetPresetListCmd(PlayConfig.ListType.FAVORLIST, playSingle.getUnique(), md5);
        }else{
            if (PlayConfig.isOnlineType(playSingle.getMediaInfo().getType())) {
                //加载当前页数据
                loadFirstOnlinePlayList(unique, currentPage);
            } else {
                //从固件端拉取该页数据
                Observable.create(new Observable.OnSubscribe<String>(){
                    @Override
                    public void call(Subscriber<? super String> subscriber) {
                        subscriber.onNext(MachineSongWrapper.getInstance().getLisMd5(Preferences.getSelectedPad(), playSingle.getMediaInfo().getType(), playSingle.getUnique()));
                        subscriber.onCompleted();
                    }
                }).subscribeOn(Schedulers.io())
                  .observeOn(AndroidSchedulers.mainThread())
                  .subscribe(new Action1<String>() {
                      @Override
                      public void call(String s) {
                          doGetPresetListCmd(playSingle.getMediaInfo().getType(), playSingle.getUnique(), s);
                      }
                  });
            }
        }
    }

    /*
    * 处理歌曲变化
    **/
    private void handlePlaySingleChange(MachinePlaySingle singleInfo, String cmd, String from) {
        if (TextUtils.equals(cmd, PlayConfig.CommandType.GETPLAYSTATUS) && TextUtils.equals(from, PlayConfig.CmdFrom.PLAYPAGE)) {//获取播放信息
            if (singleInfo != null) {
                playSingle = singleInfo;
                //我应该去加载播放信息
                if (playSingle != null) {
                    handlerNewPlayinfo();
                    //加载播放列表
                    //TODO 之前没有加载过播放列表,加载播放列表,需要区分是本地的还是预置的,如果是本地则需要从服务端拉取，如果是预置需要从固件拉取
                    loadPlayList();
                } else {
                    //TODO 用户没有播放任何一个列表
                    setUnableStatus(false);
                }
            }
        }else if(TextUtils.equals(cmd, PlayConfig.CommandType.PLAYCONTROL) && TextUtils.isEmpty(from)){//播放状态变化
            if(playSingle==null){
                //之前不存在播放信息
                if (singleInfo != null) {
                    playSingle = singleInfo;
                    //我应该去加载播放信息
                    handlerNewPlayinfo();
                    //加载播放列表
                    //TODO 之前没有加载过播放列表,加载播放列表,需要区分是本地的还是预置的,如果是本地则需要从服务端拉取，如果是预置需要从固件拉取
                    loadPlayList();
                }
            }else{
                if(singleInfo!=null){
                    //判断是否属于该列表，如果播放的不是这个列表，那么就需要取消已有播放
                    boolean isSmae =false;
                    //同一个专辑和同一个分类(同一个列表)
                    if(PlayConfig.isVoiceType(singleInfo.getMediaInfo().getType())){
                        isSmae = false;
                    } else if(TextUtils.equals(unique, PlayConfig.FAVORUNIQUE)){
                        if(TextUtils.equals(singleInfo.getUnique(), PlayConfig.FAVORUNIQUE)){
                            isSmae = true;
                        }
                    }else if(playSingle.getMediaInfo().getType() == PlayConfig.ListType.FAVORLIST){
                        if(playSingle.getMediaInfo().getType() == singleInfo.getMediaInfo().getType()){
                            isSmae = true;
                        }
                    }else{
                        if(playSingle.getMediaInfo().getType() == singleInfo.getMediaInfo().getType() && TextUtils.equals(playSingle.getUnique(), singleInfo.getUnique())){
                            isSmae = true;
                        }
                    }

                    playSingle = singleInfo;
                    if(isSmae){//是同一个列表
                        preUniqueId = playSingle.getMediaInfo().getUniqueid();
                        updatePlayStatus();
                        CLog.e("test","前currentPage:"+currentPage);
                        currentPage = playSingle.getPageId();
                        CLog.e("test","后currentPage:"+currentPage);
                        if(PlayConfig.isOnlineType(playSingle.getMediaInfo().getType())){
                            //TODO 如果是从第一页跨到最后一页或者是最后一页跨到第一页，需要先清空列表
                            if(mStoryPlayerPopWin.totalPage>=3){
                                if(mStoryPlayerPopWin.downPage!=(mStoryPlayerPopWin.totalPage-1) && playSingle.getPageId()==mStoryPlayerPopWin.totalPage && songList.size()!=totalSize){
                                    songList.clear();
                                    //加载当前页数据
                                    loadFirstOnlinePlayList(unique, currentPage);
                                    return;
                                }else if(mStoryPlayerPopWin.downPage==mStoryPlayerPopWin.totalPage && playSingle.getPageId()==1 && songList.size()!=totalSize){
                                    songList.clear();
                                    //加载当前页数据
                                    loadFirstOnlinePlayList(unique, currentPage);
                                    return;
                                }
                            }

                            //如果线上的，则考虑是否需要加载上一页或者下一页
                            if(playSingle.getPageId()>mStoryPlayerPopWin.downPage){//大于当前最大页，需要加载下一页
                                loadMorePage = mStoryPlayerPopWin.currentPage = playSingle.getPageId();
                                loadMoreOnlinePlayList(unique, playSingle.getPageId());
                            }else if(playSingle.getPageId()<mStoryPlayerPopWin.upPage){
                                loadMorePage = mStoryPlayerPopWin.currentPage = playSingle.getPageId();
                                loadMoreOnlinePlayList(unique, playSingle.getPageId());
                            }else{
                                mStoryPlayerPopWin.currentPage = playSingle.getPageId();
                                mStoryPlayerPopWin.setSectedSong(playSingle.getMediaInfo().getUniqueid());
                            }
                        }else{
                            //如果是内置的,直接更新播放的是哪一首就行
                            mStoryPlayerPopWin.setSectedSong(playSingle.getMediaInfo().getUniqueid());
                        }
                    }else{
                        handlerNewPlayinfo();
                        loadPlayList();
                    }
                }
            }
        }
    }

    //TODO 处理我主动请求的列表(我会主动请求收藏列表和导入列表，预置的列表会请求一次)
    private void handleListUpdate(int listType, String cmd, String from) {
        if (TextUtils.equals(cmd, PlayConfig.CommandType.GETPLAYLIST) && TextUtils.equals(from, PlayConfig.CmdFrom.PLAYPAGE)) {//获取播放列表

            Observable.create(new Observable.OnSubscribe<ArrayList<MachineSong>>() {
                @Override
                public void call(Subscriber<? super ArrayList<MachineSong>> subscriber) {
                    ArrayList<MachineSong> list = new ArrayList<>();
                    if (TextUtils.equals(PlayConfig.FAVORUNIQUE, playSingle.getUnique())) {
                        list = MachineSongWrapper.getInstance().getMachineSongList(Preferences.getSelectedPad(), PlayConfig.ListType.FAVORLIST, playSingle.getUnique());
                    } else {
                        list = MachineSongWrapper.getInstance().getMachineSongList(Preferences.getSelectedPad(), playSingle.getMediaInfo().getType(), playSingle.getUnique());
                    }
                    subscriber.onNext(list);
                    subscriber.onCompleted();
                }
            }).subscribeOn(Schedulers.io())
              .observeOn(AndroidSchedulers.mainThread())
              .subscribe(new Action1<ArrayList<MachineSong>>() {
                  @Override
                  public void call(ArrayList<MachineSong> machineSongs) {
                      songList.clear();
                      for (MachineSong song : machineSongs) {
                          songList.add(song);
                      }
                      mStoryPlayerPopWin.setPlaySum(songList.size());
                      //更新播放列表
                      updatePlayList();
                      //内置的歌曲是没有封面的
                      mImageViewCover.setImageResource(R.drawable.player_default_bg);
                  }
              });
        }
    }

    //TODO 根据unique和id主动获取播放列表
    private void handleFirstLoadOnlineList(ArrayList<SongEntity> sList){
        songList.clear();
        for(SongEntity songEntity : sList){
            songEntity.setPage(currentPage);
            songEntity.setType(playSingle.getMediaInfo().getType());
        }
        songList.addAll(sList);
        updatePlayList();
        mStoryPlayerPopWin.setSectedSong(playSingle.getMediaInfo().getUniqueid());
    }

    //TODO 根据unique和id加载更多在线播放列表
    private void handleLoadMoreOnlineList(ArrayList<SongEntity> sList){
        CLog.e("test","songList:"+songList.size());
        for(SongEntity songEntity : sList){
            songEntity.setPage(loadMorePage);
            songEntity.setType(playSingle.getMediaInfo().getType());
        }
        if(loadMorePage > mStoryPlayerPopWin.downPage){
            mStoryPlayerPopWin.downPage = loadMorePage;
            songList.addAll(sList);
        }else if(loadMorePage < mStoryPlayerPopWin.upPage){
            mStoryPlayerPopWin.upPage = loadMorePage;
            ArrayList<SongEntity> tmp = new ArrayList<>();
            tmp.addAll(sList);
            tmp.addAll(songList);
            songList.clear();
            songList = tmp;
        }
        mStoryPlayerPopWin.addMore(songList);
        mStoryPlayerPopWin.setSectedSongNoScroll(playSingle.getMediaInfo().getUniqueid());
    }

   //处理故事忙，只有播放控制才有
    private void handleBusy(String cmd, String from){
        //TODO 没在播放，忙着呢
        if(TextUtils.equals(from, PlayConfig.CmdFrom.PLAYPAGE)){
            if(TextUtils.equals(cmd, PlayConfig.CommandType.GETPLAYSTATUS)){
                Utils.ensureUnableClick(mBtnPlay, mPrePlayBtn, mNextPlayBtn, favorZone, listZone);
            }else if(TextUtils.equals(cmd, PlayConfig.CommandType.PLAYCONTROL)){
                //TODO 在播放页面点击播放，发现故事机正忙着，做出提示
                CameraToast.show(getString(R.string.machine_is_busy), Toast.LENGTH_SHORT);
            }

        }
    }

    //处理本地设置更新
    private void handlerLocalSetting(LocalSetting setting){
        settinginfo = setting;
        updateSettingStatus();
    }

    //处理收藏是否成功(resultCode: 0-成功，1-达到收藏上限，添加失败，2-删除失败，没有这条歌曲)
    private void handlerFavorResult(FavorResultEntity favorResult, String from){
        if(TextUtils.equals(from, PlayConfig.CmdFrom.PLAYPAGE)){
            switch(favorResult.resultCode){
                case 0:
                    //无需处理
                    setCollectBtnState(TextUtils.equals(favorResult.getOperation(), PlayConfig.FavorType.ADDSONG) ? true : false);
                    break;

                case 1://达到收藏上限，添加失败
                    //TODO 需要作出提示
                    CameraToast.show(getActivity(), getString(R.string.favor_over_failed), Toast.LENGTH_SHORT);
                    break;

                case 2://删除失败，没有这条收藏
                    //TODO 需要作出提示
                    CameraToast.show(getActivity(), getString(R.string.favor_del_failed), Toast.LENGTH_SHORT);
                    break;

                case 3://添加失败，歌曲已经存在
                    //TODO 需要作出提示
                    CameraToast.show(getActivity(), getString(R.string.favor_again_failed), Toast.LENGTH_SHORT);
                    break;
            }
        }
    }

    //播放列表的item点击事件
    @Override
    public void OnItemClick(int p) {
        long currentTime = System.currentTimeMillis();//当前时间
        if(preTime == 0){
            preTime = currentTime;
            handler.postDelayed(runnable = new MyRunnable(p), 500);
        }else{
            if(currentTime - preTime <= 500){
                handler.removeCallbacks(runnable);
                handler.postDelayed(runnable = new MyRunnable(p), 500);
            }else{
                preTime = currentTime;
                handler.postDelayed(runnable = new MyRunnable(p), 500);
            }
        }
    }

    class MyRunnable implements Runnable{

        private int pos;

        MyRunnable(int p){
            pos = p;
        }

        @Override
        public void run() {
            CameraToast.show(getString(R.string.had_notify_machine), Toast.LENGTH_SHORT);
            sendPlayCmd(pos);
        }
    }

    private void sendPlayCmd(int pos){
        //切换播放列表里面的歌
        SongEntity songEntity = songList.get(pos);
        TaskExecutor.Execute(new SettingTask(getActivity(), PlayConfig.CommandType.PLAYCONTROL, JsonManager.getPlayControlContent(PlayConfig.PlayType.PLAYSONG, songEntity, unique, songEntity.getPage()), handler, PlayConfig.CmdFrom.PLAYPAGE));
        //播放儿歌打点
        QHStatAgentHelper.doSongStoryStick(QHStatAgentHelper.getSongPlayMap(songEntity.getTitle(), unique));
    }

    //播放列表的分页加载
    @Override
    public void loadMore(int pageId) {
        loadMorePage = pageId;
        loadMoreOnlinePlayList(unique, loadMorePage);
    }


    //---------------------------------------------发送指令---------------------------------------//
    //发送获取下播放信息的指令
    private void getPlayInfo(){
        TaskExecutor.Execute(new SettingTask(getActivity(), PlayConfig.CommandType.GETPLAYSTATUS, JsonManager.getPlayStatusContent(), handler, PlayConfig.CmdFrom.PLAYPAGE));
    }

    //发送获取本地设置的指令
    private void doGetSetingCmd(){
        TaskExecutor.Execute(new SettingTask(getActivity(), PlayConfig.CommandType.GETLOCALSETTING, JsonManager.getPlayStatusContent(), handler, PlayConfig.CmdFrom.PLAYPAGE));
    }

    //发送本地设置操作指令
    private void doLocalSettingCmd(String circleType, int lockType, long time) {

        JSONObject setting = new JSONObject();

        try {
            if (!TextUtils.isEmpty(circleType)) {
                setting.put("circulation", circleType);
            }

            if (lockType != NULLINT) {
                setting.put("childlock", lockType);
            }

            if (time != NULLINT) {
                setting.put("shutdownDelaySeconds", time == -1 ? -1 : time * 60);
            }

            TaskExecutor.Execute(new SettingTask(getActivity(), PlayConfig.CommandType.DOLOCALSETTING, JsonManager.getLocalSetting(setting), handler, PlayConfig.CmdFrom.PLAYPAGE));
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    //发送收藏指令
    private void doFavorCmd(boolean isCollected){
        String operate = isCollected ? PlayConfig.FavorType.ADDSONG : PlayConfig.FavorType.DELSONG;
        TaskExecutor.Execute(new SettingTask(getActivity(), PlayConfig.CommandType.DOFAVOR, JsonManager.getStoryFavor(operate, playSingle.getMediaInfo(), unique, currentPage), handler, PlayConfig.CmdFrom.PLAYPAGE));
        //打点收藏
        if(isCollected){
            QHStatAgentHelper.doSongStoryStick(QHStatAgentHelper.getSongFavorMap(playSingle.getMediaInfo().getTitle()));
        }
    }

    //发送播放或者暂停指令(需要区分是重开开始播还是继续播放同一首)
    private void doPlayCmd(boolean isPlay){
        String status;
        if(isPlay){
            status = TextUtils.equals(preUniqueId, playSingle.getMediaInfo().getUniqueid()) ? PlayConfig.PlayType.RESUMESONG : PlayConfig.PlayType.PLAYSONG;
        }else{
           status = PlayConfig.PlayType.PAUSESONG;
        }
        TaskExecutor.Execute(new SettingTask(getActivity(), PlayConfig.CommandType.PLAYCONTROL, JsonManager.getPlayControlContent(status, playSingle.getMediaInfo(), unique, currentPage), handler, PlayConfig.CmdFrom.PLAYPAGE));
        //播放打点
        if(TextUtils.equals(status, PlayConfig.PlayType.PLAYSONG)){
            QHStatAgentHelper.doSongStoryStick(QHStatAgentHelper.getSongPlayMap(playSingle.getMediaInfo().getTitle(), unique));
        }
    }

    //发送上一首或者下一首指令
    private void doPrevOrNextCmd(String status){
        TaskExecutor.Execute(new SettingTask(getActivity(), PlayConfig.CommandType.PLAYCONTROL, JsonManager.getPrevOrNextContent(status), handler, PlayConfig.CmdFrom.PLAYPAGE));
    }

    //发送获取内置列表的指令
    private void doGetPresetListCmd(int listType, String unique, String md5){
        TaskExecutor.Execute(new SettingTask(getActivity(), PlayConfig.CommandType.GETPLAYLIST, JsonManager.getPlayListContent(listType, unique, md5), handler, PlayConfig.CmdFrom.PLAYPAGE));
    }
    //---------------------------------------------end--------------------------------------------//


    //指令失败异常处理
    static class MyHandler extends Handler{

        WeakReference<StoryPlayerFragment> storyPlayerFragmentWeakReference;

        MyHandler(StoryPlayerFragment storyPlayerFragment) {
            storyPlayerFragmentWeakReference = new WeakReference<>(storyPlayerFragment);
        }

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if(storyPlayerFragmentWeakReference.get()!=null && storyPlayerFragmentWeakReference.get().isAdded()){
                storyPlayerFragmentWeakReference.get().handlerCmdExcept((String)msg.obj);
            }
        }
    }

    private void handlerCmdExcept(String cmd){

        if(TextUtils.equals(cmd, PlayConfig.CommandType.GETPLAYSTATUS)){
            //TODO 获取播放信息失败
            setUnableStatus(true);
        }else if(TextUtils.equals(cmd, PlayConfig.CommandType.GETPLAYLIST)){
            //获取列表失败

        }else if(TextUtils.equals(cmd, PlayConfig.CommandType.PLAYCONTROL)){
            //播放儿歌失败
            if(!this.isDetached() && getActivity()!=null){
                CameraToast.show(getActivity(), getString(R.string.play_failed_tip), Toast.LENGTH_SHORT);
            }
        }else if(TextUtils.equals(cmd, PlayConfig.CommandType.DOFAVOR)){
            //收藏失败
            if(!this.isDetached() && getActivity()!=null){
                CameraToast.show(getActivity(), getString(R.string.play_failed_tip), Toast.LENGTH_SHORT);
            }
        }else if(TextUtils.equals(cmd, PlayConfig.CommandType.DOLOCALSETTING)){
            //进行 童锁、定时关机或者循环方式失败
            timeSetting = false;
            loopSetting = false;
            if(!this.isDetached() && getActivity()!=null){
                CameraToast.show(getActivity(), getString(R.string.play_failed_tip), Toast.LENGTH_SHORT);
            }
        }
    }

    private void setUnableStatus(boolean showTip){
        //Toast提示故事机离线
        if(getActivity()!=null && showTip){
            CameraToast.show(getActivity(), getString(R.string.story_machine_offline), Toast.LENGTH_SHORT);
        }

        Utils.ensureUnableClick(listZone, timerZone, lockZone, mBtnPlay, mPrePlayBtn, mNextPlayBtn, favorZone, loopZone);
        mImageViewShowList.setImageResource(R.drawable.btn_play_list_gray);
        mImageViewTime.setImageResource(R.drawable.btn_timing_gray);
        mImageViewChildLock.setImageResource(R.drawable.btn_lock_gray);
        mBtnPlay.setImageResource(R.drawable.btn_play_gray);
        mPrePlayBtn.setImageResource(R.drawable.btn_play_pre_gray);
        mNextPlayBtn.setImageResource(R.drawable.btn_play_next_gray);
        mImageViewCollect.setImageResource(R.drawable.btn_favor_gray);
        mImageViewLoop.setImageResource(R.drawable.btn_loop_gray);
    }

    private void noNetTip(){
        if (!Utils.isNetworkAvailable(mContext)) {
            CameraToast.show(null, R.string.network_disabled, Toast.LENGTH_SHORT);
            return;
        }
    }
}
