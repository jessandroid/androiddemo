package com.qihoo360.homecamera.machine.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by zhangtao-iri on 2017/2/22.
 */
public class ChatMessageEntity implements Parcelable{
    public String type;
    public String time;
    public String title;
    public String message;
    public String device;
    public Data data;
    public String msgId;

    public static class Data implements Parcelable{

        public String sn;
        public int subType;
        public ChatContent content;
        public SenderInfo senderInfo;

        public Data() {
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(this.sn);
            dest.writeInt(this.subType);
            dest.writeParcelable(this.content, flags);
            dest.writeParcelable(this.senderInfo, flags);
        }

        protected Data(Parcel in) {
            this.sn = in.readString();
            this.subType = in.readInt();
            this.content = in.readParcelable(ChatContent.class.getClassLoader());
            this.senderInfo = in.readParcelable(SenderInfo.class.getClassLoader());
        }

        public static final Creator<Data> CREATOR = new Creator<Data>() {
            @Override
            public Data createFromParcel(Parcel source) {
                return new Data(source);
            }

            @Override
            public Data[] newArray(int size) {
                return new Data[size];
            }
        };
    }

    public static class ChatContent implements Parcelable{
        public String message;
        public String pkId;
        public String emojiId;
        public String downUrl;
        public int duration;

        public ChatContent() {
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(this.message);
            dest.writeString(this.pkId);
            dest.writeString(this.emojiId);
            dest.writeString(this.downUrl);
            dest.writeInt(this.duration);
        }

        protected ChatContent(Parcel in) {
            this.message = in.readString();
            this.pkId = in.readString();
            this.emojiId = in.readString();
            this.downUrl = in.readString();
            this.duration = in.readInt();
        }

        public static final Creator<ChatContent> CREATOR = new Creator<ChatContent>() {
            @Override
            public ChatContent createFromParcel(Parcel source) {
                return new ChatContent(source);
            }

            @Override
            public ChatContent[] newArray(int size) {
                return new ChatContent[size];
            }
        };
    }

    public static class SenderInfo implements Parcelable{
        public String relation;//json串
        public String title;
        public String imgUrl;
        public String phone;

        public SenderInfo() {
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(this.relation);
            dest.writeString(this.title);
            dest.writeString(this.imgUrl);
            dest.writeString(this.phone);
        }

        protected SenderInfo(Parcel in) {
            this.relation = in.readString();
            this.title = in.readString();
            this.imgUrl = in.readString();
            this.phone = in.readString();
        }

        public static final Creator<SenderInfo> CREATOR = new Creator<SenderInfo>() {
            @Override
            public SenderInfo createFromParcel(Parcel source) {
                return new SenderInfo(source);
            }

            @Override
            public SenderInfo[] newArray(int size) {
                return new SenderInfo[size];
            }
        };
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.type);
        dest.writeString(this.time);
        dest.writeString(this.title);
        dest.writeString(this.message);
        dest.writeString(this.device);
        dest.writeParcelable(this.data, flags);
        dest.writeString(this.msgId);
    }

    public ChatMessageEntity() {
    }

    protected ChatMessageEntity(Parcel in) {
        this.type = in.readString();
        this.time = in.readString();
        this.title = in.readString();
        this.message = in.readString();
        this.device = in.readString();
        this.msgId = in.readString();
        this.data = in.readParcelable(Data.class.getClassLoader());
    }

    public static final Creator<ChatMessageEntity> CREATOR = new Creator<ChatMessageEntity>() {
        @Override
        public ChatMessageEntity createFromParcel(Parcel source) {
            return new ChatMessageEntity(source);
        }

        @Override
        public ChatMessageEntity[] newArray(int size) {
            return new ChatMessageEntity[size];
        }
    };
}
