
package com.qihoo360.homecamera.machine.ui.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.util.AttributeSet;
import android.view.View;

import com.qihoo360.homecamera.mobile.R;

public class VolumeBar extends View {
    private Bitmap backgroundBitmap;
    private Bitmap progressBitmap;
    private Paint paint;
    private int left;
    private int right;

    public VolumeBar(Context context, AttributeSet attrs) {
        super(context, attrs);
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.VolumeBar);
        BitmapDrawable background =
                (BitmapDrawable) a.getDrawable(R.styleable.VolumeBar_backgroundrecourse);
        backgroundBitmap = background.getBitmap();
        BitmapDrawable progress =
                (BitmapDrawable) a.getDrawable(R.styleable.VolumeBar_progressrecourse);
        progressBitmap = progress.getBitmap();
        a.recycle();
        paint = new Paint();
        paint.setAntiAlias(true);
    }

    @SuppressLint("DrawAllocation")
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Rect rect = new Rect();
        rect.left = 0;
        rect.right = getWidth();
        rect.top = 0;
        rect.bottom = getHeight();
        canvas.drawBitmap(backgroundBitmap, null, rect, paint);

        canvas.save();
        Rect clipRect = new Rect(left, 0, right, rect.bottom);
        // 将剪切矩形与要下面要画的矩形相交，只显示相交的区域
        canvas.clipRect(clipRect);
        // 将剪切矩形与要下面要画的矩形相交，不显示相交的区域
        // canvas.clipRect(clipRect,Op.XOR)
        canvas.drawBitmap(progressBitmap, null, rect, paint);
        canvas.restore();
    }

    /**
     * progress 0~100
     *
     * @param progress
     */
    public void setProgress(int progress) {
        int pro = getWidth() * progress / 40 / 2;
        left = getWidth() / 2 - pro;
        right = getWidth() - left;
        invalidate();
    }
}
