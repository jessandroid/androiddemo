package com.qihoo360.homecamera.mobile.http.builder;

import android.text.TextUtils;

import com.qihoo360.homecamera.mobile.http.request.PostStringRequest;
import com.qihoo360.homecamera.mobile.http.request.RequestCall;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.util.LinkedHashMap;
import java.util.Map;

import okhttp3.MediaType;

/**
 * Created by zhy on 15/12/14.
 */
public class PostStringBuilder extends OkHttpRequestBuilder {
    private String content;
    private MediaType mediaType;
    private String upUrl;

    public PostStringBuilder content(String content) {
        this.content = content;
        return this;
    }

    public PostStringBuilder mediaType(MediaType mediaType) {
        this.mediaType = mediaType;
        return this;
    }


    @Override
    public RequestCall build() {
        return new PostStringRequest(url, tag, params, headers, content, mediaType).build();
    }

    @Override
    public OkHttpRequestBuilder isDebug(boolean debug) {
        this.debug = debug;
        return this;
    }

    @Override
    public OkHttpRequestBuilder isHttps(boolean https) {
        this.https = https;
        return this;
    }

    @Override
    public OkHttpRequestBuilder isLogUpload(String up) {
        this.upUrl = up;
        return this;
    }

    @Override
    public OkHttpRequestBuilder withOutCookie() {
        return super.withOutCookie();
    }

    @Override
    public PostStringBuilder url(String url) {
        if (!isStatic) {
            if (TextUtils.isEmpty(this.upUrl)) {
                this.url = Utils.getUrl(url, https);
            }
            this.url = url;
        }else {
            this.url = url;
        }
        return this;
    }

    @Override
    public OkHttpRequestBuilder isStatic(boolean isStatic) {
        this.isStatic = isStatic;
        return this;
    }

    @Override
    public PostStringBuilder tag(Object tag) {
        this.tag = tag;
        return this;
    }

    @Override
    public PostStringBuilder params(Map<String, String> params) {
        this.params = params;
        return this;
    }

    @Override
    public PostStringBuilder addParams(String key, String val) {
        if (this.params == null) {
            params = new LinkedHashMap<String, String>();
        }
        params.put(key, val);
        return this;
    }

    @Override
    public PostStringBuilder headers(Map<String, String> headers) {
        this.headers = headers;
        return this;
    }



    @Override
    public PostStringBuilder addHeader(String key, String val) {
        if (this.headers == null) {
            headers = new LinkedHashMap<String, String>();
        }
        headers.put(key, val);
        return this;
    }
}
