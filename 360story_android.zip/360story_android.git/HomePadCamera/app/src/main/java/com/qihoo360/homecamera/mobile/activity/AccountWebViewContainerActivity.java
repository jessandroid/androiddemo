
package com.qihoo360.homecamera.mobile.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.entity.InnerMsg;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.config.Const;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.widget.CommonWebView;

import java.net.URLEncoder;


public class AccountWebViewContainerActivity extends BaseActivity implements OnClickListener {
    public static final String SUCC_CB_URL = "qucsdk://";
    public static final String FORGET_PASSWORD = "http://i.360.cn/findpwdwap?src=mpc_pingmuban_and&skin=blue&client=app&isShowSuccess=1&appJumpNotify=1";
    public final static String REQUEST_CODE_KEY = "request_code";

    CommonWebView mWebView;
    LinearLayout exit;
    private ProgressBar mPbWebView;
    int requestCode = -1;
    TextView titleTextView;
    private ImageView mBackIv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTintManagerQWork(true);
        tintManager.setStatusBarTintColor(Color.parseColor("#00aeff"));
        setContentView(R.layout.n_change_pwd_main);
         String url = "";
        try {
            boolean hasCategory = getIntent().hasExtra("url");
            if (hasCategory == true) {
                url = getIntent().getStringExtra("url");
            }
        } catch (Exception e) {
            finish();
        }
        titleTextView = (TextView) findViewById(R.id.common_title_text);
        String title = getString(R.string.acc_bind_phone_label);
        requestCode = getIntent().getIntExtra(REQUEST_CODE_KEY, -1);
        if (requestCode == 0) {
            title = getString(R.string.acc_bind_phone_label);
        } else if (requestCode == 1) {
            title = getString(R.string.acc_change_pwd_title);
        } else if (requestCode==2){
            title = getString(R.string.acc_find_pwd_title);
        }else {
            finish();
        }
        titleTextView.setText(title);

        mPbWebView = (ProgressBar) findViewById(R.id.pb);
        mWebView = (CommonWebView) findViewById(R.id.change_pwd_webview);
        mWebView.setWebViewClient(new WebViewViewClient());
//        mWebView.setWebChromeClient(new WebViewChromeClient());
        
        WebSettings webSettings = mWebView.getSettings();
        webSettings.setSavePassword(false);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setSupportZoom(true); // 支持缩放
        webSettings.setJavaScriptEnabled(true);
        webSettings.setAllowFileAccess(false);
        webSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);// 解决缓存问题
        webSettings.setDefaultTextEncodingName("utf-8");
        setQTCookie(url, getIntent().getStringExtra("q"), getIntent().getStringExtra("t"));


        mWebView.loadUrl(url);
        exit = (LinearLayout) findViewById(R.id.close_zone);
        exit.setOnClickListener(this);
        exit.setVisibility(View.GONE);
        mBackIv = (ImageView) findViewById(R.id.iv_back);
        mBackIv.setOnClickListener(this);
    }

    public void modifyPwdSuccess(String webMessage) {
        //need kick user to login
        CameraToast.showToast(this, "change pwd success");
    }

    class WebViewViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            mPbWebView.setMax(100);
            mPbWebView.setVisibility(View.VISIBLE);
            if (url.startsWith(SUCC_CB_URL)) {//处理修改密码，绑定手机等操作成功的回调
                try {
                    Uri aUri = Uri.parse(url);
                    String qid = aUri.getQueryParameter("qid");
                    if (qid.equals(AccUtil.getInstance().getQID())) {//仅当返回的qid和之前的qid相同时， 才会返回新的QT
                        int promptStrId = R.string.change_pwd_suc;
                        String action = Const.BROADCAST_APP_PWD_CHANGED;
                        if (requestCode == 0) {
                            promptStrId = R.string.change_bind_phone_suc;
                            action = Const.BROADCAST_APP_BIND_PHONE_CHANGED;
                        }
                        CameraToast.showToast(AccountWebViewContainerActivity.this, getResources().getString(promptStrId));
                        Context context = Utils.getContext();
                        context.sendBroadcast(new Intent(action));
                    }
                } catch (Throwable e) {
                }
            } else {
                view.loadUrl(url);
            }
            return true;
        }

        @Override
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            super.onReceivedError(view, errorCode, description, failingUrl);
            mPbWebView.setMax(100);
            mPbWebView.setVisibility(View.VISIBLE);
        }
    }

    private void setQTCookie(String url, String Q, String T) {
        if (TextUtils.isEmpty(Q) || TextUtils.isEmpty(T)) {
            return;
        }

        CookieSyncManager.createInstance(this);
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setCookie(url, "T=" + T + ";path=/; domain=360.cn; httponly");// cookies是在HttpClient中获得的cookie
        cookieManager.setCookie(url, "Q=" + Q + ";path=/;domain=360.cn");
        CookieSyncManager.getInstance().sync();
    }

//    class WebViewChromeClient extends WebChromeClient {
//
//        @Override
//        public void onProgressChanged(WebView view, int newProgress) {
//            mPbWebView.setProgress(newProgress);
//            if (newProgress == 100) {
//                mPbWebView.setVisibility(View.GONE);
//            }
//            super.onProgressChanged(view, newProgress);
//        }
//
//    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        // TODO Auto-generated method stub
        if ((keyCode == KeyEvent.KEYCODE_BACK) && mWebView.canGoBack()) {
            mWebView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.close_zone:
                finish();
                break;
            case R.id.iv_back:
                finish();
                break;
        }

    }

    @Override
    protected void switchMode(boolean speaker_mode) {
        super.switchMode(speaker_mode);
    }

    @Override
    public void onMessage(InnerMsg imsg) {
        super.onMessage(imsg);
    }

    @Override
    public void setTintManagerQWork(boolean work) {
        super.setTintManagerQWork(work);
    }
}
