
package com.qihoo360.homecamera.mobile.db;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

import com.google.gson.Gson;
import com.qihoo360.homecamera.machine.config.MachineDebugConfig;
import com.qihoo360.homecamera.mobile.entity.DeviceInfo;
import com.qihoo360.homecamera.mobile.entity.DeviceInfoList;
import com.qihoo360.homecamera.mobile.entity.PrivateEntity;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.CLog;

import java.util.ArrayList;
import java.util.List;

/**
 * User: Tomcat
 * Date: 2016/1/11
 * Time: 15:06
 * To change this template use File | Settings | File Templates.
 */

public class PadInfoWrapper extends AbstractWrapper {

    public static final String TABLE_NAME = "pad_info";
    private static volatile PadInfoWrapper mInstance;

    public static PadInfoWrapper getInstance() {
        if (mInstance == null) {
            synchronized (PadInfoWrapper.class) {
                if (mInstance == null) {
                    mInstance = new PadInfoWrapper();
                }
            }
        }
        return mInstance;
    }

    public synchronized void processPadInfo(DeviceInfoList deviceInfoList) {
        SQLiteDatabase sqLiteDatabase = GlobalManager.getInstance().config().db.getWritableDatabase();
        List<String> oldDeviceInfoSet = PadInfoWrapper.getInstance().getAllPadSet();
        ArrayList<DeviceInfo> newDeviceInfo = deviceInfoList.data.device;
        CLog.e("hyuan", "get device list size:" + newDeviceInfo.size());
        for (int i = 0; i < newDeviceInfo.size(); i++) {
            DeviceInfo deviceInfo = newDeviceInfo.get(i);
            Gson gson = new Gson();
            if (MachineDebugConfig.DEBUG && deviceInfo.relation == null) {
                deviceInfo.relation = new DeviceInfo.Relation();//空指针保护
            }
            PadInfoWrapper.getInstance().setPadInfoData(sqLiteDatabase, AccUtil.getInstance().getQID(),
                    deviceInfo.getSn(),
                    deviceInfo.title, deviceInfo.getRole(), deviceInfo.getShareNum(), deviceInfo.getCoverUrl(),
                    deviceInfo.getAvatarUrl(), deviceInfo.relation.relation_title, deviceInfo.hardware,
                    deviceInfo.version, deviceInfo.isOnline, gson.toJson(deviceInfo.aclInfo).toString(),
                    deviceInfo.support, deviceInfo.deviceType);
            if (oldDeviceInfoSet.contains(deviceInfo.getSn())) {
                oldDeviceInfoSet.remove(deviceInfo.getSn());
                CLog.e("hyuan", "remove old device:" + deviceInfo.getSn());
            }
        }
        for (String sn : oldDeviceInfoSet) {
            PadInfoWrapper.getInstance().deletePadBySnQid(sn, AccUtil.getInstance().getQID());
        }
    }

    public synchronized void setPadInfoData(SQLiteDatabase sqLiteDatabase, String qid, String sn, String title,
            int role, int shareNum, String coverUrl,
            String avatarUrl, String relationTitle,
            String hdType, String hdVer, int state, String alcinfo, String remoteSettingSupport, String deviceType) {

        if (existQidPadInfo(qid, sn)) {
            long count = updatePadInfo(sqLiteDatabase, qid, sn, title, role, shareNum, coverUrl, avatarUrl,
                    relationTitle, hdType, hdVer, state, alcinfo, remoteSettingSupport, deviceType);
            CLog.e("hyuan", "update " + sn + "," + remoteSettingSupport + "--count:" + count);
        } else {
            long count = insertPadInfo(sqLiteDatabase, qid, sn, title, role, shareNum, coverUrl, avatarUrl,
                    relationTitle, hdType, hdVer, state, alcinfo, remoteSettingSupport, deviceType);
            CLog.e("hyuan", "insert " + sn + "," + remoteSettingSupport + "--count:" + count);
        }
    }

    private synchronized int updatePadInfo(SQLiteDatabase sqLiteDatabase, String qid, String sn, String title,
            int role, int shareNum, String coverUrl, String avatarUrl, String relationTitle,
            String hardwareType, String hardwareVersion, int state, String aclinfo, String remoteSettingSupport,
            String deviceType) {
        int effectCount = 0;
        ContentValues values = new ContentValues();
        values.put("qid", qid);
        values.put("sn", sn);
        values.put("title", title);
        values.put("role", role);
        values.put("shareNum", shareNum);
        values.put("coverUrl", coverUrl);
        values.put("avatarUrl", avatarUrl);
        values.put(Field.STATE, state);
        values.put(Field.RELATION_TITLE, relationTitle);
        values.put(Field.HARDWARE_TYPE, hardwareType);
        values.put(Field.HARDWARE_VERSION, hardwareVersion);
        values.put(Field.ACLINFO, aclinfo);
        values.put(Field.SUPPORT, remoteSettingSupport);
        values.put(Field.DEVICE_TYPE, deviceType);
        effectCount = sqLiteDatabase.update(TABLE_NAME, values, "sn=? and qid=?", new String[] {
                sn, qid
        });
        return effectCount;
    }

    public int updateLocalImg(String qid, String sn, String path) {
        SQLiteDatabase sqLiteDatabase = GlobalManager.getInstance().config().db.getWritableDatabase();
        int effectCount = 0;
        ContentValues values = new ContentValues();
        values.put("qid", qid);
        values.put("sn", sn);
        values.put("localCoverImg", path);
        effectCount = sqLiteDatabase.update(TABLE_NAME, values, "sn=? and qid=?", new String[] {
                sn, qid
        });
        CLog.e("call_inner", effectCount + ":" + path);
        return effectCount;
    }

    public DeviceInfo getPadBySn(String sn) {
        if (GlobalManager.getInstance().config().db != null) {
            SQLiteDatabase db = GlobalManager.getInstance().config().db.getReadableDatabase();
            DeviceInfo deviceInfo = null;
            Cursor cursor = null;
            try {
                Gson gson = new Gson();
                cursor = db.query(TABLE_NAME, null, "sn = ? ", new String[] {
                        sn
                }, null, null, null);
                while (cursor.moveToNext()) {
                    deviceInfo = new DeviceInfo();
                    deviceInfo.qid = cursor.getString(cursor.getColumnIndex(Field.KEY_QID_ID));
                    deviceInfo.title = cursor.getString(cursor.getColumnIndex(Field.TITLE_CLO));
                    deviceInfo.setCoverUrl(cursor.getString(cursor.getColumnIndex(Field.KEY_COVERURL)));
                    deviceInfo.shareNum = cursor.getInt(cursor.getColumnIndex(Field.KEY_SHARE_NUMBER));
                    deviceInfo.sn = cursor.getString(cursor.getColumnIndex(Field.KEY_SN));
                    deviceInfo.localCoverImg = cursor.getString(cursor.getColumnIndex(Field.LOCALCOVERIMG));
                    deviceInfo.role = cursor.getInt(cursor.getColumnIndex(Field.KEY_ROLE));
                    deviceInfo.avatarUrl = cursor.getString(cursor.getColumnIndex(Field.AVATAR_URL));
                    DeviceInfo.Relation relation = new DeviceInfo.Relation();
                    relation.relation_title = cursor.getString(cursor.getColumnIndex(Field.RELATION_TITLE));
                    deviceInfo.relation = relation;
                    deviceInfo.hardware = cursor.getString(cursor.getColumnIndex(Field.HARDWARE_TYPE));
                    deviceInfo.version = cursor.getString(cursor.getColumnIndex(Field.HARDWARE_VERSION));
                    deviceInfo.isOnline = cursor.getInt(cursor.getColumnIndex(Field.STATE));
                    String aclString = cursor.getString(cursor.getColumnIndex(Field.ACLINFO));
                    deviceInfo.aclInfo = gson.fromJson(aclString, PrivateEntity.class);
                    deviceInfo.support = cursor.getString(cursor.getColumnIndex(Field.SUPPORT));
                    deviceInfo.deviceType = cursor.getString(cursor.getColumnIndex(Field.DEVICE_TYPE));
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }

            return deviceInfo;
        } else {
            return null;
        }
    }

    public ArrayList<DeviceInfo> getAllPad() {
        SQLiteDatabase sqLiteDatabase = GlobalManager.getInstance().config().db.getWritableDatabase();
        ArrayList<DeviceInfo> deviceInfos = new ArrayList<>();
        Cursor cursor = null;
        try {
            Gson gson = new Gson();
            cursor = sqLiteDatabase.query(TABLE_NAME, null, null, null, null, null, null);
            while (cursor.moveToNext()) {
                DeviceInfo deviceInfo = new DeviceInfo();
                deviceInfo.qid = cursor.getString(cursor.getColumnIndex(Field.KEY_QID_ID));
                deviceInfo.title = cursor.getString(cursor.getColumnIndex(Field.TITLE_CLO));
                deviceInfo.setCoverUrl(cursor.getString(cursor.getColumnIndex(Field.KEY_COVERURL)));
                deviceInfo.shareNum = cursor.getInt(cursor.getColumnIndex(Field.KEY_SHARE_NUMBER));
                deviceInfo.sn = cursor.getString(cursor.getColumnIndex(Field.KEY_SN));
                deviceInfo.localCoverImg = cursor.getString(cursor.getColumnIndex(Field.LOCALCOVERIMG));
                deviceInfo.role = cursor.getInt(cursor.getColumnIndex(Field.KEY_ROLE));
                deviceInfo.avatarUrl = cursor.getString(cursor.getColumnIndex(Field.AVATAR_URL));
                DeviceInfo.Relation relation = new DeviceInfo.Relation();
                relation.relation_title = cursor.getString(cursor.getColumnIndex(Field.RELATION_TITLE));
                deviceInfo.relation = relation;
                deviceInfo.hardware = cursor.getString(cursor.getColumnIndex(Field.HARDWARE_TYPE));
                deviceInfo.version = cursor.getString(cursor.getColumnIndex(Field.HARDWARE_VERSION));
                deviceInfo.isOnline = cursor.getInt(cursor.getColumnIndex(Field.STATE));
                String aclString = cursor.getString(cursor.getColumnIndex(Field.ACLINFO));
                deviceInfo.aclInfo = gson.fromJson(aclString, PrivateEntity.class);
                deviceInfo.support = cursor.getString(cursor.getColumnIndex(Field.SUPPORT));
                deviceInfo.deviceType = cursor.getString(cursor.getColumnIndex(Field.DEVICE_TYPE));
                deviceInfos.add(deviceInfo);
            }
        } catch (Exception e) {
            CLog.e(e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return deviceInfos;
    }

    public List<String> getAllPadSet() {
        SQLiteDatabase sqLiteDatabase = GlobalManager.getInstance().config().db.getWritableDatabase();
        List<String> deviceInfosSet = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = sqLiteDatabase.query(TABLE_NAME, null, null, null, null, null, null);
            while (cursor.moveToNext()) {
                String sn = cursor.getString(cursor.getColumnIndex(Field.KEY_SN));
                deviceInfosSet.add(sn);
            }
        } catch (Exception e) {
            CLog.e(e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return deviceInfosSet;
    }

    private synchronized long insertPadInfo(SQLiteDatabase sqLiteDatabase, String qid, String sn, String title, int role,
            int shareNum, String coverUrl, String avatarUrl, String relationTitle,
            String hardwareType, String hardwareVersion, int state, String alcinfo, String remoteSupport,
            String deviceType) {
        long effectCount = 0;
        ContentValues values = new ContentValues();
        values.put("qid", qid);
        values.put("sn", sn);
        values.put("title", title);
        values.put("role", role);
        values.put("shareNum", shareNum);
        values.put("coverUrl", coverUrl);
        values.put("avatarUrl", avatarUrl);
        values.put(Field.STATE, state);
        values.put(Field.RELATION_TITLE, relationTitle);
        values.put(Field.HARDWARE_TYPE, hardwareType);
        values.put(Field.HARDWARE_VERSION, hardwareVersion);
        values.put(Field.ACLINFO, alcinfo);
        values.put(Field.SUPPORT, remoteSupport);
        values.put(Field.DEVICE_TYPE, deviceType);
        effectCount = sqLiteDatabase.insert(TABLE_NAME, "", values);
        return effectCount;
    }

    public boolean existQidPadInfo(String qid, String sn) {
        long count = 0;
        SQLiteDatabase db = GlobalManager.getInstance().config().db.getReadableDatabase();
        StringBuffer sb = new StringBuffer("");
        sb.append("select count(_id) from ");
        sb.append(TABLE_NAME);
        sb.append(" where qid='" + qid + "' and sn='" + sn + "'");
        try {
            SQLiteStatement statement = db.compileStatement(sb.toString());
            count = statement.simpleQueryForLong();
        } catch (Exception e) {
            //            e.printStackTrace();
        } finally {
        }
        return count > 0;
    }

    public synchronized boolean deletePadBySnQid(String sn, String qid) {
        synchronized (PadInfoWrapper.class) {
            long count = 0;
            SQLiteDatabase db = GlobalManager.getInstance().config().db.getReadableDatabase();
            StringBuffer sb = new StringBuffer("");
            sb.append("delete from ");
            sb.append(TABLE_NAME);
            sb.append(" where sn='" + sn + "'");
            try {
                SQLiteStatement statement = db.compileStatement(sb.toString());
                count = statement.simpleQueryForLong();
            } catch (Exception e) {
                //                e.printStackTrace();
            } finally {
                return count > 0;
            }
        }
    }

    public void delAll() {
        synchronized (PadInfoWrapper.class) {
            SQLiteDatabase db = GlobalManager.getInstance().config().db.getWritableDatabase();
            db.delete(TABLE_NAME, null, null);
        }
    }

    public synchronized boolean deletePadByQid(String qid) {
        SQLiteDatabase db = GlobalManager.getInstance().config().db.getWritableDatabase();
        long count = 0;
        StringBuffer sb = new StringBuffer("");
        sb.append("delete from ");
        sb.append(TABLE_NAME);
        sb.append(" where qid='" + qid + "'");
        try {
            SQLiteStatement statement = db.compileStatement(sb.toString());
            count = statement.simpleQueryForLong();
        } catch (Exception e) {
            //            e.printStackTrace();
        } finally {
            return count > 0;
        }
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int toVersion) {
        switch (toVersion) {
            case 3:
                db.execSQL("ALTER TABLE " + TABLE_NAME + " ADD COLUMN " + Field.HARDWARE_TYPE + " varchar(255,0)");
                db.execSQL("ALTER TABLE " + TABLE_NAME + " ADD COLUMN " + Field.HARDWARE_VERSION + " varchar(255,0)");
                break;
            case 5:
                db.execSQL("ALTER TABLE " + TABLE_NAME + " ADD COLUMN " + Field.STATE + " INTEGER NOT NULL DEFAULT 0");
                break;
            case 6:
                db.execSQL("ALTER TABLE " + TABLE_NAME + " ADD COLUMN " + Field.ACLINFO + " varchar(255,0)");
                db.execSQL("ALTER TABLE " + TABLE_NAME + " ADD COLUMN " + Field.SUPPORT + " varchar(255,0)");
                break;
            case 9:
                db.execSQL("ALTER TABLE " + TABLE_NAME + " ADD COLUMN " + Field.DEVICE_TYPE + " varchar(255,0)");
                break;
        }

    }

    @Override
    public void onOpen(SQLiteDatabase db) {

    }

    private static final class Field {
        public static final String KEY_QID_ID = "qid";
        public static final String KEY_SN = "sn";
        public static final String KEY_ROLE = "role";
        public static final String KEY_SHARE_NUMBER = "shareNum";
        public static final String KEY_COVERURL = "coverUrl";
        public static final String LOCALCOVERIMG = "localCoverImg";
        public static final String SELECTED = "selected";
        public static final String TITLE_CLO = "title";
        public static final String AVATAR_URL = "avatarUrl";
        public static final String RELATION_TITLE = "relationTitle";
        public static final String HARDWARE_TYPE = "hardware";
        public static final String HARDWARE_VERSION = "version";
        public static final String STATE = "state";
        public static final String ACLINFO = "aclInfo";
        public static final String SUPPORT = "support";
        public static final String DEVICE_TYPE = "device_type";
    }
}
