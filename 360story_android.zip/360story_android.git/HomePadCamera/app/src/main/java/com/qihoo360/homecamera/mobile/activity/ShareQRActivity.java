
package com.qihoo360.homecamera.mobile.activity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.db.PadInfoWrapper;
import com.qihoo360.homecamera.mobile.entity.InnerMsg;
import com.qihoo360.homecamera.mobile.entity.ShareShareEntity;
import com.qihoo360.homecamera.mobile.exception.CameraAesException;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.utils.AESUtil;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.util.Hashtable;

public class ShareQRActivity extends BaseActivity implements ActionListener {

    private ImageView img_QR;//, shareBg;
    private int QR_WIDTH = 200, QR_HEIGHT = 200;
    private int LOGO_WIDTH = QR_WIDTH / 5, LOGO_HEIGHT = QR_HEIGHT / 5;
    private boolean ISSMALL = false;
    private String mSn;
    private Bitmap shareBgBmp;
    private ImageView mBackIv;

    @Override
    protected void onCreate(Bundle arg0) {
        super.onCreate(arg0);

        mSn = getIntent().getStringExtra("sn");
        if (TextUtils.isEmpty(mSn)) {
            CameraToast.show(this, R.string.error_no_camera_sn, Toast.LENGTH_SHORT);
            finish();
            return;
        }

        setContentView(R.layout.activity_share_qr);

//        shareBg = (ImageView) findViewById(R.id.share_bg);
//        shareBg.setMaxWidth(SysConfig.BASE_SCREEN_WIDTH);
//        shareBg.setMaxHeight(SysConfig.BASE_SCREEN_HEIGHT);

        img_QR = (ImageView) findViewById(R.id.img_QR);
        img_QR.getViewTreeObserver().addOnGlobalLayoutListener(new OnGlobalLayoutListener() {
            @SuppressWarnings("deprecation")
            @Override
            public void onGlobalLayout() {
                img_QR.getViewTreeObserver().removeGlobalOnLayoutListener(this);
                if (img_QR.getWidth() < img_QR.getHeight()) {
                    QR_WIDTH = img_QR.getWidth();
                    QR_HEIGHT = QR_WIDTH;
                    ISSMALL = false;
                } else {
                    QR_WIDTH = img_QR.getHeight();
                    QR_HEIGHT = QR_WIDTH;
                    ISSMALL = true;
                }

                LOGO_WIDTH = QR_WIDTH / 5;
                LOGO_HEIGHT = LOGO_WIDTH;
            }
        });

        mBackIv = (ImageView) findViewById(R.id.btn_back);
        mBackIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        Glide.with(this)
                .load(AccUtil.getInstance().getUserToken().mAvatorUrl)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .error(R.drawable.icon_avator_empty)
                .into((ImageView) findViewById(R.id.iv_qr_head));

//        ImageLoader.getInstance().cancelDisplayTask((ImageView) findViewById(R.id.iv_qr_head));
//        ImageLoader.getInstance().displayImage(AccUtil.getInstance().getUserToken().mAvatorUrl, (ImageView) findViewById(R.id.iv_qr_head));
        showTipsDialog(getString(R.string.tips_qrcode_loading), R.drawable.icon_loading, true);
        GlobalManager.getInstance().getShareManager().registerActionListener(this);
        GlobalManager.getInstance().getShareManager().asyncShareShare(mSn, "1", "", PadInfoWrapper.getInstance().getPadBySn(mSn).isStoryMachine() ? Constants.DeviceType.STORYMACHINE : Constants.DeviceType.KIBOTMACHINE);//401000000008
    }

    @Override
    public void onDestroy() {
        if (shareBgBmp != null) {
            shareBgBmp.recycle();
            shareBgBmp = null;
        }
        GlobalManager.getInstance().getShareManager().removeActionListener(this);
        super.onDestroy();
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_refresh_qr:
                //TODO 刷新分享码
                GlobalManager.getInstance().getShareManager().asyncShareShare(mSn, "1", "", PadInfoWrapper.getInstance().getPadBySn(mSn).isStoryMachine()?Constants.DeviceType.STORYMACHINE:Constants.DeviceType.KIBOTMACHINE);//401000000008
                break;

            default:
                break;
        }
    }

    public void createQRImage(String url, Bitmap logo) throws WriterException {

        Hashtable<EncodeHintType, Object> hints = new Hashtable<EncodeHintType, Object>();
        if (ISSMALL) {
            hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.M);
        } else {
            hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
        }
        hints.put(EncodeHintType.CHARACTER_SET, "utf-8");
        hints.put(EncodeHintType.MARGIN, 1);

        BitMatrix matrix =
                new MultiFormatWriter().encode(url, BarcodeFormat.QR_CODE, QR_WIDTH, QR_HEIGHT,
                        hints);
        int width = matrix.getWidth();
        int height = matrix.getHeight();
        int halfW = width / 2;
        int halfH = height / 2;
        int[] pixels = new int[width * height];
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                if (x > halfW - LOGO_WIDTH / 2 && x < halfW + LOGO_WIDTH / 2
                        && y > halfH - LOGO_HEIGHT / 2 && y < halfH + LOGO_HEIGHT / 2) {

                    //                    pixels[y * width + x] =
                    //                            logo.getPixel(x - halfW + LOGO_WIDTH / 2, y - halfH + LOGO_HEIGHT / 2);
                    pixels[y * width + x] = 0xff000000;

                } else {
                    if (matrix.get(x, y)) {
                        pixels[y * width + x] = 0xff000000;
                    } else {
                        pixels[y * width + x] = 0xffffffff;
                    }
                }

            }
        }
        final Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        bitmap.setPixels(pixels, 0, width, 0, 0, width, height);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                img_QR.setImageBitmap(bitmap);
                if (shareBgBmp == null) {
                    shareBgBmp = Utils.getBitmap(R.drawable.add_share_word_bg);
                }
//                shareBg.setImageBitmap(shareBgBmp);
                //findViewById(R.id.ll_share_qr_container).setVisibility(View.VISIBLE);
                getProgressDialog().dismiss();
            }
        });

    }

    @Override
    protected void switchMode(boolean speaker_mode) {
        super.switchMode(speaker_mode);
    }

    @Override
    public void onMessage(InnerMsg imsg) {
        super.onMessage(imsg);
    }

    @Override
    public void setTintManagerQWork(boolean work) {
        super.setTintManagerQWork(work);
    }

    @Override
    public int getProperty() {
        return 0;
    }

    @SuppressWarnings("unchecked")
    @Override
    public Object actionPerformed(int actionCode, Object... args) {
        switch (actionCode) {
            case Actions.Share.SHARE_SHARE_SUCCESS:
                ShareShareEntity shareShareEntity = (ShareShareEntity) args[0];
                try {
                    createQRImage("http://kibot.360.cn/app/down.html?appInvite=" + AESUtil.encryptBase64(Constants.AEC_KEY, shareShareEntity.data.code), null);
                } catch (WriterException e) {
                    e.printStackTrace();
                } catch (CameraAesException e) {
                    e.printStackTrace();
                } finally {
                    hideTipsDialog();
                }
                return Boolean.TRUE;
            case Actions.Share.SHARE_SHARE_FAIL: {
                hideTipsDialog();
//                if (args == null || args.length == 0) {
//                    CameraToast.showErrorToast(ShareQRActivity.this, R.string.load_camera_list_failed);
//                } else {
//                    CameraToast.showErrorToast((String) args[0]);
//                }
                return Boolean.TRUE;
            }
        }
        return null;
    }
}
