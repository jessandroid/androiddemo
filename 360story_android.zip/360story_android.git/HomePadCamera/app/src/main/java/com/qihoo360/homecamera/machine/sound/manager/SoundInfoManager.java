
package com.qihoo360.homecamera.machine.sound.manager;

import android.os.Handler;
import android.text.TextUtils;

import com.qihoo360.homecamera.machine.business.TaskExecutor;
import com.qihoo360.homecamera.machine.config.MachineDefaultClientConfig;
import com.qihoo360.homecamera.machine.net.CameraHttpApi;
import com.qihoo360.homecamera.machine.sound.SoundPlayView;
import com.qihoo360.homecamera.machine.sound.entity.SoundCmdInfo;
import com.qihoo360.homecamera.machine.sound.entity.SoundPlayInfo;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.activity.RuntimeConfig;
import com.qihoo360.homecamera.mobile.config.Const;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionPublisherWithThreadPoolBase;
import com.qihoo360.homecamera.mobile.core.manager.workpool.PoolThreadFactory;
import com.qihoo360.homecamera.mobile.entity.Head;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class SoundInfoManager extends ActionPublisherWithThreadPoolBase {

    private static final String TAG = SoundInfoManager.class.getSimpleName();

    private String url = MachineDefaultClientConfig.CHILD_URL;
    private static Map<String, SoundInfoManager> map = new HashMap<String, SoundInfoManager>();
    private String mPoolNameHighPriority;

    public SoundPlayInfo.SoundInfo mSoundInfo = null;//正在播放的info
    public int playNum = -1;//正在播放第几个，从0开始
    public int playState = SoundTask.SOUND_STOP;//播放状态，保持和摄像头一致，1是处于播放音乐的状态;2是处于暂停播放的状态 ;4是处于结束播放的状态

    private static SoundPlayInfo mSoundPlayInfo = null;//联网获取的数据，只获取一次
    public static boolean isGetSoundPlayData = false;//是否获取了data

    private boolean isAnalysePlayState = true;//是否需要，联网完成主动调用调用解析
    private SoundCmdInfo playStateInfo = null;//服务器返回播放状态的结构

    public boolean isNeedSelection = false;

    private SoundInfoManager() {
        super();
        mPoolNameHighPriority = "Sound-Info-manager-" + Utils.DATE_FORMAT_3.format(new Date());
        if (!isGetSoundPlayData) {
            mThreadPool.initPool(mPoolNameHighPriority,
                    Executors.newCachedThreadPool(new PoolThreadFactory(mPoolNameHighPriority)));
        }

    }

    /*public static SoundInfoManager getInstance() {
        if (mManager == null) {
            mManager = new SoundInfoManager();
        }
        return mManager;
    }*/

    public static SoundInfoManager getInstance(String sn) {
        if (map == null) {
            map = new HashMap<String, SoundInfoManager>();
        }
        SoundInfoManager mSoundInfoManager = (SoundInfoManager) map.get(sn);
        if (mSoundInfoManager == null) {
            mSoundInfoManager = new SoundInfoManager();
            map.put(sn, mSoundInfoManager);//添加一次，第二次就不填写了
        }
        return mSoundInfoManager;
    }

    public SoundPlayInfo getSoundPlayInfo() {
        return mSoundPlayInfo;
    }

    /**
     * 请求儿歌列表
     */
    public void asyncGetSoundList() {
        if (mThreadPool != null) {
            mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("sound-list"));
        }
    }

    /**
     * 更新摄像头的播放状态
     */
    @SuppressWarnings("rawtypes")
    public Future updatePlayState(Handler handler, String sn) {
        CLog.i("play-v2","called updatePlayState");
        return TaskExecutor.Execute(new SoundTask("", SoundTask.SOUND_QUERY,
                "", 1, 1, SoundTask.SOUND_QUERY, Head.class, handler, sn));
    }

    // TODO 暂时注释 push的处理
//    public void updataPush(final Push push) {
//        new Thread() {
//            public void run() {
//                try {
//                    CLog.d(TAG, "收到摄像头消息：" + new Gson().toJson(push));
//                    if (push.value.errorCode == 3601) {
//                        //和服务器约定了，3601为服务器回复的值
//                        Gson gson = new Gson();
//                        SoundCmdInfo info = gson.fromJson(push.value.errorMsg, SoundCmdInfo.class);
//
//                        if (info.isquery == SoundTask.SOUND_QUERY_KEY) {
//                            //如果是查询的key，走查询的配置
//                            analysePlayState(info);
//                        }
//
//                        if (info.key == SoundTask.SOUND_RECEIVE_KEY - 1) {
//                            //正好比上次收到的消息小1，说明新消息先到的后来的，后收到新到的
//                            return;
//                        } else {
//                            //只有收到的消息大于等于发送的，才接收
//                            SoundTask.SOUND_RECEIVE_KEY = info.key;
//                        }
//
//                        switch (info.state) {
//                            case SoundTask.SOUND_PLAY:
//                                //1播放音乐的状态;
//                            case SoundTask.SOUND_PAUSE:
//                                //2暂停播放的状态
//                            case SoundTask.SOUND_CONTINUE:
//                                //3继续播放的状态
//                            case SoundTask.SOUND_STOP:
//                                //3结束播放的状态
//                                if (info.state == SoundTask.SOUND_CONTINUE) {
//                                    //如果是继续播放的状态，则识别为播放状态
//                                    playState = SoundTask.SOUND_PLAY;
//                                    info.state = SoundTask.SOUND_PLAY;
//                                } else {
//                                    playState = info.state;
//                                }
//                                if (TextUtils.isEmpty(info.md5)) {
//                                    playState = SoundTask.SOUND_STOP;//如果播放值是空的，则重置状态停止
//                                } else {
//                                    //说明md5不是空
//                                    if (!mSoundInfo.songMd5.equals(info.md5)) {
//                                        //如果正在播放的和返回的不是同一首歌，则列表数一次
//                                        analysePlayState(info);
//                                    }
//                                }
//                                break;
//                            default:
//                                break;
//                        }
//                        publishAction(Actions.Sound.SOUND_PUSH, info.state);
//                    }
//                } catch (Exception e) {
//                }
//            };
//        }.start();
//    }

    public void analysePlayState(SoundCmdInfo info, final SoundPlayView.SoundPlayListener mSoundPlayListener) {
        if (info == null)
            return;
        if (Const.DEBUG) {
            CLog.d(TAG, "analysePlayState");
        }

        if (TextUtils.isEmpty(info.md5)) {
            //如果MD5是空的，则认为没有歌曲在播放
            playState = SoundTask.SOUND_STOP;
            playNum = 0;
            return;
        }

        playStateInfo = info;
        new Thread() {
            public void run() {
                try {
                    if (isGetSoundPlayData) {
                        if (Const.DEBUG) {
                            CLog.d(TAG, "analysePlayState   ==  isGetSoundPlayData");
                        }
                        //如果获取到了数据
                        if (mSoundPlayInfo != null && mSoundPlayInfo.data != null && mSoundPlayInfo.data.size() > 0) {
                            CLog.d(TAG, "analysePlayState   ==  数据满足开始查询");

                            SoundPlayInfo.SoundInfo itemInfo;
                            for (int i = 0; i < mSoundPlayInfo.data.size(); i++) {
                                itemInfo = mSoundPlayInfo.data.get(i);
                                if (!TextUtils.isEmpty(itemInfo.songMd5) && !TextUtils.isEmpty(playStateInfo.md5) && itemInfo.songMd5.equals(playStateInfo.md5)) {
                                    CLog.d(TAG, "读取到服务器的状态：" + playStateInfo.state + ",正在播放：" + i);

                                    playNum = i;//找到了正在播放的
                                    playState = playStateInfo.state;
                                    isAnalysePlayState = false;
                                    isNeedSelection = true;
                                    mSoundInfo = itemInfo;
                                    if (mSoundPlayListener != null) {
                                        mSoundPlayListener.onRefresh(3);
                                    }
                                    return;
                                }
                            }
                        }
                    } else {
                        if (Const.DEBUG) {
                            CLog.d(TAG, "analysePlayState   !=  isGetSoundPlayData");
                        }
                        //如果没有获取数据
                        isAnalysePlayState = true;
                    }
                } catch (Exception e) {
                }
            };
        }.start();
    }

    /**
     * 不开线程遍历
     * @param info
     */
    private void analysePlayState(SoundCmdInfo info) {
        if (info == null)
            return;
        if (Const.DEBUG) {
            CLog.d(TAG, "analysePlayState");
        }

        if (TextUtils.isEmpty(info.md5)) {
            //如果MD5是空的，则认为没有歌曲在播放
            playState = SoundTask.SOUND_STOP;
            playNum = 0;
            return;
        }

        playStateInfo = info;
        try {
            if (isGetSoundPlayData) {
                if (Const.DEBUG) {
                    CLog.d(TAG, "analysePlayState   ==  isGetSoundPlayData");
                }
                //如果获取到了数据
                if (mSoundPlayInfo != null && mSoundPlayInfo.data != null && mSoundPlayInfo.data.size() > 0) {
                    CLog.d(TAG, "analysePlayState   ==  数据满足开始查询");
                    SoundPlayInfo.SoundInfo itemInfo;
                    for (int i = 0; i < mSoundPlayInfo.data.size(); i++) {
                        itemInfo = mSoundPlayInfo.data.get(i);
                        if (!TextUtils.isEmpty(itemInfo.songMd5) && !TextUtils.isEmpty(playStateInfo.md5) && itemInfo.songMd5.equals(playStateInfo.md5)) {
                            CLog.d(TAG, "读取到服务器的状态：" + playStateInfo.state + ",正在播放：" + i);

                            playNum = i;//找到了正在播放的
                            playState = playStateInfo.state;
                            isAnalysePlayState = false;
                            isNeedSelection = true;
                            return;
                        }
                    }
                }
            } else {
                if (Const.DEBUG) {
                    CLog.d(TAG, "analysePlayState   !=  isGetSoundPlayData");
                }
                //如果没有获取数据
                isAnalysePlayState = true;
            }
        } catch (Exception e) {
        }
    }

    public synchronized static int getPlayNum(SoundCmdInfo playStateInfo) {
        if (mSoundPlayInfo != null && mSoundPlayInfo.data != null && mSoundPlayInfo.data.size() > 0) {
            CLog.d(TAG, "analysePlayState   ==  数据满足开始查询");

            SoundPlayInfo.SoundInfo itemInfo;
            for (int i = 0; i < mSoundPlayInfo.data.size(); i++) {
                itemInfo = mSoundPlayInfo.data.get(i);
                if (!TextUtils.isEmpty(itemInfo.songMd5) && !TextUtils.isEmpty(playStateInfo.md5) && itemInfo.songMd5.equals(playStateInfo.md5)) {
                    CLog.d(TAG, "读取到服务器的状态：" + playStateInfo.state + ",正在播放：" + i);

                    return i;
                }
            }
        }
        return -1;
    }

    @Override
    protected void asyncDoNamedJob(String jobName, Object... args) {
        if (TextUtils.equals("sound-list", jobName)) {
            doGetSoundList();
        }
    }

    private void doGetSoundList() {
        if (Const.DEBUG)
            CLog.d(TAG, "doGetSoundList()");
        try {
            RuntimeConfig runtimeConfig = GlobalManager.getInstance().config();
            CameraHttpApi cameraHttpApi = runtimeConfig.cameraHttpApi;
            String tmp = Utils.getContext().getResources().getString(R.string.name_child_list);

            final SoundPlayInfo result = cameraHttpApi.doSpecialGetRequest(TextUtils.isEmpty(tmp) ? url : tmp, SoundPlayInfo.class);
            CLog.i("test2","SoundPlayInfo result.getStatusCode() = ----------" + result.getStatusCode());
            if (result.getStatusCode() == 200 && result != null && result.data != null) {
                mSoundPlayInfo = result;
                isGetSoundPlayData = true;
                if (isAnalysePlayState) {
                    analysePlayState(playStateInfo);
                }
                publishAction(Actions.Sound.SOUND_LIST, Boolean.TRUE);
            } else {
                isGetSoundPlayData = false;
                publishAction(Actions.Sound.SOUND_ERROR, Boolean.FALSE);
            }
        } catch (Exception e) {
            isGetSoundPlayData = false;
            publishAction(Actions.Sound.SOUND_ERROR, Boolean.FALSE);
            e.printStackTrace();
        }
    }

    @Override
    public void stopNow() {
        super.stopNow();
        if (mThreadPool != null)
            mThreadPool.destroyPool(mPoolNameHighPriority);
        mPoolNameHighPriority = null;
        if (map != null) {
            map.clear();
        }
    }

    public static void clearData() {
        //列表数据，最后清理
        if (mSoundPlayInfo != null && mSoundPlayInfo.data != null) {
            mSoundPlayInfo.data.clear();
            mSoundPlayInfo = null;
        } else {
            mSoundPlayInfo = null;
        }
        isGetSoundPlayData = false;
    }

    @Override
    public void destroyNow() {
        super.destroyNow();
    }

    /**
     * 释放资源
     */
    public void onDestroy() {
        stopNow();
        destroyNow();
    }

}
