package com.qihoo360.homecamera.machine.push.business.cmd.content;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by zhangchao-pd on 2016/11/22.
 */

public class ContentBase implements Parcelable{

    public static class SenderInfo implements Parcelable{
        private String sn;

        private String title;

        private String qid;

        public String getSn() {
            return sn;
        }

        public void setSn(String sn) {
            this.sn = sn;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getQid() {
            return qid;
        }

        public void setQid(String qid) {
            this.qid = qid;
        }


        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(this.sn);
            dest.writeString(this.title);
            dest.writeString(this.qid);
        }

        public SenderInfo() {
        }

        protected SenderInfo(Parcel in) {
            this.sn = in.readString();
            this.title = in.readString();
            this.qid = in.readString();
        }

        public static final Creator<SenderInfo> CREATOR = new Creator<SenderInfo>() {
            @Override
            public SenderInfo createFromParcel(Parcel source) {
                return new SenderInfo(source);
            }

            @Override
            public SenderInfo[] newArray(int size) {
                return new SenderInfo[size];
            }
        };
    }

    private SenderInfo senderInfo;

    public SenderInfo getSenderInfo() {
        return senderInfo;
    }

    public void setSenderInfo(SenderInfo senderInfo) {
        this.senderInfo = senderInfo;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(this.senderInfo, flags);
    }

    public ContentBase() {
    }

    protected ContentBase(Parcel in) {
        this.senderInfo = in.readParcelable(SenderInfo.class.getClassLoader());
    }

    public static final Creator<ContentBase> CREATOR = new Creator<ContentBase>() {
        @Override
        public ContentBase createFromParcel(Parcel source) {
            return new ContentBase(source);
        }

        @Override
        public ContentBase[] newArray(int size) {
            return new ContentBase[size];
        }
    };
}
