
package com.qihoo360.homecamera.mobile.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.SysConfig;
import com.qihoo360.homecamera.mobile.core.beans.PhotoAlbum;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.utils.imageloader.ImageLoaderHelper;
import com.qihoo360.homecamera.mobile.widget.PhotoViewNew;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;

public class LocalPhotoListAdapter extends BaseAlbumPhotoListAdapter implements OnScrollListener {
    @SuppressWarnings("unused")
    private OnClickListener mOpenAlbumListener;
    private OnClickListener mCameraAlbumListener;
    @SuppressWarnings("unused")
    private int scrollStauts = 0;
    private ListView mListView;
    private ActionListener mListener;
    private LinkedHashMap<Integer, PhotoAlbum> selectedMap = new LinkedHashMap<Integer, PhotoAlbum>();
    private ArrayList<PhotoAlbum> list = new ArrayList<PhotoAlbum>();
    @SuppressWarnings("unused")
    private HashMap<Integer, String> mImageThumbPath = null;
    private Context ctx;
    private boolean mIsAvatar = false;
    private DisplayImageOptions imageDisplayOptions;

    public LocalPhotoListAdapter(OnClickListener openAlbumListener, OnClickListener cameraAlbumListener,
                                 ListView listView, ActionListener listener, Context context, boolean isAvatar) {
        mOpenAlbumListener = openAlbumListener;
        mCameraAlbumListener = cameraAlbumListener;
        imageDisplayOptions = new DisplayImageOptions.Builder().cloneFrom(ImageLoaderHelper.DEFAULT_DISPLAY_OPTIONS)
                .imageScaleType(ImageScaleType.EXACTLY_STRETCHED)
                .build();
        mListener = listener;
        mListView = listView;
        mListView.setOnScrollListener(this);
        mIsAvatar = isAvatar;
        setChildColumnCount(3);
        ctx = context;
    }

    public void setData(ArrayList<PhotoAlbum> list, HashMap<Integer, String> map) {
        this.mImageThumbPath = map;
        this.list = list;
        int size = 0;
        if (mIsAvatar == true) {
            size = this.list.size() + 1;
        } else {
            size = this.list.size();
        }

        int row = 0;
        int mod = size % mColumnCount;
        if (mod > 0) {
            row = (size / mColumnCount) + 1;
        } else {
            row = size / mColumnCount;
        }
        setCount(row);
        setTotalCount(size);
        notifyDataSetChanged();
    }

    public long getItemId(int position) {
        return position;
    }

    @Override
    public Object getItem(int position) {
        return this.list.get(position);
    }

    enum TYPE {
        camera, img
    }

    @Override
    public int getItemViewType(int position) {
        int newType = 0;
        if (mIsAvatar == true) {
            if (position == 0) {
                newType = 0;
            } else {
                newType = 1;
            }
        } else {
            newType = 1;
        }
        return newType;
    }

    @Override
    public int getViewTypeCount() {
        return TYPE.values().length;
    }

    public boolean isFileChecked(int id) {
        return selectedMap.containsKey(id);
    }

    public void addFileChecked(PhotoAlbum photoAlbum) {
        if (photoAlbum != null) {
            if (mIsAvatar) {
                mListener.actionPerformed(Actions.Local.UPLOAD_ALBUM_AVATAR_CHOOSE, photoAlbum);
            } else {
                selectedMap.put(photoAlbum._id, photoAlbum);
            }
        }
    }

    public void removeFileChecked(int nid) {
        if (!"".equals(nid)) {
            selectedMap.remove(nid);
        }
    }

    public void clearAllSelectedNoExit() {
        if (!selectedMap.isEmpty()) {
            selectedMap.clear();
            notifyDataSetChanged();
            if (mListener != null) {
                mListener.actionPerformed(Actions.Activity.SELECT_SIZE_CHANGE, 0, Actions.FileListMenu.UNSELECT_ALL);
            }
        }
    }

    public void clearAllSelected() {
        if (!selectedMap.isEmpty()) {
            selectedMap.clear();
            notifyDataSetChanged();
            if (mListener != null) {
                mListener.actionPerformed(Actions.Activity.SELECT_SIZE_CHANGE, 0, 0);
            }
        }
    }

    public void selectAll() {
        for (PhotoAlbum pa : this.list) {
            if (!isFileChecked(pa._id)) {
                addFileChecked(pa);
            }
        }
        onSelecSizeChanged(Actions.FileListMenu.SELECT_ALL);
        notifyDataSetChanged();
    }

    public int getCheckedFileCount() {
        return selectedMap.size();
    }

    public ArrayList<PhotoAlbum> getFilesChecked() {
        ArrayList<PhotoAlbum> fileList = new ArrayList<PhotoAlbum>();
        fileList.addAll(selectedMap.values());
        return fileList;
    }

    private void onSelecSizeChanged(int actionType) {
        if (mListener != null) {
            mListener.actionPerformed(Actions.Activity.SELECT_SIZE_CHANGE, getCheckedFileCount(), actionType);
        }
    }

    private int getItemCount() {
        return this.list.size();
    }

    @Override
    public View getChildItemView(int childPosition, View convertView, ViewGroup parent, int rawPosition) {
        View realView = convertView;

        int viewType = getItemViewType(childPosition);

        TYPE type = TYPE.camera;

        if (viewType == 0) {
            type = TYPE.camera;
        } else if (viewType == 1) {
            type = TYPE.img;
        }

        if (realView == null) {
            realView = newView(parent, type);
        }
        int dataPos = 0;
        if (childPosition > 0) {
            if (mIsAvatar == true) {
                dataPos = childPosition - 1;
            } else {
                dataPos = childPosition;
            }
        }
        PhotoAlbum album = new PhotoAlbum();
        if (this.list.isEmpty() == false) {
            album = this.list.get(dataPos);
        }
        bindView(dataPos, realView, album, type);
        setItemPadding((int) (1 * SysConfig.DENSITY));
        setChildrenParentPadding(0);
        return realView;
    }

    @SuppressWarnings("unused")
    public View newView(ViewGroup parent, TYPE type) {
        View baseView = null;
        AlbumViewHolder holder;
        AddAlbumViewHolder addholder;
        if (type == TYPE.img) {
            if (baseView == null) {
                holder = new AlbumViewHolder();
                baseView = LayoutInflater.from(parent.getContext()).inflate(R.layout.photo_local_album_item, null);
                holder.albumThumb = (PhotoViewNew) baseView.findViewById(R.id.ca_bg);
                holder.albumThumb.setModeAndCheck(PhotoViewNew.MODE_NORMAL, false, 1);
                holder.albumThumb.setTag(holder);
                baseView.setTag(holder);
                setItemPadding(0);
                setChildrenParentPadding(0);
            } else {
                if (baseView.getTag() instanceof AlbumViewHolder) {
                } else {
                    holder = new AlbumViewHolder();
                    baseView = LayoutInflater.from(parent.getContext()).inflate(R.layout.photo_local_album_item, null);
                    holder.albumThumb = (PhotoViewNew) baseView.findViewById(R.id.ca_bg);
                    holder.albumThumb.setModeAndCheck(PhotoViewNew.MODE_NORMAL, false, 1);
                    holder.albumThumb.setTag(holder);
                    baseView.setTag(holder);
                    setItemPadding(0);
                    setChildrenParentPadding(0);
                }
            }
            return baseView;
        } else if (type == TYPE.camera) {
            if (baseView == null) {
                addholder = new AddAlbumViewHolder();
                baseView = LayoutInflater.from(parent.getContext()).inflate(R.layout.album_list_item_add, null);
                addholder.viewAddAlbum = (ImageView) baseView.findViewById(R.id.addAlbum);
                baseView.setTag(addholder);
                setItemPadding(0);
                setChildrenParentPadding(0);
            } else {
                if (baseView.getTag() instanceof AlbumViewHolder) {
                } else {
                    addholder = new AddAlbumViewHolder();
                    baseView = LayoutInflater.from(parent.getContext()).inflate(R.layout.album_list_item_add, null);
                    addholder.viewAddAlbum = (ImageView) baseView.findViewById(R.id.addAlbum);
                    baseView.setTag(addholder);
                    setItemPadding(0);
                    setChildrenParentPadding(0);
                }
            }
            return baseView;
        }
        return baseView;
    }

    public void bindView(final int position, View view, final PhotoAlbum album, TYPE type) {

        if (type == TYPE.img) {
            final AlbumViewHolder holder = (AlbumViewHolder) view.getTag();
            holder.album = album;
            holder.albumThumb.setMaxWidth(SysConfig.BASE_SCREEN_WIDTH / 3);
            holder.albumThumb.setMaxHeight(SysConfig.BASE_SCREEN_WIDTH / 3);
            String path = null;
            path = album.getThumbnailUri();
            if (selectedMap.containsKey(album._id)) {
                holder.albumThumb.setModeAndCheck(PhotoViewNew.MODE_SELECTED, true, 1);
            } else {
                holder.albumThumb.setModeAndCheck(PhotoViewNew.MODE_NORMAL, false, 1);
            }
            ImageLoader.getInstance().cancelDisplayTask(holder.albumThumb);
            ImageLoader.getInstance().displayImage(path, holder.albumThumb, imageDisplayOptions, createSimpleImageLoadingListener());
            holder.albumThumb.setOnClickListener(new OnClickListener() {

                @Override
                public void onClick(View v) {
                    boolean isCheck = false;
                    if (selectedMap.containsKey(album._id)) {
                        removeFileChecked(album._id);
                        isCheck = false;
                    } else if (getCheckedFileCount() <= 2) {
                        isCheck = true;
                        CLog.i("test1", "album._size = " + album._size);
                        if (album._size > 10 * 1024 * 1024) {
                            CameraToast.showToast(ctx, R.string.size_too_big);
                        } else {
                            addFileChecked(album);
                        }
                    } else {
                        CameraToast.show(ctx, Utils.getString(R.string.atmost_3_prompt), Toast.LENGTH_LONG);
                    }
                    CLog.d("the selected count is :" + selectedMap.size());
                    notifyDataSetChanged();
                    onSelecSizeChanged(getCheckedFileCount() != getItemCount() ?
                            0 /*0 means default check action*/: Actions.FileListMenu.SELECT_ALL);
                }
            });
        } else if (type == TYPE.camera) {
            view.setOnClickListener(mCameraAlbumListener);
        }
    }

    private SimpleImageLoadingListener createSimpleImageLoadingListener() {
        return new SimpleImageLoadingListener() {
            @Override
            public void onLoadingStarted(String imageUri, View view) {
            }

            @Override
            public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
            }

            @Override
            public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
            }
        };
    }

    public class AlbumViewHolder {
        PhotoViewNew albumThumb;
        ImageView checkbox;
        TextView photosNum, albumName;

        public PhotoAlbum album;
    }

    class AddAlbumViewHolder {
        ImageView viewAddAlbum;
    }

    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState) {
        switch (scrollState) {
            case OnScrollListener.SCROLL_STATE_IDLE:
                scrollStauts = 0;
                notifyDataSetChanged();
                break;
            case OnScrollListener.SCROLL_STATE_TOUCH_SCROLL:// 触摸滑动
                                                                        // 1
                scrollStauts = 1;
                break;
            case OnScrollListener.SCROLL_STATE_FLING:// 快速滑动 2
                scrollStauts = 2;
                break;
        }
    }

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
    }

    public boolean back() {
        if (getCheckedFileCount() > 0) {
            clearAllSelected();
            return true;
        }
        return false;
    }
}
