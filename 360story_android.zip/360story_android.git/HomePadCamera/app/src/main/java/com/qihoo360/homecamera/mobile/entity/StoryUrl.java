package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/4/6
 * Time: 16:45
 * To change this template use File | Settings | File Templates.
 */
public class StoryUrl implements Parcelable {
    public String url;
    public String token;

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.url);
        dest.writeString(this.token);
    }

    public StoryUrl() {
    }

    protected StoryUrl(Parcel in) {
        this.url = in.readString();
        this.token = in.readString();
    }

    public static final Parcelable.Creator<StoryUrl> CREATOR = new Parcelable.Creator<StoryUrl>() {
        @Override
        public StoryUrl createFromParcel(Parcel source) {
            return new StoryUrl(source);
        }

        @Override
        public StoryUrl[] newArray(int size) {
            return new StoryUrl[size];
        }
    };


    public String getUrl() {
        return this.url + "&Authorization=" + token;

    }
}
