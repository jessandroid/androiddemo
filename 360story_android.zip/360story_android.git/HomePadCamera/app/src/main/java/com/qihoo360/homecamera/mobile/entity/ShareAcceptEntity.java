package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by zhaojunbo on 2016/5/11.
 * desc:
 */
public class ShareAcceptEntity extends Head {

    public Data data;

    public static class Data implements Parcelable {
        public String sn;

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(this.sn);
        }

        public Data() {
        }

        protected Data(Parcel in) {
            this.sn = in.readString();
        }

        public static final Creator<Data> CREATOR = new Creator<Data>() {
            @Override
            public Data createFromParcel(Parcel source) {
                return new Data(source);
            }

            @Override
            public Data[] newArray(int size) {
                return new Data[size];
            }
        };
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeParcelable(this.data, flags);
    }

    public ShareAcceptEntity() {
    }

    protected ShareAcceptEntity(Parcel in) {
        super(in);
        this.data = in.readParcelable(Data.class.getClassLoader());
    }

    public static final Creator<ShareAcceptEntity> CREATOR = new Creator<ShareAcceptEntity>() {
        @Override
        public ShareAcceptEntity createFromParcel(Parcel source) {
            return new ShareAcceptEntity(source);
        }

        @Override
        public ShareAcceptEntity[] newArray(int size) {
            return new ShareAcceptEntity[size];
        }
    };
}
