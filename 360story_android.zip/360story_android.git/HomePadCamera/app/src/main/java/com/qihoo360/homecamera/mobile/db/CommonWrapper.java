
package com.qihoo360.homecamera.mobile.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.qihoo360.homecamera.mobile.entity.ImageInfoListEntity;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.model.Splash;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.Preferences;

import java.util.ArrayList;
import java.util.List;

public class CommonWrapper extends AbstractWrapper {

    private final static String TAG = "CommonWrapper";
    public static final String TABLE_NAME = "common_tab";
    private static CommonWrapper mInstance;
    private LocalDB dbManage;
    private Context mContext;
    public static final int TYPE_FIRST_PAGE = 1;
    public static final int TYPE_APP_GET_INFO = 2;
    public static final int TYPE_SHARE_GETLIST_INFO = 3;
    public static final int TYPE_UPLOAD_SUC_STORY = 4;
    public static final int TYPE_GET_IPC_ALL = 5;
    public static final int TYPE_MACHINE_LOCAL_SETTING = 6;//故事机本地设置信息
    public static final int TYPE_MACHINE_DEVICE_INFO = 7;//故事机信息

    public static CommonWrapper getInstance(Context context) {
        if (mInstance == null) {
            synchronized (CommonWrapper.class) {
                if (mInstance == null) {
                    mInstance = new CommonWrapper(
                            GlobalManager.getInstance().config().db,
                            context.getApplicationContext());
                }
            }
        }
        return mInstance;
    }

    private CommonWrapper(LocalDB db, Context context) {
        CLog.e(TAG, "CommonWrapper db = " + db);
        this.dbManage = db;
        this.mContext = context;
    }

//    private void setDbManage(LocalDB db){
//        if (db != null){
//            dbManage = db;
//        }
//    }
//
//    private boolean isValidDb(){
//        if (dbManage != null){
//            return true;
//        }
//
//        return false;
//    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int toVersion) {
        switch (toVersion) {
            case 4:
                db.execSQL("CREATE TABLE IF NOT EXISTS common_tab (_id INTEGER, vt INTEGER ,v VARCHAR (255,0), column_one VARCHAR (255,0), column_two VARCHAR (255,0), column_three VARCHAR (255,0), column_four VARCHAR (255,0),column_five VARCHAR (255,0), column_six VARCHAR (255,0), column_seven VARCHAR (255,0), column_eight VARCHAR (255,0), column_nine VARCHAR (255,0), column_ten VARCHAR (255,0), column_eleven VARCHAR (255,0), column_twelve VARCHAR (255,0), column_thirteen VARCHAR (255,0), column_fourteen VARCHAR (255,0), column_fifteen VARCHAR (255,0), column_sixteen VARCHAR (255,0), column_seventeen VARCHAR (255,0), column_eighteen VARCHAR (255,0), column_nineteen VARCHAR (255,0), column_twenty VARCHAR (255,0), column_twentyone VARCHAR (255,0), PRIMARY KEY(_id));");
                break;
        }
    }

    @Override
    public void onOpen(SQLiteDatabase db) {

    }

    public void writeBySnWithType(String sn, String json, int valueType) {
        if (json != null) {
            SQLiteDatabase db = dbManage.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(Field.V, json);
            values.put(Field.T, valueType);
            values.put(Field.COLUMN_TWO, sn);

            if (existTitle(valueType)) {
                db.update(TABLE_NAME, values, Field.T + "=?" + " and " + Field.COLUMN_TWO + "=?", new String[]{
                        String.valueOf(valueType), sn
                });
            } else {
                db.insert(TABLE_NAME, null, values);
            }
        }
    }

    public void writeFirstTinyVideo(String sn, ImageInfoListEntity ile) {
        writeBySnWithType(sn, ile.toJson(), TYPE_FIRST_PAGE);
    }

    public <T> T getLocalToClazz(String mSn, int valueType, Class<T> clazz) throws InstantiationException, IllegalAccessException {
        T t = null;
        SQLiteDatabase db = dbManage.getReadableDatabase();
        Cursor cursor = null;
        String v = null;
        try {
            cursor = db.query(
                    TABLE_NAME, null, Field.T + " =? and " + Field.COLUMN_TWO + " =? ",
                    new String[]{
                            String.valueOf(valueType), mSn
                    }, null, null, null);
            if (cursor.moveToFirst()) {
                v = cursor.getString(cursor.getColumnIndex(Field.V));
            }
            if (!TextUtils.isEmpty(v)) {
                Gson gson = new Gson();
                t = gson.fromJson(v, clazz);
            }
        } catch (Exception e) {
            CLog.e("db", e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return t;
    }

    public synchronized int delData(String mSn, int valueType) {
        int delRes = 0;
        SQLiteDatabase db = dbManage.getWritableDatabase();
        try {
            db.beginTransaction();
            delRes = db.delete(TABLE_NAME, Field.T + "=? and " + Field.COLUMN_TWO + " =? ",
                    new String[]{
                            String.valueOf(valueType), mSn
                    });
            db.setTransactionSuccessful();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (db != null) {
                db.endTransaction();
            }
        }
        return delRes;
    }


    public ImageInfoListEntity getFirstTinyVideo(String mSn) {
        ImageInfoListEntity list = null;
        try {
            list = getLocalToClazz(mSn, TYPE_FIRST_PAGE, ImageInfoListEntity.class);
        } catch (Exception e) {
            CLog.e("db", e.getMessage());
        }
        return list;
    }

    public boolean deleteAll() {
        boolean flag = false;
        synchronized (this) {
            SQLiteDatabase db = dbManage.getWritableDatabase();
            db.delete(TABLE_NAME, null, null);
            Cursor cursor = null;
            try {
                cursor = db.query(TABLE_NAME, null, null, null, null, null, null);
                if (cursor.moveToNext()) {
                    flag = true;
                } else {
                    flag = true;
                }
            } catch (Exception e) {
                flag = false;
                CLog.e(e.getMessage());
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
        return flag;
    }

    public boolean existTitle(int type) {
        boolean exist = false;
        Cursor cursor = null;
        try {
            SQLiteDatabase db = dbManage.getReadableDatabase();
            cursor = db.query(TABLE_NAME, null, Field.T + " = ?", new String[]{
                    String.valueOf(type)
            }, null, null, null);
            exist = cursor.moveToFirst();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return exist;
    }

    private boolean existCamera(int type, String url) {
        boolean exist = false;
        Cursor cursor = null;
        try {
            SQLiteDatabase db = dbManage.getReadableDatabase();
            cursor = db.query(TABLE_NAME, null, Field.T + " = ? and " + Field.URL + " = ?", new String[]{
                    String.valueOf(type), url
            }, null, null, null);
            exist = cursor.moveToFirst();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return exist;
    }

    public void writeSimpleUrlStringDataCache(String url, String content) {
        SQLiteDatabase db = dbManage.getWritableDatabase();
        try {
            db.beginTransaction();
            ContentValues values = new ContentValues();
            values.put(Field.COLUMN_THREE, url);
            values.put(Field.COLUMN_8, content);
            if (hasSimpleUrlStringDataCache(url)) {
                db.update(TABLE_NAME, values, Field.COLUMN_THREE + " =? ", new String[]{
                        url
                });
            } else {
                db.insert(TABLE_NAME, null, values);
            }
            db.setTransactionSuccessful();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (db != null) {
                db.endTransaction();
            }
        }
    }

    public String readSimpleUrlStringDataCache(String url) {
        String result = null;
        Cursor cursor = null;
        try {
            SQLiteDatabase db = dbManage.getReadableDatabase();
            cursor = db.query(TABLE_NAME, null, Field.COLUMN_THREE + " = ?", new String[]{
                    url
            }, null, null, null);
            if (cursor.moveToFirst()) {
                result = cursor.getString(cursor.getColumnIndex(Field.COLUMN_8));
            }
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return result;
    }

    public synchronized boolean hasSimpleUrlStringDataCache(String url) {
        boolean has = false;
        Cursor cursor = null;
        try {
            SQLiteDatabase db = dbManage.getReadableDatabase();
            cursor = db.query(TABLE_NAME, null, Field.COLUMN_THREE + " = ?", new String[]{
                    url
            }, null, null, null);
            has = cursor.moveToFirst();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return has;
    }

    public synchronized int delSimpleUrlStringDataCache(String url) {
        int delRes = 0;
        SQLiteDatabase db = dbManage.getWritableDatabase();
        try {
            db.beginTransaction();
            delRes = db.delete(TABLE_NAME, Field.COLUMN_THREE + "=?",
                    new String[]{
                            url
                    });
            db.setTransactionSuccessful();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (db != null) {
                db.endTransaction();
            }
        }
        return delRes;
    }

    /**
     * 闪屏数据开始
     */
    public synchronized void writeSplash(String url, Splash splash) {
        SQLiteDatabase db = dbManage.getWritableDatabase();
        try {
            db.beginTransaction();
            ContentValues values = new ContentValues();
            values.put(Field.COLUMN_THREE, splash.getImageServeLocal()); //唯一的id
            values.put(Field.COLUMN_FOUR, splash.toJson());
            values.put(Field.COLUMN_FIVE, 3);
            if (exitSplash(url)) {
                CLog.e(TAG, "writeSplash  exist url = " + url);
                if (splash.judgeEventIsAvaliable()) {
                    db.update(TABLE_NAME, values, Field.COLUMN_THREE + " =? ", new String[]{url});
                } else {
                    delSplash(splash);
                }
            } else {
                CLog.e(TAG, "writeSplash  not exist url = " + url);
                db.insert(TABLE_NAME, null, values);
            }
            db.setTransactionSuccessful();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (db != null) {
                db.endTransaction();
            }
        }
    }

    public synchronized int setSplashShowCount(String splashId, int count) {
        CLog.e(TAG, "setSplashShowCount splashId=" + splashId);
        int update_rows = 0;
        SQLiteDatabase db = dbManage.getWritableDatabase();
        try {
            db.beginTransaction();
            ContentValues values = new ContentValues();
            values.put(Field.COLUMN_SIX, count);
            update_rows = db.update(TABLE_NAME, values, Field.COLUMN_THREE + " =? ", new String[]{splashId});
            db.setTransactionSuccessful();
        } catch (Exception e) {
        } finally {
            if (db != null) {
                db.endTransaction();
            }
        }
        return update_rows;
    }

    public synchronized int delSplash(String splashId) {
        int delRes = 0;
        SQLiteDatabase db = dbManage.getWritableDatabase();
        try {
            db.beginTransaction();
            delRes = db.delete(TABLE_NAME, Field.COLUMN_THREE + "=?",
                    new String[]{splashId});
            db.setTransactionSuccessful();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (db != null) {
                db.endTransaction();
            }
        }
        CLog.e(TAG, "delSplash delRes=" + delRes + ", splashId=" + splashId);
        return delRes;
    }

    public synchronized int delSplash(Splash splash) {
        int delRes = 0;
        if (splash != null) {
            delRes = delSplash(splash.getImageServeLocal());
        }
        return delRes;
    }

    public Splash readSplashData() {
        CLog.e(TAG, "------------------  readSplashData  ------------------");
        Splash splash = new Splash();
        Splash splashPrev = null;
        Splash splashRandom = null;

        List<Splash> splashList = getAllSplashs();
        String splashId = Preferences.getSplashId();

        CLog.e(TAG, "splashList.size()=" + splashList.size() + ", splashId=" + splashId);
        for (Splash s : splashList) {
            CLog.e(TAG, "readSplashData -> Splash [" + s + "]");
            if (s.isEndTimeExpired()) {
                CLog.e(TAG, "过期数据删除：[" + s + "]");
                delSplash(splash);
            } else if (s.getSplashShowCount() < 3) {
                if (!TextUtils.isEmpty(splashId) && TextUtils.equals(s.getImageServeLocal(), splashId)) {
                    splashPrev = s; //取指定的数据
                    CLog.e(TAG, "取到指定的数据：[" + s + "]");
                    break;
                } else {
                    splashRandom = s; //随机取一个
                    CLog.e(TAG, "随机取一个：[" + s + "]");
                }
            }
        }
        if (splashPrev != null) {
            splash = splashPrev;
        } else if (splashRandom != null) {
            splash = splashRandom;
        }

        CLog.e(TAG, "最后返回数据: [" + splash + "]");
        Preferences.saveSplashId(splash.getImageServeLocal());
        //添加假数据
//        splash.setDestinationUrl("http://jia.360.cn/xuanfu_h5_2.html?from=shexiangji");
//        splash.setFromDate("2016-10-31");
//        splash.setEndDate("2016-12-09");
//        splash.setIamgeLocal("/sdcard/splash.jpg");

        return splash;
    }

    public synchronized List<Splash> getAllSplashs() {
        List<Splash> splashList = new ArrayList<Splash>();
        SQLiteDatabase db = dbManage.getWritableDatabase();
        Cursor cursor = null;
        Gson gson = new Gson();
        try {
            cursor = db.query(TABLE_NAME,
                    new String[]{Field.COLUMN_THREE, Field.COLUMN_FOUR, Field.COLUMN_SIX},
                    Field.COLUMN_FIVE + "=3",
                    null, null, null, null);

            CLog.e(TAG, "cursor.getCount()=" + cursor.getCount());
            CLog.e(TAG, "cursor.getColumnCount()=" + cursor.getColumnCount());

            while (cursor.moveToNext()) {
                String serverUrl = cursor.getString(0);
                String strJsonContent = cursor.getString(1);
                int count = cursor.getInt(2);
                CLog.e(TAG, "serverUrl = " + serverUrl + ", strJsonContent = " + strJsonContent + ", count = " + count);
                if (!TextUtils.isEmpty(serverUrl) && !TextUtils.isEmpty(strJsonContent)) {
                    Splash splash = gson.fromJson(strJsonContent, Splash.class);
                    if (splash != null) {
                        splash.setImageServeLocal(serverUrl);
                        splash.setSplashShowCount(count);
                        splashList.add(splash);
                    }
                }
            }
        } catch (Exception e) {
            CLog.e(TAG, "Exception: " + e.toString());
            e.printStackTrace();
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                CLog.e(TAG, "cursor.close();");
                cursor.close();
            }
        }

        return splashList;
    }

    public boolean exitSplash(String url) {
        boolean exist = false;
        Cursor cursor = null;
        try {
            SQLiteDatabase db = dbManage.getReadableDatabase();
            cursor = db.query(TABLE_NAME, null, Field.COLUMN_THREE + "=?", new String[]{url}, null, null, null);
            exist = cursor.moveToFirst();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        CLog.e(TAG, "exitSplash exist = " + exist + ", url = " + url);
        return exist;
    }



    public class Field {
        public static final String _ID = "_id";
        private static final String T = "vt";
        private static final String V = "v";
        private static final String URL = "column_one"; //4 camera
        private static final String COLUMN_TWO = "column_two"; //是否为首页

        //
        private static final String COLUMN_THREE = "column_three";
        private static final String COLUMN_FOUR = "column_four";
        private static final String COLUMN_FIVE = "column_five";
        private static final String COLUMN_SIX = "column_six";
        private static final String COLUMN_SEVEN = "column_seven";

        private static final String COLUMN_8 = "column_eight";
        private static final String COLUMN_9 = "column_nine";

        private static final String COLUMN_10 = "column_ten";
        private static final String COLUMN_11 = "column_eleven";

        private static final String COLUMN_12 = "column_twelve";
        private static final String COLUMN_13 = "column_thirteen";

        private static final String COLUMN_14 = "column_fourteen";
        private static final String COLUMN_15 = "column_fifteen";

        private static final String COLUMN_16 = "column_sixteen";
        private static final String COLUMN_17 = "column_seventeen";

        private static final String COLUMN_18 = "column_eighteen";
        private static final String COLUMN_19 = "column_nineteen";

        private static final String COLUMN_20 = "column_twenty";
        private static final String COLUMN_21 = "column_twentyone";

    }
}
