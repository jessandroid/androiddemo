
package com.qihoo360.homecamera.mobile.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.text.TextUtils;

import com.qihoo360.accounts.api.auth.model.UserTokenInfo;
import com.qihoo360.homecamera.mobile.entity.CamUserInfo;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.CLog;

import java.util.HashMap;

public class UserWrapper extends AbstractWrapper {

    public static final String TABLE_NAME = "user";
    private volatile static UserWrapper mInstance;
    @SuppressWarnings("unused")
    private Context mContext;

    public static UserWrapper getInstance(Context context) {
        if (mInstance == null) {
            synchronized (UserWrapper.class) {
                if (mInstance == null) {
                    mInstance = new UserWrapper(context.getApplicationContext());
                }
            }
        }
        return mInstance;
    }

    private UserWrapper(Context context) {
        this.mContext = context;
    }

    public static void destroyUserWrapper() {
        if (mInstance != null) {
            mInstance = null;
        }
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int toVersion) {
        switch (toVersion) {
            case 8:
                break;
            default:
                break;
        }
    }

    @Override
    public void onOpen(SQLiteDatabase db) {

    }

    public int updateSteamInfo(SQLiteDatabase db, String qid, String steamid, String steampwd, String token) {
        int effectCount = 0;
        ContentValues values = new ContentValues();
        values.put(Field.STREAM_ID, steamid);
        values.put(Field.STREAM_PWD, steampwd);
        CLog.i("test1", "steamid = " + steamid + "-------" + "steampwd = " + steampwd);
        values.put(Field.TOKEN, token);
        if (exist(qid)) {
            effectCount = db.update(TABLE_NAME, values, "qid=?", new String[]{
                    qid
            });
        }
        return effectCount;
    }

    /**
     * 插入数据、更新数据
     *
     * @param user
     */
    public void write(SQLiteDatabase db, UserTokenInfo user, String sessionId) {
        String qid = user.qid;
        String mAvatorUrl = null;
        String mLoginEmail = null;
        String mNickname = null;
        String mSecEmail = null;
        String mSecPhoneNumber = null;
        String mSecPhoneZone = null;
        String mUsername = null;
        String q = null;
        String t = null;

        String u = null;
        int mAvatorFlag = user.mAvatorFlag ? 1 : 0;
        mAvatorUrl = user.mAvatorUrl;

        mLoginEmail = user.mLoginEmail;
        mNickname = user.mNickname;
        mSecEmail = user.mSecEmail;
        mSecPhoneNumber = user.mSecPhoneNumber;

        mSecPhoneZone = user.mSecPhoneZone;
        mUsername = user.mUsername;
        q = user.q;
        t = user.t;
        u = user.u;
        ContentValues values = new ContentValues();
        values.put(Field.QID, qid);
        values.put(Field.Q, q);
        values.put(Field.AVATOR_FLAG, mAvatorFlag);
        values.put(Field.AVATOR_URL, mAvatorUrl);
        values.put(Field.LOGIN_EMAIL, mLoginEmail);
        values.put(Field.NICK_NAME, mNickname);
        values.put(Field.SEC_EMAIL, mSecEmail);
        values.put(Field.SEC_PHONE_NUM, mSecPhoneNumber);
        values.put(Field.SEC_PHONE_ZONE, mSecPhoneZone);
        values.put(Field.USER_NAME, mUsername);
        values.put(Field.T, t);
        values.put(Field.U, u);
        if (!TextUtils.isEmpty(sessionId)) {
            values.put(Field.SESSION_ID, sessionId);
        }
        if (exist(qid)) {
            db.update(TABLE_NAME, values, "qid=?", new String[]{
                    qid
            });
        } else {
            values.put(Field.QID, qid);
            db.insert(TABLE_NAME, null, values);
        }
        CLog.d("test1", "user DB write:" + user.toString());
    }

    /**
     * session key update
     *
     * @param sessionId
     * @return
     */
    public synchronized boolean setSessionId(String sessionId) {
        synchronized (this) {
            boolean flag = false;
            String qid = AccUtil.getInstance().getQID();
            if (GlobalManager.getInstance().config() != null && GlobalManager.getInstance().config().db != null) {
                SQLiteDatabase db = GlobalManager.getInstance().config().db.getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put(Field.SESSION_ID, sessionId);
                if (exist(qid)) {
                    db.update(TABLE_NAME, values, "qid=?", new String[]{
                            qid
                    });
                    flag = true;
                }
            }
            return flag;
        }
    }

    public String getSessionId() {
        return getUser().sessionId;
    }

    /**
     * session key update
     *
     * @param avator_local
     * @return
     */
    public boolean setAvator_local(String avator_local) {
        synchronized (this) {
            boolean flag = false;
            String qid = AccUtil.getInstance().getQID();
            SQLiteDatabase db = GlobalManager.getInstance().config().db.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put(Field.AVATOR_LOCAL, avator_local);
            if (exist(qid)) {
                db.update(TABLE_NAME, values, "qid=?", new String[]{
                        qid
                });
                flag = true;
            }
            return flag;
        }
    }

    public String getAvator_local() {
        return getUser().avator_local;
    }

    /**
     * push key update
     *
     * @param pushKey
     * @return
     */
    public boolean setPushKey(String pushKey) {
        synchronized (this) {
            boolean flag = false;
            String qid = AccUtil.getInstance().getQID();
            if (GlobalManager.getInstance().config().db != null) {
                SQLiteDatabase db = GlobalManager.getInstance().config().db.getWritableDatabase();

                ContentValues values = new ContentValues();
                values.put(Field.PUSH_KEY, pushKey);
                if (exist(qid)) {
                    flag = db.update(TABLE_NAME, values, "qid=?", new String[]{
                            qid
                    }) > 0;
                }
            }
            return flag;
        }

    }

    /**
     * push key update
     *
     * @return
     */
    public boolean setStreamPwdAndId(String pwd, String streamId) {
        synchronized (this) {
            boolean flag = false;
            String qid = AccUtil.getInstance().getQID();
            SQLiteDatabase db = GlobalManager.getInstance().config().db.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put(Field.STREAM_PWD, pwd);
            values.put(Field.STREAM_ID, streamId);
            CLog.i("test1", "steamid = " + streamId + "-------" + "steampwd = " + pwd);
            if (exist(qid)) {
                db.update(TABLE_NAME, values, "qid=?", new String[]{
                        qid
                });
                flag = true;
            }
            return flag;
        }
    }

    public String getPushKey() {
        return getUser().pushKey;
    }

    public String getStID() {
        return getUser().streamId;
    }

    public String getStPWD() {
        return getUser().streamPwd;
    }

    /**
     * 更新数据
     *
     * @param user
     */
    public void update(UserTokenInfo user) {
        synchronized (this) {
            SQLiteDatabase db = GlobalManager.getInstance().config().db.getWritableDatabase();
            int mAvatorFlag = user.mAvatorFlag ? 1 : 0;
            String mAvatorUrl = user.mAvatorUrl;
            String mLoginEmail = user.mLoginEmail;
            String mNickname = user.mNickname;
            String mSecEmail = user.mSecEmail;
            String mSecPhoneNumber = user.mSecPhoneNumber;
            String mSecPhoneZone = user.mSecPhoneZone;
            String mUsername = user.mUsername;
            String q = user.q;
            String t = user.t;
            String u = user.u;
            String qid = user.qid;
            ContentValues values = new ContentValues();
            values.put(Field.QID, qid);
            values.put(Field.Q, q);
            values.put(Field.AVATOR_FLAG, mAvatorFlag);
            values.put(Field.AVATOR_URL, mAvatorUrl);
            values.put(Field.LOGIN_EMAIL, mLoginEmail);
            values.put(Field.NICK_NAME, mNickname);
            values.put(Field.SEC_EMAIL, mSecEmail);
            values.put(Field.SEC_PHONE_NUM, mSecPhoneNumber);
            values.put(Field.SEC_PHONE_ZONE, mSecPhoneZone);
            values.put(Field.USER_NAME, mUsername);
            values.put(Field.T, t);
            values.put(Field.U, u);
            if (exist(qid)) {
                db.update(TABLE_NAME, values, "qid=?", new String[]{
                        qid
                });
            }
        }
    }

    public boolean updateUserInfoItemNew(UserTokenInfo info) {
        synchronized (this) {
            boolean flag = false;
            SQLiteDatabase db = GlobalManager.getInstance().config().db.getWritableDatabase();
            ContentValues values = new ContentValues();
            if (!TextUtils.isEmpty(info.mNickname)) {
                values.put(Field.NICK_NAME, info.mNickname);
            }
            if (info.mLoginEmail != null) {
                values.put(Field.LOGIN_EMAIL, info.mLoginEmail);
            }
            if (info.mSecEmail != null) {
                values.put(Field.SEC_EMAIL, info.mSecEmail);
            }
            if (info.mSecPhoneNumber != null) {
                values.put(Field.SEC_PHONE_NUM, info.mSecPhoneNumber);
            }
            if (info.mUsername != null) {
                values.put(Field.USER_NAME, info.mUsername);
            }
            if (info.q != null) {
                values.put(Field.Q, info.q);
            }
            if (info.t != null) {
                values.put(Field.T, info.t);
            }
            if (info.mAvatorUrl != null) {
                values.put(Field.AVATOR_URL, info.mAvatorUrl);
            }
            values.put(Field.AVATOR_FLAG, info.mAvatorFlag);

            String qid = AccUtil.getInstance().getQID();
            if (qid != null && !qid.equals("")) {
                if (exist(qid)) {
                    db.update(TABLE_NAME, values, "qid=?", new String[]{
                            qid
                    });
                    flag = true;
                }
            }
            return flag;
        }
    }

    public boolean updateUserInfoItem(HashMap<String, String> itemMap) {
        CLog.e("push", "updateUserInfoItem");
        synchronized (this) {
            boolean flag = false;
            SQLiteDatabase db = GlobalManager.getInstance().config().db.getWritableDatabase();
            ContentValues values = new ContentValues();
            if (itemMap.containsKey(Field.NICK_NAME)) {
                values.put(Field.NICK_NAME, itemMap.get(Field.NICK_NAME));
            }
            if (itemMap.containsKey(Field.LOGIN_EMAIL)) {
                values.put(Field.LOGIN_EMAIL, itemMap.get(Field.LOGIN_EMAIL));
            }
            if (itemMap.containsKey(Field.AVATOR_FLAG)) {
                values.put(Field.AVATOR_FLAG, itemMap.get(Field.AVATOR_FLAG));
            }
            if (itemMap.containsKey(Field.SEC_EMAIL)) {
                values.put(Field.SEC_EMAIL, itemMap.get(Field.SEC_EMAIL));
            }
            if (itemMap.containsKey(Field.SEC_PHONE_NUM)) {
                values.put(Field.SEC_PHONE_NUM, itemMap.get(Field.SEC_PHONE_NUM));
            }
            if (itemMap.containsKey(Field.USER_NAME)) {
                values.put(Field.USER_NAME, itemMap.get(Field.USER_NAME));
            }
            if (itemMap.containsKey(Field.Q)) {
                values.put(Field.Q, itemMap.get(Field.Q));
            }
            if (itemMap.containsKey(Field.T)) {
                values.put(Field.T, itemMap.get(Field.T));
            }
            if (itemMap.containsKey(Field.PUSH_KEY)) {
                CLog.e("push", "updateUserInfoItem" + itemMap.get(Field.PUSH_KEY));
                values.put(Field.PUSH_KEY, itemMap.get(Field.PUSH_KEY));
            }
            if (itemMap.containsKey(Field.AVATOR_URL)) {
                values.put(Field.AVATOR_URL, itemMap.get(Field.AVATOR_URL));
            }
            if (itemMap.containsKey(Field.AVATOR_LOCAL)) {
                values.put(Field.AVATOR_LOCAL, itemMap.get(Field.AVATOR_LOCAL));
            }
            if (itemMap.containsKey(Field.SEC_PHONE_NUM)) {
                values.put(Field.SEC_PHONE_NUM, itemMap.get(Field.SEC_PHONE_NUM));
            }
            if (itemMap.containsKey(Field.LOGIN_EMAIL)) {
                values.put(Field.LOGIN_EMAIL, itemMap.get(Field.LOGIN_EMAIL));
            }
            if (itemMap.containsKey(Field.SEC_EMAIL)) {
                values.put(Field.SEC_EMAIL, itemMap.get(Field.SEC_EMAIL));
            }

            String qid = AccUtil.getInstance().getQID();

            if (qid != null && !qid.equals("")) {
                if (exist(qid)) {
                    db.update(TABLE_NAME, values, "qid=?", new String[]{
                            qid
                    });
                    flag = true;
                }
            }
            return flag;
        }
    }

    public boolean deleteAll() {
        synchronized (this) {
            boolean flag = false;
            SQLiteDatabase db = GlobalManager.getInstance().config().db.getWritableDatabase();
            db.delete(TABLE_NAME, null, null);
            Cursor cursor = null;
            try {
                cursor = db.query(TABLE_NAME, null, null, null, null, null, null);
                if (cursor.moveToNext()) {
                    flag = true;
                } else {
                    flag = true;
                }
            } catch (Exception e) {
                flag = false;
                CLog.e(e.getMessage());
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
            return flag;
        }
    }

    /**
     * 获取用户信息
     *
     * @return
     */
    public CamUserInfo getUser() {
        CamUserInfo user = new CamUserInfo();
        if (GlobalManager.getInstance().config().db != null) {
            SQLiteDatabase db = GlobalManager.getInstance().config().db.getReadableDatabase();
            String qid = null;
            String mAvatorUrl = null;
            String mLoginEmail = null;
            String mNickname = null;
            String mSecEmail = null;
            String mSecPhoneNumber = "";
            String mSecPhoneZone = "";
            String mUsername = null;
            String q = null;
            String t = null;
            String u = null;
            String pushKey = null;
            String sessionId = null;
            String avator_local = null;
            String streamID = null;
            String streamPWD = null;
            String token = null;
            Cursor cursor = null;
            try {
                cursor = db.query(TABLE_NAME, null, null, null, null, null, null);
                while (cursor.moveToNext()) {
                    user.mAvatorFlag = cursor.getInt(cursor.getColumnIndex(Field.AVATOR_FLAG)) == 1 ? true : false;
                    mAvatorUrl = cursor.getString(cursor.getColumnIndex(Field.AVATOR_URL));
                    mLoginEmail = cursor.getString(cursor.getColumnIndex(Field.LOGIN_EMAIL));
                    mNickname = cursor.getString(cursor.getColumnIndex(Field.NICK_NAME));
                    mSecEmail = cursor.getString(cursor.getColumnIndex(Field.SEC_EMAIL));
                    mSecPhoneNumber = cursor.getString(cursor.getColumnIndex(Field.SEC_PHONE_NUM));
                    mSecPhoneZone = cursor.getString(cursor.getColumnIndex(Field.SEC_PHONE_ZONE));
                    mUsername = cursor.getString(cursor.getColumnIndex(Field.USER_NAME));
                    q = cursor.getString(cursor.getColumnIndex(Field.Q));
                    qid = cursor.getString(cursor.getColumnIndex(Field.QID));
                    t = cursor.getString(cursor.getColumnIndex(Field.T));
                    u = cursor.getString(cursor.getColumnIndex(Field.U));
                    avator_local = cursor.getString(cursor.getColumnIndex(Field.AVATOR_LOCAL));
                    sessionId = cursor.getString(cursor.getColumnIndex(Field.SESSION_ID));
                    pushKey = cursor.getString(cursor.getColumnIndex(Field.PUSH_KEY));
                    streamID = cursor.getString(cursor.getColumnIndex(Field.STREAM_ID));
                    streamPWD = cursor.getString(cursor.getColumnIndex(Field.STREAM_PWD));
                    CLog.i("test1", "get user streamID = " + streamID + "-------" + "streamPWD = " + streamPWD);
                    token = cursor.getString(cursor.getColumnIndex(Field.TOKEN));
                    user.mAvatorUrl = mAvatorUrl;
                    user.qid = qid;
                    user.mLoginEmail = mLoginEmail;
                    user.mNickname = mNickname;
                    user.mSecEmail = mSecEmail;
                    user.mSecPhoneNumber = mSecPhoneNumber;
                    user.mSecPhoneZone = mSecPhoneZone;
                    user.mUsername = mUsername;
                    user.q = q;
                    user.t = t;
                    user.u = u;
                    user.pushKey = pushKey;
                    user.sessionId = sessionId;
                    user.avator_local = avator_local;
                    user.streamId = streamID;
                    user.streamPwd = streamPWD;
                    user.token = token;
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
        return user;

    }

    public final Long queryQidCount(SQLiteDatabase db, String qid) {
        //        SQLiteDatabase db = GlobalManager.getInstance().config().db.getReadableDatabase();
        long count = 0;
        StringBuffer sb = new StringBuffer("");
        sb.append("select count(_id) from ");
        sb.append(TABLE_NAME);
        sb.append(" where " + Field.QID + "='" + qid + "'");
        try {
            SQLiteStatement statement = db.compileStatement(sb.toString());
            count = statement.simpleQueryForLong();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }
        return count;
    }

    private boolean exist(String qid) {
        boolean exist = false;
        if (TextUtils.isEmpty(qid)) {
            return exist;
        }
        try {
            SQLiteDatabase db = GlobalManager.getInstance().config().db.getReadableDatabase();
            long queryRes = queryQidCount(db, qid);
            if (queryRes > 0) {
                exist = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return exist;
    }

    public class Field {
        public static final String QID = "qid";
        public static final String Q = "q";
        public static final String T = "t";
        public static final String U = "u";
        public static final String USER_NAME = "user_name";
        public static final String AVATOR_URL = "avator_url";
        public static final String LOGIN_EMAIL = "login_email";
        public static final String NICK_NAME = "nick_name";
        public static final String SEC_EMAIL = "sec_email";
        public static final String SEC_PHONE_NUM = "sec_phone_num";
        public static final String SEC_PHONE_ZONE = "sec_phone_zone";
        public static final String AVATOR_FLAG = "avator_flag";
        public static final String SESSION_ID = "session_id";
        public static final String PUSH_KEY = "push_key";
        public static final String AVATOR_LOCAL = "avator_local";
        public static final String IS_VIP = "is_vip";
        public static final String IS_ADMIN = "is_admin";
        public static final String user_type = "type";
        public static final String STREAM_ID = "stream_id";
        public static final String STREAM_PWD = "stream_pwd";
        public static final String TOKEN = "token";
    }
}
