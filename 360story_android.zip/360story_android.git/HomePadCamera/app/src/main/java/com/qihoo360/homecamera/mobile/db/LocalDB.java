
package com.qihoo360.homecamera.mobile.db;

import android.content.Context;
import android.content.res.Resources.NotFoundException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.utils.CLog;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class LocalDB extends SQLiteOpenHelper {

    public static int DATABASE_VERSION = 10;

    private volatile static LocalDB mInstances = null;
    private List<AbstractWrapper> mWrappers;
    public Context context;
    private String name;

    private LocalDB(Context context, String name) {
        super(context, name, null, DATABASE_VERSION);
        this.context = context;
        this.name = name;
        mWrappers = new ArrayList<AbstractWrapper>();
    }

    public static LocalDB getInstances(Context context, String name) {
        if (mInstances == null) {
            mInstances = new LocalDB(context.getApplicationContext(), name);
        }
        return mInstances;
    }

    public static void destroyLocalDB() {
        if (mInstances != null) {
            mInstances = null;
        }
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(context.getResources().openRawResource(
                    R.raw.phone_jia_local), "UTF-8"));
            String str = null;
            while ((str = reader.readLine()) != null) {
                CLog.justalkFile(str);
                db.execSQL(str);
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (NotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            // db.endTransaction();
        }

        Iterator<AbstractWrapper> iterator = mWrappers.iterator();
        while (iterator.hasNext()) {
            AbstractWrapper next = iterator.next();
            next.onCreate(db);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion > newVersion) {
            CLog.d("Database version error. ");
        } else {
            while (oldVersion < newVersion) {
                oldVersion += 1;
                Iterator<AbstractWrapper> iterator = mWrappers.iterator();
                while (iterator.hasNext()) {
                    AbstractWrapper next = iterator.next();
                    next.onUpgrade(db, oldVersion);
                }
            }
        }
    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        Iterator<AbstractWrapper> iterator = mWrappers.iterator();
        while (iterator.hasNext()) {
            AbstractWrapper next = iterator.next();
            next.onOpen(db);
        }
    }

    public void addWrapper(AbstractWrapper wrapper) {
        if (mWrappers == null) {
            mWrappers = new ArrayList<AbstractWrapper>();
        }
        mWrappers.add(wrapper);
    }

    public void removeWrapper() {
        if (mWrappers != null && mWrappers.size() > 0) {
            mWrappers = null;
        }
    }

}
