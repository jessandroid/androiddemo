
package com.qihoo360.homecamera.machine.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.text.Html;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.method.PasswordTransformationMethod;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;

import com.qihoo360.homecamera.device.config.StoryMachineConsts;
import com.qihoo360.homecamera.machine.adapter.WifiAdapter;
import com.qihoo360.homecamera.machine.entity.Group;
import com.qihoo360.homecamera.machine.entity.Wifi;
import com.qihoo360.homecamera.machine.preferences.Preferences;
import com.qihoo360.homecamera.machine.util.MachineUtils;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.SysConfig;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.FileUtil;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.widget.CamAlertDialog;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class CameraSettingsWifiActivity extends MachineBaseActivity implements View.OnClickListener {

    private ListView mWifiListView;
    private View mEmptyView;
    private ImageView img_refresh;
    private ProgressBar pb_wifi_ap;
    private TextView tv_wifi_ap;
    private WifiAdapter adapter;
    private WifiManager wifiManage;
    private WifiReceiver receiverWifi;
    private Group<Wifi> wifiGroup;
    private AccUtil mAccUtil;
    private Wifi wifi = new Wifi();
    private EditText tv_wifi_ssid;
    private LinearLayout layout_password;
    private EditText password_input;
    private TextView text_password;
    private boolean isRefresh = false;
    public String mSSID = "";
    private View wifi_view;
    private int scanCount;
    private boolean isFirst = true;
    private TextView tv_add_title;
    private boolean isRegisted = false;
    private ImageView iv_wifi_bg;
    private Bitmap addBgBmp;
    private MediaPlayer mMediaPlayer;
    private String setup_from;//设置的来源

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        wifiManage = (WifiManager) this.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if (!wifiManage.isWifiEnabled()) {
            if (!wifiManage.setWifiEnabled(true)) {
                // TODO string
                Toast.makeText(this, Utils.getString(R.string.confirm_wifi_permission_prompt), Toast.LENGTH_LONG).show();
                finish();
            }
        }
        setup_from = getIntent().getStringExtra(StoryMachineConsts.KEY_SET_WIFI_FROM);
        initView();
        setView();
        initSound();
    }

    private void initView() {
        setTintManagerQWork(true);
        tintManager.setStatusBarTintColor(Color.parseColor("#0000aeff"));
        setContentView(R.layout.activity_add_camera_wifi);
        iv_wifi_bg = (ImageView) findViewById(R.id.iv_wifi_bg);
        tv_add_title = (TextView) findViewById(R.id.tv_add_title);
        wifi_view = findViewById(R.id.wifi_list);
        tv_wifi_ssid = (EditText) findViewById(R.id.tv_wifi_ssid);
        layout_password = (LinearLayout) findViewById(R.id.layout_password);
        password_input = (EditText) findViewById(R.id.password_input);
        password_input.setTypeface(Typeface.DEFAULT);
        text_password = (TextView) findViewById(R.id.text_password);
        text_password.setText(R.string.app_pwd_hint);

        mWifiListView = (ListView) findViewById(R.id.lv_wifi_list);
        mEmptyView = findViewById(R.id.mEmptyView);
        img_refresh = (ImageView) findViewById(R.id.img_refresh);
        img_refresh.setOnClickListener(this);

        pb_wifi_ap = (ProgressBar) findViewById(R.id.pb_wifi_ap);
        tv_wifi_ap = (TextView) findViewById(R.id.tv_wifi_ap);

        adapter = new WifiAdapter();
        mWifiListView.setAdapter(adapter);
        mWifiListView.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parentView, View arg1, int position, long arg3) {
                Wifi wifis = (Wifi) parentView.getItemAtPosition(position);
                if (wifis.getAUTHTYPE() != 4 && wifis.getAUTHTYPE() != 5) {
                    wifi = wifis;
                    getWifiPassword();
                    tv_wifi_ssid.setText(wifi.getSSID());
                    tv_wifi_ssid.setTextColor(getResources()
                            .getColor(R.color.k_common_text_pressed));
                    password_input.setText(wifi.getPASSWORD());
                    password_input.setSelection(password_input.getText().toString().length());
                    password_input.requestFocus();
//                    if (wifis.getAUTHTYPE() == 0) {
//                        layout_password.setVisibility(View.GONE);
//                    } else {
//                        layout_password.setVisibility(View.VISIBLE);
//                    }
                    wifi_view.setVisibility(View.GONE);
                }
            }
        });
        findViewById(R.id.btn_wifi_cancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                wifi_view.setVisibility(View.GONE);
            }
        });

    }

    private void setView() {
        iv_wifi_bg.setMaxWidth(SysConfig.BASE_SCREEN_WIDTH);
        iv_wifi_bg.setMaxHeight(SysConfig.BASE_SCREEN_HEIGHT);
        addBgBmp = Utils.getBitmap(R.drawable.bg_machine_add);
        iv_wifi_bg.setImageBitmap(addBgBmp);

        wifiGroup = new Group<Wifi>();
        mAccUtil = AccUtil.getInstance();
        receiverWifi = new WifiReceiver();

        tv_wifi_ssid.setFilters(new InputFilter[] {
                new InputFilter() {
                    @Override
                    public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart,
                            int dend) {
                        layout_password.setVisibility(View.VISIBLE);
                        return source;
                    }
                }
        });

        tv_wifi_ssid.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                EditText _v = (EditText) view;
                _v.setSelection(_v.getEditableText().length());
            }
        });

        // password_input.setFilters(new InputFilter[] {
        // new InputFilter() {
        // @Override
        // public CharSequence filter(CharSequence source, int start, int end,
        // Spanned dest,
        // int dstart, int dend) {
        // int len =
        // source.toString().length() + dest.toString().length()
        // + tv_wifi_ssid.getText().toString().length();
        // if (len > 55) {
        // CameraToast.show(getString(R.string.add_psw_too_long), 0);
        // return "";
        // }
        // return source;
        // }
        // }
        // });
        password_input.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                EditText _v = (EditText) view;
                if (!b) {// 失去焦点
                    _v.setHint(_v.getTag().toString());
                } else {
                    String hint = _v.getHint().toString();
                    _v.setTag(hint);
                    _v.setHint("");
                }
            }
        });
        password_input.setOnEditorActionListener(new OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    GenerateQR(v);
                }
                return false;
            }
        });
        password_input.setTransformationMethod(null);

        text_password.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                if (password_input.getTransformationMethod() == null) {
                    text_password.setText(R.string.app_pwd_show);
                    password_input.setTransformationMethod(new PasswordTransformationMethod());
                    password_input.setSelection(password_input.getText().toString().length());
                } else {
                    text_password.setText(R.string.app_pwd_hint);
                    password_input.setTransformationMethod(null);
                    password_input.setSelection(password_input.getText().toString().length());
                }
            }
        });

        setConnectInfoView();
    }

    private void setConnectInfoView() {
        TextView textView = (TextView) findViewById(R.id.btn_wifi_connect_error);
        textView.setText(Html.fromHtml("<u>" + getString(R.string.wifi_connect_on_error) + "</u>"));
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LayoutInflater inflater = LayoutInflater.from(CameraSettingsWifiActivity.this);
                View viewDialog = inflater.inflate(R.layout.item_wifi_connect_toast, null);
                View closeBtn = viewDialog.findViewById(R.id.toast_close_iv);

                final CamAlertDialog camAlertDialog = new CamAlertDialog(CameraSettingsWifiActivity.this,
                        R.style.Dialog_Fullscreen);
                camAlertDialog.setContentView(viewDialog);
                closeBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        camAlertDialog.dismiss();
                    }
                });

                camAlertDialog.show();
            }
        });
    }

    private void initSound(){
        mMediaPlayer = MediaPlayer.create(this, R.raw.selectwifi);
        if (mMediaPlayer != null) {
            mMediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                }
            });
            mMediaPlayer.start();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (isFirst) {
            startTitleNextAnimation(tv_add_title, getString(R.string.add_first_step),
                    getString(R.string.add_second_step));
            isFirst = false;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        ConnectivityManager connManager =
                (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo mWifi = connManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        if (!mWifi.isConnected()) {
            // tv_wifi_ssid.setText(R.string.wifi_ssid_hint);
            // tv_wifi_ssid.setTextColor(getResources().getColor(R.color.text_hint));
            tv_wifi_ssid.setText("");
            password_input.setText("");
            ShowWiFiList(null);
        } else {
            if (!getWifiSign()) {
                // tv_wifi_ssid.setText(R.string.wifi_ssid_hint);
                // tv_wifi_ssid.setTextColor(getResources().getColor(R.color.text_hint));
                tv_wifi_ssid.setText("");
                password_input.setText("");
                ShowWiFiList(null);
            } else {
                tv_wifi_ssid.setText(wifi.getSSID());
                // tv_wifi_ssid.setTextColor(getResources().getColor(
                // R.color.k_common_text_pressed));

                if (MachineUtils.getAuth(wifi) != 0) {
                    getWifiPassword();
                    password_input.setText(wifi.getPASSWORD());
                    password_input.setSelection(password_input.getText().toString().length());
                }else{
                    password_input.setText("");
                }
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver();
    }

    @Override
    protected void onDestroy() {
        if (addBgBmp != null) {
            addBgBmp.recycle();
        }
        receiverWifi = null;
        if (mMediaPlayer != null) {
            mMediaPlayer.release();
        }
        super.onDestroy();
    }

    private void registerReceiver() {
        if (!isRegisted) {
            registerReceiver(receiverWifi, new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
            isRegisted = true;
        }
    }

    private void unregisterReceiver() {
        if (isRegisted) {
            try {
                unregisterReceiver(receiverWifi);
            } catch (Exception e) {
            }
            isRegisted = false;
        }
    }

    // 获取当前wifi连接名称和是否可使用frequency
    //
    public boolean getWifiSign() {
        try {
            if (wifiManage.isWifiEnabled() == false) {
                return false;
            }
            WifiInfo wifiInfo = wifiManage.getConnectionInfo();
            List<ScanResult> scanResults = wifiManage.getScanResults();
            if (wifiInfo != null && scanResults != null) {
                for (ScanResult scanResult : scanResults) {
//                    Gson gson = new Gson();
//                    CLog.d("CameraSettingsWifiActivity", gson.toJson(scanResult));
                    if (scanResult.SSID.equals(wifiInfo.getSSID().replace("\"", ""))) {
                        if (scanResult.frequency < 2405 || scanResult.frequency > 2485) {
                            return false;
                        } else {
                            Wifi wifi = createWifi(scanResult);
                            if (wifi.getAUTHTYPE() == 4 || wifi.getAUTHTYPE() == 5) {
                                return false;
                            }
                            this.wifi = wifi;
                            return true;
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public void ShowWiFiList(View view) {
        hideSoftInput();
        registerReceiver();
        wifi_view.setVisibility(View.VISIBLE);
        scanCount = 0;
        startScan();
    }

    /**
     * 支持了隐藏ssid，手动输入，就没办法过滤不支持的WiFi了
     * @param view
     */
    public void GenerateQR(View view) {
        //先关闭提示音
        String wifi_ssid = tv_wifi_ssid.getText().toString();
        String router_pwd = password_input.getText().toString();
        wifi.setSSID(wifi_ssid);
        wifi.setPASSWORD(router_pwd);
        wifi.setTIMESTAMP(System.currentTimeMillis());
        wifi.setQID(mAccUtil.getQID());
        if (TextUtils.isEmpty(wifi_ssid)) {
            CameraToast.show(getString(R.string.choose_wifi), Toast.LENGTH_SHORT);
        } else if (TextUtils.isEmpty(router_pwd)) {
            CamAlertDialog.Builder builder = new CamAlertDialog.Builder(this);
            builder.setMessageLeft(false);
            builder.setMessage(R.string.add_have_no_password);
            builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    SendPassword();
                }
            });
            builder.setNegativeButton(R.string.cancel, null);
            builder.show();
        } else {
            SendPassword();
        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.img_refresh) {
            if (!isRefresh) {
                scanCount = 0;
                startScan();
            } else {
                CameraToast.show(getString(R.string.refreshing), Toast.LENGTH_SHORT);
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (wifi_view.getVisibility() == View.VISIBLE) {
            wifi_view.setVisibility(View.GONE);
        } else {
            if (mMediaPlayer != null && mMediaPlayer.isPlaying()) {
                mMediaPlayer.stop();
            }
            Intent intent = new Intent(this, SetupGuideActivity.class);
            intent.putExtra("from", "behind");
            intent.putExtra("directSource", 1);
            intent.putExtra(StoryMachineConsts.KEY_SET_WIFI_FROM,setup_from);
            startActivity(intent);
            finish();
            overridePendingTransition(0, 0);
        }
    }

    private void hideSoftInput() {
        if (tv_wifi_ssid != null) {
            tv_wifi_ssid.clearFocus();
            InputMethodManager imm =
                    (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm.isActive()) {
                imm.hideSoftInputFromWindow(tv_wifi_ssid.getWindowToken(), 0);
            }
        }
    }

    public void startScan() {
        isRefresh = true;
        mWifiListView.setVisibility(View.GONE);
        mEmptyView.setVisibility(View.VISIBLE);
        pb_wifi_ap.setVisibility(View.VISIBLE);
        tv_wifi_ap.setText(getString(R.string.waiting));
        try {
            wifiManage.setWifiEnabled(true);
            wifiManage.startScan();
        } catch (Exception e) {
            CameraToast.show(Utils.getString(R.string.wifi_scan_fail_prompt), Toast.LENGTH_SHORT);
        }
        startTimer();
    }

    public void filterWifiList() {
        HashMap<String, Wifi> map = new HashMap<String, Wifi>();
        for (int i = 0; i < wifiGroup.size(); i++) {
            Wifi wifi = wifiGroup.get(i);
            if (!map.containsKey(wifi.getSSID())) {
                map.put(wifi.getSSID(), wifi);
            } else {
                Wifi wifio = map.get(wifi.getSSID());
                if (wifi.getLevel() <= wifio.getLevel()) {
                    map.put(wifio.getSSID(), wifio);
                }
            }
        }
        Iterator<String> iterator = map.keySet().iterator();
        Group<Wifi> filterwifis = new Group<Wifi>();
        while (iterator.hasNext()) {
            filterwifis.add(map.get(iterator.next()));
        }
        wifiGroup = filterwifis;
        Collections.sort(wifiGroup);
    }

    class WifiReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context c, Intent intent) {
            if (intent.getAction().equals(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)) {
                if(handler!=null){
                    handler.removeCallbacks(myRunnable);
                }
                List<ScanResult> scanResults = wifiManage.getScanResults();
                if (scanResults != null && scanResults.size() > 0) {
                    wifiGroup.clear();
                    for (ScanResult scanResult : scanResults) {
                        if (scanResult.SSID != null && !scanResult.SSID.equals("")) {
                            wifiGroup.add(createWifi(scanResult));
                        }
                    }
                    filterWifiList();
                    adapter.setWifis(wifiGroup);
                    mWifiListView.setVisibility(View.VISIBLE);
                    mEmptyView.setVisibility(View.GONE);
                    isRefresh = false;
                } else if (scanCount < 4) {
                    scanCount++;
                    startScan();
                } else if (wifi_view.getVisibility() == View.VISIBLE && !isFinishing()) {
                    mEmptyView.setVisibility(View.VISIBLE);
                    pb_wifi_ap.setVisibility(View.GONE);
                    tv_wifi_ap.setText(getString(R.string.camera_setting_no_wifi_ap));
                    CameraToast.show(Utils.getString(R.string.wifi_scan_fail_prompt), Toast.LENGTH_SHORT);
                    isRefresh = false;
                }
            }
        }
    }

    public void SendPassword() {
        if (testStorage()) {
            if(mMediaPlayer!=null && mMediaPlayer.isPlaying()){
                mMediaPlayer.stop();
            }
            saveWifiPassword();
            Intent intent = new Intent(CameraSettingsWifiActivity.this, AddCameraSoundActivity.class);
            intent.putExtra("Wifi", wifi);
            intent.putExtra(StoryMachineConsts.KEY_SET_WIFI_FROM,setup_from);
            startActivity(intent);
            overridePendingTransition(0, 0);
        } else {
            CameraToast.show(getString(R.string.storage_unenough), Toast.LENGTH_LONG);
        }
    }

    private boolean testStorage() {
        return FileUtil.getInstance().getAvailableSpare() > 10;
    }

    public int getSignalRes(Wifi wifi) {
        int resId = R.drawable.ic_wifi_signal_1_light;
        boolean isSecure = MachineUtils.getAuth((wifi)) != 0;
        int level = wifi.getLevel();
        if (level >= 3) {
            resId =
                    isSecure
                            ? R.drawable.ic_wifi_lock_signal_4_light
                            : R.drawable.ic_wifi_signal_4_light;
        } else if (level == 2) {
            resId =
                    isSecure
                            ? R.drawable.ic_wifi_lock_signal_3_light
                            : R.drawable.ic_wifi_signal_3_light;
        } else if (level == 1) {
            resId =
                    isSecure
                            ? R.drawable.ic_wifi_lock_signal_2_light
                            : R.drawable.ic_wifi_signal_2_light;
        } else {
            resId =
                    isSecure
                            ? R.drawable.ic_wifi_lock_signal_1_light
                            : R.drawable.ic_wifi_signal_1_light;
        }
        return resId;
    }

    private void saveWifiPassword() {
        String key = wifi.getWifiKey();
        String password = wifi.getPASSWORD();
        Preferences.saveWifiPassword(key, password);
    }

    private void getWifiPassword() {
        String key = wifi.getWifiKey();
        String password = Preferences.getWifiPassword(key);
        wifi.setPASSWORD(password);
        if (!TextUtils.isEmpty(password)) {
            text_password.setText(R.string.app_pwd_hint);
            password_input.setTransformationMethod(null);
        }
    }

    private Wifi createWifi(ScanResult scanResult) {
        Wifi wifi = new Wifi();
        wifi.setSSID(scanResult.SSID);
        wifi.setBSSID(scanResult.BSSID);
        wifi.setLevel(WifiManager.calculateSignalLevel(scanResult.level, 4));
        wifi.setAUTH(scanResult.capabilities.replace("[ESS]", ""));
        if (scanResult.frequency < 2405 || scanResult.frequency > 2485) {
            if (scanResult.frequency >= 2485) {
                wifi.setAUTHTYPE(5);
            } else {
                wifi.setAUTHTYPE(4);
            }
        } else {
            wifi.setAUTHTYPE(MachineUtils.getAuth(wifi));
        }
        wifi.setTIMESTAMP(System.currentTimeMillis());
        wifi.setQID(mAccUtil.getQID());

        String key = wifi.getWifiKey();
        String password = Preferences.getWifiPassword(key);
        if (!TextUtils.isEmpty(password)) {
            wifi.setPASSWORD(password);
        }
        return wifi;
    }

    private int index = 0;

    //TODO 特定机型在关闭位置权限后，收不到wifi扫描结果的广播， 需要添加超时机制
    private void startTimer(){
        index = 0;
        handler.postDelayed(myRunnable, 1000);
    }

    Runnable myRunnable = new Runnable() {
        @Override
        public void run() {
            index++;
            if(index==20){
                index=0;
                if(handler!=null){
                    handler.removeCallbacks(this);
                }
                if (wifi_view.getVisibility() == View.VISIBLE && !isFinishing()) {
                    mEmptyView.setVisibility(View.VISIBLE);
                    pb_wifi_ap.setVisibility(View.GONE);
                    tv_wifi_ap.setText(getString(R.string.camera_setting_no_wifi_ap));
                    CameraToast.show(Utils.getString(R.string.wifi_scan_fail_prompt), Toast.LENGTH_SHORT);
                    isRefresh = false;
                }
            }else{
                if(handler!=null){
                    handler.postDelayed(this, 1000);
                }
            }
        }
    };

}
