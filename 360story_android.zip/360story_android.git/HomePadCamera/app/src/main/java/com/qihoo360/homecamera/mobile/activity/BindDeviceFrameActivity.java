
package com.qihoo360.homecamera.mobile.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.widget.Toast;

import com.qihoo360.homecamera.device.config.StoryMachineConsts;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.callback.ModelSwitcherCallback;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.entity.ShareGetInfoEntity;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.ui.CameraPopupWindow;
import com.qihoo360.homecamera.mobile.ui.fragment.AddFamilyFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.BDEntryFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.BDFamilyRequestFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.BDInputChooseFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.BDInputIDFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.BDInputPhoneFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.BDSuccessFragment;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.StorageUtil;
import com.qihoo360.homecamera.mobile.utils.ToastUtil;

/**
 * 绑定设备
 * 
 * @author lvpeng-s
 */
public class BindDeviceFrameActivity extends BaseActivity implements ModelSwitcherCallback, ActionListener {
    /** 绑定类型 1=输入码 */
    public static final String TYPE_INPUT = "1";

    /** 绑定类型 2=二维码 */
    public static final String TYPE_EWM = "2";

    public static final int MODE_INPUT_CHOOSE = 1;

    public static final int MODE_INPUT_ID = 2;

    public static final int MODE_ENTRY = 0;

    public static final int MODE_SUCCESS = 3;

    public static final int MODE_FAMILY_REQUEST = 4;

    public static final int MODE_FRIEND_FIND = 5;

    public static final int MODE_FRIEND_REQUEST = 6;

    public static final int MODE_BIND_PHONE = 7;

    public static final int VALUE_CONN_ME = 1;

    public static final int VALUE_CONN_FAMILY = 2;

    public static final int VALUE_CONN_FRIEND = 3;

    private FragmentManager mFragManager;

    private int mCurrentMode = 1;

    private Fragment showFragment;

    private BDEntryFragment entryFragment;

    private BDInputChooseFragment inputChooseFragment;

    private BDInputIDFragment inputIDFragment;

    private BDSuccessFragment meSuccessFragment;

    private AddFamilyFragment addFamilyFragment;

    private BDFamilyRequestFragment mBDFamilyRequestFragment;

    private BDInputPhoneFragment mBDInputPhoneFragment;

    private String mShareCode;

    private ShareGetInfoEntity mShareGetInfoEntity;

    private String mSn;
    private String device_type;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bind_device_fram);
        mFragManager = getSupportFragmentManager();
        entryFragment = new BDEntryFragment();
        inputChooseFragment = new BDInputChooseFragment();
        inputIDFragment = new BDInputIDFragment();
        meSuccessFragment = new BDSuccessFragment();
        addFamilyFragment = new AddFamilyFragment();
        mBDFamilyRequestFragment = new BDFamilyRequestFragment();
        if (getIntent().hasExtra(StoryMachineConsts.KEY_SET_DEVICE_TYPE)){
            device_type = getIntent().getStringExtra(StoryMachineConsts.KEY_SET_DEVICE_TYPE);
        }
        mBDInputPhoneFragment = new BDInputPhoneFragment();
        GlobalManager.getInstance().getShareManager().registerActionListener(this);
        if (getIntent().hasExtra("mode")) {
            mCurrentMode = getIntent().getIntExtra("mode", 0);
            mSn = getIntent().getStringExtra("sn");
        }

        setMode(mCurrentMode);


        if (mCurrentMode == MODE_FRIEND_FIND) {
            BDEntryFragment.sConnType = BindDeviceFrameActivity.VALUE_CONN_FRIEND;
        } else {
            BDEntryFragment.sConnType = BindDeviceFrameActivity.VALUE_CONN_FAMILY;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public void onDestroy() {
        GlobalManager.getInstance().getShareManager().removeActionListener(this);
        super.onDestroy();
    }

    @Override
    public void setMode(int mode) {
        mCurrentMode = mode;
        FragmentTransaction trans = mFragManager.beginTransaction();
        switch (mCurrentMode) {
            case MODE_ENTRY:
                trans.replace(R.id.main_bind_device, entryFragment);
                showFragment = entryFragment;
                break;
            case MODE_INPUT_CHOOSE:
                trans.replace(R.id.main_bind_device, inputChooseFragment);
                showFragment = inputChooseFragment;
                break;
            case MODE_INPUT_ID:
            case MODE_FRIEND_FIND:
                trans.replace(R.id.main_bind_device, inputIDFragment);
                showFragment = inputIDFragment;
                break;
            case MODE_SUCCESS:
                trans.replace(R.id.main_bind_device, meSuccessFragment);
                showFragment = meSuccessFragment;
                break;
            case MODE_FAMILY_REQUEST:
            case MODE_FRIEND_REQUEST:
                trans.replace(R.id.main_bind_device, mBDFamilyRequestFragment);
                showFragment = mBDFamilyRequestFragment;
                break;
            case MODE_BIND_PHONE:
                if (device_type != null){
                    Bundle bundle = new Bundle();
                    bundle.putString(StoryMachineConsts.KEY_SET_DEVICE_TYPE,device_type);
                    mBDInputPhoneFragment.setArguments(bundle);
                }
                trans.replace(R.id.main_bind_device, mBDInputPhoneFragment);
                showFragment = mBDInputPhoneFragment;
                break;
        }
        trans.commitAllowingStateLoss();
    }

    public void setMode(int mode, String sn) {
        mSn = sn;
        setMode(mode);
    }

    public void setMode(int mode, String shareCode, ShareGetInfoEntity shareGetInfoEntity) {
        mShareCode = shareCode;
        mShareGetInfoEntity = shareGetInfoEntity;
        setMode(mode);
    }

    public String getmShareCode() {
        return mShareCode;
    }

    public ShareGetInfoEntity getmShareGetInfoEntity() {
        return mShareGetInfoEntity;
    }

    public void goBack() {
        if (showFragment instanceof BDEntryFragment) {
            finish();
        } else if (showFragment instanceof BDInputChooseFragment) {
            //this.setMode(MODE_ENTRY);
            finish();
        } else if (showFragment instanceof BDInputIDFragment) {
            if (BDEntryFragment.sConnType == BindDeviceFrameActivity.VALUE_CONN_FRIEND) {
                finish();
            } else {
                this.setMode(MODE_INPUT_CHOOSE);
            }
        } else if (showFragment instanceof AddFamilyFragment) {
            this.setMode(MODE_ENTRY);
        } else if (showFragment instanceof BDSuccessFragment) {
            finish();
        } else if (showFragment instanceof BDFamilyRequestFragment) {
            if (BDEntryFragment.sConnType == BindDeviceFrameActivity.VALUE_CONN_FRIEND) {
                this.setMode(MODE_FRIEND_FIND);
            } else {
                finish();
            }
        } else if (showFragment instanceof BDInputPhoneFragment) {
            finish();
        }
    }

    @Override
    public void onBackPressed() {
        goBack();
    }

    @Override
    public int getMode() {
        return mCurrentMode;
    }

    @Override
    public void toggleMode() {

    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        CLog.i("requestCode" + requestCode + ",resultCode" + resultCode);
        // 从系统相册选取照片或者摄像头拍照后，照片上传
        if (requestCode == CameraPopupWindow.CAMERA_REQUEST_CODE) {// 拍照
            if (resultCode == Activity.RESULT_OK) {
                // 检测sd是否可用
                if (!StorageUtil.externalMemoryAvailable()) {
                    ToastUtil.showToast(this, R.string.sd_card_no_exist, Toast.LENGTH_LONG);
                    return;
                }
            } else if (resultCode == Activity.RESULT_CANCELED) {

            }
            CLog.i(TAG, "this is camera : requestCode = " + requestCode + " ,resultCode = " + resultCode);
        } else if (requestCode == CameraPopupWindow.PIC_REQUEST_CODE) { // 获取系统相册
            if (resultCode == Activity.RESULT_OK) {

            } else if (resultCode == Activity.RESULT_CANCELED) {

            }
            CLog.i(TAG, "this is system picture : requestCode = " + requestCode + " ,resultCode = " + resultCode);
        }
    }

    public String getmSn() {
        return mSn;
    }

    @Override
    public Object actionPerformed(int actionCode, Object... args) {
        switch (actionCode) {
            case Actions.Share.SHARE_SHARE_SUCCESS: {
                finish();
                return Boolean.TRUE;
            }
            case Actions.Share.SHARE_SHARE_FAIL: {
                hideTipsDialog();
                return Boolean.TRUE;
            }
        }
        return null;
    }

    @Override
    public int getProperty() {
        return 0;
    }
}
