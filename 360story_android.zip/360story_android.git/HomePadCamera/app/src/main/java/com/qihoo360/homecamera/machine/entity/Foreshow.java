
package com.qihoo360.homecamera.machine.entity;

import android.text.TextUtils;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.entity.Head;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * 
 * @author changxiao-qhwl
 *
 */
public class Foreshow extends Head implements Comparable<Foreshow> {

    private static final long serialVersionUID = -1410993020411345764L;

    public String id;//预告id
    public String topicid;//谈谈id
    public String title;//直播名称
    public String description;//直播描述
    public int viewNum;//查看次数
    public int voteNum;//点钻数
    public int status;//1:预告中，2：直播中，3：直播结束
    public String start;//活动开始时间    shengli保证给标准格式 yyyy-MM-dd HH:mm:ss
    public String createTime;//预告创建时间   
    public String previewUrl;//预告图片url
    public int isNotify;
    public String sn;

    private long startLong;
    private long createTimeLong;
    private String startFormat;

    public PublicCamera fillDate(PublicCamera publicCamera) {
        if (publicCamera == null) {
            publicCamera = new PublicCamera();
        }
        publicCamera.sn = this.sn;
        publicCamera.setTopicid(this.topicid);
        publicCamera.setTitlePub(this.title);
        publicCamera.setDesc(this.description);
        publicCamera.setViewNum(this.viewNum);
        publicCamera.setVoteNum(this.voteNum);
        publicCamera.setThumbnail(this.previewUrl);
        publicCamera.foreshowType = this.status;
        publicCamera.foreshow = this;
        return publicCamera;
    }

    public long getStartTime() {
        if (startLong == 0 && !TextUtils.isEmpty(start)) {
            startLong = Utils.strToDateLong(start,"yyyy-MM-dd HH:mm:ss").getTime();
        }
        return startLong;
    }

    public long getCreateTime() {
        if (createTimeLong == 0 && !TextUtils.isEmpty(createTime)) {
            createTimeLong = Utils.strToDateLong(createTime,"yyyy-MM-dd HH:mm:ss").getTime();
        }
        return createTimeLong;
    }

    public String getStartFormatTime() {
        if(startFormat == null) {
            StringBuilder sb = new StringBuilder();
            Date date = Utils.strToDateLong(start,"yyyy-MM-dd HH:mm:ss");
            Calendar c = Calendar.getInstance();
            int nowDay = c.get(Calendar.DAY_OF_YEAR);
            int nowYear = c.get(Calendar.YEAR);
            c.setTime(date);
            int foreshowDay = c.get(Calendar.DAY_OF_YEAR);
            int foreshowYear = c.get(Calendar.YEAR);

            String formatStr = Utils.getString(R.string.date_format_md);
            SimpleDateFormat dateFormat = new SimpleDateFormat(formatStr, Locale.getDefault());
            if(nowYear == foreshowYear) {
                if(nowDay == foreshowDay) {
                    sb.append(Utils.getString(R.string.date_today_space));
                }else if(foreshowDay - nowDay == 1) {
                    sb.append(Utils.getString(R.string.date_tomorrow_space));
                }else {
                    sb.append(dateFormat.format(date)).append("  ");
                }
            }else {
                sb.append(dateFormat.format(date)).append("  ");
            }
            formatStr = Utils.getString(R.string.date_format_hm);
            dateFormat = new SimpleDateFormat(formatStr, Locale.getDefault());
            sb.append(dateFormat.format(date));
            startFormat = sb.toString();
        }
        return startFormat;
    }

    @Override
    public int compareTo(Foreshow another) {
        if (getStartTime() > another.getStartTime()) {
            return 1;
        } else {
            return -1;
        }
    }
}
