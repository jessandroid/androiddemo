package com.qihoo360.homecamera.mobile.entity;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/3/22
 * Time: 17:15
 * To change this template use File | Settings | File Templates.
 */
public class RecordStoryFile extends Head {
    String sn;
    String local;
    int errorCode;
}
