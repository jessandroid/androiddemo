package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by hyuan on 2016/9/27.
 */
public class CommandReceipt extends Head implements Parcelable {
    public String taskId;
    public int status;

    public static final Parcelable.Creator<CommandReceipt> CREATOR = new Parcelable.Creator<CommandReceipt>() {
        @Override
        public CommandReceipt createFromParcel(Parcel source) {
            return new CommandReceipt(source);
        }

        @Override
        public CommandReceipt[] newArray(int size) {
            return new CommandReceipt[size];
        }
    };

    private CommandReceipt(Parcel in) {
        taskId = in.readString();
        status = in.readInt();
    }

    @Override
    public void writeToParcel(Parcel out, int flags) {
        out.writeString(taskId);
        out.writeInt(status);
    }

    @Override
    public int describeContents() {
        return 0;
    }
}
