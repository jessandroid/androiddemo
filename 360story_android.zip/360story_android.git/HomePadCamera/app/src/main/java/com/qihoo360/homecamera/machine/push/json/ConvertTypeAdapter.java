package com.qihoo360.homecamera.machine.push.json;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.InstanceCreator;
import com.google.gson.JsonSyntaxException;
import com.google.gson.TypeAdapter;
import com.google.gson.annotations.SerializedName;
import com.google.gson.internal.$Gson$Types;
import com.google.gson.internal.ConstructorConstructor;
import com.google.gson.internal.Excluder;
import com.google.gson.internal.ObjectConstructor;
import com.google.gson.internal.Primitives;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;

/**
 * Created by renjihai on 2016/3/4.
 */
public class ConvertTypeAdapter<T> extends TypeAdapter {

    private static final Excluder excluder = Excluder.DEFAULT;
    private final Map<String, BoundField> boundFields;
    private ObjectConstructor<T> constructor;
    private static FieldNamingPolicy fieldNamingPolicy = FieldNamingPolicy.IDENTITY;

    public ConvertTypeAdapter(Gson gson, TypeToken<T> type) {
        Class<?> rawType = type.getRawType();
        boundFields = getBoundFields(gson, type, rawType);
        ConstructorConstructor constructorConstructor = new ConstructorConstructor(
                Collections.<Type, InstanceCreator<?>> emptyMap());
        constructor = constructorConstructor.get(type);
    }
    /****
     *该方法的主要作用就是让json串封装成你希望的对象，在这里是把json串
     */
    @Override
    public T read(JsonReader in) throws IOException {
        if (in.peek() == JsonToken.NULL) {
            in.nextNull();
            return null;
        }

        T instance = constructor.construct();

        try {
            in.beginObject();
            while (in.hasNext()) {
                String name = in.nextName();
                BoundField field = boundFields.get(name);
                if (field == null || !field.deserialized) {
                    in.skipValue();
                } else {
                    field.read(in, instance);
                }
            }
        } catch (IllegalStateException e) {
            throw new JsonSyntaxException(e);
        } catch (IllegalAccessException e) {
            throw new AssertionError(e);
        }
        in.endObject();
        return instance;
    }

    static abstract class BoundField {
        final String name;
        final boolean serialized;
        final boolean deserialized;
        final TypeAdapter<?> typeAdapter;

        protected BoundField(String name, TypeAdapter<?> typeAdapter, boolean serialized,
                boolean deserialized) {
            this.name = name;
            this.serialized = serialized;
            this.deserialized = deserialized;
            this.typeAdapter = typeAdapter;
        }

        abstract void write(JsonWriter writer, Object value) throws IOException,
                IllegalAccessException;

        abstract void read(JsonReader reader, Object value) throws IOException,
                IllegalAccessException;
    }

    private Map<String, BoundField> getBoundFields(Gson context, TypeToken<?> type, Class<?> raw) {
        Map<String, BoundField> result = new LinkedHashMap<String, BoundField>();
        if (raw.isInterface()) {
            return result;
        }
        Type declaredType = type.getType();
        while (raw != Object.class) {
            Field[] fields = raw.getDeclaredFields();
            for (Field field : fields) {
                boolean serialize = excludeField(field, true);
                boolean deserialize = excludeField(field, false);
                if (!serialize && !deserialize) {
                    continue;
                }
                field.setAccessible(true);
                Type fieldType = $Gson$Types.resolve(type.getType(), raw, field.getGenericType());
                BoundField boundField = createBoundField(context, field, getFieldName(field),
                        TypeToken.get(fieldType), serialize, deserialize);
                BoundField previous = result.put(boundField.name, boundField);
                if (previous != null) {
                    throw new IllegalArgumentException(declaredType
                            + " declares multiple JSON fields named " + previous.name);
                }
            }
            type = TypeToken.get($Gson$Types.resolve(type.getType(), raw,
                    raw.getGenericSuperclass()));
            raw = type.getRawType();
        }
        return result;
    }

    public boolean excludeField(Field f, boolean serialize) {
        return !excluder.excludeClass(f.getType(), serialize)
                && !excluder.excludeField(f, serialize);
    }

    private String getFieldName(Field f) {
        SerializedName serializedName = f.getAnnotation(SerializedName.class);
        return serializedName == null ? fieldNamingPolicy.translateName(f) : serializedName.value();
    }

    private BoundField createBoundField(final Gson context, final Field field, final String name,
            final TypeToken<?> fieldType, boolean serialize, boolean deserialize) {

        final boolean isPrimitive = Primitives.isPrimitive(fieldType.getRawType());
        // special casing primitives here saves ~5% on Android...
        TypeToken<?> token = fieldType;

        if (field.getAnnotation(ConvertType.class) != null) {
            ConvertType annotation = field.getAnnotation(ConvertType.class);
            token = TypeToken.get(annotation.oriType());
        }
        TypeAdapter<?> typeAdapter = context.getAdapter(token);
        return new BoundField(name, typeAdapter, serialize, deserialize) {

            @SuppressWarnings({ "unchecked", "rawtypes" })
            // the type adapter and field type always agree
            @Override
            void write(JsonWriter writer, Object value) throws IOException, IllegalAccessException {
                Object fieldValue = field.get(value);
                Type type = fieldType.getType();
                TypeAdapter<?> adapter = this.typeAdapter;
                if (field.getAnnotation(ConvertType.class) != null && fieldValue != null) {
                    ConvertType annotation = field.getAnnotation(ConvertType.class);
                    type = annotation.oriType();
                    fieldValue = context.fromJson(fieldValue.toString(), type);
                    TypeToken token = TypeToken.get(type);
                    adapter = context.getAdapter(token);
                }
                TypeAdapter t = new TypeAdapterRuntimeTypeWrapper(context, adapter, type);
                t.write(writer, fieldValue);
            }

            @Override
            void read(JsonReader reader, Object value) throws IOException, IllegalAccessException {
//                System.err.println(name);
                Object fieldValue = typeAdapter.read(reader);
                if (field.getAnnotation(ConvertType.class) != null) {
                    // ConvertType annotation =
                    // field.getAnnotation(ConvertType.class);
                    fieldValue = context.toJson(fieldValue);
                }
                if (fieldValue != null || !isPrimitive) {
                    field.set(value, fieldValue);
                }
            }
        };
    }

    @Override
    public void write(JsonWriter out, Object value) throws IOException {
        if (value == null) {
            out.nullValue();
            return;
        }

        out.beginObject();
        try {
            for (BoundField boundField : boundFields.values()) {
                if (boundField.serialized) {
                    out.name(boundField.name);
                    boundField.write(out, value);
                }
            }
        } catch (IllegalAccessException e) {
            throw new AssertionError();
        }
        out.endObject();
    }
}
