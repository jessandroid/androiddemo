
package com.qihoo360.homecamera.machine.ui.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.utils.Utils;

public class ButtonLayoutNew extends LinearLayout {

    private MultModeButtonNew button = null;
    private TextView textView = null;
    private int[] textArray;
    private int[] textColorArray;
    private int[] img_res;

    public ButtonLayoutNew(Context context, AttributeSet attrs) {
        super(context, attrs);
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.MultMode);
        int id = a.getResourceId(R.styleable.MultMode_text_array_index, 0);
        if (id != 0) {
            textArray = getResourceIds(id);
        }
        id = a.getResourceId(R.styleable.MultMode_text_color_array_index, 0);
        if (id != 0) {
            textColorArray = getResourceIds(id);
        }
        id = a.getResourceId(R.styleable.MultMode_drawable_array_index, 0);
        if (id != 0) {
            img_res = getResourceIds(id);
        }
        a.recycle();
    }

    private int[] getResourceIds(int id) {
        TypedArray ta = Utils.getContext().getResources().obtainTypedArray(id);
        int[] array = new int[ta.length()];
        for (int i = 0; i < ta.length(); i++) {
            array[i] = ta.getResourceId(i, R.string.ok);
        }
        ta.recycle();
        return array;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        initView();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        textView = null;
        button = null;
    }

    private void initView() {
        for (int i = 0; i < getChildCount(); i++) {
            View v = getChildAt(i);
            if (v instanceof TextView) {
                textView = (TextView) v;
            }
            if (v instanceof MultModeButtonNew) {
                button = (MultModeButtonNew) v;
            }
        }
    }

    @Override
    public void setEnabled(boolean enabled) {
        super.setEnabled(enabled);
        if (button == null) {
            initView();
        }
        button.setEnabled(enabled);

        if (textView != null) {
            textView.setEnabled(enabled);
        }
    }

    @Override
    public void setSelected(boolean selected) {
        super.setSelected(selected);
        if (textView != null) {
            textView.setSelected(selected);
        }
        if (button != null) {
            button.setSelected(selected);
        }
    }

    public void setMode(int mode) {
        if (mode >= 0) {
            if (button == null) {
                initView();
            }
            button.setMode(mode);
            if (textArray != null && mode < textArray.length) {
                textView.setText(textArray[mode]);
            }
            if (textColorArray != null && mode < textColorArray.length) {
                textView.setTextColor(getResources().getColorStateList(textColorArray[mode]));
            }
            if (img_res != null && mode < img_res.length) {
                setBackgroundResource(img_res[mode]);
            }
        }
    }

    public int getMode() {
        if (button == null) {
            initView();
        }
        return button.getMode();
    }
}
