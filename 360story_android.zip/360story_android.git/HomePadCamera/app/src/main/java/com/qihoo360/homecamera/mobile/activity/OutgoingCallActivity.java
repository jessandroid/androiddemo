
package com.qihoo360.homecamera.mobile.activity;

import android.app.KeyguardManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.media.AudioManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.justalk.cloud.lemon.MtcApi;
import com.justalk.cloud.lemon.MtcBuddy;
import com.justalk.cloud.lemon.MtcBuddyConstants;
import com.justalk.cloud.lemon.MtcCall;
import com.justalk.cloud.lemon.MtcCallConstants;
import com.justalk.cloud.lemon.MtcCallExt;
import com.justalk.cloud.lemon.MtcCli;
import com.justalk.cloud.lemon.MtcCliConstants;
import com.justalk.cloud.lemon.MtcConstants;
import com.justalk.cloud.lemon.MtcMdm;
import com.justalk.cloud.lemon.MtcMediaConstants;
import com.justalk.cloud.lemon.MtcUser;
import com.justalk.cloud.lemon.MtcUserConstants;
import com.justalk.cloud.zmf.Zmf;
import com.justalk.cloud.zmf.ZmfAudio;
import com.justalk.cloud.zmf.ZmfObserver;
import com.justalk.cloud.zmf.ZmfVideo;
import com.qihoo360.homecamera.machine.business.RxBus;
import com.qihoo360.homecamera.mobile.BuildConfig;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.config.Const;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.db.PadInfoWrapper;
import com.qihoo360.homecamera.mobile.db.PhoneRecordWrapper;
import com.qihoo360.homecamera.mobile.entity.DeviceInfo;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.DensityUtil;
import com.qihoo360.homecamera.mobile.utils.PhoneUtil;
import com.qihoo360.homecamera.mobile.utils.Preferences;
import com.qihoo360.homecamera.mobile.utils.QHStatAgentHelper;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.utils.VibratorUtil;
import com.qihoo360.homecamera.mobile.widget.TextViewWithFont;
import com.qihoo360.homecamera.mobile.widget.howling.HowlingWindowMgr;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.util.ArrayList;

import jp.wasabeef.glide.transformations.BlurTransformation;

/**
 * 视频呼出界面
 *
 * @author lvpeng-s
 */
public class OutgoingCallActivity extends InnerOrOutgoingBaseActivity implements OnClickListener, ZmfObserver {
    private final static boolean open_network_speed_model = true;
    private int mCurrentCallState = 0;
    private int mLastCallState = -1;
    public final static int VIDEO_CALL = 0;
    public final static int VIDEO_BECALLED = 1;
    public final static int VIDEO_CONNECTED = 2;
    public final static int AUDIO_CALL = 3;
    public final static int AUDIO_BECALLED = 4;
    public final static int AUDIO_CONNECTED = 5;

    public final static String PAD_HOWLING = "1";
    public final static String PAD_HOWLING_END = "0";

    public int mIsOutgoing = 1;
    public int mInitiativeTermed = 1;
    public long mStartCallTime = -1;
    public long mConnectedTime = -1;

    private LinearLayout outgoingcall_hangup_layout;
    private LinearLayout mSwitchToVoiceLl;

    private boolean mIsVideoCall;
    private LinearLayout mHangupLayout;
    private LinearLayout mAnswerLayout;
    private RelativeLayout mToolAreaRl;
    private TextViewWithFont mCallTimeTv;
    private TextView mAvatorTv;
    private View mChangeVideoArea;
    private boolean mIsToolOpen = true;
    private TextViewWithFont mCallStateTv;
    private int mCallSecond = 0;
    private int mToastSecond = 0;
    private Runnable mTimerRunnable;
    private Runnable mToastRunnable;
    private Runnable mDisconnectedRunnable;
    private Runnable mNetBadRunnable;
    private Runnable mNoiseRunnable;
    private Runnable mNetworkSpeedCheckRunnable;
    private boolean mCameraDirectFront = true;

    private BroadcastReceiver mCallTermedkReceiver;
    private BroadcastReceiver mCallConnectingReceiver;
    private BroadcastReceiver mCallTalkingReceiver;
    private BroadcastReceiver mCallVideoReceiveStatusChangedReceiver;
    private BroadcastReceiver mCallAlertedReceiver;
    private BroadcastReceiver mCallNetworkStatusChangedReceiver;
    private BroadcastReceiver mAccountChangeReceiver;
    private BroadcastReceiver mBatInfoReceiver;
    private BroadcastReceiver mMtcBuddyQueryLoginPropertiesOkNotification;
    private BroadcastReceiver mMtcBuddyQueryLoginPropertiesDidFailNotification;
    private BroadcastReceiver mMediaHowlingDetectedReceiver;
    private BroadcastReceiver mMediaHowlingEndReceiver;
    private BroadcastReceiver mMCallInfoReceiver;

    private SurfaceView mLocalView;
    private SurfaceView mRemoteView;
    private ViewGroup mViewMain;
    private boolean mNormalShowMode = true;
    private String mErrorMsg;
    private String mAcceptMsg;
    private boolean mIsCameraFailedShow = false;
    private int notifyId = 100;
    private NotificationManager mNotificationManager;
    private boolean mIsNotificationExist = false;
    private boolean isPreFinish = false;
    private String mTrack;
    private String mTitle;
    private String mContent;
    private boolean mCanShowNetToast = true;
    private boolean mCanShowNetToastCounting = false;
    private boolean mHasShowDisconnected = false;
    private boolean mIsDestory = false;
    private View mSnapshotSplash;
    private int mIsFromInner = 0;
    private boolean mActiveEnd = false;
    private boolean mIsOnPause = false;
    private TextView mNetworkSpeed;
    private ImageView mNetworkSpeedArray;

    KeyguardManager mKeyguardManager;
    private KeyguardManager.KeyguardLock mKeyguardLock;
    private PowerManager.WakeLock mWakeLock;
    private boolean needPlayHoldUpSound = true;
    private boolean mHasRingBack = false;

    private RelativeLayout mTopToolBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!Utils.isNetworkAvailable(this)) {
            needPlayHoldUpSound = false;
        }
        Intent intent = getIntent();
        if (intent == null || intent.getExtras() == null) {
            return;
        }

        Bundle bundle = intent.getExtras();
        mIsFromInner = bundle.getInt("from_inner", 0);
        if (mIsFromInner == 1) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        }
        mDeviceInfo = bundle.getParcelable("deviceInfo");
        CLog.justalkFile("onCreate----------->mDeviceInfo is null:" + (mDeviceInfo == null));
        if (mDeviceInfo == null) {
            mCallId = bundle.getInt("callId", -1);
            CLog.justalkFile("onCreate----------->mCallId:" + mCallId);
            Const.PHONE_CALLING_ID = mCallId;
            mCurrentCallState = bundle.getInt("from", VIDEO_CALL);
        } else {
            CLog.justalkFile("onCreate----------->mDeviceInfo.getTitle():" + mDeviceInfo.getTitle());
        }

        Constants.IS_CALLING_OR_INNER = true;
        Constants.IS_CALLING = true;
        Constants.HAS_SHOW_NOISE_HIGH = false;
        mIsRecording = false;

        initRunnable();
        initReceiver();
        registerCallingBroadcast();
        initManager();
        initView();

        if (!Utils.isNetworkAvailable(this)) {
            showCustomToast(getResources().getString(R.string.net_tips_1), Toast.LENGTH_SHORT);
            preFinish();
            return;
        }

        if (bundle.getInt("from", VIDEO_CALL) != VIDEO_BECALLED) {
            callJustalk(0);
        }
    }

    private void initView() {
        setWindow();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
        }
        mIsVideoCall = true;
        createView();
    }

    private void initManager() {
        mNotificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        mStartCallTime = System.currentTimeMillis();
        PowerManager mPowerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
        mKeyguardManager = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);

        mWakeLock = mPowerManager.newWakeLock
                (PowerManager.ACQUIRE_CAUSES_WAKEUP | PowerManager.SCREEN_DIM_WAKE_LOCK, "Tag");
        mWakeLock.acquire();
        // 初始化键盘锁
        mKeyguardLock = mKeyguardManager.newKeyguardLock("");
        // 键盘解锁
        mKeyguardLock.disableKeyguard();
    }

    @Override
    protected void initReceiver() {

        mAccountChangeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                accountChangeCloseCall();
            }
        };

        mBatInfoReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(final Context context, final Intent intent) {
                final String action = intent.getAction();
                if (Intent.ACTION_SCREEN_OFF.equals(action)) {
                    stopAlarm();
                }
            }
        };

        registerReceiver(mAccountChangeReceiver, new IntentFilter(Const.BROADCAST_ACCOUNT_CHANGE));

        IntentFilter screenFilter = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        registerReceiver(mBatInfoReceiver, screenFilter);

        Zmf.addObserver(this);
        super.initReceiver();
    }

    private void initTermToast() {
        mToastRunnable = new Runnable() {
            @Override
            public void run() {
                mToastSecond++;
                if (mToastSecond == 3) {
                    String uri = MtcUser.Mtc_UserFormUri(MtcUserConstants.EN_MTC_USER_ID_USERNAME, mDeviceInfo.getSn());
                    MtcBuddy.Mtc_BuddyQueryLoginProperties(0, uri);
                }
                if (mToastSecond == 20) {
                    if (mHasRingBack) {
                        showCustomToast(getResources().getString(R.string.tips_1), Toast.LENGTH_SHORT);
                    } else if (MtcCli.Mtc_CliGetState() == MtcCliConstants.EN_MTC_CLI_STATE_LOGINED) {
                        showCustomToast(getString(R.string.tips_87), Toast.LENGTH_SHORT);
                    }
                }
                if (mToastSecond == 60) {
                    CLog.justalkFile("initTermToast----->60s超时");
                    showCustomToast(getResources().getString(R.string.tips_2), Toast.LENGTH_SHORT);
                    preFinish();
                } else {
                    if (mTimerHandler != null) {
                        mTimerHandler.postDelayed(mToastRunnable, 1000);
                    }
                }
            }
        };
        mTimerHandler.postDelayed(mToastRunnable, 1000);
    }

    @SuppressWarnings("deprecation")
    private void showNotify(String ticker, String title, String text) {
        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(this);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, getIntent(), PendingIntent.FLAG_CANCEL_CURRENT);
        mBuilder.setSmallIcon(Utils.getNotificationIcon())
                .setTicker(ticker)
                .setContentTitle(title)
                .setContentText(text)
                .setLargeIcon(Utils.getInstance().getLargeIcon())
                .setSmallIcon(Utils.getNotificationIcon())
                .setContentIntent(pendingIntent);
        Notification mNotification = mBuilder.build();
        mNotification.icon = R.drawable.ic_launcher;
        mNotification.flags = Notification.FLAG_ONGOING_EVENT;//FLAG_ONGOING_EVENT 在顶部常驻，可以调用下面的清除方法去除  FLAG_AUTO_CANCEL  点击和清理可以去调
        mNotification.tickerText = ticker;
        mNotification.when = System.currentTimeMillis();
        mNotificationManager.notify(notifyId, mNotification);
        mIsNotificationExist = true;
    }

    public void clearNotify(int notifyId) {
        if (mIsNotificationExist) {
            mIsNotificationExist = false;
            mNotificationManager.cancel(notifyId);//删除一个特定的通知ID对应的通知
        }
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        if (mCurrentCallState != AUDIO_CONNECTED && newConfig.orientation == ActivityInfo.SCREEN_ORIENTATION_PORTRAIT) {

        } else {
            createView();
        }
        super.onConfigurationChanged(newConfig);
    }

    private void initRunnable() {
        mToolAreaDelayDismissRunnable = new Runnable() {
            @Override
            public void run() {
                showToolArea(false);
            }
        };
        mTimerRunnable = new Runnable() {
            @Override
            public void run() {
                mCallSecond++;
                if (mIsNotificationExist) {
                    mContent = getString(R.string.tips_12, PhoneUtil.formatTime(mCallSecond));
                    showNotify(mTrack, mTitle, mContent);
                }
                if (!mIsRecording) {
                    if (!isPreFinish) {
                        mCallTimeTv.setText(PhoneUtil.formatTime(mCallSecond));
                    }
                } else {
                    if (!isPreFinish) {
                        mCallTimeTv.setText(PhoneUtil.formatTime(mRecordingSecond));
                    }
                    mRecordingSecond++;
                }
                if (mTimerHandler != null) {
                    mTimerHandler.postDelayed(mTimerRunnable, 1000);
                }
            }
        };
        mVideoShotRunnable = new Runnable() {
            @Override
            public void run() {
                if (mShotFrameLayout != null) {
                    mShotFrameLayout.setVisibility(View.INVISIBLE);
                }
            }
        };
        mDisconnectedRunnable = new Runnable() {
            @Override
            public void run() {
                showCustomToast(getString(R.string.tips_15), Toast.LENGTH_SHORT);
                CLog.e("zhaojunbo", getString(R.string.tips_15));
                preFinish();
            }
        };

        mNoiseRunnable = new Runnable() {
            @Override
            public void run() {
                //showCustomToast(getString(R.string.tips_70), Toast.LENGTH_LONG);
                if (Preferences.getIsShowHowlingTips() == false){
                    CLog.e("howling", "showing toast");
                    //showHowlingDialog();
                    HowlingWindowMgr.show(OutgoingCallActivity.this, getString(R.string.tips_70));
                    Constants.HAS_SHOW_NOISE_HIGH = true;
                    Preferences.setIsShowHowlingTips(true);
               }
            }
        };

        mNetworkSpeedCheckRunnable = new Runnable() {
            @Override
            public void run() {
                String msg = "";
                if (mIsVideoCall){
                    msg = MtcCall.Mtc_CallVideoGetStatus(mCallId, MtcCallConstants.MTC_CALL_STATUS_RECV_BITRATE
                            | MtcCallConstants.MTC_CALL_STATUS_SEND_BITRATE);
                }
                else
                {
                    msg = MtcCall.Mtc_CallAudioGetStatus(mCallId, MtcCallConstants.MTC_CALL_STATUS_RECV_BITRATE
                            | MtcCallConstants.MTC_CALL_STATUS_SEND_BITRATE);
                }
                String speed = "0";
                try {
                    JSONObject json = (JSONObject) new JSONTokener(msg).nextValue();
                    speed = json.getString("MtcRecvBitRateKey") + "KB/S";
                } catch (Exception e){
                    e.printStackTrace();
                    return;
                }
                if (mNetworkSpeed != null)
                    mNetworkSpeed.setText(speed);
                mTimerHandler.postDelayed(mNetworkSpeedCheckRunnable, 5000);
                CLog.e("hyuan","Mtc_CallVideoGetStatus get:" + msg + ", mIsVideoCall:" + mIsVideoCall);
                //CLog.justalkFile("Mtc_CallVideoGetStatus get MtcRecvBitRateKey:" + speed);
            }
        };
    }

    /**
     * 处理各种通话状态
     */
    private void createView() {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setWindow();
        setFullScreen(mCurrentCallState == VIDEO_CONNECTED);
        if (mCurrentCallState == mLastCallState) {
            return;
        }
        mLastCallState = mCurrentCallState;
        switch (mCurrentCallState) {
            case VIDEO_CALL://视频呼叫未接通
                CLog.justalkFile("createView----->VIDEO_CALL");
                initVideoCallConnecting();
                mErrorMsg = getString(R.string.tips_cancel_video_invited);
                mAcceptMsg = "";//getString(R.string.tips_to_accept);
                mTrack = getString(R.string.tips_7);
                mTitle = getString(R.string.tips_7);
                mContent = getString(R.string.tips_8);
                break;
            case VIDEO_BECALLED://视频被叫未接通
                CLog.justalkFile("createView----->VIDEO_BECALLED");
                initVideoBeCalledConnecting();
                String title = "";
                if (mDeviceInfo != null) {
                    title = mDeviceInfo.getTitle();
                }
                mErrorMsg = getString(R.string.tips_decline);
                mTrack = getString(R.string.tips_9, title);
                mTitle = getString(R.string.tips_9, title);
                mContent = getString(R.string.tips_8);
                break;
            case AUDIO_CALL://音频主叫未接通
                CLog.justalkFile("createView----->AUDIO_CALL");
                initAudioCallConnecting();
                mErrorMsg = getString(R.string.tips_cancel_video_invited);
                mAcceptMsg = "";//getString(R.string.tips_to_accept);
                break;
            case AUDIO_BECALLED://音频被叫未接通
                CLog.justalkFile("createView----->AUDIO_BECALLED");
                initAudioCalledConnecting();
                mErrorMsg = getString(R.string.tips_decline);
                break;
            case AUDIO_CONNECTED://竖屏音频通话已接通
                CLog.justalkFile("createView----->AUDIO_CONNECTED");
                initAudioCallConnected();
                mErrorMsg = getString(R.string.tips_hang_up);
                mTrack = getString(R.string.tips_10);
                mTitle = getString(R.string.tips_10);
                mContent = getString(R.string.tips_12, PhoneUtil.formatTime(mCallSecond));
                break;
            case VIDEO_CONNECTED://横屏视频通话已接通
                CLog.justalkFile("createView----->VIDEO_CONNECTED");
                initVideoCallConnected();
                mErrorMsg = getString(R.string.tips_hang_up);
                mTrack = getString(R.string.tips_11);
                mTitle = getString(R.string.tips_11);
                mContent = getString(R.string.tips_12, PhoneUtil.formatTime(mCallSecond));
                break;
        }
        if (mIsNotificationExist) {
            showNotify(mTrack, mTitle, mContent);
        }
    }

    /**
     * 视频主叫(未接通)
     */
    private void initVideoCallConnecting() {
        setContentView(R.layout.outgoing_call_layout_connecting);
        initCallView(true);
        initTermToast();
        if (needPlayHoldUpSound) {
            startAlarm(false);
        }
    }

    /**
     * 视频被叫(未接通)
     */
    private void initVideoBeCalledConnecting() {
        mIsOutgoing = 0;
        setContentView(R.layout.incoming_call_layout);
        mHangupLayout = (LinearLayout) findViewById(R.id.incomingcall_hangup_layout);
        mAnswerLayout = (LinearLayout) findViewById(R.id.incomingcall_answer_layout);
        LinearLayout switchLayout = (LinearLayout) findViewById(R.id.incomingcall_switch_layout);
        Utils.ensuerSetOnclick(this, mHangupLayout, mAnswerLayout, switchLayout);
        mAvatorTv = (TextView) findViewById(R.id.incomingcall_tv_name);
        DeviceInfo deviceInfo = PadInfoWrapper.getInstance().getPadBySn(MtcCall.Mtc_CallGetPeerName(mCallId));
        CLog.justalkFile("initVideoBeCalledConnecting---------->mCallId:" + mCallId + ",GetPeerName:" + MtcCall.Mtc_CallGetPeerName(mCallId));
        if (deviceInfo != null) {
            mDeviceInfo = deviceInfo;
            mAvatorTv.setText(deviceInfo.getTitle());
            ImageView userAvatar = (ImageView) findViewById(R.id.incoming_call_view1);
            if (userAvatar != null) {
                Glide.with(Utils.getContext())
                        .load(mDeviceInfo.getAvatarUrl())
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .dontAnimate()
                        .priority(Priority.HIGH)
                        .error(R.drawable.icon_avator_empty)
                        .into(userAvatar);
            }
            ImageView avatorBg = (ImageView) findViewById(R.id.iv_avator_bg);
            if (avatorBg != null) {
                Glide.with(Utils.getContext())
                        .load(TextUtils.isEmpty(mDeviceInfo.getAvatarUrl()) ? R.drawable.icon_avator_empty : mDeviceInfo.getAvatarUrl())
                        .dontAnimate()
                        .bitmapTransform(new BlurTransformation(OutgoingCallActivity.this, 20))
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .priority(Priority.HIGH)
                        .error(R.drawable.icon_avator_empty)
                        .into(avatorBg);
            }

        } else {
            ArrayList<DeviceInfo> deviceInfoArrayList = PadInfoWrapper.getInstance().getAllPad();
            if (deviceInfoArrayList != null && deviceInfoArrayList.size() > 0) {
                CLog.justalkFile("数据库--------------------");
                for (int i = 0; i < deviceInfoArrayList.size(); i++) {
                    DeviceInfo deviceInfo1 = deviceInfoArrayList.get(i);
                    CLog.justalkFile("title:" + deviceInfo1.getTitle() + ",sn:" + deviceInfo1.getSn());
                }
                CLog.justalkFile("-------------------------");
            }
            showCustomToast("获取设备信息失败", Toast.LENGTH_SHORT);
            finish();
            return;
        }
        stopAlarm();
        if (needPlayHoldUpSound) {
            startAlarm(true);
        }
        MtcCall.Mtc_CallAlert(mCallId, 0, MtcCallConstants.EN_MTC_CALL_ALERT_RING, false);
    }

    /**
     * 视频通话(已接通)
     */
    private void initVideoCallConnected() {
        stopAlarm();
        setContentView(R.layout.outgoing_call_layout);
        outgoingcall_hangup_layout = (LinearLayout) findViewById(R.id.outgoingcall_hangup_layout);
        mSwitchToVoiceLl = (LinearLayout) findViewById(R.id.ll_switch_to_voice);
        mToolAreaRl = (RelativeLayout) findViewById(R.id.rl_tool_area);
        mTopToolBar = (RelativeLayout) findViewById(R.id.rl_back_area);
        mNetworkSpeed = (TextView) findViewById(R.id.network_speed);
        mNetworkSpeedArray = (ImageView) findViewById(R.id.network_speed_arrow);
        View mTouchView = findViewById(R.id.touch_view);
        RelativeLayout mHoldUpRl = (RelativeLayout) findViewById(R.id.rl_hold_up);
        ImageView mBackIv = (ImageView) findViewById(R.id.iv_back);
        mCallTimeTv = (TextViewWithFont) findViewById(R.id.tv_call_time);
        mRecordingIv = (ImageView) findViewById(R.id.iv_recoding);
        mRecordBtnIv = (ImageView) findViewById(R.id.iv_record_btn);
        ImageView mScreenShotIv = (ImageView) findViewById(R.id.iv_screenshot);
        ImageView mChangeCamera = (ImageView) findViewById(R.id.iv_change_camera);
        mShotFrameLayout = (FrameLayout) findViewById(R.id.frame);
        mCommonPreviewImg = (ImageView) findViewById(R.id.iv_shot);
        mChangeVideoArea = findViewById(R.id.headview_local);
        mSnapshotSplash = findViewById(R.id.snapshotSplash);
        Button checkRateBt = (Button) findViewById(R.id.bt_check_rate);
        Utils.ensureVisbility(BuildConfig.isDebug ? View.VISIBLE : View.GONE, checkRateBt);
        Utils.ensuerSetOnclick(this, mChangeCamera, mScreenShotIv, mRecordBtnIv, mTouchView, mHoldUpRl, mBackIv, mChangeVideoArea, mSwitchToVoiceLl, checkRateBt, mTopToolBar);
        mChangeVideoArea.setOnTouchListener(new TouchListener());
        if (mTimerHandler != null) {
            mTimerHandler.postDelayed(mToolAreaDelayDismissRunnable, 3000);
            resetTimeCount();
            mTimerHandler.postDelayed(mTimerRunnable, 1000);
        }
        mCurrentCallState = VIDEO_CONNECTED;
        establishJusCall();
        ZmfVideo.renderAdd(mRemoteView, MtcCall.Mtc_CallGetName(mCallId), 0, ZmfVideo.RENDER_FULL_SCREEN);
        ZmfVideo.renderRotate(mRemoteView, 0);
        //ZmfVideo.renderMirror(mRemoteView, MtcCall.Mtc_CallGetName(mCallId), ZmfVideo.MIRROR_VERTICAL);
        mTimerHandler.post(mNetworkSpeedCheckRunnable);
    }

    /**
     * 语音主叫（未接通）
     */
    private void initAudioCallConnecting() {
        if (mTimerHandler != null) {
            resetTimeCount();
        }
        setContentView(R.layout.voice_call_layout);
        initCallView(false);
        mCallStateTv.setVisibility(View.VISIBLE);
        mCallStateTv.setText("语音主叫连接中");
        mCallTimeTv.setVisibility(View.INVISIBLE);
    }

    /**
     * 语音被叫（未接通）
     */
    private void initAudioCalledConnecting() {
        if (mTimerHandler != null) {
            resetTimeCount();
        }
        setContentView(R.layout.voice_call_layout);
        initCallView(false);
        mCallStateTv.setVisibility(View.VISIBLE);
        mCallStateTv.setText("语音被叫连接中");
        mCallTimeTv.setVisibility(View.INVISIBLE);
    }

    /**
     * 语音通话中
     */
    private void initAudioCallConnected() {
        setContentView(R.layout.voice_call_layout);
        initCallView(false);
        if (mCallStateTv != null) {
            mCallStateTv.setVisibility(View.INVISIBLE);
            mCallTimeTv.setVisibility(View.VISIBLE);
        }
        mIsVideoCall = false;
        mNetworkSpeed = (TextView) findViewById(R.id.network_speed);
        mNetworkSpeedArray = (ImageView) findViewById(R.id.network_speed_arrow);
        mTimerHandler.post(mNetworkSpeedCheckRunnable);
    }

    /**
     * 界面初始化共用部分
     *
     * @param isShowVideo 是否显示视频
     */
    private void initCallView(boolean isShowVideo) {
        ImageView userAvatar = (ImageView) findViewById(R.id.incoming_call_view1);
        if (userAvatar != null) {
            Glide.with(Utils.getContext())
                    .load(mDeviceInfo.getAvatarUrl())
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .priority(Priority.HIGH)
                    .dontAnimate()
                    .error(R.drawable.icon_avator_empty)
                    .into(userAvatar);
        }
        ImageView bgCover = (ImageView) findViewById(R.id.iv_avator_bg);
        if (bgCover != null) {
            Glide.with(Utils.getContext())
                    .load(TextUtils.isEmpty(mDeviceInfo.getAvatarUrl()) ? R.drawable.icon_avator_empty : mDeviceInfo.getAvatarUrl())
                    .bitmapTransform(new BlurTransformation(OutgoingCallActivity.this, 20))
                    .dontAnimate()
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .priority(Priority.HIGH)
                    .error(R.drawable.icon_avator_empty)
                    .into(bgCover);
        }

        mCallStateTv = (TextViewWithFont) findViewById(R.id.tv_call_state);
        outgoingcall_hangup_layout = (LinearLayout) findViewById(R.id.outgoingcall_hangup_layout);
        mSwitchToVoiceLl = (LinearLayout) findViewById(R.id.ll_switch_to_voice);
        ImageView outgoingcall_iv_hangup = (ImageView) findViewById(R.id.outgoingcall_iv_hangup);
        Utils.ensuerSetOnclick(this, mSwitchToVoiceLl, outgoingcall_iv_hangup);
        mCallTimeTv = (TextViewWithFont) findViewById(R.id.tv_call_time);
        mAvatorTv = (TextView) findViewById(R.id.incomingcall_tv_name);
        DeviceInfo deviceInfo = PadInfoWrapper.getInstance().getPadBySn(MtcCall.Mtc_CallGetPeerName(mCallId));
        if (mDeviceInfo == null && deviceInfo != null) {
            mDeviceInfo = deviceInfo;
        }
        mAvatorTv.setText(mDeviceInfo.getTitle());
        mtcCallStopVideo(mCallId);
        if (isShowVideo) {
            videoCaptureStart(true);
        }
    }


    private void showToolArea(boolean flag) {
        if (mToolAreaRl != null) {
            mToolAreaRl.setVisibility(flag ? View.VISIBLE : View.GONE);
        }
        if (mTopToolBar != null && !mIsRecording){
            mTopToolBar.setVisibility(flag ? View.VISIBLE : View.GONE);
        }
//        if (mNetworkSpeed != null){
//            mNetworkSpeed.setVisibility(flag ? View.GONE : View.VISIBLE);
//            CLog.e("network", "change network show:" + mNetworkSpeed.getVisibility());
//        }
        mIsToolOpen = flag;
    }

    /**
     * 预处理挂断，3s后走finish
     */
    @Override
    protected void preFinish() {
        CLog.justalkFile("preFinish");
        if (isPreFinish) {
            return;
        }
        if (needPlayHoldUpSound) {
            PhoneUtil.playHoldUpSound();
        }
        mIsDestory = true;
        if(mDeviceInfo != null){
            PhoneRecordWrapper.getInstance(this).insertPhoneRecord(mDeviceInfo.sn, AccUtil.getInstance().getQID(), mStartCallTime, mConnectedTime, System.currentTimeMillis(), mInitiativeTermed, mIsOutgoing);
            RxBus.getInstance().send(mDeviceInfo.sn);
        }
        isPreFinish = true;
        RelativeLayout relativeLayout = (RelativeLayout) findViewById(R.id.rl_end_background);
        if (relativeLayout != null) {
            relativeLayout.setVisibility(View.VISIBLE);
        }
        if (mHangupLayout != null) {
            mHangupLayout.setEnabled(false);
        }
        if (mAnswerLayout != null) {
            mAnswerLayout.setEnabled(false);
        }
        if (outgoingcall_hangup_layout != null) {
            outgoingcall_hangup_layout.setEnabled(false);
        }
        TextView textView = (TextView) findViewById(R.id.iv_end_name);
        if (textView != null && mDeviceInfo != null) {
            textView.setText(mDeviceInfo.getTitle());
        }
        ImageView avatarIv = (ImageView) findViewById(R.id.iv_end_avator);
        if (avatarIv != null && mDeviceInfo != null) {
            Glide.with(Utils.getContext())
                    .load(mDeviceInfo.getAvatarUrl())
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .priority(Priority.HIGH)
                    .dontAnimate()
                    .error(R.drawable.icon_avator_empty)
                    .into(avatarIv);
        }
        ImageView avatarBgIv = (ImageView) findViewById(R.id.iv_avator_bg);
        if (avatarBgIv != null && mDeviceInfo != null) {
            Glide.with(Utils.getContext())
                    .load(TextUtils.isEmpty(mDeviceInfo.getAvatarUrl()) ? R.drawable.icon_avator_empty : mDeviceInfo.getAvatarUrl())
                    .bitmapTransform(new BlurTransformation(OutgoingCallActivity.this, 20))
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .priority(Priority.HIGH)
                    .dontAnimate()
                    .error(R.drawable.icon_avator_empty)
                    .into(avatarBgIv);
        }

        TextView tipsCallLengthTv = (TextView) findViewById(R.id.tv_call_time_length);
        if (mCallTimeTv != null && tipsCallLengthTv != null && !TextUtils.isEmpty(mCallTimeTv.getText().toString())) {
            tipsCallLengthTv.setText(getResources().getString(R.string.tips_call_length, mCallTimeTv.getText().toString()));
            PhoneUtil.setFlickerAnimation(tipsCallLengthTv);
        }
        if (mCallTimeTv != null && mCallTimeTv != null && !TextUtils.isEmpty(mCallTimeTv.getText().toString())) {
            mCallTimeTv.setText(getResources().getString(R.string.tips_call_length, mCallTimeTv.getText().toString()));
            PhoneUtil.setFlickerAnimation(mCallTimeTv);
        }
        mContent = getString(R.string.tips_14, PhoneUtil.formatTime(mCallSecond));
        if (mIsOnPause) {
            showNotify(mTrack, mTitle, mContent);
        }
        VibratorUtil.stopVibrate();
        closeCall();
        mTimerHandler.removeCallbacks(mTimerRunnable);
        if (mNetBadRunnable != null) {
            mTimerHandler.removeCallbacks(mNetBadRunnable);
        }
        if (mNoiseRunnable != null){
            mTimerHandler.removeCallbacks(mNoiseRunnable);
        }
        mTimerHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                finish();
            }
        }, 3000);
        HowlingWindowMgr.hide(OutgoingCallActivity.this);
    }

    @Override
    public void finish() {
        CLog.justalkFile("finish");

        ZmfVideo.captureSetScreenOrientation(0);

        if (!isPreFinish) {
            closeCall();
        }
        sendCloseBroadcast();
        clearNotify(notifyId);
        mIsDestory = true;
        Constants.IS_CALLING_OR_INNER = false;
        Constants.IS_CALLING = false;
        if (mIsRecording) {
            stopRecordDoodleVideo(mCallId);
        }
        Zmf.removeObserver(this);
        stopAlarm();
        super.finish();
    }

    @Override
    public void onDestroy() {
        clearNotify(notifyId);
        stopAlarm();
        if (mWakeLock != null) {
            mWakeLock.release();
            mWakeLock = null;
        }
        if (mKeyguardLock != null) {
            mKeyguardLock.reenableKeyguard();
        }
        HowlingWindowMgr.hide(OutgoingCallActivity.this);
        super.onDestroy();
    }

    private void unregisterAllReceiver() {
        try {
            if (mAccountChangeReceiver != null)
                unregisterReceiver(mAccountChangeReceiver);
            if (mCallTermedkReceiver != null)
                LocalBroadcastManager.getInstance(this).unregisterReceiver(mCallTermedkReceiver);
            if (mCallConnectingReceiver != null)
                LocalBroadcastManager.getInstance(this).unregisterReceiver(mCallConnectingReceiver);
            if (mCallTalkingReceiver != null)
                LocalBroadcastManager.getInstance(this).unregisterReceiver(mCallTalkingReceiver);
            if (mCallNetworkStatusChangedReceiver != null) {
                LocalBroadcastManager.getInstance(this).unregisterReceiver(mCallNetworkStatusChangedReceiver);
            }
//            if (mMtcBuddyQueryLoginPropertiesOkNotification != null)
//                LocalBroadcastManager.getInstance(this).unregisterReceiver(mMtcBuddyQueryLoginPropertiesOkNotification);
//            if (mMtcBuddyQueryLoginPropertiesDidFailNotification != null)
//                LocalBroadcastManager.getInstance(this).unregisterReceiver(mMtcBuddyQueryLoginPropertiesDidFailNotification);
            if (mMediaHowlingDetectedReceiver != null) {
                LocalBroadcastManager.getInstance(this).unregisterReceiver(mMediaHowlingDetectedReceiver);
            }
            if (mMediaHowlingEndReceiver != null) {
                LocalBroadcastManager.getInstance(this).unregisterReceiver(mMediaHowlingEndReceiver);
            }
            if (mMCallInfoReceiver != null) {
                LocalBroadcastManager.getInstance(this).unregisterReceiver(mMCallInfoReceiver);
            }
            if (mCallVideoReceiveStatusChangedReceiver != null)
                LocalBroadcastManager.getInstance(this).unregisterReceiver(mCallVideoReceiveStatusChangedReceiver);
            if (mCallAlertedReceiver != null)
                LocalBroadcastManager.getInstance(this).unregisterReceiver(mCallAlertedReceiver);
            if (mBatInfoReceiver != null) {
                unregisterReceiver(mBatInfoReceiver);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void acceptCall(final boolean isVideo) {
        setRequestedOrientation(isVideo ? ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE : ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        stopAlarm();
    }

    private void establishJusCall() {
        setCallMode();
        CLog.e("zhaojuno", "startcall");
        MtcCall.Mtc_CallHasAudio(1);

        if (mIsVideoCall) {
            mtcCallStopVideo(mCallId);
            videoCaptureStart(false);
            MtcCall.Mtc_CallHasVideo(1);
            MtcCall.Mtc_CallCameraAttach(mCallId, mCameraDirectFront ? ZmfVideo.CaptureFront() : ZmfVideo.CaptureBack());
        }
        int result = MtcCall.Mtc_CallAnswer(mCallId, 0, true, mIsVideoCall);
        QHStatAgentHelper.addCallTimeStick(QHStatAgentHelper.ACCEPT_ALERT, mCallId + "");
        if (MtcConstants.ZOK != result) {
            CLog.e("phone_call", "通话挂断" + mCallId);
            CLog.justalkFile("establishJusCall----->answer错误，主动挂断" + mCallId);
            preFinish();
            //MtcCall.Mtc_CallTerm(mCallId, MtcCallConstants.EN_MTC_CALL_TERM_STATUS_NORMAL, "{\"reason_msg\":\"" + getString(R.string.tips_decline) + "\"}");
            QHStatAgentHelper.uploadEndCallStick(mCallId + "", MtcCallConstants.EN_MTC_CALL_TERM_STATUS_ERROR_ACCEPT + "", 0 + "");
        }

    }

    @Override
    protected void audioStart() {
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... params) {
                synchronized (OutgoingCallActivity.this) {

                    int ret = ZmfAudio.outputStart(
                            MtcMdm.Mtc_MdmGetAndroidAudioOutputDevice(), 0, 0);
                    if (ret == 0) {
                        ret = ZmfAudio.inputStart(
                                MtcMdm.Mtc_MdmGetAndroidAudioInputDevice(), 0, 0,
                                MtcMdm.Mtc_MdmGetOsAec() ? ZmfAudio.AEC_ON : ZmfAudio.AEC_OFF,
                                MtcMdm.Mtc_MdmGetOsAgc() ? ZmfAudio.AGC_ON : ZmfAudio.AGC_OFF);
                    }
                    if (ret != 0) {
                        ZmfAudio.inputStopAll();
                        ZmfAudio.outputStopAll();
                        if (mAudioManager != null) {
                            if (AudioManager.MODE_NORMAL != mAudioManager.getMode()) {
                                mAudioManager.setMode(AudioManager.MODE_NORMAL);
                            }
                        }
                        ret = ZmfAudio.outputStart(
                                MtcMdm.Mtc_MdmGetAndroidAudioOutputDevice(), 0, 0);
                        if (ret == 0) {
                            ZmfAudio.inputStart(
                                    MtcMdm.Mtc_MdmGetAndroidAudioInputDevice(), 0, 0,
                                    MtcMdm.Mtc_MdmGetOsAec() ? ZmfAudio.AEC_ON : ZmfAudio.AEC_OFF,
                                    MtcMdm.Mtc_MdmGetOsAgc() ? ZmfAudio.AGC_ON : ZmfAudio.AGC_OFF);
                        } else {
                            CLog.justalkFile("audioStart----->ZmfAudio.outputStart failed");
                        }
                    }
                }
                return null;
            }
        }.execute();
    }

    private void closeCall() {

        CLog.e("phone_call", "通话挂断" + mCallId);
        CLog.justalkFile("closeCall----->mCallId:" + mCallId);
        MtcCall.Mtc_CallTerm(mCallId, mActiveEnd ? MtcCallConstants.EN_MTC_CALL_TERM_STATUS_DECLINE : MtcCallConstants.EN_MTC_CALL_TERM_STATUS_NORMAL, "{\"reason_msg\":\"" + mErrorMsg + "\"}");
        //QHStatAgentHelper.uploadEndCallStick(mCallId + "", MtcCallConstants.EN_MTC_CALL_TERM_STATUS_NORMAL + "", 0 + "");
        unregisterAllReceiver();
        stopAlarm();
      //  new Thread(new Runnable() {
      //      @Override
      //      public void run() {
                mtcCallTermed();
      //      }
      //  }).start();
    }

    private void accountChangeCloseCall() {
        CLog.justalkFile("accountChangeCloseCall----->reason_msg:EN_MTC_CALL_TRANSMISSION_PAUSE4QOS,callId:" + mCallId);
        MtcCall.Mtc_CallTerm(mCallId, Constants.TermReason.TERM_OTHER_LOGOUT, "{\"reason_msg\":\"kicked out!\"}");
        QHStatAgentHelper.uploadEndCallStick(mCallId + "", Constants.TermReason.TERM_OTHER_LOGOUT + "", 0 + "");
        finish();
    }

    protected void cancelDismissHandler() {
        if (mTimerHandler != null && mToolAreaDelayDismissRunnable != null) {// && !mIsRecording
            mTimerHandler.removeCallbacks(mToolAreaDelayDismissRunnable);
            mTimerHandler.postDelayed(mToolAreaDelayDismissRunnable, 3000);
        }
    }

    @Override
    public void onClick(View v) {
        if (isPreFinish) {
            return;
        }
        switch (v.getId()) {
            case R.id.incomingcall_answer_layout: // 接听
                mCurrentCallState = VIDEO_CONNECTED;
                acceptCall(true);
                PhoneUtil.mute(mCallId, true);
                break;
            case R.id.incomingcall_hangup_layout: // 拒绝
                showCustomToast(getResources().getString(R.string.tips_4), Toast.LENGTH_SHORT);
                CLog.justalkFile("onClick----->点击拒绝");
                mTrack = getString(R.string.tips_17);
                mTitle = getString(R.string.tips_17);
                mActiveEnd = true;
                QHStatAgentHelper.uploadEndCallStick(mCallId + "", MtcCallConstants.EN_MTC_CALL_TERM_STATUS_NORMAL + "", 0 + "");
                QHStatAgentHelper.uploadEndCallStick(mCallId + "", Constants.TermReason.TERM_USER_REFUSE + "", 0 + "");
                preFinish();
                break;
            case R.id.outgoingcall_iv_hangup:
                if (mCurrentCallState == AUDIO_CONNECTED) {
                    showCustomToast(getResources().getString(R.string.tips_5), Toast.LENGTH_SHORT);
                } else {
                    showCustomToast(getResources().getString(R.string.tips_3), Toast.LENGTH_SHORT);
                }
                mTrack = getString(R.string.tips_17);
                mTitle = getString(R.string.tips_17);
                CLog.justalkFile("onClick----->点击挂断");
                mActiveEnd = true;
                QHStatAgentHelper.addCallTimeStick(QHStatAgentHelper.END, mCallId + "");
                QHStatAgentHelper.uploadEndCallStick(mCallId + "", MtcCallConstants.EN_MTC_CALL_TERM_STATUS_NORMAL + "", 0 + "");
                QHStatAgentHelper.uploadEndCallStick(mCallId + "", Constants.TermReason.TERM_USER_HANG_UP + "", 0 + "");
                preFinish();
                break;
            case R.id.rl_hold_up://挂断
            case R.id.iv_back:
                mTrack = getString(R.string.tips_17);
                mTitle = getString(R.string.tips_17);
                showCustomToast(getResources().getString(R.string.tips_5), Toast.LENGTH_SHORT);
                CLog.justalkFile("onClick----->点击挂断");
                mActiveEnd = true;
                QHStatAgentHelper.addCallTimeStick(QHStatAgentHelper.END, mCallId + "");
                QHStatAgentHelper.uploadEndCallStick(mCallId + "", MtcCallConstants.EN_MTC_CALL_TERM_STATUS_NORMAL + "", 0 + "");
                QHStatAgentHelper.uploadEndCallStick(mCallId + "", Constants.TermReason.TERM_USER_HANG_UP + "", 0 + "");
                preFinish();
                break;

            case R.id.rl_back_area:
            case R.id.touch_view://中间触摸区域
                if (mIsToolOpen) {
                    showToolArea(false);
                } else {
                    showToolArea(true);
                }
                break;

            case R.id.ll_switch_to_voice://切换到音频按钮
                showCustomToast(getString(R.string.tips_34), Toast.LENGTH_SHORT);
                CLog.justalkFile("onClick----->主动切换到语音");
                switchToAudio();
                break;

            case R.id.iv_record_btn://点击录像
                recordVideo();
                break;

            case R.id.iv_screenshot:
                showSnapShotEffect(mSnapshotSplash);
                takeShot();
                break;

            case R.id.iv_change_camera:
                mCameraDirectFront = !mCameraDirectFront;
                ZmfVideo.renderRemoveAll(mNormalShowMode ? mLocalView : mRemoteView);
                ZmfVideo.captureStopAll();
                videoCaptureStart(false);
                MtcCall.Mtc_CallCameraAttach(mCallId, mCameraDirectFront ? ZmfVideo.CaptureFront() : ZmfVideo.CaptureBack());
                break;

            case R.id.bt_check_rate:
                showState();
                break;
            default:
                break;
        }
        cancelDismissHandler();//发生点击事件取消消失
    }

    private void changeArea() {
        ZmfVideo.renderRemoveAll(mLocalView);
        ZmfVideo.renderRemoveAll(mRemoteView);
        if (mNormalShowMode) {
            ZmfVideo.renderAdd(mRemoteView, mCameraDirectFront ? ZmfVideo.CaptureFront() : ZmfVideo.CaptureBack(), 0, ZmfVideo.RENDER_AUTO);
            ZmfVideo.renderAdd(mLocalView, MtcCall.Mtc_CallGetName(mCallId), 0, ZmfVideo.RENDER_FULL_SCREEN);
            ZmfVideo.renderRotate(mRemoteView, 270);
            ZmfVideo.renderRotate(mLocalView, 0);


        } else {
            ZmfVideo.renderAdd(mRemoteView, MtcCall.Mtc_CallGetName(mCallId), 0, ZmfVideo.RENDER_FULL_SCREEN);
            ZmfVideo.renderAdd(mLocalView, mCameraDirectFront ? ZmfVideo.CaptureFront() : ZmfVideo.CaptureBack(), 0, ZmfVideo.RENDER_AUTO);
            ZmfVideo.renderRotate(mRemoteView, 0);
            ZmfVideo.renderRotate(mLocalView, 270);

        }
        Utils.ensureVisbility(View.GONE, mLocalView, mLocalView);
        Utils.ensureVisbility(View.VISIBLE, mLocalView, mRemoteView);
        mNormalShowMode = !mNormalShowMode;
    }

    /**
     * 通知监控已关闭
     */
    private void sendCloseBroadcast() {
        CLog.e("phone_call", "发送关闭广播");
        Intent closeIntent = new Intent();
        closeIntent.setAction(Const.BROADCAST_SEND_CLOSE_BROADCAST);
        sendBroadcast(closeIntent);
    }

    private void switchToAudio() {
        QHStatAgentHelper.changeToVoice(mCallId + "");
        switch (mCurrentCallState) {
            case VIDEO_CONNECTED:
                mCurrentCallState = AUDIO_CONNECTED;
                break;
            case VIDEO_CALL:
                mCurrentCallState = AUDIO_CALL;
                break;
            case VIDEO_BECALLED:
                mCurrentCallState = AUDIO_BECALLED;
                break;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                MtcCall.Mtc_CallCameraDetach(mCallId);
                ZmfVideo.captureStopAll();
                MtcCall.Mtc_CallVideoSetSend(mCallId,
                        MtcCallConstants.EN_MTC_CALL_TRANSMISSION_CAMOFF);
            }
        }).start();
        acceptCall(false);
        createView();
    }

    private void resetTimeCount() {
        mTimerHandler.removeCallbacks(mTimerRunnable);
        mCallSecond = 0;
        mRecordingSecond = 0;
    }

    private void setFullScreen(boolean enable) {
        if (enable) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.flags |= WindowManager.LayoutParams.FLAG_FULLSCREEN;
            getWindow().setAttributes(lp);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        } else {
            WindowManager.LayoutParams attr = getWindow().getAttributes();
            attr.flags &= (~WindowManager.LayoutParams.FLAG_FULLSCREEN);
            getWindow().setAttributes(attr);
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        }
    }

    private void videoCaptureStart(final boolean isOnlyLocalFullScreen) {
        String capture = mCameraDirectFront ? ZmfVideo.CaptureFront() : ZmfVideo.CaptureBack();
        int w = 640;
        int h = 480;
        int f = 15;

        if (PhoneUtil.hasBackFacingCamera() && !PhoneUtil.hasFrontFacingCamera()) {
            capture = ZmfVideo.CaptureBack();
            mCameraDirectFront = false;
        } else if (!PhoneUtil.hasBackFacingCamera() && PhoneUtil.hasFrontFacingCamera()) {
            capture = ZmfVideo.CaptureFront();
            mCameraDirectFront = true;
        }

        ZmfVideo.captureEnableRotation(false,90);


        if (ZmfVideo.captureStart(capture, w, h, f) == -1 && !mIsCameraFailedShow) {
            mIsCameraFailedShow = true;
            showFailedDialog(getResources().getString(R.string.camera_failed));
            CLog.justalkFile("videoCaptureStart----->captureStartFailed");
        }

        createVideoViews(isOnlyLocalFullScreen);
        ZmfVideo.renderAdd(mNormalShowMode ? mLocalView : mRemoteView, capture, 0, ZmfVideo.RENDER_AUTO);
        if (!isOnlyLocalFullScreen || (mCurrentCallState == VIDEO_CALL && mIsFromInner == 1)) {
            //ZmfVideo.renderRotate(mNormalShowMode ? mLocalView : mRemoteView, 270);

            ZmfVideo.captureSetScreenOrientation(270);
        }
    }

    private void createVideoViews(boolean isOnlyLocalFullScreen) {
        if (mLocalView != null) {
            return;
        }
        Context context = getApplicationContext();
        mViewMain = (FrameLayout) findViewById(R.id.fl_background);
        if (!isOnlyLocalFullScreen) {
            // 为对端视频创建显示窗口
            mRemoteView = ZmfVideo.renderNew(context);
            mRemoteView.setLayoutParams(new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
            mViewMain.addView(mRemoteView, 0);
            // 开始对端视频显示窗口的渲染，此时尚未与对方视频数据相关联
            ZmfVideo.renderStart(mRemoteView);
        }

        // 为摄像头采集视频创建显示窗口
        mLocalView = ZmfVideo.renderNew(context);
        mLocalView.setZOrderMediaOverlay(true);
        if (!isOnlyLocalFullScreen) {
            FrameLayout.LayoutParams rlp = new FrameLayout.LayoutParams(DensityUtil.dip2px(144), DensityUtil.dip2px(90));
            rlp.leftMargin = DensityUtil.dip2px(19);
            rlp.topMargin = DensityUtil.dip2px(52);
            mLocalView.setLayoutParams(rlp);
            mViewMain.addView(mLocalView, 1);
        } else {
            FrameLayout.LayoutParams rlp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT);
            mLocalView.setLayoutParams(rlp);
            mViewMain.addView(mLocalView, 0);
        }

        // 开始摄像头采集视频窗口的渲染，此时尚未与摄像头采集数据相关联

        ZmfVideo.renderStart(mLocalView);


    }

    public void mtcCallTermed() {
        clearCallMode();
        mtcCallStopVideo(mCallId);
    }

    public synchronized void mtcCallStopVideo(int callId) {
        MtcCall.Mtc_CallCameraDetach(callId);
        ZmfVideo.captureStopAll();
        //CLog.e("phone_call", "captureStopAll");
        if (mLocalView != null) {
            ZmfVideo.renderRemoveAll(mLocalView);
            ZmfVideo.renderStop(mLocalView);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    mViewMain.removeView(mLocalView);
                    mLocalView = null;
                }
            });
        }
        if (mRemoteView != null) {
            ZmfVideo.renderRemoveAll(mRemoteView);
            ZmfVideo.renderStop(mRemoteView);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    mViewMain.removeView(mRemoteView);
                    mRemoteView = null;
                }
            });
        }
    }

    private void registerCallingBroadcast() {
        mCallTermedkReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!judgeNeedProcess(intent, mCallId)) {
                    return;
                }
                try {
                    String info = intent.getStringExtra(MtcApi.EXTRA_INFO);
                    JSONObject json = (JSONObject) new JSONTokener(info).nextValue();
                    int dwStatusCode = json.getInt(MtcCallConstants.MtcCallStatusCodeKey);
                    String state = json.optString(MtcCallConstants.MtcCallDescriptionKey);
                    switch (dwStatusCode) {
                        case Constants.TermReason.TERM_ANSWER_ERROR:
                            CLog.justalkFile("TERM_ANSWER_ERROR,callId:" + mCallId);
                            showCustomToast("机器人接听失败", Toast.LENGTH_SHORT);
                            break;
                        case Constants.TermReason.TERM_SHARE_REMOVED:
                            CLog.justalkFile("TERM_SHARE_REMOVED,callId:" + mCallId);
                            showCustomToast(getString(mCurrentCallState == VIDEO_CALL || mCurrentCallState == VIDEO_BECALLED ? R.string.net_tips_3 : R.string.net_tips_4), Toast.LENGTH_SHORT);
                            break;
                        case MtcCallConstants.EN_MTC_CALL_TERM_STATUS_USER_OFFLINE:
                            CLog.justalkFile("EN_MTC_CALL_TERM_STATUS_USER_OFFLINE,callId:" + mCallId);
                            showCustomToast(getString(R.string.net_tips_2), Toast.LENGTH_SHORT);
                            break;
                        case MtcCallConstants.EN_MTC_CALL_TERM_STATUS_TIMEOUT:
                            CLog.justalkFile("EN_MTC_CALL_TERM_STATUS_TIMEOUT,callId:" + mCallId);
                            if (!isPreFinish) {
                                mInitiativeTermed = 0;
                            }
                            break;
                        case MtcCallConstants.EN_MTC_CALL_TERM_STATUS_DECLINE:
                            if (mCurrentCallState == AUDIO_CONNECTED || mCurrentCallState == VIDEO_CONNECTED) {
                                showCustomToast(getString(R.string.tips_78), Toast.LENGTH_SHORT);
                                CLog.justalkFile("EN_MTC_CALL_TERM_STATUS_DECLINE,callId:" + mCallId);
                                QHStatAgentHelper.addCallTimeStick(QHStatAgentHelper.END, mCallId + "");
                            } else {
                                showCustomToast(getString(R.string.tips_79), Toast.LENGTH_SHORT);
                                CLog.justalkFile("EN_MTC_CALL_TERM_STATUS_DECLINE,callId:" + mCallId);
                            }
                            if (!isPreFinish) {
                                mInitiativeTermed = 0;
                            }
                            break;
                        case Constants.TermReason.TERM_NO_DISTURB:
                            showCustomToast(getString(R.string.tips_77), Toast.LENGTH_SHORT);
                            CLog.justalkFile("TERM_NO_DISTURB,callId:" + mCallId);
                            break;
                        case Constants.TermReason.TERM_NO_DISTURB_INTERRUPT:
                            showCustomToast(getString(R.string.tips_76), Toast.LENGTH_SHORT);
                            CLog.justalkFile("TERM_NO_DISTURB_INTERRUPT,callId:" + mCallId);
                            break;
                        case MtcCallConstants.EN_MTC_CALL_TERM_STATUS_BUSY:
                            showCustomToast(getString(R.string.tips_52), Toast.LENGTH_SHORT);
                            CLog.justalkFile("EN_MTC_CALL_TERM_STATUS_BUSY,callId:" + mCallId);
                            break;
                        case Constants.TermReason.TERM_UNKNOW:
                            mInitiativeTermed = 0;
                        default:
                            CLog.justalkFile("mCallTermedkReceiver----->default0， callId:" + mCallId);
                            if (state != null && !TextUtils.isEmpty(state)) {
                                JSONObject msg = new JSONObject(state);
                                String reasonMsg = msg.optString("reason_msg", "");
                                if (!TextUtils.isEmpty(reasonMsg)) {
                                    CLog.justalkFile("mCallTermedkReceiver----->reason_msg" + reasonMsg + ",callId:" + mCallId);
                                    showCustomToast(reasonMsg, Toast.LENGTH_SHORT);
                                    if (!isPreFinish) {
                                        mInitiativeTermed = 0;
                                    }
                                }
                                CLog.justalkFile("mCallTermedkReceiver----->default1， callId:" + mCallId + ",reason_msg:" + msg.optString("reason_msg", ""));
                            } else {
                                if (mCurrentCallState == AUDIO_CONNECTED || mCurrentCallState == VIDEO_CONNECTED) {
                                    if (MtcCli.Mtc_CliGetState() == MtcCliConstants.EN_MTC_CLI_STATE_LOGINED) {
                                        showCustomToast(getString(R.string.net_tips_5), Toast.LENGTH_SHORT);
                                    } else {
                                        if (!isPreFinish) {
                                            showCustomToast(getString(R.string.net_tips_1), Toast.LENGTH_SHORT);
                                        }
                                    }
                                } else {
                                    if (MtcCli.Mtc_CliGetState() == MtcCliConstants.EN_MTC_CLI_STATE_LOGINED) {
                                        showCustomToast(getString(R.string.net_tips_5), Toast.LENGTH_SHORT);
                                    } else {
                                        showCustomToast(getString(R.string.net_tips_1), Toast.LENGTH_SHORT);
                                    }
                                }
                                CLog.justalkFile("mCallTermedkReceiver----->default2， callId:" + mCallId + ",LOGINED:" + (MtcCli.Mtc_CliGetState() == MtcCliConstants.EN_MTC_CLI_STATE_LOGINED));
                                CLog.e("zhaojunbo", "对方不在线");
                            }
                            break;
                    }
                    QHStatAgentHelper.uploadEndCallStick(mCallId + "", dwStatusCode + "", 0 + "");
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    mTrack = getString(R.string.tips_13);
                    mTitle = getString(R.string.tips_13);
                    mContent = getString(R.string.tips_14, PhoneUtil.formatTime(mCallSecond));
                    preFinish();
                }
            }
        };

        mCallConnectingReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!judgeNeedProcess(intent, mCallId)) {
                    return;
                }


                //ZmfVideo.captureEnableRotation(true,1);

                MtcCallExt.Mtc_CallArsSetVideoParm(mCallId, 300000, 900000, 7, 15);
                CLog.justalkFile("mCallConnectingReceiver----->callId:" + mCallId);
                QHStatAgentHelper.addCallTimeStick(QHStatAgentHelper.CONNECTING, mCallId + "");
                mConnectedTime = System.currentTimeMillis();
                if (mToastRunnable != null && mTimerHandler != null) {
                    mTimerHandler.removeCallbacks(mToastRunnable);
                }
                if (Utils.isMoblieNetwork(Utils.getContext()) && Constants.NEED_4G_TOAST) {
                    showCustomToast("正在使用移动网络，将会产生手机流量", Toast.LENGTH_SHORT);
                }
                if (mCurrentCallState == VIDEO_CALL || mCurrentCallState == VIDEO_BECALLED) {
                    mCurrentCallState = VIDEO_CONNECTED;
                    if (mIsFromInner == 0) {
                        acceptCall(true);
                    } else {
                        createView();
                    }
                } else if (mCurrentCallState == AUDIO_CALL || mCurrentCallState == AUDIO_BECALLED || mCurrentCallState == AUDIO_CONNECTED) {
                    mCurrentCallState = AUDIO_CONNECTED;
                    createView();
                }
                ZmfVideo.captureSetScreenOrientation(270);
            }
        };

        mCallTalkingReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!judgeNeedProcess(intent, mCallId)) {
                    return;
                }
                CLog.justalkFile("mCallTalkingReceiver----->callId:" + mCallId);
                QHStatAgentHelper.addCallTimeStick(QHStatAgentHelper.TALKING, mCallId + "");
                VibratorUtil.stopVibrate();
                if (!TextUtils.isEmpty(mAcceptMsg) && !mIsDestory) {
                    showCustomToast(mAcceptMsg, Toast.LENGTH_LONG);
                }
                if (!MtcCall.Mtc_CallPeerOfferVideo(mCallId) && !mIsDestory) {
                    acceptCall(false);
                    mCurrentCallState = AUDIO_CONNECTED;
                    createView();
                    VibratorUtil.Vibrate(OutgoingCallActivity.this, 100);
                }
            }
        };

        mMtcBuddyQueryLoginPropertiesOkNotification = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                //CameraToast.show("QueryLoginOk", Toast.LENGTH_SHORT);
                try {
                    String info = intent.getStringExtra(MtcApi.EXTRA_INFO);
                    JSONObject json = (JSONObject) new JSONTokener(info).nextValue();
                    int state = json.getInt(MtcBuddyConstants.MtcBuddyStatusKey);
//                    CameraToast.show("QueryLoginOk" + state, Toast.LENGTH_SHORT);
                    switch (state) {
                        case MtcCliConstants.MTC_ACCOUNT_STATUS_ERR:
                        case MtcCliConstants.MTC_ACCOUNT_STATUS_NOT_FOUND:
                        case MtcCliConstants.MTC_ACCOUNT_STATUS_OFFLINE:
                            showCustomToast(getString(R.string.tips_87), Toast.LENGTH_SHORT);
                            preFinish();
                            break;
                        case MtcCliConstants.MTC_ACCOUNT_STATUS_PUSH:
                        case MtcCliConstants.MTC_ACCOUNT_STATUS_ONLINE:
                            break;
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };

        mMtcBuddyQueryLoginPropertiesDidFailNotification = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
//                showCustomToast(getString(R.string.tips_87), Toast.LENGTH_SHORT);
//                preFinish();
            }
        };

        mMediaHowlingDetectedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                boolean needProcess = judgeNeedProcess(intent, mCallId);
                CLog.e("howling", "phone howling call id = " + mCallId + ", toast showing = " +
                        Preferences.getIsShowHowlingTips() + ", need process=" + needProcess);
                if (!needProcess) {
                    return;
                }
               if (!Preferences.getIsShowHowlingTips() && !Constants.HAS_SHOW_NOISE_HIGH) {
                    CLog.e("howling", "wait for 3s to show toast");
                    mTimerHandler.removeCallbacks(mNoiseRunnable);
                    mTimerHandler.postDelayed(mNoiseRunnable, 3 * 1000);
                    //Constants.HAS_SHOW_NOISE_HIGH = true;
               }
            }
        };

        mMCallInfoReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                CLog.e("hyuan", "receive pad message");
                if (!judgeNeedProcess(intent, mCallId)) {
                    return;
                }
                String msg = "";
                try {
                    String info = intent.getStringExtra(MtcApi.EXTRA_INFO);
                    JSONObject json = (JSONObject) new JSONTokener(info).nextValue();
                    msg = json.getString(MtcCallConstants.MtcCallBodyKey);
                } catch (Exception e){
                    e.printStackTrace();
                    return;
                }
                CLog.e("hyuan", "receive pad message:" + msg);
                if (PAD_HOWLING.equals(msg)){
                    CLog.e("howling", "receive pad howling start message, prf:" +
                            Preferences.getIsShowHowlingTips() + ", showing:" + Constants.HAS_SHOW_NOISE_HIGH);
                   if (!Preferences.getIsShowHowlingTips() && !Constants.HAS_SHOW_NOISE_HIGH) {
                        CLog.e("howling", "wait for 3s to show toast");
                        mTimerHandler.removeCallbacks(mNoiseRunnable);
                        mTimerHandler.postDelayed(mNoiseRunnable, 3 * 1000);
                        //Constants.HAS_SHOW_NOISE_HIGH = true;
                   }
                }
                else if (PAD_HOWLING_END.equals(msg)){
                    CLog.e("howling", "receive pad howling end message, disturb toast show." +
                            Preferences.getIsShowHowlingTips() + ", showing:" + Constants.HAS_SHOW_NOISE_HIGH);
                    mTimerHandler.removeCallbacks(mNoiseRunnable);
                    Constants.HAS_SHOW_NOISE_HIGH = false;
                }
            }
        };

        mMediaHowlingEndReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                CLog.e("howling", "phone howling end, disturb toast show.");
                if (!judgeNeedProcess(intent, mCallId)) {
                    return;
                }
                mTimerHandler.removeCallbacks(mNoiseRunnable);
                Constants.HAS_SHOW_NOISE_HIGH = false;
            }
        };

        mCallVideoReceiveStatusChangedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!judgeNeedProcess(intent, mCallId)) {
                    return;
                }
                try {
                    String info = intent.getStringExtra(MtcApi.EXTRA_INFO);
                    JSONObject json = (JSONObject) new JSONTokener(info).nextValue();
                    int state = json.getInt(MtcCallConstants.MtcCallVideoStatusKey);
                    switch (state) {
                        case MtcCallConstants.EN_MTC_CALL_TRANSMISSION_CAMOFF:
                            CLog.justalkFile("mCallVideoReceiveStatusChangedReceiver----->reason_msg:EN_MTC_CALL_TRANSMISSION_CAMOFF,callId:" + mCallId);
                            showCustomToast(getString(R.string.tips_35), Toast.LENGTH_SHORT);
                            switchToAudio();
                            mHasNoVideo = true;
                            break;
                        case MtcCallConstants.EN_MTC_CALL_TRANSMISSION_PAUSE:
                            CLog.justalkFile("mCallVideoReceiveStatusChangedReceiver----->reason_msg:EN_MTC_CALL_TRANSMISSION_PAUSE,callId:" + mCallId);
                            mHasNoVideo = true;
                            break;
                        case MtcCallConstants.EN_MTC_CALL_TRANSMISSION_PAUSE4QOS:
                            CLog.justalkFile("mCallVideoReceiveStatusChangedReceiver----->reason_msg:EN_MTC_CALL_TRANSMISSION_PAUSE4QOS,callId:" + mCallId);
//                            mHasNoVideo = true;
                            break;
                        default:
                            break;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        };

        mCallAlertedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!judgeNeedProcess(intent, mCallId)) {
                    return;
                }
                QHStatAgentHelper.addCallTimeStick(QHStatAgentHelper.ACCEPT_ALERT, mCallId + "");
                mHasRingBack = true;
                CLog.e("outgoing", "电话回铃");
            }
        };

        mCallNetworkStatusChangedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!judgeNeedProcess(intent, mCallId)) {
                    return;
                }
                try {
                    String info = intent.getStringExtra(MtcApi.EXTRA_INFO);
                    JSONObject json = (JSONObject) new JSONTokener(info).nextValue();
                    int iStatus = json.getInt(MtcCallConstants.MtcCallNetworkStatusKey);
//                    switch (iStatus){
//                        case MtcCallConstants.EN_MTC_NET_STATUS_BAD:
//                        case MtcCallConstants.EN_MTC_NET_STATUS_VERY_BAD:
//                        case MtcCallConstants.EN_MTC_NET_STATUS_DISCONNECTED: {
//                            mNetworkSpeed.setTextColor(getResources().getColor(R.color.net_work_bad));
//                            mNetworkSpeedArray.setImageDrawable(getResources().getDrawable(R.drawable.arrow_network_bad));
//                            break;
//                        }
//                        case MtcCallConstants.EN_MTC_NET_STATUS_GOOD:
//                        case MtcCallConstants.EN_MTC_NET_STATUS_VERY_GOOD:{
//                            mNetworkSpeed.setTextColor(getResources().getColor(R.color.net_work_good));
//                            mNetworkSpeedArray.setImageDrawable(getResources().getDrawable(R.drawable.arrow_network_good));
//                            break;
//                        }
//                        case MtcCallConstants.EN_MTC_NET_STATUS_NORMAL: {
//                            mNetworkSpeed.setTextColor(getResources().getColor(R.color.net_work_normal));
//                            mNetworkSpeedArray.setImageDrawable(getResources().getDrawable(R.drawable.arrow_network_normal));
//                            break;
//                        }
//                    }
                    String speed = json.getString(MtcCallConstants.MtcCallReceiveCurBitRateKey) + "KB/S";
                    boolean isSend = json.getBoolean(MtcCallConstants.MtcCallIsSendKey);
                    boolean isVideo = json.getBoolean(MtcCallConstants.MtcCallIsVideoKey);
                    CLog.e("hyuan","Network state change MtcCallReceiveCurBitRateKey:" + speed + ", isSend:" +
                            isSend + ",EN_MTC_NET_STATUS:" + iStatus + ", isVideo:" + isVideo);
                    if (!isSend && isVideo == mIsVideoCall){
                        mTimerHandler.removeCallbacks(mNetworkSpeedCheckRunnable);
                        mNetworkSpeed.setText(speed);
                        // CLog.justalkFile("MTC notify network change at speed(MtcCallReceiveCurBitRateKey):" + speed);
                    }
                    mTimerHandler.postDelayed(mNetworkSpeedCheckRunnable, 5000);
                    if (iStatus == MtcCallConstants.EN_MTC_NET_STATUS_DISCONNECTED && isVideo == mIsVideoCall) {
                        if (!mHasShowDisconnected) {
                            mHasShowDisconnected = true;
                            mTimerHandler.postDelayed(mDisconnectedRunnable, 20000);
                        }
                    } else {
                        mHasShowDisconnected = false;
                        mTimerHandler.removeCallbacks(mDisconnectedRunnable);
                    }
                    if ((iStatus == MtcCallConstants.EN_MTC_NET_STATUS_VERY_BAD) && mCanShowNetToast) {
                        mCanShowNetToast = false;
                        mCanShowNetToastCounting = true;
                        if (isPreFinish) return;
                        mNetBadRunnable = new Runnable() {
                            @Override
                            public void run() {
                                mCanShowNetToastCounting = false;
                                if (mCurrentCallState != AUDIO_CONNECTED) {
                                    showCustomToast(getString(R.string.tips_16), Toast.LENGTH_SHORT);
                                } else {
                                    if (MtcCli.Mtc_CliGetState() == MtcCliConstants.EN_MTC_CLI_STATE_LOGINED) {
                                        showCustomToast("对方网络状态不佳，可能会影响通话质量", Toast.LENGTH_SHORT);
                                    } else {
                                        if (!isPreFinish) {
                                            showCustomToast("网络状态不佳，可能会影响通话质量", Toast.LENGTH_SHORT);
                                        }
                                    }
                                }
                                mTimerHandler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mCanShowNetToast = true;
                                    }
                                }, 1000 * 60 * 5);
                            }
                        };
                        mTimerHandler.postDelayed(mNetBadRunnable, 1000 * 5);
                    }
                    if (iStatus != MtcCallConstants.EN_MTC_NET_STATUS_VERY_BAD && mTimerHandler != null && mCanShowNetToastCounting) {
                        mTimerHandler.removeCallbacks(mNetBadRunnable);
                        mCanShowNetToast = true;
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };

        LocalBroadcastManager.getInstance(this).registerReceiver(mCallTermedkReceiver, new IntentFilter(MtcCallConstants.MtcCallTermedNotification));
        LocalBroadcastManager.getInstance(this).registerReceiver(mCallConnectingReceiver, new IntentFilter(MtcCallConstants.MtcCallConnectingNotification));
        LocalBroadcastManager.getInstance(this).registerReceiver(mCallTalkingReceiver, new IntentFilter(MtcCallConstants.MtcCallTalkingNotification));
        LocalBroadcastManager.getInstance(this).registerReceiver(mCallVideoReceiveStatusChangedReceiver, new IntentFilter(MtcCallConstants.MtcCallVideoReceiveStatusChangedNotification));
        LocalBroadcastManager.getInstance(this).registerReceiver(mCallAlertedReceiver, new IntentFilter(MtcCallConstants.MtcCallAlertedNotification));
        LocalBroadcastManager.getInstance(this).registerReceiver(mCallNetworkStatusChangedReceiver, new IntentFilter(MtcCallConstants.MtcCallNetworkStatusChangedNotification));
//        LocalBroadcastManager.getInstance(this).registerReceiver(mMtcBuddyQueryLoginPropertiesOkNotification, new IntentFilter(MtcBuddyConstants.MtcBuddyQueryLoginPropertiesOkNotification));
//        LocalBroadcastManager.getInstance(this).registerReceiver(mMtcBuddyQueryLoginPropertiesDidFailNotification, new IntentFilter(MtcBuddyConstants.MtcBuddyQueryLoginPropertiesDidFailNotification));
        LocalBroadcastManager.getInstance(this).registerReceiver(mMediaHowlingDetectedReceiver, new IntentFilter(MtcMediaConstants.MtcMediaHowlingDetectedNotification));
        LocalBroadcastManager.getInstance(this).registerReceiver(mMediaHowlingEndReceiver, new IntentFilter(MtcMediaConstants.MtcMediaHowlingEndNotification));
        LocalBroadcastManager.getInstance(this).registerReceiver(mMCallInfoReceiver, new IntentFilter(MtcCallConstants.MtcCallInfoReceivedNotification));
    }

    private long mLastTime;

    class TouchListener implements View.OnTouchListener {
        int lastX;
        int lastY;
        int screenWidth;
        int screenHeight;

        public TouchListener() {
            DisplayMetrics dm = getApplicationContext().getResources().getDisplayMetrics();
            screenWidth = dm.widthPixels;
            screenHeight = dm.heightPixels;
        }

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    lastX = (int) event.getRawX();
                    lastY = (int) event.getRawY();
                    mLastTime = System.currentTimeMillis();
                    break;
                case MotionEvent.ACTION_MOVE:
                    int dx = (int) event.getRawX() - lastX;
                    int dy = (int) event.getRawY() - lastY;
                    int left = v.getLeft() + dx;
                    int top = v.getTop() + dy;
                    int right = v.getRight() + dx;
                    int bottom = v.getBottom() + dy;
                    // set bound
                    if (left < 0) {
                        left = 0;
                        right = left + v.getWidth();
                    }
                    if (right > screenWidth) {
                        right = screenWidth;
                        left = right - v.getWidth();
                    }
                    if (top < 0) {
                        top = 0;
                        bottom = top + v.getHeight();
                    }
                    if (bottom > screenHeight) {
                        bottom = screenHeight;
                        top = bottom - v.getHeight();
                    }
                    v.layout(left, top, right, bottom);

                    lastX = (int) event.getRawX();
                    lastY = (int) event.getRawY();

                    FrameLayout.LayoutParams rlp = new FrameLayout.LayoutParams(DensityUtil.dip2px(144), DensityUtil.dip2px(90));
                    rlp.leftMargin = left;
                    rlp.topMargin = top;
                    RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) mChangeVideoArea.getLayoutParams();
                    layoutParams.leftMargin = left;
                    layoutParams.topMargin = top;
                    mChangeVideoArea.setLayoutParams(layoutParams);
                    mLocalView.setLayoutParams(rlp);
                    lastX = (int) event.getRawX();
                    lastY = (int) event.getRawY();
                    break;
                case MotionEvent.ACTION_UP:
                    if (System.currentTimeMillis() - mLastTime <= 100) {
                        changeArea();
                    }
                    break;
            }
            return true;
        }
    }

    @Override
    protected void changeTo3G() {
        if (Constants.NEED_4G_TOAST) {
            showCustomToast(getString(R.string.tips_36), Toast.LENGTH_SHORT);
        }
    }

    @Override
    protected void wifiDisconnect() {
//        if (!isPreFinish) {
//            showCustomToast("网络状况不佳，通话即将结束", Toast.LENGTH_SHORT);
//        }
//        preFinish();
    }

    @Override
    protected void onPause() {
        mIsOnPause = true;
        showNotify(mTrack, mTitle, mContent);
        super.onPause();
    }

    @Override
    protected void onResume() {
        mIsOnPause = false;
        clearNotify(notifyId);
        if (mCurrentCallState == VIDEO_CONNECTED){
            MtcCall.Mtc_CallCameraAttach(mCallId, mCameraDirectFront ? ZmfVideo.CaptureFront() : ZmfVideo.CaptureBack());
        }
        super.onResume();
    }

    @Override
    public void onLowMemory() {
        CLog.justalkFile("onLowMemory");
        Constants.IS_CALLING_OR_INNER = false;
        Constants.IS_CALLING = false;
        closeCall();
        sendCloseBroadcast();
        finish();
        super.onLowMemory();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        int type = (mCurrentCallState == VIDEO_CONNECTED || mCurrentCallState == AUDIO_CONNECTED) ? getStreamType() : AudioManager.STREAM_RING;
        float volumn = (float) mAudioManager.getStreamVolume(AudioManager.STREAM_RING) / (float) mAudioManager.getStreamMaxVolume(AudioManager.STREAM_RING);
        switch (keyCode) {
            case KeyEvent.KEYCODE_VOLUME_DOWN:
                if (mAudioManager.getStreamVolume(type) > 1) {
                    mAudioManager.adjustStreamVolume(type, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI);
                }
                if (volumn - 0.1 > 0) {
                    volumn -= 0.1;
                }
                break;
            case KeyEvent.KEYCODE_VOLUME_UP:
                mAudioManager.adjustStreamVolume(type, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI);
                if (volumn + 0.1 < 1) {
                    volumn += 0.1;
                }
                break;
            case KeyEvent.KEYCODE_VOLUME_MUTE:
                mAudioManager.setStreamVolume(type, 0, AudioManager.FLAG_SHOW_UI);
                if (volumn - 0.1 > 0) {
                    volumn = 0;
                }
                break;
        }
        if (mMediaPlayer != null) {
            mMediaPlayer.setVolume(volumn, volumn);
        }
        return true;
    }

    @Override
    public void handleNotification(int arg0, JSONObject arg1) {
        switch (arg0) {
            case Zmf.VideoErrorOccurred: {
                if (mCurrentCallState == VIDEO_CONNECTED && !isPreFinish) {
                    mIsCameraFailedShow = true;
                    showFailedDialog(getResources().getString(R.string.camera_failed));
                }
                break;
            }
            case Zmf.AudioErrorOccurred: {
                ZmfAudio.inputStopAll();
                ZmfAudio.outputStopAll();
                audioStart();
                break;
            }
        }

    }

    @Override
    public void onBackPressed() {
        HowlingWindowMgr.hide(OutgoingCallActivity.this);
    }


}
