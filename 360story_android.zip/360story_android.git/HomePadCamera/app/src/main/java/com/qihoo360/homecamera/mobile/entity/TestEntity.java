package com.qihoo360.homecamera.mobile.entity;

import java.util.HashMap;

/**
 * Created by zhaojunbo on 2016/3/3.
 * desc:
 */
public class TestEntity {

    private HashMap<String,Integer> data;
    private String title;
    private int defaultType;
    private CharSequence[] streamItems;
    private int newType;

    public TestEntity(HashMap<String,Integer> data, String title, int defaultType, CharSequence[] streamItems) {
        this.data = data;
        this.title = title;
        this.defaultType = defaultType;
        this.streamItems = streamItems;
        newType = defaultType;
    }

    public HashMap<String, Integer> getData() {
        return data;
    }

    public String getTitle() {
        return title;
    }

    public int getDefaultType() {
        return defaultType;
    }

    public CharSequence[] getStreamItems() {
        return streamItems;
    }

    public void setNewType(int newType) {
        this.newType = newType;
    }

    public int getNewType() {
        return newType;
    }
}
