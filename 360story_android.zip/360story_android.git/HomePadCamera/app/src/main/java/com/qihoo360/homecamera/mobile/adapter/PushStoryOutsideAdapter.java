package com.qihoo360.homecamera.mobile.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.entity.Story;
import com.qihoo360.homecamera.mobile.entity.StoryList;
import com.qihoo360.homecamera.mobile.widget.PagerTabStrip.PushStoryDetailActivity;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhaojunbo on 2016/3/18.
 * desc:
 */
public class PushStoryOutsideAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private Context mContext;
    private static final int TYPE_HEADER = 0;
    private static final int TYPE_TITLE = 1;
    private static final int TYPE_ITEM = 2;
    private static final int TYPE_FOOTER = 3;
    private List<Story> mStoryListAll;

    public PushStoryOutsideAdapter(Context context) {
        mContext = context;
        mStoryListAll = new ArrayList<Story>();
    }

    public void setData(List<StoryList> storyLists) {
        mStoryListAll.clear();
        if (storyLists != null) {
            for (int i = 0;i < storyLists.size();i++) {
                StoryList storyList = storyLists.get(i);
                if (storyList != null) {
//                    mStoryListAll.add(new Story(storyList.title, storyList.linkUrl, storyList.cateInfo));
                    mStoryListAll.addAll(storyList.data);
                }
            }
        }

        notifyDataSetChanged();
    }

    public void setDetailData(List<Story> storyLists) {
        mStoryListAll.clear();
        mStoryListAll.addAll(storyLists);
        notifyDataSetChanged();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == TYPE_ITEM) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_push_story_content, parent, false);
            return new ViewHolderItem(view);
        } else if (viewType == TYPE_TITLE) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_push_story_head, parent, false);
            return new ViewHolderTitle(view);
        } else {
            return null;
        }
    }

    @Override
    public int getItemViewType(int position) {
        if (mStoryListAll != null && mStoryListAll.get(position) != null && !TextUtils.isEmpty(mStoryListAll.get(position).id)) {
            return TYPE_ITEM;
        } else {
            return TYPE_TITLE;
        }
    }

    @Override
    public int getItemCount() {
        if (mStoryListAll != null) {
            return mStoryListAll.size();
        } else {
            return 0;
        }

    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof ViewHolderTitle) {
            ViewHolderTitle viewHolderHead = (ViewHolderTitle) holder;
            viewHolderHead.mHeadTitleTv.setText(mStoryListAll.get(position).name);
            final ArrayList<String> category_ids = mStoryListAll.get(position).cateInfo;
            final String linkUrl = mStoryListAll.get(position).linkUrl;
            viewHolderHead.mHeadView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(mContext, PushStoryDetailActivity.class);
                    intent.putExtra("linkUrl", linkUrl);
                    intent.putStringArrayListExtra("tabs", category_ids);
                    mContext.startActivity(intent);
                }
            });
        } else {
            ViewHolderItem viewHolderItem = (ViewHolderItem) holder;
            viewHolderItem.mStoryTitleIv.setText(mStoryListAll.get(position).name);
            viewHolderItem.mStoryTimeTv.setText(mStoryListAll.get(position).duration);
            Glide.with(mContext)
                    .load(mStoryListAll.get(position).cover_url)
                    .placeholder(R.drawable.ic_launcher)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .error(R.drawable.ic_launcher)
                    .into(viewHolderItem.mStoryCoverIv);
            viewHolderItem.mDottedLine.setVisibility(position + 1 >= mStoryListAll.size()
                    || TextUtils.isEmpty(mStoryListAll.get(position + 1).id) ? View.INVISIBLE : View.VISIBLE);
        }
    }

    public class ViewHolderTitle extends RecyclerView.ViewHolder {
        public final View mHeadView;
        public TextView mHeadTitleTv;

        public ViewHolderTitle(View view) {
            super(view);
            mHeadView = view.findViewById(R.id.rl_head_view);
            mHeadTitleTv = (TextView) view.findViewById(R.id.tv_head_title);
        }

    }

    public class ViewHolderItem extends RecyclerView.ViewHolder {
        public ImageView mStoryCoverIv;
        public TextView mStoryTitleIv;
        public TextView mStoryTimeTv;
        public TextView StoryBtnTv;
        public View mDottedLine;

        public ViewHolderItem(View view) {
            super(view);
            mStoryCoverIv = (ImageView) view.findViewById(R.id.iv_story_cover);
            mStoryTitleIv = (TextView) view.findViewById(R.id.tv_story_title);
            mStoryTimeTv = (TextView) view.findViewById(R.id.tv_story_time);
            StoryBtnTv = (TextView) view.findViewById(R.id.tv_story_btn);
            mDottedLine = view.findViewById(R.id.dotted_line);
        }

    }
}
