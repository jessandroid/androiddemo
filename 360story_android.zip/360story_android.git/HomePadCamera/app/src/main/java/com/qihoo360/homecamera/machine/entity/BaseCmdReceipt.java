package com.qihoo360.homecamera.machine.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by zhangtao-iri on 2016/12/20.
 */
public class BaseCmdReceipt implements Parcelable{

    public String taskid;
    public int resultCode;
    public String result;


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.taskid);
        dest.writeInt(this.resultCode);
        dest.writeString(this.result);
    }

    public BaseCmdReceipt() {
    }

    protected BaseCmdReceipt(Parcel in) {
        this.taskid = in.readString();
        this.resultCode = in.readInt();
        this.result = in.readString();
    }

}
