package com.qihoo360.homecamera.machine.push.business;

import android.text.TextUtils;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.qihoo360.homecamera.machine.push.json.ConvertType;
import com.qihoo360.homecamera.machine.push.json.ConvertTypeAdapterFactory;

/**
 * push 业务数据
 * @author zhangtao
 *
 */
public class BusinessBean {
	/**
	 * 对应push.PushConsts.Type中的常量
	 */
	private int type;

	/**
	 * push时间戳
	 */
    private String time;

    private String message;

    /**
     * 指定业务数据
     * @ConvertType 使json解析时,data转为字符串
     */
    @ConvertType(oriType = JsonObject.class)
    private String data;

    public void setType(int type){
        this.type = type;
    }
    public int getType(){
        return this.type;
    }
    public void setTime(String time){
        this.time = time;
    }
    public String getTime(){
        return this.time;
    }
    public void setMessage(String message){
        this.message = message;
    }
    public String getMessage(){
        return this.message;
    }
    public void setData(String data){
        this.data = data;
    }
    public String getData(){
        return this.data;
    }
    
    /**
     * @param tClass 具体业务需要获取的data字段的类
     * @param <T>    具体业务需要获取的data字段的类结构
     * @return 具体业务需要获取的data字段的类的实例
     */
    public <T> T getData(Class<T> tClass) {
        if (TextUtils.isEmpty(data)) {
            return null;
        }
        T object = null;
        try {
            Gson gson = new GsonBuilder().registerTypeAdapterFactory(new ConvertTypeAdapterFactory(tClass)).create();
            object = gson.fromJson(data, tClass);
        } catch (JsonSyntaxException e) {
            e.printStackTrace();
        }
        return object;
    }
}
