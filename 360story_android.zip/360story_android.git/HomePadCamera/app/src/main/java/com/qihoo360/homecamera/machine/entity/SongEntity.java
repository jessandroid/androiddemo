package com.qihoo360.homecamera.machine.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by zhangtao-iri on 2016/12/19.
 */
public class SongEntity implements Parcelable{

    public String uniqueid;  //id
    public String title;     //名称
    public String mediaurl;  //下载地址
    public int type;         //所在类型
    public String src;       //来源名称
    public String srclogo;   //来源log
    public String volume;    //

    public int page;//本地使用，用于区分在哪个页
    public boolean isFavor;//本地使用，是否收藏

    public boolean isFavor() {
        return isFavor;
    }

    public void setFavor(boolean favor) {
        isFavor = favor;
    }

    public String getSrclogo() {
        return srclogo;
    }

    public void setSrclogo(String srclogo) {
        this.srclogo = srclogo;
    }

    public String getUniqueid() {
        return uniqueid;
    }

    public void setUniqueid(String uniqueid) {
        this.uniqueid = uniqueid;
    }

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMediaurl() {
        return mediaurl;
    }

    public void setMediaurl(String mediaurl) {
        this.mediaurl = mediaurl;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public String getVolume() {
        return volume;
    }

    public void setVolume(String volume) {
        this.volume = volume;
    }

    public SongEntity() {
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.uniqueid);
        dest.writeString(this.title);
        dest.writeString(this.mediaurl);
        dest.writeInt(this.type);
        dest.writeString(this.src);
        dest.writeString(this.srclogo);
        dest.writeString(this.volume);
        dest.writeInt(this.page);
        dest.writeByte(this.isFavor ? (byte) 1 : (byte) 0);
    }

    protected SongEntity(Parcel in) {
        this.uniqueid = in.readString();
        this.title = in.readString();
        this.mediaurl = in.readString();
        this.type = in.readInt();
        this.src = in.readString();
        this.srclogo = in.readString();
        this.volume = in.readString();
        this.page = in.readInt();
        this.isFavor = in.readByte() != 0;
    }

    public static final Creator<SongEntity> CREATOR = new Creator<SongEntity>() {
        @Override
        public SongEntity createFromParcel(Parcel source) {
            return new SongEntity(source);
        }

        @Override
        public SongEntity[] newArray(int size) {
            return new SongEntity[size];
        }
    };
}
