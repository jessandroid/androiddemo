
package com.qihoo360.homecamera.mobile.core.manager.workpool;

/**
 * Used with {@link NamedThreadPool}, represents a piece of job to be done with the pool.
 * 
 */
public abstract class AsyncJob implements Runnable {
    protected Object[] args;

    public AsyncJob() {

    }

    public AsyncJob(Object... args) {
        this.args = args;
    }

    /**
     * Do not call this, call asyncRun
     */
    @Override
    public void run() {
        try {
            asyncRun(args);
        } catch (Throwable e) {
            e.printStackTrace();
        }
        jobDone(args);
    }

    /**
     * If you want any callback to be called after job is done, put it here.
     */
    public void jobDone(Object[] args) {
    }

    public abstract void asyncRun(Object[] args);
}
