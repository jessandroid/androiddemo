
package com.qihoo360.homecamera.mobile.db;

import android.database.sqlite.SQLiteDatabase;

import java.util.Observable;

public abstract class AbstractWrapper extends Observable{
	/**
	 * 创建数据库
	 *
	 * @param db
	 */
	public abstract void onCreate(SQLiteDatabase db);

	/**
	 * 更新数据库
	 *
	 * @param db
	 * @param toVersion
	 */
	public abstract void onUpgrade(SQLiteDatabase db, int toVersion);


	public abstract void onOpen(SQLiteDatabase db);

	/**
	 * 执行sql
	 *
	 * @param db
	 * @param sql
	 */
	public void execSQL(SQLiteDatabase db, String sql) {
		db.execSQL(sql);
	}

	/**
	 * 执行sql
	 *
	 * @param db
	 * @param sql
	 * @param bindArgs
	 */
	public void execSQL(SQLiteDatabase db, String sql, String[] bindArgs) {
		if (bindArgs != null && bindArgs.length > 0) {
			db.execSQL(sql, bindArgs);
		}
	}

	/**
	 * 删除数据库表
	 *
	 * @param db
	 * @param tableName
	 */
	public void dropTable(SQLiteDatabase db, String tableName) {
		StringBuilder sb = new StringBuilder();
		sb.append("DROP TABLE IF EXISTS ").append(tableName).append(";");
		execSQL(db, sb.toString());
	}

	/**
	 * 重命名table
	 * @param db
	 * @param tableName
	 * @param newTableName
	 */
	public void renameTable(SQLiteDatabase db, String tableName,
							String newTableName) {
		StringBuilder sb = new StringBuilder();
		sb.append("ALTER TABLE")
				.append(tableName)
				.append("RENAME TO ")
				.append(newTableName).append(";");
		execSQL(db, sb.toString());
	}



}
