
package com.qihoo360.homecamera.mobile.http.builder;

import com.qihoo360.homecamera.mobile.config.DefaultClientConfig;
import com.qihoo360.homecamera.mobile.http.request.PostFileRequest;
import com.qihoo360.homecamera.mobile.http.request.RequestCall;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.io.File;
import java.util.LinkedHashMap;
import java.util.Map;

import okhttp3.MediaType;

/**
 * Created by zhy on 15/12/14.
 */
public class PostFileBuilder extends OkHttpRequestBuilder {
    private File file;
    private MediaType mediaType;
    private String upUrl;

    public OkHttpRequestBuilder file(File file) {
        this.file = file;
        return this;
    }

    public OkHttpRequestBuilder mediaType(MediaType mediaType) {
        this.mediaType = mediaType;
        return this;
    }

    @Override
    public RequestCall build() {
        return new PostFileRequest(url, tag, params, headers, file, mediaType).build();
    }

    @Override
    public OkHttpRequestBuilder isDebug(boolean debug) {
        this.debug = debug;
        return this;
    }

    @Override
    public OkHttpRequestBuilder isHttps(boolean https) {
        this.https = https;
        return this;
    }

    @Override
    public OkHttpRequestBuilder isLogUpload(String up) {
        this.upUrl = up;
        return this;
    }

    @Override
    public PostFileBuilder url(String url) {
        if (isStatic) {
            this.url = url;
        }else {
            this.url = Utils.getUrl(url,this.https);
        }
        return this;
    }

    @Override
    public OkHttpRequestBuilder isStatic(boolean isStatic) {
        this.isStatic = isStatic;
        return this;
    }

    @Override
    public PostFileBuilder tag(Object tag) {
        this.tag = tag;
        return this;
    }

    @Override
    public PostFileBuilder params(Map<String, String> params) {
        this.params = params;
        return this;
    }

    @Override
    public PostFileBuilder addParams(String key, String val) {
        if (this.params == null) {
            params = new LinkedHashMap<String, String>();
        }
        params.put(key, val);
        return this;
    }

    @Override
    public PostFileBuilder headers(Map<String, String> headers) {
        if (debug) {
            this.headers = headers;
            headers.put("hosts", DefaultClientConfig.HOST);
        }
        return this;
    }

    @Override
    public PostFileBuilder addHeader(String key, String val) {
        if (this.headers == null) {
            headers = new LinkedHashMap<String, String>();
        }
        headers.put(key, val);
        return this;
    }
}
