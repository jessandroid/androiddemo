
package com.qihoo360.homecamera.mobile.http.builder;

import com.qihoo360.homecamera.machine.config.MachineDebugConfig;
import com.qihoo360.homecamera.machine.config.MachineDefaultClientConfig;
import com.qihoo360.homecamera.mobile.BuildConfig;
import com.qihoo360.homecamera.mobile.config.DefaultClientConfig;
import com.qihoo360.homecamera.mobile.http.request.PostFormRequest;
import com.qihoo360.homecamera.mobile.http.request.RequestCall;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.io.File;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


public class MachinePostFormBuilder extends PostFormBuilder {

//    @Override
//    protected String getSessionId() {
//        return AccUtil.getInstance().getMachineSessionId();// 故事机与其他设备公用sessionId
//    }

    @Override
    protected String getHost() {
        return MachineDefaultClientConfig.HOST;
    }

    @Override
    public RequestCall build() {
        if(MachineDebugConfig.DEBUG) {
            return super.build();
        } else {
            return new RequestCall(null) {
                @Override
                public String execute() {
                    return "";
                }
            };
        }
    }

    @Override
    public PostFormBuilder url(String url) {
        if (isStatic) {
            this.url = url;
        } else {
            this.url = url.startsWith("http") || url.startsWith("https") ? url : getUrl(url, this.https);
        }
        return this;
    }

    public static String getUrl(String f, boolean https) {
        StringBuffer stringBuffer = new StringBuffer();
        if ((f.startsWith("https") || f.startsWith("http"))) {

        } else {
            if (https) {
                stringBuffer.append(MachineDefaultClientConfig.APP_SERVER_DOMAIN);
            } else {
                stringBuffer.append(MachineDefaultClientConfig.APP_SERVER_DOMAIN_HTTP);
            }
        }
        stringBuffer.append(f);
        CLog.d("the url is :" + stringBuffer.toString());
        return stringBuffer.toString();
    }
}
