package com.qihoo360.homecamera.machine.push.json;

import com.google.gson.Gson;
import com.google.gson.TypeAdapter;
import com.google.gson.TypeAdapterFactory;
import com.google.gson.reflect.TypeToken;

/**
 * Created by renjihai on 2016/3/4.
 */
public class ConvertTypeAdapterFactory implements TypeAdapterFactory {
    public Class tClass = null;

    public ConvertTypeAdapterFactory(Class<?> tClass) {
        this.tClass = tClass;
    }

    @Override
    public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> typeToken) {
        Class<? super T> rawType = typeToken.getRawType();
        return rawType == tClass ? (TypeAdapter<T>) new ConvertTypeAdapter(gson, typeToken) : null;
    }
}
