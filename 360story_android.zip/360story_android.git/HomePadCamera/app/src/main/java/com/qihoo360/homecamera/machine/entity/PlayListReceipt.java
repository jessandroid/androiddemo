package com.qihoo360.homecamera.machine.entity;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

/**
 * 故事机正在播放的儿歌列表
 * Created by zhangchao-pd on 2016/11/18.
 */
public class PlayListReceipt extends BaseCmdReceipt implements Parcelable{

    private String name;    //专辑名称
    private String unique;  //专辑唯一标示
    private String coverurl;//专辑封面
    private int total;      //

    private ArrayList<SongEntity> mediaList;//儿歌列表

    private int type;//列表类型

    private String md5;

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getMd5() {
        return md5;
    }

    public void setMd5(String md5) {
        this.md5 = md5;
    }


    public ArrayList<SongEntity> getMediaList() {
        return mediaList;
    }

    public void setMediaList(ArrayList<SongEntity> mediaList) {
        this.mediaList = mediaList;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public String getCoverurl() {
        return coverurl;
    }

    public void setCoverurl(String coverurl) {
        this.coverurl = coverurl;
    }

    public String getUnique() {
        return unique;
    }

    public void setUnique(String unique) {
        this.unique = unique;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public PlayListReceipt() {
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeString(this.name);
        dest.writeString(this.unique);
        dest.writeString(this.coverurl);
        dest.writeInt(this.total);
        dest.writeTypedList(this.mediaList);
        dest.writeInt(this.type);
        dest.writeString(this.md5);
    }

    protected PlayListReceipt(Parcel in) {
        super(in);
        this.name = in.readString();
        this.unique = in.readString();
        this.coverurl = in.readString();
        this.total = in.readInt();
        this.mediaList = in.createTypedArrayList(SongEntity.CREATOR);
        this.type = in.readInt();
        this.md5 = in.readString();
    }

    public static final Creator<PlayListReceipt> CREATOR = new Creator<PlayListReceipt>() {
        @Override
        public PlayListReceipt createFromParcel(Parcel source) {
            return new PlayListReceipt(source);
        }

        @Override
        public PlayListReceipt[] newArray(int size) {
            return new PlayListReceipt[size];
        }
    };
}
