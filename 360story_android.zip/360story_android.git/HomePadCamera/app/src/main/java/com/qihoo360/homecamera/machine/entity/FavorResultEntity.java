package com.qihoo360.homecamera.machine.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by zhangtao-iri on 2016/12/28.
 */
public class FavorResultEntity extends BaseCmdReceipt implements Parcelable{

    private String operation;

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeString(this.operation);
    }

    public FavorResultEntity() {
    }

    protected FavorResultEntity(Parcel in) {
        super(in);
        this.operation = in.readString();
    }

    public static final Creator<FavorResultEntity> CREATOR = new Creator<FavorResultEntity>() {
        @Override
        public FavorResultEntity createFromParcel(Parcel source) {
            return new FavorResultEntity(source);
        }

        @Override
        public FavorResultEntity[] newArray(int size) {
            return new FavorResultEntity[size];
        }
    };
}
