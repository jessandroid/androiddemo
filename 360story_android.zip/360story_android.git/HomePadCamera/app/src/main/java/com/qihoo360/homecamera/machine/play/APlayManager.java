
package com.qihoo360.homecamera.machine.play;

import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;

import com.qihoo.jia.play.jnibase.JPlayer;
import com.qihoo.jia.play.oper.GL2VideoView;
import com.qihoo360.homecamera.machine.net.CameraHttpApi;
import com.qihoo360.homecamera.machine.preferences.Preferences;
import com.qihoo360.homecamera.machine.ui.widget.ButtonLayoutNew;
import com.qihoo360.homecamera.mobile.BuildConfig;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.config.Const;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionPublisherWithThreadPoolBase;
import com.qihoo360.homecamera.mobile.core.manager.workpool.PoolThreadFactory;
import com.qihoo360.homecamera.mobile.entity.MediaFiles;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.FileUtil;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.Executors;

/**
 * Created by wangdan-qhwl on 2015/12/14.
 */
public abstract class APlayManager extends ActionPublisherWithThreadPoolBase {
    // region Define

    // 播放业务类型
    public enum PlayTypes {
        RealMine, RealShare, RealDemo, RealLive, RealSD, RecordCloud, RecordLive, DownloadCloud
    }

    // 初始化状态
    public enum InitStatus {
        Initializing, InitSucceed, InitFailed
    }

    // 播放器播放状态
    public enum PlayStatus {
        Unknown, JPlayerFailed, MasterConnecting, CameraOffline, SoftSwitchOff, MasterFailed, PlayerConnecting, PlayerWaiting, PlayerFailed, PlaybackOver, Playing, Buffering, Stopping, Stopped
    }

    // 截图来源
    public enum SnapShotTypes {
        None, Normal, Magic, LiveShare, ChatShare, CheckShine, Stop, Draw
    }

    // 操作指令
    public enum PlayerCmd {
        SnapShot, Quality, Record
    }

    // 清晰度定义
    public class ResoDefine {
        public static final int RESO_HD = 0; // 1280 * 720
        public static final int RESO_VGA = 1; // 640 * 360
        public static final int RESO_MID = 3; // 640 * 360
    }

    // 播放器日志
    private static final String JPLAYER_LOG_NAME = "player.log";

    // 播放器
    private static APlayManager mCurrentManger;
    protected static InitStatus mInitStatus;
    private static JPlayer mGlobalJPlayer;
    //当前开流的摄像机sn
    public String mCameraSN = "";

    // request p2p only at first time
    // if load fail or onLiveP2pNotWork callback
    // request with connect master afterwards
    protected boolean requestWithP2P;

    protected boolean requestingWithP2P;

    private static JPlayer getJPlayer() {
        if (mGlobalJPlayer == null) {
            mInitStatus = InitStatus.Initializing;
            String logFileName = FileUtil.getInstance().getLogFile().getAbsolutePath();
            if (!logFileName.endsWith(File.separator)) {
                logFileName += File.separator;
            }
            logFileName += JPLAYER_LOG_NAME;
            JPlayer.setLogPrint(BuildConfig.log, BuildConfig.log, logFileName);
            mGlobalJPlayer = new JPlayer(mJPlayerEvent);
            JPlayer.setDeviceInfo(Build.BRAND.toLowerCase(), Build.MODEL.toLowerCase());
        }
        return mGlobalJPlayer;
    }

    public static void doStopNow() {
        if (mGlobalJPlayer != null) {
            mGlobalJPlayer.release();
            mGlobalJPlayer = null;
        }
    }

    static JPlayer.IJPlayerEventListener mJPlayerEvent = new JPlayer.IJPlayerEventListener() {
        @Override
        public void onJPlayerInitResult(boolean succeed) {
            if (succeed) {
                mInitStatus = InitStatus.InitSucceed;
                mCurrentManger.managerJPlayerSucceed();
            } else {
                mInitStatus = InitStatus.InitFailed;
                mCurrentManger.updateStatus(PlayStatus.JPlayerFailed, "");
                CLog.e("JPlayer init failed!");
            }
            mCurrentManger = null;
        }
    };

    // endregion

    // region Param

    protected String mPoolNameHighPriority;

    protected CameraHttpApi mCameraHttpsApi;
    protected CameraHttpApi mLiveCameraHttpsApi;
    protected JPlayer mJPlayer = null;
    protected GL2VideoView mVideoView = null;
    protected long mVideoViewHandle;

    protected static long VideoViewHandle;

    protected PlayTypes mPlayType;
    protected PlayStatus mCurrentStatus;

    protected String mIdentify;
    protected String mTaskId;
    protected String mVideoTitle;
    protected long mStreamTime;
    protected int mStreamVersion;

    protected boolean mAllowSound = true;
    protected boolean mIsMuted = false;
    private boolean mIsFirstReso = true;

    // endregion

    // region Init

    public APlayManager(PlayTypes playType) {
        this(playType, true);
    }

    public APlayManager(PlayTypes playType, boolean defaultAllowSound) {
        mPlayType = playType;
        initData();
        this.mAllowSound = defaultAllowSound;
    }

    private void initData() {
        // 请求
        mCameraHttpsApi = GlobalManager.getInstance().config().cameraHttpsApi;
        mLiveCameraHttpsApi = GlobalManager.getInstance().config().liveHttpsApi;
        mPoolNameHighPriority = "APlayManager-pool-worker-high-priority-" + Utils.DATE_FORMAT_3.format(new Date());
        mThreadPool.initPool(mPoolNameHighPriority,
                Executors.newCachedThreadPool(new PoolThreadFactory(mPoolNameHighPriority)));

        mCurrentManger = this;
        mJPlayer = getJPlayer();
        if (mInitStatus == InitStatus.InitSucceed) {
            managerJPlayerSucceed();
        } else if (mInitStatus == InitStatus.InitFailed) {
            updateStatus(PlayStatus.JPlayerFailed, "");
        }

        // 超时、异常情况处理
        mTimeHandler = new Handler();
    }

    protected abstract void managerJPlayerSucceed();

    // endregion

    // region Manage Job

    @Override
    protected void asyncDoNamedJob(String jobName, Object... args) {
        managerAsyncDoNamedJob(jobName, args);
    }

    protected abstract void managerAsyncDoNamedJob(String jobName, Object... args);

    // endregion

    // region Public

    // region Param

    public String getIdentify() {
        return mIdentify;
    }

    public String getTitle() {
        return mVideoTitle;
    }

    public PlayTypes getPlayType() {
        return mPlayType;
    }

    public PlayStatus getCurrentStatus() {
        return mCurrentStatus;
    }

    public boolean getIsAllowSound() {
        return mAllowSound;
    }

    public boolean getIsFirstReso() {
        return mIsFirstReso;
    }

    public void setIsFirstReso(boolean isFirstReso) {
        this.mIsFirstReso = isFirstReso;
    }

    public void setVideoView(GL2VideoView videoView) {
        mVideoView = videoView;
        manageSetVideoView(videoView);
    }

    public void setVideoViewHandle(long handle) {
        mVideoViewHandle = handle;
        VideoViewHandle = handle;
        manageSetVideoViewHandle(handle);
    }

    protected abstract void manageSetVideoView(GL2VideoView videoView);

    protected void manageSetVideoViewHandle(long videoViewHandle) {

    }

    // endregion

    // region Control

    public void stopPlay() {
        CLog.d("Debug Play - stopPlay");
        updateStatus(PlayStatus.Stopping, "");

        handleStop();

//        if (mPlayType == PlayTypes.RealMine ||
//                mPlayType == PlayTypes.RealDemo ||
//                mPlayType == PlayTypes.RealShare) {
//            snapShot(SnapShotTypes.Stop);
//        } else {
//            handleStop();
//        }
    }

    public void stopPlayNow() {
        CLog.d("Debug Play - stopPlayNow");
        updateStatus(PlayStatus.Stopping, "");
        handleStop();
        analyzeRelease();
    }

    public void stopPlayDraw(boolean isSet) {
        if (isSet) {
            snapShot(SnapShotTypes.Draw);
        } else {
            handleStop();
        }
    }

    protected void handleStop() {
        removeRunnable();
        manageStopPlayer();
        // TODO 统计
        //LogUtil.getInstance().setTimestamp(requestingWithP2P, mIdentify, mTaskId, LogUtil.TYPE3, LogUtil.T5);
    }

    protected abstract void manageStopPlayer();

    protected void reStartPlay() {
        // TODO 统计
        //LogUtil.getInstance().setTimestamp(requestingWithP2P, mIdentify, mTaskId, LogUtil.TYPE3, LogUtil.T5);
        manageReStartPlay();
    }

    protected abstract void manageReStartPlay();

    protected boolean isRelease;

    public void release() {
        isRelease = true;
        CLog.d("Debug Play - release");
        if (mSnapShotType != SnapShotTypes.Stop) {
            CLog.d("Debug Play - manageRelease");
            isRelease = false;
            analyzeRelease();
        }
        mVideoView = null;
    }

    protected abstract void analyzeRelease();

    protected abstract void manageRelease();

    // endregion

    // region Mute(设置是否静默状态)

    public boolean getIsMuted() {
        return mIsMuted;
    }

    public void setIsMuted(boolean isMuted) {
        mIsMuted = isMuted;
    }

    public void setMute(boolean isMute) {
        CLog.i("test2", "---setMute-- = " + isMute);
        manageMute(isMute);
    }

    public void toggleMute(ButtonLayoutNew button) {
        toggleMute(button, true);
    }

    public void toggleMute(ButtonLayoutNew button, boolean isSave) {
        mIsMuted = !mIsMuted;
        manageMute(mIsMuted);
        button.setMode(mIsMuted ? 1 : 0);
        if (isSave) {
            Preferences.saveVideoMuted(mIdentify, mIsMuted);
        }
    }

    public void toggleMute(boolean isSave) {
        mIsMuted = !mIsMuted;
        manageMute(mIsMuted);
        if (isSave) {
            Preferences.saveVideoMuted(mIdentify, mIsMuted);
        }
    }

    public void commitIsMute() {
        manageMute(mIsMuted);
    }

    protected abstract void manageMute(boolean isMute);

    // endregion

    // region snapShot

    private boolean mIsSnapShot;
    private String mSnapFilename;
    private SnapShotTypes mSnapShotType;

    public void snapShot(SnapShotTypes type) {
        if (mIsSnapShot) {
            if (type != SnapShotTypes.Stop) {
                CLog.i("play-v2", "snapShot call snapshot_failed" + "--SnapShotTypes = " + type);
                String msg = Utils.getContext().getString(R.string.notice_video_snapshot_failed);
                publishAction(Actions.Play.UPDATE_CMD_RESULT, msg, PlayerCmd.SnapShot);
            }
            return;
        }
        mIsSnapShot = true;
        if (FileUtil.getInstance().calcAvailableSpare() < Const.MINAVAILABLESPARE) {
            String msg = Utils.getContext().getString(R.string.snap_storage_space_not_enough);
            publishAction(Actions.Play.UPDATE_CMD_RESULT, msg, PlayerCmd.SnapShot);
            return;
        }

        String snapPath = "";
        if (type == SnapShotTypes.Stop) {
            long time;
            if (mStreamTime > 0) {
                time = mStreamTime;
            } else {
                time = System.currentTimeMillis();
            }
            snapPath = Utils.getDeviceThumbPath(getIdentify() + "_" + time, ".jpeg");
        } else if (type == SnapShotTypes.Draw) {
            snapPath = Utils.getDeviceThumbPath(getIdentify() + "_draw", ".jpeg");
        } else {
            String name;
            name = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(new Date(System
                    .currentTimeMillis())) + "_" + System.currentTimeMillis() % 1000;

            snapPath = FileUtil.getInstance().getSnapshotFile().getAbsolutePath() + "/" + name + ".jpeg";
        }

        mSnapFilename = snapPath;
        mSnapShotType = type;
        manageSnapShot(snapPath);
    }

    protected abstract void manageSnapShot(String filename);

    protected void handleSnapshotResult(int result) {
        String filename = mSnapFilename;
        SnapShotTypes type = mSnapShotType;
        mSnapShotType = SnapShotTypes.None;
        mIsSnapShot = false;

        if (type == SnapShotTypes.Stop) {
            CLog.d("Debug Play - StopSnap");
            manageStopSnap(result == 0, filename);
            return;
        } else if (type == SnapShotTypes.Draw) {
            CLog.d("Debug Play - DrawSnap");
            manageDrawSnap(result == 0, filename);
            return;
        }

        String msg = "";
        if (result == 0) {
            playSnapshotSound(type);
            FileUtil.getInstance().updateGallery(filename);
            if (type == SnapShotTypes.LiveShare) {
                msg = Utils.getContext().getString(R.string.notice_video_snapshot_succe_for_share);
            } else {
                msg = Utils.getContext().getString(R.string.notice_video_snapshot_saved);
            }
            // 存储db
            MediaFiles mediaFiles = new MediaFiles();
            mediaFiles.setType(MediaFiles.TYPE.IMAGE);
            mediaFiles.setPath(filename);

            mediaFiles.setCreate_time(System.currentTimeMillis());
            mediaFiles.setSn(getIdentify());

            mediaFiles.setCamera_name(mVideoTitle);
            // TODO FileWrapper
            //FileWrapper.getInstance(Utils.getContext()).write(mediaFiles);

            publishAction(Actions.Play.UPDATE_SNAP_SHOT, mediaFiles, type);
        } else {
            File snapFile = new File(filename);
            if (snapFile.exists()) {
                snapFile.delete();
            }
            if (type == SnapShotTypes.LiveShare) {
                msg = Utils.getContext().getString(R.string.notice_video_snapshot_failed_for_share);
            } else {
                CLog.i("play-v2", "handleSnapshotResult call snapshot_failed");
                msg = Utils.getContext().getString(R.string.notice_video_snapshot_failed);
            }
        }

        publishAction(Actions.Play.UPDATE_CMD_RESULT, msg, PlayerCmd.SnapShot);
    }

    private MediaPlayer shootMP;

    private void playSnapshotSound(SnapShotTypes type) {
        if (type == SnapShotTypes.CheckShine) {
            return;
        }

        AudioManager audioM = (AudioManager) Utils.getContext().getSystemService(Context.AUDIO_SERVICE);
        int volume = audioM.getStreamVolume(AudioManager.STREAM_MUSIC);

        if (volume != 0) {
            if (shootMP == null)
                shootMP = MediaPlayer.create(Utils.getContext(),
                        Uri.parse("file:///system/media/audio/ui/camera_click.ogg"));
            if (shootMP != null)
                shootMP.start();
        }
    }

    private void manageStopSnap(boolean isSucceed, String filename) {
        if (isSucceed) {
            // TODO 暂时注释
//            GlobalManager.getInstance().myCameraManager().publishAction(Actions.Camera.REFRESH_IMAGE,
//                    getIdentify(), "file:///" + filename);
        }

        handleStop();

        CLog.d("Debug Play - isRelease:" + isRelease);
        if (isRelease) {
            isRelease = false;
            analyzeRelease();
        }
    }

    private void manageDrawSnap(boolean isSucceed, String filename) {
        publishAction(Actions.Play.STOP_DRAW_RESULT, isSucceed, filename);
    }

    // endregion

    // endregion

    // region Status

    protected void updateStatus(PlayStatus status, String msg) {
        if (status != mCurrentStatus) {
            CLog.d("Debug Play - PlayerStatus:" + status + "    msg:" + msg);
            manageLog(status);
            mCurrentStatus = status;
            publishAction(Actions.Play.UPDATE_PLAY_STATUS, status, msg);
        }
    }

    private void manageLog(PlayStatus status) {
        switch (status) {
            case MasterConnecting: {
                String env = "unKnow";

                if (mPlayType == PlayTypes.RealMine) {
                    env = "private";
                } else if (mPlayType == PlayTypes.RealLive) {
                    env = "public";
                } else if (mPlayType == PlayTypes.RealSD) {
                    env = "card";
                } else if (mPlayType == PlayTypes.RealShare) {
                    env = "private";
                }

                String sv;
                if (!requestingWithP2P) {
                    if (mStreamVersion == 0) {
                        sv = "1";
                    } else {
                        sv = "2";
                    }
                } else {
                    sv = "3";
                }

                // TODO 统计
                //LogUtil.getInstance().setTimestamp(requestingWithP2P, mIdentify, mTaskId, LogUtil.TYPE3, LogUtil.T1, env, sv);
                break;
            }
            case PlayerConnecting: {
                // TODO 统计
                //LogUtil.getInstance().setTimestamp(requestingWithP2P, mIdentify, mTaskId, LogUtil.TYPE3, LogUtil.T2);
                break;
            }
            case PlayerWaiting: {
                // TODO 统计
                //LogUtil.getInstance().setTimestamp(requestingWithP2P, mIdentify, mTaskId, LogUtil.TYPE3, LogUtil.T3);
                break;
            }
            case Playing: {
                if (mCurrentStatus == PlayStatus.PlayerWaiting) {
                    // TODO 统计
                    //LogUtil.getInstance().setTimestamp(requestingWithP2P, mIdentify, mTaskId, LogUtil.TYPE3, LogUtil.T4);
                }
                break;
            }
            case Buffering:
                // TODO 统计
                //LogUtil.getInstance().addSlowCount(mTaskId);
                break;
        }
    }

    // endregion

    // region Manage Timeout

    protected int mLastError;
    protected final int playTimeout = 10000;
    protected Handler mTimeHandler;

    private Runnable playRunnable = new Runnable() {
        @Override
        public void run() {
            reStartPlay();
            manageTimeout();
        }
    };

    private Runnable timeoutRunnable = new Runnable() {
        @Override
        public void run() {
            String msg;
            msg = Utils.getContext().getString(R.string.video_player_no_last_error);
            updateStatus(PlayStatus.Buffering, "");
            mTimeHandler.postDelayed(retryRunnable, playTimeout);
            manageTimeout();
            CLog.d("Debug Play - Timeout: " + mLastError);
            // TODO 错误上报
//            GlobalManager.getInstance().newPublicCameraManager().asyncSendErrorRtick(String.valueOf(mLastError), msg,
//                    getIdentify(), AccUtil.getInstance().getQID());
        }
    };

    private Runnable retryRunnable = new Runnable() {
        @Override
        public void run() {
            String msg;
            msg = Utils.getContext().getString(R.string.video_player_no_last_error);
            reStartPlay();
            manageTimeout();
            CLog.d("Debug Play - Retry: " + mLastError);
            // TODO 错误上报
//            GlobalManager.getInstance().newPublicCameraManager().asyncSendErrorRtick(String.valueOf(mLastError), msg,
//                    getIdentify(), AccUtil.getInstance().getQID());
        }
    };

    protected abstract void manageTimeout();

    private void addCachingTimeout() {
        CLog.d("Debug Play - addCachingTimeout");

        removeRunnable();
        mTimeHandler.postDelayed(timeoutRunnable, playTimeout);
    }

    private void removeRunnable() {
        CLog.d("Debug Play - removeRunnable");

        mTimeHandler.removeCallbacks(playRunnable);
        mTimeHandler.removeCallbacks(timeoutRunnable);
        mTimeHandler.removeCallbacks(retryRunnable);
        manageRemoveRunnable();
    }

    protected abstract void manageRemoveRunnable();

    protected void handleVideoReady() {
        removeRunnable();
    }

    protected void handleVideoCaching() {
        CLog.e("handleVideoCaching mCurrentStatus:" + mCurrentStatus + ", mPlayType:" + mPlayType);
        if (mCurrentStatus == PlayStatus.Playing) {
            if (mPlayType == PlayTypes.RecordLive || mPlayType == PlayTypes.RecordCloud) {
                removeRunnable();

                updateStatus(PlayStatus.Buffering, "");
                CLog.e("handleVideoCaching (PlayStatus.Buffering,");
            } else {
                addCachingTimeout();
            }
        }
    }

    protected void handleSessionOpenSucceed() {
        mTimeHandler.postDelayed(playRunnable, playTimeout * 2);
    }

    protected void handleCloseResult() {
        updateStatus(PlayStatus.Stopped, "");
    }

    protected int getDistortType() {
        if (mCameraSN.startsWith("3606")) {
            return 1;
        } else {
            return 0;
        }
    }
    // endregion
}
