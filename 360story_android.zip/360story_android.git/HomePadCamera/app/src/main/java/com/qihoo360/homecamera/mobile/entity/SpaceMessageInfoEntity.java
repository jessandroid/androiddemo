package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by yanggang on 2016/5/18.
 * 云空间不足推动消息
 */
public class SpaceMessageInfoEntity implements Parcelable {
    public String type;
    public String time;
    public String message;
    public Data data;

    public static class Data implements Parcelable {
        public String sn;
        public int status;

        public static final Parcelable.Creator<Data> CREATOR = new Parcelable.Creator<Data>() {
            @Override
            public Data createFromParcel(Parcel source) {
                return new Data(source);
            }

            @Override
            public Data[] newArray(int size) {
                return new Data[size];
            }
        };

        private Data(Parcel in) {
            sn = in.readString();
            status = in.readInt();
        }

        @Override
        public void writeToParcel(Parcel out, int flags) {
            out.writeString(sn);
            out.writeInt(status);
        }

        @Override
        public int describeContents() {
            return 0;
        }
    }

    public static final Parcelable.Creator<SpaceMessageInfoEntity> CREATOR = new Parcelable.Creator<SpaceMessageInfoEntity>() {
        @Override
        public SpaceMessageInfoEntity createFromParcel(Parcel source) {
            return new SpaceMessageInfoEntity(source);
        }

        @Override
        public SpaceMessageInfoEntity[] newArray(int size) {
            return new SpaceMessageInfoEntity[size];
        }
    };

    private SpaceMessageInfoEntity(Parcel in) {
        type = in.readString();
        time = in.readString();
        message = in.readString();
        data = (Data) in.readValue(Data.class.getClassLoader());
    }

    @Override
    public void writeToParcel(Parcel out, int flags) {
        out.writeString(type);
        out.writeString(time);
        out.writeString(message);
        out.writeValue(data);
    }

    @Override
    public int describeContents() {
        return 0;
    }
}
