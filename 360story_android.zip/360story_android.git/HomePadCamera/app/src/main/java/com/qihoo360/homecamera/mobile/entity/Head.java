
package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.Gson;
import com.qihoo360.homecamera.mobile.utils.CLog;

/**
 *
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/1/11
 * Time: 16:18
 * To change this template use File | Settings | File Templates.
 */
public class Head implements Parcelable {

    public int statusCode = 0;
    public int errorCode = 0;
    public String taskid;
    public String errorMsg;
    public String sid;
    public String pushKey;
    public long time = -1;

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public int getStatusCode() {
        return this.statusCode;
    }

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }

    public int getErrorCode() {
        return this.errorCode;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public String getErrorMsg() {
        return this.errorMsg;
    }



    public Head() {
    }

    public String getErrorMsgForShow() {
        String errorMsg4show="当前网络不可用，请检查您的手机网络";
        CLog.e(errorMsg4show);
        return errorMsg4show;
    }



    public String toJson() {
        Gson gson = new Gson();
        return gson.toJson(this);
    }

    @Override
    public String toString() {
        return toJson();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.statusCode);
        dest.writeInt(this.errorCode);
        dest.writeString(this.taskid);
        dest.writeString(this.errorMsg);
        dest.writeString(this.sid);
        dest.writeString(this.pushKey);
        dest.writeLong(this.time);
    }

    protected Head(Parcel in) {
        this.statusCode = in.readInt();
        this.errorCode = in.readInt();
        this.taskid = in.readString();
        this.errorMsg = in.readString();
        this.sid = in.readString();
        this.pushKey = in.readString();
        this.time = in.readLong();
    }

}
