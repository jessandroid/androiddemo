
package com.qihoo360.homecamera.mobile.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.qihoo360.accounts.api.auth.ModifyNickname;
import com.qihoo360.accounts.api.auth.ModifyUserHeadShot;
import com.qihoo360.accounts.api.auth.RefreshUser;
import com.qihoo360.accounts.api.auth.i.IRefreshListener;
import com.qihoo360.accounts.api.auth.i.IRequestListener;
import com.qihoo360.accounts.api.auth.i.IUploadHeadSheatListenser;
import com.qihoo360.accounts.api.auth.model.UserTokenInfo;
import com.qihoo360.accounts.api.auth.p.ClientAuthKey;
import com.qihoo360.accounts.api.auth.p.UserCenterUpdate;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.config.Const;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.config.DefaultClientConfig;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.entity.AppGetInfoEntity;
import com.qihoo360.homecamera.mobile.entity.BabyInfoEntity;
import com.qihoo360.homecamera.mobile.entity.DeviceInfo;
import com.qihoo360.homecamera.mobile.entity.RelationInfoEntity;
import com.qihoo360.homecamera.mobile.entity.ShareShareEntity;
import com.qihoo360.homecamera.mobile.entity.ShareUserEntity;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.ui.fragment.AboutPadFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.MuteModeFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.PadDiscSpaceFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.PadFamilyEditFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.PadFamilyManageFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.PadHeadFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.PadPersonalSettingAboutFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.PadPersonalSettingAccountFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.PadPersonalSettingChangeNicknameFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.PadPersonalSettingFeedbackFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.PadPersonalSettingForumFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.PadPersonalSettingNotificationFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.PadPersonalSettingProblemFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.PadPersonalSettingProtocolFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.PadPersonalSettingWebsiteFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.PadTitleFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.SetScreenProtectFragment;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.ActivityUtils;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.Preferences;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.utils.share.ShareToWeChatAndWeibo;
import com.qihoo360.homecamera.mobile.widget.TextViewWithFont;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Calendar;
import java.util.Date;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/1/28
 * Time: 10:14
 * To change this template use File | Settings | File Templates.
 */
public class SettingDetialActivity extends BaseActivity implements ActionListener {

    private ImageView back_zone;
    private ImageView mAddPadIv;
    private TextViewWithFont title_string;
    private RelativeLayout main_title_layout;
    private FrameLayout item_content;
    private String item = "";
    private DeviceInfo deviceInfo;
    private TextViewWithFont mRightButtonTv;
    private Fragment fragment;
    private String mNickName;
    private String mPreCommitName;
    private AccUtil mAccUtil;
    private ClientAuthKey mAuthKey;
    private static final int MSG_WHAT_GETSHARE_CODE = 1;
    private static final int MSG_WHAT_REF = 3;

    private AppGetInfoEntity mAppGetInfoEntity;
    private BabyInfoEntity mBabyInfoEntity;
    private BabyInfoEntity mOldBabyInfoEntity;
    private RelationInfoEntity mRelationInfoEntity;
    private RelationInfoEntity mOldRelationInfoEntity;
    private RelationInfoEntity mNewRelationInfoEntity;
    private String mSn;
    private boolean mUnset;
    private RefreshUser mRefreshUserPwd;

    public static final String URL_MODIFY_PWD = "http://i.360.cn/profile/chuserpwdwap?src=mpc_pingmuban_and&client=app&isShowSuccess=1&appJumpNotify=1&dskin=%23bc3131_%23bc3131_%23bc3131_%23bc3131";
    public static final String BIND_MOBILE_URL = "http://i.360.cn/security/bindmobilewap?src=mpc_pingmuban_and&client=app&appJumpNotify=2&isShowSuccess=1&dskin=%23bc3131_%23bc3131_%23bc3131_%23bc3131";
    public static final String FORGET_PASSWORD = "http://i.360.cn/findpwdwap?src=mpc_pingmuban_and&client=app&isShowSuccess=1&appJumpNotify=1&dskin=%23bc3131_%23bc3131_%23bc3131_%23bc3131";
    public String mRelax;
    private boolean mForbiddenBack = false;
    private boolean mBindSucceed = false;

    private ShareUserEntity mShareUserEntity;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        item = getIntent().getStringExtra("key");
        mNickName = getIntent().getStringExtra("nickname");
        mAppGetInfoEntity = getIntent().getParcelableExtra("appGetInfoEntity");
        mBabyInfoEntity = getIntent().getParcelableExtra("babyInfoEntity");
        mOldBabyInfoEntity = mBabyInfoEntity;
        mRelationInfoEntity = getIntent().getParcelableExtra("relationInfoEntity");
        mOldRelationInfoEntity = mRelationInfoEntity;
        mSn = getIntent().getStringExtra("sn");
        mUnset = getIntent().getBooleanExtra("unset", false);

        deviceInfo = getIntent().getParcelableExtra(DeviceInfo.class.getSimpleName());
        mShareUserEntity = getIntent().getParcelableExtra("shareUserEntity");
        mBindSucceed = getIntent().getBooleanExtra("bind_succeed", false);
        if (TextUtils.isEmpty(item)) {
            finish();
        }
        mAccUtil = AccUtil.getInstance();
        mAuthKey = new ClientAuthKey(DefaultClientConfig.FROM, DefaultClientConfig.SIGN_KEY, DefaultClientConfig.CRYPT_KEY);
        GlobalManager.getInstance().getCameraManager().registerActionListener(this);
        GlobalManager.getInstance().getUserInfoManager().registerActionListener(this);
        GlobalManager.getInstance().getShareManager().registerActionListener(this);
        //GlobalManager.getInstance().getCameraManager().asyncLoadPadBySn(mSn);
        setContentView(R.layout.camera_setting_detial_layout);
        initView();
        Fragment fragment = getFragmentByKey(item);
        if (fragment == null) {
            finish();
        }
        getSupportFragmentManager().beginTransaction().add(R.id.item_content, fragment).commit();
    }

    public void replaceFragment(Fragment fragment) {
        this.fragment = fragment;
        FragmentTransaction beginTransaction = getSupportFragmentManager()
                .beginTransaction();
        beginTransaction.replace(R.id.item_content, fragment).addToBackStack(null)
                .commitAllowingStateLoss();

        if (fragment instanceof PadPersonalSettingProtocolFragment) {
            String url = fragment.getArguments().getString("url");
            if (Const.USER_PRIVACY.equals(url)) {
                title_string.setText(R.string.user_privacy_title);
            } else if (Const.USER_PROTOCOL.equals(url)) {
                title_string.setText(R.string.user_protocol_title);
            } else if (Const.KIBOT_OFFICAL.equals(url)) {
                title_string.setText(R.string.offical_website);
            }
        } else if (fragment instanceof PadPersonalSettingWebsiteFragment) {
            title_string.setText(R.string.offical_website);
        } else if (fragment instanceof PadPersonalSettingForumFragment) {
            title_string.setText("论坛");
            mRightButtonTv.setVisibility(View.GONE);
        } else if (fragment instanceof PadDiscSpaceFragment) {
            title_string.setText("云端存储空间");
        } else if (fragment instanceof PadPersonalSettingChangeNicknameFragment) {
            title_string.setText("修改昵称");
        }
    }

    @Override
    public void onBackPressed() {
//        mRightButtonTv.setVisibility(View.INVISIBLE);
        if(fragment instanceof PadHeadFragment && TextUtils.equals(item, Constants.SettingCameraItem.PAD_HEAD_BIND_ITEM)){
            return;
        }
        if (getSupportFragmentManager().getBackStackEntryCount() == 0) {
            // 常见问题页面，返回按钮可能处理为返回上一页
            if (fragment instanceof PadPersonalSettingProblemFragment) {
                if (((PadPersonalSettingProblemFragment) fragment).onBackPressed()) {
                    return;
                }
            } else if (fragment instanceof PadPersonalSettingFeedbackFragment) {
                if (((PadPersonalSettingFeedbackFragment) fragment).onBackPressed()) {
                    return;
                }
            }
            back_zone.setVisibility(View.INVISIBLE);
            super.onBackPressed();
        } else {
            if (getSupportFragmentManager().getBackStackEntryCount() == 1) {
                if ((fragment instanceof PadPersonalSettingProtocolFragment) || (fragment instanceof PadPersonalSettingWebsiteFragment)) {
                    title_string.setText("关于");
                } else if (fragment instanceof PadPersonalSettingForumFragment) {
                    title_string.setText("意见反馈");
                    mRightButtonTv.setVisibility(View.VISIBLE);
                    mRightButtonTv.setText("提交");
                } else if (fragment instanceof PadDiscSpaceFragment) {
                    title_string.setText(getString(R.string.cam_setting_title));
                } else if (fragment instanceof PadPersonalSettingChangeNicknameFragment) {
                    mRightButtonTv.setVisibility(View.INVISIBLE);
                    title_string.setText("账号管理");
                }
                //btnSecond.setVisibility(View.VISIBLE);
                back_zone.setVisibility(View.VISIBLE);
            }
            getSupportFragmentManager().popBackStack();
        }
    }

    private void initView() {
        mAddPadIv = (ImageView) findViewById(R.id.iv_add_pad);
        mAddPadIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPopMenuAdding();
            }
        });
        back_zone = (ImageView) findViewById(R.id.back_zone);
        back_zone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        title_string = (TextViewWithFont) findViewById(R.id.title_string);
        title_string.setText("设置头像");
        main_title_layout = (RelativeLayout) findViewById(R.id.main_title_layout);
        item_content = (FrameLayout) findViewById(R.id.item_content);
        mRightButtonTv = (TextViewWithFont) findViewById(R.id.tv_right_button);
        mRightButtonTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (fragment instanceof SetScreenProtectFragment) {
                    int startHour = ((SetScreenProtectFragment) fragment).getTime()[0];
                    int startMinute = ((SetScreenProtectFragment) fragment).getTime()[1];
                    int endHour = ((SetScreenProtectFragment) fragment).getTime()[2];
                    int endMinute = ((SetScreenProtectFragment) fragment).getTime()[3];
                    CameraToast.show(startHour + ":" + startMinute + "-" + endHour + ":" + endMinute, Toast.LENGTH_SHORT);
                } else if (fragment instanceof MuteModeFragment) {
                    int startHour = ((MuteModeFragment) fragment).getTime()[0];
                    int startMinute = ((MuteModeFragment) fragment).getTime()[1];
                    int endHour = ((MuteModeFragment) fragment).getTime()[2];
                    int endMinute = ((MuteModeFragment) fragment).getTime()[3];
                    CameraToast.show(startHour + ":" + startMinute + "-" + endHour + ":" + endMinute, Toast.LENGTH_SHORT);
                } else if (fragment instanceof PadTitleFragment) {
                    GlobalManager.getInstance().getCameraManager().asyncModifyTitleAndHeadView(deviceInfo.getSn(), ((PadTitleFragment) fragment).getTitle());
                    showTipsDialog("正在修改昵称，请稍候...", R.drawable.icon_loading, 10000, true);
                } else if (fragment instanceof PadHeadFragment) {
                    ((PadHeadFragment) fragment).saveChange(false);
                } else if (fragment instanceof PadPersonalSettingFeedbackFragment) {
                    if (((PadPersonalSettingFeedbackFragment) fragment).commitFeedback()) {
                        showTipsDialog("提交反馈，请稍候...", R.drawable.icon_loading, 10000, true);
                    }
                } else if (fragment instanceof PadPersonalSettingChangeNicknameFragment) {
                    String nickname = ((PadPersonalSettingChangeNicknameFragment) fragment).getTitle();
                    if (!"".equals(nickname.trim())) {
                        showTipsDialog("正在修改昵称，请稍候...", R.drawable.icon_loading, 10000, true);
                        doCommandModifyNickname(nickname);
                    } else {
                        CameraToast.show(SettingDetialActivity.this, getString(R.string.acc_input_nick_name_toast),
                                Toast.LENGTH_LONG);
                    }
                }
            }
        });
    }

    public void setCurrentFrag(Fragment frag) {
        fragment = frag;
    }

    public Fragment getFragmentByKey(String key) {
        fragment = null;
        if (TextUtils.equals(key, Constants.SettingCameraItem.PAD_ABOUT_ITEM)) {
            fragment = AboutPadFragment.getInstance(deviceInfo);
            title_string.setText(getString(R.string.pad_about));
        } else if (TextUtils.equals(key, Constants.SettingCameraItem.PAD_HEAD_ITEM)) {
            fragment = PadHeadFragment.getInstance(deviceInfo);
            ((PadHeadFragment) fragment).setmIsFromBind(false);
            mRightButtonTv.setVisibility(View.VISIBLE);
            mRightButtonTv.setText("保存");
            title_string.setText(getString(R.string.detail_title_2));
        } else if (TextUtils.equals(key, Constants.SettingCameraItem.PAD_HEAD_BIND_ITEM)) {
            fragment = PadHeadFragment.getInstance(deviceInfo);
            ((PadHeadFragment) fragment).setmIsFromBind(true);
            mRightButtonTv.setVisibility(View.VISIBLE);
            mRightButtonTv.setText("保存");
            title_string.setText(getString(R.string.detail_title_2));
            mForbiddenBack = true;
            //不能返回
            back_zone.setVisibility(View.INVISIBLE);
        } else if (TextUtils.equals(key, Constants.SettingCameraItem.PAD_TITLE_ITEM)) {
            fragment = PadTitleFragment.getInstance(deviceInfo);
            title_string.setText(getString(R.string.title_2));
            mRightButtonTv.setVisibility(View.VISIBLE);
        } else if (TextUtils.equals(key, Constants.SettingCameraItem.PAD_MANAGER_ITEM)) {
            fragment = PadFamilyManageFragment.getInstance(deviceInfo);
            title_string.setText("成员管理");
        } else if (TextUtils.equals(key, Constants.SettingCameraItem.PAD_MUTE_ITEM)) {
            fragment = MuteModeFragment.getInstance(deviceInfo);
            title_string.setText("机器人静音模式");
            mRightButtonTv.setVisibility(View.VISIBLE);
        } else if (TextUtils.equals(key, Constants.SettingCameraItem.PAD_EDIT_FAMILY_ITEM)) {
            fragment = PadFamilyEditFragment.getInstance(deviceInfo);
            title_string.setText("家庭成员");
        }
//        else if (TextUtils.equals(key, Constants.SettingCameraItem.PAD_SCREENSAVERS_ITEM)) {
//            fragment = SetScreenProtectFragment.getInstance(deviceInfo);
//            title_string.setText("远程为机器人设置屏保");
//            mRightButtonTv.setVisibility(View.VISIBLE);
//        }else if (TextUtils.equals(key, Constants.SettingCameraItem.PAD_HEALTH_ITEM)) {
//            fragment = PadHealthFragment.getInstance(deviceInfo);
//            title_string.setText(R.string.health_pad);
//        }
        else if (TextUtils.equals(key, Constants.SettingCameraItem.PAD_PERSONAL_SETTING_PROBLEM_ITEM)) {
            fragment = PadPersonalSettingProblemFragment.getInstance();
            title_string.setText("常见问题");
        } else if (TextUtils.equals(key, Constants.SettingCameraItem.PAD_PERSONAL_SETTING_FEEDBACK_ITEM)) {
            fragment = PadPersonalSettingFeedbackFragment.getInstance();
            title_string.setText("意见反馈");
            mRightButtonTv.setVisibility(View.VISIBLE);
            mRightButtonTv.setText("提交");
        } else if (TextUtils.equals(key, Constants.SettingCameraItem.PAD_PERSONAL_SETTING_ABOUT_ITEM)) {
            fragment = PadPersonalSettingAboutFragment.getInstance();
            title_string.setText("关于");
        } else if (TextUtils.equals(key, Constants.SettingCameraItem.PAD_PERSONAL_SETTING_ACCOUNT_ITEM)) {
            fragment = PadPersonalSettingAccountFragment.getInstance();
            title_string.setText("账号管理");
        } else if (TextUtils.equals(key, Constants.SettingCameraItem.PAD_PERSONAL_SETTING_NOTIFICATION_ITEM)) {
            fragment = PadPersonalSettingNotificationFragment.getInstance();
            title_string.setText(getString(R.string.user_item_notification));
        }
        return fragment;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && mForbiddenBack) {
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void finish() {
        GlobalManager.getInstance().getCameraManager().removeActionListener(this);
        GlobalManager.getInstance().getUserInfoManager().removeActionListener(this);
        GlobalManager.getInstance().getShareManager().removeActionListener(this);
        super.finish();
        item = null;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (fragment instanceof PadHeadFragment) {
            switch (requestCode) {
                case PadHeadFragment.REQUEST_CROP_PHOTO: {
                    if (mUserHeadUri != null && resultCode == RESULT_OK) {
                        Glide.with(Utils.getContext())
                                .load(mUserHeadUri.getPath())
                                .diskCacheStrategy(DiskCacheStrategy.ALL)
                                .priority(Priority.HIGH)
                                .dontAnimate()
                                .error(R.drawable.icon_avator_empty)
                                .into(((PadHeadFragment) fragment).mIvHead);
                        ((PadHeadFragment) fragment).saveBitmap(mUserHeadUri.getPath());
                    }
//                    if (mUserHeadBitmap != null) {
//                        ((PadHeadFragment) fragment).mIvHead.setImageBitmap(mUserHeadBitmap);
//                        ((PadHeadFragment) fragment).saveBitmap(mUserHeadBitmap);
//                    }
                    break;
                }
            }
        }
        if (fragment instanceof PadPersonalSettingAccountFragment) {
            switch (requestCode) {
                case PadHeadFragment.REQUEST_CROP_PHOTO: {
                    if (mUserHeadUri != null && resultCode == RESULT_OK) {
                        modifyUserHead(mUserHeadUri.getPath());
                    }

//                    if (mUserHeadBitmap != null && data != null) {
//                        modifyUserHead(mUserHeadBitmap, avatarCrop.getAbsolutePath());
//                    }

                    break;
                }
            }
        }

    }

    public DeviceInfo getDeviceInfo() {
        return deviceInfo;
    }

    public String getmNickName() {
        return mNickName;
    }

    public void setmNickName(String mNickName) {
        this.mNickName = mNickName;
    }

    @Override
    public Object actionPerformed(int actionCode, Object... args) {
        switch (actionCode) {
            case Actions.UserInfo.APP_UPDATE_INFO_SUCCESS: {
                if (!TextUtils.equals(item, Constants.SettingCameraItem.PAD_HEAD_BIND_ITEM)) {
                    CameraToast.showToast(Utils.context, R.string.modify_success);
                }
                if(TextUtils.equals(item, Constants.SettingCameraItem.PAD_HEAD_BIND_ITEM)){//来自于绑定
                    Preferences.saveSelectedPad(getmSn());
                    GlobalManager.getInstance().getCommonManager().publishAction(Actions.Common.BIND_SUCCESS_UPDATE);
                    ActivityUtils.startActivityAndFinish(this, MainActivity.class);
                    finish();
                }else{
                    hideTipsDialog();
                    Intent intent = new Intent();
                    intent.putExtra("babyInfo", (String) args[0]);
                    intent.putExtra("filePath", (String) args[1]);
                    setResult(Constants.SUCCEED, intent);
                    finish();
                }
                return Boolean.TRUE;
            }

            case Actions.UserInfo.APP_UPDATE_INFO_FAIL: {
                if (args == null || args.length == 0) {
                    CameraToast.showErrorToast(this, R.string.modify_fail);
                } else {
                    CameraToast.showErrorToast((String) args[0]);
                }
                hideTipsDialog();
                if(TextUtils.equals(item, Constants.SettingCameraItem.PAD_HEAD_BIND_ITEM)){//来自于绑定
                    Preferences.saveSelectedPad(getmSn());
                    GlobalManager.getInstance().getCommonManager().publishAction(Actions.Common.BIND_SUCCESS_UPDATE);
                    ActivityUtils.startActivityAndFinish(this, MainActivity.class);
                    finish();
                }
                return Boolean.TRUE;
            }

            case Actions.ChangePwd.GET_RD_SUC:
                String rd = (String) args[0];
                String cookie_q = (String) args[1];
                String cookie_t = (String) args[2];
//                String url = getLoginToBrowserUrl(URL_MODIFY_PWD, rd);
                String url = URL_MODIFY_PWD;
                Intent intent = new Intent(this, AccountWebViewContainerActivity.class);
                intent.putExtra("url", url);
                intent.putExtra("url", url);
                intent.putExtra("q", cookie_q);
                intent.putExtra("t", cookie_t);
                CLog.i("cookie", cookie_q);
                CLog.i("cookie", cookie_t);
                intent.putExtra(AccountWebViewContainerActivity.REQUEST_CODE_KEY, 1);
                startActivity(intent);
                return Boolean.TRUE;

            case Actions.Share.SHARE_SHARE_SUCCESS:
                if (((String) args[1]).equals("2")) {
                    ShareShareEntity shareShareEntity = (ShareShareEntity) args[0];
                    ShareToWeChatAndWeibo shareToWeChatAndWeibo = GlobalManager.getInstance().getShareToWeChatAndWeibo();
                    //TODO 这里根据失败还是成功去判断是否去更新邀请码的状态
                    shareToWeChatAndWeibo.sendCamToWechatFriend(shareShareEntity.data.downUrl, deviceInfo.getTitle(), new ShareCameraActivity.ShareWxCallBack() {
                        @Override
                        public void succ() {
                            CLog.e("zhaojunbo", "succ");
                            //UpdateCode(shareCode);
                        }

                        @Override
                        public void failed(String shareCode) {
                            CLog.e("zhaojunbo", "failed");
                        }
                    });
                } else if (((String) args[1]).equals("3")) {
                    hideTipsDialog();
                    CameraToast.show(getString(R.string.send_msm_title), Toast.LENGTH_SHORT);
                }
                return Boolean.TRUE;

            case Actions.Share.SHARE_SHARE_FAIL: {
                getProgressDialog().dismiss();
                return Boolean.TRUE;
            }
            case Actions.Camera.LOAD_PAD_BY_SN:
            {
                deviceInfo = (DeviceInfo) args[0];
                return Boolean.TRUE;
            }

        }
        return Actions.ACTION_NOT_PROCESSED;
    }

    public void setmRightButtonTv(String functionName) {
        mRightButtonTv.setVisibility(View.VISIBLE);
        mRightButtonTv.setText(functionName);
    }

    public void hideRightButtonTv(){
        Utils.ensureVisbility(mRightButtonTv, View.GONE);
    }

    public void rightButtonTvClick(){
        mRightButtonTv.performClick();
    }
    /**
     * 修改昵称的方法
     */
    private final void doCommandModifyNickname(String nickname) {
        nickname.trim();
        if (!nickname.equals(mNickName)) {
            mPreCommitName = nickname;
            ModifyNickname mModifyNickname =
                    new ModifyNickname(this, mAuthKey, getMainLooper(),
                            mRequestListener);
            mModifyNickname.request(mAccUtil.getQ(), mAccUtil.getT(), nickname);

        } else {
            CameraToast.show(SettingDetialActivity.this, R.string.acc_nick_name_save_success_toast, Toast.LENGTH_SHORT);
            hideTipsDialog();
            onBackPressed();
        }
    }

    private final IRequestListener mRequestListener = new IRequestListener() {

        @Override
        public void onRequestSuccess() {
            mAccUtil.setNickName(mPreCommitName);
            mNickName = mPreCommitName;
            CameraToast.show(SettingDetialActivity.this, R.string.acc_nick_name_save_success_toast,
                    Toast.LENGTH_SHORT);
            hideTipsDialog();
            onBackPressed();
        }

        @Override
        public void onRequestError(int errorType, int errorCode, String errorMessage) {
            hideTipsDialog();
         /*   CameraToast.show(getActivity(), errorMessage == null
                    ? getString(R.string.error_toast_no_net)
                    : getString(R.string.nickname_modify_fail) + errorMessage, Toast.LENGTH_LONG);*/
            CameraToast.showToast(Utils.getContext(), errorMessage == null
                    ? Utils.getContext().getResources().getString(R.string.error_toast_no_net)
                    : Utils.getContext().getResources().getString(R.string.nickname_modify_fail) + errorMessage);
        }
    };

    /**
     * change user avatar
     *
     * @param strPath
     */
    public void modifyUserHead(final String strPath) {
        ModifyUserHeadShot shot = new ModifyUserHeadShot(getApplicationContext(),
                new ClientAuthKey(DefaultClientConfig.FROM, DefaultClientConfig.SIGN_KEY, DefaultClientConfig.CRYPT_KEY), getMainLooper(),
                new IUploadHeadSheatListenser() {
                    @Override
                    public void onRpcError(int arg0, int arg1, String arg2) {
                        CLog.d("上传头像失败：" + arg2);
                        hideTipsDialog();
                        CameraToast.show("上传头像失败：" + arg2, Toast.LENGTH_SHORT);
                    }

                    @Override
                    public void onRpcSuccess(String arg0, String arg1, String arg2) {
                        AccUtil.getInstance().setQ(arg1);
                        AccUtil.getInstance().setT(arg2);
                        AccUtil.getInstance().setAvatorUrl(arg0);
                        hideTipsDialog();
                        CameraToast.show("上传头像成功", Toast.LENGTH_SHORT);

                        PadPersonalSettingAccountFragment.getInstance().AfterUpdateUserHead(strPath);
//                        if (!TextUtils.isEmpty(avatar)) {
//                            GlobalManager.getInstance().getUserInfoManager().publishAction(Actions.UserInfo.LOAD_AVATAR_CACHE_FILE, avatar);
//                        }

                    }
                });

        File f = new File(strPath);
        try {
            showTipsDialog("正在修改头像，请稍候...", R.drawable.icon_loading, 10000, true);
            shot.request(AccUtil.getInstance().getQ(), AccUtil.getInstance().getT(), "m", new DataInputStream(
                    new FileInputStream(f)), "jpeg");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void modifyUserHead(final Bitmap bm, final String avatar) {
        ModifyUserHeadShot shot = new ModifyUserHeadShot(getApplicationContext(),
                new ClientAuthKey(DefaultClientConfig.FROM, DefaultClientConfig.SIGN_KEY, DefaultClientConfig.CRYPT_KEY), getMainLooper(),
                new IUploadHeadSheatListenser() {
                    @Override
                    public void onRpcError(int arg0, int arg1, String arg2) {
                        CLog.d("上传头像失败：" + arg2);
                        hideTipsDialog();
                        CameraToast.show("上传头像失败：" + arg2, Toast.LENGTH_SHORT);
//                        PadPersonalSettingAccountFragment.getInstance().AfterUpdateUserHead(null);
                    }

                    @Override
                    public void onRpcSuccess(String arg0, String arg1, String arg2) {
                        AccUtil.getInstance().setQ(arg1);
                        AccUtil.getInstance().setT(arg2);
                        AccUtil.getInstance().setAvatorUrl(arg0);
                        hideTipsDialog();
                        CameraToast.show("上传头像成功", Toast.LENGTH_SHORT);
                        PadPersonalSettingAccountFragment.getInstance().AfterUpdateUserHead(bm);
                        if (!TextUtils.isEmpty(avatar)) {
                            GlobalManager.getInstance().getUserInfoManager().publishAction(Actions.UserInfo.LOAD_AVATAR_CACHE_FILE, avatar);
                        }
                    }
                });

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.PNG, 100, baos);
        InputStream isBm = new ByteArrayInputStream(baos.toByteArray());
        showTipsDialog("正在修改头像，请稍候...", R.drawable.icon_loading, true);
        shot.request(AccUtil.getInstance().getQ(), AccUtil.getInstance().getT(), UserCenterUpdate.HEAD_150X150, new DataInputStream(isBm), "jpeg");
    }

    public void getUserRd(final Context context, final int requestCode) {
        mRefreshUserPwd = new RefreshUser(context, new ClientAuthKey(DefaultClientConfig.FROM, DefaultClientConfig.SIGN_KEY, DefaultClientConfig.CRYPT_KEY),
                context.getMainLooper(), new IRefreshListener() {
            @Override
            public void onRefreshSuccess(UserTokenInfo userTokenInfo) {
                if (userTokenInfo != null) {
                    String rd = "";
                    String cookie_q = "";
                    String cookie_t = "";

                    try {
                        rd = userTokenInfo.orgInfo.getString("rd");
                        cookie_q = userTokenInfo.q;
                        cookie_t = userTokenInfo.t;
                        if (requestCode == 1) {
                            GlobalManager.getInstance().getCameraManager().publishAction(Actions.ChangePwd.GET_RD_SUC, rd, cookie_q, cookie_t);
                        } else if (requestCode == 0) {
//                                    String url = getLoginToBrowserUrl(BIND_MOBILE_URL, rd);
                            String url = BIND_MOBILE_URL;
                            Intent intent = new Intent(SettingDetialActivity.this, AccountWebViewContainerActivity.class);
                            intent.putExtra("url", url);
                            intent.putExtra("q", cookie_q);
                            intent.putExtra("t", cookie_t);
                            intent.putExtra(AccountWebViewContainerActivity.REQUEST_CODE_KEY, requestCode);
                            startActivity(intent);
                        }
                    } catch (Exception e) {
                    }
                    hideTipsDialog();
                }
            }

            @Override
            public void onRefreshError(int errorType, int errorCode,
                                       String errorMessage) {
                CameraToast.showToast(context, R.string.error_toast_no_net);
                hideTipsDialog();
            }

            @Override
            public void onInvalidQT(String errorMessage) {
                hideTipsDialog();
            }
        });
        mRefreshUserPwd.setSsoTag("1");
        mRefreshUserPwd.refresh(mAccUtil.getQ(), mAccUtil.getT(), null,
                UserCenterUpdate.HEAD_150X150);
        showTipsDialog("请稍候...", R.drawable.icon_loading, 10000, true);
    }

    @Override
    public int getProperty() {
        return 0;
    }

    public String getSn() {
        if (deviceInfo != null) {
            return deviceInfo.getSn();
        } else {
            return getmSn();
        }
    }

    public AppGetInfoEntity getmAppGetInfoEntity() {
        return mAppGetInfoEntity;
    }

    public BabyInfoEntity getmBabyInfoEntity() {
        if (mBabyInfoEntity != null)
            return mBabyInfoEntity;
        else {
            Calendar ca = Calendar.getInstance();//得到一个Calendar的实例
            ca.setTime(new Date()); //设置时间为当前时间
            ca.add(Calendar.YEAR, -3); //年份减1
            return new BabyInfoEntity("宝贝", ca.getTimeInMillis() / 1000, -1);
        }

    }

    public RelationInfoEntity getmRelationInfoEntity() {
        if (mRelationInfoEntity != null)
            return mRelationInfoEntity;
        else
            return new RelationInfoEntity(0, Constants.TAG_LIST.get(0));
    }

    public void setNewRelationInfoEntity(int tag, String title) {
        mNewRelationInfoEntity = new RelationInfoEntity(tag, title);
    }

    public RelationInfoEntity getmNewRelationInfoEntity() {
        return mNewRelationInfoEntity;
    }

    public String getmSn() {
        return mSn;
    }

    public int dip2px(float dpValue) {
        final float scale = getResources().getDisplayMetrics().density;
        return (int) (dpValue * scale + 0.5f);
    }

    public void showPopMenuAdding() {
        Rect frame = new Rect();
        getWindow().getDecorView().getWindowVisibleDisplayFrame(frame);
        int offsetY = frame.top + dip2px(50 + 12);
        int offsetX = dip2px(5);
        View parentView = LayoutInflater.from(this).inflate(R.layout.main, null);
        final View popView = LayoutInflater.from(this).inflate(R.layout.popupwindow_family_manage, null);
        final PopupWindow popupWindow = new PopupWindow(popView, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true);
        popView.findViewById(R.id.invate).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss();
            }
        });

        popView.findViewById(R.id.friend).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss();
            }
        });
        popupWindow.setBackgroundDrawable(new BitmapDrawable(getResources(), (Bitmap) null));
        popupWindow.setOutsideTouchable(true);
        popupWindow.setAnimationStyle(android.R.style.Animation_Dialog);
        popupWindow.showAtLocation(parentView, Gravity.RIGHT | Gravity.TOP, offsetX, offsetY);

        // 设置背景颜色变暗
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.alpha = 0.6f;
        getWindow().setAttributes(lp);

        popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                WindowManager.LayoutParams lp = getWindow().getAttributes();
                lp.alpha = 1f;
                getWindow().setAttributes(lp);
            }
        });
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    public void setAddBtnVisible(int visible) {
        if (mAddPadIv != null) {
            mAddPadIv.setVisibility(visible);
        }
    }

    public ShareUserEntity getShareUserEntity() {
        return mShareUserEntity;
    }

    @Override
    protected void onDestroy() {
        Constants.TAG_LIST.remove(8);
        Constants.TAG_LIST.add("其他");
        super.onDestroy();
    }

    public BabyInfoEntity getmOldBabyInfoEntity() {
        return mOldBabyInfoEntity;
    }

    public RelationInfoEntity getmOldRelationInfoEntity() {
        return mOldRelationInfoEntity;
    }

    public boolean isUnset() {
        return mUnset;
    }

    public void setUnset(boolean flag) {
        mUnset = flag;
    }

    public boolean ismBindSucceed() {
        return mBindSucceed;
    }
}
