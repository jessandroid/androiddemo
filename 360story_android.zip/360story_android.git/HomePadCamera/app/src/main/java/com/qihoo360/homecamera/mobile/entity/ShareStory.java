package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/5/13
 * Time: 10:55
 * To change this template use File | Settings | File Templates.
 */
public class ShareStory extends Head implements Parcelable {


    /**
     * errorCode : 0
     * errorMsg : 成功
     * data : {"url":"http://rs-shanghai.oss.yunpan.360.cn/Object.getDownloadUrl/pad-master-album-sh/?e=1465700020&token=030f9838e84bbe8f0d364f1eb7c59a8e:81e8044e8853347887015223deddcc68"}
     */

    public int errorCode;
    public String errorMsg;
    /**
     * url : http://rs-shanghai.oss.yunpan.360.cn/Object.getDownloadUrl/pad-master-album-sh/?e=1465700020&token=030f9838e84bbe8f0d364f1eb7c59a8e:81e8044e8853347887015223deddcc68
     */

    public DataEntity data;

    public int getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public DataEntity getData() {
        return data;
    }

    public void setData(DataEntity data) {
        this.data = data;
    }

    public static class DataEntity implements Parcelable{
        private String url;

        protected DataEntity(Parcel in) {
            url = in.readString();
        }

        public static final Creator<DataEntity> CREATOR = new Creator<DataEntity>() {
            @Override
            public DataEntity createFromParcel(Parcel in) {
                return new DataEntity(in);
            }

            @Override
            public DataEntity[] newArray(int size) {
                return new DataEntity[size];
            }
        };

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(url);
        }
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.errorCode);
        dest.writeString(this.errorMsg);
        dest.writeParcelable(this.data, flags);
    }

    public ShareStory() {
    }

    protected ShareStory(Parcel in) {
        this.errorCode = in.readInt();
        this.errorMsg = in.readString();
        this.data = in.readParcelable(DataEntity.class.getClassLoader());
    }

    public static final Parcelable.Creator<ShareStory> CREATOR = new Parcelable.Creator<ShareStory>() {
        @Override
        public ShareStory createFromParcel(Parcel source) {
            return new ShareStory(source);
        }

        @Override
        public ShareStory[] newArray(int size) {
            return new ShareStory[size];
        }
    };
}
