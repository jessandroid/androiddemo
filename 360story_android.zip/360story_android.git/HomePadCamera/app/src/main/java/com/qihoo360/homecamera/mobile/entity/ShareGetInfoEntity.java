package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by zhaojunbo on 2016/1/27.
 * desc:
 */
public class ShareGetInfoEntity extends Head {

    public Data data;

    public static class Data implements Parcelable {

        public String sn;
        public String qid;
        public String nickName;
        public String imgUrl;
        public String title;
        public String coverUrl;
        public String avatarUrl;
        public String babyInfo;
        public String phone;
        public String userName;

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(this.sn);
            dest.writeString(this.qid);
            dest.writeString(this.nickName);
            dest.writeString(this.imgUrl);
            dest.writeString(this.title);
            dest.writeString(this.coverUrl);
            dest.writeString(this.avatarUrl);
            dest.writeString(this.babyInfo);
            dest.writeString(this.phone);
            dest.writeString(this.userName);
        }

        public Data() {
        }

        protected Data(Parcel in) {
            this.sn = in.readString();
            this.qid = in.readString();
            this.nickName = in.readString();
            this.imgUrl = in.readString();
            this.title = in.readString();
            this.coverUrl = in.readString();
            this.avatarUrl = in.readString();
            this.babyInfo = in.readString();
            this.phone = in.readString();
            this.userName = in.readString();
        }

        public static final Creator<Data> CREATOR = new Creator<Data>() {
            @Override
            public Data createFromParcel(Parcel source) {
                return new Data(source);
            }

            @Override
            public Data[] newArray(int size) {
                return new Data[size];
            }
        };
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(this.data, 0);
    }

    public ShareGetInfoEntity() {
    }

    protected ShareGetInfoEntity(Parcel in) {
        this.data = in.readParcelable(Data.class.getClassLoader());
    }

    public static final Parcelable.Creator<ShareGetInfoEntity> CREATOR = new Parcelable.Creator<ShareGetInfoEntity>() {
        public ShareGetInfoEntity createFromParcel(Parcel source) {
            return new ShareGetInfoEntity(source);
        }

        public ShareGetInfoEntity[] newArray(int size) {
            return new ShareGetInfoEntity[size];
        }
    };
}
