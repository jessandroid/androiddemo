package com.qihoo360.homecamera.mobile.entity;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by Administrator on 2014/11/28.
 */
public class ShareUserList extends  Head {
    private static final long serialVersionUID = 649231518147681036L;
    @SerializedName("shares")
    List<ShareUser> shareUsers;


    public List<ShareUser> getShareUsers() {
        return shareUsers;
    }

    public void setShareUsers(List<ShareUser> shareUsers) {
        this.shareUsers = shareUsers;
    }
}
