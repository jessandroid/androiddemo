
package com.qihoo360.homecamera.mobile.manager;

import android.annotation.TargetApi;
import android.app.Application;
import android.database.Cursor;
import android.os.Build;
import android.provider.BaseColumns;
import android.provider.MediaStore.Files;
import android.provider.MediaStore.Images;
import android.provider.MediaStore.Images.ImageColumns;
import android.provider.MediaStore.Images.Media;
import android.provider.MediaStore.MediaColumns;
import android.provider.MediaStore.Video;
import android.provider.MediaStore.Video.VideoColumns;
import android.text.TextUtils;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.core.beans.PhotoAlbum;
import com.qihoo360.homecamera.mobile.core.beans.PhotoAlbumGroup;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionPublisherWithThreadPoolBase;
import com.qihoo360.homecamera.mobile.core.manager.util.CursorByDayStringGrouperForGallery;
import com.qihoo360.homecamera.mobile.db.CombinedDateSortedCursor;
import com.qihoo360.homecamera.mobile.db.GroupedCursor;
import com.qihoo360.homecamera.mobile.utils.FileUtil;
import com.qihoo360.homecamera.mobile.utils.TimeUtilNew;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executors;

public class LocalManager extends ActionPublisherWithThreadPoolBase {
    private String mThreadPoolName;
    private Application mApp;

    private static final long DAYS_7 = 7 * 24 * 3600 * 1000;
    private static final String LOAD_PHOTO_ALBUMS = "load-photo-albums";
    private static final String LOAD_PHOTO_ALBUMS_BACKUP = "load-photo-albums-backup";
    private static final String LOAD_RECENT_ALBUMS_PHOTO = "load-recent-albums-photo";
    private static final String LOAD_PHOTO_BY_BUCKETID = "load_photo_by_bucketid";

    protected LocalManager(Application app) {
        mApp = app;
        mThreadPoolName = "local-manager-" + Utils.DATE_FORMAT_3.format(new Date());
        mThreadPool.initPool(mThreadPoolName, Executors.newFixedThreadPool(3));
    }

    @Override
    public void destroyNow() {
        super.destroyNow();
        mApp = null;
        mThreadPoolName = null;
    }

    @Override
    public void stopNow() {
        super.stopNow();
        mThreadPool.destroyPool(mThreadPoolName);
    }

    public void loadPhotoAlbums() {
        mThreadPool.submit(mThreadPoolName, new NamedAsyncJob(LOAD_PHOTO_ALBUMS));
    }

    public void asyncLoadPhoto(String bucketID) {
        mThreadPool.submit(mThreadPoolName, new NamedAsyncJob(LOAD_PHOTO_BY_BUCKETID, bucketID));
    }

    @SuppressWarnings("unchecked")
    @Override
    protected void asyncDoNamedJob(String jobName, Object... args) {
        if (jobName == null)
            return;
        if (LOAD_PHOTO_ALBUMS.equals(jobName) == true) {
            doLoadPhotoAlbums();
        } else if (LOAD_PHOTO_ALBUMS_BACKUP.equals(jobName) == true) {
            doLoadPhotoAlbumsByBackup();
        } else if (LOAD_RECENT_ALBUMS_PHOTO.equals(jobName)) {
            Collection<String> bucketIds = (Collection<String>) args[0];
            doLoadRecentAlbumsPhoto(bucketIds);
        } else if (LOAD_PHOTO_BY_BUCKETID.equals(jobName) == true) {
            String bucketID = (String) args[0];
            doLoadPhoto(bucketID);
        }
    }

    private void doLoadPhoto(String bucketID) {
        String commonWhere = MediaColumns.DATA + " is not null";
        Cursor imageCursor = null;
        HashMap<Integer, String> imageThumbPath = new HashMap<Integer, String>();
        if (Constants.ID_RECENT_ALBUMS.equals(bucketID)) {
            long sysMillis = System.currentTimeMillis();
            sysMillis = (sysMillis - DAYS_7) / 1000;
            imageCursor = mApp.getContentResolver().query(Media.EXTERNAL_CONTENT_URI,
                    CombinedDateSortedCursor.PROJECTION, ImageColumns.DATE_ADDED + ">" + sysMillis, null,
                    MediaColumns.DATE_ADDED + " desc");

        } else {
            imageCursor = mApp.getContentResolver().query(Media.EXTERNAL_CONTENT_URI,
                    CombinedDateSortedCursor.PROJECTION, ImageColumns.BUCKET_ID
                            + " in (" + bucketID + ") and " + commonWhere,
                    null,
                    MediaColumns.DATE_ADDED + " desc");
        }
        Cursor imageThumbCursor = mApp.getContentResolver().query(Images.Thumbnails.EXTERNAL_CONTENT_URI,
                new String[] {
                        Images.Thumbnails.IMAGE_ID, Images.Thumbnails.DATA
                },
                Images.Thumbnails.KIND + " = " + Images.Thumbnails.MINI_KIND, null, null);

        try {
            while (imageThumbCursor.moveToNext())
                imageThumbPath.put(imageThumbCursor.getInt(0), imageThumbCursor.getString(1));
        } finally {
            Utils.close(imageThumbCursor);
        }

        publishAction(Actions.MediaLibrary.PHOTO_SINGLE_LOADED, getAllByPhotoAlbum(imageCursor), imageThumbPath);
    }

    public static List<PhotoAlbum> getAllByPhotoAlbum(Cursor cursor) {
        List<PhotoAlbum> list = new ArrayList<PhotoAlbum>();
        PhotoAlbum p = null;
        try {
            if (cursor != null) {
                while (cursor.moveToNext()) {
                    String path = cursor.getString(cursor.getColumnIndexOrThrow(MediaColumns.DATA));
                    p = new PhotoAlbum();
                    int MIME_TYPE = CombinedDateSortedCursor.ColumnIndex.MIME_TYPE;
                    int ID_index = CombinedDateSortedCursor.ColumnIndex.ID;
                    p._size = cursor.getLong(CombinedDateSortedCursor.ColumnIndex.SIZE);
                    p._display_name = cursor.getString(CombinedDateSortedCursor.ColumnIndex.DISPLAY_NAME);
                    long date = cursor.getLong(CombinedDateSortedCursor.ColumnIndex.DATE_TAKEN);
                    p.date = date;
                    p.datetaken = TimeUtilNew.convertLongToDataTime(date, "yyyyMMdd_HHmmss");
                    p._id = cursor.getInt(ID_index);
                    p._data = path;
                    p.mime_type = cursor.getString(MIME_TYPE);
                    p.isVideo = p.mime_type != null && p.mime_type.startsWith("video/");

                    p.bucket_display_name = cursor.getString(CombinedDateSortedCursor.ColumnIndex.BUCKET_DISPLAY_NAME);
                    list.add(p);
                }
            }
        } catch (Exception e) {
            p = null;
        } finally {
            Utils.close(cursor);
        }
        return list;
    }

    private void doLoadPhotoAlbums() {
        ArrayList<PhotoAlbumGroup> photoAlbumGroups = getPhotoAlbumGroupInfoOrder(" ORDER BY " + ImageColumns.BUCKET_DISPLAY_NAME + " ASC --", false);
        photoAlbumGroups = addDefault(photoAlbumGroups, true);
        publishAction(Actions.Local.IMG_QUEUE_LOADED, photoAlbumGroups);
    }

    private void doLoadPhotoAlbumsByBackup() {
        ArrayList<PhotoAlbumGroup> photoAlbumGroups = getPhotoAlbumGroupInfoOrder(" ORDER BY " + ImageColumns.BUCKET_DISPLAY_NAME + " ASC --", true);
        photoAlbumGroups = addDefault(photoAlbumGroups, false);
        publishAction(Actions.Local.IMG_QUEUE_LOADED, photoAlbumGroups);
    }

    private void doLoadRecentAlbumsPhoto(Collection<String> bucketIds) {
        long sysMillis = System.currentTimeMillis();
        sysMillis = (sysMillis - DAYS_7) / 1000;

        Cursor imageCursor = mApp.getContentResolver().query(Media.EXTERNAL_CONTENT_URI,
                CombinedDateSortedCursor.PROJECTION, ImageColumns.DATE_ADDED + ">" + sysMillis, null,
                MediaColumns.DATE_ADDED + " desc");

        Cursor videoCursor = mApp.getContentResolver().query(Video.Media.EXTERNAL_CONTENT_URI,
                CombinedDateSortedCursor.PROJECTION, ImageColumns.DATE_ADDED + ">" + sysMillis, null,
                MediaColumns.DATE_ADDED + " desc");

        HashMap<Integer, String> imageThumbPath = new HashMap<Integer, String>();
        HashMap<Integer, String> videoThumbPath = new HashMap<Integer, String>();

        Cursor imageThumbCursor = mApp.getContentResolver().query(Images.Thumbnails.EXTERNAL_CONTENT_URI,
                new String[] {
                        Images.Thumbnails.IMAGE_ID, Images.Thumbnails.DATA
                },
                Images.Thumbnails.KIND + " = " + Images.Thumbnails.MINI_KIND, null, null);

        try {
            while (imageThumbCursor.moveToNext())
                imageThumbPath.put(imageThumbCursor.getInt(0), imageThumbCursor.getString(1));
        } finally {
            Utils.close(imageThumbCursor);
        }

        Cursor videoThumbCursor = mApp.getContentResolver().query(Video.Thumbnails.EXTERNAL_CONTENT_URI,
                new String[] {
                        Video.Thumbnails.VIDEO_ID, Video.Thumbnails.DATA
                },
                Video.Thumbnails.KIND + " = " + Video.Thumbnails.MINI_KIND, null, null);
        try {
            while (videoThumbCursor.moveToNext()) {
                videoThumbPath.put(videoThumbCursor.getInt(0), videoThumbCursor.getString(1));
            }
        } finally {
            Utils.close(videoThumbCursor);
        }
        Cursor combined = new CombinedDateSortedCursor(Utils.asArray(imageCursor, videoCursor),
                CombinedDateSortedCursor.ColumnIndex.DATE_ADDED);
        int count = combined == null ? 0 : combined.getCount();
        GroupedCursor<String> groupedCursor = new GroupedCursor<String>(combined,
                new CursorByDayStringGrouperForGallery(CombinedDateSortedCursor.ColumnIndex.DATE_ADDED, false), count);

        publishAction(Actions.MediaLibrary.COMBINED_DATA_LOADED, groupedCursor, bucketIds, imageThumbPath, videoThumbPath);
    }

    /**
     * 获取游标的一个内容
     * @return PhotoAlbumGroup
     */
    private PhotoAlbumGroup getOneByPhotoAlbumGroup(Cursor cursor) {
        PhotoAlbumGroup p = null;
        try {
            if (cursor != null) {
                p = new PhotoAlbumGroup();
                int orentation = cursor.getColumnIndexOrThrow(ImageColumns.ORIENTATION);
                int BUCKET_PATH_index = cursor.getColumnIndexOrThrow(MediaColumns.DATA);
                int BUCKET_ID_index = cursor.getColumnIndexOrThrow(ImageColumns.BUCKET_ID);
                int BUCKET_DISPLAY_NAME_index = cursor.getColumnIndexOrThrow(ImageColumns.BUCKET_DISPLAY_NAME);
                int PID_index = cursor.getColumnIndexOrThrow("PID");
                int count_index = cursor.getColumnIndexOrThrow("count");
                int maxtime_index = cursor.getColumnIndexOrThrow("maxtime");
                p.bucket_path = FileUtil.getParentPath(cursor.getString(BUCKET_PATH_index));
                if (p.bucket_path != null && p.bucket_path.indexOf(FileUtil.getmSDCacheDir().getAbsolutePath()) == 0)
                    return null;
                p.bucket_id = cursor.getString(BUCKET_ID_index);
                p.bucket_display_name = cursor.getString(BUCKET_DISPLAY_NAME_index);
                p.thumbnail_id = cursor.getInt(PID_index);
                p.bucket_num = cursor.getInt(count_index);
                p.orentation = cursor.getInt(orentation);
                if (cursor.getString(maxtime_index) != null)
                    p.maxtime = TimeUtilNew.convertLongToDataTime(Long.parseLong(cursor.getString(maxtime_index)));
            }
        } catch (Exception e) {
            p = null;
        }
        return checkPhotoAlbumGroupData(p);
    }

    /**
     * 检测NULL
     * @return PhotoAlbumGroup
     */
    private PhotoAlbumGroup checkPhotoAlbumGroupData(PhotoAlbumGroup group) {
        if (group != null) {
            if (TextUtils.isEmpty(group.bucket_path))
                return null;
            if (TextUtils.isEmpty(group.bucket_id))
                return null;
            if (group.bucket_display_name == null)
                group.bucket_display_name = "";
            if (group.maxtime == null)
                group.maxtime = "";
        }
        return group;
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    // 涉及函数已经做系统版本判断
    private ArrayList<PhotoAlbumGroup> getPhotoAlbumGroupInfoOrder(String orderStr, boolean isNeedVideo) {
        ArrayList<PhotoAlbumGroup> list = new ArrayList<PhotoAlbumGroup>();
        Cursor cursor = null;
        Cursor multiImgCursor = null;
        PhotoAlbumGroup pa = null;
        try {
            if (mApp != null && !TextUtils.isEmpty(orderStr)) {
                String[] IMAGE_PROJECTION = new String[] {
                        MediaColumns.DATA, ImageColumns.BUCKET_ID, ImageColumns.ORIENTATION,
                        ImageColumns.BUCKET_DISPLAY_NAME, " max(" + BaseColumns._ID + ") as PID ", " count(1) as count ",
                        " max(" + ImageColumns.DATE_TAKEN + ") as maxtime "
                };
                /*String WHERE_CLAUSE = MediaColumns.DATA + " is not null) group by " + ImageColumns.BUCKET_ID + ","
                        + ImageColumns.BUCKET_DISPLAY_NAME + orderStr;*/
                final boolean old_os = Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB;
                if (old_os) {
                    String WHERE_CLAUSE = MediaColumns.DATA + " is not null) group by " + ImageColumns.BUCKET_ID
                            + orderStr;
                    cursor = mApp.getContentResolver().query(Media.EXTERNAL_CONTENT_URI, IMAGE_PROJECTION,
                            WHERE_CLAUSE, null, null);
                } else {
                    String WHERE_CLAUSE = "";
                    if (isNeedVideo == true) {
                        WHERE_CLAUSE = "(media_type=1 or media_type=3) and _size>0 and _data is not null) group by " + ImageColumns.BUCKET_ID
                                + orderStr;
                    } else {
                        WHERE_CLAUSE = "(media_type=1) and _size>0 and _data is not null) group by " + ImageColumns.BUCKET_ID
                                + orderStr;
                    }
                    cursor = mApp.getContentResolver().query(Files.getContentUri("external"), IMAGE_PROJECTION,
                            WHERE_CLAUSE, null, null);
                }
                if (cursor != null) {
                    // list = new ArrayList<PhotoAlbumGroup>();
                    while (cursor.moveToNext()) {
                        pa = getOneByPhotoAlbumGroup(cursor);
                        String selection = ImageColumns.BUCKET_ID + "=" + pa.bucket_id;
                        try {
                            if (old_os) {
                                multiImgCursor = mApp.getContentResolver().query(Media.EXTERNAL_CONTENT_URI, null,
                                        selection, null, ImageColumns.DATE_TAKEN + " desc" + " limit 0, 4");
                            } else {
                                multiImgCursor = mApp.getContentResolver().query(Files.getContentUri("external"), null,
                                        selection, null, ImageColumns.DATE_TAKEN + " desc" + " limit 0, 4");
                            }
                            int count = 0;
                            while (multiImgCursor.moveToNext()) {
                                final int OS_MEDIA_TYPE_IMAGE = 1;// 系统中 image 对应的media type = 1
                                final int OS_MEDIA_TYPE_VIDEO = 3;// 系统中 image 对应的media type = 3
                                final int tMediaTypeIndex = multiImgCursor.getColumnIndex("media_type");
                                int media_type = -1 == tMediaTypeIndex ? OS_MEDIA_TYPE_IMAGE : multiImgCursor.getInt(tMediaTypeIndex); // 如果不存在该列则当成image
                                int id = multiImgCursor.getInt(multiImgCursor.getColumnIndex(BaseColumns._ID));
                                if (OS_MEDIA_TYPE_IMAGE == media_type) {
                                    pa.thumbnail_uris.put(count, Media.EXTERNAL_CONTENT_URI + "/" + id);
                                }
                                if (isNeedVideo == true) {
                                    if (OS_MEDIA_TYPE_VIDEO == media_type) {
                                        pa.thumbnail_uris.put(count, Video.Media.EXTERNAL_CONTENT_URI + "/" + id);
                                    }
                                }
                                // 保留旧方案
                                if (count == 0) {
                                    pa.thumbnail_id = multiImgCursor.getInt(multiImgCursor.getColumnIndex(BaseColumns._ID));
                                } else if (count == 1) {
                                    pa.thumbnail_id_second = multiImgCursor.getInt(multiImgCursor.getColumnIndex(BaseColumns._ID));
                                } else if (count == 2) {
                                    pa.thumbnail_id_third = multiImgCursor.getInt(multiImgCursor.getColumnIndex(BaseColumns._ID));
                                } else if (count == 3) {
                                    pa.thumbnail_id_fourth = multiImgCursor.getInt(multiImgCursor.getColumnIndex(BaseColumns._ID));
                                }
                                count++;
                            }
                        } finally {
                            Utils.close(multiImgCursor);
                        }
                        if (pa != null) {
                            if (pa.bucket_display_name.equals("360云盘相册") == false) {
                                list.add(pa);
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            Utils.close(cursor);
            Utils.close(multiImgCursor);
        }
        return list;
    }

    private ArrayList<PhotoAlbumGroup> addDefault(ArrayList<PhotoAlbumGroup> mDataList, boolean isAddRecent) {
        ArrayList<PhotoAlbumGroup> list = new ArrayList<PhotoAlbumGroup>();
        ArrayList<String> selectList = new ArrayList<String>(Arrays.asList(Constants.defaultAlbum));

        if (isAddRecent)
            addRecentAlbum(list, false);

        for (String path : Constants.defaultAlbum) {
            PhotoAlbumGroup camera = existInList(String.valueOf(path.toLowerCase(Locale.getDefault()).hashCode()), mDataList);
            if (camera != null) {
                camera.summary = mApp.getString(R.string.camera_photo);
                mDataList.remove(camera);
                list.add(camera);
            }
        }

        for (PhotoAlbumGroup camera : mDataList) {
            String path = camera.bucket_path;
            if (path.contains("DCIM/Camera")) {
                mDataList.remove(camera);
                list.add(camera);
                break;
            }
        }

        for (String path : Constants.screenAlbum) {
            PhotoAlbumGroup shots = existInList(String.valueOf(path.toLowerCase(Locale.getDefault()).hashCode()), mDataList);
            if (shots != null) {
                shots.summary = mApp.getString(R.string.screen_shot);
                mDataList.remove(shots);
                list.add(shots);
            }
        }

        for (String path:Constants.cameraSnap){
            PhotoAlbumGroup shots = existInList(String.valueOf(path.toLowerCase(Locale.getDefault()).hashCode()), mDataList);
            if (shots != null) {
                shots.summary = mApp.getString(R.string.camera_snap);
                mDataList.remove(shots);
                list.add(shots);
            }
        }

        for (String s : selectList) {
            if (!TextUtils.isEmpty(s)) {
                PhotoAlbumGroup group = existInList(String.valueOf(s.toLowerCase(Locale.getDefault()).hashCode()), mDataList);
                if (group != null) {
                    mDataList.remove(group);
                    list.add(group);
                }
            }
        }

        list.addAll(mDataList);

        return list;
    }

    private void addRecentAlbum(ArrayList<PhotoAlbumGroup> list, boolean isNeedVideo) {
        long sysMillis = System.currentTimeMillis();
        sysMillis = (sysMillis - DAYS_7) / 1000;
        Cursor imageCursor = mApp.getContentResolver().query(Media.EXTERNAL_CONTENT_URI,
                new String[] {
                        ImageColumns._ID, MediaColumns.DATE_ADDED
                }, ImageColumns.DATE_ADDED + ">" + sysMillis, null,
                MediaColumns.DATE_ADDED + " desc");

        Cursor videoCursor = mApp.getContentResolver().query(Video.Media.EXTERNAL_CONTENT_URI,
                new String[] {
                        VideoColumns._ID, MediaColumns.DATE_ADDED
                },
                VideoColumns.DATE_ADDED + ">" + sysMillis, null,
                MediaColumns.DATE_ADDED + " desc");

        int totalCount = 0;
        int imgId = 0, videoId = 0, imgId_2 = 0, imgId_3 = 0, imgId_4 = 0;
        long imgDataAdded = 0, videoDataAdded = 0;
        try {
            totalCount += imageCursor.getCount();
            int count = 0;
            while (imageCursor.moveToNext() && count < 4) {
                if (count == 0) {
                    imgId = imageCursor.getInt(0);
                } else if (count == 1) {
                    imgId_2 = imageCursor.getInt(0);
                } else if (count == 2) {
                    imgId_3 = imageCursor.getInt(0);
                } else if (count == 3) {
                    imgId_4 = imageCursor.getInt(0);
                }
                imgDataAdded = imageCursor.getLong(1);
                count++;
            }
            //            if (imageCursor.moveToNext()) {
            //                imgId = imageCursor.getInt(0);
            //                imgDataAdded = imageCursor.getLong(1);
            //            }
        } finally {
            Utils.close(imageCursor);
        }

        try {
            if (isNeedVideo == true) {
                totalCount += videoCursor.getCount();
                if (videoCursor.moveToNext()) {
                    videoId = videoCursor.getInt(0);
                    videoDataAdded = videoCursor.getLong(1);
                }
            }
        } finally {
            Utils.close(videoCursor);
        }

        if (totalCount > 0) {
            PhotoAlbumGroup recentAlbum = new PhotoAlbumGroup();
            recentAlbum.bucket_id = Constants.ID_RECENT_ALBUMS;
            recentAlbum.bucket_num = totalCount;
            recentAlbum.bucket_display_name = "最新图片";
            recentAlbum.summary = "";
            if (imgDataAdded > videoDataAdded) {
                recentAlbum.mimeType = "image/jpeg";
                recentAlbum.thumbnail_id = imgId;
                recentAlbum.thumbnail_id_second = imgId_2;
                recentAlbum.thumbnail_id_third = imgId_3;
                recentAlbum.thumbnail_id_fourth = imgId_4;
            } else {
                recentAlbum.mimeType = "video/mp4";
                recentAlbum.thumbnail_id = videoId;
            }

            list.add(recentAlbum);
        }
    }

    private PhotoAlbumGroup existInList(String key, ArrayList<PhotoAlbumGroup> mDataList) {
        if (mDataList != null && !mDataList.isEmpty() && key != null) {
            for (PhotoAlbumGroup group : mDataList) {
                if (group != null && !TextUtils.isEmpty(group.bucket_id) && group.bucket_id.equals(key)) {
                    return group;
                }
            }
        }
        return null;
    }
}
