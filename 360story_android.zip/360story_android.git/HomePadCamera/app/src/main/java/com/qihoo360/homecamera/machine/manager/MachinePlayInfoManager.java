package com.qihoo360.homecamera.machine.manager;

import android.text.TextUtils;

import com.qihoo360.homecamera.machine.entity.FamilyMessageEntity;
import com.qihoo360.homecamera.machine.entity.FavorResultEntity;
import com.qihoo360.homecamera.machine.entity.LocalSetting;
import com.qihoo360.homecamera.machine.entity.MachineDeviceInfo;
import com.qihoo360.homecamera.machine.entity.MachinePlaySingle;
import com.qihoo360.homecamera.machine.entity.UpgradeReceipt;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionPublisherBase;
import com.qihoo360.homecamera.mobile.utils.Preferences;

/**
 * 故事机播放信息管理器
 * Created by zhangtao-iri
 */

public class MachinePlayInfoManager extends ActionPublisherBase {

    private static MachinePlayInfoManager sInstance;

    public static MachinePlayInfoManager getInstance() {
        if (sInstance == null) {
            synchronized (MachinePlayInfoManager.class) {
                if (sInstance == null) {
                    sInstance = new MachinePlayInfoManager();
                }
            }
        }
        return sInstance;
    }

    public MachinePlayInfoManager() {
    }

    //TODO 通知列表和播放页面进行更新
    public void notifySinglePlayUpdate(MachinePlaySingle singleInfo, String cmd, String from, String sn){
        if(TextUtils.equals(sn, Preferences.getSelectedPad())){
            publishAction(Actions.MachinePlayInfo.NOTIFY_SINGLEPLAY_LIST, singleInfo, cmd, from);
        }
    }

    //TODO 通知页面有新的列表更新（进入收藏页获取收藏列表，还有就是播放页获取用户内置列表、收藏列表已经导入列表）
    public void notifyListUpdate(int listType, String cmd, String from, String sn){
        if(TextUtils.equals(sn, Preferences.getSelectedPad())){
            publishAction(Actions.MachinePlayInfo.NOTIFY_LIST_UPDATE, listType, cmd, from);
        }
    }

    //TODO 通知故事机正在忙，在列表页和故事机页需要处理
    public void notifyMachineBusy(String cmd, String from, String sn){
        if(TextUtils.equals(sn, Preferences.getSelectedPad())){
            publishAction(Actions.MachinePlayInfo.NOTIFY_MACHINE_BUSY, cmd, from);
        }
    }

    //TODO 通知故事机正闲着，只有在播放页面需要做处理
    public void notifyMachineFree(String cmd, String sn){
        if(TextUtils.equals(sn, Preferences.getSelectedPad())){
            publishAction(Actions.MachinePlayInfo.NOTIFY_MACHINE_IS_FREE, cmd);
        }
    }

    //TODO 通知播放列表为空
    public void notifyPlayListEmpty(String cmd, String sn){
        if(TextUtils.equals(sn, Preferences.getSelectedPad())){
            publishAction(Actions.MachinePlayInfo.NOTIFY_PLAY_LIST_EMPTY, cmd);
        }
    }

    //TODO 通知播放页面更新本地设置状态
    public void notifyLocalSettingUpdate(LocalSetting setting, String sn){
        publishAction(Actions.MachinePlayInfo.NOTIFY_LOCAL_SETTING_UPDATE, setting, sn);
    }

    //TODO 通知列表已经是最新的了
    public void notifyListIsNewwest(int listType, String from, String sn){
        if(TextUtils.equals(sn, Preferences.getSelectedPad())){
            publishAction(Actions.MachinePlayInfo.NOTIFY_LIST_IS_NEWEST, listType, from);
        }
    }

    //TODO 固件主动告知收藏列表有更新
    public void nativenotifyFavorListUpdate(String sn){
        if(TextUtils.equals(sn, Preferences.getSelectedPad())){
            publishAction(Actions.MachinePlayInfo.NATIVE_NOTIFY_FAVOR_LIST_UPDATE);
        }
    }

    //TODO 固件主动告知导入列表有更新
    public void nativenotifyInsertListUpdate(String sn){
        if(TextUtils.equals(sn, Preferences.getSelectedPad())){
            publishAction(Actions.MachinePlayInfo.NATIVE_NOTIFY_INSERT_LIST_UPDATE);
        }
    }

    //TODO 通知操作结果更新
    public void notifyFavorResultUpdate(FavorResultEntity entity, String from, String sn){
        if(TextUtils.equals(sn, Preferences.getSelectedPad())){
            publishAction(Actions.MachinePlayInfo.NOTIFY_FAVOR_RESULT_UPDATE, entity, from);
        }
    }

    //通知获取到故事机信息
    public void notifyDeviceInfoUpdate(MachineDeviceInfo info, String sn, String from) {
        publishAction(Actions.MachinePlayInfo.NOTIFY_MACHINE_DEVICE_INFO, info, sn, from);
    }

    //通知获取到故事机固件升级的信息
    public void notifyGetUpgradeInfo(UpgradeReceipt upgradeReceipt, String sn, String form) {
        publishAction(Actions.MachinePlayInfo.NOTIFY_GET_UPGRADE_RECEIPT, upgradeReceipt, sn, form);
    }

    //故事机在线状态发生变化
    public void notifyOnlineStateChange(int isOnline, String sn){
        if(TextUtils.equals(sn, Preferences.getSelectedPad())){
            publishAction(Actions.MachinePlayInfo.NOTIFY_MACHINE_ONLINE_STATE_CHANGED, isOnline);
        }
    }

    //通知有新的聊天消息到达
    public void notifyChatMessageReached(FamilyMessageEntity entity){
        publishAction(Actions.MachinePlayInfo.NOTIFY_CHAT_MESSAGE_REACHED, entity);
    }

    //单独通知家庭群更新消息
    public void notifyGroupUpdateMsg(FamilyMessageEntity entity){
        publishAction(Actions.MachinePlayInfo.NOTIFY_FAMILY_GROUP_MESSAGE_REACHED, entity);
    }
}
