
package com.qihoo360.homecamera.machine.activity;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.View;

import com.qihoo360.homecamera.machine.ui.widget.MallWebViewFragment;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.utils.ActionListener;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.Utils;

// TODO 相关操作已注释，以后填充

public class MoreActivity extends BaseFragmentActivity implements ActionListener {

//    private final String TAG = MoreActivity.class.getSimpleName();

    public static final int ABOUT_FARGMENT = 1;
    public static final int SHARE_APP_FARGMENT = 2;
    public static final int HELP_FRAGMENT = 3;
    public static final int FEEDBACK_FRAGMENT = 4;
    public static final int PURCHASE_FRAGMENT = 5;
    public static final int ACCOUNT_MANAGER = 6;
    public static final int MODIFY_PUBLIC_NAME = 7;
    public static final int BBS_FRAGMENT = 8;
    public static final int SPLASH_WEB = 9;
    public static final int BBS_SHUIDI_LIVE = 10;
    public static final int BBS_SHUIDI_WHY = 11;
    public static final int HOME_AD_INTENT = 1000;

    private Fragment fragment = null;
    private String spalshUrl = "";

    private String homeAdurl = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getIntent().hasExtra("splash_url")) {
            spalshUrl = getIntent().getStringExtra("splash_url");
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        CLog.d("DESTORY");
    }

    @Override
    public void onBackPressed() {
        //		onBack(null);
        super.onBackPressed();
        overridePendingTransition(R.anim.left_in, R.anim.right_out);
    }

    public void OnCommit(View v) {
        switch (getStatus()) {
            case FEEDBACK_FRAGMENT:
                //((FeedBackFragment) fragment).onFeedBack();
                break;
            default:
                break;
        }
    }

    @Override
    protected void setReplaceFragment(String newUrl) {
        Bundle extras = new Bundle();
        switch (getStatus()) {
//            case ABOUT_FARGMENT:
//                setTitleText(R.string.about);
//                fragment = new AboutFragment();
//                break;
//            case SHARE_APP_FARGMENT:
//                setTitleText(R.string.share_app);
//                fragment = new ShareAppFragment();
//                break;
//            case HELP_FRAGMENT:
//                setTitleText(R.string.help_web_title);
//                // fragment = new HelpFragment();
//                Bundle extras = new Bundle();
//                extras.putString("url", ServerLocation.getStringUrl(R.string.name_newxcjvhakyewdhsfajk));
//                fragment = new WebViewFragment();
//                fragment.setArguments(extras);
//                break;
            case PURCHASE_FRAGMENT:
                setTitleText(R.string.purchase);
                extras = new Bundle();
                extras.putString("url", Utils.getContext().getResources().getString(R.string.name_camera_purchase_url));
                fragment = new MallWebViewFragment();
                fragment.setArguments(extras);
                break;
//            case ACCOUNT_MANAGER:
//                setTitleText(R.string.account_settings_prompt);
//                fragment = new AccountManageFragment();
//                if(getIntent().hasExtra("subCommand")) {
//                    Bundle subCommand = new Bundle();
//                    subCommand.putInt("goto", getIntent().getIntExtra("subCommand", -1));
//                    fragment.setArguments(subCommand);
//                }
//                break;
//            case BBS_FRAGMENT:
//                setTitleText(R.string.bbs_title);
//                extras = new Bundle();
//                extras.putString("url", Const.BBS_URL);
//                fragment = new WebViewFragment();
//                fragment.setArguments(extras);
//                break;
//            case SPLASH_WEB:
//                setTitleText("");
//                extras = new Bundle();
//                extras.putString("url", spalshUrl);
//                fragment = new WebViewFragment();
//                fragment.setArguments(extras);
//                break;
//            case BBS_SHUIDI_LIVE:
//                setTitleText(getResources().getString(R.string.app_lanucher_name));
//                extras = new Bundle();
//                extras.putString("url", Const.LIVE_UNBLOCK);
//                fragment = new WebViewFragment();
//                fragment.setArguments(extras);
//                break;
//            case BBS_SHUIDI_WHY:
//                setTitleText(getResources().getString(R.string.app_lanucher_name));
//                extras = new Bundle();
//                extras.putString("url", Const.LIVE_WHY);
//                fragment = new WebViewFragment();
//                fragment.setArguments(extras);
//                break;
//            case HOME_AD_INTENT:
//                setTitleText(getResources().getString(R.string.app_lanucher_name));
//                extras = new Bundle();
//                extras.putString("url", newUrl);
//                fragment = new WebViewFragment();
//                fragment.setArguments(extras);
//                break;
            default:
                CLog.e("fragmentId  传入有误");
                finish();
                return;
        }
        replaseFragment(fragment);
    }

    @Override
    public Object actionPerformed(int actionCode, Object... args) {
//        switch (actionCode)
//        {
//            case Actions.ModifyLiveCamera.MODIFY_TITLE_ACTION: {
//                CLog.d("--------------->");
//                return Boolean.TRUE;
//            }
//        }
        return Actions.ACTION_NOT_PROCESSED;
    }

    @Override
    public int getProperty() {
        return 0;
    }

}
