
package com.qihoo360.homecamera.mobile.adapter;

import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.qihoo360.homecamera.mobile.SysConfig;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.DensityUtil;
import com.qihoo360.homecamera.mobile.widget.MultiColumnAlbumView;

import java.util.ArrayList;

public abstract class BaseAlbumPhotoListAdapter extends BaseAdapter {

    public int mColumnCount = 2;
    private final int TYPE_ENTRY = 1;
    protected ArrayList<Integer> mSectionList = new ArrayList<Integer>();
    protected int mTotalCount;
    private int childItemPaddingH = (int) (1 * SysConfig.DENSITY);
    private int parentPaddingH = 0;
    private int parentPaddingV = (int) (0* SysConfig.DENSITY);
    private int totalCount = 0;

    public BaseAlbumPhotoListAdapter() {
    }

    @Override
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return mTotalCount;
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int count) {
        totalCount = count;
    }

    public void setCount(int count) {
        mTotalCount = count;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return bindSelectionView(position, convertView, parent, position);
    }

    private View bindSelectionView(int childRowStart, View convertView, ViewGroup parent, int rawPosition) {
        if (convertView == null) {
            convertView = generateRowView(parent);
        }
        MultiColumnAlbumView root = (MultiColumnAlbumView) convertView;
        root.setItemPaddingHV(DensityUtil.dip2px(1), DensityUtil.dip2px(1));
        root.setPaddingHV(0, 0);
        root.removeAllViews();
        for (int i = 0; i < mColumnCount; i++) {
            int curPos = i + (childRowStart * mColumnCount);
            if (curPos < totalCount) {
                View child = getChildItemView(curPos, null, parent, rawPosition);
                root.addView(child);
            }
        }
        return convertView;
    }

    public void setItemPadding(int padding) {
        this.childItemPaddingH = padding;
    }

    public void setChildrenParentPadding(int padding) {
        CLog.i("test2", "setChildrenParentPadding : " + padding);
        this.parentPaddingH = padding;
    }

    public void setChildrenParentPaddingV(int padding) {
        CLog.i("test2", "setChildrenParentPaddingV : " + padding);
        this.parentPaddingV = padding;
    }

    private final ViewGroup generateRowView(ViewGroup parent) {
        MultiColumnAlbumView root = new MultiColumnAlbumView(parent.getContext());
        root.setColumnCount(mColumnCount);
        root.setClickable(true);
        return root;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public int getItemViewType(int position) {
        return TYPE_ENTRY;
    }

    public void setChildColumnCount(int columnCount) {
        mColumnCount = columnCount;
    }

    public int getChildColumnCount() {
        return mColumnCount;
    }
    
    public abstract View getChildItemView(int childPosition, View convertView, ViewGroup parent, int rawPosition);
}
