package com.qihoo360.homecamera.mobile.activity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.FutureTarget;
import com.google.gson.Gson;
import com.qihoo360.homecamera.device.config.StoryMachineConsts;
import com.qihoo360.homecamera.mobile.BuildConfig;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.config.DefaultClientConfig;
import com.qihoo360.homecamera.mobile.entity.AlbumShareEntity;
import com.qihoo360.homecamera.mobile.entity.ShareStoryEntity;
import com.qihoo360.homecamera.mobile.entity.Story;
import com.qihoo360.homecamera.mobile.entity.UploadToken;
import com.qihoo360.homecamera.mobile.http.OkHttpUtils;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.widget.CamAlertDialog;

import java.io.File;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.concurrent.ExecutionException;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import jp.wasabeef.glide.transformations.RoundedCornersTransformation;
import rx.Observable;
import rx.Observer;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;
import rx.schedulers.Schedulers;


public class PushAndShareStoryActivity extends BaseActivity implements View.OnClickListener {

    @Bind(R.id.back_button)
    ImageView backButton;
    @Bind(R.id.shareStory)
    TextView shareStory;
    @Bind(R.id.title_bar)
    RelativeLayout titleBar;
    @Bind(R.id.imageView3)
    ImageView imageView3;
    @Bind(R.id.story_title)
    TextView storyTitle;
    @Bind(R.id.relativeLayout4)
    RelativeLayout relativeLayout4;
    @Bind(R.id.textView4)
    LinearLayout textView4;
    @Bind(R.id.click_layout)
    LinearLayout clickLayout;
    private CamAlertDialog camAlertDialog;
    private GridView video_share_grid_layout;
    private TextView title;
    private ImageView close;
    private WeakReference<PushAndShareStoryActivity> weakReference;
    private String sn;
    private Story story;
    private UploadToken uploadToken;
    private String shareUrl;
    private String imagePath;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String token = getIntent().getStringExtra("uploadToken");
        final String storyJson = getIntent().getStringExtra("story");
        sn = getIntent().getStringExtra("devSn");
        if (TextUtils.isEmpty(token) || TextUtils.isEmpty(sn) || TextUtils.isEmpty(storyJson)) {
            finish();
        }
        weakReference = new WeakReference<>(this);
        final Gson gson = new Gson();

        uploadToken = gson.fromJson(token, UploadToken.class);
        story = gson.fromJson(storyJson, Story.class);
        CLog.d(storyJson);

        setContentView(R.layout.push_share_layout);
        ButterKnife.bind(this);
        storyTitle.setText(uploadToken.name);
        clickLayout.setEnabled(false);

        Glide.with(this)
                .load(uploadToken.cover)
                .crossFade()
                .diskCacheStrategy(DiskCacheStrategy.RESULT)
                .bitmapTransform(new RoundedCornersTransformation(this, 10, 0,
                        RoundedCornersTransformation.CornerType.TOP))
                .error(R.drawable.moren_icon_story_on_line)
                .into(imageView3);
        Observable.create(new Observable.OnSubscribe<String>() {
            @Override
            public void call(Subscriber<? super String> subscriber) {
                HashMap<String, String> param = new HashMap<String, String>();
                param.put("sn", sn);
                param.put("id", story.serverIntID.trim());
                param.put("qid", AccUtil.getInstance().getQID());
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.post().params(param).headers(null).url(DefaultClientConfig.SHARE_STORY_URL).build().execute();
                try {
                    FutureTarget<File> future = Glide.with(Utils.context)
                            .load(uploadToken.cover)
                            .downloadOnly(500, 500);
                    File imageFile = future.get();
                    if (imageFile != null) {
                        imagePath = imageFile.getAbsolutePath();
                        subscriber.onNext(responseStr);
                    } else {
                        subscriber.onError(new Throwable(responseStr));
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    subscriber.onError(e);
                } catch (ExecutionException e) {
                    e.printStackTrace();
                    subscriber.onError(e);
                }
                subscriber.onNext(responseStr);

            }
        }).map(new Func1<String, ShareStoryEntity>() {
            @Override
            public ShareStoryEntity call(String s) {
                ShareStoryEntity shareStoryEntity =
                        gson.fromJson(s, ShareStoryEntity.class);
                return shareStoryEntity;
            }
        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Observer<ShareStoryEntity>() {
            @Override
            public void onCompleted() {

            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onNext(ShareStoryEntity shareStoryEntity) {
                clickLayout.setEnabled(true);
                shareUrl = shareStoryEntity.getShareUrl(story.serverIntID.trim(), "story", sn);
                CLog.d(shareUrl);
            }
        });
    }


    @OnClick({R.id.back_button, R.id.shareStory, R.id.title_bar, R.id.imageView3, R.id.story_title, R.id.relativeLayout4, R.id.textView4, R.id.click_layout})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.back_button:
                finish();
                break;
            case R.id.shareStory:
                // TODO: 2016/3/25  推送故事
                break;
            case R.id.title_bar:
                break;
            case R.id.imageView3:
                break;
            case R.id.story_title:
                break;
            case R.id.relativeLayout4:
                break;
            case R.id.textView4:
                break;
            case R.id.click_layout:
                if (!TextUtils.isEmpty(shareUrl)) {
                    showDialog(shareUrl);
                }
                break;
        }
    }

    public void showDialog(final String url) {

        AlbumShareEntity entity = new AlbumShareEntity();
        entity.image = imagePath;
        entity.type = AlbumShareEntity.TYPE_STORY;
        entity.info = story.name;
        entity.url = url;
        entity.type = AlbumShareEntity.TYPE_STORY;
        PhotoShareToAppActivity.startActivityFromEntity(entity, this);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (camAlertDialog != null) {
            camAlertDialog.dismiss();
            camAlertDialog = null;
        }
    }

    @Override
    public void finish() {
        if (camAlertDialog != null) {
            camAlertDialog.dismiss();
        }
        super.finish();
    }
}
