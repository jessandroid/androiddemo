package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by zhaojunbo on 2016/1/21.
 * desc:
 */
public class ShareShareEntity extends Head {

    public Data data;

    public static class Data {

        public String code;
        public String isRegUser;
        public String downUrl;

    }


    public static final Parcelable.Creator<ShareShareEntity> CREATOR = new Parcelable.Creator<ShareShareEntity>() {
        @Override
        public ShareShareEntity createFromParcel(Parcel source) {
            return new ShareShareEntity(source);
        }

        @Override
        public ShareShareEntity[] newArray(int size) {
            return new ShareShareEntity[size];
        }
    };

    private ShareShareEntity(Parcel in) {
        data = (Data) in.readValue(Data.class.getClassLoader());
    }

    public void writeToParcel(Parcel out, int flags) {
        out.writeValue(data);
    }

    @Override
    public int describeContents() {
        return 0;
    }

}
