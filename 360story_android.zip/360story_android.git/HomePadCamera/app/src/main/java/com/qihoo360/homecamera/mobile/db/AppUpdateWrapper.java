package com.qihoo360.homecamera.mobile.db;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.qihoo360.homecamera.mobile.entity.Update;
import com.qihoo360.homecamera.mobile.entity.UpdateInfo;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/5/1
 * Time: 10:21
 * To change this template use File | Settings | File Templates.
 */
public class AppUpdateWrapper extends AbstractWrapper {


    private static AppUpdateWrapper appupdatewrapper;
    private static final String TABLE_NAME = "update_app";

    private AppUpdateWrapper() {

    }

    public synchronized static AppUpdateWrapper getInstance() {
        if (appupdatewrapper == null) {
            appupdatewrapper = new AppUpdateWrapper();
        }
        return appupdatewrapper;
    }


    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int toVersion) {
        switch (toVersion) {
            case 2:
                break;
            default:
                break;
        }
    }

    @Override
    public void onOpen(SQLiteDatabase db) {

    }

   //清空所有版本更新数据记录
    public void deleteInfo() {
        synchronized (AppUpdateWrapper.class) {
            SQLiteDatabase db = GlobalManager.getInstance().config().db.getWritableDatabase();
            db.beginTransaction();
            db.delete(TABLE_NAME, null, null);
            db.endTransaction();
        }
    }

    //写入一条版本更新信息
    public void write(Update update) {
        synchronized (AppUpdateWrapper.class) {
            SQLiteDatabase db = GlobalManager.getInstance().config().db.getWritableDatabase();
            UpdateInfo dataEntity = update.result;
            ContentValues values = new ContentValues();
            values.put(Field.KEY_SIZE, dataEntity.size);
            values.put(Field.KEY_MD5, dataEntity.md5);
            values.put(Field.KEY_IGNORE, 0);
            values.put(Field.KEY_VERSION, dataEntity.versionCode);
            if (!TextUtils.isEmpty(dataEntity.getLocalpath())) {
                values.put(Field.KEY_LOCAL, dataEntity.getLocalpath());
            }
            values.put(Field.KEY_TOTAL_JSON, update.toJson());
            try {
                db.insert(TABLE_NAME, null, values);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    //从数据库中读取该版本号的数据信息（主要是是否忽略和时候有已下载的apk地址）
    public Update readUpDate(int versionCode) {
        SQLiteDatabase db = GlobalManager.getInstance().config().db.getReadableDatabase();
        Update update = new Update();
        Cursor cursor = null;
        Gson gson = new Gson();
        try {
            cursor = db.query(TABLE_NAME, null, Field.KEY_VERSION + " = ?", new String[]{String.valueOf(versionCode)}, null, null, null);
            while (cursor.moveToNext()) {
                String arg_1 = cursor.getString(cursor.getColumnIndex(Field.KEY_TOTAL_JSON));
                update = gson.fromJson(arg_1, Update.class);
                update.result.localpath = cursor.getString(cursor.getColumnIndex(Field.KEY_LOCAL));
                update.result.isIgnored = cursor.getInt(cursor.getColumnIndex(Field.KEY_IGNORE));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return update;
    }

    //是否存在该版本的更新数据
    public boolean exist(int version){
        boolean exist = false;
        if (version < 0) {
            return false;
        }
        long queryRes = queryQidCount(version);
        if (queryRes > 0) {
            exist = true;
        }
        return exist;

    }

    public Long queryQidCount(int version) {
        SQLiteDatabase db = GlobalManager.getInstance().config().db.getWritableDatabase();
        long count = 0;
        StringBuffer sb = new StringBuffer("");
        sb.append("select count(_id) from ");
        sb.append(TABLE_NAME);
        sb.append(" where " + Field.KEY_VERSION + " = " + version + "");
        try {
            SQLiteStatement statement = db.compileStatement(sb.toString());
            count = statement.simpleQueryForLong();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }
        return count;
    }

    //通过版本号更新是否忽略字段(0--不忽略  1--忽略)
    public void updateIgnored(int versionCode, int state){
        try{
            SQLiteDatabase db = GlobalManager.getInstance().config().db.getReadableDatabase();
            ContentValues values = new ContentValues();
            values.put(Field.KEY_IGNORE, state);
            String selection = Field.KEY_VERSION + " = ?";
            String[] args = new String[]{String.valueOf(versionCode)};
            db.update(TABLE_NAME, values, selection, args);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    //判断数据库是否为空
    public Long queryUpdateCount() {
        SQLiteDatabase db = GlobalManager.getInstance().config().db.getWritableDatabase();
        long count = 0;
        StringBuffer sb = new StringBuffer("");
        sb.append("select count(_id) from ");
        sb.append(TABLE_NAME);
        try {
            SQLiteStatement statement = db.compileStatement(sb.toString());
            count = statement.simpleQueryForLong();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }
        return count;
    }

    public boolean updateIsNull(){
        if(queryUpdateCount()>0){
            return false;
        }else{
            return true;
        }
    }

    public class Field {
        public static final String KEY_ID = "_id"; // id
        public static final String KEY_SIZE = "v_size";  //大小
        public static final String KEY_MD5 = "v_md5";  //md5
        public static final String KEY_VERSION = "v_vcode"; // 内部版本
        public static final String KEY_IGNORE = "v_ignore"; //是否忽略该版本
        public static final String KEY_LOCAL = "v_locaPath";
        public static final String KEY_TOTAL_JSON = "v_total"; //update json
    }

}
