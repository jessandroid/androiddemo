
package com.qihoo360.homecamera.mobile.core.manager.workpool;


import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionPublisher;
import com.qihoo360.homecamera.mobile.core.util.ParallelAsyncTask;

/**
 * Catches api errors when executing server calls, and publish conresponding errors throw assoicated ActionPublisher.
 */
public abstract class AsyncApiJob<Params, Progress, Result> extends
        ParallelAsyncTask<Params, Progress, Result> {
    private ActionPublisher mActionPublisher = null;
    private Throwable mExcetpion = null;

    public AsyncApiJob() {

    }

    public void setActionPublisher(ActionPublisher listener) {
        mActionPublisher = listener;
    }

    public AsyncApiJob(ActionPublisher publisher) {
        mActionPublisher = publisher;
    }

    @SuppressWarnings("unchecked")
    @Override
    protected Result doInBackground(Params... params) {
        try {
            return makeApiCall(params);
        } catch (Throwable e) {
            mExcetpion = e;
            return null;
        }
    }

    @Override
    protected void onPostExecute(Result result) {
        if (mExcetpion == null) {
            onApiResult(result);
        } else if (mActionPublisher != null) {
            mActionPublisher.publishAction(Actions.Misc.MANAGED_EXCEPTION, mExcetpion);
        }
        mExcetpion = null;
        mActionPublisher = null;
    }

    @SuppressWarnings("unchecked")
    protected abstract Result makeApiCall(Params... params);

    protected abstract void onApiResult(Result result);

}
