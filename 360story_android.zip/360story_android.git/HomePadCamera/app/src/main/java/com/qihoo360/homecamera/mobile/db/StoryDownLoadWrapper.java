package com.qihoo360.homecamera.mobile.db;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.qihoo360.homecamera.mobile.entity.Story;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.utils.CLog;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/3/31
 * Time: 14:30
 * To change this template use File | Settings | File Templates.
 */
public class StoryDownLoadWrapper extends AbstractWrapper {


    private static StoryDownLoadWrapper storyCacheWrapper;
    private static final String TABLE_NAME = "down_laod_story";

    private StoryDownLoadWrapper() {

    }

    public static StoryDownLoadWrapper getInstance() {
        if (storyCacheWrapper == null) {
            synchronized (StoryDownLoadWrapper.class) {
                storyCacheWrapper = new StoryDownLoadWrapper();
            }
        }
        return storyCacheWrapper;
    }


    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int toVersion) {
        switch (toVersion) {
            case 2:
                break;
            default:
                break;
        }
    }

    @Override
    public void onOpen(SQLiteDatabase db) {

    }

    public void saveStory(Story story) {
        synchronized (StoryDownLoadWrapper.class) {
            SQLiteDatabase sqLiteDatabase = GlobalManager.getInstance().config().db.getWritableDatabase();
            try {
                sqLiteDatabase.beginTransaction();
                if (exist(story.id)) {
                    storyCacheWrapper.delStoryByStoryId(story.id);
                }
                storyCacheWrapper.write(sqLiteDatabase, story);
                sqLiteDatabase.setTransactionSuccessful();
            } catch (Exception e) {
                e.printStackTrace();
                CLog.e(e);
            } finally {
                if (sqLiteDatabase != null) {
                    sqLiteDatabase.endTransaction();
                }
            }
        }
    }

    private boolean delStoryByStoryId(String id) {
        synchronized (StoryDownLoadWrapper.class) {
            SQLiteDatabase db = GlobalManager.getInstance().config().db.getWritableDatabase();
            long count = 0;
            StringBuffer sb = new StringBuffer("");
            sb.append("delete from ");
            sb.append(TABLE_NAME);
            sb.append(" where story_id='" + id + "'");
            try {
                SQLiteStatement statement = db.compileStatement(sb.toString());
                count = statement.simpleQueryForLong();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
            }
            return count > 0;
        }
    }


    // FIXME: 2016/3/22 写入数据库
    private void write(SQLiteDatabase db, Story story) {

        ContentValues values = new ContentValues();
        values.put(Field.KEY_STORY_ID, story.id);
        values.put(Field.KEY_VIDEO_PATH, story.mp4_path);
        values.put(Field.KEY_LRC_PATH, story.lrc_path);
        values.put(Field.KEY_STORY_JSON, story.toJson());

        try {
            if (!exist(story.id)) {
                db.insert(TABLE_NAME, null, values);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean exist(String storyId) throws Exception {
        boolean exist = false;
        if (TextUtils.isEmpty(storyId)) {
            throw new Exception("sn or code is null");
        }
        SQLiteDatabase db = GlobalManager.getInstance().config().db.getReadableDatabase();
        long queryRes = queryQidCount(db, storyId);
        if (queryRes > 0) {
            exist = true;
        }
        return exist;
    }


    public long storySize(String storyId) {
        long size = -1;
        try {
            SQLiteDatabase db = GlobalManager.getInstance().config().db.getReadableDatabase();
            if (exist(storyId)) {
                Story story = null;
                Cursor cursor = null;
                Gson gson = new Gson();
                try {
                    cursor = db.query(TABLE_NAME, null, Field.KEY_STORY_ID + "=?", new String[]{storyId}, null, null, null);
                    while (cursor.moveToNext()) {
                        String arg_1 = cursor.getString(cursor.getColumnIndex(Field.KEY_STORY_JSON));
                        story = gson.fromJson(arg_1, Story.class);
                    }
                    size = Long.parseLong(story.size);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    if (cursor != null) {
                        cursor.close();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return size;
    }

    public Long queryQidCount(SQLiteDatabase db, String storyId) {
        long count = 0;
        StringBuffer sb = new StringBuffer("");
        sb.append("select count(_id) from ");
        sb.append(TABLE_NAME);
        sb.append(" where " + Field.KEY_STORY_ID + "='" + storyId + "'");
        try {
            SQLiteStatement statement = db.compileStatement(sb.toString());
            count = statement.simpleQueryForLong();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }
        return count;
    }

    /**
     * read cache
     *
     * @return
     */
    public Story getStoryCache(String storyId) {
        SQLiteDatabase db = GlobalManager.getInstance().config().db.getReadableDatabase();
        Story story = null;
        Cursor cursor = null;
        Gson gson = new Gson();
        try {
            cursor = db.query(TABLE_NAME, null, " story_id = '?' ", new String[]{storyId}, null, null, null);
            while (cursor.moveToNext()) {
                String arg_1 = cursor.getString(cursor.getColumnIndex(Field.KEY_STORY_JSON));
                story = gson.fromJson(arg_1, Story.class);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return story;
    }


    private class Field {
        public static final String KEY_STORY_ID = "story_id";
        public static final String KEY_VIDEO_PATH = "video_path";
        public static final String KEY_LRC_PATH = "lrc_path";
        public static final String KEY_STORY_JSON = "json_s";
    }
}
