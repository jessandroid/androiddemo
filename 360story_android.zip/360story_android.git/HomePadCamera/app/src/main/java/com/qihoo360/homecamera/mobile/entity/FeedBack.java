package com.qihoo360.homecamera.mobile.entity;

/**
 * Created by yanggang on 2016/4/21.
 */
public class FeedBack {

    public int errno;
    public String errmsg;

    public void setErrno(int errno) {
        this.errno = errno;
    }

    public void setErrmsg(String errmsg) {
        this.errmsg = errmsg;
    }

    public int getErrno() {
        return errno;
    }

    public String getErrmsg() {
        return errmsg;
    }
}
