
package com.qihoo360.homecamera.mobile.env;

public class AppEnv {

    public static final boolean DEBUG = true;

    public static final String APP_VERSION = "0.1.1";

    public static final String APP_BUILD = "1001";

    public static final String APP_VERSION_BUILD = APP_VERSION + "." + APP_BUILD;

}
