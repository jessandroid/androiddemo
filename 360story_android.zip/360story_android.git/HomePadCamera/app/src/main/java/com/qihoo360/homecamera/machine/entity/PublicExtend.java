
package com.qihoo360.homecamera.machine.entity;

import java.io.Serializable;

/**
 * Created by wdynetposa on 2015/5/4.
 */
public class PublicExtend implements Serializable {
    private static final long serialVersionUID = 4713206346769707402L;

    public int filter; // 0关 1开 默认关
}
