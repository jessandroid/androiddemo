package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.text.TextUtils;

import com.qihoo360.homecamera.mobile.utils.TimeUtilNew;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by Administrator on 2014/11/11.
 */
public class MediaFiles implements Serializable ,ShareAble{

    /**
     * 
     */
    private static final long serialVersionUID = 4308849915928626573L;
    private int id;
    public   enum  TYPE {
        IMAGE, VIDEO
    }

    private String path = "";
    /**
     * 媒体文件类型:0是图片,1是视频
     */
    private TYPE type;
    private long create_time;
    private String sn;
    private String qid;
    private String camera_name;

    private String date;//用来record展示列表的时候,存放日期
    public boolean isDateTitle_all;
    public boolean isDateTitle;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSn() {
        return sn;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public TYPE getType() {
        return type;
    }

    public void setType(TYPE type) {
        this.type = type;
    }


    public long getCreate_time() {
        return create_time;
    }

    public void setCreate_time(long create_time) {
        this.create_time = create_time;
    }
    
    public void setQid(String qid) {
    	this.qid = qid;
    }
    
    public String getQid() {
    	return qid;
    }


//    @Override
//    public int describeContents() {
//        return 0;
//    }

//    @Override
//    public void writeToParcel(Parcel dest, int flags) {
//        dest.writeInt(this.id);
//        dest.writeString(this.path);
//        dest.writeInt(this.type == null ? -1 : this.type.ordinal());
//        dest.writeLong(this.create_time);
//        dest.writeString(this.sn);
//        dest.writeString(this.qid);
//        dest.writeString(this.camera_name);
//    }

    public MediaFiles() {
    }

    @SuppressWarnings("unused")
    private MediaFiles(Parcel in) {
        this.id = in.readInt();
        this.path = in.readString();
        int tmpType = in.readInt();
        this.type = tmpType == -1 ? null : TYPE.values()[tmpType];
        this.create_time = in.readLong();
        this.sn = in.readString();
        this.qid = in.readString();
        this.camera_name = in.readString();
    }

    public String getCamera_name() {
        return camera_name;
    }

    public void setCamera_name(String camera_name) {
        this.camera_name = camera_name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDateTime() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String tmp = dateFormat.format(new Date(create_time));
        String dateLable = TimeUtilNew.getCustomStr(tmp);
        if(TextUtils.equals(tmp,dateLable)){
            dateFormat = new SimpleDateFormat("MM.dd");
            dateLable = dateFormat.format(create_time);
        }
        return dateLable;
    }
//    public static final Creator<MediaFiles> CREATOR = new Creator<MediaFiles>() {
//        public MediaFiles createFromParcel(Parcel source) {
//            return new MediaFiles(source);
//        }
//
//        public MediaFiles[] newArray(int size) {
//            return new MediaFiles[size];
//        }
//    };
}
