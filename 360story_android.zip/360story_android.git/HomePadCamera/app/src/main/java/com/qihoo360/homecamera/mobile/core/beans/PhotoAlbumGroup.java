
package com.qihoo360.homecamera.mobile.core.beans;

import android.provider.MediaStore.Images;
import android.provider.MediaStore.Video;
import android.text.TextUtils;

import java.util.HashMap;

public class PhotoAlbumGroup {
    public int orentation = 0;
    /**
     * 相册组ID
     */
    public String bucket_path = "";
    /**
     * 相册组ID
     */
    public String bucket_id = "";
    /**
     * 相册组名称
     */
    public String bucket_display_name = "";
    /**
     * 相册组数量
     */
    public int bucket_num = 0;
    /**
     * 相册组缩略图ID
     */
    /**thumbnail_id_xxx 无法区分是否视频还是图片的缩率图，建议换用字段thumbnail_uris[index]*/
    public int thumbnail_id = -1;
    /**thumbnail_id_xxx 无法区分是否视频还是图片的缩率图，建议换用字段thumbnail_uris[index]*/
    public int thumbnail_id_second = -1;
    /**thumbnail_id_xxx 无法区分是否视频还是图片的缩率图，建议换用字段thumbnail_uris[index]*/
    public int thumbnail_id_third = -1;
    /**thumbnail_id_xxx 无法区分是否视频还是图片的缩率图，建议换用字段thumbnail_uris[index]*/
    public int thumbnail_id_fourth = -1;
    
    /**thumbnail_id_xxx 无法区分是否视频还是图片的缩率图，故增加如下字段*/
    public HashMap<Integer, String>thumbnail_uris = new HashMap<Integer, String>();

    /**
     * 此相册最后更新时间
     */
    public String maxtime = "";

    public String mimeType = null;
    public String summary = "";

    public String getThumbnailUri(int position) {
        { // 如果新缩率图方案中存在指定项，优先使用
            String tmp = thumbnail_uris.get(position);
            if (null != tmp) {
                return tmp;
            }
        }
        
        if (!TextUtils.isEmpty(mimeType) && mimeType.startsWith("video/")) {
            if (position == 0) {
                return Video.Media.EXTERNAL_CONTENT_URI + "/" + thumbnail_id;
            } else if (position == 1) {
                return Video.Media.EXTERNAL_CONTENT_URI + "/" + thumbnail_id_second;
            } else if (position == 2) {
                return Video.Media.EXTERNAL_CONTENT_URI + "/" + thumbnail_id_third;
            } else {
                return Video.Media.EXTERNAL_CONTENT_URI + "/" + thumbnail_id_fourth;
            }
        } else {
            if (position == 0) {
                return Images.Media.EXTERNAL_CONTENT_URI + "/" + thumbnail_id;
            } else if (position == 1) {
                return Images.Media.EXTERNAL_CONTENT_URI + "/" + thumbnail_id_second;
            } else if (position == 2) {
                return Images.Media.EXTERNAL_CONTENT_URI + "/" + thumbnail_id_third;
            } else {
                return Images.Media.EXTERNAL_CONTENT_URI + "/" + thumbnail_id_fourth;
            }
        }
    }
}
