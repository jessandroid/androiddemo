package com.qihoo360.homecamera.mobile.activity;

import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.MD5Util;
import com.qihoo360.homecamera.mobile.utils.Utils;

/**
 * Created by wangshiyuan on 2016/11/15.
 */

public class ResetPasswordActivity extends BaseActivity implements View.OnClickListener, ActionListener {
    private ImageView mBackIv;
    private TextView mTitleTv;
    private EditText mEditPassword;
    private TextView mSavePassword;
    private TextView mTogglePassword;

    private String mSn = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activitiy_reset_password_layout);

        mSn = getIntent().getStringExtra("sn");

        init();
    }

    private void init(){
        mBackIv = (ImageView) findViewById(R.id.back_zone);
        mTitleTv = (TextView) findViewById(R.id.title_string);
        mTogglePassword = (TextView) findViewById(R.id.toggle_password);
        mSavePassword = (TextView) findViewById(R.id.save_password);
        mEditPassword = (EditText) findViewById(R.id.editText);

        //因为密码为空 初始化为enable false
        mSavePassword.setEnabled(false);

        mEditPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!TextUtils.isEmpty(s)) {
                    mSavePassword.setEnabled(true);
                } else {
                    mSavePassword.setEnabled(false);
                }
            }
        });

        mTitleTv.setText(getString(R.string.tips_108));

        Utils.ensuerSetOnclick(this, mBackIv, mTogglePassword, mSavePassword);

        GlobalManager.getInstance().getPadSettingManager().registerActionListener(this);
    }

    @Override
    public Object actionPerformed(int actionCode, Object... args) {
        switch (actionCode) {
            case Actions.PadSetting.SET_SETTING_PASSWORD_SUCCESS: {
                hideTipsDialog();
                CameraToast.show("设置成功", Toast.LENGTH_SHORT);
                finish();
                return Boolean.TRUE;
            }
            case Actions.PadSetting.SET_SETTING_PASSWORD_FAIL: {
                hideTipsDialog();
                CameraToast.show("网络不给力，请稍候再试。", Toast.LENGTH_SHORT);
                return Boolean.TRUE;
            }
        }
        return null;
    }

    @Override
    public int getProperty() {
        return 0;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.back_zone:
                back();
                break;
            case R.id.save_password:
                savePassword();
                break;
            case R.id.toggle_password:
                togglePassword(mEditPassword, mTogglePassword);
                break;
        }
    }

    private void savePassword(){
        String password = mEditPassword.getText().toString();
        if (TextUtils.isEmpty(password)){
            showCustomToast(getString(R.string.tips_110), Toast.LENGTH_SHORT);
            return;
        }

        if (password.length() < 6){
            showCustomToast(getString(R.string.tips_110), Toast.LENGTH_SHORT);
            return;
        }

        String convertPassword = getConvertPassword(password);

        if (!TextUtils.isEmpty(convertPassword)){
            String settingJson = "{\"password\": \"" + convertPassword + "\"}";

            if (Utils.isNetworkAvailable(this)) {
                showTipsDialog("设置中，请稍后...", R.drawable.icon_loading, true);
                GlobalManager.getInstance().getPadSettingManager().asyncSetIpcPassword(mSn, settingJson);
            } else {
                CameraToast.showToast(this, R.string.network_disabled);
            }
        }
    }

    public void togglePassword(EditText inputView, TextView indicator) {
        int type = inputView.getInputType();
        CLog.d("the type is :" + type);
        int nNormal = InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_NORMAL;
        int nPassword = InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD;
        if (type != nNormal) {
            type = nNormal;
            indicator.setText(R.string.app_pwd_hint);
        } else {
            type = nPassword;
            indicator.setText(R.string.app_pwd_show);
        }
        inputView.setInputType(type);
        inputView.setSelection(inputView.getText().length());
    }

    public final static String MD5_KEY = "360Robot_";

    private String getConvertPassword(String password){
        if (TextUtils.isEmpty(password)){
            return "";
        }

        String convertStr = MD5_KEY + password;

        return MD5Util.encode(convertStr).toUpperCase();
    }

    private void back(){
        finish();
    }

    @Override
    protected void onDestroy() {
        GlobalManager.getInstance().getPadSettingManager().removeActionListener(this);
        super.onDestroy();
    }
}
