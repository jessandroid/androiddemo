package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;

/**
 * Created by zhaojunbo on 2016/9/1.
 * desc:
 */
public class IpcAllEntity extends Head {

    public Data data;

    public static class Data implements android.os.Parcelable {

        public Settings settings;

        public static class Settings implements android.os.Parcelable {

            public String night_rest = "1";
            public String capture_video = "1";
            public String remote_view = "1";
            public String eye_protection = "1";

            @Override
            public int describeContents() {
                return 0;
            }

            @Override
            public void writeToParcel(Parcel dest, int flags) {
                dest.writeString(this.night_rest);
                dest.writeString(this.capture_video);
                dest.writeString(this.remote_view);
                dest.writeString(this.eye_protection);
            }

            public Settings() {
            }

            protected Settings(Parcel in) {
                this.night_rest = in.readString();
                this.capture_video = in.readString();
                this.remote_view = in.readString();
                this.eye_protection = in.readString();
            }

            public static final Creator<Settings> CREATOR = new Creator<Settings>() {
                @Override
                public Settings createFromParcel(Parcel source) {
                    return new Settings(source);
                }

                @Override
                public Settings[] newArray(int size) {
                    return new Settings[size];
                }
            };
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeParcelable(this.settings, flags);
        }

        public Data() {
        }

        protected Data(Parcel in) {
            this.settings = in.readParcelable(Settings.class.getClassLoader());
        }

        public static final Creator<Data> CREATOR = new Creator<Data>() {
            @Override
            public Data createFromParcel(Parcel source) {
                return new Data(source);
            }

            @Override
            public Data[] newArray(int size) {
                return new Data[size];
            }
        };
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeParcelable(this.data, flags);
    }

    public IpcAllEntity() {
    }

    protected IpcAllEntity(Parcel in) {
        super(in);
        this.data = in.readParcelable(Data.class.getClassLoader());
    }

    public static final Creator<IpcAllEntity> CREATOR = new Creator<IpcAllEntity>() {
        @Override
        public IpcAllEntity createFromParcel(Parcel source) {
            return new IpcAllEntity(source);
        }

        @Override
        public IpcAllEntity[] newArray(int size) {
            return new IpcAllEntity[size];
        }
    };
}
