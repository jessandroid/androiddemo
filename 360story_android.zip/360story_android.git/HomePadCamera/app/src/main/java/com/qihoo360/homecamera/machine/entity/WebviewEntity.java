package com.qihoo360.homecamera.machine.entity;

import java.util.ArrayList;

/**
 * Created by zhangtao-iri on 2016/12/16.
 */
public class  WebviewEntity {

    public static abstract class BaseWebviewEntity{
        public String action;
    }

    //----------------------native吐给webview的数据-----------------------------//
    //native告知webview 专辑信息
    public static class PlayAlbum extends BaseWebviewEntity{
        public Data data;
        public static class Data{
            public String unique; //专辑唯一标识
            public String name;  //专辑名称
            public int total;
            public String coverurl;
            public String category;
            public int type;
        }
    }

    //native告知webview 儿歌列表信息
    public static class SongAlbum extends BaseWebviewEntity{
        public Data data;
        public static class Data{
            public String unique;  //专辑唯一标识
            public String category;//分类信息
            public String title;    //专辑名称
            public int total;
            public String coverurl;
            public int type;
        }
    }

    //native告知webview 歌曲列表信息以及需要播第几首
    public static class PlaySong extends BaseWebviewEntity{
        public Data data;
        public static class Data{
            public String uniqueid;
            public String title;
            public String mediaurl;
            public String volume;
            public String srclogo;
            public int type;
            public String src;
            public String unique;
            public int pageid;
        }
    }

    //native告知webview 收藏或者取消收藏的操作
    public static class CollectSong extends BaseWebviewEntity{

        public Data data;

        public static class Data{
            public int collect; //1/0
            public String uniqueid;
            public String title;
            public String mediaurl;
            public String volume;
            public String srclogo;
            public int type;
            public String src;
            public String unique;
            public int pageid;
        }
    }

    public static class JumpAd extends BaseWebviewEntity{

        public Data data;

        public static class Data{
            public String url;
        }
    }

    //----------------------------end-------------------------------------------//



    //----------------------------webview吐给antive的数据----------------------//

    //告知native 歌曲播放状态
    public static class PlayStatus extends BaseWebviewEntity{

        public Data data;

        public static class Data{
            public String status;  //playing -> 正在播放  pause ->暂停
            public String uniqueid;
            public String title;
            public String mediaurl;
            public String volume;
            public String srclogo;
            public int type;
            public String src;
            public String unique;
            public int pageid;
        }
    }

    //告知native uid
    public static class PushUid extends  BaseWebviewEntity{
        public Data data;

        public static class Data{
            public String uid;     //uid
        }
    }


    //----------------------------- end -----------------------------------//
}
