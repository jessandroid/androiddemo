
package com.qihoo360.homecamera.machine.ui.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import android.widget.RelativeLayout;

import com.qihoo360.homecamera.machine.ui.widget.gallary.ZommTextureView;
import com.qihoo360.homecamera.mobile.utils.CLog;

public class VideoParentLayout extends RelativeLayout {

    public VideoParentLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        if (oldw == 0) {
            return;
        }
        CLog.e("cx_debug onSizeChanged w:" + w + " h:" + h + " oldw:" + oldw + " oldh:" + oldh);
        View v;
        for (int i = 0; i < getChildCount(); i++) {
            v = getChildAt(i);
            if (v instanceof ZommTextureView) {
                ((ZommTextureView) v).onParentSizeChanged();
                break;
            }
        }
    }

    @Override
    protected boolean drawChild(Canvas canvas, View child, long drawingTime) {
        try {
            return super.drawChild(canvas, child, drawingTime);
        } catch (Exception e) {
            e.printStackTrace();
            CLog.e(e.toString());
            return true;
        }
    }
}
