
package com.qihoo360.homecamera.machine.entity;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * @author Administrator
 */
public class CameraSettings implements Serializable {
    private static final long serialVersionUID = -9008909786148215023L;

    public int alarm;// 报警通知开关
    public int light;// LED通知开关
    public int sound;// 摄像头声音音量
    public int resolution;// 摄像头视频模式：0 超清   2高清  1流畅
    public int online;// 摄像头上线语音提示
    public int offline;// 摄像头离线语音提示
    public int check;// 有人查看语音提示
    public int inversion;// 摄像头倒置
    public int mirror; // 左右倒置
    public int mute; // 麦克风开关 0有声音 1静音
    public int moving = 0; // 报警开关
    public int overline; // 报警开关
    @SerializedName("motion")
    public int face; // 报警开关
    public int faceMode = 1;
    public String alarmTime = "0-0";// 报警时间
    public int upgrade;// 固件升级语音提示的开关
    public int ir;// 夜视参数
    public int night;//固件知道是晚上了


    public String ip; // 摄像机ip
    public String mac; // mac地址
    public int signal; // wifi信号强度
    public String ssid = ""; // wifi名称
    public String versionName = ""; // 摄像机型号

    public String cloudTime = "800-2000";
    public int cloud = 0;
    public int poweroff = 0;

    // 1 is image
    // 2 is video
    public int secureMode = ALERT_TYPE_IMAGE;

    public static final int ALERT_TYPE_VIDEO = 2;
    public static final int ALERT_TYPE_IMAGE = 1;

    /**
     * +08:00 北京
     * -05:00 纽约
     * +05:30 新德里
     * +00:00 伦敦
     */
    public String timezone; //从cmd 取下来的camera 信息中，如果timezone 不是空的表示支持，如果没有取到timezone 表示不支持。所以使用的时候请先判断是否为空。

    public int wakeup = -1; //语音唤醒开关 0关1开

    public int noise = -1; //异响开关 0关1开

    public int cry = -1; //哭声报警开关 0关1开

    public int fullscreen = -1;//未见人形  0关1开

    public int huajiaoVR = -1;//双目直播是否开启 0关1开

    @Override
    public String toString() {
        return "CameraSettings [alarm=" + alarm + ", light=" + light + ", sound=" + sound
                + ", online=" + online + ", offline=" + offline + ", check=" + check
                + ", inversion=" + inversion + ", moving=" + moving + ", overline=" + overline + ", face=" + face
                + ", alarmTime=" + alarmTime + ", cloudTime:" + cloudTime + ", cloud:" + cloud + ", poweroff=" + poweroff + ", versionName=" + versionName
                + "]";
    }

    public int getAlarm() {
        return alarm;
    }

    public void setAlarm(int alarm) {
        this.alarm = alarm;
    }

    public int getLight() {
        return light;

    }

    public void setLight(int light) {
        this.light = light;
    }

    public int getSound() {
        return sound;
    }

    public void setSound(int sound) {
        this.sound = sound;
    }

    public int getOnline() {
        return online;
    }

    public void setOnline(int online) {
        this.online = online;
    }

    public int getOffline() {
        return offline;
    }

    public void setOffline(int offline) {
        this.offline = offline;
    }

    public int getCheck() {
        return check;
    }

    public void setCheck(int check) {
        this.check = check;
    }

    public int getInversion() {
        return inversion;
    }

    public void setInversion(int inversion) {
        this.inversion = inversion;
    }

    public int getMirror() {
        return mirror;
    }

    public void setMirror(int mirror) {
        this.mirror = mirror;
    }

    public int getSecureMode() {
        return secureMode;
    }

    public void setSecureMode(int secureMode) {
        this.secureMode = secureMode;
    }

}
