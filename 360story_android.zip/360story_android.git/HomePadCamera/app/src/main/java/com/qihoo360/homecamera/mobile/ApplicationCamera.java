
package com.qihoo360.homecamera.mobile;

import android.app.job.JobScheduler;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.support.multidex.MultiDex;
import android.support.multidex.MultiDexApplication;
import android.telephony.TelephonyManager;
import android.text.TextUtils;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.model.GlideUrl;
import com.google.gson.Gson;
import com.nostra13.universalimageloader.cache.disc.naming.Md5FileNameGenerator;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.QueueProcessingType;
import com.qihoo.pushsdk.utils.AppContext;
import com.qihoo.pushsdk.utils.LogUtils;
import com.qihoo.sdk.report.QHStatAgent;
import com.qihoo360.accounts.base.common.DefaultLocalAccounts;
import com.qihoo360.accounts.sso.svc.QihooServiceController;
import com.qihoo360.homecamera.mobile.activity.BaseActivity;
import com.qihoo360.homecamera.mobile.activity.LoginAndRegisterActivity;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.config.DefaultClientConfig;
import com.qihoo360.homecamera.mobile.download.DownloadConfiguration;
import com.qihoo360.homecamera.mobile.download.DownloadManager;
import com.qihoo360.homecamera.mobile.entity.Head;
import com.qihoo360.homecamera.mobile.env.AppEnv;
import com.qihoo360.homecamera.mobile.exception.CrashHandler;
import com.qihoo360.homecamera.mobile.http.OkHttpUtils;
import com.qihoo360.homecamera.mobile.image.my.OkHttpsUrlLoader;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.service.JustalkService;
import com.qihoo360.homecamera.mobile.service.MessageService;
import com.qihoo360.homecamera.mobile.upload.UploadConfiguration;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CompatibilitySupport;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.utils.imageloader.CameraLoggedInUserImageDownloader;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.net.CookieHandler;
import java.net.CookiePolicy;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Stack;
import java.util.concurrent.TimeUnit;

public class ApplicationCamera extends MultiDexApplication {

    public static Context sContext;

    public static int SELF_UID = 0;

    public static String SELF_PKG_NAME = "com.qihoo360.homecamera.mobile";

    public static Stack<BaseActivity> activityStack;
    private boolean jiaApplicationExit = false;
    private InputStream ins;

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
        Utils.context = this;
        Utils.getInstance().init();
        sContext = this;
        SELF_UID = this.getApplicationInfo().uid;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        CLog.d("------------------->oncreate");
        CLog.e("zt", "application onCreate");

        String processName = Utils.getProcessName(this, android.os.Process.myPid());
        if (processName != null) {
            if (processName.equals("com.qihoo360.kibot")) {
                init();
            } else if (TextUtils.equals(processName, "com.qihoo360.kibot:PushClient")) {
                initPushApp();
            }
        }
    }

    private void initPushApp(){
        Utils.context = ApplicationCamera.this;
        AppContext.setContext(ApplicationCamera.this.getApplicationContext());
        LogUtils.init(AppContext.getContext());
        CrashHandler crashHandler = CrashHandler.getInstance();
        crashHandler.init(this);
    }

    private void init() {
        CLog.i("test2", "application init called");
        //QDAS初始化
        QHStatAgent.openActivityDurationTrack(this, false);
        //QHStatAgent.onError(this);
        QHStatAgent.setDefaultReportPolicy(this, 1);    //手动设置上传策略(0为下次启动时，1为按间隔)，注意此设置可能会被云控参数覆盖
        //QHStatAgent.setLocation(0, 0);  //设置设备当前所处经纬度。当用户已传入经纬度时，不再使用定位采集的功能（但用户必须在第一个onResume之前调用，否则只能对后续header产生影响，第一个header还是会使用定位功能）
        QHStatAgent.setLoggingEnabled(false);    //打开/关闭SDK的LogCat日志输出, enableLogging true 打开日志输出, false 关闭日志输出。默认为关闭
//        QHStatAgent.setDebugMode(this, false);     //打开/关闭SDK的调试模式。打开后，数据实时上传忽略上传策略中的时间间隔, enableLogging true 打开调试模式, false 关闭调试模式。默认为关闭
//        QHStatAgent.setBetaVersion(this, false);   //设置当前是否为测试版本，测试版本与正式版本使用不同的云控策略。比如可以设置测试版本中不采样，正式版中采样。
        loadOkHttp();

        //TODO 这里取得是那个用户登录的。
        SysConfig.init(this);
        GlobalManager.getInstance().init(this);
        // 实现SSO服务中的帐号接续服务
        QihooServiceController.installServiceHost(new DefaultLocalAccounts());
        // 初始化用户中心分配的from/sign key/encrypt key
        QihooServiceController.initAuthKeyParameter(DefaultClientConfig.FROM, DefaultClientConfig.SIGN_KEY, DefaultClientConfig.CRYPT_KEY);

        CrashHandler crashHandler = CrashHandler.getInstance();
        crashHandler.init(this);

        Glide.get(this)
                .register(GlideUrl.class, InputStream.class, new OkHttpsUrlLoader.Factory(OkHttpUtils.getInstance().getOkHttpClient()));

        initDownloader();

        ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(getApplicationContext())
                .threadPriority(Thread.NORM_PRIORITY - 2)
                .denyCacheImageMultipleSizesInMemory()
                .discCacheFileNameGenerator(new Md5FileNameGenerator())
                .tasksProcessingOrder(QueueProcessingType.LIFO)
                .imageDownloader(new CameraLoggedInUserImageDownloader(this))
                .build();
        ImageLoader.getInstance().init(config);

        if (BuildConfig.DEBUG) {
            getDeviceInfo(this);
        }
    }


    /**
     * 获取DeviceInfo
     *
     * @param context
     * @return
     */
    public static String getDeviceInfo(Context context) {
        try {
            TelephonyManager tm = (TelephonyManager) (context
                    .getSystemService(Context.TELEPHONY_SERVICE));
            String imei = tm == null ? "" : (tm.getDeviceId() == null ? "" : tm.getDeviceId());
            String androidId = android.provider.Settings.System.getString(context.getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);
            String serialNo = getDeviceSerial();
            String sImei2 = md5("" + imei + androidId + serialNo);
            CLog.e("DeviceInfo", sImei2 + "," + imei);
            return sImei2 + "," + imei;
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    private static String getDeviceSerial() {
        String serial = null;
        try {
            Class c = Class.forName("android.os.SystemProperties");
            Method get = c.getMethod("get", String.class);
            serial = (String) get.invoke(c, "ro.serialno");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return serial;
    }

    public static String md5(String str) {
        try {
            MessageDigest localMessageDigest = MessageDigest.getInstance("MD5");
            localMessageDigest.update(str.getBytes());
            byte[] arrayOfByte = localMessageDigest.digest();
            StringBuffer localStringBuffer = new StringBuffer(64);
            for (int i = 0; i < arrayOfByte.length; i++) {
                int j = 0xFF & arrayOfByte[i];
                if (j < 16)
                    localStringBuffer.append("0");
                localStringBuffer.append(Integer.toHexString(j));
            }
            return localStringBuffer.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return "";
    }

    private void initDownloader() {
        DownloadConfiguration configuration = new DownloadConfiguration();
        configuration.setMaxThreadNum(5);
        configuration.setThreadNum(3);
        DownloadManager.getInstance().init(getApplicationContext(), configuration);
    }


    @Override
    public void onTerminate() {
        super.onTerminate();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        Glide.with(this).onDestroy();
    }

    private InputStream insCer;
    private void loadOkHttp() {
        try {
            java.net.CookieManager cookieManager = new java.net.CookieManager();
            cookieManager.setCookiePolicy(CookiePolicy.ACCEPT_ALL);
            CookieHandler.setDefault(cookieManager);
            AssetManager am = Utils.getContext().getAssets();
//            ins = am.open("wildcard.jia.360.cn_bundle.crt");
//            insCer = am.open("ssl.qhmsg.com.cer");
//            OkHttpUtils.getInstance().setCertificates(ins, insCer);
            OkHttpUtils.getInstance().debug(AppEnv.DEBUG).setConnectTimeout(DefaultClientConfig.HTTP_TIME_OUT, TimeUnit.MILLISECONDS);
            UploadConfiguration uploadConfiguration = new UploadConfiguration();
            uploadConfiguration.setMaxThreadNum(10);
            uploadConfiguration.setThreadNum(3);
            OkHttpUtils.postFile2OOS().init(uploadConfiguration);
        }
//        catch (IOException e) {
//            e.printStackTrace();
//            CLog.d(e.getMessage());
//        }
        finally {
            if (ins != null) {
                try {
                    ins.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if (insCer != null) {
                try {
                    insCer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void addActivity(BaseActivity activity) {
        if (activityStack == null) {
            activityStack = new Stack<BaseActivity>();
            CLog.e("stack", "new Stack");
        }
        activityStack.add(activity);
        CLog.e("stack", "addActivity");
    }

    public BaseActivity currentActivity() {
        BaseActivity activity = activityStack.lastElement();
        return activity;
    }

    public void finishActivity() {
        BaseActivity activity = activityStack.lastElement();
        finishActivity(activity);
    }

    public void finishActivity(BaseActivity activity) {
        if (activity != null) {
            activityStack.remove(activity);
            CLog.e("stack", "remove");
            activity = null;
        }
    }

    public void finishAllActivity() {
        CLog.e("stack", "finishAllActivity()" + (activityStack == null));
        for (int i = 0, size = activityStack.size(); i < size; i++) {
            if (i < activityStack.size()) {
                if (null != activityStack.get(i)) {
                    activityStack.get(i).finish();
                }
            }
        }
        activityStack.clear();
        CLog.e("stack", "activityStack.clear");
    }

    public void AppExit() {
        try {
            finishAllActivity();
//            stopService(new Intent(this, JustalkService.class));
        } catch (Exception e) {
        }
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        CLog.d(level);
        Glide.with(this).onTrimMemory(level);
        if (level >= TRIM_MEMORY_BACKGROUND) {
            Glide.with(this).onLowMemory();
        }
    }

    public void logout() {
        finishAllActivity();
        GlobalManager.logout(Utils.getContext());
        stopService(new Intent(this, JustalkService.class));
        stopService(new Intent(this, MessageService.class));
        if (CompatibilitySupport.isGreatOrEqual50()) {
            JobScheduler jobScheduler = (JobScheduler) getSystemService(JOB_SCHEDULER_SERVICE);
            jobScheduler.cancelAll();
        }
    }

    public void logoutWithRequest(RequestErrorCallBack requestErrorCallBack) {
        CLog.e("stack", "logoutWithRequest");
        Constants.IS_LOGIN = false;
        final String string = requestErrorCallBack.geterror();
        Gson gson = new Gson();
        final Head head = gson.fromJson(string, Head.class);
        long time = head.time;
        switch (head.errorCode) {
            case Constants.Http.VERIFY_QT_ERROR:
            case Constants.Http.SID_OUTDATE_ERROR:
                Intent i = new Intent(this, LoginAndRegisterActivity.class);
                i.putExtra("switch", true);
                i.putExtra("time", time);
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                CLog.e("stack", "logoutWithRequest------->logout:SID_OUTDATE_ERROR");
                logout();
                startActivity(i);
                break;
            case Constants.Http.SID_OUTDATE_OUTSIDE_ERROR:
                logout();
                CLog.e("stack", "logoutWithRequest------->logout:SID_OUTDATE_OUTSIDE_ERROR");
                break;
        }
    }

    public boolean isJiaApplicationExit() {
        return jiaApplicationExit;
    }

    public void setJiaApplicationExit(boolean isCamApplicationExit) {
        this.jiaApplicationExit = isCamApplicationExit;
    }

    public interface RequestErrorCallBack {
        String geterror();
    }


}
