package com.qihoo360.homecamera.mobile.activity;

import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.FragmentActivity;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qihoo.sdk.report.QHStatAgent;
import com.qihoo360.accounts.api.auth.model.UserTokenInfo;
import com.qihoo360.accounts.api.auth.p.ClientAuthKey;
import com.qihoo360.homecamera.mobile.ApplicationCamera;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.config.DefaultClientConfig;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.service.JustalkService;
import com.qihoo360.homecamera.mobile.ui.dialog.BaseDialogFactory;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.DensityUtil;
import com.qihoo360.homecamera.mobile.utils.Preferences;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.widget.CamAlertDialog;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/1/15
 * Time: 17:23
 * To change this template use File | Settings | File Templates.
 */
public class AccountActivity extends FragmentActivity {

    private CamAlertDialog tipsDialog;
    private Handler mShowTipsDialogHandler = new Handler();
    private IOnTipsDialogDismiss mIOnTipsDialogDismiss;
    private TextView mToastTv;
    private ImageView mIconIv;
    public static final String ACTION_LOGIN_DONE = "com.kindroid.sso.ACTION_LOGIN_DONE";
    // public SharedPreferences mPref;
    private final boolean mTaskCancelled = false;

    private final boolean mIsTablet = false;

    public ClientAuthKey mAuthKey;
    private Runnable mDelayRunnable;

    BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            finish();
        }
    };
    private BaseDialogFactory mCommonDialogFactory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mAuthKey = new ClientAuthKey(DefaultClientConfig.FROM, DefaultClientConfig.SIGN_KEY, DefaultClientConfig.CRYPT_KEY);
        mDelayRunnable = new Runnable() {
            @Override
            public void run() {
                if (tipsDialog != null) {
                    tipsDialog.dismiss();
                }
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_LOGIN_DONE);
        registerReceiver(mReceiver, filter);

        if (!Preferences.getShowGuide()) {
            GuideActivity.startActivity(this);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        QHStatAgent.onResume(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        QHStatAgent.onPause(this);
    }

    @Override
    protected void onDestroy() {
        unregisterReceiver(mReceiver);
        hideTipsDialog();
        tipsDialog = null;
        if (mCommonDialogFactory != null) {
            mCommonDialogFactory.destory();
            mCommonDialogFactory = null;
        }
        CLog.d("onDestroy hideProgressDialog");
        super.onDestroy();
    }

    public void showProgressDialog(String msg) {

    }

    protected void showProgressDialog() {
        showProgressDialog(getString(R.string.waiting));
    }

    public void hideProgressDialog() {
        if(isFinishing()) {
            return;
        }

    }



    public void startMainActivity(final UserTokenInfo info, final String sessionId, final String pushKey, final String Pwd, final String Id) {
        if (mTaskCancelled) {
            return;
        }
        if (info != null && sessionId != null) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    AccUtil.getInstance().setSessionIdAndPushKeyAndPwd(sessionId, pushKey, Pwd, Id);
                    CLog.e("push", "setSessionIdAndPushKeyAndPwd:" + sessionId + ":" + pushKey);
                    startService(new Intent(AccountActivity.this, JustalkService.class));
                }
            }).start();
            AccUtil.getInstance().setVerify(false);

            ((ApplicationCamera) getApplication()).setJiaApplicationExit(false);
            GlobalManager.getInstance().init(getApplication());
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            CLog.e("check", "AccountActivity");
            finish();
        }

    }

    public void startMainActivityFromShare(final UserTokenInfo info, final String sessionId, final String pushKey,
                                           String shareCode) {
    }

    public void hideTipsDialog() {
        if (tipsDialog != null) {
            mShowTipsDialogHandler.removeCallbacks(mDelayRunnable);
            tipsDialog.dismiss();
        }
    }

    public void showTipsDialog(String msg, int icon, int delay, boolean rotate) {
        showTipsDialog(msg, icon, delay);
        if (rotate) {
            Animation anim = AnimationUtils.loadAnimation(this, R.anim.rotate_icon);
            mIconIv.startAnimation(anim);
        }
    }

    public void showTipsDialog(String msg, int icon, boolean rotate) {
        showTipsDialog(msg, icon);
        if (rotate) {
            Animation anim = AnimationUtils.loadAnimation(this, R.anim.rotate_icon);
            mIconIv.startAnimation(anim);
        }
    }

    public void showTipsDialog(String msg, int icon, int delay) {
        showTipsDialog(msg, icon);
        mShowTipsDialogHandler.postDelayed(mDelayRunnable, delay);
    }

    public void showTipsDialog(String msg, int icon) {
        if (tipsDialog != null) {
            tipsDialog.dismiss();
        }
        tipsDialog =
                new CamAlertDialog(this, R.style.NewDialog, true);
        Window w = tipsDialog.getWindow();
        WindowManager.LayoutParams lp = w.getAttributes();
        lp.y = -DensityUtil.dip2px(80);
        View content = getLayoutInflater().inflate(R.layout.tips_toast_dialog, null);
        mToastTv = (TextView) content.findViewById(R.id.stv_toast);
        mIconIv = (ImageView) content.findViewById(R.id.iv_icon);
        mToastTv.setText(msg);
        mIconIv.setImageResource(icon);
        tipsDialog.setContentView(content);
        tipsDialog.setCancelable(true);
        tipsDialog.setCanceledOnTouchOutside(false);
        tipsDialog.show();
        tipsDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                if (mIOnTipsDialogDismiss != null) {
                    mIOnTipsDialogDismiss.onDismiss();
                }
            }
        });
    }

    public void setOnTipsDialogDismiss(IOnTipsDialogDismiss iOnTipsDialogDismiss) {
        mIOnTipsDialogDismiss = iOnTipsDialogDismiss;
    }

    interface IOnTipsDialogDismiss {
        public void onDismiss();
    }

    public Dialog showCommonDialog(String title, String content, String leftButton, String rightButton, String checkContent, boolean needCheckBox, final ICommonDialog iCommonDialog, boolean canCancel) {
        Dialog dialog = showCommonDialog(title, content, leftButton, rightButton, checkContent, needCheckBox, iCommonDialog);
        dialog.setCancelable(canCancel);
        return dialog;
    }

    public Dialog showCommonDialog(String title, String content, String leftButton, String rightButton, String checkContent, boolean needCheckBox, final ICommonDialog iCommonDialog) {
        if (TextUtils.isEmpty(title)) {
            title = getString(R.string.tips_47);
        }
        if (mCommonDialogFactory != null) {
            mCommonDialogFactory.destory();
            mCommonDialogFactory = null;
        }
        mCommonDialogFactory = new BaseDialogFactory(this, R.layout.remove_device_dialog);
        Dialog mDialog = mCommonDialogFactory.createDialog();
        mCommonDialogFactory.setMarginLeftAndRight(46f);
        mDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {

            @Override
            public void onCancel(DialogInterface dialog) {
                iCommonDialog.onDialogCancel();
                mCommonDialogFactory = null;
            }
        });
        View view = mCommonDialogFactory.getDialogContentView();
        TextView btnOK = (TextView) view.findViewById(R.id.remove_device_dialog_ok);

        TextView btnCancle = (TextView) view.findViewById(R.id.remove_device_dialog_cancel);
        RelativeLayout remove_device_dialog_ok_zone = (RelativeLayout) view.findViewById(R.id.remove_device_dialog_ok_zone);
        TextView titleTv = (TextView) view.findViewById(R.id.remove_device_dialog_tips);
        RelativeLayout remove_device_dialog_cancel_zone = (RelativeLayout) view.findViewById(R.id.remove_device_dialog_cancel_zone);
        TextView contentTv = (TextView) view.findViewById(R.id.remove_device_dialog_content);
        final CheckBox saveDataCb = (CheckBox) view.findViewById(R.id.cb_save_data);
        LinearLayout checkAreaLl = (LinearLayout) view.findViewById(R.id.ll_check_area);
        TextView checkContentTv = (TextView) view.findViewById(R.id.tv_check_content);
        View dividerView = findViewById(R.id.divider);
        if (TextUtils.isEmpty(title)) {
            titleTv.setVisibility(View.GONE);
        } else {
            titleTv.setText(title);
        }
        if (TextUtils.isEmpty(leftButton)) {
            Utils.ensureVisbility(View.GONE, remove_device_dialog_ok_zone, dividerView);
            remove_device_dialog_cancel_zone.setBackgroundResource(R.drawable.pop_win_round_bg_left_right);
        } else {
            btnOK.setText(leftButton);
        }
        contentTv.setText(content);
        btnCancle.setText(rightButton);
        checkContentTv.setText(checkContent);

        checkAreaLl.setVisibility(needCheckBox ? View.VISIBLE : View.GONE);
        btnOK.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                iCommonDialog.onLeftButtonClick(saveDataCb.isChecked());
                mCommonDialogFactory.destory();
            }
        });
        btnCancle.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                iCommonDialog.onRightButtonClick(saveDataCb.isChecked());
                mCommonDialogFactory.destory();
            }
        });
        mCommonDialogFactory.show();
        return mDialog;
    }

    public interface ICommonDialog {
        public void onRightButtonClick(boolean isChecked);
        public void onLeftButtonClick(boolean isChecked);
        public void onDialogCancel();
    }
}
