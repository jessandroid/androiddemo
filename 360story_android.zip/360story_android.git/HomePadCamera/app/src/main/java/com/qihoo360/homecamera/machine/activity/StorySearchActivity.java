package com.qihoo360.homecamera.machine.activity;

import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;

import com.qihoo360.homecamera.device.config.StoryMachineConsts;
import com.qihoo360.homecamera.machine.fragment.StorySearchFragment;
import com.qihoo360.homecamera.mobile.R;

/**
 * Created by zhangtao-iri on 2017/3/3.
 */
public class StorySearchActivity extends MachineBaseActivity {
//    private StorySearchFragment mStorySearchFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_machine_songlist);

        boolean isOnline = getIntent().getBooleanExtra("isOnline", false);
        String device_type = getIntent().getStringExtra(StoryMachineConsts.KEY_SET_DEVICE_TYPE);
        StorySearchFragment mStorySearchFragment = StorySearchFragment.newInstance(isOnline);
        Bundle bundle = new Bundle();
        bundle.putString(StoryMachineConsts.KEY_SET_DEVICE_TYPE,device_type);
        mStorySearchFragment.setArguments(bundle);

        FragmentTransaction beginTransaction = getSupportFragmentManager().beginTransaction();
        beginTransaction.replace(R.id.common_fragment, mStorySearchFragment).commitAllowingStateLoss();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }


//    private void setDeviceType(){
//        boolean isOnline = getIntent().getBooleanExtra("isOnline", false);
//        String device_type = getIntent().getStringExtra(StoryMachineConsts.KEY_SET_DEVICE_TYPE);
//        StorySearchFragment mStorySearchFragment = StorySearchFragment.newInstance(isOnline);
//        Bundle bundle = new Bundle();
//        bundle.putString(StoryMachineConsts.KEY_SET_DEVICE_TYPE,device_type);
//        mStorySearchFragment.setArguments(bundle);
//
//    }
}
