package com.qihoo360.homecamera.machine.popwin;

import android.view.View;

import com.qihoo360.homecamera.machine.fragment.StoryPlayerFragment;
import com.qihoo360.homecamera.mobile.R;

/**
 * Created by lixin3-s on 2016/11/16.
 */
public class DefaultDialog extends BaseDialog{

    private int mLayoutId;

    public DefaultDialog(StoryPlayerFragment fragment, View parent, boolean onlyShowOkButton, int layoutId) {
        super(fragment, parent, onlyShowOkButton);
        this.mLayoutId = layoutId;
        setContainer(mLayoutId);
    }

    @Override
    void initContainerView() {

    }
}
