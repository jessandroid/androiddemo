package com.qihoo360.homecamera.machine.config;

public class MainActivityLifecycleConfigVar {

    public static int Show_Check_Shine_Prompt_Count = 0;

    public static boolean Prompt_TO_Bind_Phone = false;

    public static void reset() {
        Show_Check_Shine_Prompt_Count = 0;
        Prompt_TO_Bind_Phone = false;
    }
}
