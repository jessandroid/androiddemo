package com.qihoo360.homecamera.mobile.entity;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/4/20
 * Time: 18:04
 * To change this template use File | Settings | File Templates.
 */
public class Setting {
    public String name;
    public int draw;
}
