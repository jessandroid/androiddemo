
package com.qihoo360.homecamera.machine.activity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.text.Html;
import android.text.SpannableString;
import android.text.Spanned;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ViewFlipper;

import com.qihoo360.homecamera.device.config.StoryMachineConsts;
import com.qihoo360.homecamera.machine.ui.widget.CirclePageIndicator;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.SysConfig;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.DensityUtil;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.widget.CamAlertDialog;
import com.qihoo360.homecamera.mobile.widget.CenteredImageSpan;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import rx.Observable;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;
import rx.subscriptions.CompositeSubscription;

public class SetupGuideActivity extends MachineBaseActivity implements View.OnClickListener {
    private ViewFlipper vfAddGuide;
    private Button btnPowerNext;
    private Button btnResetNext, btn_home_start;
    private TextView tv_add_title;
    private View add_title;
    private SoundPool soundPool;
    private HashMap<Integer, Integer> soundPoolMap;
    private AnimationDrawable animationGreen;
    private int playStreamId;
    private AudioManager mgr;
    private String from;
    private String setup_from;//
    private TextView mPowerErrorView;
    private TextView mHeadDiErrorView;
    private Bitmap addBgBmp, guide1Bmp, guide2BmpNormal, guide2BmpNight, greenBmp;
    private ViewPager mStep2Pager;
    private MediaPlayer mediaPlayer;
    private int mDirectSource = 0;
    private ImageView imgGreen;
    private ImageView imgSettingBig;
    private CompositeSubscription mLoadDataSubscription;
    private Subscription greenSubscription;
    private Subscription settingSubscription;

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            CLog.i("test1", "msg receiver");
            soundPool.stop(playStreamId);
            if (msg.what == 1) {
                playSound(1, 0);
            } else if (msg.what == 2) {
                playSound(2, 0);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        from = getIntent().getStringExtra("from");
        setup_from = getIntent().getStringExtra(StoryMachineConsts.KEY_SET_WIFI_FROM);
        initView();
        setView();
        initSounds();//设置入口

        mDirectSource = getIntent().getIntExtra("directSource", 0);
        onClick(btn_home_start);
    }

    private void initView() {
        setTintManagerQWork(true);
        tintManager.setStatusBarTintColor(Color.parseColor("#0000aeff"));
        setContentView(R.layout.activity_add_machine_guide);

        ImageView addBg = (ImageView) findViewById(R.id.add_camera_bg);
        addBg.setMaxWidth(SysConfig.BASE_SCREEN_WIDTH);
        addBg.setMaxHeight(SysConfig.BASE_SCREEN_HEIGHT);
        addBgBmp = Utils.getBitmap(R.drawable.bg_machine_add);
        addBg.setImageBitmap(addBgBmp);

        vfAddGuide = (ViewFlipper) findViewById(R.id.vf_add_guide);
        mPowerErrorView = (TextView) findViewById(R.id.btn_power_on_error);
        mHeadDiErrorView = (TextView) findViewById(R.id.btn_hear_di_error);
        btnPowerNext = (Button) findViewById(R.id.btn_power_next);
        btnResetNext = (Button) findViewById(R.id.setp_2_next_btn);
        btn_home_start = (Button) findViewById(R.id.btn_home_start);

        add_title = findViewById(R.id.add_title);
        tv_add_title = (TextView) findViewById(R.id.tv_add_title);

        ImageView img1 = (ImageView) findViewById(R.id.setup_guide_1_img);
        guide1Bmp = Utils.getBitmap(R.drawable.img_add_camera_front);
        img1.setImageBitmap(guide1Bmp);

        imgGreen = (ImageView) findViewById(R.id.setup_guide_1_img_green);
        greenBmp = Utils.getBitmap(R.drawable.img_add_camera_front_green);
        imgGreen.setImageBitmap(greenBmp);

        WizardPagerAdapter adapter = new WizardPagerAdapter();
        mStep2Pager = (ViewPager) findViewById(R.id.step_2_pager);
        mStep2Pager.setAdapter(adapter);
        mStep2Pager.setCurrentItem(0);

        CirclePageIndicator indicator = ((CirclePageIndicator) findViewById(R.id.step_2_pager_indicator));
        indicator.setViewPager(mStep2Pager);
        indicator.setCentered(true);
        indicator.setRadius(DensityUtil.dip2px(5));
        indicator.setFillColor(getResources().getColor(R.color.white));
        indicator.setPageColor(getResources().getColor(R.color.transclucent));
        indicator.setStrokeColor(getResources().getColor(R.color.transparent));

        mLoadDataSubscription = new CompositeSubscription();
    }

    private void setView() {
        add_title.setVisibility(View.GONE);
        // TODO 从CameraSettingsActivity入口过来的话，此处另行处理
//        if (CameraSettingsActivity.class.getName().equals(from)) {
//            ((TextView) findViewById(R.id.add_guide0_title)).setText(R.string.add_set_my);
//            btn_home_start.setText(R.string.set_my_capacity_camera);
//        } else {
//            onClick(btn_home_start);
//        }

        mPowerErrorView.setText(Html.fromHtml("<u>" + getString(R.string.confirm_power_on_error)
                + "</u>"));
        mHeadDiErrorView.setText(Html.fromHtml("<u>" + getString(R.string.confirm_hear_di_error)
                + "</u>"));
        mPowerErrorView.setOnClickListener(this);
        mHeadDiErrorView.setOnClickListener(this);
        btn_home_start.setOnClickListener(this);
        btnPowerNext.setOnClickListener(this);
        btnResetNext.setOnClickListener(this);
    }

    private void initAudio() {
        if (mgr == null) {
            mgr = (AudioManager) this.getSystemService(Context.AUDIO_SERVICE);
            mgr.setSpeakerphoneOn(true);
            mgr.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
        }
    }

    @SuppressLint("UseSparseArrays")
    public void initSounds() {
        initAudio();
        float streamVolumeCurrent = mgr.getStreamVolume(AudioManager.STREAM_MUSIC);
        float streamVolumeMax = mgr.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        if (streamVolumeCurrent / streamVolumeMax < 0.6) {
            mgr.setStreamVolume(AudioManager.STREAM_MUSIC, mgr.getStreamMaxVolume(AudioManager.STREAM_MUSIC) * 6 / 10,
                    0);
        }
        soundPool = new SoundPool(2, AudioManager.STREAM_MUSIC, 0);
        soundPoolMap = new HashMap<Integer, Integer>();
        soundPoolMap.put(1, soundPool.load(this, R.raw.reset, 1));
        soundPoolMap.put(2, soundPool.load(this, R.raw.greed, 1));
        mediaPlayer = MediaPlayer.create(this, R.raw.greed);
    }

    public void playSound(int sound, int loop) {

        float streamVolumeCurrent = mgr.getStreamVolume(AudioManager.STREAM_MUSIC);
        float streamVolumeMax = mgr.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        float volume = streamVolumeCurrent / streamVolumeMax;
        if (sound == 1) {
            playStreamId = soundPool.play(soundPoolMap.get(sound), volume, volume, 1, loop, 1f);
        } else {
            if (mediaPlayer == null) {
                mediaPlayer = MediaPlayer.create(this, R.raw.greed);
            }
            CLog.i("test2", "/***volume****/ = " + volume);
            mediaPlayer.setVolume(volume, volume);
            mediaPlayer.start();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        String from = intent.getStringExtra("from");
        if ("behind".equals(from)) {
            vfAddGuide.setDisplayedChild(2);
            startTitlePreAnimation(tv_add_title, getString(R.string.add_second_step),
                    getString(R.string.add_first_step));
        }else{
            vfAddGuide.setDisplayedChild(1);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        handler.removeMessages(1);
        handler.removeMessages(2);
        soundPool.stop(playStreamId);
        mediaStop();
        if(mLoadDataSubscription!=null){
            mLoadDataSubscription.clear();
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        initAudio();
        startGreenAnimation();
        startSetingAnimation();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (addBgBmp != null) {
            addBgBmp.recycle();
        }
        if (guide1Bmp != null) {
            guide1Bmp.recycle();
        }
        if (guide2BmpNormal != null) {
            guide2BmpNormal.recycle();
        }
        if (guide2BmpNight != null) {
            guide2BmpNight.recycle();
        }
        if (mediaPlayer != null) {
            mediaPlayer.release();
        }
        if (soundPool != null) {
            soundPool.release();
        }
        if(mLoadDataSubscription!=null){
            mLoadDataSubscription.clear();
        }
    }

    public void onNext(View v) {

    }

    public void OnCommit(View v) {
    }

    public void onBack(View view) {
        switch (vfAddGuide.getDisplayedChild()) {
            case 0:
                finish();
                overridePendingTransition(R.anim.left_in, R.anim.right_out);
                break;
            case 1:
                add_title.setVisibility(View.GONE);
                soundPool.stop(playStreamId);
                finish();
                overridePendingTransition(R.anim.left_in, R.anim.right_out);
                break;
            default:
                vfAddGuide.showPrevious();
                mediaStop();
                soundPool.stop(playStreamId);
                break;
        }
    }

    private void mediaStop() {
        try {
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.stop();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            //
            case R.id.btn_home_start:
                vfAddGuide.showNext();
                add_title.setVisibility(View.VISIBLE);
                Animation a = AnimationUtils.loadAnimation(this, R.anim.right_in);
                tv_add_title.startAnimation(a);
                handler.sendEmptyMessageDelayed(1, 500);
                break;

            //绿灯闪烁设置完毕
            case R.id.btn_power_next:
                mediaStop();
                soundPool.stop(playStreamId);
                Intent intent = new Intent(this, CameraSettingsWifiActivity.class);
                intent.putExtra("from", "front");
                intent.putExtra(StoryMachineConsts.KEY_SET_WIFI_FROM,setup_from);
                startActivity(intent);
                overridePendingTransition(0, 0);
                break;

            //已经收到提示音
            case R.id.setp_2_next_btn:
                add_title.setVisibility(View.VISIBLE);
                vfAddGuide.showNext();
                handler.sendEmptyMessageDelayed(2, 500);
                break;

            //
            case R.id.btn_power_on_error:
                showError(R.layout.item_setup_guide_1_toast);
                break;

            case R.id.btn_hear_di_error:
                showError(R.layout.item_setup_guide_2_toast);
                break;
            default:
                break;
        }
    }

    public void showError(int layoutID) {
        LayoutInflater inflater = LayoutInflater.from(this);
        View viewDialog = inflater.inflate(layoutID, null);
        View closeBtn = viewDialog.findViewById(R.id.toast_close_iv);
        TextView noVoiceTip = (TextView) viewDialog.findViewById(R.id.no_voide_tip1);
        SpannableString spannableString = new SpannableString(getString(R.string.no_voice_tip1));
        CenteredImageSpan imgSpanLeft = new CenteredImageSpan(this, R.drawable.button_left);
        CenteredImageSpan imgSpanRight = new CenteredImageSpan(this, R.drawable.button_right);
        spannableString.setSpan(imgSpanLeft, 11, 12, Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
        spannableString.setSpan(imgSpanRight, 15, 16, Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
        noVoiceTip.setText(spannableString);
        final CamAlertDialog camAlertDialog = new CamAlertDialog(this, R.style.Dialog_Fullscreen);
        camAlertDialog.setContentView(viewDialog);
        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                camAlertDialog.dismiss();
            }
        });
        camAlertDialog.show();
    }

    @Override
    public void onBackPressed() {
        onBack(null);
    }

    public class WizardPagerAdapter extends PagerAdapter {
        private List<View> mListViews;

        public WizardPagerAdapter() {

            LayoutInflater inflater = LayoutInflater.from(SetupGuideActivity.this);
            View viewNormal = inflater.inflate(R.layout.item_setup_guide_2_normal_multi, null);
            mListViews = new ArrayList<View>();
            mListViews.add(viewNormal);
//            mListViews.add(viewNight);
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView(mListViews.get(position));// 删除页卡
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {    // 这个方法用来实例化页卡
            container.addView(mListViews.get(position), 0);// 添加页卡
            imgSettingBig = (ImageView) mListViews.get(position).findViewById(R.id.seting_img_big);
            startSetingAnimation();
            return mListViews.get(position);
        }

        @Override
        public int getCount() {
            return mListViews.size();// 返回页卡的数量
        }

        @Override
        public boolean isViewFromObject(View arg0, Object arg1) {
            return arg0 == arg1;// 官方提示这样写
        }
    }

    private void startGreenAnimation(){
        if(greenSubscription==null || (greenSubscription!=null && greenSubscription.isUnsubscribed())){
            greenSubscription = Observable.interval(500, TimeUnit.MILLISECONDS).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Subscriber<Long>() {
                @Override
                public void onCompleted() {

                }

                @Override
                public void onError(Throwable e) {

                }

                @Override
                public void onNext(Long aLong) {
                    CLog.e("test","long:"+aLong);
                    if(imgGreen!=null && imgGreen.getVisibility()==View.VISIBLE){
                        Utils.ensureVisbility(imgGreen, View.GONE);
                    }else if(imgGreen!=null && imgGreen.getVisibility()==View.GONE){
                        Utils.ensureVisbility(imgGreen, View.VISIBLE);
                    }
                }
            });
            mLoadDataSubscription.add(greenSubscription);
        }
    }

    private void startSetingAnimation(){
        if(settingSubscription==null || (settingSubscription!=null && settingSubscription.isUnsubscribed())){
            settingSubscription = Observable.interval(500, TimeUnit.MILLISECONDS).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Subscriber<Long>() {
                @Override
                public void onCompleted() {

                }

                @Override
                public void onError(Throwable e) {

                }

                @Override
                public void onNext(Long aLong) {
                    CLog.e("test","setting long:"+aLong);
                    if(imgSettingBig!=null && imgSettingBig.getVisibility()==View.VISIBLE){
                        Utils.ensureVisbility(imgSettingBig, View.GONE);
                    }else if(imgSettingBig!=null && imgSettingBig.getVisibility()==View.GONE){
                        Utils.ensureVisbility(imgSettingBig, View.VISIBLE);
                    }
                }
            });
            mLoadDataSubscription.add(settingSubscription);
        }
    }
}
