
package com.qihoo360.homecamera.machine.play;

import android.text.TextUtils;

import com.qihoo.jia.play.jnibase.JPlayer;
import com.qihoo.jia.play.jnibase.LiveSession;
import com.qihoo.jia.play.jnibase.PlayerConsts;
import com.qihoo.jia.play.oper.GL2VideoView;
import com.qihoo360.homecamera.machine.config.MachineDefaultClientConfig;
import com.qihoo360.homecamera.machine.entity.Relay;
import com.qihoo360.homecamera.machine.play.audio.VqeLookupTable;
import com.qihoo360.homecamera.machine.preferences.Preferences;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.config.Const;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.net.MachineApi;
import com.qihoo360.homecamera.mobile.entity.Head;
import com.qihoo360.homecamera.mobile.entity.MediaFiles;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.FileUtil;
import com.qihoo360.homecamera.mobile.utils.Utils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import rx.Observable;
import rx.Subscriber;
import rx.schedulers.Schedulers;

/**
 * Created by wangdan-qhwl on 2015/12/14.
 */
public class RealTimeManager extends APlayManager {
    // region Param

    public class PlayParam {
        public static final String CONNECT_MASTER = "connect_master";
        public static final String CHANGE_RESO = "change_reso";
        public static final String SET_RECORD_TIME = "set_record_time";
    }

    private final int SRC_TYPE = 1001;

    private Relay mRelay;
    private LiveSession mLiveSession;
    private int mAudioSource = LiveSession.AudioRecordSourceType.TYPE_NONE;
    private int mTalkMode = 0;

    private int mCloudEventFlag;
    private boolean isNewFirmware;

    private boolean mIsTalk = false;
    private boolean mIsResoSetting = false;
    public int mCurrentReso = -1;

    private boolean isSetStart;

    // SD
    public long mPlayTime;

    private String mDeviceType;

    private volatile boolean mPaused;

    // endregion

    // region Init

    private LiveSession.JP2PInfo mJP2PInfo;

    private boolean talkNoVoiceShowed;

    public RealTimeManager(String cameraSn, String title, int streamVersion, PlayTypes playType, boolean defaultAllowSound) {
        super(playType, defaultAllowSound);
        mCameraSN = cameraSn;
        mVideoTitle = title;
        mStreamVersion = streamVersion;
        mIdentify = mCameraSN;
        CLog.d("STREAMV2 streamVersion:" + streamVersion);
    }

    public RealTimeManager(String cameraSn, String title, int streamVersion, PlayTypes playType) {
        this(cameraSn, title, streamVersion, playType, true);
    }

    public RealTimeManager(String cameraSn, String title, int streamVersion, PlayTypes playType, LiveSession.JP2PInfo p2pInfo,String deviceType) {
        this(cameraSn, title, streamVersion, playType, true);
        mJP2PInfo = p2pInfo;
        mDeviceType = deviceType;
        if (p2pInfo != null && !TextUtils.isEmpty(p2pInfo.mStreamKey)) {
            requestWithP2P = true;
        } else {
            requestWithP2P = false;
        }
    }

    // endregion

    // region Override

    @Override
    protected void managerJPlayerSucceed() {
        CLog.e("managerJPlayerSucceed");
        if (mJPlayer == null) {
            return;
        }

        mLiveSession = mJPlayer.createLiveSession();
        mCallback = new Callback();
        mLiveSession.setCallback(mCallback);
        mLiveSession.setAppContext(Utils.getContext());
        if (isSetStart) {
            startPlay();
        }
    }

    @Override
    protected void managerAsyncDoNamedJob(String jobName, Object... args) {
        if (TextUtils.equals(jobName, PlayParam.CONNECT_MASTER)) {
            doConnectMaster();
        } else if (TextUtils.equals(jobName, PlayParam.CHANGE_RESO)) {
            int reso = (Integer) args[0];
            doChangeReso(reso);
        } else if (TextUtils.equals(jobName, PlayParam.SET_RECORD_TIME)) {
            long time = (Long) args[0];
            doSetRecordTime(time);
        }
    }

    @Override
    protected void manageSetVideoView(GL2VideoView videoView) {
        if (mLiveSession != null && mLiveSession.isOpened()) {
            mLiveSession.setVideoView(mVideoView, getDistortType());
        }
    }

    @Override
    protected void manageSetVideoViewHandle(long videoViewHandle) {
//        if (mLiveSession != null && mLiveSession.isOpened()) {
        if (mLiveSession != null) {
            mLiveSession.setVideoHandle(mVideoViewHandle, getDistortType());
        }
    }

    @Override
    protected void manageStopPlayer() {
        endRecord();
        endTalk();

        try {
            if (mLiveSession != null && mLiveSession.isOpened()) {
                mLiveSession.stopLive();
                mLiveSession.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (mJP2PInfo != null && !TextUtils.isEmpty(mJP2PInfo.mStreamKey)) {
            requestWithP2P = true;
        } else {
            requestWithP2P = false;
        }
    }

    @Override
    protected void manageReStartPlay() {
        endRecord();
        endTalk();

        if (mLiveSession != null && mLiveSession.isOpened()) {
            mLiveSession.stopLive();
        }

        startPlay();
    }

    @Override
    protected void analyzeRelease() {
        if (mIsRecord) {
            mRecordRelease = true;
        } else {
            manageRelease();
        }
    }

    @Override
    protected void manageRelease() {
        if (mLiveSession != null) {
            CLog.d("Debug Play - destroyLiveSession");
            mJPlayer.destroyLiveSession(mLiveSession);
            mCallback = null;
            mLiveSession = null;
        }
    }

    @Override
    protected void manageMute(boolean isMute) {
        mLiveSession.mute(isMute);
    }

    @Override
    protected void manageSnapShot(String filename) {
        if (mLiveSession != null && mLiveSession.isOpened()) {
            mLiveSession.snapshot(filename);
        } else {
            handleSnapshotResult(-1);
        }
    }

    // endregion

    // region 回调

    private LiveSession.LiveSessionCallback mCallback;

    private class Callback implements LiveSession.LiveSessionCallback {
        @Override
        public void onLiveSessionOpenResult(boolean result) {
            CLog.d("Debug Play - onLiveSessionOpenResult: " + result);
            if (result) {
                if (mLiveSession == null) {
                    return;
                }
                if (mVideoView != null) {
                    mLiveSession.setVideoView(mVideoView, getDistortType());
                }
                mLiveSession.startLive();
                updateStatus(PlayStatus.PlayerWaiting, "");
                setIsMuted(Preferences.getVideoMuted(mCameraSN));
                commitIsMute();
                if (mPlayType == PlayTypes.RealLive || mPlayType == PlayTypes.RealDemo) {
                    mLiveSession.setLatencyType(1);
                } else {
                    mLiveSession.setLatencyType(0);
                }

                handleSessionOpenSucceed();
            } else {
                updateStatus(PlayStatus.PlayerFailed, "");
            }
        }

        @Override
        public void onLiveSessionCloseResult() {
            CLog.d("Debug Play - onLiveSessionCloseResult");
            handleCloseResult();
        }

        @Override
        public void onLiveLastError(int lastError) {
            CLog.d("Debug Play - onLiveLastError: " + lastError);
            mLastError = lastError;
        }

        //截屏处理的回调
        @Override
        public void onLiveSnapshotResult(int result) {
            CLog.d("Debug Play - onLiveSnapshotResult: " + result);
            handleSnapshotResult(result);
        }

        @Override
        public void onLiveSetVideoViewResult(boolean succeed) {
            CLog.d("Debug Play - onLiveSetVideoViewResult: " + succeed);

        }

        @Override
        public void onLiveStartResult(int result) {
            CLog.d("Debug Play - onLiveStartResult: " + result);

        }

        @Override
        public void onLiveSessionConnected() {
            CLog.d("Debug Play - onLiveSessionConnected");

        }

        //切换分辨力的回调
        @Override
        public void onLiveVideoResolutionChanged(int quality) {
            CLog.d("Debug Play - onLiveVideoResolutionChanged: " + quality);
            isNewFirmware = true;
            int newReso = ResoDefine.RESO_HD;
            switch (quality) {
                case 0:
                    isNewFirmware = false;
                case 1:
                    newReso = ResoDefine.RESO_HD;
                    break;
                case 2:
                    newReso = ResoDefine.RESO_VGA;
                    break;
                case 4:
                    newReso = ResoDefine.RESO_MID;
                    break;
            }

            if (newReso != mCurrentReso) {
                mCurrentReso = newReso;
                publishAction(Actions.Play.UPDATE_RESO_MODE, mCurrentReso);
                mIsResoSetting = false;
                if (getPlayType() == PlayTypes.RealMine) {
                    Preferences.saveVideoReso(mCameraSN, mCurrentReso);
                }
            }
        }

        //视频状态变化的回调
        @Override
        public void onLiveVideoStatusChanged(int status) {
            CLog.d("Debug Play - onLiveVideoStatusChanged: " + status);
            PlayStatus currentStatus = getCurrentStatus();
            if (status == PlayerConsts.VideoStatus.VIDEO_READY) {
                if (currentStatus != PlayStatus.Playing) {
                    if (mLiveSession != null) {
                        mLiveSession.mute(mIsMuted);
                    }
                }
                updateStatus(PlayStatus.Playing, "");
                handleVideoReady();
            } else if (status == PlayerConsts.VideoStatus.VIDEO_CACHING) {
                handleVideoCaching();
            } else if (status == PlayerConsts.VideoStatus.VIDEO_PAUSE) {
            } else {
            }
        }


        @Override
        public void onLiveVideoPlayProgress(long timestamp) {
            CLog.d("Debug Play - onLiveVideoPlayProgress: " + timestamp);
            publishAction(Actions.Play.UPDATE_PLAY_TIME, timestamp);
            setReadyCount(timestamp / 1000);
            if (mCurrentStatus != PlayStatus.Playing) {
                updateStatus(PlayStatus.Playing, "");
                handleVideoReady();
            }
        }

        @Override
        public void onLiveStartTalkResult(int result) {
            CLog.d("Debug Play - onLiveStartTalkResult: " + result);

        }

        @Override
        public void onLiveTalkRecordError() {
        }

        @Override
        public void onLiveRecordStartResult(long handle) {
            CLog.i("Debug Play - onLiveRecordStartResult: " + handle);
            AnalyzeBeginRecordResult(handle != 0);
        }

        @Override
        public void onLiveRecordProgress(long handle, int progress) {
            CLog.i("Debug Play - onLiveRecordProgress: " + progress);
            publishAction(Actions.Play.UPDATE_RECORD_TIME, progress);
        }

        @Override
        public void onLiveRecordError(long handle, int error) {
            CLog.i("Debug Play - onLiveRecordError: " + error);
            endRecord();
            publishAction(Actions.Play.UPDATE_RECORD_STATUS, mIsRecord,
                    Utils.getContext().getString(R.string.record_suspend));
        }

        @Override
        public void onLiveRecordEndStream(long handle, boolean succeed) {
            CLog.i("Debug Play - onLiveRecordEndStream: " + succeed);
            AnalyzeEndRecordResult(succeed);
            if (mRecordRelease) {
                mRecordRelease = false;
                manageRelease();
            }
        }

        @Override
        public void onLiveAudioIsSilent(boolean isSilent) {
            CLog.d("Debug Play - onLiveAudioIsSilent: " + isSilent);
            mAllowSound = !isSilent;
            publishAction(Actions.Play.UPDATE_MUTE_STATUS, mAllowSound);
        }

        @Override
        public void onLiveIsCloudRecord(int isCloudRecord) {
            CLog.d("Debug Play - onLiveIsCloudRecord: " + isCloudRecord);
            mCloudEventFlag = isCloudRecord;
            publishAction(Actions.Play.UPDATE_CLOUD_STATUS, mCloudEventFlag);
        }

        @Override
        public void onLiveVoiceTalkVolume(float volume) {
            CLog.d("Debug Play - onLiveVoiceTalkVolume： " + volume);
            if (volume > 0) {
                mTimeHandler.removeCallbacks(talkNoVoiceRunnable);
            }
            publishAction(Actions.Play.UPDATE_TALK_VOLUME, volume - 40);
        }

        @Override
        public void onLiveBandWidthStatistic(int dvbps, int dabps, int dvfps, int dafps) {
            int downloadSpeed = (dvbps + dabps) / 1024;
            CLog.d("Debug Play - onLiveBandWidthStatistic downloadSpeed=" + downloadSpeed + ",dvfps=" + dvfps + ",dabps=" + dabps + ",dvfps=" + dvfps + ",dafps=" + dafps);
            publishAction(Actions.Play.UPDATE_STREAM_FLOW, downloadSpeed, dvfps);
        }

        @Override
        public void onLiveP2pNotWork(int errorCode) {
            CLog.d("Debug Play - onLiveP2pNotWork code:" + errorCode);
            if (mLiveSession != null && mLiveSession.isOpened()) {
                mLiveSession.stopLive();
            }

            String env = "unKnow";
            if (mPlayType == PlayTypes.RealMine) {
                env = "private";
            } else if (mPlayType == PlayTypes.RealLive) {
                env = "public";
            } else if (mPlayType == PlayTypes.RealSD) {
                env = "card";
            } else if (mPlayType == PlayTypes.RealShare) {
                env = "private";
            }
            // TODO 统计
            //LogUtil.getInstance().logP2PNotWork(mCameraSN, env, errorCode);

            // request with connect master
            startPlay();
        }
    }

    // endregion

    // region Public

    // region Param

    public int getCloudEventFlag() {
        return mCloudEventFlag;
    }

    public boolean getIsNewFirmware() {
        return isNewFirmware;
    }

    public boolean getIsTalk() {
        return mIsTalk;
    }

    public boolean getIsResoSetting() {
        return mIsResoSetting;
    }

    public void setIsResoSetting(boolean isResoSetting) {
        this.mIsResoSetting = isResoSetting;
    }

    public int getCurrentReso() {
        return mCurrentReso;
    }

    public void setCurrentReso(int currentReso) {
        mCurrentReso = currentReso;
    }

    // endregion

    public void setTalkMode(int talkMode) {
        CLog.i("play-v2", "Debug Play - setTalkType: " + talkMode);
        mTalkMode = talkMode;
        manageTalkParam();
    }

    public int getTalkMode() {
        return mTalkMode;
    }

    public void startPlay() {
        CLog.e("startPlay1...mJP2PInfo:" + mJP2PInfo + ", requestWithP2P:" + requestWithP2P);
        if (requestWithP2P) {
            startPlay(mJP2PInfo);
        } else {
            mTaskId = UUID.randomUUID().toString();
            CLog.e("startPlay1...");

            if (mInitStatus == InitStatus.InitSucceed) {
                isSetStart = false;
                requestingWithP2P = false;
                updateStatus(PlayStatus.MasterConnecting, "");
                mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob(PlayParam.CONNECT_MASTER));
            } else {
                isSetStart = true;
            }
        }
    }

    public void startPlay(LiveSession.JP2PInfo info) {
        mTaskId = UUID.randomUUID().toString();
        CLog.e("startPlay2...");

        if (mInitStatus == InitStatus.InitSucceed) {
            requestingWithP2P = true;
            isSetStart = false;
            // compatible with relay request
            updateStatus(PlayStatus.MasterConnecting, "");
            updateStatus(PlayStatus.PlayerConnecting, "");
            if (mLiveSession != null) {
                CLog.e("startPlay mLiveSession is NOT null.");
                if (!mLiveSession.isOpened()) {
                    mLiveSession.open(null, info, true, mAudioSource, mTalkMode);
                    if (VideoViewHandle != 0) {
                        mLiveSession.setVideoHandle(VideoViewHandle, getDistortType());
                    }
                }
                CLog.e("startPlay setPlaybackPos:" + ((int) (mPlayTime / 1000)));
                mLiveSession.setPlaybackPos((int) (mPlayTime / 1000));
                requestWithP2P = false;
            } else {
                CLog.e("startPlay mLiveSession is null.");
            }
        } else {
            isSetStart = true;
        }
    }

    public void startPlay(long currentTime) {
        startPlay(currentTime, true);
    }

    public void startPlay(long currentTime, boolean open) {
        mPlayTime = currentTime;
        startPlay();
    }

    public void setRecordTime(long time) {
        startPlay(time, false);
    }

    // region Talk

    public void beginTalk() {
        if (mLiveSession != null) {
            mIsTalk = true;
            mLiveSession.startTalk();
            if (!talkNoVoiceShowed) {
                mTimeHandler.postDelayed(talkNoVoiceRunnable, 3000);
            }
        }
    }

    public void endTalk() {
        mTimeHandler.removeCallbacks(talkNoVoiceRunnable);
        if (mIsTalk) {
            mLiveSession.stopTalk();
            mIsTalk = false;
        }
    }

    // endregion

    // region Quality

    public void changeQuality(int resolution) {
        if (resolution == -1) {
            return;
        }
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob(PlayParam.CHANGE_RESO, resolution));
    }

    // endregion

    // region Record

    private boolean mRecordRelease = false;
    private boolean mIsRecord = false;

    private String mRecordPath;
    private long mRecordBeginTime;
    private long mRecordTime;

    public boolean getIsRecord() {
        return mIsRecord;
    }

    public void toggleRecord() {
        if (mIsRecord) {
            endRecord();
        } else {
            beginRecord();
        }
    }

    private void beginRecord() {
        if (FileUtil.getInstance().calcAvailableSpare() < Const.MINAVAILABLESPARE_RECORD) {
            String msg = Utils.getContext().getString(R.string.notice_video_snapshot_failed);
            publishAction(Actions.Play.UPDATE_RECORD_STATUS, false, msg);
            return;
        }

        String name = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(new Date(System.currentTimeMillis())) + "_"
                + System.currentTimeMillis() % 1000;
        String recordPath = FileUtil.getInstance().getRecordFile().getAbsolutePath() + "/" + name + ".mp4";
        mRecordPath = recordPath;
        mLiveSession.startRecord(mRecordPath);
    }

    protected void AnalyzeBeginRecordResult(boolean result) {
        String msg = "";
        if (result) {
            mRecordBeginTime = System.currentTimeMillis();
            mRecordTime = 0;
        } else {
            if (new File(mRecordPath).exists()) {
                new File(mRecordPath).delete();
            }
            msg = Utils.getContext().getString(R.string.notice_video_record_failed);
            endRecord();
        }
        mIsRecord = result;
        publishAction(Actions.Play.UPDATE_RECORD_STATUS, mIsRecord, msg);
    }

    private void endRecord() {
        if (mIsRecord) {
            mLiveSession.stopRecord();
        }
    }

    protected void AnalyzeEndRecordResult(boolean result) {
        mIsRecord = false;
        if (result) {
            String recordSuccessMsg = Utils.getContext().getString(R.string.notice_video_record_saved);
            FileUtil.getInstance().updateGallery(mRecordPath);

            // 存储db
            MediaFiles mediaFiles = new MediaFiles();
            mediaFiles.setType(MediaFiles.TYPE.VIDEO);
            mediaFiles.setPath(mRecordPath);
            mediaFiles.setCreate_time(System.currentTimeMillis());
            mediaFiles.setSn(getIdentify());

            mediaFiles.setCamera_name(mVideoTitle);
            // TODO FileWrapper
            //FileWrapper.getInstance(Utils.getContext()).write(mediaFiles);

            publishAction(Actions.Play.UPDATE_RECORD_STATUS, false, recordSuccessMsg, mediaFiles);
        } else {
            if (mRecordPath != null && new File(mRecordPath).exists()) {
                new File(mRecordPath).delete();
            }

            long nowTime = System.currentTimeMillis();
            long sub = (nowTime - mRecordBeginTime) / 1000;
            String invalidFileMsg;
            if (sub > 3 && mRecordTime > 3) {
                invalidFileMsg = Utils.getContext().getString(
                        R.string.notice_video_record_invalid_with_net);
            } else {
                invalidFileMsg = Utils.getContext().getString(R.string.notice_video_record_invalid);
            }
            publishAction(Actions.Play.UPDATE_RECORD_STATUS, false, invalidFileMsg);
        }
    }

    // endregion

    // endregion

    // region Do Method

    private void doConnectMaster() {
        CLog.d("Debug Play - doConnectMaster");
        String msg = Utils.getContext().getString(R.string.error_unknown);

        int errorCode;
        // 命令参数
        JSONObject req = new JSONObject();
        try {
            req.put("sn", mCameraSN);
            req.put("taskid", mTaskId);
            if (mPlayType == PlayTypes.RealSD) {
                long currentTime = mPlayTime;
                req.put("timePoint", currentTime / 1000);
            }
        } catch (JSONException e) {
            e.printStackTrace();
            errorCode = Constants.Http.ERROR_CODE_JSON;
            updateStatus(PlayStatus.MasterFailed, Utils.getString(R.string.video_play_failed));
            return;
        }

        // 命令调用
        Relay resultRelay = null;
//        if (mPlayType == PlayTypes.RealDemo
//                || mPlayType == PlayTypes.RealLive) {
//            // 统一调用GET_INFO_AND_PLAY接口，以便同步信息
//            PlayPublicInfo result;
//            if (mStreamVersion == 0) {
//                result = mLiveCameraHttpsApi.doCommonRequest(req, MachineDefaultClientConfig.URL_PUBLIC_GET_INFO_AND_PLAY, PlayPublicInfo.class);
//            } else {
//                result = mLiveCameraHttpsApi.doCommonRequest(req, MachineDefaultClientConfig.URL_PUBLIC_GET_INFO_AND_PLAY_V2, PlayPublicInfo.class);
//            }
//
//            // Relay
//            if (result.getErrorCode() == Constants.Http.SUCCESS) {
//                resultRelay = result.getPlayInfo();
//            } else {
//                resultRelay = new Relay();
//            }
//            resultRelay.setErrorCode(result.getErrorCode());
//            resultRelay.setErrorMsg(result.getErrorMsg());
//
//            // Camera
//            PublicCamera publicCamera = result.getPublicInfo();
//            if (publicCamera != null) {
//                if (resultRelay.errorCode == Constants.Http.ERROR_CAM_OFFLINE) {
//                    publicCamera.state = 0;
//                }
//                // TODO 暂时注释
////                GlobalManager.getInstance().newPublicCameraManager()
////                        .publishAction(Actions.PublicCamera.UPDATE_PLAY_CAMERA, publicCamera);
////                GlobalManager.getInstance().newPublicCameraManager()
////                        .publishAction(Actions.PublicCamera.UPDATE_MY_LIVE_CAMERA, publicCamera);
//            }
//        } else {
        if (mStreamVersion == 0) {
            //resultRelay = mCameraHttpsApi.doCommonRequest(req, MachineDefaultClientConfig.APP_PLAY, Relay.class);
        } else {
            resultRelay = MachineApi.Machine.doStreamPlay(mCameraSN,mDeviceType);
            //resultRelay = mCameraHttpsApi.doCommonRequest(req, MachineDefaultClientConfig.APP_PLAY_V2, Relay.class);
        }
//        }

        // 返回值解析
        if (resultRelay == null) {
            errorCode = Constants.Http.ERROR_CODE_IO;
        } else {
            errorCode = resultRelay.getErrorCode();

            if (errorCode != Constants.Http.SUCCESS) {
                msg = resultRelay.getErrorMsg();
                if (TextUtils.isEmpty(msg)) {
                    msg = Utils.getContext().getString(R.string.video_player_http_error);
                    CLog.d(Utils.getContext().getString(R.string.error_toast, String.valueOf(resultRelay.getStatusCode()), String.valueOf(errorCode), msg));
                }
            }

            if (resultRelay.getData() != null) {
                if ((resultRelay.getData().getRelayInfo() != null && resultRelay.getData().getRelayInfo().getSig() == null) || resultRelay.getData().getPlayKey() == null) {
                    errorCode = Constants.Http.ERROR_UNKNOWN;
                }
            }
        }

        if (mCurrentStatus != PlayStatus.MasterConnecting)
            return;

        if (errorCode != Constants.Http.SUCCESS) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            if (mLiveSession.isOpened()) {
                // mPlayerControl.stopOperator();
            }

            if (errorCode == Constants.Http.ERROR_CODE_DEVICE_OFFLINE) {
                updateStatus(PlayStatus.CameraOffline, msg);
            } else if (errorCode == Constants.Http.ERROR_SOFT_SWITCH_OFF) {
                updateStatus(PlayStatus.SoftSwitchOff, msg);
            } else {
                updateStatus(PlayStatus.MasterFailed, msg);
            }
        } else {
            updateStatus(PlayStatus.PlayerConnecting, "");
            if (!mPaused) {
                doSessionOpen(resultRelay);
            }
        }
    }

    public void onPause() {
        mPaused = true;
    }

    public void onResume() {
        mPaused = false;
    }

    private void doSetRecordTime(long time) {
        JSONObject params = new JSONObject();
        try {
            params.put("sn", mCameraSN);
            params.put("taskid", UUID.randomUUID().toString());
            params.put("timePoint", time / 1000);
            Relay recordRelay;
            if (mStreamVersion == 0) {
                recordRelay = mCameraHttpsApi.doCommonRequest(params, MachineDefaultClientConfig.APP_PLAY, Relay.class);
            } else {
                recordRelay = mCameraHttpsApi.doCommonRequest(params, MachineDefaultClientConfig.APP_PLAY_V2, Relay.class);
            }
            if (!TextUtils.equals(recordRelay.getData().getRelayInfo().getSig(), mRelay.getData().getRelayInfo().getSig())) {
                CLog.e("relay sig inconformity");
            }
            publishAction(Actions.Record.UPDATE_SET_RECORD_TIME_RESULT, recordRelay);
        } catch (JSONException e) {
            e.printStackTrace();
            return;
        }
    }

    private void doChangeReso(int reso) {
        int errorCode;
        JSONObject params = new JSONObject();
        try {
            params.put("command", "setDevice");
            params.put("key", MachineDefaultClientConfig.COMMAND[MachineDefaultClientConfig.CMD_SETTING_RESOLUTION]);
            params.put("value", reso);
            params.put("sn", mCameraSN);
        } catch (JSONException e) {
            e.printStackTrace();
            errorCode = Constants.Http.ERROR_CODE_JSON;
            publishAction(Actions.Play.UPDATE_CMD_RESULT, Utils.getString(R.string.video_set_resc_failed), PlayerCmd.Quality);
            return;
        }
        mCameraHttpsApi.doAysnCommonRequest(params, MachineDefaultClientConfig.URL_APP_CMD, Head.class);
    }

    // endregion

    // region Private

    private void manageTalkParam() {
        if (isSupport()) {
            VqeLookupTable.VqeConfig vqeConfig = VqeLookupTable.getVqeConfig();
            if (vqeConfig == null) {
                return;
            }
            mAudioSource = vqeConfig.mAudioSource;
            CLog.d("Support, AudioSource : " + mAudioSource);

            CLog.d("Audio params: aec " + vqeConfig.mEnableAEC + ", cache " + vqeConfig.mFarCacheSizeInMs + ", faradj "
                    + vqeConfig.mFarADJ + ", nearns " + vqeConfig.mNearNs + ", nearadj " + vqeConfig.mNearAdj
                    + ", nearvad " + vqeConfig.mNearVad);
            JPlayer.enableFeature(JPlayer.FeatureType.FEATURE_AEC, vqeConfig.mEnableAEC);
            JPlayer.setVqeParam(JPlayer.VQE_KEY_FAR_CACHE_SIZE, vqeConfig.mFarCacheSizeInMs);
            JPlayer.setVqeParam(JPlayer.VQE_KEY_FAR_ADJ, vqeConfig.mFarADJ);
            JPlayer.setVqeParam(JPlayer.VQE_KEY_NEAR_NS, vqeConfig.mNearNs);
            JPlayer.setVqeParam(JPlayer.VQE_KEY_NEAR_ADJ, vqeConfig.mNearAdj);
            JPlayer.setVqeParam(JPlayer.VQE_KEY_NEAR_VAD, vqeConfig.mNearVad);

        } else {
            // 0 默认值-未获取到服务器信息；其他，同步服务器定义
            mAudioSource = Preferences.getMicType();
            CLog.d("None Support, AudioSource : " + mAudioSource);
            if (mAudioSource == LiveSession.AudioRecordSourceType.TYPE_NONE) {
                mAudioSource = LiveSession.AudioRecordSourceType.TYPE_MIC;
            }
            JPlayer.enableFeature(JPlayer.FeatureType.FEATURE_AEC, false);
        }
        CLog.d("Using AudioSource : " + mAudioSource);
    }

    private void doSessionOpen(Relay relay) {
        CLog.d("Debug Play - doSessionOpen");
        mRelay = relay;
        StringBuilder listString = new StringBuilder();
        if (mRelay.getData().getRelayInfo().getIpInfo() != null) {
            for (String s : mRelay.getData().getRelayInfo().getIpInfo()) {
                listString.append(s);
                listString.append(",");
            }
        }

        LiveSession.JSessionInfo sessionInfo = new LiveSession.JSessionInfo();
        sessionInfo.mIsRecord = false;
        sessionInfo.mSrcType = SRC_TYPE;

        sessionInfo.mStreamVersion = mStreamVersion;
        sessionInfo.mStreamKey = mRelay.getData().getPlayKey();
        sessionInfo.mRelayId = mRelay.getData().getRelayInfo().getCluster();
        sessionInfo.mSrvListKey = listString.toString();
        if (mStreamVersion == 0) {
            sessionInfo.mSN = mCameraSN;
            sessionInfo.mRelayKey = mRelay.getData().getRelayInfo().getSig();
        } else {
            sessionInfo.mSN = mRelay.getData().getRelayInfo().getLiveId();
            sessionInfo.mRelayKey = mRelay.getData().getRelayInfo().getSig();
        }

        CLog.d("Debug Play - Use mAudioSource：" + mAudioSource + " mTalkMode: " + mTalkMode + " srvListKey=" + sessionInfo.mSrvListKey);
        CLog.d("Debug Play - mRelay=" + mRelay);
        if (mLiveSession.isOpened()) {
            if (mPlayType == PlayTypes.RealLive || mPlayType == PlayTypes.RealDemo) {
                mLiveSession.setLatencyType(2);
            }

            mLiveSession.setSession(sessionInfo);
            mLiveSession.startLive();
            updateStatus(PlayStatus.PlayerWaiting, "");
            handleSessionOpenSucceed();
        } else {
            mLiveSession.open(sessionInfo, mAudioSource, mTalkMode);
            if (VideoViewHandle != 0) {
                // TODO 扭曲设置？
                mLiveSession.setVideoHandle(VideoViewHandle, getDistortType());
            }
        }
    }

    private boolean isSupport() {
        if (mTalkMode == LiveSession.PTT_DUPLEX) {
            return true;
        }
        return false;
    }

    // endregion

    // region Brake

    private int breakCount;
    private long readyTime = -1;

    private int minQualityCount = 5;

    private void setReadyCount(long time) {
        if (getPlayType() != PlayTypes.RealMine || mCurrentReso == ResoDefine.RESO_VGA || mIsResoSetting) {
            return;
        }

        if (readyTime == -1) {
            readyTime = time;
            mTimeHandler.postDelayed(breakRunnable, playTimeout * 2 + 1);
            return;
        }

        long sub = time - readyTime;
        if (sub > 1) {
            CLog.d("Video Break ---- Sub:" + sub + "    Count: " + breakCount);
            testBreakCount();
        }
        readyTime = time;
    }

    @Override
    protected void manageTimeout() {
        if (getPlayType() != PlayTypes.RealMine || mCurrentReso == ResoDefine.RESO_VGA || mIsResoSetting) {
            return;
        }
        CLog.d("Video Break ---- Timeout" + "    Count: " + breakCount);
        mTimeHandler.removeCallbacks(breakRunnable);
//        testBreakCount();
        testTimeOutNew();
        mTimeHandler.postDelayed(breakRunnable, playTimeout * 2 + 1);
    }

    @Override
    protected void manageRemoveRunnable() {
        mTimeHandler.removeCallbacks(breakRunnable);
    }

    private Runnable breakRunnable = new Runnable() {

        @Override
        public void run() {
            CLog.d("Video Break ---- breakRunnable ");
            readyTime = -1;
            breakCount = 0;
        }
    };

    private Runnable talkNoVoiceRunnable = new Runnable() {
        @Override
        public void run() {
            CLog.d("talkNoVoiceRunnable");
            talkNoVoiceShowed = true;
            publishAction(Actions.Play.NOTIFY_TALK_NO_VOICE);
        }
    };

    private void testBreakCount() {
        breakCount++;
        if (breakCount > minQualityCount) {
            CLog.d("Video Break ---- Change Quality ");
            mTimeHandler.removeCallbacks(breakRunnable);
            mIsResoSetting = true;
            readyTime = -1;
            breakCount = 0;
            if (!mIsRecord) {
                publishAction(Actions.Play.NOTIFY_STREAM_BRAKE);
            }
        }
    }

    private void testTimeOutNew() {
        if (mCurrentStatus == PlayStatus.Playing) {
            testBreakCount();
        } else if (mCurrentStatus == PlayStatus.PlayerWaiting) {
            if (!mIsRecord) {
                publishAction(Actions.Play.NOTIFY_VIDEO_TIMEOUT);
            }
        }
    }

    //终止视频流
    public void stopStream() {
        if (!TextUtils.isEmpty(mCameraSN)) {
            CLog.e("zt", "通知关流");
            Observable.empty().observeOn(Schedulers.io()).subscribe(new Subscriber<Object>() {
                @Override
                public void onNext(Object o) {

                }

                @Override
                public void onCompleted() {
                    MachineApi.Machine.doStreamStop(mCameraSN);
                }

                @Override
                public void onError(Throwable e) {

                }
            });
        }
    }
    // endregion
}
