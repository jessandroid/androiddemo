package com.qihoo360.homecamera.machine.entity;

import android.os.Parcel;
import android.os.Parcelable;

import com.qihoo360.homecamera.mobile.entity.Head;

import org.json.JSONException;
import org.json.JSONObject;


public class Firmware extends Head implements Parcelable {

    public String url;//升级地址
    public String newVersion;//新版本号
    public String desc;//描述
    public int status;//状态
    public int compel;//是否强制升级
    public String md5 = "";//固件md5
    public String hardware = "";//固件型号
    public String model = "";//硬件型号
    
    public int recommand ;//推荐度 0 -100
    public int fileSize;//固件大小,单位 Byte
    public String createTime = "";//发布日期

    public Firmware() {}

    protected Firmware(Parcel in) {
        super(in);
        url = in.readString();
        newVersion = in.readString();
        desc = in.readString();
        status = in.readInt();
        compel = in.readInt();
        md5 = in.readString();
        hardware = in.readString();
        model = in.readString();
        recommand = in.readInt();
        fileSize = in.readInt();
        createTime = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeString(url);
        dest.writeString(newVersion);
        dest.writeString(desc);
        dest.writeInt(status);
        dest.writeInt(compel);
        dest.writeString(md5);
        dest.writeString(hardware);
        dest.writeString(model);
        dest.writeInt(recommand);
        dest.writeInt(fileSize);
        dest.writeString(createTime);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Firmware> CREATOR = new Creator<Firmware>() {
        @Override
        public Firmware createFromParcel(Parcel in) {
            return new Firmware(in);
        }

        @Override
        public Firmware[] newArray(int size) {
            return new Firmware[size];
        }
    };

    /**
     * 用来促发升级的指令
     * @return
     */
	public JSONObject getjson() {
		JSONObject json = new JSONObject();
		try {
			json.put("md5", md5);
			json.put("ver", model+"_"+hardware+"_"+newVersion);
			json.put("url", url);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return json;
	}

    @Override
    public String toString() {
        return "Firmware [url=" + url + ", newVersion=" + newVersion + ", desc=" + desc
                + ", status=" + status + ", compel=" + compel + ", md5=" + md5 + ", hardware="
                + hardware + ", model=" + model + "]";
    }
	
	

}
