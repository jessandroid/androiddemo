package com.qihoo360.homecamera.machine.log;

/**
 * Created by zhangchao-pd on 2016/11/9.
 */

public interface MachineLogTag {
    public static final String LOG_TAG_MACHINE = "machine";
}
