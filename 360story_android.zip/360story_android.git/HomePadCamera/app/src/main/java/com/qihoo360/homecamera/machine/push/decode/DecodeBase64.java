package com.qihoo360.homecamera.machine.push.decode;

import android.util.Base64;

public class DecodeBase64 {
	/**
	 * 解密
	 * @param encodeContent
	 * @return
	 */
	public byte[] decode(String encodeContent) {
		if(null == encodeContent) {
			return null;
		}

		return Base64.decode(encodeContent.getBytes(), Base64.DEFAULT);
	}
}
