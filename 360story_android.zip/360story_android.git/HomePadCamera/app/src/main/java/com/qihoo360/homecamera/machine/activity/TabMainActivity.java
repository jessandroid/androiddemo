
package com.qihoo360.homecamera.machine.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qihoo360.homecamera.machine.fragment.StoryLibraryFragment;
import com.qihoo360.homecamera.machine.fragment.TestFragment;
import com.qihoo360.homecamera.machine.util.ScreenUtil;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.activity.BaseActivity;
import com.qihoo360.homecamera.mobile.activity.CameraSettingActivity;
import com.qihoo360.homecamera.mobile.adapter.MainDeviceRecycleAdapter;
import com.qihoo360.homecamera.mobile.adapter.MainViewPagerAdapter;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.db.PadInfoWrapper;
import com.qihoo360.homecamera.mobile.entity.DeviceInfo;
import com.qihoo360.homecamera.mobile.entity.TabEntity;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.ui.MainViewPager;
import com.qihoo360.homecamera.mobile.ui.tabview.CommonTabLayout;
import com.qihoo360.homecamera.mobile.ui.tabview.listener.CustomTabEntity;
import com.qihoo360.homecamera.mobile.ui.tabview.listener.OnTabSelectListener;
import com.qihoo360.homecamera.mobile.utils.DensityUtil;
import com.qihoo360.homecamera.mobile.utils.Preferences;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.util.ArrayList;

public class TabMainActivity extends MachineBaseActivity implements ViewPager.OnPageChangeListener
        , ActionListener, View.OnClickListener, MainDeviceRecycleAdapter.OnViewClick {

    public static final int VIDEO_CALL_INDEX = 0; // 视频通话索引值
    public static final int HOME_PHOTO_INDEX = 1; // 家庭相册索引值
    public static final int COAX_BABY_INDEX = 2; // 哄娃助手
    public static final int SHOW_STORY_LIST = 3; // k故事
    public MainViewPager mViewPager;
    private View firstGuideView;
    private String[] mTitles;
    private ArrayList<DeviceInfo> deviceInfoArrayList;
    public DeviceInfo deviceInfo;
    private int[] mIconUnselectIds = {
            R.drawable.video_call_disable, R.drawable.home_pic_disable, R.drawable.coax_baby, R.drawable.children_story_normal
    };

    private int[] mIconSelectIds = {
            R.drawable.video_call_pressed, R.drawable.home_pic_pressed, R.drawable.coax_baby_hover, R.drawable.children_story
    };
    private ArrayList<Fragment> fragments;
    private CommonTabLayout bottom;
    private RelativeLayout mBottomAreaRL;
    private ArrayList<CustomTabEntity> mTabEntities = new ArrayList<>();
    private TextView titleView;
    private TestFragment mPersonCenterFragment;
    private TestFragment mHomePhotoShowAllDayFragment;
    private TestFragment storyFragment;
    private TestFragment chatFragment;
    private TestFragment newDeviceFragment;
    private MainDeviceRecycleAdapter mainDeviceRecycleAdapter;
    private StoryLibraryFragment mStoryLibraryFragment;
    private View view2;
    private PopupWindow popupWindow;
    private ImageView dropDownMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Constants.IS_LOGIN = true;
        deviceInfoArrayList = new ArrayList<>();
        mTitles = Utils.context.getResources().getStringArray(R.array.machine_main_bottom_title);
        new Thread(new Runnable() {
            @Override
            public void run() {
                String sn = Preferences.getSelectedPad();
                deviceInfo = PadInfoWrapper.getInstance().getPadBySn(sn);
                if (deviceInfo == null)
                    deviceInfo = new DeviceInfo();
                if (!TextUtils.isEmpty(deviceInfo.sn)) {
                    GlobalManager.getInstance().getUserInfoManager().asyncGetSpaceInfo(deviceInfo.sn);
                }
            }
        }).start();
        fragments = new ArrayList<>();
        setContentView(R.layout.main);
        firstGuideView = findViewById(R.id.first_guide_view);
        view2 = findViewById(R.id.view2);
        firstGuideView.setOnClickListener(this);
        if (Preferences.getIsShowGuideChat()) {
            Utils.ensureVisbility(firstGuideView, View.GONE);
        } else {
            Utils.ensureVisbility(firstGuideView, View.VISIBLE);
        }

        TextView textView = new TextView(this);
        LinearLayout.LayoutParams lParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, ScreenUtil.getStatusBarHeight(this));
        textView.setBackgroundColor(getResources().getColor(R.color.title_bg1));
        textView.setLayoutParams(lParams);
        ViewGroup view = (ViewGroup) getWindow().getDecorView();
        view.addView(textView);

        initView();

    }

    private void initView() {
        int curTab = VIDEO_CALL_INDEX;
        if (getIntent().hasExtra("switch") && getIntent().getBooleanExtra("switch", false))
            curTab = HOME_PHOTO_INDEX;
        titleView = (TextView) findViewById(R.id.story_title);
        bottom = (CommonTabLayout) findViewById(R.id.main_bottom_layout);

        dropDownMenu = (ImageView) findViewById(R.id.arrow_down);
        mBottomAreaRL = (RelativeLayout) findViewById(R.id.rl_bottom_tool);
        for (int i = 0; i < mTitles.length; i++) {
            mTabEntities.add(new TabEntity(mTitles[i], mIconSelectIds[i], mIconUnselectIds[i]));
        }

        view2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!deviceInfoArrayList.isEmpty()) {
                    if (deviceInfoArrayList.size() > 1) {
                        showPopMenuDevice();
                        dropDownMenu.setImageResource(R.drawable.arrow_up_white);
                    } else if (deviceInfoArrayList.size() == 1) {
//                        Intent intent = new Intent(MainActivity.this, CameraSettingActivity.class);
//                        intent.putExtra("dev", deviceInfo);
//                        startActivityForResult(intent, 1200);
                    }
                }
            }
        });

        bottom.setTabData(mTabEntities);
        bottom.setCurrentTab(curTab);
        bottom.setOnTabSelectListener(new OnTabSelectListener() {

            @Override
            public void onTabSelect(int position) {
                mViewPager.setCurrentItem(position, false);
                titleView.setText(mTitles[position]);
            }

            @Override
            public void onTabReselect(int position) {
            }
        });

        mViewPager = (MainViewPager) findViewById(R.id.main_viewpager);

        mPersonCenterFragment = new TestFragment();
        mHomePhotoShowAllDayFragment = new TestFragment();
        storyFragment = new TestFragment();
        chatFragment = new TestFragment();
        newDeviceFragment = new TestFragment();
        mStoryLibraryFragment = new StoryLibraryFragment();

        fragments.add(mStoryLibraryFragment);
        fragments.add(mHomePhotoShowAllDayFragment);
        fragments.add(chatFragment);//// TODO: 2016/9/27 哄娃
        fragments.add(storyFragment);

        mViewPager.setScanScroll(false);
        mViewPager.setOffscreenPageLimit(fragments.size());
        mViewPager.setAdapter(new MainViewPagerAdapter(getSupportFragmentManager(), fragments));
        mViewPager.setCurrentItem(curTab, false);
        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        mainDeviceRecycleAdapter = new MainDeviceRecycleAdapter(deviceInfoArrayList, this);
    }


    @Override
    public Object actionPerformed(int actionCode, Object... args) {
        return null;
    }

    @Override
    public int getProperty() {
        return 0;
    }

    @Override
    public void onClick(View v) {

    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {

    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

    public void showPopMenuDevice() {
        Rect frame = new Rect();
        getWindow().getDecorView().getWindowVisibleDisplayFrame(frame);
        int offsetY = frame.top + DensityUtil.dip2px(50);
        int offsetX = DensityUtil.dip2px(10);
        backgroundAlpha(1);
        View parentView = LayoutInflater.from(this).inflate(R.layout.main, null);
        View popView = LayoutInflater.from(this).inflate(R.layout.popupwindow_menu, null);
        popView.findViewById(R.id.lv_menu).setVisibility(View.GONE);
        RecyclerView myList = (RecyclerView) popView.findViewById(R.id.device_checkList);
        myList.setVisibility(View.VISIBLE);
        myList.setLayoutManager(new LinearLayoutManager(this));
        myList.setAdapter(mainDeviceRecycleAdapter);
        mainDeviceRecycleAdapter.setOnViewClick(this);
       /* for (int i = 0; i < 100; i++) {
            deviceInfoArrayList.add(mainDeviceRecycleAdapter.getItem(0));
        }*/
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int screenHeight = dm.heightPixels;
        if (deviceInfoArrayList.size() > 10) {
            popupWindow = new PopupWindow(popView, ViewGroup.LayoutParams.MATCH_PARENT, screenHeight / 2, true);
        } else {
            popupWindow = new PopupWindow(popView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, true);
        }
        popupWindow.setBackgroundDrawable(new BitmapDrawable(getResources(), (Bitmap) null));
        popupWindow.setOutsideTouchable(true);
        popupWindow.setAnimationStyle(android.R.style.Animation_Dialog);
        popupWindow.showAtLocation(parentView, Gravity.LEFT | Gravity.TOP, offsetX, offsetY);

        // 设置背景颜色变暗
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.alpha = 0.6f;
        getWindow().setAttributes(lp);

        popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                dropDownMenu.setImageResource(R.drawable.arrow_down_white);

                WindowManager.LayoutParams lp = getWindow().getAttributes();
                lp.alpha = 1f;
                getWindow().setAttributes(lp);
            }
        });
    }

    @Override
    public void click(int po) {
        mainDeviceRecycleAdapter.getItem(mainDeviceRecycleAdapter.p).checked = false;
        mainDeviceRecycleAdapter.notifyItemChanged(mainDeviceRecycleAdapter.p);

        mainDeviceRecycleAdapter.getItem(po).checked = true;
        mainDeviceRecycleAdapter.notifyItemChanged(po);

        deviceInfo = mainDeviceRecycleAdapter.getItem(po);
        popupWindow.dismiss();
        
    }

    @Override
    public void clearTopMsg() {
    }

    @Override
    public void showTopMsgTip() {
    }
}
