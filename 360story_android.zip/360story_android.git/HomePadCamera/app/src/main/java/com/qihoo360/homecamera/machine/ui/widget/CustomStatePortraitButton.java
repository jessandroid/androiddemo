
package com.qihoo360.homecamera.machine.ui.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;

import com.qihoo360.homecamera.machine.preferences.Preferences;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.utils.CLog;

/**
 * Created by zhaojunbo on 2015/11/3.
 * desc:
 */
public class CustomStatePortraitButton extends AbstractCustomStateButton {

    public boolean call = false;

    public CustomStatePortraitButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        mContext = context;

        LayoutInflater inflater = LayoutInflater.from(mContext);
        View view = inflater.inflate(R.layout.custom_state_button, null);
        addView(view, new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
        mChangeBtn = (ImageView) view.findViewById(R.id.iv_change);
        mChangeBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mIsDemoCamera) {
                    onChangeErrorListener.onErrorMsg(IS_DEMO_CAMERA);
                    return;
                }
                if (!mIsCameraSupport) {
                    onChangeErrorListener.onErrorMsg(CAMERA_NOT_SUPPORT);
                    return;
                }
                if (!mIsPhoneSupport) {
                    onChangeErrorListener.onErrorMsg(PHONE_NOT_SUPPORT);
                    return;
                }
                if (!mIsfirmworkSupport) {
                    onChangeErrorListener.onErrorMsg(FIRMWORK_NEED_UPDATE);
                    return;
                }
                if (!isChanging()) {
                    mIsChanging = true;
                    mButtonState = mButtonState < 3 ? PHONE_NORMAL : MIC_NORMAL;
                    playAnim();
                    onChangeStateListener.onChange(mButtonState);
                    onChangeStateListener.onChange(mButtonState < 3 ? PHONE2MIC : MIC2PHONE);
                    mChangeBtn.setImageResource(mButtonState < 3 ? R.drawable.phone_state_drawable : R.drawable.mic_state_drawable);
                    mCurrentFunBtn.setImageResource(mButtonState < 3 ? R.drawable.btn_video_push_talk : R.drawable.btn_video_push_phone_talk);
                    mTipsTv.setTextColor(getResources().getColor(R.color.white));
                    mCurrentFunBtn.setBackgroundResource(R.drawable.btn_video_push_talk_bg);
                    Preferences.setIsMic(mSn, mButtonState);
                    setPressed(mButtonState <= 3 ? false : true);
                    mLastButtonState = mButtonState;
                }
            }
        });
        mChangeBtn.setImageResource(mButtonState < 3 ? R.drawable.phone_state_drawable : R.drawable.mic_state_drawable);

        setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (!mIsfirmworkSupport && mButtonState == AbstractCustomStateButton.PHONE_NORMAL) {
                    if (event.getAction() == MotionEvent.ACTION_DOWN) {
                        onChangeErrorListener.onErrorMsg(FIRMWORK_NEED_UPDATE);
                    }
                    return true;
                }
                return clickTalkBtn(v, event, event.getAction());
            }
        });

        setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mButtonState >= 3) {
                    if (mButtonState != PHONE_NORMAL) {
                        mTipsTv.setTextColor(getResources().getColor(R.color.white));
                        mCurrentFunBtn.setImageResource(R.drawable.phone_normal);
                        mCurrentFunBtn.setBackgroundResource(R.drawable.btn_push_talk_normal);
                    } else {
                        mTipsTv.setTextColor(getResources().getColor(R.color.white));
                        mCurrentFunBtn.setImageResource(R.drawable.hang_up_phone);
                        mCurrentFunBtn.setBackgroundResource(R.drawable.hang_up_red);
                    }
                    mButtonState = mButtonState == PHONE_NORMAL ? PHONE_PRESS : PHONE_NORMAL;
                    if (mLastButtonState != mButtonState) {
                        if(mButtonState != PHONE_NORMAL){
                            onChangeStateListener.onChange(mButtonState);
                        }else{
                            onChangeStateListener.onCloseVideo();
                        }
                    }
                    mLastButtonState = mButtonState;
                }
            }
        });
    }

    public boolean clickTalkBtn(View v, MotionEvent event, int action) {
        if (mIsDemoCamera) {
            if (action == MotionEvent.ACTION_DOWN) {
                onChangeErrorListener.onErrorMsg(IS_DEMO_CAMERA);
            }
            return true;
        }
        //按下状态
        if (action == MotionEvent.ACTION_DOWN) {
            onTalkButtonClickListener.onClick(mButtonState);
            if (mButtonState < 3) {//单工状态下
                mTipsTv.setTextColor(getResources().getColor(R.color.white));
                setPressed(true);
                mButtonState = MIC_PRESS;
            } else {
                //双工状态下
                mTipsTv.setTextColor(getResources().getColor(R.color.white));
                return false;
            }
        } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL || action == MotionEvent.ACTION_OUTSIDE) {
            if (mButtonState < 3) {
                mTipsTv.setTextColor(0xff6692f7);
                setPressed(false);
                mButtonState = MIC_NORMAL;
            } else {
                if (v != null && event != null && !inRangeOfView(v, event)) {
                    mTipsTv.setTextColor(getResources().getColor(R.color.white));
                    return true;
                }
                return false;
            }
        } else {
            return false;
        }
        //通知页面进行相应的操作
        if (mLastButtonState != mButtonState) {
            onChangeStateListener.onChange(mButtonState);
        }
        mLastButtonState = mButtonState;
        return true;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        initView();
        int offset = getMeasuredWidth() / 2 - mTipsTv.getMeasuredWidth() / 2 - 30;
        mChangeBtnTranslateAnimation = new TranslateAnimation(0.1f, -offset, 0.1f, offset);
        mCurrentFunBtnTranslateAnimation = new TranslateAnimation(0.1f, offset, 0.1f, -offset);

    }

    public boolean isChanging() {
        return mIsChanging;
    }

    @Override
    public void setPhoneModeVisible(boolean isVisible) {
        //Utils.ensureVisbility(isVisible ? View.VISIBLE : View.GONE, mChangeBtn);
        mIsPhoneModeEnable = isVisible;
    }

    //刚进来的初始的状态
    @Override
    public void restoreLastState(int state) {
        mButtonState = state;
        mChangeBtn.setImageResource(mButtonState < 3 ? R.drawable.phone_state_drawable : R.drawable.mic_state_drawable);
        //setBackgroundResource(R.drawable.btn_video_push_talk_bg);
        if (mButtonState >= 3) {
            updateBtnState();
        } else {
            mCurrentFunBtn.setImageResource(R.drawable.btn_video_push_talk);
            mCurrentFunBtn.setBackgroundResource(R.drawable.btn_video_push_talk_bg);
            mTipsTv.setText(mButtonState < 3 ? mContext.getString(R.string.talk_mic_normal) : mContext.getString(R.string.talk_phone_normal));
            mTipsTv.setEnabled(false);
            if (!mIsEnable) {
                mTipsTv.setTextColor(0xffa9a9a9);
            } else {
                mTipsTv.setTextColor(getResources().getColor(R.color.white));
            }
            setPressed(state == AbstractCustomStateButton.PHONE_PRESS ? true : false);
        }
        onChangeStateListener.onChange(mButtonState);
    }

    @Override
    public void setEnabled(boolean enabled) {
        super.setEnabled(enabled);
        if (mTipsTv != null) {
            mTipsTv.setTextColor(enabled ? 0xff6692f7 : 0xffa9a9a9);
        }
        if (mButtonState >= 3) {
            updateBtnState();
        }
    }

    //双工模式下
    private void updateBtnState() {
        CLog.d(CustomStatePortraitButton.class.getSimpleName(), "mButtonState:" + mButtonState);
        if (!mIsEnable) {
            if (call) {
                mTipsTv.setTextColor(getResources().getColor(R.color.text_gray));
                mCurrentFunBtn.setImageResource(R.drawable.hang_up_phone_inactive);
                mCurrentFunBtn.setBackgroundResource(R.drawable.hang_up_inactive_bg);
                mTipsTv.setText("挂断");
            } else {
                mTipsTv.setTextColor(0xffa9a9a9);
                mCurrentFunBtn.setImageResource(R.drawable.phone_disable);
                mCurrentFunBtn.setBackgroundResource(R.drawable.hang_up_inactive_bg);
                mTipsTv.setText("发起通话");
            }
        } else if (mButtonState == PHONE_NORMAL) {
            if (call) {
                mTipsTv.setTextColor(getResources().getColor(R.color.white));
                mCurrentFunBtn.setImageResource(R.drawable.hang_up_phone);
                mCurrentFunBtn.setBackgroundResource(R.drawable.hang_up_red);
                mTipsTv.setText("挂断");
            } else {
                mTipsTv.setTextColor(getResources().getColor(R.color.white));
                mCurrentFunBtn.setImageResource(R.drawable.phone_normal);
                mCurrentFunBtn.setBackgroundResource(R.drawable.hang_up_normal_bg);
                mTipsTv.setText("发起通话");
            }
        } else {
            if (call) {
                mTipsTv.setTextColor(getResources().getColor(R.color.white));
                mCurrentFunBtn.setImageResource(R.drawable.hang_up_phone);
                mCurrentFunBtn.setBackgroundResource(R.drawable.hang_up_red);
                mTipsTv.setText("挂断");
            } else {
                mTipsTv.setTextColor(getResources().getColor(R.color.white));
                mCurrentFunBtn.setImageResource(R.drawable.hang_up_phone);
                mCurrentFunBtn.setBackgroundResource(R.drawable.hang_up_red);
                mTipsTv.setText("挂断");
            }
        }
    }

    public void setCallButton(boolean callButton) {
        this.call = callButton;
        updateBtnState();
    }

    //true为视频通话，false为远程查看
    public void setIsCall(boolean callButton){
        this.call = callButton;
    }
}
