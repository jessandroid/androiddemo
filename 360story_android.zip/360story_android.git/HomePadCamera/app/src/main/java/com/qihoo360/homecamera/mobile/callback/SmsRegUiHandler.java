package com.qihoo360.homecamera.mobile.callback;

import android.content.Context;

import com.qihoo360.accounts.api.auth.model.UserTokenInfo;

/**
 * Created by Administrator on 2014/11/10.
 */
public interface SmsRegUiHandler {


    Context getApplicationContext();

    void handleRegSuccess(UserTokenInfo info, String sessionId, String pushKey, String A, String B);
    void handleGetCaptchaError(int errorType, int errorCode, String errorMessage);
    void handleSMSRequestSuccess();
    void handleCommitError(int errorType, int errorCode, String errorMessage);
    void handleAuthError(int errorCode, String errorMessage);



}
