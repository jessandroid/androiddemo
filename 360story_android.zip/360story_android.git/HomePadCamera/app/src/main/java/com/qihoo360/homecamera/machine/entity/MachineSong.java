package com.qihoo360.homecamera.machine.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by zhangtao-iri on 2016/12/22.
 */
public class MachineSong extends SongEntity implements Parcelable{

    public String sn;      //设备号

    public String unique;  //专辑唯一baioshi

    public String md5;     //列表md5

    public int typeFrom;//来自于那个列表

    public MachineSong() {
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeString(this.sn);
        dest.writeString(this.unique);
        dest.writeString(this.md5);
        dest.writeInt(this.typeFrom);
    }

    protected MachineSong(Parcel in) {
        super(in);
        this.sn = in.readString();
        this.unique = in.readString();
        this.md5 = in.readString();
        this.typeFrom = in.readInt();
    }

    public static final Creator<MachineSong> CREATOR = new Creator<MachineSong>() {
        @Override
        public MachineSong createFromParcel(Parcel source) {
            return new MachineSong(source);
        }

        @Override
        public MachineSong[] newArray(int size) {
            return new MachineSong[size];
        }
    };
}
