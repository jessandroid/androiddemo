package com.qihoo360.homecamera.mobile.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qihoo360.homecamera.device.config.StoryMachineConsts;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.db.FamilyGroupWrapper;
import com.qihoo360.homecamera.mobile.db.MachineSongWrapper;
import com.qihoo360.homecamera.mobile.db.PadInfoWrapper;
import com.qihoo360.homecamera.mobile.db.PhoneRecordWrapper;
import com.qihoo360.homecamera.mobile.entity.DeviceInfo;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.Preferences;
import com.qihoo360.homecamera.mobile.utils.Utils;

import rx.Observable;
import rx.Single;
import rx.SingleSubscriber;
import rx.schedulers.Schedulers;

/**
 * Created by hyuan on 2016/9/5.
 */
public class UnbindMachineActivity extends BaseActivity implements View.OnClickListener, ActionListener, CompoundButton.OnCheckedChangeListener{
    private static final String url = "http://kibot.360.cn/mobile/app/restore.html";
    public static boolean DO_UNBIND = false;

    private TextView mTitleTxtView;
    private ImageView mBackBtnView;
    private Button mDeleteConfirm;
    private DeviceInfo devInfo;
    private CheckBox deleteCheck;
    private CheckBox delFavorCheck;
    private RelativeLayout rlAutoDeleteVideoData;
    private String device_type;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_unbind_machine);
        Intent intent = getIntent();
        devInfo = intent.getParcelableExtra(DeviceInfo.class.getSimpleName());
        device_type = devInfo.deviceType;
        initView();
        initListener();
        DO_UNBIND = false;
    }

    private void initView(){
        mTitleTxtView = (TextView) findViewById(R.id.title_string);
        mTitleTxtView.setText("解除绑定");
        mBackBtnView = (ImageView) findViewById(R.id.back_zone);
        deleteCheck = (CheckBox) findViewById(R.id.delete_check);
        deleteCheck.setOnCheckedChangeListener(this);
        delFavorCheck = (CheckBox) findViewById(R.id.delete_favor_check);
        delFavorCheck.setOnCheckedChangeListener(this);
        mDeleteConfirm = (Button) findViewById(R.id.delete_confirm);
        rlAutoDeleteVideoData = (RelativeLayout) findViewById(R.id.rl_auto_delete_video_data);
        if (device_type != null && device_type.equals(StoryMachineConsts.VALUE_SET_MACHINE_TYPE_605)){
            rlAutoDeleteVideoData.setVisibility(View.GONE);
        }
    }

    private void initListener(){
        mBackBtnView.setOnClickListener(this);
        mDeleteConfirm.setOnClickListener(this);
        GlobalManager.getInstance().getCameraManager().registerActionListener(this);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        GlobalManager.getInstance().getCameraManager().removeActionListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.back_zone: {
                finish();
                break;
            }

            case R.id.delete_confirm:{
                if (devInfo.getRole() == 1) {
                    GlobalManager.getInstance().getCameraManager().asyncLoadUnBindDevice(devInfo.getSn(), deleteCheck.isChecked() ? "1" : "0", delFavorCheck.isChecked() ? "1" : "0");
                } else {
                    GlobalManager.getInstance().getShareManager().asyncShareCancel(devInfo.getSn(), devInfo.getQid());
                }
                showTipsDialog(getString(R.string.tips_49), R.drawable.icon_loading, 10000, true);
                break;
            }
        }
    }


    @Override
    public Object actionPerformed(int actionCode, Object... args) {
        switch (actionCode) {

            case Actions.Camera.UN_BIND_DEVICE_SUCCESS: {
                GlobalManager.getInstance().getPadSettingManager().asyncDelAcl(devInfo.getSn());
                PhoneRecordWrapper.getInstance(UnbindMachineActivity.this).updatePhoneRecordStateBySn(devInfo.getSn());
                CameraToast.showToast(Utils.context, R.string.unbind_device_suc);
                hideTipsDialog();
                //清空该sn下的聊天记录

                Single.create(new Single.OnSubscribe<Object>() {
                    @Override
                    public void call(SingleSubscriber<? super Object> singleSubscriber) {
                        FamilyGroupWrapper.getInstance().cleanData(devInfo.getSn());
                        if (delFavorCheck.isChecked()) {
                            MachineSongWrapper.getInstance().cleanSongData(devInfo.getSn());
                        }
                        singleSubscriber.onSuccess(new Object());
                    }
                }).subscribeOn(Schedulers.io()).subscribe();
                DO_UNBIND = true;
                GlobalManager.getInstance().getCommonManager().publishAction(Actions.Common.EXIT);
                GlobalManager.getInstance().getCommonManager().publishAction(Actions.Common.UNBIND_SUCCESS_UPDATE);
                finish();
                return Boolean.TRUE;
            }

            case Actions.Share.SHARE_CANCEL_SUCCESS: {
                CameraToast.showToast(this, R.string.unbind_device_suc);
                hideTipsDialog();
                if (Preferences.getSelectedPad().equals(devInfo.getSn())) {
                    Preferences.saveSelectedPad("");
                }
                PadInfoWrapper.getInstance().deletePadBySnQid(devInfo.getSn(), AccUtil.getInstance().getQID());
                GlobalManager.getInstance().getPadSettingManager().asyncDelAcl(devInfo.getSn());
                GlobalManager.getInstance().getCameraManager().asyncLoadMyCamera(0);
                GlobalManager.getInstance().getCameraManager().publishAction(Actions.Camera.CAMERA_LIST_ACTION);
                GlobalManager.getInstance().getCameraManager().publishAction(Actions.Camera.DELTET_SN, devInfo.getSn());
                DO_UNBIND = true;
                GlobalManager.getInstance().getCommonManager().publishAction(Actions.Common.EXIT);
                finish();
                return Boolean.TRUE;
            }

            case Actions.Camera.UN_BIND_DEVICE_FAIL: {
                CameraToast.showToast(Utils.context, R.string.unbind_device_fail);
                hideTipsDialog();
                DO_UNBIND = false;
                return Boolean.TRUE;
            }

            case Actions.Share.SHARE_CANCEL_FAIL: {
                CameraToast.showErrorToast(this, R.string.unbind_device_fail);
                hideTipsDialog();
                DO_UNBIND = false;
                return Boolean.TRUE;
            }
        }
        return null;
    }

    @Override
    public int getProperty() {
        return 0;
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
    }
}
