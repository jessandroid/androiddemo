package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by hyuan on 2016/9/2.
 */
public class DeviceCloudSettingSupport implements  Parcelable{
    private int test = 1;
    private int setting_v1 = 0;
    private int lock_screen = 0;
    private int change_pwd = 0;
    private int unlock_screen = 0;

    public int getTest() {
        return test;
    }

    public void setTest(int test) {
        this.test = test;
    }

    public int getSetting_v1() {
        return setting_v1;
    }

    public void setSetting_v1(int setting_v1) {
        this.setting_v1 = setting_v1;
    }

    public int getLock_screen() {
        return lock_screen;
    }

    public void setLock_screen(int lock_screen) {
        this.lock_screen = lock_screen;
    }

    public int getChange_pwd() {
        return change_pwd;
    }

    public void setChange_pwd(int change_pwd) {
        this.change_pwd = change_pwd;
    }

    public int getUnlock_screen() {
        return unlock_screen;
    }

    public void setUnlock_screen(int unlock_screen) {
        this.unlock_screen = unlock_screen;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.test);
        dest.writeInt(this.setting_v1);
        dest.writeInt(this.lock_screen);
    }

    public DeviceCloudSettingSupport() {
    }

    protected DeviceCloudSettingSupport(Parcel in) {
        this.test = in.readInt();
        this.setting_v1 = in.readInt();
        this.lock_screen = in.readInt();
    }

    public static final Parcelable.Creator<DeviceCloudSettingSupport> CREATOR = new Parcelable.Creator<DeviceCloudSettingSupport>() {
        @Override
        public DeviceCloudSettingSupport createFromParcel(Parcel source) {
            return new DeviceCloudSettingSupport(source);
        }

        @Override
        public DeviceCloudSettingSupport[] newArray(int size) {
            return new DeviceCloudSettingSupport[size];
        }
    };
}
