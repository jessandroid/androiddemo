package com.qihoo360.homecamera.mobile.entity;

import android.graphics.Bitmap;

import java.io.File;

/**
 * Created by yanggang on 2016/5/26.
 */
public class AlbumShareEntity {
    public static final int TYPE_IMAGE = 0;
    public static final int TYPE_VIDEO_CATCH = 1;
    public static final int TYPE_VIDEO_SELF = 2;
    public static final int TYPE_VIDEO_AR = 3;
    public static final int TYPE_VIDEO_LISTEN = 4;
    public static final int TYPE_VIDEO_SPECK = 5;
    public static final int TYPE_STORY = 6;

    public String image;
    public String url;
    public String info;
    public int type;
}
