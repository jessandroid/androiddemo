package com.qihoo360.homecamera.mobile.entity;


import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/1/14
 * Time: 11:52
 * To change this template use File | Settings | File Templates.
 */
public class Camera extends Head {

    public String sn;

    public static class Data {
        public ArrayList<DeviceInfo> device = new ArrayList<DeviceInfo>();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        out.writeString(sn);
    }

    public static final Parcelable.Creator<Camera> CREATOR = new Parcelable.Creator<Camera>() {
        @Override
        public Camera createFromParcel(Parcel source) {
            return new Camera(source);
        }

        @Override
        public Camera[] newArray(int size) {
            return new Camera[size];
        }
    };

    private Camera(Parcel in) {
        sn = in.readString();
    }

    public Camera() {

    }
}
