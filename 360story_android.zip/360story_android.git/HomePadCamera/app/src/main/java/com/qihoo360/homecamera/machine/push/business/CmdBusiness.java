package com.qihoo360.homecamera.machine.push.business;

import com.qihoo360.homecamera.machine.business.PlayConfig;
import com.qihoo360.homecamera.machine.entity.LocalSetting;
import com.qihoo360.homecamera.machine.entity.MachinePlaySingle;
import com.qihoo360.homecamera.machine.entity.MachineSong;
import com.qihoo360.homecamera.machine.entity.PlayControlReceipt;
import com.qihoo360.homecamera.machine.entity.PlayListReceipt;
import com.qihoo360.homecamera.machine.entity.SongEntity;
import com.qihoo360.homecamera.machine.log.MachineLogTag;
import com.qihoo360.homecamera.machine.manager.MachinePlayInfoManager;
import com.qihoo360.homecamera.machine.push.business.cmd.content.CmdBean;
import com.qihoo360.homecamera.machine.push.business.cmd.content.ContentBase;
import com.qihoo360.homecamera.mobile.db.MachineSongWrapper;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.Preferences;
import java.util.ArrayList;

/**
 * cmd业务处理
 * Created by zhangtao on 2016/11/22.
 */

public class CmdBusiness extends BusinessBase {

    @Override
    protected Class<? extends ContentBase> getBeanClass() {
        return CmdBean.class;
    }

    @Override
    protected void disposeData(Object data) {
        CLog.i(MachineLogTag.LOG_TAG_MACHINE, "处理播放状态改变push data=" + data);
        CmdBean cmdBean = (CmdBean)data;
        switch (cmdBean.getCmd()) {
            case PlayConfig.CommandType.PLAYCONTROL:    //收到播放控制的push
                disposeContentPlayReceipt(cmdBean.getContent(PlayControlReceipt.class), cmdBean.getCmd(), cmdBean.getSenderInfo().getSn());
                break;

            case PlayConfig.CommandType.GETPLAYLISTRESULT:
                disposeContentGetPlayList(cmdBean.getContent(PlayListReceipt.class), cmdBean.getSenderInfo().getSn());
                break;

            case PlayConfig.CommandType.DOLOCALSETTING:
                disposeLocalSetting(cmdBean.getContent(LocalSetting.class), cmdBean.getSenderInfo().getSn());
                break;
        }
    }

    /**
     * 处理cmd：PlayReceipt(故事机主动推送的播放状态)
     * @param playControlReceipt
     */
    private void disposeContentPlayReceipt(PlayControlReceipt playControlReceipt, String cmd, String sn) {
        if(playControlReceipt.resultCode==0){
            MachinePlaySingle playSingle = new MachinePlaySingle();
            playSingle.setMediaInfo(playControlReceipt.getMediaInfo());
            playSingle.setPageId(playControlReceipt.getPageId());
            playSingle.setStatus(playControlReceipt.getStatus());
            playSingle.setUnique(playControlReceipt.getUnique());
            CLog.e("zt","固件主动更新播放状态");
            MachinePlayInfoManager.getInstance().notifySinglePlayUpdate(playSingle, cmd, "", sn);
        }else if(playControlReceipt.resultCode==1){
            //TODO 故事机正在忙

        }else if(playControlReceipt.resultCode==2){
            //TODO 故事机闲着
            CLog.e("zt","固件主动更新播放状态,故事机闲置");
            MachinePlayInfoManager.getInstance().notifyMachineFree(cmd, sn);
        }

    }

    /**
     * 处理cmd：GetPlayList(故事机主动推送的收藏列表或者导入列表)
     * @param playListReceipt
     */
    private void disposeContentGetPlayList(PlayListReceipt playListReceipt, String sn) {
        ArrayList<MachineSong> machineSongList = new ArrayList<>();
        for(SongEntity song : playListReceipt.getMediaList()){
            MachineSong machineSong = new MachineSong();
            machineSong.sn = Preferences.getSelectedPad();
            machineSong.unique = playListReceipt.getUnique();
            machineSong.md5 = playListReceipt.getMd5();
            machineSong.uniqueid = song.uniqueid;
            machineSong.title = song.title;
            machineSong.mediaurl = song.mediaurl;
            machineSong.type = song.type;
            machineSong.srclogo = song.srclogo;
            machineSong.src = song.src;
            machineSong.typeFrom =playListReceipt.getType();
            machineSongList.add(machineSong);
        }
        //因为是主动推送，只需要入库就可以了
        if(machineSongList.size()>0){
            MachineSongWrapper.getInstance().updateSongList(machineSongList);
        }else{
            MachineSong machineSong = new MachineSong();
            machineSong.sn = Preferences.getSelectedPad();
            machineSong.unique = playListReceipt.getUnique();
            machineSong.typeFrom = playListReceipt.getType();
            MachineSongWrapper.getInstance().deleteList(machineSong);
        }
        if(playListReceipt.getType() ==  PlayConfig.ListType.FAVORLIST){
            //如果是收藏列表变了，需要通知更新
            CLog.e("zt","固件告知收藏列表有更新");
            MachinePlayInfoManager.getInstance().nativenotifyFavorListUpdate(sn);
        }else if(playListReceipt.getType() ==  PlayConfig.ListType.INSERTLIST){
            //如果是导入列表，播放页又刚好是播放导入部分，需要刷新导入列表
            MachinePlayInfoManager.getInstance().nativenotifyInsertListUpdate(sn);
        }
    }

    /*
    * 处理群发的设置改变push
    * */
    private void disposeLocalSetting(LocalSetting setting, String sn){
        MachinePlayInfoManager.getInstance().notifyLocalSettingUpdate(setting, sn);
    }
}
