package com.qihoo360.homecamera.mobile.manager;

import android.app.Application;
import android.text.TextUtils;

import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionPublisherWithThreadPoolBase;
import com.qihoo360.homecamera.mobile.core.manager.workpool.PoolThreadFactory;
import com.qihoo360.homecamera.mobile.core.net.Api;
import com.qihoo360.homecamera.mobile.db.CommandMessageWraper;
import com.qihoo360.homecamera.mobile.entity.CommandMessage;
import com.qihoo360.homecamera.mobile.entity.CommandResponse;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.Executors;

/**
 * Created by hyuan on 2016/9/27.
 */
public class CommandMessageManager extends ActionPublisherWithThreadPoolBase {

    private final String mPoolNameHighPriority, mPoolNameLowPriority;
    private final Application mApp;

    public CommandMessageManager(Application app) {
        this.mApp = app;
        mPoolNameHighPriority = "CommandMessageManager-high-priority-" + Utils.DATE_FORMAT_3.format(new Date());
        mPoolNameLowPriority = "CommandMessageManager-low-priority-" + Utils.DATE_FORMAT_3.format(new Date());
        mThreadPool.initPool(mPoolNameHighPriority, Executors.newFixedThreadPool(3));
        mThreadPool.initPool(mPoolNameLowPriority,
                Executors.newCachedThreadPool(new PoolThreadFactory(mPoolNameLowPriority)));
    }

    public void asyncGetCmdMsgList(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("CommandMessageList", args));
    }

    public void asyncGetCmdMsg(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("CommandMessage", args));
    }

    public void asyncInsertCmdMsg(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("CommandMessageInsert", args));
    }

    public void asyncSendCmdMsg(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("CommandMessageSend", args));
    }

    public void asyncUpdateCmdMsg(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("CommandMessageUpdate", args));
    }

    @Override
    protected void asyncDoNamedJob(String jobName, Object... args) {
        if (TextUtils.equals(jobName, "CommandMessageList")) {
            doGetList((String) args[0], (String) args[1], (int) args[2]);
        } else if (TextUtils.equals(jobName, "CommandMessage")) {
            doGetInstance((String) args[0], (String) args[1], (String) args[2]);
        } else if (TextUtils.equals(jobName, "CommandMessageInsert")) {
            doInsert((CommandMessage)args[0]);
        } else if (TextUtils.equals(jobName, "CommandMessageSend")) {
            doSend((CommandMessage)args[0], (boolean)args[1]);
        } else if (TextUtils.equals(jobName, "CommandMessageUpdate")) {
            doUpdate((CommandMessage)args[0]);
        }
    }

    private void doGetList(String sn, String userPhone, int num) {
       try {
           ArrayList<CommandMessage> list = CommandMessageWraper.getInstance().getCommandMessageList(sn, userPhone, num);
           if (list != null)
               publishAction(Actions.CommandMessage.GET_LIST_SUCCESS, list);
           else
               publishAction(Actions.CommandMessage.GET_LIST_FAIL);
       } catch (Exception e) {
           e.printStackTrace();
       }
    }

    private void doGetInstance(String taskId, String sn, String userPhone) {
        try {
            CommandMessage instance = CommandMessageWraper.getInstance().getCommandMessage(taskId, sn, userPhone);
            if (instance != null)
                publishAction(Actions.CommandMessage.GET_INSTANCE_SUCCESS, instance);
            else
                publishAction(Actions.CommandMessage.GET_INSTANCE_FAIL);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void doInsert(CommandMessage cmdMsg) {
        try {
            long r = CommandMessageWraper.getInstance().setCommandMessage(cmdMsg, false);
            if (r > 0)
                publishAction(Actions.CommandMessage.SET_INSTANCE_SUCCESS);
            else
                publishAction(Actions.CommandMessage.SET_INSTANCE_FAIL);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void doUpdate(CommandMessage cmdMsg) {
        try {
            long r = CommandMessageWraper.getInstance().setCommandMessage(cmdMsg, true);
            if (r > 0)
                publishAction(Actions.CommandMessage.UPDATE_COMMAND);
            else
                publishAction(Actions.CommandMessage.UPDATE_COMMAND);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void doSend(CommandMessage cmdMsg, boolean tryAgain) {
        try {
            CommandResponse response =  Api.Command.postCommand("lock_screen", cmdMsg.trickContent, cmdMsg.qid, 0, cmdMsg.timeExecute, cmdMsg.sn);
            publishAction(Actions.CommandMessage.SEND_COMMAND, response, cmdMsg, tryAgain);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
