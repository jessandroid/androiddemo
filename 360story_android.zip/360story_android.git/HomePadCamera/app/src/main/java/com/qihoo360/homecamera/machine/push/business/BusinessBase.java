package com.qihoo360.homecamera.machine.push.business;

import android.content.Context;

import com.qihoo360.homecamera.machine.push.business.cmd.content.ContentBase;

/**
 * push业务处理基类
 * @author zhangtao
 *
 */
public abstract class BusinessBase {
	
	/**
	 * 获得业务的json实体类
	 * @return
	 */
	protected abstract Class<? extends ContentBase> getBeanClass();
	
	/**
	 * 业务实体数据
	 * @param data
	 */
	protected abstract void disposeData(Object data);
	
	/**
	 * 需要处理BusinessBean中的非data数据时继承此方法并处理
	 * @param businessBean
	 */
	protected void disposeBusiness(BusinessBean businessBean) {
		// 例:处理message
		// businessBean.getMessage();
	}

	/**
	 * 处理业务bean
	 * @param businessBean
	 */
	public void dispose(BusinessBean businessBean) {

		if(null == businessBean) {
			return;
		}
		
		// 提供businessBean非data数据处理接口
		disposeBusiness(businessBean);
		
		// 拿到业务的data json 实体类
		Class<?> classType = getBeanClass();
		
		if(null != classType) {
			Object data = businessBean.getData(classType);
			
			// 业务类处理data
			disposeData(data);
		}
	}
}
