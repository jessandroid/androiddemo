
package com.qihoo360.homecamera.mobile.core.manager.workpool;

public abstract class AbstractStoppableJob<T> implements IStoppableJob<T> {
    private boolean mIsStopped = false;

    @Override
    public abstract T doJob();

    @Override
    public void stop() {
        mIsStopped = true;
    }

    @Override
    public boolean isStopped() {
        return mIsStopped;
    }
}
