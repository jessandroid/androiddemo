package com.qihoo360.homecamera.machine.sound;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PaintFlagsDrawFilter;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;

import java.util.Random;

/**
 * @author chengxiangyu 声音波形图
 */
public class SoundWaveView extends ImageView {

	private final static int SPEED_SPACE = 5;// 速度取值，共四个，随机
	private final static int REVERSAL_SPACE = 50;//变向取值
	
	// 控件默认长、宽
	private int defaultWidth = 0;
	private int defaultHeight = 0;
	
	private Bitmap bmp = null;
	private boolean isRunning = true;//false;

	private int[][] bars = new int[4][2];
	private int barWidth = 0;//条形宽度
	
	private Paint mPaint = new Paint();
	
	private boolean isSelfAni = true;

	public SoundWaveView(Context context) {
		super(context);
		init();
	}

	public SoundWaveView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
	}

	public SoundWaveView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		init();
	}
	
	Random random = new Random();//速度随机值
	private void init() {
		mPaint.setColor(Color.WHITE);
	}

	@Override
	protected void onDraw(Canvas canvas) {
		if (defaultWidth == 0 || defaultHeight == 0) {
			defaultWidth = getWidth();
			defaultHeight = getHeight();
			barWidth = defaultWidth/(bars.length*2-1);
			initBars();
		}
		if (bmp == null)
			createBitmap();
		canvas.drawBitmap(bmp, 0, 0, null);
		
		if (isRunning) {
			createBitmap();
			postInvalidateDelayed(3);
		}
	}

	private Bitmap createBitmap() {
		if (bmp == null) {
			bmp = Bitmap.createBitmap(defaultWidth, defaultHeight, Config.ARGB_8888);
			Canvas cv = new Canvas(bmp);
			cv.setDrawFilter(new PaintFlagsDrawFilter(0, Paint.ANTI_ALIAS_FLAG
					| Paint.FILTER_BITMAP_FLAG));// 抗锯齿
			cv.save(Canvas.ALL_SAVE_FLAG);// 保存
			onDrawBmp(cv);
			cv.restore();// 存储
		} else {
			Canvas cv = new Canvas(bmp);

			Paint paint = new Paint();
			paint.setXfermode(new PorterDuffXfermode(Mode.CLEAR));
			cv.drawPaint(paint);
			paint.setXfermode(new PorterDuffXfermode(Mode.SRC));

			cv.setDrawFilter(new PaintFlagsDrawFilter(0, Paint.ANTI_ALIAS_FLAG
					| Paint.FILTER_BITMAP_FLAG));// 抗锯齿
			cv.save(Canvas.ALL_SAVE_FLAG);// 保存
			onDrawBmp(cv);
			cv.restore();// 存储
		}
		return bmp;
	}

	private void onDrawBmp(Canvas canvas) {
		for (int i = 0; i < bars.length; i++) {
			bars[i][0] = bars[i][0] + bars[i][1];
			if(bars[i][0] <=0){
				bars[i][1] = -bars[i][1];//如果超出边界，则反向
				bars[i][0] = bars[i][1];
			} else if(bars[i][0] >=defaultHeight){
				bars[i][1] = -getSpeed();//如果归零了则重新设置负速度
				bars[i][0] = defaultHeight + bars[i][1];
			} else if(getReversal()){
				//中途转向
				bars[i][1] = -bars[i][1];//如果超出边界，则反向
			}
			RectF rect = new RectF(barWidth*i*2, bars[i][0],barWidth*i*2+barWidth, defaultHeight);// 设置个新的长方形
			canvas.drawRoundRect(rect, barWidth/2, barWidth/2, mPaint);
		}
	}
	
	private void initBars() {
		for (int i = 0; i < bars.length; i++) {
			bars[i][0]=defaultHeight/2;
			if(getReversal()){
				bars[i][1]=-getSpeed();
			} else {
				bars[i][1]=getSpeed();
			}
		}
	}
	
	/**
	 * @return 随机速度
	 */
	private int getSpeed() {
		return random.nextInt(SPEED_SPACE)+1;
	}
	
	/**
	 * @return 随机变向的概率
	 */
	private boolean getReversal() {
		return random.nextInt(REVERSAL_SPACE)==0;
	}
	
	public void startAni() {
		if(!isRunning){
			isRunning = true;
			postInvalidate();
		}
	}

	public void stopAni() {
		isRunning = false;
	}
	
	/**
	 * @return 是否自动控制动画启动
	 */
	public boolean isSelfAni() {
		return isSelfAni;
	}

	/**
	 * @param isSelfAni 是否自动控制动画启动
	 */
	public void setSelfAni(boolean isSelfAni) {
		this.isSelfAni = isSelfAni;
	}


	@Override
	protected void onWindowVisibilityChanged(int visibility) {
		super.onWindowVisibilityChanged(visibility);
		if(visibility == View.VISIBLE){
			if(isSelfAni)
				startAni();
		} else {
			stopAni();
		}
	}
}