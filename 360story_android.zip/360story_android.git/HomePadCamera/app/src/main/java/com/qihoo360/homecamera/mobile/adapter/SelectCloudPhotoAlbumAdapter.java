
package com.qihoo360.homecamera.mobile.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.core.beans.PhotoAlbumGroup;
import com.qihoo360.homecamera.mobile.utils.CompatibilitySupport;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SelectCloudPhotoAlbumAdapter extends BaseAdapter {

    private List<PhotoAlbumGroup> albums;

    private Context cxt;
    
    protected Set<String> mHighlightNodes = new HashSet<String>();

    public SelectCloudPhotoAlbumAdapter(Context context) {
        cxt = context;
    }

    public void setFileList(List<PhotoAlbumGroup> albums) {
        this.albums = albums;
    }

    @Override
    public int getCount() {
        if (albums != null)
            return albums.size();
        else
            return 0;

    }
    public List<PhotoAlbumGroup> getFileList() {
       return this.albums;
    }

    public void addHighlightXid(String xid) {
        mHighlightNodes.add(xid);
    }

    public void removeHighlightXid(String xid) {
        mHighlightNodes.remove(xid);
    }
    
    public void clearHighlightNodes() {
        mHighlightNodes.clear();
    }
    
    @Override
    public PhotoAlbumGroup getItem(int position) {
        return albums.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public void setData(ArrayList<PhotoAlbumGroup> data) {
        this.albums = data;
        notifyDataSetChanged();
    }

    @Override
    public boolean areAllItemsEnabled() {
        return false;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Holder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.select_album_item, parent, false);
            holder = new Holder();
            holder.icon = (ImageView) convertView.findViewById(R.id.album_icon);
            holder.txt = (TextView) convertView.findViewById(R.id.album_title);
            holder.detail = (TextView) convertView.findViewById(R.id.album_pic_count);
            holder.content = convertView.findViewById(R.id.content);
            convertView.setTag(holder);
        } else {
            holder = (Holder) convertView.getTag();
        }

        PhotoAlbumGroup album = albums.get(position);
        ImageLoader.getInstance().cancelDisplayTask(holder.icon);
        ImageLoader.getInstance().displayImage(album.getThumbnailUri(0), holder.icon, new ImageLoadingListener() {
            
            @Override
            public void onLoadingStarted(String imageUri, View view) {
                ImageView iv = (ImageView) view;
                iv.setImageResource(R.drawable.icon_image_empty);
            }
            
            @Override
            public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
                ImageView iv = (ImageView) view;
                iv.setImageResource(R.drawable.icon_image_empty);
            }
            
            @Override
            public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                ImageView iv = (ImageView) view;
                iv.setImageBitmap(loadedImage);
            }
            
            @Override
            public void onLoadingCancelled(String imageUri, View view) {}
        });
        holder.txt.setText(album.bucket_display_name);
        holder.detail.setText(cxt.getString(R.string.pic_count_unit, album.bucket_num));
        
        
        if (mHighlightNodes.contains(album.bucket_id)) {
            holder.content.setBackgroundColor(parent.getContext().getResources().getColor(R.color.choose_albums_list_press));
        } else {
            // 2.3 有高亮，且滑动时有随机黑条，只能舍弃2.3，不要按下效果了。
            if (CompatibilitySupport.isGreatOrEqual40()) {
                holder.content.setBackgroundResource(R.drawable.choose_album_to_upload_bg);
            } else {
                holder.content.setBackgroundColor(parent.getContext().getResources().getColor(R.color.choose_albums_list_normal));
            }
        }
        
        return convertView;
    }

    class Holder {
        ImageView icon;
        TextView txt, detail;
        View content;
    }
}
