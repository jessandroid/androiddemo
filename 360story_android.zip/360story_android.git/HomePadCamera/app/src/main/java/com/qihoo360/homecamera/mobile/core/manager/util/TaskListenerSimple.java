
package com.qihoo360.homecamera.mobile.core.manager.util;

public interface TaskListenerSimple {
    Object taskFinished(Object param);

    Object taskFailed(Object param);
}
