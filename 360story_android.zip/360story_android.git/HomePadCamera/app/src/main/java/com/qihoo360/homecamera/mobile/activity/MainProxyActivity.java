package com.qihoo360.homecamera.mobile.activity;

import android.app.Activity;
import android.os.Bundle;

import com.qihoo.sdk.report.QHStatAgent;
import com.qihoo360.homecamera.mobile.utils.CLog;


public class MainProxyActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onResume() {
        super.onResume();
        QHStatAgent.onResume(this);
        QHStatAgent.onPageStart(this, "MainProxyActivity");
        CLog.i("yanggang", "QualityChangeActivity onPageStart");
    }

    @Override
    protected void onPause() {
        super.onPause();
        QHStatAgent.onPause(this);
        QHStatAgent.onPageEnd(this, "MainProxyActivity");
        CLog.i("yanggang", "QualityChangeActivity onPageEnd");
    }
}
