
package com.qihoo360.homecamera.mobile.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.SysConfig;
import com.qihoo360.homecamera.mobile.adapter.SelectCloudPhotoAlbumAdapter;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.core.beans.PhotoAlbum;
import com.qihoo360.homecamera.mobile.core.beans.PhotoAlbumGroup;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.core.manager.util.TaskListenerSimple;
import com.qihoo360.homecamera.mobile.entity.ImageInfo;
import com.qihoo360.homecamera.mobile.entity.InnerMsg;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.ui.fragment.UploadAllPhotoToAlbumFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.UploadFragmentBase;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.DensityUtil;
import com.qihoo360.homecamera.mobile.utils.FileUtil;
import com.qihoo360.homecamera.mobile.utils.ImageUtil;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class AlbumUploadMainActivity extends BaseActivity implements ActionListener, OnClickListener,
        OnItemClickListener, OnItemLongClickListener {
    public static FragmentManager fm;
    private String type;

    public static final int ALBUM_ADD_LOCAL_IMAGE = 10001;
    public static final String ALBUM_CAMERA_LOCAL_CACHE_DIR = "camera_upload";
    
    public static final String IMG_TYPE_LOCAL = "local";
    public static final String IMG_TYPE_CHOOSE_AVATAR = "choose_avatar";
    public static final String IMG_TYPE_FEEDBACK = "feedback";

    private TextView titleMiddle, btn_right, choose_thump_dir;
    private ImageView arrow;
    private RelativeLayout mBackZoneIv;

    private UploadFragmentBase mUploadFragmentBase;
    private PopupWindow mPopupWindow;
    private FrameLayout backgroundLayout;
    private ListView listView;
    private SelectCloudPhotoAlbumAdapter simpleAdapter;
    private Uri mCurCameraFileUri;
    boolean isChooseAvatar = false;

    public static void startActivity(Context context, String type) {
        Intent intent = new Intent(context, AlbumUploadMainActivity.class);
        Bundle mBundle = new Bundle();
        mBundle.putString("type", type);
        intent.putExtras(mBundle);
        context.startActivity(intent);
    }

    public static void startActivityForResult(Activity context, int requestCode, String type) {
        Intent intent = new Intent(context, AlbumUploadMainActivity.class);
        Bundle mBundle = new Bundle();
        mBundle.putString("type", type);
        intent.putExtras(mBundle);
        context.startActivityForResult(intent, requestCode);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.album_local_main);
        setTintManagerQWork(true);
        tintManager.setStatusBarTintColor(Color.parseColor("#00aeff"));
        fm = getSupportFragmentManager();
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            type = bundle.getString("type");
        }
        simpleAdapter = new SelectCloudPhotoAlbumAdapter(this);
        if (IMG_TYPE_LOCAL.equals(type) || IMG_TYPE_FEEDBACK.equals(type)) {
            isChooseAvatar = false;
        } else if (IMG_TYPE_CHOOSE_AVATAR.equals(type)) {
            isChooseAvatar = true;
        }

        mUploadFragmentBase = UploadAllPhotoToAlbumFragment.newInstance(isChooseAvatar);
        initView();
        initFragment(mUploadFragmentBase);
        initPopupWindow();
        loadAlbumInfoLocal();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        //super.onSaveInstanceState(outState);
        // recreate and reinit(fragment and members)
    }

    void initView() {
        titleMiddle = (TextView) findViewById(R.id.common_title_text);
        arrow = (ImageView) findViewById(R.id.arrow);
        choose_thump_dir = (TextView) findViewById(R.id.choose_thum_dir);
        choose_thump_dir.setOnClickListener(this);
        findViewById(R.id.choose_thum_dir_layout).setOnClickListener(this);
        btn_right = (TextView) findViewById(R.id.btn_right);
        mBackZoneIv = (RelativeLayout) findViewById(R.id.back_zone);
        mBackZoneIv.setOnClickListener(this);
        if (isChooseAvatar) {
            btn_right.setVisibility(View.GONE);
        } else {
            btn_right.setVisibility(View.VISIBLE);
            btn_right.setText(R.string.send_img_right_txt);
            btn_right.setOnClickListener(this);
        }
    }

    public static void changeFragment(Fragment f) {
        changeFragment(f, false);
    }

    public static void initFragment(Fragment f) {
        changeFragment(f, true);
    }

    private static void changeFragment(Fragment f, boolean init) {
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.simple_fragment, f);
        if (!init)
            ft.addToBackStack(null);
        ft.commit();
    }

    @Override
    protected void onResume() {
        super.onResume();
        GlobalManager.getInstance().getLocalManager().registerActionListener(this);
        if (mPopupWindow != null) {
            if (mPopupWindow.isShowing()) {
                mPopupWindow.dismiss();
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_right:
                btn_right.setEnabled(false);
                final ArrayList<PhotoAlbum> arrayList = ((UploadAllPhotoToAlbumFragment) mUploadFragmentBase)
                        .getChoosedItem();
                if (arrayList == null || arrayList.isEmpty()) {
                    CameraToast.showToast(this, Utils.getString(R.string.select_first_prompt));
//                    CameraToast.showToast(this, Utils.getString(R.string.select_first_prompt));
                    btn_right.setEnabled(true);
                } else {
                    doCompressImage(arrayList);
                }
                break;
            case R.id.choose_thum_dir_layout:
                showPopup();
                break;
            case R.id.choose_thum_dir:
                showPopup();
                break;
            case R.id.back_zone:
                finish();
                break;
        }
    }

    public void setCurrentCameraUri(Uri uri) {
        mCurCameraFileUri = uri;
    }

    public void doCompressImage(final ArrayList<PhotoAlbum> arrayList) {
        ImageUtil imageUtil = new ImageUtil();
        imageUtil.compressImage(arrayList , getIntent().getBooleanExtra("must_png" , false), new TaskListenerSimple() {
            @Override
            public Object taskFinished(Object param) {
                ImageInfo imageInfo = (ImageInfo) param;
                //GlobalManager.getInstance().commentManager().sendImageInfo(imageInfo);
                finish();
                return imageInfo;
            }

            @Override
            public Object taskFailed(Object param) {
                //GlobalManager.getInstance().commentManager().sendImageInfoError();
                finish();
                return null;
            }
        }, false);
    }

    @Override
    public Object actionPerformed(int actionCode, Object... args) {
        switch (actionCode) {
            case Actions.Activity.SELECT_SIZE_CHANGE:
                break;
            case Actions.FileListMenu.EXIT_MULITI:
                mUploadFragmentBase.clearAllSelected();
                break;
            case Actions.FileListMenu.SELECT_ALL:
                break;
            case Actions.Local.IMG_QUEUE_LOADED:
                ArrayList<PhotoAlbumGroup> data = (ArrayList<PhotoAlbumGroup>) args[0];
                PhotoAlbumGroup defaultAlbum = getDefaultBucket(data);
                simpleAdapter.setData(data);
                simpleAdapter.clearHighlightNodes();
                simpleAdapter.addHighlightXid(defaultAlbum.bucket_id);
                GlobalManager.getInstance().getLocalManager()
                        .publishAction(Actions.UploadToAlbum.CHOOSE_ALBUM, defaultAlbum);
                titleMiddle.setText(defaultAlbum.bucket_display_name);
                return true;
            case Actions.Local.UPLOAD_ALBUM_ERROR:
                String msg = args[0].toString();
                CameraToast.show(AlbumUploadMainActivity.this, msg, Toast.LENGTH_SHORT);
                break;
            case Actions.Local.UPLOAD_ALBUM_AVATAR_CHOOSE:
                PhotoAlbum photoAlbum = (PhotoAlbum) args[0];
                if (photoAlbum != null) {
                    Intent intent = new Intent();
                    intent.putExtra("result", photoAlbum._data);
                    setResult(RESULT_OK, intent);
                    finish();
                }
                return true;
            default:
                break;
        }
        return Actions.ACTION_NOT_PROCESSED;
    }

    @Override
    public void onBackPressed() {
        if (mUploadFragmentBase.onBackPressed()) {
            return;
        }
        finish();
        overridePendingTransition(R.anim.left_in, R.anim.right_out);
    }

    @Override
    public void onDestroy() {
        GlobalManager.getInstance().getLocalManager().removeActionListener(this);
        super.onDestroy();
    }

    private void loadAlbumInfoLocal() {
        GlobalManager.getInstance().getLocalManager().loadPhotoAlbums();
    }

    // region More Popup

    @SuppressWarnings("deprecation")
    private void initPopupWindow() {
        View contentView = getLayoutInflater()
                .inflate(R.layout.upload_to_album_popup, null);
        listView = (ListView) contentView.findViewById(R.id.listView);
        listView.setDivider(null);
        listView.setAdapter(simpleAdapter);
        listView.setSelector(new ColorDrawable(Color.TRANSPARENT));
        listView.setOnItemClickListener(this);
        listView.setOnItemLongClickListener(this);
        listView.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,
                SysConfig.BASE_SCREEN_HEIGHT / 2));
        backgroundLayout = (FrameLayout) contentView.findViewById(R.id.bg);
        backgroundLayout.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                closeMoreDialog();
            }
        });
        mPopupWindow = new PopupWindow(contentView,
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        mPopupWindow.setBackgroundDrawable(new BitmapDrawable());
        mPopupWindow.setAnimationStyle(R.style.popu_animation);
        mPopupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {

            @Override
            public void onDismiss() {
                arrow.setImageResource(R.drawable.arrow_down);
            }
        });
        mPopupWindow.setFocusable(true);
    }

    private void showPopup() {
        if (choose_thump_dir != null) {
            arrow.setImageResource(R.drawable.arrow_up);
            mPopupWindow.showAtLocation(choose_thump_dir, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0,
                    DensityUtil.dip2px(47)); // 设置layout在PopupWindow中显示的位置
        }
    }

    public void closeMoreDialog() {
        if (mPopupWindow != null) {
            arrow.setImageResource(R.drawable.arrow_down);
            mPopupWindow.dismiss();
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        PhotoAlbumGroup pag = simpleAdapter.getItem(position);
        simpleAdapter.clearHighlightNodes();
        simpleAdapter.addHighlightXid(pag.bucket_id);
        GlobalManager.getInstance().getLocalManager().publishAction(Actions.UploadToAlbum.CHOOSE_ALBUM, pag);
        titleMiddle.setText(pag.bucket_display_name);
        closeMoreDialog();
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
        PhotoAlbumGroup pag = simpleAdapter.getItem(position);
        simpleAdapter.clearHighlightNodes();
        simpleAdapter.addHighlightXid(pag.bucket_id);
        GlobalManager.getInstance().getLocalManager().publishAction(Actions.UploadToAlbum.CHOOSE_ALBUM, pag);
        titleMiddle.setText(pag.bucket_display_name);

        closeMoreDialog();
        return true;
    }

    private PhotoAlbumGroup getDefaultBucket(ArrayList<PhotoAlbumGroup> list) {
        if (list.size() == 0) {
            PhotoAlbumGroup group = new PhotoAlbumGroup();
            group.bucket_id = Constants.ID_RECENT_ALBUMS;
            group.bucket_num = 0;
            group.bucket_display_name = Utils.getString(R.string.image_display_name_prompt);
            group.summary = "";
            group.mimeType = "image/jpeg";
            list.add(group);
            findViewById(R.id.arrow).setVisibility(View.GONE);
            findViewById(R.id.bottomZone).setVisibility(View.GONE);
            btn_right.setVisibility(View.GONE);
        }

        PhotoAlbumGroup camera = null;
        for (String path : Constants.cameraSnap) {
            camera = existInList(String.valueOf(path.toLowerCase(Locale.getDefault()).hashCode()), list);
            if (camera != null) {
                break;
            }
        }
        if (camera == null || isChooseAvatar) {
            camera = list.get(0);
        }
        return camera;
    }

    private PhotoAlbumGroup existInList(String key, ArrayList<PhotoAlbumGroup> mDataList) {
        if (mDataList != null && !mDataList.isEmpty() && key != null) {
            for (PhotoAlbumGroup group : mDataList) {
                if (group != null && !TextUtils.isEmpty(group.bucket_id) && group.bucket_id.equals(key)) {
                    return group;
                }
            }
        }
        return null;
    }

    // endregion

    @Override
    public int getProperty() {
        // TODO Auto-generated method stub
        return 0;
    }

    // region Tack Photo
    private static String mPhotoPath;

    public static Uri startTakePhotoActivity(Activity context, int requestCode) {
        PackageManager packageManager = context.getPackageManager();
        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA)) {
            CameraToast.show("设备不支持拍照，请尝试使用其他设备！", Toast.LENGTH_SHORT);
            return null;
        }

//        File fileDir = FileUtil.getmSDCacheDir();
        File fileDir = FileUtil.getInstance().getSnapshotFile();
        fileDir = new File(fileDir.getPath() + File.separator + AlbumUploadMainActivity.ALBUM_CAMERA_LOCAL_CACHE_DIR);
        if (!fileDir.exists()) {
            fileDir.mkdirs();
        }

        mPhotoPath = fileDir.getPath() + File.separator +
                "camera_" + Calendar.getInstance().getTimeInMillis() + ".jpg";
        File filePath = new File(mPhotoPath);
        Uri targetUri = Uri.fromFile(filePath);

        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, targetUri);
        context.startActivityForResult(intent, requestCode);
        if (Utils.isIntentSafe(intent)) {
            return targetUri;
        } else {
            CameraToast.show(Utils.getString(R.string.camera_app_not_found_prompt), Toast.LENGTH_SHORT);
            return null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case ALBUM_ADD_LOCAL_IMAGE:
                if (resultCode == RESULT_OK) {
                    Intent intent = new Intent();
                    intent.putExtra("result", mPhotoPath);
                    setResult(RESULT_OK, intent);
                    finish();
                }
                break;
        }
    }

    // endregion

    @Override
    protected void switchMode(boolean speaker_mode) {
        super.switchMode(speaker_mode);
    }

    @Override
    public void onMessage(InnerMsg imsg) {
        super.onMessage(imsg);
    }

    @Override
    public void setTintManagerQWork(boolean work) {
        super.setTintManagerQWork(work);
    }
}
