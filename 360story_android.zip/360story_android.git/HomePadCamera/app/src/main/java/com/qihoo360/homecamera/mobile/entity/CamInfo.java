package com.qihoo360.homecamera.mobile.entity;

/**
 * Created by zhaojunbo on 2016/5/5.
 * desc:
 */
public class CamInfo {

    public String sn = "";
    public String screenPath = "";
    public long createTime = 0;

}
