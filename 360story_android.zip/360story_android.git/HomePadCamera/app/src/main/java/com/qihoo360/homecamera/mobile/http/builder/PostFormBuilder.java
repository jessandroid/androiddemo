
package com.qihoo360.homecamera.mobile.http.builder;

import com.qihoo360.homecamera.mobile.http.request.PostFormRequest;
import com.qihoo360.homecamera.mobile.http.request.RequestCall;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * Created by zhy on 15/12/14.
 */
public class PostFormBuilder extends OkHttpRequestBuilder {
    private List<FileInput> files = new ArrayList<FileInput>();
    private String upUrl;

    @Override
    public RequestCall build() {
        return new PostFormRequest(url, tag, params, headers, files, cookie).build();
    }

    @Override
    public OkHttpRequestBuilder isDebug(boolean debug) {
        this.debug = debug;
        return this;
    }

    @Override
    public OkHttpRequestBuilder isHttps(boolean https) {
        this.https = https;
        return this;
    }

    @Override
    public OkHttpRequestBuilder isLogUpload(String up) {
        this.upUrl = up;
        return this;
    }

    public PostFormBuilder addFile(String name, String filename, File file) {
        files.add(new FileInput(name, filename, file));
        return this;
    }

    public static class FileInput {
        public String key;
        public String filename;
        public File file;

        public FileInput(String name, String filename, File file) {
            this.key = name;
            this.filename = filename;
            this.file = file;
        }

        @Override
        public String toString() {
            return "FileInput{" +
                    "key='" + key + '\'' +
                    ", filename='" + filename + '\'' +
                    ", file=" + file +
                    '}';
        }
    }

    //
    @Override
    public PostFormBuilder url(String url) {
        if (isStatic) {
            this.url = url;
        } else {
            this.url = url.startsWith("http") || url.startsWith("https") ? url : Utils.getUrl(url, this.https);
        }
        return this;
    }

    @Override
    public OkHttpRequestBuilder isStatic(boolean isStatic) {
        this.isStatic = isStatic;
        return this;
    }

    @Override
    public PostFormBuilder tag(Object tag) {
        this.tag = tag;
        return this;
    }

    @Override
    public PostFormBuilder addParams(String key, String val) {
        if (this.params == null) {
            params = new LinkedHashMap<String, String>();
        }
        params.put(key, val);
        return this;
    }

    @Override
    public PostFormBuilder addHeader(String key, String val) {
        if (this.headers == null) {
            headers = new LinkedHashMap<String, String>();
        }
        headers.put(key, val);
        return this;
    }

}
