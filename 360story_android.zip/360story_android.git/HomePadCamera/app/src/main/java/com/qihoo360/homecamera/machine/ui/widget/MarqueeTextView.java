package com.qihoo360.homecamera.machine.ui.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.TextView;

/**
 * @author chengxiangyu
 * 跑马灯专用textview
 */
public class MarqueeTextView extends TextView{
    private boolean isFocused = true;//如果是ture，则默认滚动

    public MarqueeTextView(Context context) {
        super(context);
    }
    
    public MarqueeTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }
    
    public void setFocused(boolean isFocused) {
        this.isFocused = isFocused;
    }

    public boolean isFocused() {
        return isFocused;
    }

}
