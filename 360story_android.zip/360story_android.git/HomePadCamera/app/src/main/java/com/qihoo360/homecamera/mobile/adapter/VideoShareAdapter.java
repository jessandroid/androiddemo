package com.qihoo360.homecamera.mobile.adapter;

import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.qihoo360.homecamera.mobile.R;

import java.util.List;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2015/8/11
 * Time: 10:39
 * To change this template use File | Settings | File Templates.
 */
public class VideoShareAdapter extends BaseAdapter {

    private List<ResolveInfo> list;
    LayoutInflater inflater;
    private PackageManager pManager;

    public VideoShareAdapter(Context context, List<ResolveInfo> list) {
        inflater = LayoutInflater.from(context);
        this.list = list;
        pManager = context.getPackageManager();
    }

    public int getCount() {
        if (list == null)
            return 0;
        return list.size();
    }

    public Object getItem(int position) {
        return list.get(position);
    }

    public long getItemId(int position) {
        return position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder viewHolder = null;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.album_photo_share_to_app_list_item, null);
            viewHolder = new ViewHolder();
            viewHolder.appIcon = (ImageView) convertView.findViewById(R.id.appIcon);
            viewHolder.appName = (TextView) convertView.findViewById(R.id.appName);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        ResolveInfo resolveInfo = list.get(position);
        viewHolder.resolveInfo = resolveInfo;
        viewHolder.appIcon.setImageDrawable(resolveInfo.loadIcon(pManager));
        viewHolder.appName.setText(resolveInfo.loadLabel(pManager).toString());
        return convertView;
    }

    class ViewHolder {
        ImageView appIcon;
        TextView appName;
        ResolveInfo resolveInfo;
    }

}
