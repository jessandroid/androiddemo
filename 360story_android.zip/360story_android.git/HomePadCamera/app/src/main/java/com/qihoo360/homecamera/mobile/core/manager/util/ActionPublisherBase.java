
package com.qihoo360.homecamera.mobile.core.manager.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map.Entry;

import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Looper;
import android.os.Message;

import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.util.Stoppable;
import com.qihoo360.homecamera.mobile.utils.CLog;

public class ActionPublisherBase implements ActionPublisher, Callback, Stoppable {
    private HashMap<ActionListener, HashSet<Integer>> mListenerTable;
    protected final static int DELEGATE_MESSAGE = 909;
    protected Handler mUiHandler;
    private boolean mIsStopped = false;

    public ActionPublisherBase() {
        mListenerTable = new HashMap<ActionListener, HashSet<Integer>>();
        mUiHandler = new Handler(Looper.getMainLooper(), this);
    }

    @Override
    public void registerActionListener(ActionListener listener) {
        registerActionListener(listener, null);
    }

    @Override
    public synchronized void registerActionListener(ActionListener listener, int... caredActions) {
        if (mListenerTable == null) {
            mListenerTable = new HashMap<ActionListener, HashSet<Integer>>();
        }
        if (mListenerTable.containsKey(listener) == true) {
            if (caredActions != null && caredActions.length != 0) {
                //appending to exiting caredActions
                final HashSet<Integer> caredActionSet = mListenerTable.get(listener);
                if (caredActionSet == null) {
                    mListenerTable.put(listener, fromArray(caredActions));
                } else {
                    for (int i : caredActions) {
                        int actionInteger = Integer.valueOf(i);
                        if (caredActionSet.contains(actionInteger) == false) {
                            caredActionSet.add(actionInteger);
                        }
                    }
                }
            }
        } else {
            if (caredActions == null || caredActions.length == 0) {
                mListenerTable.put(listener, null);
            } else {
                mListenerTable.put(listener, fromArray(caredActions));
            }
        }
    }

    @Override
    public synchronized void removeActionListener(ActionListener listener) {
        if (mListenerTable != null) {
            mListenerTable.remove(listener);
        }
    }

    @Override
    public void publishAction(int actionCode, Object... args) {
        if (Looper.getMainLooper() == Looper.myLooper()) {
            publishActionInUiThread(actionCode, args);
        } else {
            if (mUiHandler == null) {
                mUiHandler = new Handler(Looper.getMainLooper(), this);
            }
            mUiHandler.obtainMessage(DELEGATE_MESSAGE, actionCode, 0, args).sendToTarget();
        }
    }

    //This runs in ui thread
    @Override
    public boolean handleMessage(Message msg) {
        switch (msg.what) {
            case DELEGATE_MESSAGE: {
                publishActionInUiThread(msg.arg1, (Object[]) msg.obj);
                break;
            }
        }
        return true;
    }

    private final void publishActionInUiThread(final int actionCode, final Object... args) {
        if (mListenerTable == null) {
            return;
        }
        
        //增加action接受处理优先级功能  by changxiao  进一步优化空间:不同action也能区分优先级
        List<Entry<ActionListener,HashSet<Integer>>> entryList = new ArrayList<Entry<ActionListener,HashSet<Integer>>>(mListenerTable.entrySet());
        Collections.sort(entryList, new Comparator<Entry<ActionListener,HashSet<Integer>>>() {
            @Override
            public int compare(Entry<ActionListener, HashSet<Integer>> lhs, Entry<ActionListener, HashSet<Integer>> rhs) {
                return rhs.getKey().getProperty() - lhs.getKey().getProperty();
            }
        });
        for (Entry<ActionListener,HashSet<Integer>> e : entryList) {
            HashSet<Integer> caredActions = e.getValue();
            if (caredActions == null || caredActions.contains(Integer.valueOf(actionCode)) == true) {
                try {
                    // 增加 action 消费机制  by changxiao
                    if(e.getKey().actionPerformed(actionCode, args) == Actions.ACTION_STOP_PROPAGATION) {
                        break;
                    }
                    //leixiaojun: if actionPerformed do stopNow(), then mListenerTable will be clear
                    if (mListenerTable.size() == 0) {
                        break;
                    }
                } catch (Throwable ex) {
                    CLog.e("error", "Error while processing action " + actionCode + ", with listener " + e.getKey().getClass().getSimpleName());
                    ex.printStackTrace();
                }
            }
        }
    }

    private final static HashSet<Integer> fromArray(int[] arrary) {
        HashSet<Integer> r = new HashSet<Integer>(arrary.length);
        for (int i : arrary) {
            r.add(i);
        }
        return r;
    }

    @Override
    public void destroyNow() {
        mListenerTable = null;
        mUiHandler = null;
    }

    @Override
    public void stopNow() {
        synchronized (this) {
            mListenerTable.clear();
        }
        mUiHandler.removeCallbacksAndMessages(null);
        mIsStopped = true;
    }

    @Override
    public boolean isStopped() {
        return mIsStopped;
    }
}
