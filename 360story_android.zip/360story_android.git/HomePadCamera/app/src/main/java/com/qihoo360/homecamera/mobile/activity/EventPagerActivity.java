/*******************************************************************************
 * Copyright 2011, 2012 Chris Banes.
 * <p/>
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * <p/>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p/>
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 *******************************************************************************/

package com.qihoo360.homecamera.mobile.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.support.v7.widget.LinearLayoutManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.OrientationEventListener;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.drawable.GlideDrawable;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.google.gson.Gson;
import com.qihoo360.homecamera.device.config.StoryMachineConsts;
import com.qihoo360.homecamera.mobile.BuildConfig;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.config.Const;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.config.DefaultClientConfig;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.db.PadInfoWrapper;
import com.qihoo360.homecamera.mobile.db.StoryAndVideoCacheWrapper;
import com.qihoo360.homecamera.mobile.download.CallBack;
import com.qihoo360.homecamera.mobile.download.DownloadException;
import com.qihoo360.homecamera.mobile.download.DownloadManager;
import com.qihoo360.homecamera.mobile.download.DownloadRequest;
import com.qihoo360.homecamera.mobile.entity.AlbumShareEntity;
import com.qihoo360.homecamera.mobile.entity.ImageInfoEntity;
import com.qihoo360.homecamera.mobile.entity.ShareStoryEntity;
import com.qihoo360.homecamera.mobile.http.OkHttpUtils;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.player.Player;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.DensityUtil;
import com.qihoo360.homecamera.mobile.utils.FileUtil;
import com.qihoo360.homecamera.mobile.utils.ImageCache;
import com.qihoo360.homecamera.mobile.utils.ImageUtil;
import com.qihoo360.homecamera.mobile.utils.Preferences;
import com.qihoo360.homecamera.mobile.utils.QHStatAgentHelper;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.utils.VideoCache;
import com.qihoo360.homecamera.mobile.widget.CamAlertDialog;
import com.qihoo360.homecamera.mobile.widget.JiaProgressDialog;
import com.qihoo360.homecamera.mobile.widget.gallary.HackyViewPager;
import com.qihoo360.homecamera.mobile.widget.gallary.PhotoView;
import com.qihoo360.homecamera.mobile.widget.gallary.PhotoViewAttacher;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.ref.SoftReference;
import java.lang.ref.WeakReference;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.ExecutionException;

import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;


public class EventPagerActivity extends BaseActivity implements ActionListener, View.OnClickListener, Player.VideoDownloadCompleteListener, Player.ErrorListener {

    private static final String ISLOCKED_ARG = "isLocked";
    private HackyViewPager mViewPager;
    //    private DisplayImageOptions options;
    private ImageView down_load_image;
    public final static int EVENT_PAGE = 1009;
    public final static int EVENT_PAGE_SELECT = 1010;
    public final static int EVENT_PAGE_UNSELECT = 1011;

    private Handler mHandler = new Handler();

    private static ArrayList<ImageInfoEntity> mEventsList = new ArrayList<>();
    private static int position = 0;
    private TextView tv_title, tv_time;
    private SamplePagerAdapter adapter;
    private String from;

    //防止分享按钮多次点击标志
    private boolean isMagicClickable = true;
    private TextView totalText;
    private ImageView mBackIv;
    private CheckBox mSelectedCB;
    private ImageView mDeleteIv;

    private CamAlertDialog camAlertDialog;
    private PackageManager pManager;
    private GridView video_share_grid_layout;
    private ImageView close;
    private TextView title;
    private DownloadManager downloadManager;
    private File mDownloadDir = FileUtil.getInstance().getDayGifFile();
    private WeakReference<EventPagerActivity> weakReference;


    //---play---
    private static final String TAG = "EventPagerActivity";
    private Player mPlayer;
    private SurfaceView mSurfaceView;
    private SurfaceHolder mSurfaceHolder;
    private boolean mIsPlayerAvailable = false;

    private LinearLayout mVideoOperation;
    private LinearLayout mVideoOperationBackground;
    private SeekBar mSeekBar;
    private TextView mTvPlayTime;
    private TextView mTvTotalTime;
    private ImageView mIvPlay;
    private ImageView mIvPause;
    private ImageView mIvVideoOperationBackground;
    private LinearLayout mIvOperate;
    private ImageView mIvOrientationFullScreen;
    private ImageView mIvOrientationResize;
    private ImageView mLoading;
    private RelativeLayout mLoadingArea;
    private ImageView mPreviewLoading;
    private RelativeLayout mPreviewLoadingArea;
    private ImageView mRetry;
    private LinearLayout mRetryArea;

    private FrameLayout mControlZone;
    private RelativeLayout mPhotoViewerTitle;

    private final static int TIME_CONVERT = 1000000;
    private ImageView mIvShare;

    //onResume时是否需要重新播放
    private boolean mIsNeedReplay = true;
    //onResume时 帮助判断 当前是否处于视频模式下
    private boolean mIsVideoMode = false;

    //是否为全屏模式 全屏不显示所有
    private boolean mIsFullScreen = false;

    private int mCurPosition = 0;
    private int mCurDuration = 0;
    private static String mSn = "";

    //记录当前是否为横屏
    private boolean mIsLandScreen = false;

    private boolean mInitComplete = false;

    private RelativeLayout mVideoContainer;
    private RelativeLayout mPreviewContainer;
    private RelativeLayout mOperateContainer;

    //记录从notification进来的 需要提示是否中断通话
    //从notification来的数据可能会来着不同的sn数据 需要记录最先显示的sn 退出时 返回到mainactivity的小视频类别 并且 切换设备
    private static boolean mIsFromNotification = false;

    private WebChangeBroadcastReceiver mWebChangeBroadcastReceiver;

    private String imagePath;

    //当前正在播放本地还是在线视频
    private boolean mIsPlayLocalVideo = false;
    private HashMap<String, Object> _4sbQds = new HashMap<String, Object>();
    private HashMap<String, Object> qds4sb = new HashMap<String, Object>();
    private HashMap<String, String> storyMachineStick = new HashMap<>();
    private long t4Sbstart = 0;
    private boolean flag4qds = false;
    private long netxt4Sb = 0;
    private ImageInfoEntity event;
    private DownloadRequest request;

    //记录卡顿事件
    private boolean startWatchLag = false;
    private int lagCountTemp = 0;
    private int lagCount = 0;

    private static boolean mIsFromStoryMachine;//是否是来自故事机的小视频

    public static void startActivity(ArrayList<ImageInfoEntity> list, Activity context, int pos, IDeleteCallback iDeleteCallback, boolean isFromStoryMachine) {
        if (list == null) {
            return;
        }

        if (list.size() == 0) {
            return;
        }

        EventPagerActivity.iDeleteCallback = iDeleteCallback;
        mEventsList = list;
        position = pos;

        SoftReference<MainActivity> mainSoft = new SoftReference<MainActivity>((MainActivity) context);
        MainActivity mainActivity = mainSoft.get();
        if (mainActivity.deviceInfo != null) {
            mSn = mainActivity.deviceInfo.getSn();
        }
        if (position >= list.size()) {
            position = 0;
        }
        mIsFromStoryMachine = isFromStoryMachine;
        CLog.justalkFile("list_err_act_", list);
        Intent intent = new Intent();
        intent.setComponent(new ComponentName(context, EventPagerActivity.class));
        context.startActivityForResult(intent, EVENT_PAGE);

        mIsFromNotification = false;
    }

    public static void startShareActivity(ArrayList<ImageInfoEntity> list, Context context, int pos, IDeleteCallback iDeleteCallback) {
        if (list == null) {
            return;
        }

        if (list.size() == 0) {
            return;
        }

        EventPagerActivity.iDeleteCallback = iDeleteCallback;
        mEventsList = list;
        position = pos;
        if (position >= list.size()) {
            position = 0;
        }

        mSn = list.get(position).sn;
        CLog.justalkFile("list_err_push_", list);
        Intent intent = new Intent();
        intent.setComponent(new ComponentName(context, EventPagerActivity.class));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);

        mIsFromNotification = true;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        CLog.startTimer("EventPagerActivity");
        super.onCreate(savedInstanceState);

        //屏幕不锁屏
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

//        setContentView(R.layout.activity_main);
        weakReference = new WeakReference<>(this);
        setTintManagerQWork(true);
        tintManager.setTintColor(Color.parseColor("#212121"));
//        options = new DisplayImageOptions.Builder().cloneFrom(ImageLoaderHelper.DEFAULT_LOCAL_DISPLAY_OPTIONS)
//                .showImageForEmptyUri(R.drawable.camera_default_icon_bg)
//                .showImageOnFail(R.drawable.camera_default_icon_bg)
//                .showImageOnLoading(R.drawable.camera_default_icon_bg).build();

        setContentView(R.layout.event_safe_viewpager_layout);
        mSelectedCB = (CheckBox) findViewById(R.id.btn_selected);
        mSelectedCB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int currentItem = mViewPager.getCurrentItem();
                mEventsList.get(currentItem).isChecked = !mEventsList.get(currentItem).isChecked;
            }
        });
        mDeleteIv = (ImageView) findViewById(R.id.iv_delete);
        mDeleteIv.setOnClickListener(this);

        mBackIv = (ImageView) findViewById(R.id.btn_back);
        mBackIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                finish();
                onBackPressed();
            }
        });
        tv_title = (TextView) findViewById(R.id.tv_title);
        mIvShare = (ImageView) findViewById(R.id.btn_share_image_magic);
        mIvShare.setOnClickListener(this);
        View faceZoneView = findViewById(R.id.bottom_ll_single);
        View safeZoneView = findViewById(R.id.bottom_ll);

        tv_time = (TextView) findViewById(R.id.tv_time);
        totalText = (TextView) findViewById(R.id.image_total);
        down_load_image = (ImageView) findViewById(R.id.down_load_image);
        down_load_image.setVisibility(View.GONE);
        Utils.ensureVisbility(safeZoneView, View.VISIBLE);
        down_load_image.setVisibility(View.VISIBLE);
        down_load_image.setOnClickListener(mDownloadListener);
        mViewPager = (HackyViewPager) findViewById(R.id.view_pager);
        adapter = new SamplePagerAdapter(this, mEventsList);

        mViewPager.setAdapter(adapter);

        mViewPager.setOnPageChangeListener(new OnPageChangeListener() {
            @SuppressLint("SimpleDateFormat")
            @Override
            public void onPageSelected(int position) {
                upDateTitle();
                flag4qds = false;
                if (mInitComplete) {
                    stopCurrentVideo();
                    lagCount = lagCountTemp;
                    qds4sb.put("lag_count", lagCount);
                    storyMachineStick.put("lag_count", String.valueOf(lagCount));
                    if(!mIsFromStoryMachine){
                        QHStatAgentHelper.commitCommonEventHash("S_Video_bf010", qds4sb);
                    }else{
                        QHStatAgentHelper.doSmallVideoPlayStick(storyMachineStick);
                    }
                    lagCountTemp = 0;
                    startWatchLag = false;
                    CLog.i("test2", "S_Video_bf010 lagcount = " + lagCount);
                    CLog.justalkFile("list_err_act_", mEventsList.get(position));
                    hideRetryArea();
                }
            }

            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });

        mViewPager.setTouchCallback(mViewPagerCallback);
        mViewPager.setCurrentItem(position, true);
        if (position == 0) {
            upDateTitle();
        }
        if (savedInstanceState != null) {
            boolean isLocked = savedInstanceState.getBoolean(ISLOCKED_ARG, false);
            ((HackyViewPager) mViewPager).setLocked(isLocked);
        }

        initPlayVideo();
        initNetOperation();
        initOrientationEvent();

        registBroadcast();

        //横屏播放时 不显示下载栏
        int currentOrientation = getResources().getConfiguration().orientation;
        if (currentOrientation == Configuration.ORIENTATION_LANDSCAPE) {
            setLandscapeMode();
        } else {
            setPortraitMode();
        }

        mInitComplete = true;

        //需要提示是否中断通话
        if (mIsFromNotification) {
            showEndCallingDialog();
        }

        CLog.i("test2", "event page oncreat cost = " + CLog.endTimer("EventPagerActivity"));
    }

    //点击小视频通知，singleTop在栈顶的时候触发
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);

        stopCurrentVideo();
        adapter = new SamplePagerAdapter(this, mEventsList);
        mViewPager.setAdapter(adapter);
        mViewPager.setCurrentItem(position, true);
        setPicMode();
        upDateTitle();
    }

    private void initPlayVideo() {
        mIsPlayerAvailable = false;

        try {
            Player.init(this);

            mIsPlayerAvailable = true;

        } catch (Exception e) {
            CLog.e(String.format("the e is %s ", e.getMessage()));
            mIsPlayerAvailable = false;
        }

        if (mIsPlayerAvailable) {
            mPlayer = new Player();
        }

        mSurfaceView = (SurfaceView) findViewById(R.id.surfaceView);
        mSurfaceHolder = mSurfaceView.getHolder();
        mSurfaceHolder.addCallback(mCallback);
//        mSurfaceHolder.setFormat(PixelFormat.TRANSPARENT);
//        Canvas canvas = mSurfaceHolder.lockCanvas();
//        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
//        mSurfaceView.setOnClickListener(this);
        mSurfaceView.setOnTouchListener(mSurfaceTouchListener);

        //设置setFixedSize 解决视频播放暂停 旋转导致上一帧绘制不对
        WindowManager wm = this.getWindowManager();
        int width = wm.getDefaultDisplay().getWidth();
        mSurfaceHolder.setFixedSize(width, (int) (width / VIDEO_SHOW_SCALE));


        mVideoOperation = (LinearLayout) findViewById(R.id.video_operation);
        //解决太容易触发全屏操作
        mVideoOperation.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return true;
            }
        });
        mVideoOperationBackground = (LinearLayout) findViewById(R.id.video_operation_background);
        mTvPlayTime = (TextView) findViewById(R.id.video_play_time);
        mTvTotalTime = (TextView) findViewById(R.id.video_total_time);
        mIvPlay = (ImageView) findViewById(R.id.iv_video_operate_play);
        mIvPlay.setOnClickListener(this);
        mIvPause = (ImageView) findViewById(R.id.iv_video_operate_pause);
        mIvPause.setOnClickListener(this);
        mIvOperate = (LinearLayout) findViewById(R.id.iv_video_operate);
        mIvOperate.setOnClickListener(this);
        mIvVideoOperationBackground = (ImageView) findViewById(R.id.video_container_background);
        mIvOrientationFullScreen = (ImageView) findViewById(R.id.iv_video_orientation_full_screen);
        mIvOrientationFullScreen.setOnClickListener(this);
        mIvOrientationResize = (ImageView) findViewById(R.id.iv_video_orientation_resize);
        mIvOrientationResize.setOnClickListener(this);
        mSeekBar = (SeekBar) findViewById(R.id.seekBar);
        mSeekBar.setOnSeekBarChangeListener(mSeekBarChangeListener);

        mControlZone = (FrameLayout) findViewById(R.id.img_control_zone);

        mPhotoViewerTitle = (RelativeLayout) findViewById(R.id.photoviewer_title);


        mPlayer.setPositionUpdatedListener(mPositionUpdatedListener);
        mPlayer.setDurationChangedListener(mDurationChangedListener);
        mPlayer.setStateChangedListener(mStateChangedListener);
        mPlayer.setEndOfStreamListener(mEndOfStreamListener);
        mPlayer.setErrorListener(this);
        mPlayer.setVideoDownloadCompleteListener(this);

        mLoading = (ImageView) findViewById(R.id.iv_video_loading);
        mLoadingArea = (RelativeLayout) findViewById(R.id.video_loading_area);

        mPreviewLoading = (ImageView) findViewById(R.id.iv_video_preview_loading);
        mPreviewLoadingArea = (RelativeLayout) findViewById(R.id.video_preview_loading_area);

        mRetryArea = (LinearLayout) findViewById(R.id.video_retry_area);
        mRetry = (ImageView) findViewById(R.id.iv_video_retry);
        mRetry.setOnClickListener(this);


        mVideoContainer = (RelativeLayout) findViewById(R.id.video_container);
        mOperateContainer = (RelativeLayout) findViewById(R.id.operate_container);
        mPreviewContainer = (RelativeLayout) findViewById(R.id.preview_container);

        setPicMode();
    }

    private void initNetOperation() {
        GlobalManager.getInstance().getAlbumManager().registerActionListener(this);
    }

    //判断网络状态 什么时候显示 断网重试界面
    private void checkNetStatus() {

    }

    private void setVideoUri(Uri uri) {
        if (uri != null) {
            mPlayer.setUri(uri.toString());
        }
    }

    //不要调用stop接口 直接调用pause
    private void stopVideo() {
//        if (mPlayer != null){
//            mPlayer.stop();
//        }
    }

    private void pauseVideo() {
        if (mPlayer != null) {
            mPlayer.pause();
        }
    }

    private void playVideo() {
        if (mPlayer != null) {
            mPlayer.play();
        }
    }

    private void releasePlayer() {
        if (mPlayer != null) {

            mPlayer.setPositionUpdatedListener(null);
            mPlayer.setDurationChangedListener(null);
            mPlayer.setStateChangedListener(null);
            mPlayer.setEndOfStreamListener(null);
            mPlayer.setVideoDownloadCompleteListener(null);

//            stopVideo();
            mPlayer.close();
            mPlayer = null;
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        switch (newConfig.orientation) {
            case Configuration.ORIENTATION_LANDSCAPE:
                setLandscapeMode();
                break;
            case Configuration.ORIENTATION_PORTRAIT:
                setPortraitMode();
                break;
            default:
                break;
        }
    }

    private final static int ORI_NONE = 0;
    private final static int ORI_PORT = 1;
    private final static int ORI_LAND = 2;
    //ori到什么时候更改
    private int mOriWhenChange = ORI_NONE;

    private OrientationEventListener mOrientationEventListener = null;

    private void initOrientationEvent() {
        mOrientationEventListener = new OrientationEventListener(this) {

            @Override
            public void onOrientationChanged(int orientation) {
//                System.out.println("wsy onOrientationChanged orientation = " + orientation);

                int nOrient = ORI_NONE;

                if (orientation == -1) {//手机平放
                    nOrient = ORI_NONE;
                } else if (orientation < 10 || orientation > 350) {//手机顶部向上 竖直
                    nOrient = ORI_PORT;
                } else if (orientation < 100 && orientation > 80) {//手机右边向上 水平
                    nOrient = ORI_LAND;
                } else if (orientation < 190 && orientation > 170) {//手机边边向上 竖直
                    nOrient = ORI_PORT;
                } else if (orientation < 280 && orientation > 260) {//手机左边向上 水平
                    nOrient = ORI_LAND;
                }

                //0 不自动转
                //1 自动转屏
                int flag = Settings.System.getInt(getContentResolver(), Settings.System.ACCELEROMETER_ROTATION, 0);

                //添加是否开启自动转屏
                if (nOrient == ORI_LAND && mOriWhenChange == ORI_LAND && flag == 1) {
                    if (getRequestedOrientation() == ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE) {
                        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
                    }
                } else if (nOrient == ORI_PORT && flag == 1) {//&& mOriWhenChange == ORI_PORT
                    if (getRequestedOrientation() == ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT) {
                        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
                    }
                }
            }
        };

        mOrientationEventListener.enable();
    }

    private SeekBar.OnSeekBarChangeListener mSeekBarChangeListener = new SeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            if (fromUser) {
                if (mPlayer != null) {

                    mPlayer.seek((long) progress * TIME_CONVERT);
                    seekBar.setProgress(progress);
                }
            }
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {

        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {

        }
    };


    private Player.PositionUpdatedListener mPositionUpdatedListener = new Player.PositionUpdatedListener() {

        @Override
        public void positionUpdated(Player player, final long position) {
            int nCalcPosition = (int) (position / TIME_CONVERT);
            qds4sb.put("playTime", nCalcPosition);
            qds4sb.put("playPer", (float) nCalcPosition / (float) mCurDuration);
            storyMachineStick.put("playTime", String.valueOf(nCalcPosition));
            storyMachineStick.put("playPercent",String.valueOf(nCalcPosition / mCurDuration));

            if (nCalcPosition != mCurPosition) {
                mCurPosition = nCalcPosition;

                if (mCurPosition == mCurDuration) {
                    return;
                }

                runOnUiThread(new Runnable() {
                    public void run() {
                        mSeekBar.setProgress((int) (position / TIME_CONVERT));
                        updateTimeWidget();
                    }
                });
            }

        }
    };

    private Player.DurationChangedListener mDurationChangedListener = new Player.DurationChangedListener() {

        @Override
        public void durationChanged(Player player, final long duration) {
            mCurDuration = (int) (duration / TIME_CONVERT);
            qds4sb.put("totalTime", mCurDuration);
            runOnUiThread(new Runnable() {
                public void run() {
                    mSeekBar.setMax((int) (duration / TIME_CONVERT));

                    CLog.d(TAG, String.format("duration:%d", (int) (duration / TIME_CONVERT)));
                    updateTimeWidget();
                }
            });
        }
    };

    private Player.StateChangedListener mStateChangedListener = new Player.StateChangedListener() {

        @Override
        public void stateChanged(Player player, final Player.State state) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    updatePlayerState(state);
                }
            });
        }
    };

    private Player.EndOfStreamListener mEndOfStreamListener = new Player.EndOfStreamListener() {

        @Override
        public void endOfStream(Player player) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    CLog.d(TAG, "endOfStream");
                    mSeekBar.setProgress(mSeekBar.getMax());
                    mSeekBar.setProgress(0);
                    mSeekBar.invalidate();
                    updateTimeWidget();
                    //??
                    setPicMode();
                    qds4sb.put("familyPhoto", event.toJson());
                    qds4sb.put("sn", event.sn);
                    qds4sb.put("envType", event.envType);
                    qds4sb.put("playtime", event.playtime);
                    lagCount = lagCountTemp;
                    qds4sb.put("lag_count", lagCount);
                    storyMachineStick.put("lag_count", String.valueOf(lagCount));
                    if(!mIsFromStoryMachine){
                        QHStatAgentHelper.commitCommonEventHash("S_Video_bf010", qds4sb);
                    }else{
                        QHStatAgentHelper.doSmallVideoPlayStick(storyMachineStick);
                    }
                    CLog.i("test2", "S_Video_bf010 lagcount = "+ lagCount);
                    lagCountTemp = 0;
                }
            });

        }
    };


    private SurfaceHolder.Callback mCallback = new SurfaceHolder.Callback() {
        @Override
        public void surfaceCreated(SurfaceHolder holder) {
//            mPlayer.setSurface(holder.getSurface());
        }

        @Override
        public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            mPlayer.setSurface(holder.getSurface());
        }

        @Override
        public void surfaceDestroyed(SurfaceHolder holder) {
//            mPlayer.setSurface(holder.getSurface());
        }
    };

    private HackyViewPager.TouchCallback mViewPagerCallback = new HackyViewPager.TouchCallback() {
        @Override
        public void click() {
            if (mIsVideoMode) {
                if (mIsFullScreen) {
                    exitFullScreen();
                } else {
                    enterFullScreen();
                }
            }
        }
    };

    private View.OnTouchListener mSurfaceTouchListener = new View.OnTouchListener() {

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            return false;
        }
    };

    private void updateTimeWidget() {
        int pos = mSeekBar.getProgress();
        int max = mSeekBar.getMax();
        SimpleDateFormat df = new SimpleDateFormat("mm:ss");
        df.setTimeZone(TimeZone.getTimeZone("UTC"));
        mTvTotalTime.setText(df.format(new Date(max)));
        mTvPlayTime.setText(df.format(new Date(pos)));
    }

    public void showMobileNetPlayAlertDialog() {
        tipsDialog = new CamAlertDialog.Builder(this).setCancelable(false).setMessage(R.string.video_operate_not_wifi_dialog_title)
                .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                }).setPositiveButton(R.string.continue_down, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Constants.HAS_SHOW_NET_TIPS = true;
                        dialogInterface.dismiss();
                        openAndPlay();
                    }
                }).show();
    }

    public void checkNetAndPlay() {

        //本地有 就不用判断网络状况
        ImageInfoEntity event = adapter.getItem(mViewPager.getCurrentItem());
        File file = getVideoCached(event);
        if (file != null) {
            openAndPlay();
            return;
        }

        if (Utils.isNetworkAvailable(Utils.context)) {
//            if (Utils.isMoblieNetwork(Utils.context) && BuildConfig.DEBUG && Constants.HAS_SHOW_NET_TIPS && Constants.NEED_4G_TOAST) {
            if (Utils.isMoblieNetwork(Utils.context) && Constants.NEED_4G_TOAST) {
                CameraToast.show(Utils.context, R.string.video_tip_play_not_wifi, Toast.LENGTH_LONG);
            }
            if (Utils.isWifi(Utils.context) || Constants.HAS_SHOW_NET_TIPS) {
                openAndPlay();
            } else {
                showMobileNetPlayAlertDialog();
            }
        } else {
            CameraToast.show(Utils.context, R.string.video_tip_network_disabled, Toast.LENGTH_LONG);
        }
    }

    private File getVideoCached(ImageInfoEntity imageInfoEntity) {
        if (imageInfoEntity == null) {
            return null;
        }

        String downloadFilePath = mDownloadDir.getPath() + "/" + imageInfoEntity.getVideoName();
        File downloadFile = new File(downloadFilePath);

        if (!TextUtils.isEmpty(downloadFilePath) && downloadFile.exists()) {
            return downloadFile;
        }
        String cacheFilePath = VideoCache.getInstance().checkCache(mSn, imageInfoEntity);
        if (!TextUtils.isEmpty(cacheFilePath)) {
            File cacheFile = new File(cacheFilePath);
            if (cacheFile.exists()) {
                return cacheFile;
            }
        }
        return null;
    }


    private void openAndPlay() {
        if (!mIsPlayerAvailable) {
            CLog.i(TAG, "openAndPlay: mIsPlayerAvailable" + mIsPlayerAvailable);
            return;
        }

        final ImageInfoEntity event = adapter.getItem(mViewPager.getCurrentItem());

        if (event == null) {
            return;
        }

        setVideoMode();

        //已下载 播放本地 / 在cache中有
        Uri uri = null;
        File file = getVideoCached(event);
        if (file != null && file.exists()) {
            uri = Uri.fromFile(file);
            //播放本地视频
            mIsPlayLocalVideo = true;
            t4Sbstart = 0;
        } else {
            //此url就是流媒体文件的下载地址
            uri = Uri.parse(event.file.url + "&Authorization=" + event.file.token);
            //S_Video_qb001
            t4Sbstart = System.currentTimeMillis();
            //播放在线视频
            mIsPlayLocalVideo = false;
        }

        //播放时 隐藏播放按钮
        setVideoPlayBtn(false);

//        Uri uri = Uri.parse(mEventsList.get(position).file.url + "&Authorization=" + mEventsList.get(position).file.token);//此url就是流媒体文件的下载地址
//        Uri uriLocal = Uri.fromFile(new File("/sdcard/DCIM/Camera/test.mp4"));
        setVideoUri(uri);
        playVideo();

        //点击播放后 3s进入全屏
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mIsVideoMode) {
                    if (!mIsFullScreen) {
                        enterFullScreen();
                    }
                }
            }
        }, 3000);
    }

    private void setVideoMode() {
        mIsVideoMode = true;

        //进入video模式下尝试不锁定
//        mViewPager.setLocked(true);
//        mViewPager.setVisibility(View.GONE);
        mVideoOperation.setVisibility(View.VISIBLE);

        //横屏播放时 不显示下载栏
        if (mIsLandScreen) {
            mControlZone.setVisibility(View.GONE);
        } else {
            mControlZone.setVisibility(View.VISIBLE);
        }

        startLoading();

        setVideoPlayMode();

        //在video处于player状态时 才将surfaceview 显示
//        mVideoContainer.bringToFront();
//        mOperateContainer.bringToFront();
        mPreviewContainer.bringToFront();
        mOperateContainer.bringToFront();
    }

    private void setPicMode() {
        mIsVideoMode = false;

        //进入pic模式下尝试不锁定
        mViewPager.setLocked(false);
        mViewPager.setVisibility(View.VISIBLE);
        mSeekBar.setVisibility(View.GONE);
        mVideoOperation.setVisibility(View.GONE);

        setLoadingIcon(false);
        setPreviewLoadingIcon(false);

        mPhotoViewerTitle.setVisibility(View.VISIBLE);

        //横屏播放时 不显示下载栏
        if (mIsLandScreen) {
            mControlZone.setVisibility(View.GONE);
        } else {
            mControlZone.setVisibility(View.VISIBLE);
        }

        setVideoPauseMode();

        mIsNeedReplay = true;

        //恢复播放按钮
        setVideoPlayBtn(true);

        //恢复播放键显示
        setCurrentVideoPlay(null);

        mPreviewContainer.bringToFront();
        mOperateContainer.bringToFront();
    }

    private void setVideoPlayMode() {
        mIvPlay.setVisibility(View.GONE);
        mIvPause.setVisibility(View.VISIBLE);
    }

    private void setVideoPauseMode() {
        mIvPlay.setVisibility(View.VISIBLE);
        mIvPause.setVisibility(View.GONE);
    }

    //视频播放比例16:9
    private final static float VIDEO_SHOW_SCALE = 16f / 9f;

    //横屏
    private void setLandscapeMode() {
        mIsLandScreen = true;

//        if (mIsVideoMode){
//            mControlZone.setVisibility(View.GONE);
//        }else {
//            mControlZone.setVisibility(View.VISIBLE);
//        }
        mControlZone.setVisibility(View.GONE);

        mIvOrientationResize.setVisibility(View.VISIBLE);
        mIvOrientationFullScreen.setVisibility(View.GONE);
        mVideoOperationBackground.setBackgroundColor(0x55000000);

        mIvPlay.setPadding(dip2px(this, 10), 0, dip2px(this, 10), 0);
        mIvPause.setPadding(dip2px(this, 10), 0, dip2px(this, 10), 0);
        mIvOrientationFullScreen.setPadding(dip2px(this, 10), 0, dip2px(this, 10), 0);
        mIvOrientationResize.setPadding(dip2px(this, 10), 0, dip2px(this, 10), 0);

        WindowManager wm = this.getWindowManager();
        int width = wm.getDefaultDisplay().getWidth();
        int height = wm.getDefaultDisplay().getHeight();

        int nBig;
        int nSmall;
        if (width > height) {
            nBig = width;
            nSmall = height;
        } else {
            nBig = height;
            nSmall = width;
        }
        mSurfaceView.getLayoutParams().width = nBig;
        mSurfaceView.getLayoutParams().height = (int) (nBig / VIDEO_SHOW_SCALE);

        mLoadingArea.getLayoutParams().width = nBig;
        mLoadingArea.getLayoutParams().height = (int) (nBig / VIDEO_SHOW_SCALE);

        mPreviewLoadingArea.getLayoutParams().width = nBig;
        mPreviewLoadingArea.getLayoutParams().height = (int) (nBig / VIDEO_SHOW_SCALE);

        mRetryArea.getLayoutParams().width = nBig;
        mRetryArea.getLayoutParams().height = (int) (nBig / VIDEO_SHOW_SCALE);


        final int nVideoOperationHeight = 48;
//        mVideoOperation.getLayoutParams().height = dip2px(this, nVideoOperationHeight);
        RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) mVideoOperation.getLayoutParams();
        params.height = dip2px(this, nVideoOperationHeight);
        params.topMargin = mSurfaceView.getLayoutParams().height - dip2px(this, nVideoOperationHeight);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

//        setNaviBarFullScreen(true);

        //横屏隐藏下载tip
        hideTipsDialog();
    }

    //
    private void setPortraitMode() {
        mIsLandScreen = false;

        mControlZone.setVisibility(View.VISIBLE);
        mIvOrientationResize.setVisibility(View.GONE);
        mIvOrientationFullScreen.setVisibility(View.VISIBLE);
        mVideoOperationBackground.setBackgroundColor(Color.parseColor("#141414"));

        mIvPlay.setPadding(0, 0, 0, 0);
        mIvPause.setPadding(0, 0, 0, 0);
        mIvOrientationFullScreen.setPadding(0, 0, 0, 0);
        mIvOrientationResize.setPadding(0, 0, 0, 0);

        WindowManager wm = this.getWindowManager();
        int width = wm.getDefaultDisplay().getWidth();
        int height = wm.getDefaultDisplay().getHeight();

        int nBig;
        int nSmall;
        if (width > height) {
            nBig = width;
            nSmall = height;
        } else {
            nBig = height;
            nSmall = width;
        }
        mSurfaceView.getLayoutParams().width = nSmall;
        mSurfaceView.getLayoutParams().height = (int) (nSmall / VIDEO_SHOW_SCALE);

        mLoadingArea.getLayoutParams().width = nSmall;
        mLoadingArea.getLayoutParams().height = (int) (nSmall / VIDEO_SHOW_SCALE);

        mPreviewLoadingArea.getLayoutParams().width = nSmall;
        mPreviewLoadingArea.getLayoutParams().height = (int) (nSmall / VIDEO_SHOW_SCALE);

        mRetryArea.getLayoutParams().width = nSmall;
        mRetryArea.getLayoutParams().height = (int) (nSmall / VIDEO_SHOW_SCALE);


        int nVideoOperationHeight = 40;
        int nVideoOperationTopMargin = 8;
        RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) mVideoOperation.getLayoutParams();
        params.height = dip2px(this, nVideoOperationHeight);
        params.topMargin = mSurfaceView.getLayoutParams().height + dip2px(this, nVideoOperationTopMargin);

        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    private int dip2px(Context context, float dpValue) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (dpValue * scale + 0.5f);
    }

    private void enterLandScreen() {
        mIsLandScreen = true;
        mOriWhenChange = ORI_LAND;
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
    }

    private void exitLandScreen() {
        mIsLandScreen = false;
        mOriWhenChange = ORI_PORT;
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
    }

    private void enterFullScreen() {
        mIsFullScreen = true;
        mPhotoViewerTitle.setVisibility(View.GONE);
        mVideoOperation.setVisibility(View.GONE);
        mControlZone.setVisibility(View.GONE);
    }

    private void exitFullScreen() {
        mIsFullScreen = false;
        mPhotoViewerTitle.setVisibility(View.VISIBLE);
        mVideoOperation.setVisibility(View.VISIBLE);

        if (mIsLandScreen) {
            mControlZone.setVisibility(View.GONE);
        } else {
            mControlZone.setVisibility(View.VISIBLE);
        }
    }

    private ImageView mCurrentVideoPlay = null;

    //设置当前播放按钮
    private void setCurrentVideoPlay(ImageView imageView) {
        if (mCurrentVideoPlay != imageView) {
            if (mCurrentVideoPlay != null) {
                mCurrentVideoPlay.setVisibility(View.VISIBLE);
            }
            mCurrentVideoPlay = imageView;
        }
    }

    //设置当前播放按钮 显示状态
    private void setVideoPlayBtn(boolean isShow) {
        boolean bShow = false;

        if (mCurrentVideoPlay == null) {
            return;
        }

        if (bShow) {
            if (mCurrentVideoPlay.getVisibility() != View.VISIBLE) {
                mCurrentVideoPlay.setVisibility(View.VISIBLE);
            }
        } else {
            if (mCurrentVideoPlay.getVisibility() != View.GONE) {
                mCurrentVideoPlay.setVisibility(View.GONE);
            }
        }
    }

    /**
     * 进入加载状态
     */
    private void startLoading() {
        resetVideoWidget();
        mSeekBar.setVisibility(View.GONE);
//        setLoadingIcon(true);
        setPreviewLoadingIcon(true);
    }

    /**
     * 退出加载状态
     */
    private void endLoading() {
        mSeekBar.setVisibility(View.VISIBLE);
        setLoadingIcon(false);
        setPreviewLoadingIcon(false);
    }

    private void updatePlayerState(Player.State state) {
        if (mIsVideoMode) {
            if (state == Player.State.BUFFERING) {
                setLoadingIcon(true);
                if(startWatchLag){
                    lagCountTemp += 1;
                }
            } else {
                setLoadingIcon(false);
            }

            //处于播放状态下 将surfaceview 放到前面
            if (state == Player.State.PLAYING) {
                mVideoContainer.bringToFront();
                mOperateContainer.bringToFront();
                //开始记录lag事件
                startWatchLag = true;
//                QHStatAgentHelper.commitCommonEvent("S_Video_loading_count");
                setPreviewLoadingIcon(false);
            }

            if (mSeekBar.getVisibility() != View.VISIBLE) {
                mSeekBar.setVisibility(View.VISIBLE);
            }
        } else {
            setLoadingIcon(false);
            setPreviewLoadingIcon(false);
        }

    }

    private void setLoadingIcon(boolean bEnable) {
        if (bEnable) {
            mLoadingArea.setVisibility(View.VISIBLE);
            mLoading.setVisibility(View.VISIBLE);
            Animation anim = AnimationUtils.loadAnimation(this, R.anim.video_rotate_icon);
            mLoading.startAnimation(anim);
        } else {
            mLoadingArea.setVisibility(View.GONE);
            mLoading.setVisibility(View.GONE);
            mLoading.clearAnimation();
        }

    }

    //pic模式下 视频加载图 显示状态(未进入视频播放模式)
    private void setPreviewLoadingIcon(boolean bEnable) {
        try {
            if (bEnable) {
                mPreviewLoadingArea.setVisibility(View.VISIBLE);
                mPreviewLoading.setVisibility(View.VISIBLE);
                Animation anim = AnimationUtils.loadAnimation(this, R.anim.video_rotate_icon);
                mPreviewLoading.startAnimation(anim);
            } else {
                mPreviewLoadingArea.setVisibility(View.GONE);
                mPreviewLoading.setVisibility(View.GONE);
                mPreviewLoading.clearAnimation();
                if (!flag4qds && t4Sbstart != 0) {
                    netxt4Sb = System.currentTimeMillis() - t4Sbstart;
                    _4sbQds.put("loadingTime", netxt4Sb);
                    storyMachineStick.put("bufferTime", String.valueOf(netxt4Sb));
                    if(!mIsFromStoryMachine){
                        QHStatAgentHelper.commitCommonEventHash("S_Video_qb001", _4sbQds);
                    }
                    flag4qds = true;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void resetVideoWidget() {
        mTvPlayTime.setText("");
        mTvTotalTime.setText("");
        mSeekBar.setProgress(0);
        mSeekBar.invalidate();
    }

    private void showRetryArea() {
        if (!mInitComplete) {
            return;
        }
        if (mRetryArea.getVisibility() != View.VISIBLE) {
            mRetryArea.setVisibility(View.VISIBLE);
        }
    }

    private void hideRetryArea() {
        if (!mInitComplete) {
            return;
        }
        if (mRetryArea.getVisibility() != View.GONE) {
            mRetryArea.setVisibility(View.GONE);
        }
    }

    //播放视频时 无网络处理
    private void playWhenNoNetwork() {
        if (mIsVideoMode) {
            stopCurrentVideo();
            showRetryArea();
        }
    }

    //滑动到下一个
    //若当前正在播放 则暂停
    private void stopCurrentVideo() {
        if (mIsVideoMode) {
            pauseVideo();
            setPicMode();
//            QHStatAgent.onEvent(EventPagerActivity.this, "S_Video_bf010", qds4sb);

        }

        //恢复播放键显示
        setCurrentVideoPlay(null);
    }

    private String getTitleDateString(Date date) {
        long curTime = System.currentTimeMillis();
        long calcTime = date.getTime();

        String curDay = Utils.DATE_FORMAT_5.format(curTime);
        String calcDay = Utils.DATE_FORMAT_5.format(calcTime);

        String[] curSplit = curDay.split("-");
        String[] calcSplit = calcDay.split("-");

        if (curSplit.length != 3 || calcSplit.length != 3) {
            return "";
        }

        if (calcDay.equals(curDay)) {
            return "今天" + Utils.DATE_FORMAT_9.format(date);
        } else if (Utils.DATE_FORMAT_5.format(curTime - 24 * 60 * 60 * 1000).equals(calcDay)) {
            return "昨天" + Utils.DATE_FORMAT_9.format(date);
        }

        //年不同
        if (!curSplit[0].equalsIgnoreCase(calcSplit[0])) {
            return Utils.DATE_FORMAT_6.format(date);
        }

        return Utils.DATE_FORMAT_8.format(date) + Utils.DATE_FORMAT_9.format(date);
    }

    //设定当前所需要的空间大小 //暂时定为100m
    private final static int VIDEO_AVAIL_SPACE = 100;
    private View.OnClickListener mDownloadListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            QHStatAgentHelper.commitCommonEvent("S_Video_xg011");//小视频下载
            if (Utils.isNetworkAvailable(Utils.context)) {
//                if (Utils.isMoblieNetwork(Utils.context) && BuildConfig.DEBUG && Constants.HAS_SHOW_NET_TIPS && Constants.NEED_4G_TOAST) {
                if (Utils.isMoblieNetwork(Utils.context) && Constants.NEED_4G_TOAST) {
                    CameraToast.show(Utils.context, R.string.video_tip_download_not_wifi, Toast.LENGTH_LONG);
                }
                if (FileUtil.getInstance().calcAvailableSpare() > VIDEO_AVAIL_SPACE) {
                    if (Utils.isWifi(Utils.context) || Constants.HAS_SHOW_NET_TIPS) {
                        downloadVideo();
                    } else {
                        showMobileNetDownloadAlertDialog();
                    }
                } else {
                    CameraToast.showToast(Utils.context, getString(R.string.no_enough_storage_space));
                }
            } else {
                CameraToast.show(Utils.context, R.string.video_tip_network_disabled, Toast.LENGTH_LONG);
            }
        }
    };

    public void showMobileNetDownloadAlertDialog() {
        tipsDialog = new CamAlertDialog.Builder(this).setCancelable(false).setMessage(R.string.video_operate_not_wifi_dialog_title)
                .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                }).setPositiveButton(R.string.continue_down, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                        Constants.HAS_SHOW_NET_TIPS = true;
                        downloadVideo();
                    }
                }).show();
    }

    private int mTipDialogOffset = 180;




    private void downloadVideo() {
        Observable.create(new Observable.OnSubscribe<Boolean>() {
            @Override
            public void call(Subscriber<? super Boolean> subscriber) {
                boolean hasCache = false;
                ImageInfoEntity imageInfoEntity = adapter.getItem(mViewPager.getCurrentItem());
                if (imageInfoEntity != null) {
                    File cachePath = getVideoCached(imageInfoEntity);
                    String downloadPath = mDownloadDir.getPath() + "/" + imageInfoEntity.getVideoName();
                    File downloadFile = new File(downloadPath);
                    if (cachePath != null && cachePath.exists()) {
                        if (cachePath.exists()) {
                            if (downloadFile.exists()){
                                hasCache = true;
                            }else {
                                hasCache = FileUtil.copyFile(cachePath, downloadFile);
                            }
                        } else {
                            if (!downloadFile.getParentFile().exists()) {
                                downloadFile.getParentFile().mkdirs();
                            }
                        }
                    }
                }
                subscriber.onNext(hasCache);
                subscriber.onCompleted();
            }
        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).unsubscribeOn(Schedulers.io()).subscribe(new Action1<Boolean>() {
            @Override
            public void call(Boolean imageInfoEntity) {
                if (!imageInfoEntity) {
                    mViewPager.setLocked(true);
                    showDownloadTipsDialog(getString(R.string.video_download_msg_progress), mTipDialogOffset);
                    if (event != null) {
                        if (!TextUtils.isEmpty(event.getVideoPath())) {
                            request = new DownloadRequest.Builder()
                                    .setTitle(event.getVideoName())
                                    .setUri(event.file.url + "&Authorization=" + event.file.token)
                                    .setFolder(mDownloadDir)
                                    .build();
                            downloadManager = DownloadManager.getInstance();
                            downloadManager.download(request, "event", new DownloadCallback(event));
                        }
                    } else {
                        hideTipsDialog();
                        CameraToast.showToast(EventPagerActivity.this, "请稍后再试");
                        mViewPager.setLocked(false);
                    }
                } else {
                    if (mDownloadDir != null) {
                        String downloadPath = mDownloadDir.getAbsolutePath();
                        if (event.ftype == 0) {
                            CameraToast.showToast(EventPagerActivity.this, getResources().getString(R.string.video_download_msg_success_img, downloadPath), true);
                        } else if (event.ftype == 1) {
                            CameraToast.showToast(EventPagerActivity.this, getResources().getString(R.string.video_download_msg_success_video, downloadPath), true);
                        }
                    }
                }
            }
        });
    }

    @Override
    public void videoDownloadComplete(String downloadPath) {
        if (TextUtils.isEmpty(downloadPath)) {
            return;
        }
        CLog.d("small video path :" + downloadPath);
        if (adapter == null) {
            return;
        }
        if (mViewPager == null) {
            return;
        }

        ImageInfoEntity imageInfoEntity = adapter.getItem(mViewPager.getCurrentItem());
        if (imageInfoEntity == null) {
            return;
        }
        StoryAndVideoCacheWrapper.getInstance().saveVideoCache(mSn, downloadPath, imageInfoEntity);
    }

    @Override
    public void error(Player player, Player.Error error, String errorMessage) {

        CameraToast.show("播放失败", Toast.LENGTH_LONG);
        /*
        if (TextUtils.equals(errorMessage, "fail")) {
            CameraToast.show("播放失败", Toast.LENGTH_LONG);
            // TODO: 2016/7/7 这里添加播放失败的状态处理
        }
        */
    }

    class DownloadCallback implements CallBack {

        private int mProgress = 0;

        ImageInfoEntity targetEvent;

        public DownloadCallback(ImageInfoEntity event) {
            this.targetEvent = event;
        }

        @Override
        public void onStarted() {
            mProgress = 0;
            CLog.e("zhaojunbo", "onStarted");
        }

        @Override
        public void onConnecting() {
            CLog.e("zhaojunbo", "onConnecting");
        }

        @Override
        public void onConnected(long total, boolean isRangeSupport) {
            CLog.e("zhaojunbo", "onCompleted");
        }

        @Override
        public void onProgress(long finished, long total, int progress) {
            int nProgress = (int) ((float) finished / total * 100f);
            if (mProgress != nProgress) {
                mProgress = nProgress;

                if (mProgress > 99) {
                    updateDownloadProgress(99);
                } else {
                    updateDownloadProgress(mProgress);
                }
            }
        }

        @Override
        public void onCompleted() {
            finishDownload();
            sendToMediaStore();
            if (mDownloadDir != null) {
                String downloadPath = mDownloadDir.getAbsolutePath();
                if (targetEvent.ftype == 0) {
                    CameraToast.showToast(EventPagerActivity.this, getResources().getString(R.string.video_download_msg_success_img, downloadPath), true);
                } else if (targetEvent.ftype == 1) {
                    CameraToast.showToast(EventPagerActivity.this, getResources().getString(R.string.video_download_msg_success_video, downloadPath), true);
                }
            }
        }

        @Override
        public void onDownloadPaused() {
            CLog.e("zhaojunbo", "onDownloadPaused");
        }

        @Override
        public void onDownloadCanceled() {
            CLog.e("zhaojunbo", "onDownloadCanceled");
            finishDownload();
            CameraToast.showToast(EventPagerActivity.this, R.string.video_download_msg_cancel);
        }

        @Override
        public void onFailed(DownloadException e) {
            CLog.e("zhaojunbo", "onFailed");
            finishDownload();
            CameraToast.showToast(EventPagerActivity.this, R.string.video_download_msg_fail);
        }
    }

    private void updateDownloadProgress(final int nProgress) {
        EventPagerActivity.this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mToastTv != null) {
                    mToastTv.setText(getResources().getString(R.string.video_download_msg_progress_num, nProgress));
                }
            }
        });
    }

    private void finishDownload() {
        hideTipsDialog();
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mViewPager.setLocked(false);
            }
        });
    }

    private TextView mToastTv;

    private void showDownloadTipsDialog(final String msg, final int nOffset) {

        if (tipsDialog != null) {
            tipsDialog.dismiss();
        }
        tipsDialog =
                new CamAlertDialog(EventPagerActivity.this, R.style.NewDialog, true);
        Window w = tipsDialog.getWindow();
        WindowManager.LayoutParams lp = w.getAttributes();

        if (nOffset > 0) {
            lp.y = DensityUtil.dip2px(nOffset);
        } else {
            lp.y = -DensityUtil.dip2px(Math.abs(nOffset));
        }

        View content = getLayoutInflater().inflate(R.layout.tips_toast_video_dialog, null);
        mToastTv = (TextView) content.findViewById(R.id.stv_toast);
        mToastTv.setText(msg);
        tipsDialog.setContentView(content);
        tipsDialog.setCancelable(false);
        tipsDialog.setCanceledOnTouchOutside(false);
        tipsDialog.show();
    }


    public void hideTipsDialog() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (tipsDialog != null) {
                    tipsDialog.dismiss();
                }
            }
        });
    }

    private void sendToMediaStore() {
        ImageInfoEntity imageInfoEntity = adapter.getItem(mViewPager.getCurrentItem());
        if (imageInfoEntity != null) {
            String filePath = mDownloadDir + "/" + imageInfoEntity.getVideoName();
            if (!TextUtils.isEmpty(filePath)) {
                File file = new File(filePath);
                if (file.exists()) {
                    Uri contentUri = Uri.fromFile(file);
                    Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, contentUri);
                    EventPagerActivity.this.sendBroadcast(mediaScanIntent);
                }
            }
        }
    }

    public void doDown(String src, String name, final JiaProgressDialog jiaProgressDialog) {
        final File target = new File(name);
        File srcFile = new File(src);
        final boolean flag = FileUtil.copyFile(srcFile, target);
        FileUtil.getInstance().updateGallery(name);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mViewPager.setLocked(false);
                jiaProgressDialog.dismiss();
                mViewPager.setLocked(false);
                if (flag) {
                    CameraToast.showToast(EventPagerActivity.this, "图片下载成功，您可以在" + target.getAbsolutePath() + " 中查看", true);
                } else {
                    CameraToast.showToast(EventPagerActivity.this, "保存失败，请稍后再试。");
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        isMagicClickable = true;
        if (mIsNeedReplay && mIsVideoMode) {
            playVideo();
        }
    }

    @Override
    protected void onPause() {

        if (mIsVideoMode) {
            pauseVideo();
        }
        super.onPause();
    }

    @Override
    public void onDestroy() {
        setPicMode();
        releasePlayer();
        if (mOrientationEventListener != null) {
            mOrientationEventListener.disable();
        }
        GlobalManager.getInstance().getAlbumManager().removeActionListener(this);
        unregistBroadcast();

        super.onDestroy();
    }

    private void upDateTitle() {


        final int currentItem = mViewPager.getCurrentItem();
        if (currentItem < adapter.getCount()) {
            event = adapter.getItem(currentItem);
            if (event.ftype == 1) {
                qds4sb.put("familyPhoto", event.toJson());
            }
            totalText.setText(getString(R.string.total_event_image, currentItem + 1, adapter.getCount()));
            if (event != null) {
                //从notification来的数据 可能来着多设备, 需要刷新sn, 防止删除和分享时 使用到sn时 失败
                if (mIsFromNotification) {
                    if (!TextUtils.isEmpty(event.sn)) {
                        mSn = event.sn;
                    }
                }

                String dateStr = getTitleDateString(event.getDate());
                if (!TextUtils.isEmpty(dateStr)) {
                    tv_title.setText(dateStr);
                } else {
                    tv_title.setText(event.getDateString());
                }
            }

            if (mEventsList != null) {
                if (mEventsList.size() > currentItem) {
                    mSelectedCB.setChecked(mEventsList.get(currentItem).isChecked);
                }
            }
        }
    }

    public class SamplePagerAdapter extends PagerAdapter {
        private Context mContext;
        private ArrayList<ImageInfoEntity> list;
        private LayoutInflater mLayoutInflater;

        private int mScreenBigSize;
        private int mScreenSmallSize;

        public SamplePagerAdapter(Context mContext, ArrayList<ImageInfoEntity> list) {
            this.mContext = mContext;
            this.list = new ArrayList<ImageInfoEntity>();
            if (list != null) {
                this.list.addAll(list);
            }
            mLayoutInflater = LayoutInflater.from(mContext);

            init();
        }

        private void init() {
            WindowManager wm = EventPagerActivity.this.getWindowManager();
            int width = wm.getDefaultDisplay().getWidth();
            int height = wm.getDefaultDisplay().getHeight();

            if (width > height) {
                mScreenBigSize = width;
                mScreenSmallSize = height;
            } else {
                mScreenBigSize = height;
                mScreenSmallSize = width;
            }
        }

        @Override
        public int getCount() {
            return list.size();
        }

        public ImageInfoEntity getItem(int position) {
            if (list.size() > 0) {
                return list.get(position);
            } else {
                finish();
                return null;
            }
        }

        public int getItemPosition(Object object) {
            return POSITION_NONE;
        }

        public boolean getViewProgress(int i) {
            try {
                ImageInfoEntity event = list.get(i);
                return false;
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }

        @Override
        public Object instantiateItem(ViewGroup container, final int position) {
            final ImageInfoEntity event = list.get(position);
            View page = mLayoutInflater.inflate(R.layout.ac_image_pager, null);
            final PhotoView photoView = (PhotoView) page.findViewById(R.id.photo_view);
            //photoView.setmWatermark(R.drawable.img_water_mark);
//            photoView.setmFootnote(Utils.DATE_FORMAT_1.format(event.eventTime));
            final View progressBar = page.findViewById(R.id.loading_progressbar);

            photoView.enableDisplayScale(VIDEO_SHOW_SCALE, true, mScreenBigSize, mScreenSmallSize);

            final ImageView videoPlayIv = (ImageView) page.findViewById(R.id.iv_video_play);
            videoPlayIv.setVisibility(event.ftype == 1 ? View.VISIBLE : View.GONE);
            videoPlayIv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                    openAndPlay(event);
                    //正在播放时 重复点击 不响应
                    CLog.e("test2", "mIsVideoMode = " + mIsVideoMode);
                    if (!mIsVideoMode) {

                        if (event.ftype == 1) {
                            setCurrentVideoPlay(videoPlayIv);
                        } else {
                            setCurrentVideoPlay(null);
                        }

                        checkNetAndPlay();
                    }

                }
            });

            //此处不加载两张图 只加载preview
            final String thumbUrl = event.thumbnail.url + "&Authorization=" + event.thumbnail.token;
            final String thumbPath = ImageCache.getInstance().checkCache(event.fileName, ImageCache.THUMBNAIL);

            final String imagePreviewUrl = event.preview.url + "&Authorization=" + event.preview.token;
            final String previewPath = ImageCache.getInstance().checkCache(event.fileName, ImageCache.PREVIEW);

            if (TextUtils.isEmpty(previewPath)) {
                if (!TextUtils.isEmpty(thumbPath)) {
                    Glide.with(mContext)
                            .load(thumbPath)
                            .listener(new RequestListener<String, GlideDrawable>() {
                                @Override
                                public boolean onException(Exception e, String model, Target<GlideDrawable> target, boolean isFirstResource) {
                                    return false;
                                }

                                @Override
                                public boolean onResourceReady(GlideDrawable resource, String model, Target<GlideDrawable> target, boolean isFromMemoryCache, boolean isFirstResource) {
                                    ImageCache.getInstance().cacheImage(event, ImageCache.PREVIEW);
                                    if (!TextUtils.isEmpty(previewPath)) {
                                        Glide.with(mContext)
                                                .load(new File(previewPath))
                                                .diskCacheStrategy(DiskCacheStrategy.ALL)
                                                .error(R.drawable.camera_default_icon_bg)
                                                .into(photoView);
                                    } else {
                                        if (Utils.isNetworkAvailable(EventPagerActivity.this)) {
                                            if (progressBar.getVisibility() != View.VISIBLE) {
                                                if (event.ftype != 1) {
                                                    progressBar.setVisibility(View.VISIBLE);
                                                }
                                            }

                                            Glide.with(mContext)
                                                    .load(imagePreviewUrl)
                                                    .listener(new RequestListener<String, GlideDrawable>() {
                                                        @Override
                                                        public boolean onException(Exception e, String model, Target<GlideDrawable> target, boolean isFirstResource) {
                                                            progressBar.setVisibility(View.GONE);
                                                            return false;
                                                        }

                                                        @Override
                                                        public boolean onResourceReady(GlideDrawable resource, String model, Target<GlideDrawable> target, boolean isFromMemoryCache, boolean isFirstResource) {
                                                            ImageCache.getInstance().cacheImage(event, ImageCache.PREVIEW);

                                                            progressBar.setVisibility(View.GONE);

                                                            return false;
                                                        }
                                                    })
                                                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                                                    .error(R.drawable.camera_default_icon_bg)
                                                    .into(photoView);
                                        }
                                    }
                                    return false;
                                }
                            })
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .error(R.drawable.camera_default_icon_bg)
                            .into(photoView);
                } else {
                    if (event.ftype != 1) {
                        progressBar.setVisibility(View.VISIBLE);
                    }
                    Glide.with(mContext)
                            .load(thumbUrl)
                            .listener(new RequestListener<String, GlideDrawable>() {
                                @Override
                                public boolean onException(Exception e, String model, Target<GlideDrawable> target, boolean isFirstResource) {
                                    progressBar.setVisibility(View.GONE);
                                    return false;
                                }

                                @Override
                                public boolean onResourceReady(GlideDrawable resource, String model, Target<GlideDrawable> target, boolean isFromMemoryCache, boolean isFirstResource) {
                                    ImageCache.getInstance().cacheImage(event, ImageCache.PREVIEW);
                                    if (!TextUtils.isEmpty(previewPath)) {
                                        Glide.with(mContext)
                                                .load(new File(previewPath))
                                                .diskCacheStrategy(DiskCacheStrategy.ALL)
                                                .error(R.drawable.camera_default_icon_bg)
                                                .into(photoView);
                                    } else {
                                        if (progressBar.getVisibility() != View.VISIBLE) {
                                            if (event.ftype != 1) {
                                                progressBar.setVisibility(View.VISIBLE);
                                            }
                                        }
                                        Glide.with(mContext)
                                                .load(imagePreviewUrl)
                                                .listener(new RequestListener<String, GlideDrawable>() {
                                                    @Override
                                                    public boolean onException(Exception e, String model, Target<GlideDrawable> target, boolean isFirstResource) {
                                                        progressBar.setVisibility(View.GONE);
                                                        return false;
                                                    }

                                                    @Override
                                                    public boolean onResourceReady(GlideDrawable resource, String model, Target<GlideDrawable> target, boolean isFromMemoryCache, boolean isFirstResource) {
                                                        ImageCache.getInstance().cacheImage(event, ImageCache.PREVIEW);

                                                        progressBar.setVisibility(View.GONE);

                                                        return false;
                                                    }
                                                })
//                        .placeholder(R.drawable.camera_default_icon_bg)
                                                .diskCacheStrategy(DiskCacheStrategy.ALL)
                                                .error(R.drawable.camera_default_icon_bg)
                                                .into(photoView);
                                    }

                                    return false;
                                }
                            })
                            .placeholder(R.drawable.camera_default_icon_bg)
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .error(R.drawable.camera_default_icon_bg)
                            .into(photoView);
                }
            } else {
                Glide.with(mContext)
                        .load(new File(previewPath))
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .error(R.drawable.camera_default_icon_bg)
                        .into(photoView);
            }

            photoView.setOnPhotoTapListener(new PhotoViewAttacher.OnPhotoTapListener() {
                @Override
                public void onPhotoTap(View view, float x, float y) {
                    // TODO 这里需要继续修改。
                }
            });
            photoView.setTag("php");
            container.addView(page);
            return page;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            CLog.d("destroyItem");
            container.removeView((View) object);
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            CLog.d("isViewFromObject");
            return view == object;
        }

        public void remove(ImageInfoEntity event) {
            list.remove(event);
            notifyDataSetChanged();
        }
    }

    @Override
    public void onBackPressed() {
        //横屏状态下要先回到竖屏
        if (mIsLandScreen) {
            exitLandScreen();
        } else {
            //竖屏状态下退出
            if (mIsFromNotification) {
                //update title 中更新sn
                //退出时使用当前的sn
                if (!TextUtils.isEmpty(mSn)) {
                    Preferences.saveSelectedPad(mSn);
                }
                lagCount = lagCountTemp;
                storyMachineStick.put("lag_count", String.valueOf(lagCount));
                if(mIsFromStoryMachine){
                    QHStatAgentHelper.doSmallVideoPlayStick(storyMachineStick);
                }
                Intent intent = new Intent(this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra(MainActivity.SWITCH_TAB_INDEX, MainActivity.HOME_PHOTO_INDEX);
                EventPagerActivity.this.startActivity(intent);
            }
            finish();
            startWatchLag = false;
        }
    }

    private void toggleViewPagerScrolling() {
        if (isViewPagerActive()) {
            ((HackyViewPager) mViewPager).toggleLock();
        }
    }

    private boolean isViewPagerActive() {
        return (mViewPager != null && mViewPager instanceof HackyViewPager);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (isViewPagerActive()) {
            outState.putBoolean(ISLOCKED_ARG, ((HackyViewPager) mViewPager).isLocked());
        }
        super.onSaveInstanceState(outState);
    }

    public void share() {
        if (!isMagicClickable) {
            return;
        }

        if (!Utils.isNetworkAvailable(this)) {
            CameraToast.show(getString(R.string.network_disabled), Toast.LENGTH_SHORT);
            return;
        }

        final ImageInfoEntity event = adapter.getItem(mViewPager.getCurrentItem());
        if (event != null) {

            stopCurrentVideo();
            hideRetryArea();
              //TODO 产品要求去掉
//            showTipsDialog(getString(R.string.getting_share_url), R.drawable.icon_loading, 10000, true);
            imagePath = null;

            Observable.create(new Observable.OnSubscribe<ShareStoryEntity>() {
                @Override
                public void call(Subscriber<? super ShareStoryEntity> subscriber) {
                    String iPath = null;
                    if (event.ftype == 0) {
                        iPath = ImageCache.getInstance().checkCache(event.fileName, ImageCache.ORIGINAL);
                        if (TextUtils.isEmpty(iPath)) {
                            iPath = event.file.url + "&Authorization=" + event.file.token;
                        }
                    } else {
                        iPath = ImageCache.getInstance().checkCache(event.fileName, ImageCache.PREVIEW);
                        if (TextUtils.isEmpty(iPath)) {
                            iPath = event.preview.url + "&Authorization=" + event.preview.token;
                        }
                    }

                    try {
                        File file = Glide.with(Utils.context)
                                .load(iPath)
                                .downloadOnly(Target.SIZE_ORIGINAL, Target.SIZE_ORIGINAL).get();
                        if (file != null) {
                            imagePath = file.getAbsolutePath();//makeWaterMark(file.getAbsolutePath());
                        }
                    } catch (InterruptedException e) {
                        ;
                    } catch (ExecutionException e) {
                        ;
                    }

                    if (imagePath != null) {
                        if (event.ftype == 0) {
                            subscriber.onNext(null);
                        } else {
                            //分享视频
                            Map<String, String> param = new HashMap<String, String>();
                            param.put("sn", mSn);
                            param.put("id", String.valueOf(event.imageId));
                            param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                            String responseStr = OkHttpUtils.post().params(param).headers(null).url(DefaultClientConfig.APP_VIDEO_CREATE_SHARE).build().execute();
                            Gson gson = new Gson();
                            ShareStoryEntity shareStoryEntity = gson.fromJson(responseStr, ShareStoryEntity.class);
                            if (shareStoryEntity != null && shareStoryEntity.errorCode == 0) {
                                subscriber.onNext(shareStoryEntity);
                            } else {
                                subscriber.onError(new Throwable(responseStr));
                            }
                        }
                    } else {
                        subscriber.onError(new Throwable());
                    }
                    subscriber.onCompleted();
                }
            }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Subscriber<ShareStoryEntity>() {
                @Override
                public void onCompleted() {
                    hideTipsDialog();
                    isMagicClickable = true;
                }

                @Override
                public void onError(Throwable e) {
                    hideTipsDialog();
                    isMagicClickable = true;

                    CameraToast.show(Utils.getContext(), R.string.get_share_url_fail, Toast.LENGTH_LONG);
                }

                @Override
                public void onNext(ShareStoryEntity shareStoryEntity) {
                    hideTipsDialog();
                    isMagicClickable = true;

                    AlbumShareEntity entity = new AlbumShareEntity();
                    if (event.ftype == 0) {
                        entity.type = AlbumShareEntity.TYPE_IMAGE;
                    } else {
                        if (event.envType > 0)
                            entity.type = event.envType;
                        else
                            entity.type = AlbumShareEntity.TYPE_VIDEO_CATCH;
                    }
                    entity.image = imagePath;
                    if (event.ftype == 0) {
                        entity.url = null;
                    } else {
                        String url = shareStoryEntity.getShareUrl(String.valueOf(event.imageId), "album", mSn);
                        entity.url = url;
                    }
                    PhotoShareToAppActivity.startActivityFromEntity(entity, EventPagerActivity.this);
                }
            });
        }

        isMagicClickable = false;
    }

    private String makeWaterMark(String srcImagePath) {
        String destImagePath = srcImagePath;
        //增加水印实现
        Bitmap srcBitmap = BitmapFactory.decodeFile(srcImagePath);
        if (srcBitmap != null) {
            Bitmap maskBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.icon_add_robot);
            if (maskBitmap != null) {
                Bitmap newBitmap = ImageUtil.watermarkBitmap(srcBitmap, maskBitmap, null);
                if (newBitmap != null) {
                    File f = new File(srcImagePath);
                    if (f != null) {
                        try {
                            FileOutputStream out = new FileOutputStream(f);
                            newBitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                            out.flush();
                            out.close();
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    newBitmap.recycle();
                }
                maskBitmap.recycle();
            }
            srcBitmap.recycle();
        }

        return destImagePath;
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.iv_delete:
                showDeleteDialog();
                break;
            case R.id.btn_share_image_magic:
                ImageInfoEntity iie = adapter.getItem(mViewPager.getCurrentItem());
                PhotoShareToAppActivity.startActivityFromImageEntity(iie, EventPagerActivity.this);
//                share();
                break;
            case R.id.iv_video_operate_play:
                playVideo();
                setVideoPlayMode();
                mIsNeedReplay = true;
                break;
            case R.id.iv_video_operate_pause:
                pauseVideo();
                setVideoPauseMode();
                mIsNeedReplay = false;
                break;
            case R.id.iv_video_operate:
                if (mIvPlay.getVisibility() == View.VISIBLE) {
                    mIvPlay.performClick();
                } else if (mIvPause.getVisibility() == View.VISIBLE) {
                    mIvPause.performClick();
                }
                break;
            case R.id.iv_video_orientation_full_screen:
                enterLandScreen();
                break;

            case R.id.iv_video_orientation_resize:
                exitLandScreen();
                break;

            case R.id.surfaceView:
                if (mIsVideoMode) {
                    if (mIsFullScreen) {
                        exitFullScreen();
                    } else {
                        enterFullScreen();
                    }
                }

                break;
            case R.id.iv_video_retry:
                ImageInfoEntity imageInfoEntity = adapter.getItem(mViewPager.getCurrentItem());
                if (imageInfoEntity != null) {
                    if (Utils.isNetworkAvailable(Utils.context)) {
                        hideRetryArea();

                        //pic 0; video 1
                        if (imageInfoEntity.ftype == 1) {
                            openAndPlay();
                        }
                    }
                }
                break;
            default:
                break;
        }
    }

    private void showDeleteDialog() {
        CamAlertDialog.Builder builder = new CamAlertDialog.Builder(this);

        int nResId = R.string.del_video_msg;

        builder.setMessage(Utils.getContext().getString(nResId));
        builder.setPositiveButton(Utils.getContext().getString(R.string.del_video_msg_yes),
                new CamAlertDialog.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        deleteFile();
                    }
                });
        builder.setNegativeButton(Utils.getString(R.string.del_video_msg_no), null);
        builder.show();
    }

    private void showEndCallingDialog() {
        if (Constants.IS_CALLING_OR_INNER) {
            CamAlertDialog.Builder builder = new CamAlertDialog.Builder(this);
            builder.setMessage(this.getString(R.string.need_cancle_phone));
            builder.setPositiveButton(R.string.accept,
                    new CamAlertDialog.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //结束通话
                            Intent endCallingIntent = new Intent();
                            endCallingIntent.setAction(Const.BROADCAST_NOTIFY_END_CALLING);
                            sendBroadcast(endCallingIntent);
                        }
                    });
            builder.setNegativeButton(R.string.refuse,
                    new CamAlertDialog.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
            builder.show();
        }
    }

    private void deleteFile() {
        ImageInfoEntity imageInfoEntity = adapter.getItem(mViewPager.getCurrentItem());

        ArrayList<ImageInfoEntity> deleteList = new ArrayList<>();
        deleteList.add(imageInfoEntity);
        GlobalManager.getInstance().getAlbumManager().asyncDeleteAlbumOneFile(mSn, deleteList, PadInfoWrapper.getInstance().getPadBySn(mSn).isStoryMachine() ? DefaultClientConfig.STORY_DEVICE : DefaultClientConfig.KIBOT_DEVICE);
        QHStatAgentHelper.commitCommonEvent("S_Video_xg013");//删除次数

    }

    private void deleteFileCallback(ImageInfoEntity imageInfoEntity) {
        stopCurrentVideo();

        //没有内容 返回到小视频列表
        //当只有1项时,删掉应该返回到小视频列表
        if (adapter.getCount() == 1) {
            finish();
        }

        adapter.remove(imageInfoEntity);

        iDeleteCallback.onDelete(imageInfoEntity);

        setPicMode();

        upDateTitle();
    }

    @Override
    public Object actionPerformed(int actionCode, Object... args) {
        switch (actionCode) {
            case Actions.Album.DELETE_ALBUM_ONE_FILE_SUCCESS:

                ArrayList<ImageInfoEntity> deleteList = (ArrayList<ImageInfoEntity>) args[1];

                if (deleteList != null) {
                    for (int i = 0; i < deleteList.size(); i++) {
                        deleteFileCallback(deleteList.get(i));
                    }
                }

                CameraToast.show(Utils.getContext(), R.string.del_success, Toast.LENGTH_LONG);
                return Boolean.TRUE;
            case Actions.Album.DELETE_ALBUM_ONE_FILE_FAIL:
                CameraToast.show(Utils.getContext(), R.string.del_fail, Toast.LENGTH_LONG);
                return Boolean.TRUE;
            default:
                break;
        }
        return Actions.ACTION_NOT_PROCESSED;
    }

    @Override
    public int getProperty() {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public void finish() {
        int selectCount = 0;
        if (mEventsList != null) {
            for (int i = 0; i < mEventsList.size(); i++) {
                ImageInfoEntity imageInfoEntity = mEventsList.get(i);
                selectCount += imageInfoEntity.isChecked ? 1 : 0;
            }
        }

        Intent intent = new Intent();
        intent.putExtra("select_count", selectCount);
        setResult(selectCount > 0 ? EVENT_PAGE_SELECT : EVENT_PAGE_UNSELECT, intent);
        if (downloadManager != null) {
            downloadManager.cancelAll();
        }
        super.finish();
    }


    private static IDeleteCallback iDeleteCallback;

    public interface IDeleteCallback {
        public void onDelete(ImageInfoEntity imageInfoEntity);
    }

    private void registBroadcast() {
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        mWebChangeBroadcastReceiver = new WebChangeBroadcastReceiver();
        this.registerReceiver(mWebChangeBroadcastReceiver, filter);
    }

    private void unregistBroadcast() {
        this.unregisterReceiver(mWebChangeBroadcastReceiver);
    }

    private class WebChangeBroadcastReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            //只有视频模式下 需要判断网络情况
            //在播放本地视频时 不需要判断网络状况
            if (mIsVideoMode && !mIsPlayLocalVideo) {
                if (Utils.isNetworkAvailable(Utils.context)) {

                } else {
                    playWhenNoNetwork();
                }
            }
        }
    }


}
