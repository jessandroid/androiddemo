package com.qihoo360.homecamera.machine.ui.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;

public class SpaceTouchDetectorFrameLayout extends FrameLayout{

    private View mChildView;

    protected boolean mEnableDetect;
    private boolean ieatit;

    public SpaceTouchDetectorFrameLayout(Context context) {
        super(context);
    }

    public SpaceTouchDetectorFrameLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        if (getChildCount() > 0) {
            mChildView = getChildAt(0);
            mChildView.setClickable(true);
        }
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
         ieatit = super.dispatchTouchEvent(ev);
        //LiveDebug.log("SpaceTouchDetectorFrameLayout ieatit:" + ieatit);
        if (!ieatit && mEnableDetect) {
            onSpaceTouch();
        }
        return ieatit;
    }

    public void onSpaceTouch() {

    }
}
