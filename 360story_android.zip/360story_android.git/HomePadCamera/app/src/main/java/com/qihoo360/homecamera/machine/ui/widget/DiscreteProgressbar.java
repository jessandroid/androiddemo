
package com.qihoo360.homecamera.machine.ui.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;

import com.qihoo360.homecamera.mobile.R;

public class DiscreteProgressbar extends View {

    private Bitmap bitmap;
    private Paint paint;
    private float degrees;

    public DiscreteProgressbar(Context context, AttributeSet attrs) {
        super(context, attrs);
        paint = new Paint();
        paint.setAntiAlias(true);
        bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.video_progress_round);
    }

    @Override
    protected void onDetachedFromWindow() {
        if (bitmap != null && !bitmap.isRecycled()) {
            bitmap.recycle();
        }
        super.onDetachedFromWindow();
    }

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);

        if (bitmap != null && !bitmap.isRecycled()) {
            canvas.save();
            int width = getWidth();
            int height = getHeight();
            canvas.rotate(degrees, width / 2, height / 2);
            Rect rect = new Rect();
            rect.left = 0;
            rect.top = 0;
            rect.right = width;
            rect.bottom = height;
            canvas.drawBitmap(bitmap, null, rect, paint);
            canvas.restore();
        }
        degrees += 5;
        postInvalidateDelayed(10);
    }
}
