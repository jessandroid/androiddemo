package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;

import com.qihoo360.homecamera.mobile.db.PadInfoWrapper;
import com.qihoo360.homecamera.mobile.utils.AccUtil;

import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/5/24
 * Time: 11:46
 * To change this template use File | Settings | File Templates.
 */
public class ShareStoryEntity extends Head {

    /**
     * token : ad11203082f44a42
     * ts : 1464061534
     */

    private DataEntity data;

    public DataEntity getData() {
        return data;
    }

    public void setData(DataEntity data) {
        this.data = data;
    }

    public String getShareUrl(final String id, final String act, final String mSn){
        //http://pad.jia.360.cn/stories/story.html?id=319&token=a744fe8e735b4ef6&ts=1463990486
        DeviceInfo deviceInfo = PadInfoWrapper.getInstance().getPadBySn(mSn);
        if(deviceInfo.isStoryMachine()){
            return String.format("http://kibot.360.cn/story/wap_story.html?act=%s&id=%s&token=%s&ts=%s&qid=%s",act,id,data.token,data.ts, AccUtil.getInstance().getQID());
        }else{
            return String.format("http://kibot.360.cn/wap_story.html?act=%s&id=%s&token=%s&ts=%s&qid=%s",act,id,data.token,data.ts, AccUtil.getInstance().getQID());
        }
    }

    public static class DataEntity implements android.os.Parcelable {
        private String token;
        private int ts;

        public String getToken() {
            return token;
        }

        public void setToken(String token) {
            this.token = token;
        }

        public int getTs() {
            return ts;
        }

        public void setTs(int ts) {
            this.ts = ts;
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(this.token);
            dest.writeInt(this.ts);
        }

        public DataEntity() {
        }

        protected DataEntity(Parcel in) {
            this.token = in.readString();
            this.ts = in.readInt();
        }

        public static final Creator<DataEntity> CREATOR = new Creator<DataEntity>() {
            @Override
            public DataEntity createFromParcel(Parcel source) {
                return new DataEntity(source);
            }

            @Override
            public DataEntity[] newArray(int size) {
                return new DataEntity[size];
            }
        };
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeParcelable(this.data, flags);
    }

    public ShareStoryEntity() {
    }

    protected ShareStoryEntity(Parcel in) {
        super(in);
        this.data = in.readParcelable(DataEntity.class.getClassLoader());
    }

    public static final Creator<ShareStoryEntity> CREATOR = new Creator<ShareStoryEntity>() {
        @Override
        public ShareStoryEntity createFromParcel(Parcel source) {
            return new ShareStoryEntity(source);
        }

        @Override
        public ShareStoryEntity[] newArray(int size) {
            return new ShareStoryEntity[size];
        }
    };
}
