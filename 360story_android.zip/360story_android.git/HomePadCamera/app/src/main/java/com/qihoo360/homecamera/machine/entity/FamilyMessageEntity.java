package com.qihoo360.homecamera.machine.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by zhangtao-iri on 2017/2/16.
 */
public class FamilyMessageEntity implements Parcelable{

    public String sn;       //sn号
    public String msgId;    //只有收到的消息才有
    public int msgType;     //消息类型(0--文字 1--语音 2--表情)
    public String relation; //发消息人的关系
    public String avatarUrl;//发送者的头像
    public int owner;       //是否是自己发的 0--自己 1--其他
    public String content;  //文本或者语音下载地址或者表情id
    public String packageId;//表情包id
    public String cachePath;//语音文件本地缓存地址
    public int msgState;    //消息状态  0--成功  1--失败  2--正在发送中
    public int msgSize;     //语音消息的大小（多少秒）
    public long sendTime;    //消息发送的时间,时间戳
    public int hadRead;     //语音消息是否已经读过，0--已读  1--未读
    public int isPlaying;   //语音和表情的动画是否正在播放(0--不在播放  1--正在播放)
    public String uniqueId; //消息唯一标识

    public String getSn() {
        return sn;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }

    public int getMsgType() {
        return msgType;
    }

    public void setMsgType(int msgType) {
        this.msgType = msgType;
    }

    public int getHadRead() {
        return hadRead;
    }

    public void setHadRead(int hadRead) {
        this.hadRead = hadRead;
    }

    public int getMsgSize() {
        return msgSize;
    }

    public void setMsgSize(int msgSize) {
        this.msgSize = msgSize;
    }

    public long getSendTime() {
        return sendTime;
    }

    public void setSendTime(long sendTime) {
        this.sendTime = sendTime;
    }

    public String getCachePath() {
        return cachePath;
    }

    public void setCachePath(String cachePath) {
        this.cachePath = cachePath;
    }

    public int getMsgState() {
        return msgState;
    }

    public void setMsgState(int msgState) {
        this.msgState = msgState;
    }

    public String getContent() {
        return content;
    }

    public String getPackageId() {
        return packageId;
    }

    public void setPackageId(String packageId) {
        this.packageId = packageId;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getOwner() {
        return owner;
    }

    public void setOwner(int owner) {
        this.owner = owner;
    }

    public String getAvatarUrl() {
        return avatarUrl;
    }

    public void setAvatarUrl(String avatarUrl) {
        this.avatarUrl = avatarUrl;
    }

    public String getRelation() {
        return relation;
    }

    public void setRelation(String relation) {
        this.relation = relation;
    }

    public String getMsgId() {
        return msgId;
    }

    public void setMsgId(String msgId) {
        this.msgId = msgId;
    }

    public String getUniqueId() {
        return uniqueId;
    }

    public void setUniqueId(String uniqueId) {
        this.uniqueId = uniqueId;
    }

    public int getIsPlaying() {
        return isPlaying;
    }

    public void setIsPlaying(int isPlaying) {
        this.isPlaying = isPlaying;
    }

    public FamilyMessageEntity() {
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.sn);
        dest.writeString(this.msgId);
        dest.writeInt(this.msgType);
        dest.writeString(this.relation);
        dest.writeString(this.avatarUrl);
        dest.writeInt(this.owner);
        dest.writeString(this.content);
        dest.writeString(this.packageId);
        dest.writeString(this.cachePath);
        dest.writeInt(this.msgState);
        dest.writeInt(this.msgSize);
        dest.writeLong(this.sendTime);
        dest.writeInt(this.hadRead);
        dest.writeInt(this.isPlaying);
        dest.writeString(this.uniqueId);
    }

    protected FamilyMessageEntity(Parcel in) {
        this.sn = in.readString();
        this.msgId = in.readString();
        this.msgType = in.readInt();
        this.relation = in.readString();
        this.avatarUrl = in.readString();
        this.owner = in.readInt();
        this.content = in.readString();
        this.packageId = in.readString();
        this.cachePath = in.readString();
        this.msgState = in.readInt();
        this.msgSize = in.readInt();
        this.sendTime = in.readLong();
        this.hadRead = in.readInt();
        this.isPlaying = in.readInt();
        this.uniqueId = in.readString();
    }

    public static final Creator<FamilyMessageEntity> CREATOR = new Creator<FamilyMessageEntity>() {
        @Override
        public FamilyMessageEntity createFromParcel(Parcel source) {
            return new FamilyMessageEntity(source);
        }

        @Override
        public FamilyMessageEntity[] newArray(int size) {
            return new FamilyMessageEntity[size];
        }
    };
}
