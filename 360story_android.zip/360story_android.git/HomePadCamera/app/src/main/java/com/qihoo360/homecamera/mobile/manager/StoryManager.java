package com.qihoo360.homecamera.mobile.manager;

import android.app.Application;
import android.text.TextUtils;

import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionPublisherWithThreadPoolBase;
import com.qihoo360.homecamera.mobile.core.manager.workpool.PoolThreadFactory;
import com.qihoo360.homecamera.mobile.core.net.Api;
import com.qihoo360.homecamera.mobile.entity.RecordStoryEntity;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.util.Date;
import java.util.concurrent.Executors;

/**
 * Created by zhaojunbo on 2016/3/28.
 * desc:
 */
public class StoryManager extends ActionPublisherWithThreadPoolBase {

    private final String mPoolNameHighPriority, mPoolNameLowPriority;
    private final Application mApp;

    public StoryManager(Application app) {
        this.mApp = app;
        mPoolNameHighPriority = "StoryManager-high-priority-" + Utils.DATE_FORMAT_3.format(new Date());
        mPoolNameLowPriority = "StoryManager-low-priority-" + Utils.DATE_FORMAT_3.format(new Date());
        mThreadPool.initPool(mPoolNameHighPriority, Executors.newFixedThreadPool(3));
        mThreadPool.initPool(mPoolNameLowPriority, Executors.newCachedThreadPool(new PoolThreadFactory(mPoolNameLowPriority)));
    }

    public void asyncVoiceIdiom(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new ActionPublisherWithThreadPoolBase.NamedAsyncJob("RecordStory", args));
    }


    @Override
    protected void asyncDoNamedJob(String jobName, Object... args) {
        if (TextUtils.equals(jobName, "RecordStory")) {
            doVoiceIdiom((Integer) args[0], (Integer) args[1]);
        }
    }

    public void doVoiceIdiom(Integer type, Integer page) {
        RecordStoryEntity result = Api.RecordStory.postRecordStory(type, page);
        if (result == null) {
            publishAction(Actions.Story.GET_STORY_FAIL);
        } else if (result.errorCode != 0) {
            publishAction(Actions.Story.GET_STORY_FAIL, result.errorMsg);
        } else {
            publishAction(Actions.Story.GET_STORY_SUCCESS, result);
        }
    }


}
