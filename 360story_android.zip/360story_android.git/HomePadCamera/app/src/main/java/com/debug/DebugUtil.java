
package com.debug;

import android.database.Cursor;

import com.qihoo360.homecamera.mobile.core.beans.Response;
import com.qihoo360.homecamera.mobile.core.util.ManagedRuntimeException;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.util.StringTokenizer;

public class DebugUtil {

    public final static Response generateException(int errorCode, String errorMessage) {
        Response r = new Response();
        r.errorNumber = errorCode;
        r.errorMessage = errorMessage;
        throw new ManagedRuntimeException(r);
    }

    public static String dumpCursor(Cursor cursor) {
        StringBuilder buf = new StringBuilder();
        for (String s : cursor.getColumnNames()) {
            buf.append(s).append(',');
        }
        if (buf.length() > 0) {
            buf.deleteCharAt(buf.length() - 1);
        }
        buf.append('\n');
        int columnCount = cursor.getColumnCount();
        while (cursor.moveToNext()) {
            for (int i = 0; i < columnCount; i++) {
                buf.append(cursor.getString(i)).append(',');
            }
            if (buf.length() > 0) {
                buf.deleteCharAt(buf.length() - 1);
            }
            buf.append('\n');
        }
        cursor.close();
        return buf.toString();
    }

    public static void dumpLongString(String tag, String s) {
        StringTokenizer token = new StringTokenizer(s, "\n");
        while (token.hasMoreElements()) {
            CLog.d(tag, token.nextToken());
        }
    }

    public final static class TEST_USER {
        //public final static String username = "tjtest002@gmail.com", password = "aaabbb";
        //final static String username = "tjtest001@gmail.com", password = "tjtest001";
        //public final static String username = "tjtest005@gmail.com", password = "aaabbb";
        //public final static String username = "tjtest004@gmail.com", password = "aaabbb";
        //public final static String username = "yunpan@qihoo.net", password = "I1oveyunpan";
        //public final static String username = "tjtest005@gmail.com", password = "aaabbb";
    }

    @SuppressWarnings("unused")
    private final static String ErrorString = "{\"errno\":2006,\"errmsg\":\"user invalid, login failed or token invalid\",\"consume\":0,\"action\":\"login\",\"interval\":500,\"retry_metric\":\"command\"}";
    static int DOWNLOADER_COUNTER = 0;
    static int UPLOAD_COUNTER = 0;
    private final static Object[] ErrorDefs = new Object[] {
            Utils.asArray("Incr.getBgsp", new ErrorGenerator() {
                @Override
                public void generateErrorIfNecessary(String apiName, Response response) {
                    if ((DOWNLOADER_COUNTER++ + 1) % 3 == 0) {
                        CLog.d("test", "Generating 2008 error for " + response.requestUrl);
                        generateException(2008, "User logout");
                    }
                }
            }
                    ),
            Utils.asArray("Download.downloadBlock", new ErrorGenerator() {
                @Override
                public void generateErrorIfNecessary(String apiName, Response response) {
                    if (DOWNLOADER_COUNTER++ % 8 == 0) {
                        CLog.d("test", "Generating error for " + response.requestUrl);
                        generateException(2006, "Token invalid");
                    }
                }
            }
                    ),
            Utils.asArray("MUpload.block", new ErrorGenerator() {
                @Override
                public void generateErrorIfNecessary(String apiName, Response response) {
                    if (UPLOAD_COUNTER++ % 8 == 0) {
                        response.errorNumber = 2006;
                    }
                }
            }
                    )
    };
    private static int counter = 0;
    private final static ErrorGenerator DefaultErrorGenerator = new ErrorGenerator() {

        @Override
        public void generateErrorIfNecessary(String apiName, Response response) {
            if (counter++ % 10 == 0) {
            }
        }
    };

    public interface ErrorGenerator {
        void generateErrorIfNecessary(String apiName, Response response);
    }

    public static boolean isEnabled = false;

    public final static void modifyResponse(Response response) {
        if (isEnabled == false) {
            return;
        }
        DefaultErrorGenerator.generateErrorIfNecessary("", response);
        for (Object o : ErrorDefs) {
            Object[] array = (Object[]) o;
            final String apiName = (String) array[0];
            if (response.requestUrl.indexOf(apiName) > 0) {
                ((ErrorGenerator) array[1]).generateErrorIfNecessary(apiName, response);
            }
        }
    }
}
