
package com.qihoo360.homecamera.machine.activity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.SurfaceTexture;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.v4.graphics.ColorUtils;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.OrientationEventListener;
import android.view.TextureView;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.qihoo.jia.play.jnibase.LiveSession;
import com.qihoo360.homecamera.machine.business.TaskExecutor;
import com.qihoo360.homecamera.machine.config.MachineConsts;
import com.qihoo360.homecamera.machine.config.MainActivityLifecycleConfigVar;
import com.qihoo360.homecamera.machine.entity.Camera;
import com.qihoo360.homecamera.machine.entity.CameraSettings;
import com.qihoo360.homecamera.machine.entity.CameraSupport;
import com.qihoo360.homecamera.machine.entity.Config;
import com.qihoo360.homecamera.machine.entity.PublicCamera;
import com.qihoo360.homecamera.machine.manager.CloudConfigManager;
import com.qihoo360.homecamera.machine.myvideoplay.TitleHeadListAdapter;
import com.qihoo360.homecamera.machine.myvideoplay.TitleHeadListMenuWrapper;
import com.qihoo360.homecamera.machine.myvideoplay.VideoPromptBanner;
import com.qihoo360.homecamera.machine.net.CameraHttpApi;
import com.qihoo360.homecamera.machine.play.APlayManager;
import com.qihoo360.homecamera.machine.play.RealTimeManager;
import com.qihoo360.homecamera.machine.play.audio.VqeLookupTable;
import com.qihoo360.homecamera.machine.preferences.Preferences;
import com.qihoo360.homecamera.machine.sound.SoundGridView;
import com.qihoo360.homecamera.machine.sound.SoundPlayView;
import com.qihoo360.homecamera.machine.sound.SoundPlayView.SoundPlayListener;
import com.qihoo360.homecamera.machine.sound.entity.SoundPlayInfo.SoundInfo;
import com.qihoo360.homecamera.machine.sound.manager.SoundInfoManager;
import com.qihoo360.homecamera.machine.sound.manager.SoundTask;
import com.qihoo360.homecamera.machine.ui.widget.AbstractCustomStateButton;
import com.qihoo360.homecamera.machine.ui.widget.AngleView;
import com.qihoo360.homecamera.machine.ui.widget.CustomStatePortraitButton;
import com.qihoo360.homecamera.machine.ui.widget.DiscreteProgressbar;
import com.qihoo360.homecamera.machine.ui.widget.FilterMenuWrapper;
import com.qihoo360.homecamera.machine.ui.widget.MarqueeTextView;
import com.qihoo360.homecamera.machine.ui.widget.VolumeBar;
import com.qihoo360.homecamera.machine.ui.widget.gallary.TextureViewAttacher;
import com.qihoo360.homecamera.machine.ui.widget.gallary.ZommTextureView;
import com.qihoo360.homecamera.machine.videoplay.GLProducerThread;
import com.qihoo360.homecamera.machine.videoplay.GLRendererImpl;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.SysConfig;
import com.qihoo360.homecamera.mobile.config.Const;
import com.qihoo360.homecamera.mobile.config.Constants.VideoUIStatus;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.entity.DeviceInfo;
import com.qihoo360.homecamera.mobile.entity.Head;
import com.qihoo360.homecamera.mobile.entity.MediaFiles;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.DensityUtil;
import com.qihoo360.homecamera.mobile.utils.QHStatAgentHelper;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.utils.share.SocialShareType;
import com.qihoo360.homecamera.mobile.widget.CamAlertDialog;

import java.io.File;
import java.lang.ref.WeakReference;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TimeZone;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;

import jp.wasabeef.glide.transformations.BlurTransformation;
import jp.wasabeef.glide.transformations.ColorFilterTransformation;

import static com.qihoo360.homecamera.machine.play.APlayManager.PlayStatus.PlayerFailed;

public class VideoPlayActivity extends MachineBaseActivity
        implements ActionListener, CloudConfigManager.OnGlobalConfigChangedListener, GLRendererImpl.GLRenderWrapper {
    private float mWHRatio = 16.f / 9.f;

    private final static long READY_REPORT_TIME = 60 * 1000;

    private final static int SWITCH_EXPAND_UI_DURATION = 3 * 1000;
    /**
     * 通话类型标签
     */
    public final static String VIDEO_TYPE_CALL = "call";
    public final static String VIDEO_TYPE_MONITOR = "monitor";

    private long firstPlayTime = 0;
    private long MAX_READY_DURANTION = 0;
    private long readyTime = 0;
    private long halfTime = 0;
    private long oneSecondTime = 0;
    private long twoSecondTime = 0;
    private long fiveSecondTime = 0;
    private long tenSecondTime = 0;
    private long twentySecondTime = 0;
    private long thirtySecondTime = 0;
    private long overThirtySecondTime = 0;
    private long LAST_WAIT_TIME = 0;
    private long LAST_REPORT_TIME = 0;
    private long TOTAL_BUFFERED_DURATION = 0;
    private long TOTAL_BUFFERED_TIMES = 0;
    private long TOTAL_MAX_BUFFERED_DURATION = 0;
    private long FIRST_OPEN_STREAM_TIME = 0;
    private long FIRST_OPEN_STREAM_DURANTION = 0;
    private long TOTAL_PLAYED_DURATION = 0;
    private long FIRST_TALK_START_TIME = 0;
    private long TOTAL_TALK_DURATION = 0;

    private ArrayList<Long> totalOpenStreamArray = new ArrayList<Long>();

    /**
     * Model
     */
    private Camera mCamera;
    private LiveSession.JP2PInfo mJP2PInfo;
    private RealTimeManager mRealTimeManager;

    private PowerManager.WakeLock mWakeLock;
    //    private CameraSettingManager mCameraSettingManager;

    /**
     * View
     */
    // Video
    private View mFullScreenLayout;
    private View mBackLayout;
    private ImageView mNoStreamView;
//    private RelativeLayout mVideoViewLayout;
    private ImageView playBgView;
    private View mErrorLayout;
    private View mLoadingLayout;
    private ImageView mLoadingIv;
    private ImageView mLoadingShieldIv;
    private DiscreteProgressbar mLoadingNonShieldIv;
    private View mRetryLayout;
    private TextView mErrorInfoText;
    private TextView mCameraNameTV;

    //    private View mVideoErrorLayout;

    private View mRetryMultiView;

    // Record Time
    private View mRecordTimeLayout;
    private ImageView mRecordIcon;
    private TextView mRecordTimeText;
    private AnimationDrawable mTwinkleAnimDrawable;

    // Control
    private Button mMuteBtn;
    //    private ButtonLayoutNew mQualityBtn;
    private Button mSnapshotBtn;
    //    private ButtonLayoutNew mSDRecordBtn;
    private CustomStatePortraitButton mAudioTalkBtn;
    private Button mRecordBtn;
    //    private ButtonLayoutNew mSoundBtn;

    //    private PopupWindow mQualityPopup;
    //    private PopupWindow mPhoneGuidePopup;
    //    private View mHQBtn;
    //    private View mMQBtn;
    //    private View mLQBtn;

    // Snap Status
    private View mSnapshotSplash;
    private View mSnapshotThumbnailLayout;
    private ImageView mSnapshotThumbnailView;
    private Button mAddFilterButton;
    private boolean isFilterPending = false;

    // Talk
    private VolumeBar mVolumeBar;

    // Stream
    private View mStreamLayout;
    private TextView mStreamText;
    private TextView mStreamTextWithSafeShieldView;

    // 竖屏
    private TextView mVideoTimeText;
    //    private TextView mOldVideoTimeText;
    //    private RelativeLayout mOldVideoTimeTextRl;
    private View mAutoCheck, mOpenCheck, mCloseCheck;

    // 横屏
    private View mLandTitleView;
    private View mLandOptionView;

    // 状态控制
    private VideoUIStatus mCurrentUIStatus;
    private VideoUIStatusRunnable mStatusRunnable;

    // Orientation
    private int mOrientationClickMode;
    private int mCurrentOrientation = Configuration.ORIENTATION_UNDEFINED;
    private OrientationEventListener mOrientationListener;
    private final int oriLand = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE;

    // Other Param
    private boolean isBackFinish;
    private boolean isCheckPhoto;

    private boolean isOpenSuccess;
    private boolean isRetryMulti;

    private boolean isGotoVideoRecord;

    private int mCurrentNightMode = -1;
    private boolean pendingCheckShineDueToNotPlaying;

    private Future mSoundTaskFuture;

    private SimpleDateFormat format;

    /**
     * 音乐播放页面
     */
    private SoundGridView mSoundGridView;
    private SoundPlayView mSoundPlayView;// 点播播放页面
    //    private MultModeButtonNew mSoundBtnIcon;
    private MarqueeTextView playSoundName;
    private View playSoundNameZone;

    private boolean isShowGuide = false;
    private boolean isV = false;// 是否乐库页面状态
    private boolean isS = false;// 是否播放页面状态
    private String mSn = "";
    private DeviceInfo mDeviceInfo;

    /*
    private ImageView mSafeShieldView;
    */
    private FrameLayout mSafeShidldPopTv;
    private AnimationDrawable mSafeAnimation;
    //    private View mPopView;
    private Animation mOperaPanelDownAnim, mOperaPanelUpAnim;
    private boolean isFront;
    private View allView;
    private View nightSafeView;
    //    private View nightView;
    private boolean isRecording;

    //    private ImageView mMic2PhoneGuideIv;
    private int mTalkState = 0;
    private int mSoundPlayState = 0;
    private SoundInfo mSoundInfo;
    private boolean mIsInitPreference = false;
    //    private CameraSettings mAllSetting;
    private boolean mAlreadyShowPublicPhoneToast = false;
    private boolean mAlreadyClickVoiceToast = false;

    private boolean check_shine = true;

    private RelativeLayout mCameraSwitchCloseRl;
    private boolean mIsCameraSwitchOpen = false;
    private TextView mCameraSwitchTipsTv;

    private Runnable startTalkRunnable;

    private Handler mShowShieldHandler;
    private Runnable mShowShieldTimerRunnable;
    private Handler mMainHandler = new Handler();
    //    private Runnable mShowGuideRunnable;
    private int mIsDemo;

    private boolean mHasDelay = false;
    //    private ViewTreeObserver.OnGlobalLayoutListener onGlobalLayoutListener;

    // 多摄像机
    private TitleHeadListAdapter mTitleAdapter;
    private RecyclerView mCameraList;
    private GestureDetector mDetector;
    private TitleHeadListMenuWrapper mTitleHeadListMenuWrapper;
    private ImageButton mDownListButton;

    private boolean isPlayingByPaused;

    // 滑动参数
    private int mFlingRate = 4;
    private int mFlingRateX = 4;
    private int mFlingRateY = 3;

    private boolean showExpandUiPort;
    private boolean hasPlaying;

    private View mPlayMaskCoverOnSnapnail;

    private VideoPromptBanner mVideoPromptBanner;

    private boolean mPendingShowPlayNewWhenChangeCamera;
    private TextView mTalkTipTv;
    private View mResolutionBtn;
    //    private View mVolumLayout;
    private Drawable mBlurDrawable;
    private ZommTextureView mTextureView;
    private GLRendererImpl mRenderer;
    private GLProducerThread mProducerThread;
    private AngleView mSb;
    private View mSettingBtn;
    private View mPlaybackBtn;
    private View mSongBtn;
    private View mMenuBtn;
    private View mOption1;
    private View mOption2;
    private Animation mPanelLeftOutAnim;
    private Animation mPanelLeftInAnim;
    private Animation mPanelRightInAnim;
    private Animation mPanelRightOutAnim;
    private Animation mMenuRightAnim;
    private Animation mMenuLeftAnim;
    private boolean withCall = false;
    private String videoType;

    // region Override Method

    /**
     * 初始化界面对象、监听、参数等
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getIntent().getBundleExtra("bundle");
        mCamera = bundle.getParcelable("camera");
        withCall = bundle.getBoolean("call", false);
        if (withCall){
            videoType = VIDEO_TYPE_CALL;
        }else {
            videoType = VIDEO_TYPE_MONITOR;
        }
        mDeviceInfo = bundle.getParcelable(MachineConsts.DEVICEINFO);
        CLog.d(mCamera.toJson());
        if (mCamera == null) {
            CLog.d("Play Camera is null");
            finish();
            return;
        }
        //        buildJP2PInfo();
        //        setFastClickable(true);
        //        mSwipeBackLayout.setEnableGesture(false);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setWindowListener();

        initView();
        initListener();
        initAnimation();
        manageCamera();

        CloudConfigManager.getInstance().registerOnGlobalConfigChangedListener(this);
        Config config = CloudConfigManager.getInstance().getGlobalConfig();
        if (config != null) {
            check_shine = config.isCheckShineOn();
        }

        CLog.endTimerP("onCreate");
    }

    /*private void buildJP2PInfo() {
        mJP2PInfo = null;
        if (mCamera.p2pInfo != null
                && mCamera.getSupportObj() != null
                && mCamera.getSupportObj().isP2PSupported()) {
            mJP2PInfo = new LiveSession.JP2PInfo();
            mJP2PInfo.mPeerId = mCamera.p2pInfo.ukey;
            mJP2PInfo.mStreamKey = mCamera.p2pInfo.playKey;
            mJP2PInfo.mTrackerIp = mCamera.p2pInfo.ip;
            mJP2PInfo.mTrackerPort = mCamera.p2pInfo.port;
            mJP2PInfo.mSelfId = P2PManager.getSelfId(mCamera.sn);
            Config gConfig = CloudConfigManager.getInstance().getGlobalConfig();
            if (gConfig != null && gConfig.p2p != null) {
                mJP2PInfo.mP2pTimeout = gConfig.p2p.conn_ts;
            }
            CLog.e("mJP2PInfo.mPeerId:" + mJP2PInfo.mPeerId + ", mStreamKey:"
                    + mJP2PInfo.mStreamKey + ", mTrackerIp:" + mJP2PInfo.mTrackerIp
                    + ", mSelfId:" + mJP2PInfo.mSelfId + ", mP2pTimeout:" + mJP2PInfo.mP2pTimeout);
        } else {
            CLog.e("mCamera.p2pInfo is NULL");
        }
    }*/

    private void initAnimation() {
        mPanelLeftOutAnim = AnimationUtils.loadAnimation(this, R.anim.video_panel_left_out);
        mPanelLeftInAnim = AnimationUtils.loadAnimation(this, R.anim.video_panel_left_in);

        TranslateAnimation ta = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 1.0f, Animation.RELATIVE_TO_SELF, 0,
                Animation.RELATIVE_TO_SELF, 0, Animation.RELATIVE_TO_SELF, 0);
        ta.setDuration(200);
        AlphaAnimation aa = new AlphaAnimation(0, 1f);
        aa.setDuration(50);
        aa.setStartOffset(150);
        AnimationSet as = new AnimationSet(true);
        as.addAnimation(ta);
        as.addAnimation(aa);
        //        mPanelRightInAnim = AnimationUtils.loadAnimation(this, R.anim.video_panel_right_in);
        mPanelRightInAnim = as;

        mPanelRightOutAnim = AnimationUtils.loadAnimation(this, R.anim.video_panel_right_out);
        mMenuRightAnim = AnimationUtils.loadAnimation(this, R.anim.sat_main_rotate_right);
        mMenuLeftAnim = AnimationUtils.loadAnimation(this, R.anim.sat_main_rotate_left);

        mPanelLeftOutAnim.setAnimationListener(new AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                mOption2.setVisibility(View.VISIBLE);
                mMenuBtn.setBackgroundResource(R.drawable.video_menu_m2_btn);
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                mOption1.setVisibility(View.GONE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }
        });
        mPanelRightOutAnim.setAnimationListener(new AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                mOption1.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                mOption2.setVisibility(View.GONE);
                mMenuBtn.setBackgroundResource(R.drawable.video_menu_btn);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }
        });
    }

    private void setWindowListener() {
        Window window = getWindow();
        final View decorView = window.getDecorView();
        decorView.setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener() {
            @Override
            public void onSystemUiVisibilityChange(int visibility) {

            }
        });
    }

    // forceRefresh: when change camera from playNew
    // we need initiated mIsCameraSwitchOpen to true
    // to start load video again and get if SWITCH_OFF state
    private void manageCamera() {
        if (mCamera.getExtend() == null) {
            mIsCameraSwitchOpen = true;
        } else {
            mIsCameraSwitchOpen = mCamera.getExtend().getSoft_switch() == 1;
        }

        mCurrentNightMode = -1;
        isOpenSuccess = false;
        retryMultiCount = 0;
        isRetryMulti = false;

        initSn();
        initController();
        setView();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        isShowActivity = false;
        if (requestCode == 200) {
            updateSnapView();
        }
        if (!Preferences.getVideoMuted(mRealTimeManager.mCameraSN)) {
            mRealTimeManager.setIsMuted(true);
            onOption(mMuteBtn);
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    /**
     *
     */
    @Override
    public void onStart() {
        super.onStart();
        if (!isShowGuide) {
            mOrientationListener.enable();
        }

        updateOptionBtnMode();
        if (!isCheckPhoto && !isGotoVideoRecord) {
            if (isPlayingByPaused == false) {
                startVideo();
            }
        }
        isCheckPhoto = false;
        isGotoVideoRecord = false;

        // mPlayerNotify.setSnapshotThumbnail();
        acquireWakeLock();
        CLog.d("Debug Play-------------------------onStart");
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mRealTimeManager != null) {
            if (mCurrentUIStatus == VideoUIStatus.PLAYING) {
                mRealTimeManager.stopPlay();
                isPlayingByPaused = true;
            }
        }
        if (mTalkState == AbstractCustomStateButton.PHONE_PRESS) {
            mAudioTalkBtn.performClick();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mRealTimeManager != null) {
            if (isPlayingByPaused == true) {
                mRealTimeManager.startPlay();
                FIRST_OPEN_STREAM_TIME = System.currentTimeMillis();
                isPlayingByPaused = false;
            }
        }
        isFilterPending = false;
        if (!SoundInfoManager.isGetSoundPlayData) {
            SoundInfoManager.getInstance(mSn).asyncGetSoundList();
        }
    }

    /**
     *
     */
    @Override
    public void onStop() {
        try {
            if (!isBackFinish) {
                mOrientationListener.disable();
                if (!isCheckPhoto && !isGotoVideoRecord) {
                    stopVideo();
                }
            }
            releaseWakeLock();
        } catch (Exception e) {
            CLog.e(e.getMessage());
        }
        super.onStop();
        CLog.d("Debug Play-------------------------onStop");
    }

    private void savePreference() {
        if (mTextureView != null) {
            Preferences.setVideoScale(mCamera.getSN(), mTextureView.getScale());
        }
    }

    @Override
    public void onBackPressed() {
        if (mSoundPlayView != null && mSoundPlayView.isShowed()) {
            mSoundPlayView.animatorOut(100);
            return;
        }
        if (isPortrait()) {

            savePreference();

            if (mSoundGridView != null && mSoundGridView.isShow()) {
                // 乐库列表页面，返回到播放页面
                mSoundGridView.animatorOut(200);
                mOrientationListener.enable();
                isV = false;
                return;
            }

            isBackFinish = true;
            mOrientationListener.disable();
            mNoStreamView.setVisibility(View.VISIBLE);
            if (isVideoPlay()) {
                mNoStreamView.setImageDrawable(null);
            }
            mNoStreamView.setBackgroundResource(R.color.black);
            if (mRealTimeManager.getPlayType() == APlayManager.PlayTypes.RealMine
                    || mRealTimeManager.getPlayType() == APlayManager.PlayTypes.RealDemo
                    || mRealTimeManager.getPlayType() == APlayManager.PlayTypes.RealShare) {
                mRealTimeManager.setMute(true);
                mRealTimeManager.snapShot(APlayManager.SnapShotTypes.Stop);
            }
            mTextureView.setVisibility(View.INVISIBLE);
            stopVideo();
            mRealTimeManager.stopStream();
            super.onBackPressed();
        } else {
            mOrientationClickMode = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
    }

    private void sendStopRtick() {
        String duration = "";
        if (LAST_REPORT_TIME == 0) {
            duration = String.valueOf(System.currentTimeMillis() - firstPlayTime);
        } else {
            duration = String.valueOf(System.currentTimeMillis() - LAST_REPORT_TIME);
        }
        if (MAX_READY_DURANTION > 0 && readyTime > 0) {
            /* GlobalManager.getInstance().newPublicCameraManager().asyncSendReadyRtick(
                    String.valueOf(MAX_READY_DURANTION), String.valueOf(readyTime),
                    String.valueOf(halfTime), String.valueOf(oneSecondTime),
                    mSn, AccUtil.getInstance().getQID(),
                    duration, String.valueOf(twoSecondTime), String.valueOf(fiveSecondTime),
                    String.valueOf(tenSecondTime), String.valueOf(twentySecondTime),
                    String.valueOf(thirtySecondTime), String.valueOf(overThirtySecondTime), Constants.PRI_STRING);*/
            LAST_REPORT_TIME = System.currentTimeMillis();
        }
    }

    private void cleanReadyData() {
        MAX_READY_DURANTION = 0;
        readyTime = 0;
        halfTime = 0;
        oneSecondTime = 0;
        twoSecondTime = 0;
        fiveSecondTime = 0;
        tenSecondTime = 0;
        twentySecondTime = 0;
        thirtySecondTime = 0;
        overThirtySecondTime = 0;
        LAST_WAIT_TIME = 0;
        FIRST_OPEN_STREAM_DURANTION = 0;
        FIRST_OPEN_STREAM_TIME = 0;
        CLog.i("test3", "cleanReadyData called");
    }

    private void doPlayStatusUp() {
        try {
            HashMap<String, String> map = new HashMap<String, String>();

            map.put("callType", withCall == true ? "0" : "1");
            map.put("bufferTime", String.valueOf(TOTAL_PLAYED_DURATION));
            map.put("callTime", String.valueOf(TOTAL_TALK_DURATION));
            map.put("device_type", "1");
            map.put("slow_count", String.valueOf(TOTAL_BUFFERED_TIMES));
            map.put("timestamp", String.valueOf(System.currentTimeMillis()));
            map.put("uid", AccUtil.getInstance().getQID());
            map.put("sn", mCamera.getSN());

            QHStatAgentHelper.commitCommonEventHash("call", map);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (handler != null && startTalkRunnable != null) {
            handler.removeCallbacks(startTalkRunnable);
        }

        //        if (mMainHandler != null) {
        //            mMainHandler.removeCallbacks(mShowGuideRunnable);
        //            mMainHandler.removeCallbacks(mShowGuideRunnable);
        //        }
        mMainHandler.removeCallbacks(doCameraRequestTask);
        /* GlobalManager
                .getInstance()
                .newPublicCameraManager()
                .asyncSendTotalPlayReportRtick(String.valueOf(FIRST_OPEN_STREAM_DURANTION), String.valueOf(TOTAL_PLAYED_DURATION),
                        String.valueOf(TOTAL_BUFFERED_DURATION), String.valueOf(TOTAL_BUFFERED_TIMES),
                        String.valueOf(TOTAL_MAX_BUFFERED_DURATION),
                        mSn, AccUtil.getInstance().getQID(), String.valueOf(halfTime), String.valueOf(oneSecondTime),
                        String.valueOf(twoSecondTime),
                        String.valueOf(fiveSecondTime),
                        String.valueOf(tenSecondTime), String.valueOf(twentySecondTime),
                        String.valueOf(thirtySecondTime), String.valueOf(overThirtySecondTime), Constants.PRI_STRING);*/
        doPlayStatusUp();

        if (mSoundGridView != null) {
            mSoundGridView.onDestroy();
        }
        if (mSoundPlayView != null) {
            mSoundPlayView.onDestroy();
        }
        if (mSoundTaskFuture != null
                && !mSoundTaskFuture.isDone()
                && !mSoundTaskFuture.isCancelled()) {
            mSoundTaskFuture.cancel(true);
        }
        if (mBlurDrawable != null) {
            ((BitmapDrawable) mBlurDrawable).getBitmap().recycle();
        }
        sendStopRtick();
        //        getHandler().removeCallbacks(mCheckShineTask);
        CloudConfigManager.getInstance().unRegisterOnGlobalConfigChangedListener(this);

        if (mTalkState == AbstractCustomStateButton.PHONE_PRESS) {
            if (mRealTimeManager != null) {
                mRealTimeManager.endTalk();
                if (FIRST_TALK_START_TIME != 0) {
                    TOTAL_TALK_DURATION += System.currentTimeMillis() - FIRST_TALK_START_TIME;
                }
            }
            Preferences.setIsMic(mSn, AbstractCustomStateButton.PHONE_NORMAL);
        }

        //        soundBtnStopAni();
        destroyController();
        SoundInfoManager.clearData();// 清理缓存的数据
        System.gc();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        CLog.startTimer("onConfigurationChanged");
        //        if (mPhoneGuidePopup != null) {
        //            mPhoneGuidePopup.dismiss();
        //        }
        super.onConfigurationChanged(newConfig);
        int newOri = getResources().getConfiguration().orientation;
        if (newOri != mCurrentOrientation) {
            CLog.d("cx_debug722 - Orientation onConfigurationChanged");
            //            if (newOri == 2) {
            //                showGudiePopupWindow();
            //            }
            mCurrentOrientation = newOri;
            if (isPortrait()) {
                removeToolBarVisTimer();
            } else {
                addToolBarVisTimer();
            }

            if (mCameraList != null) {
                mCameraList.setAdapter(null);
            }

            /***** 切换前存 *****/
            CharSequence recordTime = mRecordTimeText.getText();
            //            LinkedList<Integer> dateList = mLatticeView.getDataList();
            /*****************/

            initView();
            setView();
            mStatusRunnable.run();

            /*********** 切换后还原 **************/
            mRecordTimeText.setText(recordTime);
            //            mLatticeView.setDataList(dateList);
            /*****************/

            updateOptionBtnMode();
            System.gc();
        }

        // mSnapshotThumbnailLayout.setVisibility(View.GONE);
        CLog.endTimerP("onConfigurationChanged");
    }

    @Override
    protected void doMessage(Message msg) {
        switch (msg.what) {
            case 0:
                mSnapshotThumbnailLayout.setVisibility(View.GONE);
                isShotShow = false;
                if (isPortrait()) {
                    if (showExpandUiPort) {
                        showSafeTip(true);
                    }
                }

                break;

            default:
                break;
        }
    }

    private void initSn() {
        if (mCamera instanceof Camera) {
            Camera myCamera = (Camera) mCamera;
            if (myCamera != null) {
                mSn = myCamera.getSN();
            }
        }
    }

    @Override
    public void onGlobalConfigChanged(Config oldConfig, Config newConfig) {
        CLog.d("onGlobalConfigChanged newConfig:" + newConfig);
        if (newConfig != null) {
            check_shine = newConfig.isCheckShineOn();
        }
    }

    //endregion

    // region Init

    private void initView() {
        mTwinkleAnimDrawable = (AnimationDrawable) getResources().getDrawable(R.drawable.led_twinkle_red);
        mTwinkleAnimDrawable.start();
        setParam();
        setContentView(R.layout.activity_video_play);
        mVideoPromptBanner = (VideoPromptBanner) findViewById(R.id.video_prompt_banner);
        mPlayMaskCoverOnSnapnail = findViewById(R.id.list_item_play);
        mCameraNameTV = (TextView) findViewById(R.id.text_camera_title);
        mFullScreenLayout = findViewById(R.id.btn_full_fl);
        mBackLayout = findViewById(R.id.btn_back);

        mNoStreamView = (ImageView) findViewById(R.id.video_nostream_iv);
//        mVideoViewLayout = (RelativeLayout) findViewById(R.id.video_frame);
        playBgView = (ImageView) findViewById(R.id.play_bg);

        mTextureView = (ZommTextureView) findViewById(R.id.textrue_video_view);

        mErrorLayout = findViewById(R.id.error_info_rl);
        mLoadingLayout = findViewById(R.id.loading_layout);

        mLoadingShieldIv = (ImageView) findViewById(R.id.loading_shield);
        mLoadingNonShieldIv = (DiscreteProgressbar) findViewById(R.id.loading_progress_non_safe_shield);

        mRetryLayout = findViewById(R.id.retry_layout);
        mErrorInfoText = (TextView) findViewById(R.id.error_info_text);

        mRecordTimeLayout = findViewById(R.id.ll_sd_record_time);
        mRecordTimeText = (TextView) findViewById(R.id.tv_sd_record_time);
        mRecordIcon = (ImageView) findViewById(R.id.iv_twinkle_red);
        mRecordIcon.setImageDrawable(mTwinkleAnimDrawable);

        mMuteBtn = (Button) findViewById(R.id.btn_mute_fl);
        //        mQualityBtn = (ButtonLayoutNew) findViewById(R.id.btn_quality_fl);
        mSnapshotBtn = (Button) findViewById(R.id.btn_snap_ll);
//        if (isPortrait()) {
//            mAudioTalkBtn = (CustomStatePortraitButton) findViewById(R.id.btn_push_talk_ll);
//        } else {
//            mAudioTalkBtn = (CustomStateLandscapeButton) findViewById(R.id.btn_push_talk_ll);
//        }
        mAudioTalkBtn = (CustomStatePortraitButton) findViewById(R.id.btn_push_talk_ll);
        mAudioTalkBtn.setIsCall(withCall);
        //        initPhoneGuidePopupWindow();

        mRecordBtn = (Button) findViewById(R.id.btn_record_ll);

        // 点读机版本
        //        mSoundBtn = (ButtonLayoutNew) findViewById(R.id.btn_sound_fl);
        //        mSoundBtnIcon = (MultModeButtonNew) findViewById(R.id.btn_sound);

        playSoundName = (MarqueeTextView) findViewById(R.id.text_sound_play_name);
        playSoundNameZone = (RelativeLayout) findViewById(R.id.text_sound_play_name_zone);

        mVideoTimeText = (TextView) findViewById(R.id.video_time_text);
        if (mVideoTimeText != null) {
            mVideoTimeText.setVisibility(mCamera.getSupportObj().withTimeShowInStream() ? View.GONE : View.VISIBLE);
        }

        //        mVolumLayout = findViewById(R.id.vb_layout);
        mVolumeBar = (VolumeBar) findViewById(R.id.vb_video);
        mTalkTipTv = (TextView) findViewById(R.id.tv_talk_tip);

        mSnapshotSplash = findViewById(R.id.snapshotSplash);
        mSnapshotThumbnailLayout = findViewById(R.id.snapshot_thumbnail_fl);
        mSnapshotThumbnailView = (ImageView) findViewById(R.id.snapshot_thumbnail_view);

        mStreamLayout = findViewById(R.id.video_stream_layout);
        mStreamText = (TextView) findViewById(R.id.video_stream_text);
        if (mStreamText != null) {
            mStreamText.setVisibility(View.GONE);
        }
        if (mStreamLayout != null) {
            mStreamLayout.setVisibility(View.GONE);
        }
        mStreamTextWithSafeShieldView = (TextView) findViewById(R.id.tv_comment_support);

        //        mVideoErrorLayout = findViewById(R.id.video_error_layout);

        //        mLatticeView = (LatticeView) findViewById(R.id.lattice_view);
        CLog.endTimerP("initView2");
        CLog.startTimer("initView3");
        if (isPortrait()) {
            //            SlideViewGroup mVideoViewGroup = (SlideViewGroup) findViewById(R.id.video_view_gl2_layout);
            //            mVideoViewGroup.setITapListener(new SlideViewGroup.ITapListener() {
            //                @Override
            //                public void onTap() {
            //                    switchExpandUi();
            //                }
            //            });
            mSb = (AngleView) findViewById(R.id.sb_video);
            //            mVideoViewGroup.setScrollView(sb);
            //            mSDRecordBtn = (ButtonLayoutNew) findViewById(R.id.btn_record_fl);
            mAddFilterButton = (Button) findViewById(R.id.public_video_share_and_view_button);
            //            mOldVideoTimeTextRl = (RelativeLayout) findViewById(R.id.video_time_text_old_rl);
            //            mOldVideoTimeText = (TextView) findViewById(R.id.video_time_text_old);

            mAutoCheck = findViewById(R.id.video_camera_night_auto_check);
            mOpenCheck = findViewById(R.id.video_camera_night_open_check);
            mCloseCheck = findViewById(R.id.video_camera_night_close_check);

            mMenuBtn = findViewById(R.id.btn_menu);
            mPlaybackBtn = findViewById(R.id.btn_playback);
            mSongBtn = findViewById(R.id.btn_song);
            mResolutionBtn = findViewById(R.id.btn_resolution);
            mSettingBtn = findViewById(R.id.btn_setting);
            mOption1 = findViewById(R.id.layout_options_1);
            mOption2 = findViewById(R.id.layout_options_2);
        }
        mTitleHeadListMenuWrapper = (TitleHeadListMenuWrapper) findViewById(R.id.titleHeadListMenuWrapper);
        mDownListButton = (ImageButton) findViewById(R.id.filter_menu_but);
        mTitleHeadListMenuWrapper.setFilterMenuIconButton(mDownListButton);
        mCameraList = (RecyclerView) mTitleHeadListMenuWrapper.findViewById(R.id.filter_menu_list);
        mCameraList.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

        //        initQualityPopup();
        CLog.endTimerP("initView3");
        CLog.startTimer("initView4");

        mLandTitleView = findViewById(R.id.ll_video_title_land);
        mLandOptionView = findViewById(R.id.ll_video_option_land);
        isToolBarVis = true;

        mRetryMultiView = findViewById(R.id.video_retry_layout);

        // TODO 点读机版本
        mSoundGridView = (SoundGridView) findViewById(R.id.layout_sound);

        if (mSoundGridView != null) {
            if (!isV) {
                mSoundGridView.animatorOut(0);
            } else {
                mSoundGridView.setVisibility(View.VISIBLE);
            }
            mSoundGridView.setOnItemListener(soundItemListener);
        }

        if (mSoundPlayView != null) {
            mSoundPlayView.onDestroy();
        }
        mSoundPlayView = (SoundPlayView) findViewById(R.id.soundplayview);
        if (mSoundPlayView != null) {
            mSoundPlayView.setSoundPlayListener(mSoundPlayListener);
            if (!isS) {
                mSoundPlayView.animatorOut(0);
            } else {
                //                mSoundPlayView.setVisibility(View.VISIBLE);
            }
        }
        mPushTalkTv = (TextView) findViewById(R.id.video_push_talk_text);

        CLog.endTimerP("initView4");
        CLog.startTimer("initView5");

        if (isPortrait()) {
            isShotShow = false;
            isToolBarShow = false;
        } else {
            isToolBarShow = true;
        }

        mLoadingIv = (ImageView) findViewById(R.id.loading_progress);
        // mSoundTipText = (TextView) findViewById(R.id.btn_sound_tip);
        // mRecordTipText = (TextView) findViewById(R.id.btn_record_tip);
        if (isPortrait()) {
            nightSafeView = (View) findViewById(R.id.view_night_safe);
            nightSafeView.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    setNightVis(false);
                }
            });
            //            nightView = (View) findViewById(R.id.view_night);
            // nightView.setOnTouchListener(new View.OnTouchListener() {
            // @Override
            // public boolean onTouch(View v, MotionEvent event) {
            //// switch (event.getAction()) {
            //// case MotionEvent.ACTION_UP:
            // if (mCurrentNightMode >= 0) {
            // RelativeLayout videoNightSettingRl =
            // (RelativeLayout)findViewById(R.id.rl_video_night_setting);
            // videoNightSettingRl.setVisibility(videoNightSettingRl.getVisibility()
            // == View.VISIBLE ? View.GONE : View.VISIBLE);
            // showSafeTip(videoNightSettingRl.getVisibility() == View.VISIBLE);
            // }
            //// break;
            //// }
            //
            // return false;
            // }
            // });
        }

        allView = (View) findViewById(R.id.all_view);
        mSafeShidldPopTv = (FrameLayout) findViewById(R.id.safe_shield_pop_tv);
        //        mSafeShieldView = (ImageView) findViewById(R.id.safe_shield_iv);
        //        mPopView = (View) findViewById(R.id.safe_shield_pop_windodw);

        mFullScreenLayout.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                fullScreen();
            }
        });

        CLog.endTimerP("initView5");
        CLog.startTimer("initView6");

        if (mAudioTalkBtn.mIsReInitView && mAudioTalkBtn.mButtonState < 3) {
            mAudioTalkBtn.mIsReInitView = true;
        }

        mCameraSwitchCloseRl = (RelativeLayout) findViewById(R.id.rl_camera_switch_close);
        mCameraSwitchTipsTv = (TextView) findViewById(R.id.tv_camera_switch_tips);

        mShowShieldHandler = new Handler();
        mShowShieldTimerRunnable = new Runnable() {
            public void run() {
                Utils.ensureVisbility(View.VISIBLE, mErrorInfoText, mLoadingLayout);
                CLog.e("zhaojunbo", "mErrorInfoTextShow");
                mHasDelay = true;
            }
        };
        mShowShieldHandler.postDelayed(mShowShieldTimerRunnable, 500);

        //        showGudiePopupWindow();
        CLog.endTimerP("initView6");
    }

    private Runnable mSwitchExpandUiRunnable = new Runnable() {
        @Override
        public void run() {
            switchExpandUi();
        }
    };

    private void switchExpandUi() {
        if (isPortrait()) {
            showExpandUiPort = !showExpandUiPort;
            if (com.qihoo360.homecamera.machine.myvideoplay.Config.VIDEO_PLAY_SHOW_NIGHT_MODE_SETTING) {
                if (mCurrentNightMode >= 0) {
                    RelativeLayout videoNightSettingRl = (RelativeLayout) findViewById(R.id.rl_video_night_setting);
                    videoNightSettingRl.setVisibility(
                            !showExpandUiPort ? View.GONE : View.VISIBLE);
                }
            }

            if (!showExpandUiPort) {
                allView.setVisibility(View.GONE);
                //                mSafeShieldView.setTag(true);
            }
            showSafeTip(showExpandUiPort);
            if (mStreamText != null && com.qihoo360.homecamera.machine.myvideoplay.Config.VIDEO_PLAY_SHOW_STREAM_TEXT) {
                mStreamLayout.setVisibility(showExpandUiPort ? View.VISIBLE : View.GONE);
                //                mStreamText.setVisibility(showExpandUiPort ? View.GONE : View.GONE);
            }
            if (mVideoTimeText != null && com.qihoo360.homecamera.machine.myvideoplay.Config.VIDEO_PLAY_SHOW_TIME) {
                mVideoTimeText.setVisibility(showExpandUiPort ? View.VISIBLE : View.GONE);
            }

            mMainHandler.removeCallbacks(mSwitchExpandUiRunnable);
            if (showExpandUiPort) {
                mMainHandler.postDelayed(mSwitchExpandUiRunnable, SWITCH_EXPAND_UI_DURATION);
            }
        }
    }

    private void initSafePopWindowAndAnim() {
        allView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                changePanel();
                if (!isPortrait()) {
                    removeToolBarVisTimer();
                    addToolBarVisTimer();
                }
            }
        });

        /* mSafeAnimation = (AnimationDrawable) mSafeShieldView.getDrawable();
        mSafeAnimation.start();*/

        Animation safeRotateAnim = AnimationUtils.loadAnimation(this, R.anim.safe_rotate_anim);
        LinearInterpolator lin = new LinearInterpolator();
        safeRotateAnim.setInterpolator(lin);
        if (safeRotateAnim != null) {
            mLoadingIv.startAnimation(safeRotateAnim);
        }

        isFront = false;
        //        Animation animation = AnimationUtils.loadAnimation(VideoPlayActivity.this, R.anim.safe_rotate_back_scale);
        //        animation.setAnimationListener(new MyAnimationListener());
        //        mLoadingShieldIv.startAnimation(animation);

        /*     mSafeShieldView.setTag(true);
        mSafeShieldView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                changePanel();
                if (!isPortrait()) {
                    removeToolBarVisTimer();
                    addToolBarVisTimer();
                }
            }
        });*/
        mSafeShidldPopTv.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                changePanel();
                if (!isPortrait()) {
                    removeToolBarVisTimer();
                    addToolBarVisTimer();
                }
            }
        });

        mOperaPanelDownAnim = AnimationUtils.loadAnimation(Utils.getContext(), R.anim.popup_unfold_safe_fhield);
        mOperaPanelUpAnim = AnimationUtils.loadAnimation(Utils.getContext(), R.anim.popup_fold_safe_fhield);
        mOperaPanelDownAnim.setAnimationListener(new AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                mSafeShidldPopTv.setVisibility(View.INVISIBLE);
                if (isSafeShieldShow) {
                    //                    mPopView.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                if (isSafeShieldShow) {
                    allView.setVisibility(View.VISIBLE);
                }
            }
        });

        mOperaPanelUpAnim.setAnimationListener(new AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                allView.setVisibility(View.GONE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                //                mPopView.setVisibility(View.INVISIBLE);
                if (isSafeShieldShow) {
                    mSafeShidldPopTv.setVisibility(View.GONE);
                }
            }
        });

        TextView itemName = (TextView) (findViewById(R.id.item1).findViewById(R.id.item_name));
        itemName.setText(Utils.getString(R.string.video_safe_1));
        itemName = (TextView) (findViewById(R.id.item2).findViewById(R.id.item_name));
        itemName.setText(Utils.getString(R.string.video_safe_2));
        itemName = (TextView) (findViewById(R.id.item3).findViewById(R.id.item_name));
        itemName.setText(Utils.getString(R.string.video_safe_3));
        itemName = (TextView) (findViewById(R.id.item4).findViewById(R.id.item_name));
        itemName.setText(Utils.getString(R.string.video_safe_4));
        itemName = (TextView) (findViewById(R.id.item5).findViewById(R.id.item_name));
        itemName.setText(Utils.getString(R.string.video_safe_5));
    }

    private void changePanel() {
        //        mMainHandler.removeCallbacks(mSwitchExpandUiRunnable);
        //        mMainHandler.postDelayed(mSwitchExpandUiRunnable, SWITCH_EXPAND_UI_DURATION);

        removeToolBarVisTimer();
        addToolBarVisTimer();
        CLog.d("changePanel");
        //        Boolean isClick = (Boolean) mSafeShieldView.getTag();
        /*  if (isClick) {
            mPopView.startAnimation(mOperaPanelDownAnim);
        } else {
            mPopView.startAnimation(mOperaPanelUpAnim);
        }*/
        //        isClick = !isClick;
        //        mSafeShieldView.setTag(isClick);
    }

    @Override
    public APlayManager getPlayManager() {
        return mRealTimeManager;
    }

    public class MyAnimationListener implements AnimationListener {

        @Override
        public void onAnimationStart(Animation animation) {
        }

        @Override
        public void onAnimationEnd(Animation animation) {
            if (mLoadingLayout.getVisibility() == View.VISIBLE) {
                if (isFront) {
                    animation = AnimationUtils.loadAnimation(VideoPlayActivity.this, R.anim.safe_rotate_back_scale);
                } else {
                    animation = AnimationUtils.loadAnimation(VideoPlayActivity.this, R.anim.safe_rotate_front_scale);
                }
                //                animation.setAnimationListener(new MyAnimationListener());
                //                mLoadingShieldIv.startAnimation(animation);
                isFront = !isFront;
            }
        }

        @Override
        public void onAnimationRepeat(Animation animation) {
        }

    }

    private void setParam() {
        WindowManager.LayoutParams params = getWindow().getAttributes();
        int flags;
        if (!isPortrait()) {
            params.flags |= WindowManager.LayoutParams.FLAG_FULLSCREEN;
            params.systemUiVisibility = View.SYSTEM_UI_FLAG_LOW_PROFILE;

            flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.INVISIBLE
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;

        } else {
            params.flags &= (~WindowManager.LayoutParams.FLAG_FULLSCREEN);

            flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
        }
        getWindow().setAttributes(params);
        getWindow().getDecorView().setSystemUiVisibility(flags);

        setVolumeControlStream(AudioManager.STREAM_MUSIC);
    }

    private void setView() {
        initNoStreamBG();
        mCurrentUIStatus = VideoUIStatus.NONE;
        mCameraNameTV.setText(withCall ? "视频通话" : "远程查看");

        if (isPortrait()) {
            if (mSb != null) {
                if (mCamera != null && mCamera.getHardwareObj() != null) {
                    Utils.setAngleView(mSb, mCamera.getHardwareObj().angle);
                } else {
                    Utils.setAngleView(mSb, "unknown");
                }
            }

              //TODO 以前小水滴的引导页面注掉（后续可能有自己的引导页面）
//            if (Preferences.getIsFirst("new_play_guide")) {
//                Preferences.setIsFirst("new_play_guide");
//                ViewStub vb = (ViewStub) findViewById(R.id.guide_new_play);
//                vb.inflate();
//                findViewById(R.id.guide_new_play_btn).setOnClickListener(new OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//                        findViewById(R.id.guide_new_play).setVisibility(View.GONE);
//                    }
//                });
//            }

            // 魔拍分享
            if (mAddFilterButton != null) {
                mAddFilterButton.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (snapshotMediaFileTemp != null) {
                            if (!isFilterPending) {
                                managerMuteShowActivity();
                                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
                                /*  ShareImageActivity.startActivityForResult(VideoPlayActivity.this, 300,
                                        wrapPublicCameraObj(),
                                        snapshotMediaFileTemp.getPath(), SocialShareType.TYPE_MY_CAMERA,
                                        dateFormat.format(System.currentTimeMillis()));*/
                                isFilterPending = true;
                            }
                        }
                    }
                });
            }

            if (mCurrentNightMode >= 0) {
                //                findViewById(R.id.rl_video_night_setting).setVisibility(View.VISIBLE);
                setSettings(mCurrentNightMode);
                setNightVis(false);
            } else {
                findViewById(R.id.rl_video_night_setting).setVisibility(View.GONE);
            }

        } else {
            manageScreenTouch(mCameraSwitchCloseRl);
            addToolBarVisTimer();
            mStreamLayout.setVisibility(View.GONE);
        }

        /*TextureView开始*/
        if (mTextureView.getOnViewTapListener() == null) {//用此条件来判断view已经设置过了
            mTextureView.setOnViewTapListener(new TextureViewAttacher.OnViewTapListener() {
                @Override
                public void onViewTap(View view, float x, float y) {
                    changeToolBarVis(!isToolBarVis);
                }
            });

            mTextureView.setOnMatrixChangeListener(new TextureViewAttacher.OnMatrixChangedListener() {
                @Override
                public void onMatrixChanged(RectF rect) {
                    if (isPortrait() && mSb != null) {
                        //                        mSb.setScale(mTextureView.getScale() / mTextureView.getMinimumScale());
                        int sw = SysConfig.BASE_SCREEN_WIDTH;
                        if (sw > SysConfig.BASE_SCREEN_HEIGHT) {
                            sw = SysConfig.BASE_SCREEN_HEIGHT;
                        }
                        int progress = (int) (Math.abs((mTextureView.getWidth() - sw) / 2 - rect.left) * 100
                                / (rect.width() - sw));
                        if (progress < 0) {
                            progress = 0;
                        } else if (progress > 100) {
                            progress = 100;
                        }
                        if ((rect.width() - sw) < 5) {
                            progress = 50;
                        }
                        mSb.setProgress(progress);
                    }
                }
            });

            mRenderer = new GLRendererImpl(this, this);
            TextureView.SurfaceTextureListener stl = new TextureView.SurfaceTextureListener() {
                @Override
                public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) {

                    CLog.e("cx_debug", "onSurfaceTextureAvailable width:" + width + ", height:" + height + " screenW:"
                            + SysConfig.BASE_SCREEN_WIDTH +
                            " screenH:" + SysConfig.BASE_SCREEN_HEIGHT + " viewW:" + mTextureView.getWidth() + " viewH:"
                            + mTextureView.getHeight() + "mTextureView Visibility = " + mTextureView.getVisibility());
                    int renderW;
                    int renderH;
                    int y = 0;
                    int x = 0;
                    if(width/mWHRatio > height){//屏幕比画面更宽,以高度为准
                        renderH = height;
                        renderW = (int) (renderH*mWHRatio);
                        x = (width - renderW)/2;
                    }else {//屏幕比画面更高
                        renderW = width;
                        renderH = (int) (renderW / mWHRatio);
                        y = (height - renderH) / 2;
                    }

                    int screenDisplayW = ((View) mTextureView.getParent()).getWidth();
                    int screenDisplayH = ((View) mTextureView.getParent()).getHeight();

                    float scale1 = (float) screenDisplayW / (float) renderW;
                    float scale2 = (float) screenDisplayH / (float) renderH;
                    mTextureView.setMinimumScale(Math.min(scale1, scale2));
                    if (isPortrait()) {
                        mTextureView.setMediumScale(Math.max(scale1, scale2));
                    } else {
                        mTextureView.setMediumScale(mTextureView.getMinimumScale() * 1.75f);
                    }
                    mTextureView.setMaximumScale(mTextureView.getMediumScale() * 1.75f);

                    restoreVideoPrefer();
                    mRenderer.setViewport(x, y, renderW, renderH);
                    mProducerThread = new GLProducerThread(surface, mRenderer, new AtomicBoolean(true));
                    mProducerThread.start();

                    CLog.e("cx_debug", "onSurfaceTextureAvailable width:" + width + ", height:" + height + " screenW:" + SysConfig.BASE_SCREEN_WIDTH +
                            " screenH:" + SysConfig.BASE_SCREEN_HEIGHT +" screenDisplayW:"+screenDisplayW+" screenDisplayH:"+screenDisplayH+ " viewW:" +
                            mTextureView.getWidth() + " viewH:" + mTextureView.getHeight()+" y:"+y + "mTextureView Visibility = " + mTextureView.getVisibility());
                }

                @Override
                public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {
                    CLog.e("cx_debug onSurfaceTextureSizeChanged width:" + width + " height:" + height);
                    int renderW;
                    int renderH;
                    int y = 0;
                    int x = 0;
                    if(width/mWHRatio > height){//屏幕比画面更宽,以高度为准
                        renderH = height;
                        renderW = (int) (renderH*mWHRatio);
                        x = (width - renderW)/2;
                    }else {//屏幕比画面更高
                        renderW = width;
                        renderH = (int) (renderW / mWHRatio);
                        y = (height - renderH) / 2;
                    }

                    int screenDisplayW = ((View) mTextureView.getParent()).getWidth();
                    int screenDisplayH = ((View) mTextureView.getParent()).getHeight();

                    float scale1 = (float) screenDisplayW / (float) renderW;
                    float scale2 = (float) screenDisplayH / (float) renderH;
                    mTextureView.setMinimumScale(Math.min(scale1, scale2));
                    if (isPortrait()) {
                        mTextureView.setMediumScale(Math.max(scale1, scale2));
                    } else {
                        mTextureView.setMediumScale(mTextureView.getMinimumScale() * 1.75f);
                    }
                    mTextureView.setMaximumScale(mTextureView.getMediumScale() * 1.75f);
                    mRenderer.resize(x, y, renderW, renderH);
                }

                @Override
                public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) {
                    CLog.e("cx_debug", "onSurfaceTextureDestroyed");
                    mProducerThread.stopRender();
                    mProducerThread = null;
                    return true;
                }

                @Override
                public void onSurfaceTextureUpdated(SurfaceTexture surface) {

                }
            };
            //            if (mTextureView.isAvailable()) {
            //                stl.onSurfaceTextureAvailable(mTextureView.getSurfaceTexture(),mTextureView.getWidth(),mTextureView.getHeight());
            //                CLog.d("cx_debug","mTextureView.isAvailable() =  true");
            //            }
            mTextureView.setSurfaceTextureListener(stl);

        }
        //      /*TextureView结束*/

        CLog.endTimerP("setView3");
        CLog.startTimer("setView4");
        HideVideoError();

        setAudioTalkBtn();
        mSnapshotSplash.setVisibility(View.INVISIBLE);
        updateOptionBtnEnable();

        if (isPortrait()) {
            format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        } else {
            format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        }

        //        if (mRealTimeManager.getPlayType() == APlayManager.PlayTypes.RealShare) {
        //            if (isPortrait()) {
        //                mQualityBtn.setVisibility(View.GONE);
        //                ShareCameraLevel level = CameraDataManager.getInstance().getShareCameraLevel(mCamera.sn);
        //                if (level.canViewData()) {
        //                    mSDRecordBtn.setVisibility(View.VISIBLE);
        //                } else {
        //                    mSDRecordBtn.setVisibility(View.GONE);
        //                }
        //                if (mSoundBtn != null) {
        //                    mSoundBtn.setVisibility(View.GONE);
        //                    format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        //                }
        //                mOldVideoTimeTextRl.setVisibility(View.VISIBLE);
        //                mVideoTimeText.setVisibility(View.INVISIBLE);
        //            } else {
        //                mQualityBtn.setVisibility(View.GONE);
        //            }
        //        } else {
        //            if (isPortrait()) {
        //                mQualityBtn.setVisibility(View.VISIBLE);
        //                mSDRecordBtn.setVisibility(View.VISIBLE);
        //                if (mSoundBtn != null) {
        //                    mSoundBtn.setVisibility(View.VISIBLE);
        //                    format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        //                }
        //                mOldVideoTimeTextRl.setVisibility(View.GONE);
        //            } else {
        //                mQualityBtn.setVisibility(View.VISIBLE);
        //            }
        //        }

        CLog.endTimerP("setView4");
        CLog.startTimer("setView5");
        if (isRetryMulti) {
            mRetryMultiView.setVisibility(View.VISIBLE);
        } else {
            mRetryMultiView.setVisibility(View.GONE);
        }

        setMicState();
        if (mIsDemo == 0) {
            initSafePopWindowAndAnim();
        } else {
            mSafeShidldPopTv.setVisibility(View.INVISIBLE);
            //            mSafeShieldView.setVisibility(View.INVISIBLE);
            mLoadingIv.setVisibility(View.INVISIBLE);
            mLoadingShieldIv.setVisibility(View.INVISIBLE);
            mLoadingNonShieldIv.setVisibility(View.VISIBLE);
        }

        if (mSoundPlayView != null) {
            mSoundPlayView.setSn(mSn);
        }

        if (mSoundGridView != null) {
            mSoundGridView.setSn(mSn);
        }

        if(mVideoTimeText!=null){
            mVideoTimeText.setText("");
        }
        //        if (isPortrait()) {
        //            mVideoTimeText.setText("");
        ////            mOldVideoTimeText.setText("");
        //
        //        }
        setCameraSpinner();

        Utils.ensureVisbility(mIsCameraSwitchOpen ? View.INVISIBLE : View.VISIBLE, mCameraSwitchCloseRl);
        showSafeTip(mIsCameraSwitchOpen);

        restorePreference();
        mMainHandler.removeCallbacks(mSwitchExpandUiRunnable);
        showExpandUiPort = false;
        hasPlaying = false;
        if (mVideoPromptBanner != null) {
            mVideoPromptBanner.hide();
        }
        if (mPendingShowPlayNewWhenChangeCamera) {
            mPendingShowPlayNewWhenChangeCamera = false;
            mVideoPromptBanner.show(getString(R.string.my_video_play_swipe_change) + mCamera.toString());
        }
        CLog.endTimerP("setView5");
    }

    private void restoreVideoPrefer() {
        float scaleP = Preferences.getVideoScale(mCamera.getSN());
        if (isPortrait()) {
            if (scaleP == -1) {
                mTextureView.setScale(mTextureView.getMediumScale());
            } else if (scaleP > mTextureView.getMaximumScale()) {
                mTextureView.setScale(mTextureView.getMaximumScale());
            } else if (scaleP < mTextureView.getMinimumScale()) {
                mTextureView.setScale(mTextureView.getMinimumScale());
            } else {
                mTextureView.setScale(scaleP);
            }
        } else {
            mTextureView.setScale(mTextureView.getMinimumScale());
        }
    }

    private void setMicState() {
        CameraSupport support = mCamera.getSupportObj();
        if (support != null) {
            mAudioTalkBtn.setmIsCameraSupport(support.voice_ppt_hd == 1);
        }
        mAudioTalkBtn.setmIsfirmworkSupport(isSupportVoicePPT());
        mAudioTalkBtn.setmIsPhoneSupport(VqeLookupTable.isSupport());
        if (!mIsInitPreference) {
            if (mAudioTalkBtn.mIsPhoneModeEnable) {
                if (mCamera.getRole() == 1 && !isSupportVoicePPT()) {// 分享的
                } else {
                    if (Preferences.getHasMicForceOnce(mSn) == 0) {
                        Preferences.setIsMic(mSn, AbstractCustomStateButton.PHONE_NORMAL);
                    }
                    Preferences.setIsMic(mSn, Preferences.getIsMic(mSn) < 3 ? AbstractCustomStateButton.MIC_NORMAL
                            : AbstractCustomStateButton.PHONE_NORMAL);
                }
            } else {
                Preferences.setIsMic(mSn, AbstractCustomStateButton.MIC_NORMAL);
            }

            mIsInitPreference = true;
        }
        mAudioTalkBtn.setSn(mSn);

        if (mCamera.getRole() == 1) {// 分享的
            mCameraSwitchTipsTv.setText(R.string.camera_switch_close_tips_share);
        } else {
            mCameraSwitchTipsTv.setText(R.string.camera_switch_close_tips_common_1);
        }

        mIsDemo = mCamera.getIsDemo();

        mAudioTalkBtn.setmIsDemoCamera(mIsDemo == 1);

//        if (mTalkTipTv != null) {
//            mTalkTipTv.setVisibility(mAudioTalkBtn.mButtonState < 3 ? View.VISIBLE : View.INVISIBLE);
//        }
    }

    private void setCameraSpinner() {
        if (mCameraList == null) {
            return;
        }
        if (mTitleAdapter != null && mTitleAdapter.getItemCount() > 1) {
            mDownListButton.setVisibility(View.VISIBLE);
            mCameraList.setAdapter(mTitleAdapter);
            updateCameraListMenuLP();
            mTitleHeadListMenuWrapper.setFilterMenuListener(new FilterMenuWrapper.FilterMenuListener() {
                @Override
                public void onToggle(boolean showing) {
                    if (showing) {
                        removeToolBarVisTimer();
                    } else {
                        removeToolBarVisTimer();
                        addToolBarVisTimer();
                    }
                }
            });
            findViewById(R.id.text_camera_zone).setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    mTitleHeadListMenuWrapper.toggle();
                }
            });
            mTitleAdapter.setCallback(new TitleHeadListAdapter.Callback() {
                @Override
                public void onCameraItemClick(Camera camera) {
                    playNew(camera);
                    mTitleHeadListMenuWrapper.toggle();
                }
            });

            //            for (int i = 0; i < mTitleAdapter.getItemCount(); i++) {
            //                if (mCamera.getSN().equals(mTitleAdapter.getItem(i).getSN())) {
            //                    mTitleSpinner.setSelection(i);
            //                    break;
            //                }
            //            }
        } else {
            mDownListButton.setVisibility(View.GONE);
            findViewById(R.id.text_camera_zone).setOnClickListener(null);
        }
    }

    private PublicCamera wrapPublicCameraObj() {
        Camera myCamera = mCamera;
        PublicCamera camera = new PublicCamera();
        camera.setTitlePub(myCamera.getTitle());
        String desc = myCamera.getDescription();
        if (!TextUtils.isEmpty(desc)) {
            camera.setDesc(desc);
        }
        CLog.d("====>title:" + myCamera.getTitle());
        return camera;
    }

    private void setAudioTalkBtn() {
        // TODO 声音
        mAudioTalkBtn.setOnTalkButtonClickListener(new CustomStatePortraitButton.OnTalkButtonClickListener() {
            @Override
            public void onClick(int state) {
                if (!mAudioTalkBtn.isEnabled()) {
                    return;
                }

                if (mRealTimeManager == null) {
                    return;
                }
                CLog.e("zhaojunbo", "OnTalkButtonClickListener" + state);
            }
        });
        mAudioTalkBtn.setOnChangeStateListener(new CustomStatePortraitButton.OnChangeStateListener() {
            @Override
            public void onChange(int state) {
                CLog.d("cx_debug state:" + state);
                if (state < 6) {
                    mTalkState = state;
                }
                switch (state) {
                    case AbstractCustomStateButton.MIC_PRESS://按下MIC状态
                        CLog.e("zhaojunbo", "MIC_PRESS");
                        mPushTalkTv.setText(R.string.talk_mic_press);

                        handler.postDelayed(startTalkRunnable, 500);

                        if (!isPortrait()) {
                            removeToolBarVisTimer();
                        }
                        return;
                    case AbstractCustomStateButton.MIC_NORMAL://松开MIC状态
                        CLog.e("zhaojunbo", "MIC_NORMAL");
                        handler.removeCallbacks(startTalkRunnable);
                        mPushTalkTv.setText(R.string.talk_mic_normal);
                        mVolumeBar.setProgress(0);
                        //                        mVolumeBar.setVisibility(View.INVISIBLE);
                        //                        mTalkTimer.setVisibility(View.INVISIBLE);
                        mVolumeBar.setVisibility(View.INVISIBLE);
                        if (mRealTimeManager == null) {
                            return;
                        }
//                        if (mTalkTipTv != null && mRealTimeManager != null) {
//                            mTalkTipTv.setVisibility(mRealTimeManager.getTalkMode() == LiveSession.PTT_HALF_DUPLEX
//                                    ? View.VISIBLE : View.INVISIBLE);
//                        }
                        isRecording = false;
                        /*if (isSupportVoicePPT() && VqeLookupTable.isSupport()) {
                        //                            //AccUtil.getInstance().rtick.addStat(mRealTimeManager.mCameraSN, Stat.HALF_TALK_PRESS);
                            if (isPortrait()) {
                                //AccUtil.getInstance().rtick.addStat(mRealTimeManager.mCameraSN, Stat.VIDEO_TALK_MIC_PORTRAIT);
                            } else {
                                //AccUtil.getInstance().rtick.addStat(mRealTimeManager.mCameraSN, Stat.VIDEO_TALK_MIC_LAND);
                            }
                        } else {
                            //AccUtil.getInstance().rtick.addStat(mRealTimeManager.mCameraSN, Stat.MY_CAMERA_SPEAK);
                        }*/

                        // if (mVideoTimeText != null) {
                        // mVideoTimeText.setVisibility(View.VISIBLE);
                        // }
                        if (!mRealTimeManager.getIsRecord() && mAudioTalkBtn.isCustomEnabled()) {
                            //                            mQualityBtn.setEnabled(true);
                            //                            mResolutionBtn.setEnable(true);
                        }
                        mFullScreenLayout.setEnabled(true);
                        mBackLayout.setEnabled(true);
                        mRealTimeManager.endTalk();
                        if (FIRST_TALK_START_TIME != 0) {
                            TOTAL_TALK_DURATION += System.currentTimeMillis() - FIRST_TALK_START_TIME;
                        }
                        if (!isPortrait()) {
                            addToolBarVisTimer();
                        }
                        return;
                    case AbstractCustomStateButton.PHONE_NORMAL://通话没有按下状态
                        CLog.e("zhaojunbo", "PHONE_NORMAL");
                        Preferences.setIsMic(mSn, AbstractCustomStateButton.PHONE_NORMAL);
                        if(withCall){
                            mPushTalkTv.setText(R.string.talk_phone_hand_up);
                        }else{
                            mPushTalkTv.setText(R.string.talk_phone_normal);
                        }

                        mVolumeBar.setProgress(0);
                        //                        mVolumeBar.setVisibility(View.INVISIBLE);
                        //                        mTalkTimer.setVisibility(View.INVISIBLE);
                        mVolumeBar.setVisibility(View.INVISIBLE);
//                        if (mTalkTipTv != null && mRealTimeManager != null) {
//                            mTalkTipTv.setVisibility(mRealTimeManager.getTalkMode() == LiveSession.PTT_HALF_DUPLEX
//                                    ? View.VISIBLE : View.INVISIBLE);
//                        }
                        isRecording = false;
                        // if (mVideoTimeText != null) {
                        // mVideoTimeText.setVisibility(View.VISIBLE);
                        // }
                        if (!mRealTimeManager.getIsRecord() && mAudioTalkBtn.isCustomEnabled()) {
                            //                            mQualityBtn.setEnabled(true);
                            //                            mResolutionBtn.setEnable(true);
                        }
                        mFullScreenLayout.setEnabled(true);
                        mBackLayout.setEnabled(true);
                        mRealTimeManager.endTalk();
                        if (FIRST_TALK_START_TIME != 0) {
                            TOTAL_TALK_DURATION += System.currentTimeMillis() - FIRST_TALK_START_TIME;
                        }
                        if (mSoundPlayState == SoundTask.SOUND_PAUSE && soundHandler != null && mSoundInfo != null) {
                            soundHandler.removeMessages(SOUND_HANDLER_PLAY);
                            soundHandler.sendMessageDelayed(soundHandler.obtainMessage(SOUND_HANDLER_PLAY,
                                    SoundTask.SOUND_CONTINUE, 0, mSoundInfo),
                                    SOUND_HANDLER_DELAY_TIME);
                        }
                        mAlreadyClickVoiceToast = false;
                        return;
                    case AbstractCustomStateButton.PHONE_PRESS://点击通话
                        CLog.e("zhaojunbo", "PHONE_PRESS");
                        if (!withCall) {
                            videoType = VIDEO_TYPE_CALL;
                            if (mRealTimeManager.getIsMuted() && !mAlreadyClickVoiceToast) {
                                clickVoice();
                                CLog.e("zhaojunbo", "clickVoice");
                            }
                            mAlreadyClickVoiceToast = true;

                            if (mSoundPlayState == SoundTask.SOUND_PLAY && soundHandler != null
                                    && mSoundInfo != null) {
                                soundHandler.removeMessages(SOUND_HANDLER_PLAY);
                                soundHandler.sendMessageDelayed(soundHandler.obtainMessage(SOUND_HANDLER_PLAY,
                                        SoundTask.SOUND_PAUSE, 0, mSoundInfo),
                                        SOUND_HANDLER_DELAY_TIME);
                            }

                            Preferences.setIsMic(mSn, AbstractCustomStateButton.PHONE_PRESS);
                            mPushTalkTv.setText(R.string.talk_phone_press);
                            isRecording = true;
                            //                        mVolumeBar.setVisibility(View.VISIBLE);
                            //                        mTalkTimer.setVisibility(View.VISIBLE);
                            mVolumeBar.setVisibility(View.VISIBLE);
                            if (mTalkTipTv != null) {
                                mTalkTipTv.setVisibility(View.INVISIBLE);
                            }
                            mFullScreenLayout.setEnabled(true);
                            mBackLayout.setEnabled(true);
                            if (!mRealTimeManager.getIsTalk()) {
                                mRealTimeManager.beginTalk();
                                FIRST_TALK_START_TIME = System.currentTimeMillis();
                                CLog.i("test1", "startTalkRunnable excute2");
                            }
                            if (!isPortrait()) {
                                removeToolBarVisTimer();
                            }

                        } else {//全双工，并且是通话模式下，直接挂断
                            //直接挂断
                            savePreference();

                            if (mSoundGridView != null && mSoundGridView.isShow()) {
                                // 乐库列表页面，返回到播放页面
                                mSoundGridView.animatorOut(200);
                                mOrientationListener.enable();
                                isV = false;
                                return;
                            }

                            isBackFinish = true;
                            mOrientationListener.disable();
                            mNoStreamView.setVisibility(View.VISIBLE);
                            if (isVideoPlay()) {
                                mNoStreamView.setImageDrawable(null);
                            }
                            mNoStreamView.setBackgroundResource(R.color.black);
                            if (mRealTimeManager.getPlayType() == APlayManager.PlayTypes.RealMine
                                    || mRealTimeManager.getPlayType() == APlayManager.PlayTypes.RealDemo
                                    || mRealTimeManager.getPlayType() == APlayManager.PlayTypes.RealShare) {
                                mRealTimeManager.setMute(true);
                                mRealTimeManager.snapShot(APlayManager.SnapShotTypes.Stop);
                            }
                            mTextureView.setVisibility(View.INVISIBLE);
                            stopVideo();
                            mRealTimeManager.stopStream();
                            VideoPlayActivity.this.finish();
                        }
                        return;
                    case AbstractCustomStateButton.PHONE2MIC:
                        mVideoPromptBanner.show(isPortrait() ? getString(R.string.talk_mode_change_portrait_phone2mic)
                                : getString(R.string.talk_mode_change_landscape_phone2mic));
                        return;
                    case AbstractCustomStateButton.MIC2PHONE:
                        mVideoPromptBanner.show(isPortrait() ? getString(R.string.talk_mode_change_portrait_mic2phone)
                                : getString(R.string.talk_mode_change_landscape_mic2phone));
                        return;
                }
            }

            @Override
            public void onCloseVideo() {
                closeStream();
            }
        });
        mAudioTalkBtn.setOnChangeErrorListener(new AbstractCustomStateButton.OnChangeStateErrorListener() {
            @Override
            public void onErrorMsg(int state) {
                switch (state) {
                    case AbstractCustomStateButton.CAMERA_NOT_SUPPORT:
                        mVideoPromptBanner.show(R.string.video_talk_no_support_camera);
                        return;
                    case AbstractCustomStateButton.PHONE_NOT_SUPPORT:
                        mVideoPromptBanner.show(R.string.video_talk_no_support_phone);
                        return;
                    case AbstractCustomStateButton.FIRMWORK_NEED_UPDATE:
                        if (mCamera.getRole() == 0) {
                            new CamAlertDialog.Builder(VideoPlayActivity.this)
                                    .setMessage(getString(R.string.video_voice_ppt_not_support_desc))
                                    .setTitle(getString(R.string.video_voice_ppt_not_support_title))
                                    .setIsError(false)
                                    .setMessageLeft(true)
                                    .setPositiveButton(R.string.firmware_upgrade_now,
                                            new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dialogInterface, int i) {
                                                    /* Intent intent = new Intent(VideoPlayActivity.this,
                                                             CameraSettingsActivity.class);
                                                     intent.putExtra("camera", mCamera);
                                                     intent.putExtra("showUpDialog", true);
                                                     startActivity(intent);
                                                     finish();*/
                                                }
                                            })
                                    .setNegativeButton(R.string.firmware_upgrade_cancel, null).show();
                        } else {
                            mVideoPromptBanner.show(R.string.video_voice_ppt_not_support_toast);
                        }
                        return;
                    case AbstractCustomStateButton.IS_DEMO_CAMERA:
                        mVideoPromptBanner.show(R.string.is_demo_camera);
                        return;
                }
            }
        });
    }

    private void HideVideoError() {
        mErrorLayout.setVisibility(View.INVISIBLE);
        mNoStreamView.setVisibility(View.INVISIBLE);
        mLoadingLayout.setVisibility(View.INVISIBLE);
        mRetryLayout.setVisibility(View.INVISIBLE);
        mErrorInfoText.setVisibility(View.INVISIBLE);
        //        mVideoErrorLayout.setVisibility(View.GONE);
    }

    private void initController() {
        String title = TextUtils.isEmpty(mCamera.getTitle()) ? mCamera.sn : mCamera.getTitle();
        if (mCamera.getIsDemo() == 1) {
            mRealTimeManager = new RealTimeManager(mCamera.getSN(), title, mCamera.getSupportObj().stream_v2,
                    APlayManager.PlayTypes.RealDemo, mJP2PInfo,videoType);
        } else if (mCamera.getRole() == 1) {
            mRealTimeManager = new RealTimeManager(mCamera.getSN(), title, mCamera.getSupportObj().stream_v2,
                    APlayManager.PlayTypes.RealShare, mJP2PInfo,videoType);
        } else {
            mRealTimeManager = new RealTimeManager(mCamera.getSN(), title, mCamera.getSupportObj().stream_v2,
                    APlayManager.PlayTypes.RealMine, mJP2PInfo,videoType);
        }
        CLog.i("play-v2", "mic type = " + Preferences.getIsMic(mSn));
        if (Preferences.getIsFirstMic(mSn) == false) {
            setMicState();
            CameraSupport support = mCamera.getSupportObj();
            if (support.voice_ppt_hd == 1 && Preferences.getMicType() != 0) {
                mRealTimeManager.setTalkMode(LiveSession.PTT_DUPLEX);
            } else {
                mRealTimeManager.setTalkMode(LiveSession.PTT_HALF_DUPLEX);
            }
        } else {
            mRealTimeManager.setTalkMode(Preferences.getIsMic(mSn) == 0 ? LiveSession.PTT_HALF_DUPLEX : LiveSession.PTT_DUPLEX);
        }
        mRealTimeManager.registerActionListener(this);

        updateOptionBtnMode();

    }

    private void initListener() {
        GlobalManager.getInstance().getCameraManager().registerActionListener(this);

        GlobalManager.getInstance().getCommonManager().registerActionListener(this);

        mOrientationClickMode = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;
        mOrientationListener = new OrientationEventListener(VideoPlayActivity.this) {
            @Override
            public void onOrientationChanged(int rotation) {
                int flag = Settings.System.getInt(getContentResolver(), Settings.System.ACCELEROMETER_ROTATION, 0);
                if (flag == 0 || (mRealTimeManager != null && (mRealTimeManager.getIsTalk()
                        && mTalkState != AbstractCustomStateButton.PHONE_PRESS)))
                    return;

                // 设置竖屏
                if (((rotation >= 0) && (rotation <= 30)) || (rotation >= 330)) {
                    if (mOrientationClickMode == oriLand) {
                        return;
                    }

                    if (mOrientationClickMode == ActivityInfo.SCREEN_ORIENTATION_PORTRAIT)
                        mOrientationClickMode = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;

                    if (!isPortrait()) {
                        //                        if (mQualityPopup.isShowing()) {
                        //                            mQualityPopup.dismiss();
                        //                        }
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    CLog.d("cx_debug722 - setRequestedOrientation");
                                    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                                } catch (IllegalStateException e) {
                                    e.printStackTrace();
                                }
                            }
                        });
                        //AccUtil.getInstance().rtick.addStat(mCamera.getSN(), Stat.VIDEO_SENSOR_PORTRAIT);
                    }
                }
                // 设置横屏
                else if (((rotation >= 240) && (rotation <= 300))
                        || ((rotation > 60) && (rotation < 120))) {
                    if (mOrientationClickMode == ActivityInfo.SCREEN_ORIENTATION_PORTRAIT) {
                        return;
                    }

                    if (mOrientationClickMode == oriLand)
                        mOrientationClickMode = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;

                    if (isPortrait()) {
                        //                        if (mQualityPopup.isShowing()) {
                        //                            mQualityPopup.dismiss();
                        //                        }
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    CLog.d("cx_debug722 - setRequestedOrientation");
                                    setRequestedOrientation(oriLand);
                                } catch (IllegalStateException e) {
                                    e.printStackTrace();
                                }
                            }
                        });
                        //AccUtil.getInstance().rtick.addStat(mCamera.getSN(), Stat.VIDEO_SENSOR_LAND);
                    }
                }
            }
        };

        startTalkRunnable = new Runnable() {
            public void run() {
                if (mRealTimeManager != null) {
                    mRealTimeManager.beginTalk();
                    FIRST_TALK_START_TIME = System.currentTimeMillis();
                    CLog.i("test1", "startTalkRunnable excute");
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            mVolumeBar.setProgress(0);
                            isRecording = true;
                            //                            mVolumeBar.setVisibility(View.VISIBLE);
                            //                            mTalkTimer.setVisibility(View.VISIBLE);
                            mVolumeBar.setVisibility(View.VISIBLE);
                            if (mTalkTipTv != null) {
                                mTalkTipTv.setVisibility(View.INVISIBLE);
                            }

                            //                            mQualityBtn.setEnabled(false);
                            //                            mResolutionBtn.setEnable(false);
                            mFullScreenLayout.setEnabled(false);
                            mBackLayout.setEnabled(false);
                        }
                    });
                }
            }
        };

        if (mDetector == null) {
            mDetector = new GestureDetector(this, new GestureDetector.OnGestureListener() {
                @Override
                public boolean onDown(MotionEvent motionEvent) {
                    return false;
                }

                @Override
                public void onShowPress(MotionEvent motionEvent) {

                }

                @Override
                public boolean onSingleTapUp(MotionEvent motionEvent) {
                    changeToolBarVis(!isToolBarVis);
                    return true;
                }

                @Override
                public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {
                    return false;
                }

                @Override
                public void onLongPress(MotionEvent motionEvent) {

                }

                @Override
                public boolean onFling(MotionEvent motionEvent1, MotionEvent motionEvent2, float velocityX,
                        float velocityY) {
                    return false;
                    //                    float motionX = motionEvent2.getX() - motionEvent1.getX();
                    //                    float motionY = motionEvent2.getY() - motionEvent1.getY();
                    //                    int with = SysConfig.screenWidth;
                    //                    int height = SysConfig.screenHeight;
                    //
                    //                    CLog.d(String.format("Activity onFling with:%d mSurfaceHeight:%d", with, height));
                    //                    CLog.d(String.format("Activity onFling motionX:%f motionY:%f velocityX:%f velocityY:%f", motionX, motionY, velocityX, velocityY));
                    //                    if (Math.abs(velocityX) > Math.abs(velocityY)) {
                    //                        if (Math.abs(motionY) < height / mFlingRateY) {
                    //                            if (motionX > with / mFlingRate) {
                    //                                CLog.d("test2", "1Fling ToRight");
                    //                                playTo(-1);
                    //                            } else if (motionX < -with / mFlingRate) {
                    //                                CLog.d("test2", "1Fling ToLeft");
                    //                                playTo(1);
                    //                            }
                    //                        }
                    //                    } else {
                    //                        if (Math.abs(motionX) < with / mFlingRateX) {
                    //                            if (motionY > height / mFlingRate) {
                    //                                CLog.d("test2", "1Fling Downward");
                    //
                    //                            } else if (motionY < -height / mFlingRate) {
                    //                                CLog.d("test2", "1Fling Upward");
                    //
                    //                            }
                    //                        }
                    //                    }
                    //
                    //                    return true;
                }
            });
        }
    }

    private void initNoStreamBG() {
        Glide.with(this)
                .load(mDeviceInfo.getCoverUrl())
                .placeholder(R.drawable.device_moren_icon)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .error(R.drawable.device_moren_icon)
                .into(mNoStreamView);

        if(!TextUtils.isEmpty(mDeviceInfo.getCoverUrl())){
            Glide.with(this)
                    .load(mDeviceInfo.getCoverUrl())
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .bitmapTransform(new BlurTransformation(this, 10), new ColorFilterTransformation(this, Color.parseColor("#7f000000")))
                    .into(playBgView);
        }
    }


    private void startVideo() {
        if (isRetryMulti) {
            mStatusRunnable.run();
        } else {
            mRealTimeManager.startPlay();
            FIRST_OPEN_STREAM_TIME = System.currentTimeMillis();
        }
    }

    private void stopVideo() {
        isOpenSuccess = false;
        if (!isRetryMulti) {
            mRealTimeManager.stopPlay();
            TOTAL_PLAYED_DURATION += System.currentTimeMillis() - FIRST_OPEN_STREAM_TIME;
        }
    }

    private void doGetCameraSetting() {
        //        if (mCameraSettingManager != null && mCurrentNightMode < 0) {
        //            CLog.d("doGetCameraSetting ===> " + System.currentTimeMillis());
        //            if (mCamera.getRole() == 0 && mCamera.getSupportObj().infrared == 1) {
        ////                mCameraSettingManager.doMethod(CameraSettingManager.CameraSettingParam.GET_CAMERA_SETTING, mSn);
        //            }
        //        }
    }

    private void destroyController() {
        if (mCameraList != null) {
            mCameraList.setAdapter(null);
        }
        if (mTitleAdapter != null) {
            mTitleAdapter.setCallback(null);
        }
        if (mOrientationListener != null) {
            mOrientationListener.disable();
        }
        if (readyRtickHandler != null) {
            readyRtickHandler.removeCallbacks(readyRtickRunnable);
        }
        if (mRealTimeManager != null) {
            mRealTimeManager.release();
        }
        if (mStatusRunnable != null) {
            mStatusRunnable = null;
        }

        //        if (mCameraSettingManager != null) {
        //            mCameraSettingManager.removeActionListener(this);
        //        }
        GlobalManager.getInstance().getCameraManager().removeActionListener(this);
        //        GlobalManager.getInstance().newPublicCameraManager().removeActionListener(this);
        GlobalManager.getInstance().getCommonManager().removeActionListener(this);
        mRealTimeManager = null;
        mOrientationListener = null;
        readyRtickHandler = null;
        mBlurDrawable = null;
    }

    /**
     * 更新控制按钮可用状态
     */
    private void updateOptionBtnEnable() {
        if (isPortrait()) {
            updataAllSoundView();

            updateResolutionEnabled();
            if (mRealTimeManager.getPlayType() == APlayManager.PlayTypes.RealShare
                    || mRealTimeManager.getPlayType() == APlayManager.PlayTypes.RealDemo) {
                if (mSettingBtn != null) {
                    mSettingBtn.setEnabled(false);
                }

                if (mSongBtn != null) {
                    mSongBtn.setEnabled(false);
                }
                if (mPlaybackBtn != null) {
                    //                    ShareCameraLevel level = CameraDataManager.getInstance().getShareCameraLevel(mCamera.sn);
                    //                    mPlaybackBtn.setEnabled(level.canViewData());
                }
            } else {
                if (mSettingBtn != null) {
                    mSettingBtn.setEnabled(true);
                }
                if (mSongBtn != null) {
                    if (mCamera.getSupportObj() != null) {
                        mSongBtn.setEnabled(mCamera.getSupportObj().playurl == 0 ? false : mIsCameraSwitchOpen);//有些摄像机不支持儿歌播放
                    }
                }
                if (mPlaybackBtn != null) {
                    mPlaybackBtn.setEnabled(true);
                }
            }
        }

        if (mRealTimeManager == null) {
            return;
        }

        if (isVideoPlay()) {
            mMuteBtn.setEnabled(true);
            mSnapshotBtn.setEnabled(true);
            // TODO 声音(支持花椒或者不支持通话)
            if (mCamera.getHardwareObj() != null && mCamera.getHardwareObj().no_speaker == 1) {
                mAudioTalkBtn.setEnabled(false);
            } else {
                mAudioTalkBtn.setEnabled(true);
            }

            mRecordBtn.setEnabled(true);
            //            if (mSoundPlayView != null) {
            //                mSoundPlayView.mRecordBtn.setEnabled(true);
            //                mSoundPlayView.mSnapshotBtn.setEnabled(true);
            //                mSoundPlayView.mBeautyBtn.setEnabled(true);
            //            }
            //            if (mSoundBtn != null
            //                    && (mRealTimeManager.getPlayType() == APlayManager.PlayTypes.RealMine ||
            //                    mRealTimeManager.getPlayType() == APlayManager.PlayTypes.RealDemo)) {
            //                mSoundBtn.setEnabled(true);
            //            }
            //            if (mSDRecordBtn != null
            //                    && (mRealTimeManager.getPlayType() == APlayManager.PlayTypes.RealMine ||
            //                    mRealTimeManager.getPlayType() == APlayManager.PlayTypes.RealDemo)) {
            //                mSDRecordBtn.setEnabled(true);
            //            }

            if (mRealTimeManager.getPlayType() != APlayManager.PlayTypes.RealDemo
                    && mCurrentUIStatus == VideoUIStatus.PLAYING && showExpandUiPort) {
                if (isPortrait()) {
                    showSafeTip(true);
                }
            }

            //            mQualityBtn.setEnabled(!mRealTimeManager.getIsRecord());

            if (isPortrait()) {
                //                if (mSDRecordBtn == null) {
                //                    // Ensure mSDRecordBtn object not null
                //                    mSDRecordBtn = (ButtonLayoutNew) findViewById(R.id.btn_record_fl);
                //                }
                //                if (mSDRecordBtn != null) {
                //                    mSDRecordBtn.setEnabled(!mRealTimeManager.getIsRecord());
                //                }
            }
        } else {
            mMuteBtn.setEnabled(false);
            //            mQualityBtn.setEnabled(false);
            mSnapshotBtn.setEnabled(false);
            // TODO 声音
            if (mTalkState == AbstractCustomStateButton.PHONE_PRESS) {
                mAudioTalkBtn.performClick();
            }
            mAudioTalkBtn.setEnabled(false);
            mRecordBtn.setEnabled(false);
            //            if (mSoundBtn != null) {
            //                mSoundBtn.setEnabled(false);
            //                // if (mSoundTipText != null) {
            //                // mSoundTipText.setTextColor(0xffcccccc);
            //                // }
            //            }
            //            if (mSDRecordBtn != null) {
            //                mSDRecordBtn.setEnabled(false);
            //                // if (mRecordTipText != null) {
            //                // mRecordTipText.setTextColor(0xffcccccc);
            //                // }
            //            }

            //            if (mSoundPlayView != null) {
            //                mSoundPlayView.mRecordBtn.setEnabled(false);
            //                mSoundPlayView.mSnapshotBtn.setEnabled(false);
            //                mSoundPlayView.mBeautyBtn.setEnabled(false);
            //            }
        }
        setRecordStatus(mRealTimeManager.getIsRecord(), null);
    }

    private void updateResolutionEnabled() {
        if (mResolutionBtn != null) {
            if (isVideoPlay()) {
                if (mRealTimeManager.getPlayType() == APlayManager.PlayTypes.RealShare
                        || mRealTimeManager.getPlayType() == APlayManager.PlayTypes.RealDemo) {
                    mResolutionBtn.setEnabled(false);
                } else {
                    mResolutionBtn.setEnabled(!mRealTimeManager.getIsRecord());
                }
            } else {
                mResolutionBtn.setEnabled(false);
            }
        }
    }

    /**
     * 更新控制按钮模式,主要解决横竖屏切换时View状态的更新问题
     */
    private void updateOptionBtnMode() {
        if (mRealTimeManager == null) {
            return;
        }

        //        mMuteBtn.setMode(mRealTimeManager.getIsMuted() ? 1 : 0);
        updateMuteBtn();

        //        if (!mRealTimeManager.getIsNewFirmware()) {//不支持3档码率的固件日活只有100多，卡哥说可以忽略
        //            mMQBtn.setVisibility(View.GONE);
        //            mQualityPopup.getContentView().findViewById(R.id.mid_quality_sp_view)
        //                    .setVisibility(View.GONE);
        //        } else {
        //            mMQBtn.setVisibility(View.VISIBLE);
        //            mQualityPopup.getContentView().findViewById(R.id.mid_quality_sp_view)
        //                    .setVisibility(View.VISIBLE);
        //        }

        if (isPortrait() && mResolutionBtn != null) {
            switch (mRealTimeManager.getCurrentReso()) {
                case APlayManager.ResoDefine.RESO_HD:
                    //                mQualityBtn.setMode(0);
                    mResolutionBtn.setBackgroundResource(R.drawable.video_resolution_hd_btn);
                    break;
                case APlayManager.ResoDefine.RESO_MID:
                    //                mQualityBtn.setMode(1);
                    mResolutionBtn.setBackgroundResource(R.drawable.video_resolution_mid_btn);
                    break;
                case APlayManager.ResoDefine.RESO_VGA:
                    mResolutionBtn.setBackgroundResource(R.drawable.video_resolution_vga_btn);
                    //                mQualityBtn.setMode(2);
                    break;
            }
        }
        //        mHQBtn.setSelected(mRealTimeManager.getCurrentReso() == APlayManager.ResoDefine.RESO_HD);
        //        mMQBtn.setSelected(mRealTimeManager.getCurrentReso() == APlayManager.ResoDefine.RESO_MID);
        //        mLQBtn.setSelected(mRealTimeManager.getCurrentReso() == APlayManager.ResoDefine.RESO_VGA);

        // if (mRealTimeManager.mPlayerControl.mCurrentReso > 0 &&
        // mRealTimeManager.isFirstTime()) {// 不知道这个是解决什么问题的,先注掉
        // mRealTimeManager.setFirstTime(false);
        // }

        if (!mRealTimeManager.getIsResoSetting()) {
            setStreamStatus();
        }

        //        mRecordBtn.setMode(mRealTimeManager.getIsRecord() ? 1 : 0);
        updateRecordBtn();

        //        if (mSoundPlayView != null) {
        //            mSoundPlayView.mRecordBtn.setMode(mRealTimeManager.getIsRecord() ? 1 : 0);
        //        }
    }

    private void updateRecordBtn() {
        if (mRealTimeManager.getIsRecord()) {
            if (isPortrait()) {
                mRecordBtn.setBackgroundResource(R.drawable.video_record_m2_btn);
            } else {
                mRecordBtn.setBackgroundResource(R.drawable.video_record_m2_land_btn);
            }
        } else {
            if (isPortrait()) {
                mRecordBtn.setBackgroundResource(R.drawable.video_record_btn);
            } else {
                mRecordBtn.setBackgroundResource(R.drawable.video_record_land_btn);
            }
        }
    }

    private void updateMuteBtn() {
        if (mRealTimeManager.getIsMuted()) {
            if (isPortrait()) {
                mMuteBtn.setBackgroundResource(R.drawable.video_mute_btn);
            } else {
                mMuteBtn.setBackgroundResource(R.drawable.video_mute_land_btn);
            }
        } else {
            if (isPortrait()) {
                mMuteBtn.setBackgroundResource(R.drawable.video_unmute_btn);
            } else {
                mMuteBtn.setBackgroundResource(R.drawable.video_unmute_land_btn);
            }
        }
    }

    /**
     * 根据偏好初始化功能状态
     */
    private void restorePreference() {
        mRealTimeManager.setIsMuted(Preferences.getVideoMuted(mRealTimeManager.mCameraSN));
        //        mMuteBtn.setMode(mRealTimeManager.getIsMuted() ? 1 : 0);
        updateMuteBtn();
    }

    //endregion

    //region Util

    private boolean isPortrait() {
        int current;
        if (mCurrentOrientation != Configuration.ORIENTATION_UNDEFINED) {
            current = mCurrentOrientation;
        } else {
            current = getResources().getConfiguration().orientation;
        }
        CLog.d("cx_debug722 - isPortrait252:" + String.valueOf(current == Configuration.ORIENTATION_PORTRAIT));
        return current == Configuration.ORIENTATION_PORTRAIT;
    }

    private void fullScreen() {
        if (isPortrait()) {
            setOrientationMode(oriLand);
            //AccUtil.getInstance().rtick.addStat(mRealTimeManager.mCameraSN, Stat.VIDEO_FULL_SCREEN_PORTRAIT);
        } else {
            setOrientationMode(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
    }

    private void setOrientationMode(int mode) {
        //AccUtil.getInstance().rtick.addStat(mSn, Stat.HORIZONTAL_SCREEN);
        mOrientationClickMode = mode;
        setRequestedOrientation(mode);
    }

    @SuppressWarnings("deprecation")
    private void acquireWakeLock() {
        if (mWakeLock == null) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            mWakeLock = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK
                    | PowerManager.ON_AFTER_RELEASE, VideoPlayActivity.class.getName());
            mWakeLock.acquire();
        }
    }

    private void releaseWakeLock() {
        if (mWakeLock != null && mWakeLock.isHeld()) {
            mWakeLock.release();
            mWakeLock = null;
        }
    }

    /*********************
     * Option Manager
     *********************/

    /**
     * 所有按钮的点击事件放在这里
     */
    public void onOption(View v) {
        switch (v.getId()) {
            case R.id.btn_back: // 返回
                onBackPressed();
                if (isPortrait()) {
                    //AccUtil.getInstance().rtick.addStat(mCamera.getSN(), Stat.VIDEO_BACK_PORTRAIT);
                } else {
                    //AccUtil.getInstance().rtick.addStat(mCamera.getSN(), Stat.VIDEO_BACK_LAND);
                }
                break;
            case R.id.btn_full_fl:// 全屏
                fullScreen();
                break;
            case R.id.btn_mute_fl: // 静音
                clickVoice();
                /*realTimePlayer.mPlayerControl.toggleMute(mMuteBtn);*/
                break;
            /*case R.id.btn_record_fl:// 播放录像
                onGotoRecordPlay();
                break;*/
            case R.id.btn_snap_ll:// 截图
                clickShot();
                break;
            case R.id.btn_record_ll:// 录像
                clickRecord();
                break;
            case R.id.video_loading_progress:
                mRealTimeManager.startPlay();
                break;
            case R.id.snapshot_thumbnail_fl:
                if (snapshotMediaFileTemp.getType() == MediaFiles.TYPE.IMAGE) {
                    Intent intent = new Intent(Utils.getContext(), ViewPagerActivity.class);
                    intent.putExtra("camera", mCamera);
                    intent.putExtra("mediaid", snapshotMediaFileTemp.getId());
                    intent.putExtra("shareType", SocialShareType.TYPE_MY_CAMERA);
                    startActivityForResult(intent, 200);
                    isCheckPhoto = true;
                } else {
                    Utils.openVideo(v.getContext(), snapshotMediaFileTemp.getPath());
                }
                managerMuteShowActivity();
                break;
            //            case R.id.video_brake_change_btn:
            //                onChangeQuality(mLQBtn);
            //                setBreakGone();
            //                break;
            /*case R.id.video_brake_close:
                setBreakGone();
                break;*/
            case R.id.video_retry_multi_lookup_btn:
                setRetryMultiLookUp();
                break;
            // TODO 点读机版本
            //            case R.id.btn_sound_fl:
            //                // 音乐
            //                clickSound();
            //                // if (RealTimePlayer.getCameraPlayType() ==
            //                // RealTimePlayer.CameraPlayTypes.SHOW) {
            //                // CameraToast.show(VideoPlayActivity.this,
            //                // R.string.is_demo_camera,
            //                // Toast.LENGTH_LONG);
            //                // return;
            //                // }
            //                // //TODO 固件版本判断
            //                //
            //                // if(!TextUtils.isEmpty(myVersion)){
            //                // if (mCamera instanceof Camera) {
            //                // Toast.makeText(VideoPlayActivity.this,
            //                // "固件判断："+myVersion/*((Camera)mCamera).supportPlayurl*/,
            //                // Toast.LENGTH_SHORT).show();
            //                // }
            //                //
            //                // }
            //                // if(SoundInfoManager.getInstance().isGetSoundPlayData){
            //                // //如果获取了列表数据
            //                // if (mSoundPlayView != null) {
            //                // mSoundPlayView.animatorIn(200);
            //                // isS = true;
            //                // }
            //                // } else {
            //                // //如果没有获取到数据
            //                // //TODO 没有联网
            //                // CameraToast.show(VideoPlayActivity.this,
            //                // R.string.sound_play_connect_error,
            //                // Toast.LENGTH_LONG);
            //                // SoundInfoManager.getInstance().asyncGetSoundList();
            //                // }
            //
            //                break;
            case R.id.sound_parent:
                mSoundPlayView.animatorOut(100);
                break;
            //            case R.id.btn_setting:
            //                MyActivity.startActivityCameraSetting(VideoPlayActivity.this, mCamera, 0, false);
            //                onBackPressed();
            //                //AccUtil.getInstance().rtick.addStat(mCamera.getSN(), Stat.VIDEO_SETTING_PORTRAIT);
            //                break;
            case R.id.btn_playback:
                onGotoRecordPlay();
                //AccUtil.getInstance().rtick.addStat(mCamera.getSN(), Stat.VIDEO_SD_VIDEO_PORTRAIT);
                break;
            case R.id.btn_resolution:
                int resolution = mRealTimeManager.getCurrentReso();
                String tipToast = "";
                switch (mRealTimeManager.getCurrentReso()) {
                    case APlayManager.ResoDefine.RESO_HD:
                        resolution = APlayManager.ResoDefine.RESO_MID;
                        tipToast = getString(R.string.resolution_going) + getString(R.string.video_quality_mid_mode);
                        break;
                    case APlayManager.ResoDefine.RESO_MID:
                        resolution = APlayManager.ResoDefine.RESO_VGA;
                        tipToast = getString(R.string.resolution_going) + getString(R.string.video_quality_fluent_mode);
                        break;
                    case APlayManager.ResoDefine.RESO_VGA:
                        resolution = APlayManager.ResoDefine.RESO_HD;
                        tipToast = getString(R.string.resolution_going) + getString(R.string.video_quality_clear_mode);
                        break;
                }
                mRealTimeManager.changeQuality(resolution);
                mVideoPromptBanner.show(tipToast);
                //AccUtil.getInstance().rtick.addStat(mCamera.getSN(), Stat.VIDEO_RESOLUTION_PORTRAIT);
                break;
            case R.id.btn_song:
                clickSound();
                //AccUtil.getInstance().rtick.addStat(mCamera.getSN(), Stat.VIDEO_SOUND_PORTRAIT);
                break;
            case R.id.btn_menu:
                switchPanel();
                break;
            default:
                break;
        }

        if (!isPortrait() && v.getId() != R.id.btn_quality_fl
                && v.getId() != R.id.snapshot_thumbnail_view && !mRealTimeManager.getIsTalk()) {
            removeToolBarVisTimer();
            addToolBarVisTimer();
        }
    }

    private void switchPanel() {
        if (mOption1 != null) {//竖屏
            if (mOption1.getVisibility() == View.VISIBLE) {
                mOption1.startAnimation(mPanelLeftOutAnim);
                mOption2.startAnimation(mPanelRightInAnim);
                mMenuBtn.startAnimation(mMenuLeftAnim);
            } else {
                mOption1.startAnimation(mPanelLeftInAnim);
                mOption2.startAnimation(mPanelRightOutAnim);
                mMenuBtn.startAnimation(mMenuRightAnim);
            }
            CLog.d("temp test: 1:" + mOption2.getWidth());
        }
    }

    private void gotoRecordVideo() {
        isBackFinish = true;
        isGotoVideoRecord = true;
        //        Intent videoIntent = null;
        //        if (Preferences.getLastWatchP(mCamera.getSN()) == 0 || mCamera.getCommon() == 1) {
        //            videoIntent = new Intent(this, CloudLoadingActivity.class);
        //        } else {
        //            videoIntent = new Intent(this, RecordVideoPlayActivity.class);
        //        }
        //        videoIntent.putExtra("camera", mCamera);
        //        startActivity(videoIntent);
        //        RecordPlayActivity.start(this, mCamera);
        mNoStreamView.setImageDrawable(null);
        onBackPressed();
        overridePendingTransition(R.anim.right_in, R.anim.left_out);
    }

    private void onGotoRecordPlay() {
        Camera camera = (Camera) mCamera;
        if (camera.getIsDemo() == 1) {
            mVideoPromptBanner.show(R.string.is_demo_camera);
            return;
        }
        gotoRecordVideo();
    }

    public void onPublicOption(View v) {
        if (v != null) {
            mVideoPromptBanner.show(R.string.public_video_not_do);
        }
    }

    private OnClickListener mQualityChangeListener = new OnClickListener() {
        @Override
        public void onClick(View v) {
            onOption(v);
        }
    };

    //    private void toggleQualityBtn() {
    //        if (!mQualityPopup.isShowing()) {
    //            View content = mQualityPopup.getContentView();
    //            int[] location = new int[2];
    //            content.getLocationOnScreen(location);
    //            content.measure(MeasureSpec.UNSPECIFIED, MeasureSpec.UNSPECIFIED);
    //            int xOff = mQualityBtn.getWidth() - content.getMeasuredWidth();
    //            if (isPortrait()) {
    //                int height = mQualityPopup.getContentView().getMeasuredHeight();
    //                mQualityPopup.showAsDropDown(mQualityBtn, xOff - 10, -mQualityBtn.getHeight()
    //                        - height - 10);
    //            } else {
    //                removeToolBarVisTimer();
    //                mQualityPopup.showAsDropDown(mQualityBtn, xOff / 2, 10);
    //            }
    //        } else {
    //            mQualityPopup.dismiss();
    //        }
    //    }

    //    private void onChangeQuality(View v) {
    //        if (mQualityPopup.isShowing()) {
    //            mQualityPopup.dismiss();
    //        }
    //
    //        if (mRealTimeManager.getPlayType() == APlayManager.PlayTypes.RealDemo) {
    //            mVideoPromptBanner.show(R.string.is_demo_camera);
    //            return;
    //        }
    //
    //        int resolution = -1;
    //        switch (v.getId()) {
    //            case R.id.high_quality_btn:
    //                resolution = APlayManager.ResoDefine.RESO_HD;
    //                break;
    //            case R.id.mid_quality_btn:
    //                resolution = APlayManager.ResoDefine.RESO_MID;
    //                break;
    //            case R.id.low_quality_btn:
    //                resolution = APlayManager.ResoDefine.RESO_VGA;
    //                break;
    //            default:
    //                break;
    //        }
    //        mRealTimeManager.changeQuality(resolution);
    //    }

    private void setBreakGone() {
        mRealTimeManager.setIsResoSetting(false);
        setStreamStatus();
    }

    private void setRetryMultiLookUp() {
        if (!isPortrait()) {
            setOrientationMode(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
        LayoutInflater inflater = LayoutInflater.from(this);
        View viewDialog = inflater.inflate(R.layout.item_video_retry_multi_toast, null);
        View closeBtn = viewDialog.findViewById(R.id.toast_close_iv);
        final CamAlertDialog camAlertDialog = new CamAlertDialog(this, R.style.Dialog_Fullscreen);
        camAlertDialog.setContentView(viewDialog);
        closeBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                camAlertDialog.dismiss();
            }
        });
        camAlertDialog.show();
    }

    private static class CheckShineWorkerResult {

        private ArrayList<Integer> shiningRegions = new ArrayList<Integer>();

        public String getOutputString() {
            String output = null;
            if (shiningRegions != null && shiningRegions.size() > 0) {
                StringBuilder builder = new StringBuilder(Utils.getString(R.string.check_shine_prompt));
                // for (int i : shiningRegions) {
                // builder.append(" " + i);
                // }
                output = builder.toString();
            }
            return output;
        }
    }

    private static class CheckShineWorker extends AsyncTask<Void, Void, CheckShineWorkerResult> {

        private static final int DEFAULT_RESIZE_BITMAP_MAX_DIMENSION = 192;

        private static final int DETECT_REGIONS_COUNT = 8;

        private ArrayList<Rect> detectRegions;
        private WeakReference<VideoPlayActivity> activityW;
        private String snapFilePath;

        private CheckShineWorker(VideoPlayActivity activity, String filename) {
            activityW = new WeakReference<VideoPlayActivity>(activity);
            detectRegions = new ArrayList<Rect>(DETECT_REGIONS_COUNT);
            snapFilePath = filename;
        }

        @Override
        protected CheckShineWorkerResult doInBackground(Void... params) {
            CheckShineWorkerResult result = null;
            try {
                VideoPlayActivity activity = activityW.get();
                CLog.d("checkShine snapFilePath:" + snapFilePath);
                if (snapFilePath != null &&
                        activity != null
                        && activity.isVideoPlay()
                        && activity.mRealTimeManager != null) {
                    File imageFile = new File(snapFilePath);
                    if (imageFile.exists()) {
                        Bitmap bitmap = decodeFromPath(snapFilePath);
                        if (bitmap != null) {
                            generateDetectRegions(bitmap);
                            Bitmap sbitmap = scaleBitmapDown(bitmap, DEFAULT_RESIZE_BITMAP_MAX_DIMENSION);
                            modifyDetectRegionsWithScale(sbitmap, bitmap);
                            for (int i = 0; i < DETECT_REGIONS_COUNT; ++i) {
                                Rect region = detectRegions.get(i);
                                CLog.d("checkShine detect region:" + region + ", i:" + i);
                                boolean isShinning = startParse(getPixelsFromBitmap(sbitmap, region));
                                CLog.d("checkShine isShinning:" + i + ", " + isShinning);
                                if (isShinning) {
                                    if (result == null) {
                                        result = new CheckShineWorkerResult();
                                    }
                                    result.shiningRegions.add(i);
                                }
                            }
                            imageFile.delete();
                        }
                    } else {
                        CLog.e("checkShine snapFilePath does not existed!");
                    }
                } else {
                    CLog.e("checkShine snapFilePath is null!");
                }
            } catch (Exception e) {
                Log.e("VideoPlayActivity", "checkShine fail.", e);
            }
            return result;
        }

        @Override
        protected void onPostExecute(CheckShineWorkerResult result) {
            super.onPostExecute(result);
            if (result != null) {
                String output = result.getOutputString();
                if (output != null) {
                    final VideoPlayActivity activity = activityW.get();
                    if (activity != null && result.shiningRegions.size() > 0) {
                        if (MainActivityLifecycleConfigVar.Show_Check_Shine_Prompt_Count < 2) {
                            activity.mVideoPromptBanner.show(Utils.getString(R.string.check_shine_prompt), 10000,
                                    new Runnable() {
                                        @Override
                                        public void run() {
                                            MainActivityLifecycleConfigVar.Show_Check_Shine_Prompt_Count++;
                                            //AccUtil.getInstance().rtick.addStat(activity.mSn, Stat.CHECK_SHINE_USER_CLOSE);
                                        }
                                    });
                            //AccUtil.getInstance().rtick.addStat(activity.mCamera.getSN(),Stat.CHECK_SHINE_HIT_AND_SHOW);
                        }
                        //AccUtil.getInstance().rtick.addStat(activity.mCamera.getSN(), Stat.CHECK_SHINE_HIT);
                    }
                }
            }
        }

        private Bitmap decodeFromPath(String path) {
            CLog.d("decode path:" + path);
            BitmapFactory.Options bfo = new BitmapFactory.Options();
            bfo.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(path, bfo);
            bfo.inJustDecodeBounds = false;
            bfo.inSampleSize = calculateInSampleSize(bfo, 200, 300);
            return BitmapFactory.decodeFile(path, bfo);
        }

        public static int calculateInSampleSize(
                BitmapFactory.Options options, int reqWidth, int reqHeight) {
            // Raw height and width of image
            final int height = options.outHeight;
            final int width = options.outWidth;
            int inSampleSize = 1;

            if (height > reqHeight || width > reqWidth) {

                final int halfHeight = height / 2;
                final int halfWidth = width / 2;

                // Calculate the largest inSampleSize value that is a power of 2
                // and keeps both
                // height and width larger than the requested height and width.
                while ((halfHeight / inSampleSize) > reqHeight
                        && (halfWidth / inSampleSize) > reqWidth) {
                    inSampleSize *= 2;
                }
            }

            return inSampleSize;
        }

        private void generateDetectRegions(Bitmap bitmap) {
            int bitmapWidth = bitmap.getWidth();
            int bitmapHeight = bitmap.getHeight();
            int detectCornerSize = (int) ((bitmapWidth > bitmapHeight ? bitmapHeight : bitmapWidth) / 4f);
            CLog.d("checkShine detectCornerSize:" + detectCornerSize + ", bitmap size:" + bitmap.getWidth() + ", "
                    + bitmap.getHeight());
            detectRegions.clear();
            for (int i = 0; i < DETECT_REGIONS_COUNT; ++i) {
                Rect region = new Rect();
                if (i == 0) {
                    region.set(0, 0, detectCornerSize, detectCornerSize);
                } else if (i == 1) {
                    region.set(detectCornerSize, 0, bitmapWidth - detectCornerSize, detectCornerSize);
                } else if (i == 2) {
                    region.set(bitmapWidth - detectCornerSize, 0, bitmapWidth, detectCornerSize);
                } else if (i == 3) {
                    region.set(bitmapWidth - detectCornerSize, detectCornerSize, bitmapWidth,
                            bitmapHeight - detectCornerSize);
                } else if (i == 4) {
                    region.set(bitmapWidth - detectCornerSize, bitmapHeight - detectCornerSize, bitmapWidth,
                            bitmapHeight);
                } else if (i == 5) {
                    region.set(detectCornerSize, bitmapHeight - detectCornerSize, bitmapWidth - detectCornerSize,
                            bitmapHeight);
                } else if (i == 6) {
                    region.set(0, bitmapHeight - detectCornerSize, detectCornerSize, bitmapHeight);
                } else if (i == 7) {
                    region.set(0, detectCornerSize, detectCornerSize, bitmapHeight - detectCornerSize);
                }
                detectRegions.add(region);
            }
        }

        private void modifyDetectRegionsWithScale(Bitmap scaledBitmap, Bitmap originBitmap) {
            // If we have a scaled bitmap and a selected region, we need to
            // scale down the
            // region to match the new scale
            final float scale = scaledBitmap.getWidth() / (float) originBitmap.getWidth();
            for (int i = 0; i < DETECT_REGIONS_COUNT; ++i) {
                Rect region = detectRegions.get(i);
                region.left = (int) Math.floor(region.left * scale);
                region.top = (int) Math.floor(region.top * scale);
                region.right = (int) Math.floor(region.right * scale);
                region.bottom = (int) Math.floor(region.bottom * scale);
            }
        }

        private int[] getPixelsFromBitmap(Bitmap bitmap, Rect region) {
            final int bitmapWidth = bitmap.getWidth();
            final int bitmapHeight = bitmap.getHeight();
            final int[] pixels = new int[bitmapWidth * bitmapHeight];

            if (region == null) {
                // If we don't have a region, return all of the pixels
                bitmap.getPixels(pixels, 0, bitmapWidth, 0, 0, bitmapWidth, bitmapHeight);
                return pixels;
            } else {
                // If we do have a region, lets create a subset array containing
                // only the region's
                // pixels
                final int regionWidth = region.width();
                final int regionHeight = region.height();

                final int[] subsetPixels = new int[regionWidth * region.height()];
                Bitmap subBitmap = Bitmap.createBitmap(bitmap, region.left, region.top, regionWidth, regionHeight);
                subBitmap.getPixels(subsetPixels, 0, subBitmap.getWidth(), 0, 0, subBitmap.getWidth(),
                        subBitmap.getHeight());

                // // First read the pixels within the region
                // bitmap.getPixels(pixels, 0, bitmapWidth, region.left,
                // region.top,
                // regionWidth, regionHeight);
                // // pixels now contains all of the pixels, but not packed
                // together. We need to
                // // iterate through each row and copy them into a new smaller
                // array
                // final int[] subsetPixels = new int[regionWidth *
                // region.height()];
                // for (int row = region.top, subRow = 0; row < region.bottom;
                // row++, subRow++) {
                // System.arraycopy(pixels, (row * bitmapWidth) + region.left,
                // subsetPixels, subRow * regionWidth, regionWidth);
                // }
                return subsetPixels;
            }
        }

        private boolean startParse(final int[] pixels) {
            int totalPixels = pixels.length;
            int whitePixels = 0;
            for (int i = 0; i < pixels.length; ++i) {
                if (isWhiteColor(pixels[i])) {
                    whitePixels++;
                }
            }
            CLog.d("checkShine parsing:" + "totalPixels:" + totalPixels + ", whitePixels:" + whitePixels);
            // return whitePixels > 10;
            return whitePixels / (float) totalPixels > 0.1 && whitePixels > 10;
        }

        private boolean isWhiteColor(int pixel) {
            float[] hsl = new float[3];
            // Color.colorToHSV(pixel, hsv);
            ColorUtils.colorToHSL(pixel, hsl);
            // XLog.d("isWhiteColor hsv:" + Arrays.toString(hsv));
            if (hsl[2] >= 0.9) {
                return true;
            }
            return false;
        }

        private static Bitmap scaleBitmapDown(Bitmap bitmap, final int targetMaxDimension) {
            final int maxDimension = Math.max(bitmap.getWidth(), bitmap.getHeight());

            if (maxDimension <= targetMaxDimension) {
                // If the bitmap is small enough already, just return it
                return bitmap;
            }

            final float scaleRatio = targetMaxDimension / (float) maxDimension;
            return Bitmap.createScaledBitmap(bitmap,
                    Math.round(bitmap.getWidth() * scaleRatio),
                    Math.round(bitmap.getHeight() * scaleRatio),
                    false);
        }
    }

    private Runnable mCheckShineTask = new Runnable() {
        @Override
        public void run() {
            CLog.d("checkShine run");
            if (isVideoPlay() && mRealTimeManager != null) {
                mRealTimeManager.snapShot(APlayManager.SnapShotTypes.CheckShine);
            }
        }
    };

    private long lastCheckShineTime;

    // if mode change, force check
    private void checkShine() {
        CLog.d("checkShine start");
        if (System.currentTimeMillis() - lastCheckShineTime > (Const.DEBUG ? 0 : 2 * 60 * 1000)) {
            CLog.d("checkShine enter");
            lastCheckShineTime = System.currentTimeMillis();
            getHandler().removeCallbacks(mCheckShineTask);
            getHandler().postDelayed(mCheckShineTask, 1 * 1000); // 5 * 1000
        } else {
            CLog.d("checkShine finish, no need");
        }
    }

    //endregion

    //region Private Method

    private int retryMultiCount;

    private class VideoUIStatusRunnable implements Runnable {
        public VideoUIStatus mUIStatus;
        private String mErrorMsg;
        private String mToastMsg;

        public VideoUIStatusRunnable(VideoUIStatus status, String errorMsg, String toastMsg) {
            mUIStatus = status;
            mErrorMsg = errorMsg;
            mToastMsg = toastMsg;
        }

        @Override
        public void run() {
            if (isBackFinish) {
                return;
            }

            CLog.d("Debug Play - VideoUIStatus:" + mUIStatus);
            if (mUIStatus != mCurrentUIStatus) {
                HideVideoError();
                switch (mUIStatus) {
                    case NONE:
                        if (isPortrait()) {
                            showSafeTip(false);
                        }
                        mNoStreamView.setVisibility(View.VISIBLE);
                        //                        isCloseError = false;
                    case LOADING:
                        if (isPortrait()) {
                            showSafeTip(false);
                        }

                        mNoStreamView.setVisibility(View.VISIBLE);
                        mErrorLayout.setVisibility(View.VISIBLE);
                        if (mHasDelay) {
                            mLoadingLayout.setVisibility(View.VISIBLE);
                            mErrorInfoText.setVisibility(View.VISIBLE);
                        }

                        //                        isCloseError = false;
                        break;
                    case RETRY:
                        mShowShieldHandler.removeCallbacks(mShowShieldTimerRunnable);
                        if (isPortrait()) {
                            showSafeTip(false);
                        }

                        if (mRealTimeManager.getPlayType() == APlayManager.PlayTypes.RealMine) {
                            retryMultiCount++;
                            if (retryMultiCount > 3) {
                                isRetryMulti = true;
                            }
                        }
                        mNoStreamView.setVisibility(View.VISIBLE);
                        if (isRetryMulti) {
                            mRetryMultiView.setVisibility(View.VISIBLE);
                        } else {
                            mErrorLayout.setVisibility(View.VISIBLE);
                            mRetryLayout.setVisibility(View.VISIBLE);
                            if (mHasDelay)
                                mErrorInfoText.setVisibility(View.VISIBLE);

                            // if (!isCloseError
                            // && realTimePlayer.getCurrentStatus() !=
                            // PlayerStatus.CAMERAOFFLINE) {
                            // mVideoErrorLayout.setVisibility(View.VISIBLE);
                            // }
                        }
                        break;
                    case PLAYING:
                        HideVideoError();
                        if (check_shine) {
                            if (pendingCheckShineDueToNotPlaying) {
                                checkShine();
                                pendingCheckShineDueToNotPlaying = false;
                            }
                        }
                        if (!hasPlaying) {
                            hasPlaying = true;
                            if (isPortrait()) {
                                showExpandUiPort = false;
                                switchExpandUi();
                                mMainHandler.removeCallbacks(mSwitchExpandUiRunnable);
                                mMainHandler.postDelayed(mSwitchExpandUiRunnable, SWITCH_EXPAND_UI_DURATION);
                            }
                        }
                        //                        isCloseError = false;
                        retryMultiCount = 0;
                        if (firstPlayTime == 0 && readyRtickHandler != null) {
                            firstPlayTime = System.currentTimeMillis();
                            FIRST_OPEN_STREAM_DURANTION = firstPlayTime - FIRST_OPEN_STREAM_TIME;
                            //add open stream cost to array
                            totalOpenStreamArray.add(FIRST_OPEN_STREAM_DURANTION);
                            CLog.i("test3", "totalOpenStreamArray add 1st = " + FIRST_OPEN_STREAM_DURANTION);
                            readyRtickHandler.postDelayed(readyRtickRunnable, READY_REPORT_TIME);
                        } else {
                            long currentOpenTime = System.currentTimeMillis();
                            long noneFirstOpen = currentOpenTime - FIRST_OPEN_STREAM_TIME;
                            totalOpenStreamArray.add(noneFirstOpen);
                            CLog.i("test3", "totalOpenStreamArray add another = " + noneFirstOpen);

                            // caculate ready durantion
                            long readyD = 0;
                            if (LAST_WAIT_TIME == 0) {
                                break;
                            }
                            readyD = System.currentTimeMillis() - LAST_WAIT_TIME;
                            TOTAL_BUFFERED_DURATION += readyD;
                            TOTAL_BUFFERED_TIMES += 1;

                            if (readyD > 30000) {
                                // 大于30000ms
                                overThirtySecondTime += 1;
                            } else if (readyD > 20000 && readyD <= 30000) {
                                // 20001-30000ms
                                thirtySecondTime += 1;
                            } else if (readyD > 10000 && readyD <= 20000) {
                                // 10001-20000ms
                                twentySecondTime += 1;
                            } else if (readyD > 5000 && readyD <= 10000) {
                                // 5001-10000ms
                                tenSecondTime += 1;
                            } else if (readyD > 2000 && readyD <= 5000) {
                                // 2001-5000ms
                                fiveSecondTime += 1;
                            } else if (readyD > 1000 && readyD <= 2000) {
                                // 1001-2000ms
                                twoSecondTime += 1;
                            } else if (readyD > 500 && readyD <= 1000) {
                                // 501-1000ms
                                oneSecondTime += 1;
                            } else if (readyD > 0 && readyD <= 500) {
                                // 0-500ms
                                halfTime += 1;
                            }
                            if (readyD > MAX_READY_DURANTION) {
                                MAX_READY_DURANTION = readyD;
                                TOTAL_MAX_BUFFERED_DURATION = MAX_READY_DURANTION;
                            }
                        }

                        // if (Preferences.getFirstMic2PhoneGuide() == 0 &&
                        // mAudioTalkBtn.mIsPhoneModeEnable) {
                        // mMic2PhoneGuideIv.setImageResource(R.drawable.mic2phone_guide);
                        // mPhoneGuidePopup.showAsDropDown(mAudioTalkBtn,
                        // mAudioTalkBtn.getMeasuredWidth() / 2
                        // - Utils.convertDpToPixel(Utils.getContext(), 265f) / 2,
                        // -mAudioTalkBtn.getMeasuredHeight() -
                        // Utils.convertDpToPixel(Utils.getContext(), 120.67f));
                        // Preferences.setFirstMic2PhoneGuide(1);
                        // }
                        // showGudiePopupWindow();

                        Utils.ensureVisbility(View.INVISIBLE, mCameraSwitchCloseRl);
                        mHasDelay = true;
                        mShowShieldHandler.removeCallbacks(mShowShieldTimerRunnable);
                        //如果是视频通话，则直接打开语音通道
                        if (mCamera.getRole() == 0 && mCamera.getSupportObj().infrared == 1) {
                            if (withCall) {
                                mRealTimeManager.beginTalk();
                                FIRST_TALK_START_TIME = System.currentTimeMillis();
                                ((CustomStatePortraitButton)mAudioTalkBtn).setCallButton(withCall);
                            }
                        }
                        break;
                    case WAITING:
                        if (firstPlayTime > 0) {
                            readyTime += 1;
                        }
                        LAST_WAIT_TIME = System.currentTimeMillis();
                        if (isPortrait()) {
                            showSafeTip(false);
                        }
                        mErrorLayout.setVisibility(View.VISIBLE);
                        mLoadingLayout.setVisibility(View.VISIBLE);
                        if (mHasDelay)
                            mErrorInfoText.setVisibility(View.VISIBLE);
                        // if (!isCloseError && !TextUtils.isEmpty(mToastMsg)) {
                        // mVideoErrorLayout.setVisibility(View.VISIBLE);
                        // }
                        break;
                    case SWITCH_OFF:
                        Utils.ensureVisbility(View.VISIBLE, mCameraSwitchCloseRl);
                        Utils.ensureVisbility(View.INVISIBLE, mRetryMultiView);
                        isRetryMulti = false;
                        break;
                    default:
                        break;
                }

                mCurrentUIStatus = mUIStatus;
                if (isVideoPlay()) {
                    isOpenSuccess = true;
                }
            }

            updateOptionBtnMode();
            updateOptionBtnEnable();
            if (Utils.isMoblieNetwork(Utils.getContext())) {
                mVideoPromptBanner.show(getString(R.string.notice_video_flow_info), 5000);
            }

            if (!TextUtils.isEmpty(mErrorMsg)) {
                mErrorInfoText.setText(mErrorMsg);
            }

            if (!TextUtils.isEmpty(mToastMsg) && !isShowActivity) {
                // mVideoErrorText.setText(mToastMsg);
                CameraToast.show(mToastMsg, Toast.LENGTH_SHORT);
            }
        }
    }

    private void doCameraRequest() {
        if (mCamera.getRole() == 0) {
            if (mCurrentNightMode == -1) {
                doGetCameraSetting();
            }

            mSoundTaskFuture = SoundInfoManager.getInstance(mSn).updatePlayState(soundHandler, mCamera.getSN());
            if (!SoundInfoManager.getInstance(mSn).isGetSoundPlayData) {
                SoundInfoManager.getInstance(mSn).asyncGetSoundList();
            }
        }
    }

    /**
     * 安全盾显隐
     *
     * @param show
     */
    private boolean isSafeShieldShow = true;
    private boolean isShotShow = false;
    private boolean isToolBarShow = false;

    private void showSafeTip(boolean show) {
        if (mRealTimeManager != null && mRealTimeManager.getPlayType() != APlayManager.PlayTypes.RealDemo) {
            if (show) {
                if (isPortrait() && isShotShow) {
                    return;
                }
                /* mSafeShieldView.setAlpha(0.2f);
                mSafeShieldView.animate().alpha(1f).setListener(null);*/
                //                Utils.ensureVisbility(View.VISIBLE, /*mSafeShidldPopTv, *//*mSafeShieldView,*/ mSafeShidldPopTv/*, mSafeShieldView*/);
                isSafeShieldShow = true;
            } else {
                /*  mSafeShieldView.setAlpha(1f);
                mSafeShieldView.animate().alpha(0f).setListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        super.onAnimationEnd(animation);
                        Utils.ensureVisbility(View.INVISIBLE, mSafeShieldView);
                    }
                });*/
                //                Utils.ensureVisbility(View.INVISIBLE, mSafeShidldPopTv/*, mPopView*/);
                isSafeShieldShow = false;
            }
        }
    }

    private boolean isVideoPlay() {
        if (mCurrentUIStatus == VideoUIStatus.PLAYING || mCurrentUIStatus == VideoUIStatus.WAITING)
            return true;
        return false;
    }

    private void updateSnapView() {
        /*    new Thread() {
            public void run() {
                String sn = mCamera.getSN();
                MediaFiles mediaFile = FileWrapper.getInstance(Utils.getContext()).getNewestFileBySn((sn));
                if (mediaFile != null) {
                    // do not RefreshSnapShot since we use VideoPromptBanner
                    //RefreshSnapShot(mediaFile);
                } else {
                    snapshotMediaFileTemp = null;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            mSnapshotThumbnailLayout.setVisibility(View.GONE);
                            if (isPortrait()) {
                                if (showExpandUiPort) {
                                    showSafeTip(true);
                                }
                            }
                        }
                    });
                }
            }
        }.start();*/
    }

    //endregion

    //region ToolBarVis Manager

    private Handler toolBarHandler;
    private boolean isToolBarVis;
    private int toolBarTime = 3000;

    private void addToolBarVisTimer() {
        if (toolBarHandler == null) {
            toolBarHandler = new Handler();
        }

        toolBarHandler.postDelayed(toolBarVisRunnable, toolBarTime);
    }

    private void removeToolBarVisTimer() {
        if (toolBarHandler != null) {
            toolBarHandler.removeCallbacks(toolBarVisRunnable);
        }
    }

    private Runnable toolBarVisRunnable = new Runnable() {
        @Override
        public void run() {
            //            if (!isPortrait() && mTalkState != AbstractCustomStateButton.PHONE_PRESS) {
            //                changeToolBarVis(false);
            //            }
            if (isPortrait() || mTalkState != AbstractCustomStateButton.PHONE_PRESS) {
                changeToolBarVis(false);
            }
        }
    };

    private Animation toolBarVis_Ani1;
    private Animation toolBarVis_Ani2;
    private Animation toolBarVis_Ani3;
    private Animation toolBarInVis_Ani1;
    private Animation toolBarInVis_Ani2;
    private Animation toolBarInVis_Ani3;

    private int toolBarVisAniTime = 200;

    private long lastReponseTime = 0;

    private void changeToolBarVis(boolean isVis) {
        if (System.currentTimeMillis() - lastReponseTime < 300) {
            return;
        }
        CLog.d("play-v2", "---ToolbarVis---:" + isVis + "--isToolBarVis--:" + isToolBarVis);
        if (toolBarVis_Ani1 == null) {
            initToolBarAni();
        }

        if (isVis == isToolBarVis) {
            return;
        }

        if (isVis) {
            lastReponseTime = System.currentTimeMillis();
            isToolBarVis = true;
            if (mLandTitleView != null) {
                if (mLandTitleView.getVisibility() == View.VISIBLE) {
                    return;
                }
                mLandTitleView.setVisibility(View.VISIBLE);
                mLandTitleView.startAnimation(toolBarVis_Ani1);
                CLog.i("play-v2", "mLandTitleView called VISIBLE");
            }
            if (mLandOptionView != null) {
                mLandOptionView.setVisibility(View.VISIBLE);
                mLandOptionView.startAnimation(toolBarVis_Ani2);
            }
            if (mStreamLayout != null) {
                mStreamLayout.setVisibility(View.GONE);
            }
            isToolBarShow = true;
            if (mCameraSwitchCloseRl.getVisibility() != View.VISIBLE) {
                showSafeTip(true);
            }
            addToolBarVisTimer();
            if (!isPortrait() && mTalkState == AbstractCustomStateButton.PHONE_PRESS) {
                //                mVolumeBar.setVisibility(View.VISIBLE);
                //                mTalkTimer.setVisibility(View.VISIBLE);
                Utils.ensureVisbility(mVolumeBar, View.VISIBLE);
                Utils.ensureVisbility(mTalkTipTv, View.INVISIBLE);
            }
        } else {
            showSafeTip(false);
            allView.setVisibility(View.GONE);
            //            mSafeShieldView.setTag(true);
            lastReponseTime = System.currentTimeMillis();
            removeToolBarVisTimer();
            isToolBarVis = false;
            if (mLandTitleView != null) {
                mLandTitleView.startAnimation(toolBarInVis_Ani1);
            }
            if (mLandOptionView != null) {
                mLandOptionView.startAnimation(toolBarInVis_Ani2);
            }
            //            mVolumeBar.setVisibility(View.INVISIBLE);
            //            mTalkTimer.setVisibility(View.INVISIBLE);
            if (!isPortrait()) {
                mVolumeBar.setVisibility(View.INVISIBLE);
                if (mTalkTipTv != null && mRealTimeManager != null) {
//                    mTalkTipTv.setVisibility(mRealTimeManager.getTalkMode() == LiveSession.PTT_HALF_DUPLEX
//                            ? View.VISIBLE : View.INVISIBLE);
                }
            }
        }
    }

    private void initToolBarAni() {
        // 显示
        toolBarVis_Ani1 = new AlphaAnimation(0, 1);
        toolBarVis_Ani1.setDuration(toolBarVisAniTime);

        toolBarVis_Ani2 = new AlphaAnimation(0, 1);
        toolBarVis_Ani2.setDuration(toolBarVisAniTime);

        toolBarVis_Ani3 = new TranslateAnimation(0, 0, Utils.convertDpToPixel(48.3f), 0);
        toolBarVis_Ani3.setDuration(toolBarVisAniTime);

        // 隐藏
        toolBarInVis_Ani1 = new AlphaAnimation(1, 0);
        toolBarInVis_Ani1.setDuration(toolBarVisAniTime);

        toolBarInVis_Ani2 = new AlphaAnimation(1, 0);
        toolBarInVis_Ani2.setDuration(toolBarVisAniTime);

        toolBarInVis_Ani3 = new TranslateAnimation(0, 0, 0, Utils.convertDpToPixel(48.3f));
        toolBarInVis_Ani3.setDuration(toolBarVisAniTime);

        toolBarInVis_Ani2.setAnimationListener(new AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                mLandTitleView.setVisibility(View.GONE);
                mLandOptionView.setVisibility(View.INVISIBLE);
                setStreamStatus();
                isToolBarShow = false;
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }

    //    private boolean isCloseError;

    //    private LatticeView mLatticeView;

    //    public void onCloseError(View v) {
    //        isCloseError = true;
    //        mVideoErrorLayout.setVisibility(View.GONE);
    //    }

    private void setStreamStatus() {
        if (!isPortrait() && mStreamLayout != null) {
            if (mRealTimeManager != null && !mRealTimeManager.getIsResoSetting() && !isToolBarVis
                    && com.qihoo360.homecamera.machine.myvideoplay.Config.VIDEO_PLAY_SHOW_STREAM_TEXT) {
                mStreamLayout.setVisibility(View.GONE);
            } else {
                mStreamLayout.setVisibility(View.GONE);
            }
        }
    }

    /**
     * 点击录像按钮
     */
    private void clickRecord() {
        mRecordBtn.setEnabled(false);
        //        if (mSoundPlayView != null) {
        //            mSoundPlayView.mRecordBtn.setEnabled(false);
        //        }
        if (mRealTimeManager.getIsRecord()) {
            mRecordIcon.setVisibility(View.GONE);
            mRecordTimeText.setText(R.string.video_play_ui_record_saving);
        }
        mRealTimeManager.toggleRecord();

        if (mRealTimeManager.getIsRecord()) {
            if (isPortrait()) {
                //AccUtil.getInstance().rtick.addStat(mRealTimeManager.mCameraSN, Stat.VIDEO_RECORD_PORTRAIT);
            } else {
                //AccUtil.getInstance().rtick.addStat(mRealTimeManager.mCameraSN, Stat.VIDEO_RECORD_LAND);
            }
        }
    }

    private void clickShot() {
        mSnapshotBtn.setEnabled(false);
        //        if (mSoundPlayView != null) {
        //            mSoundPlayView.mSnapshotBtn.setEnabled(false);
        //            mSoundPlayView.mBeautyBtn.setEnabled(false);// 截图时魔拍也应不可用
        //        }
        mRealTimeManager.snapShot(APlayManager.SnapShotTypes.Normal);
        if (isPortrait()) {
            //AccUtil.getInstance().rtick.addStat(mRealTimeManager.mCameraSN, Stat.VIDEO_SNAP_PORTRAIT);
        } else {
            //AccUtil.getInstance().rtick.addStat(mRealTimeManager.mCameraSN, Stat.VIDEO_SNAP_LAND);
        }
    }

    private void clickVoice() {
        //        mRealTimeManager.toggleMute(mMuteBtn);
        mRealTimeManager.toggleMute(true);
        updateMuteBtn();
        if (isPortrait()) {
            //AccUtil.getInstance().rtick.addStat(mRealTimeManager.mCameraSN, Stat.VIDEO_MUTE_PORTRAIT);
        } else {
            //AccUtil.getInstance().rtick.addStat(mRealTimeManager.mCameraSN, Stat.VIDEO_MUTE_LAND);
        }
    }

    private void clickSound() {
        if (Preferences.getFirstSoundGuide() == 0) {
            // 说明没有点击过引导,则以后也不显示了
            Preferences.setFirstSoundGuide(1);
        }

        if (mRealTimeManager.getPlayType() == APlayManager.PlayTypes.RealDemo) {
            mVideoPromptBanner.show(R.string.is_demo_camera);
            return;
        }

        if (mCamera instanceof Camera) {
            Camera myCamera = (Camera) mCamera;
            CameraSupport support = myCamera.getSupportObj();
            if (support != null && support.playurl != 1) {
                //                showUnSupportPlayUrlDialog(myCamera);
                return;
            }
        }

        if (SoundInfoManager.getInstance(mSn).isGetSoundPlayData) {
            // 如果获取了列表数据
            if (mSoundPlayView != null) {
                mSoundPlayView.animatorIn(200);
                isS = true;
            }
        } else {
            // 如果没有获取到数据
            mVideoPromptBanner.show(R.string.sound_play_connect_error);
            if (!SoundInfoManager.isGetSoundPlayData) {
                SoundInfoManager.getInstance(mSn).asyncGetSoundList();
            }
        }
    }

    //endregion

    //region 点读机播放控制界面

    // private SoundInfo mySoundInfo = null;//正在播放的曲目信息
    // 点读机播放页面控制回调
    SoundPlayListener mSoundPlayListener = new SoundPlayListener() {
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.btn_snap_ll:
                    // 截屏
                    clickShot();
                    break;
                case R.id.btn_record_ll:
                    // 录像
                    clickRecord();
                    break;
                //                case R.id.btn_beauty_ll:
                //                    // 魔拍
                ////                    if (mSoundPlayView != null) {
                ////                        mSoundPlayView.mSnapshotBtn.setEnabled(false);
                ////                        mSoundPlayView.mBeautyBtn.setEnabled(false);// 截图时魔拍也应不可用
                ////                    }
                //                    mRealTimeManager.snapShot(APlayManager.SnapShotTypes.Magic);
                //                    break;
                //                case R.id.btn_close_ll:
                //                    mSoundPlayView.animatorOut(200);
                //                    isS = false;
                //                    break;
                case R.id.image_sound_play_control:
                    if (mSoundPlayView != null) {
                        int statue = mSoundPlayView.getPlayingState();
                        mSoundPlayState = mSoundPlayView.getPlayingState();
                        mSoundInfo = mSoundPlayView.getPlaySoundInfo();
                        CLog.d("播放==" + statue);
                        if (statue == SoundTask.SOUND_STOP) {
                            soundHandler.removeMessages(SOUND_HANDLER_PLAY);
                            soundHandler.sendMessageDelayed(soundHandler.obtainMessage(SOUND_HANDLER_PLAY,
                                    SoundTask.SOUND_PLAY, 0, mSoundPlayView.getPlaySoundInfo()),
                                    SOUND_HANDLER_DELAY_TIME);
                        } else if (statue == SoundTask.SOUND_PLAY) {
                            soundHandler.removeMessages(SOUND_HANDLER_PLAY);
                            soundHandler.sendMessageDelayed(soundHandler.obtainMessage(SOUND_HANDLER_PLAY,
                                    SoundTask.SOUND_PAUSE, 0, mSoundPlayView.getPlaySoundInfo()),
                                    SOUND_HANDLER_DELAY_TIME);
                        } else if (statue == SoundTask.SOUND_PAUSE) {
                            soundHandler.removeMessages(SOUND_HANDLER_PLAY);
                            soundHandler.sendMessageDelayed(soundHandler.obtainMessage(SOUND_HANDLER_PLAY,
                                    SoundTask.SOUND_CONTINUE, 0, mSoundPlayView.getPlaySoundInfo()),
                                    SOUND_HANDLER_DELAY_TIME);
                        }
                    }
                    break;
                case R.id.image_sound_play_list:
                    if (mSoundGridView != null) {
                        mOrientationListener.disable();
                        mSoundGridView.animatorIn(200);
                        isV = true;
                    }
                    break;
            }
        }

        @Override
        public void onPlay(SoundInfo info, int state) {
            soundHandler.removeMessages(SOUND_HANDLER_PLAY);
            soundHandler.sendMessageDelayed(soundHandler.obtainMessage(SOUND_HANDLER_PLAY, state, 0, info),
                    SOUND_HANDLER_DELAY_TIME);
        }

        @Override
        public void onRefresh(int type) {
            switch (type) {
                case 0:
                case 1:

                    // 如果是0的话，说明数据要刷新,1的话只需要刷新界面就可以了
                    updataSoundGridView(type, isVideoPlay());
                    break;
                case 2:
                    // 音乐列表获取失败的，暂时不处理
                    break;
                case 3:// 3是非UI线程返回的刷新
                    soundHandler.sendEmptyMessage(SOUND_HANDLER_REFRESH);
                    break;
                default:
                    break;
            }
        }

        @Override
        public void onPlayStateChange(int state) {
            if (state == SoundTask.SOUND_PLAY) {
                soundHandler.removeMessages(SOUND_HANDLER_SOUNDNAME);
                soundHandler.sendEmptyMessageDelayed(SOUND_HANDLER_SOUNDNAME, 100);
                //                soundBtnStartAni();
            } else {
                soundHandler.removeMessages(SOUND_HANDLER_SOUNDNAME);
                soundHandler.sendEmptyMessageDelayed(SOUND_HANDLER_SOUNDNAME, 100);
                //                soundBtnStopAni();
            }
        }
    };

    //    private void soundBtnStartAni() {
    //        if (mSoundBtnIcon != null) {
    //            mSoundBtnIcon.startAnimation(AnimationUtils.loadAnimation(this, R.anim.sound_play_disk));
    //        }
    //    }

    //    private void soundBtnStopAni() {
    //        if (mSoundBtnIcon != null) {
    //            mSoundBtnIcon.clearAnimation();
    //        }
    //    }

    /**
     * 向摄像头发送播放指令
     *
     * @param info  服务器下发的播放结构对象
     * @param state 指令状态
     */
    private void playSound(SoundInfo info, int state) {
        if (info == null) {
            return;
        }
        if (mCamera instanceof Camera) {

            Camera myCamera = (Camera) mCamera;
            CLog.i("play-v2", "called playSound SoundTask");
            TaskExecutor.Execute(new SoundTask(info.getSongUrl(), state,
                    info.getSongMd5(), info.getSongType(), info
                            .getSongSize(),
                    ++SoundTask.SOUND_SEND_KEY, Head.class, handler, myCamera.getSN()));

            if (mSoundPlayView != null) {
                if (state == SoundTask.SOUND_CONTINUE || state == SoundTask.SOUND_PLAY) {
                    mSoundPlayView.startAni(mSn);
                    if (mTalkState == AbstractCustomStateButton.PHONE_PRESS) {
                        mAudioTalkBtn.performClick();
                    }
                } else if (state == SoundTask.SOUND_PAUSE) {
                    mSoundPlayView.stopAni(mSn);
                }
            }

        }
    }

    // cxy 由于有多个界面需要同步，所以在此统一管理
    private void updataAllSoundView() {
        updataSoundPlayView(0, isVideoPlay());
        updataSoundGridView(1, isVideoPlay());
    }

    private void updataSoundPlayView(int type, boolean isVideoPlay) {
        if (mSoundPlayView != null) {
            mSoundPlayView.update(mSn, type, isVideoPlay);
        }
    }

    private void updataSoundGridView(int type, boolean isVideoPlay) {
        if (mSoundGridView != null) {
            mSoundGridView.update(mSn, type, isVideoPlay);
        }
    }

    private static final int SOUND_HANDLER_PLAY = 1;
    private static final int SOUND_HANDLER_REFRESH = 2;
    private static final int SOUND_HANDLER_SOUNDNAME = 3;
    private static final long SOUND_HANDLER_DELAY_TIME = 1000;
    private Handler soundHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case SOUND_HANDLER_PLAY:
                    if (msg.obj instanceof SoundInfo) {
                        playSound((SoundInfo) msg.obj, msg.arg1);
                        updataAllSoundView();
                    }
                    break;
                case SOUND_HANDLER_REFRESH:
                    updataAllSoundView();
                    soundHandler.removeMessages(SOUND_HANDLER_SOUNDNAME);
                    soundHandler.sendEmptyMessageDelayed(SOUND_HANDLER_SOUNDNAME, 100);
                    break;
                case SOUND_HANDLER_SOUNDNAME:
                    if (playSoundName != null && SoundInfoManager.getInstance(mSn).mSoundInfo != null) {
                        CLog.d("显示");
                        if (SoundInfoManager.getInstance(mSn).playState == SoundTask.SOUND_PLAY && isVideoPlay()) {
                            String name = SoundInfoManager.getInstance(mSn).mSoundInfo.songName;
                            if (!TextUtils.isEmpty(name)) {
                                playSoundName.setFocused(true);
                                if (playSoundNameZone.getVisibility() != View.VISIBLE)
                                    playSoundNameZone.setVisibility(View.VISIBLE);
                                playSoundName.setText(VideoPlayActivity.this.getString(R.string.sound_play_name_add)
                                        + name);
                                if (isPortrait()) {
                                    showSafeTip(false);
                                }
                            }
                        } else {
                            CLog.d("隐藏");
                            if (playSoundNameZone.getVisibility() != View.INVISIBLE) {
                                playSoundNameZone.setVisibility(View.INVISIBLE);
                                if (isPortrait()) {
                                    if (showExpandUiPort) {
                                        showSafeTip(true);
                                    }
                                }
                            }
                            playSoundName.setFocused(false);

                        }
                    }
                    break;
                default:
                    break;
            }
        }
    };

    //endregion

    // region 杂

    private SoundGridView.OnItemListener soundItemListener = new SoundGridView.OnItemListener() {

        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.image_back:
                    mOrientationListener.enable();
                    isV = false;
                    break;
            }
        }

        @Override
        public void soundReady(SoundInfo info, int state) {
            // playSound(info,state);
            soundHandler.removeMessages(SOUND_HANDLER_PLAY);
            soundHandler.sendMessageDelayed(soundHandler.obtainMessage(SOUND_HANDLER_PLAY, state, 0, info),
                    SOUND_HANDLER_DELAY_TIME);
            updataSoundPlayView(0, isVideoPlay());
        }
    };

    private TextView mPushTalkTv;

    /* private void showUnSupportPlayUrlDialog(final Camera camera) {
        new CamAlertDialog.Builder(VideoPlayActivity.this)
                .setMessage(getString(R.string.sound_play_version_error))
                .setTitle(getString(R.string.sound_play_version_error_title))
                .setIsError(false)
                .setMessageLeft(true)
                .setPositiveButton(R.string.firmware_upgrade_now, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent(VideoPlayActivity.this, CameraSettingsActivity.class);
                        intent.putExtra("camera", camera);
                        intent.putExtra("showUpDialog", true);
                        startActivity(intent);
                    }
                })
                .setNegativeButton(R.string.firmware_upgrade_cancel, null).show();
    }*/

    private boolean isShowActivity;

    private void managerMuteShowActivity() {
        isShowActivity = true;
        mRealTimeManager.setIsMuted(false);
        //        mRealTimeManager.toggleMute(mMuteBtn, false);
        mRealTimeManager.toggleMute(false);
        updateMuteBtn();
    }

    private int oldMode = -1;

    Handler readyRtickHandler = new Handler();
    Runnable readyRtickRunnable = new Runnable() {
        @Override
        public void run() {
            sendStopRtick();
            readyRtickHandler.postDelayed(this, READY_REPORT_TIME);
        }
    };

    private void doServerSetting(int value) {
        /*     if (mCurrentNightMode != value) {
            pendingCheckShineDueToNotPlaying = false;
            oldMode = mCurrentNightMode;
            setSettings(value);
            mCameraSettingManager.doMethod(CameraSettingManager.CameraSettingParam.SET_CAMERA_INT_DATA, mSn,
                    CameraHttpApi.CMD_SETTING_IR, value);
        
            switch (value) {
                case 0:
                    mVideoPromptBanner.show(R.string.server_setting_0_prompt);
                    break;
                case 1:
                    mVideoPromptBanner.show(R.string.server_setting_1_prompt);
                    break;
                case 2:
                    mVideoPromptBanner.show(R.string.server_setting_2_prompt);
                    break;
            }
            setNightVis(false);
        }*/
    }

    private void setSettings(int value) {
        mCurrentNightMode = value;
        if (!isPortrait() || mAutoCheck == null) {
            return;
        }
        mAutoCheck.setSelected(mCurrentNightMode == 0);
        mOpenCheck.setSelected(mCurrentNightMode == 1);
        mCloseCheck.setSelected(mCurrentNightMode == 2);
    }

    public void checkClick(View view) {
        switch (view.getId()) {
            case R.id.video_camera_night_auto_check: {
                doServerSetting(CameraHttpApi.IV_AUTO);
                break;
            }
            case R.id.video_camera_night_open_check: {
                doServerSetting(CameraHttpApi.IV_ON);
                break;
            }
            case R.id.video_camera_night_close_check: {
                doServerSetting(CameraHttpApi.IV_OFF);
                break;
            }
            case R.id.video_night_setting_arrow: {
                setNightVis(!view.isSelected());
                break;
            }
            case R.id.rl_video_night_setting: {
                setNightVis(!findViewById(R.id.video_night_setting_arrow).isSelected());
                break;
            }
        }
    }

    private void setNightVis(boolean isExpand) {
        if (!isPortrait()) {
            return;
        }
        if (isExpand) {
            Utils.ensureVisbility(View.VISIBLE, mAutoCheck, mOpenCheck, mCloseCheck);
            if (nightSafeView != null) {
                nightSafeView.setVisibility(View.VISIBLE);
            }
            if (mAutoCheck != null && mOpenCheck != null && mCloseCheck != null) {
                mAutoCheck.setClickable(true);
                mOpenCheck.setClickable(true);
                mCloseCheck.setClickable(true);
            }
        } else {
            if (mAutoCheck != null && mOpenCheck != null && mCloseCheck != null) {
                mAutoCheck.setVisibility(mCurrentNightMode == 0 ? View.VISIBLE : View.GONE);
                mOpenCheck.setVisibility(mCurrentNightMode == 1 ? View.VISIBLE : View.GONE);
                mCloseCheck.setVisibility(mCurrentNightMode == 2 ? View.VISIBLE : View.GONE);
                mAutoCheck.setClickable(false);
                mOpenCheck.setClickable(false);
                mCloseCheck.setClickable(false);
            }
            if (nightSafeView != null) {
                nightSafeView.setVisibility(View.GONE);
            }

        }

        findViewById(R.id.video_night_setting_arrow).setSelected(isExpand);
    }

    private boolean isSupportVoicePPT() {
        if (mCamera.getSupportObj().voice_ppt == 0) {

            return false;
        }
        return true;
    }

    private boolean requestCheckShine(CameraSettings cameraSettings) {
        boolean check = false;
        if (cameraSettings != null && cameraSettings.ir != 2) {
            if (mCurrentNightMode == 1 || (mCurrentNightMode == 0 && cameraSettings.night == 1)) {
                if (check_shine) {
                    if (mCurrentUIStatus == VideoUIStatus.PLAYING) {
                        pendingCheckShineDueToNotPlaying = false;
                        checkShine();
                        check = true;
                    } else {
                        pendingCheckShineDueToNotPlaying = true;
                    }
                } else {
                    pendingCheckShineDueToNotPlaying = false;
                }
            } else {
                pendingCheckShineDueToNotPlaying = false;
            }
            CLog.d("checkShine setSettings mode:" + cameraSettings.ir + ", autoIsNight:" + cameraSettings.night
                    + ", " + mCurrentUIStatus + ", " + pendingCheckShineDueToNotPlaying);
        } else {
            // empty
        }
        return check;
    }

    //endregion

    // region Manage

    @Override
    public Object actionPerformed(int actionCode, Object... args) {
        final int sectionCode = actionCode & Actions.SECTION_MASK;
        switch (sectionCode) {

            case Actions.CameraSetting.SECTION_BASE: {
                return handleCameraSetting(actionCode, args);
            }

            case Actions.Play.SECTION_BASE: {
                return handlePlay(actionCode, args);
            }

            case Actions.Camera.SECTION_BASE: {
                return handleCamera(actionCode, args);
            }

            case Actions.Common.SECTION_BASE: {
                return handleCommon(actionCode, args);
            }
        }
        return Actions.ACTION_NOT_PROCESSED;
    }

    private Object handleCommon(int actionCode, Object[] args) {
          switch (actionCode) {
              //该机器刚好被解绑,如果正在视频，需要断开
              case Actions.Common.HAS_UNBINDED_UPDATE_VIDEOPLAY:{
                  boolean hasUnbinded = (boolean)args[0];
                  if(hasUnbinded){
                      closeStream();
                  }
                  return Boolean.TRUE;
              }
        }
        return Actions.ACTION_NOT_PROCESSED;
    }

    private void updateBlurBg() {
        ImageView v = (ImageView) findViewById(R.id.filter_menu_bg);
        ImageView v3 = (ImageView) findViewById(R.id.root_bg);
        if (v != null) {
            v.setImageDrawable(mBlurDrawable);
        }
        if (v3 != null) {
            v3.setImageDrawable(mBlurDrawable);
        }
    }

    @Override
    public int getProperty() {
        return 0;
    }

    private Object handlePublicCamera(int actionCode) {
        /* switch (actionCode) {
            case Actions.PublicCamera.CLEAN_READY_DATA:
                cleanReadyData();
                return Boolean.TRUE;
        }*/
        return Actions.ACTION_NOT_PROCESSED;
    }

    private Object handleCameraSetting(int actionCode, Object... args) {
        switch (actionCode) {
            case Actions.CameraSetting.PLAYER_MUTE: {
                try {
                    mRealTimeManager.setMute(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return Boolean.TRUE;
            }
            case Actions.CameraSetting.PLAYER_UN_MUTE: {
                try {
                    mRealTimeManager.setMute(false);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return Boolean.TRUE;
            }
            case Actions.CameraSetting.GET_SETTING_FROM_DB_RESULT: {
                //                mAllSetting = (CameraSettings) args[0];
                return Boolean.TRUE;
            }
            case Actions.CameraSetting.CAMERA_INFO: {
                //                Head infoHead = (Head) args[0];
                //                if (!infoHead.sn.equals(mSn)) {
                //                    return Boolean.TRUE;
                //                }
                //                if (infoHead.getErrorCode() == Constants.Http.ERROR_CODE_SUCCEED) {
                //                    CLog.d("doGetCameraSetting ===> Success");
                //                    View nightSettingView = findViewById(R.id.rl_video_night_setting);
                //                    if (nightSettingView != null && showExpandUiPort && com.qihoo360.homecamera.machine.myvideoplay.Config.VIDEO_PLAY_SHOW_NIGHT_MODE_SETTING) {
                //                        nightSettingView.setVisibility(View.VISIBLE);
                //                    }
                //                    CameraSettings cameraSettings = ((PushValues) infoHead).getData(CameraSettings.class);
                //                    mAllSetting = cameraSettings;
                //                    setSettings(cameraSettings.ir);
                //                    requestCheckShine(cameraSettings);
                //                    setNightVis(false);
                //                } else {
                //                    CLog.d("doGetCameraSetting ===> Error");
                //                    if (mCurrentUIStatus != VideoUIStatus.RETRY
                //                            && infoHead.getErrorCode() != Constants.Http.ERROR_CAM_OFFLINE) {
                ////                        CLog.d("doGetCameraSetting ===> RETRY");
                ////                        doGetCameraSetting();
                //                    }
                //                }
                return Boolean.TRUE;
            }
            case Actions.CameraSetting.SET_RESULT: {
                /* Head resultHead = (Head) args[0];
                if (!resultHead.sn.equals(mSn)) {
                    return Boolean.TRUE;
                }
                if (resultHead.getErrorCode() != Constants.Http.ERROR_CODE_SUCCEED) {
                    mVideoPromptBanner.show(resultHead.getErrorMsg());
                    setSettings(oldMode);
                    if (mCurrentNightMode != 2) {
                        doGetCameraSetting();
                    }
                } else {
                
                }*/
                return Boolean.TRUE;
            }
        }
        return Actions.ACTION_NOT_PROCESSED;
    }

    // region handlePlay

    private Object handlePlay(int actionCode, Object... args) {
        switch (actionCode) {
            case Actions.Play.NOTIFY_VIDEO_TIMEOUT:{
                String msg = getString(R.string.open_video_failed_tip);
                UpdateStatus(PlayerFailed, msg);
                return Boolean.TRUE;
            }
            case Actions.Play.UPDATE_PLAY_STATUS: {
                APlayManager.PlayStatus playStatus = (APlayManager.PlayStatus) args[0];
                String msg = args[1].toString();
                UpdateStatus(playStatus, msg);
                return Boolean.TRUE;
            }
            case Actions.Play.UPDATE_PLAY_TIME: {
                long time = (Long) args[0];
                UpdatePlayTime(time);
                return Boolean.TRUE;
            }
            case Actions.Play.UPDATE_STREAM_FLOW: {
                int download = (Integer) args[0];
                int vfps = (Integer) args[1];
                UpdateStreamFlow(download, vfps);
                return Boolean.TRUE;
            }
            case Actions.Play.UPDATE_RESO_MODE: {
                int reso = (Integer) args[0];
                UpdateQualityMode(reso);
                return Boolean.TRUE;
            }
            case Actions.Play.UPDATE_CMD_RESULT: {
                String msg = args[0].toString();
                APlayManager.PlayerCmd cmd = (APlayManager.PlayerCmd) args[1];
                UpdateCmdResult(msg, cmd);
                return Boolean.TRUE;
            }
            case Actions.Play.UPDATE_SNAP_SHOT: {
                MediaFiles mediaFiles = (MediaFiles) args[0];
                APlayManager.SnapShotTypes type = (APlayManager.SnapShotTypes) args[1];
                UpdateSnapShot(mediaFiles, type);
                return Boolean.TRUE;
            }
            case Actions.Play.UPDATE_RECORD_STATUS: {
                boolean isRecord = (Boolean) args[0];
                String msg = (String) args[1];
                MediaFiles mf = null;
                if (args.length > 2) {
                    mf = (MediaFiles) args[2];
                }
                UpdateRecordStatus(isRecord, msg, mf);
                return Boolean.TRUE;
            }
            case Actions.Play.UPDATE_RECORD_TIME: {
                int time = (Integer) args[0];
                UpdateRecordTime(time);
                return Boolean.TRUE;
            }
            case Actions.Play.UPDATE_TALK_VOLUME: {
                float volume = (Float) args[0];
                UpdateVolume(volume);
                return Boolean.TRUE;
            }
            case Actions.Play.NOTIFY_STREAM_BRAKE: {
                if (mRealTimeManager.getPlayType() != APlayManager.PlayTypes.RealDemo
                        && mRealTimeManager.getPlayType() != APlayManager.PlayTypes.RealShare) {
                     NotifyStreamBrake();
                }
                return Boolean.TRUE;
            }

            case Actions.Play.NOTIFY_TALK_NO_VOICE:{
                if(mVideoPromptBanner!=null){
                    mVideoPromptBanner.show(R.string.audio_permission);
                }
                return Boolean.TRUE;
            }
        }
        return Actions.ACTION_NOT_PROCESSED;
    }

    private Runnable doCameraRequestTask = new Runnable() {
        @Override
        public void run() {
            doCameraRequest();
        }
    };

    public void UpdateStatus(APlayManager.PlayStatus status, String msg) {
        String uiMsg = "";
        VideoUIStatus newStatus = VideoUIStatus.LOADING;
        CLog.d("Debug Play - PlayStatus:" + status);
        switch (status) {
            case MasterConnecting:
                if (mRealTimeManager.getPlayType() == APlayManager.PlayTypes.RealDemo) {
                    uiMsg = getString(R.string.notice_video_connect_server_info);
                } else {
                    uiMsg = getString(R.string.notice_video_safe_loading_info1);
                }
                newStatus = VideoUIStatus.LOADING;
                mMainHandler.removeCallbacks(doCameraRequestTask);
                break;
            case PlayerConnecting:
                if (mRealTimeManager.getPlayType() == APlayManager.PlayTypes.RealDemo) {
                    uiMsg = getString(R.string.notice_video_loading_info);
                } else {
                    uiMsg = getString(R.string.notice_video_safe_loading_info2);
                }
                newStatus = VideoUIStatus.LOADING;
                // delay doCameraRequestTask to avoid repeat request in p2p and relay
                mMainHandler.removeCallbacks(doCameraRequestTask);
                mMainHandler.postDelayed(doCameraRequestTask, 1000);
                break;
            case PlayerWaiting:
                if (mRealTimeManager.getPlayType() == APlayManager.PlayTypes.RealDemo) {
                    uiMsg = getString(R.string.notice_video_waiting_info);
                } else {
                    uiMsg = getString(R.string.notice_video_safe_loading_info3);
                }
                newStatus = VideoUIStatus.LOADING;
                break;
            case CameraOffline:
                uiMsg = getString(R.string.notice_video_device_offline);
                newStatus = VideoUIStatus.RETRY;
                break;
            case MasterFailed:
            case PlayerFailed:
                // 服务器连接失败，请检查网络
                uiMsg = getString(R.string.notice_video_retry_info);
                newStatus = VideoUIStatus.RETRY;
                break;
            case Playing:
                newStatus = VideoUIStatus.PLAYING;
                break;
            case Buffering:
                uiMsg = getString(R.string.notice_video_wait_info);
                newStatus = VideoUIStatus.WAITING;
                break;
            case Stopped:// 列表切换摄像机会 Stopping - MasterConnecting - Stopped 造成状态不对
                newStatus = null;
                break;
            case Stopping:
                newStatus = VideoUIStatus.NONE;
                break;
            case SoftSwitchOff:
                newStatus = VideoUIStatus.SWITCH_OFF;
                break;
            default:
                break;
        }
        if (newStatus != null) {
            mStatusRunnable = new VideoUIStatusRunnable(newStatus, uiMsg, msg);
            runOnUiThread(mStatusRunnable);
        }
    }

    private MediaFiles snapshotMediaFileTemp;

    public void UpdateCmdResult(final String msg, final APlayManager.PlayerCmd cmd) {
        runOnUiThread(new Runnable() {
            public void run() {
                if (cmd != APlayManager.PlayerCmd.SnapShot) {
                    mVideoPromptBanner.show(msg);
                } else {
                    if (TextUtils.equals(getString(R.string.notice_video_snapshot_failed), msg) ||
                            TextUtils.equals(getString(R.string.notice_video_snapshot_failed_for_share), msg)) {
                        mVideoPromptBanner.show(msg);
                    }

                    mSnapshotBtn.setEnabled(true);
                    //                    if (mSoundPlayView != null) {
                    //                        mSoundPlayView.mSnapshotBtn.setEnabled(true);
                    //                        mSoundPlayView.mBeautyBtn.setEnabled(true);
                    //                    }
                }
            }
        });
    }

    private Animation mSnapshotAni_Alpha;// 定义动画

    public void UpdateSnapShot(MediaFiles mediaFiles, APlayManager.SnapShotTypes type) {
        if (type == APlayManager.SnapShotTypes.Normal) {
            if (mSnapshotAni_Alpha == null) {
                mSnapshotAni_Alpha = new AlphaAnimation(1.0f, 0.0f);
                mSnapshotAni_Alpha.setDuration(500);
                mSnapshotAni_Alpha.setAnimationListener(new AnimationListener() {
                    @Override
                    public void onAnimationStart(Animation animation) {
                        mSnapshotSplash.setVisibility(View.INVISIBLE);
                    }

                    @Override
                    public void onAnimationEnd(Animation animation) {
                        mSnapshotSplash.setVisibility(View.INVISIBLE);
                    }

                    @Override
                    public void onAnimationRepeat(Animation animation) {

                    }
                });
            }

            snapshotMediaFileTemp = mediaFiles;
            runOnUiThread(new Runnable() {
                public void run() {
                    mSnapshotSplash.startAnimation(mSnapshotAni_Alpha);
                    setSnapshotThumbnail();
                    mSnapshotBtn.setEnabled(true);
                    //                    if (mSoundPlayView != null) {
                    //                        mSoundPlayView.mSnapshotBtn.setEnabled(true);
                    //                        mSoundPlayView.mBeautyBtn.setEnabled(true);
                    //                    }
                }
            });
        } else if (type == APlayManager.SnapShotTypes.Magic) {
            snapshotMediaFileTemp = mediaFiles;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (!isFilterPending) {
                        managerMuteShowActivity();
                        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
                        /*  ShareImageActivity.startActivityForResult(VideoPlayActivity.this,
                                300, wrapPublicCameraObj(), snapshotMediaFileTemp.getPath(),
                                SocialShareType.TYPE_MY_CAMERA,
                                dateFormat.format(System.currentTimeMillis()));*/
                        isFilterPending = true;
                    }
                }
            });
        } else if (type == APlayManager.SnapShotTypes.CheckShine) {
            new CheckShineWorker(VideoPlayActivity.this, mediaFiles.getPath()).execute();
        }
    }

    public void RefreshSnapShot(MediaFiles mediaFiles) {
        if (snapshotMediaFileTemp != null
                && !TextUtils.equals(snapshotMediaFileTemp.getPath(), mediaFiles.getPath())) {
            snapshotMediaFileTemp = mediaFiles;
            runOnUiThread(new Runnable() {
                public void run() {
                    setSnapshotThumbnail();
                }
            });
        }
    }

    private void setSnapshotThumbnail() {
        if (snapshotMediaFileTemp != null && snapshotMediaFileTemp.getPath() != "") {
            handler.removeMessages(0);
            handler.sendEmptyMessageDelayed(0, 4000);
            if (mSnapshotThumbnailLayout.getVisibility() != View.VISIBLE) {
                isFilterPending = false;
                if (!isPortrait()) {
                    mSnapshotThumbnailLayout.setVisibility(View.VISIBLE);
                }
                if (isPortrait()) {
                    showSafeTip(false);
                }
                isShotShow = true;
            }

            String path = "file:///" + snapshotMediaFileTemp.getPath();
            ImageLoader.getInstance().cancelDisplayTask(mSnapshotThumbnailView);
            ImageLoader.getInstance().displayImage(path, mSnapshotThumbnailView);
            if (snapshotMediaFileTemp.getType() == MediaFiles.TYPE.VIDEO) {
                if (mPlayMaskCoverOnSnapnail != null) {
                    mPlayMaskCoverOnSnapnail.setVisibility(View.VISIBLE);
                }
            } else {
                if (mPlayMaskCoverOnSnapnail != null) {
                    mPlayMaskCoverOnSnapnail.setVisibility(View.GONE);
                }
            }
            if (mVideoPromptBanner != null && isPortrait()) {
                String title = snapshotMediaFileTemp.getType() == MediaFiles.TYPE.VIDEO
                        ? getString(R.string.video_play_ui_record_prompt)
                        : getString(R.string.video_play_ui_snapshot_prompt);
                String actionText = snapshotMediaFileTemp.getType() == MediaFiles.TYPE.VIDEO
                        ? getString(R.string.video_play_ui_snapshot_prompt_action)
                        : getString(R.string.video_play_ui_record_prompt_action);
                mVideoPromptBanner.show(path, snapshotMediaFileTemp.getType() == MediaFiles.TYPE.VIDEO, new Runnable() {
                    @Override
                    public void run() {
                        if (snapshotMediaFileTemp.getType() == MediaFiles.TYPE.IMAGE) {
                            Intent intent = new Intent(Utils.getContext(), ViewPagerActivity.class);
                            intent.putExtra("camera", mCamera);
                            intent.putExtra("mediaid", snapshotMediaFileTemp.getId());
                            intent.putExtra("shareType", SocialShareType.TYPE_MY_CAMERA);
                            startActivityForResult(intent, 200);
                            isCheckPhoto = true;
                        } else {
                            Utils.openVideo(VideoPlayActivity.this, snapshotMediaFileTemp.getPath());
                        }
                    }
                }, title, actionText, new Runnable() {
                    @Override
                    public void run() {
                        if (snapshotMediaFileTemp.getType() == MediaFiles.TYPE.IMAGE) {
                            if (snapshotMediaFileTemp != null) {
                                if (!isFilterPending) {
                                    managerMuteShowActivity();
                                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
                                    /* ShareImageActivity.startActivityForResult(VideoPlayActivity.this, 300,
                                            wrapPublicCameraObj(),
                                            snapshotMediaFileTemp.getPath(), SocialShareType.TYPE_MY_CAMERA,
                                            dateFormat.format(System.currentTimeMillis()));*/
                                    isFilterPending = true;
                                }
                            }
                        } else {
                            Utils.openVideo(VideoPlayActivity.this, snapshotMediaFileTemp.getPath());
                        }
                    }
                });
            }
        }
    }

    public void UpdateQualityMode(final int resolution) {
        runOnUiThread(new Runnable() {
            public void run() {
                if (mRealTimeManager == null || mResolutionBtn == null) {
                    return;
                }
                //                if (!mRealTimeManager.getIsNewFirmware()) {
                //                    mMQBtn.setVisibility(View.GONE);
                //                    mQualityPopup.getContentView().findViewById(R.id.mid_quality_sp_view)
                //                            .setVisibility(View.GONE);
                //                } else {
                //                    mMQBtn.setVisibility(View.VISIBLE);
                //                    mQualityPopup.getContentView().findViewById(R.id.mid_quality_sp_view)
                //                            .setVisibility(View.VISIBLE);
                //                }
                //                mHQBtn.setSelected(resolution == APlayManager.ResoDefine.RESO_HD);
                //                mMQBtn.setSelected(resolution == APlayManager.ResoDefine.RESO_MID);
                //                mLQBtn.setSelected(resolution == APlayManager.ResoDefine.RESO_VGA);

                String tipToast = "";
                switch (resolution) {
                    case APlayManager.ResoDefine.RESO_HD:
                        tipToast = getString(R.string.resolution_done) + getString(R.string.video_quality_clear_mode);
                        //                        mQualityBtn.setMode(0);
                        mResolutionBtn.setBackgroundResource(R.drawable.video_resolution_hd_btn);
                        break;
                    case APlayManager.ResoDefine.RESO_MID:
                        tipToast = getString(R.string.resolution_done) + getString(R.string.video_quality_mid_mode);
                        //                        mQualityBtn.setMode(1);
                        mResolutionBtn.setBackgroundResource(R.drawable.video_resolution_mid_btn);
                        break;
                    case APlayManager.ResoDefine.RESO_VGA:
                        tipToast = getString(R.string.resolution_done) + getString(R.string.video_quality_fluent_mode);
                        //                        mQualityBtn.setMode(2);
                        mResolutionBtn.setBackgroundResource(R.drawable.video_resolution_vga_btn);
                        break;
                }

                if (mRealTimeManager.getIsFirstReso()) {
                    mRealTimeManager.setIsFirstReso(false);
                } else {
                    mVideoPromptBanner.show(tipToast);
                }
            }
        });
        CLog.d("UpdateQualityMode......");
    }

    public void UpdateStreamFlow(final int download, final int vfps) {
        runOnUiThread(new Runnable() {
            public void run() {
                String data;
                if (download < 1024) {
                    data = download + "K";
                } else {
                    float num = (float) download / 1024;
                    data = String.format("%.2f", num) + "M";
                }

                //                if (mLatticeView != null) {
                //                    mLatticeView.setProgress(vfps, data);
                //                }
                if (mStreamText != null) {
                    mStreamText.setText(data);
                }
                mStreamTextWithSafeShieldView.setText(data);
            }
        });
    }

    public void UpdatePlayTime(final long timestamp) {
        runOnUiThread(new Runnable() {
            @SuppressLint("SimpleDateFormat")
            public void run() {
                Long time = Long.valueOf(timestamp);
                String date = format.format(time);
                if (mVideoTimeText != null) {
                    mVideoTimeText.setText(date);
                }
                //                if (mOldVideoTimeText != null) {
                //                    mOldVideoTimeText.setText(date);
                //                }
            }
        });
    }

    private Animation mRecordAni_Alpha;

    public void UpdateRecordStatus(final boolean isopen, final String msg, final MediaFiles mediaFile) {
        runOnUiThread(new Runnable() {
            public void run() {
                updateOptionBtnEnable();

                if (isVideoPlay()) {
                    //                    mRecordBtn.setEnabled(true);
                    updateRecordBtn();
                    //                    if (mSoundPlayView != null) {
                    //                        mSoundPlayView.mRecordBtn.setEnabled(true);
                    //                        mSoundPlayView.mRecordBtn.setMode(isopen ? 1 : 0);
                    //                    }
                    if (mRealTimeManager.getIsRecord()) {
                        //                        mQualityBtn.setEnabled(false);
                        //                        mResolutionBtn.setEnable(false);
                        //                        if (mSDRecordBtn != null) {
                        //                            mSDRecordBtn.setEnabled(false);
                        //                        }
                    } else {
                        if (mediaFile != null) {
                            long id = Utils.getMediaID(mediaFile.getPath(), 1);
                            String content = MediaStore.Video.Media.EXTERNAL_CONTENT_URI.toString() + File.separator
                                    + id;
                            snapshotMediaFileTemp = mediaFile;
                            setSnapshotThumbnail();
                        }
                        //                        mQualityBtn.setEnabled(true);
                        //                        mResolutionBtn.setEnable(true);
                        //                        if (mSDRecordBtn != null) {
                        //                            mSDRecordBtn.setEnabled(true);
                        //                        }
                    }
                    String withMsg = TextUtils.equals(msg,
                            Utils.getContext().getString(R.string.notice_video_record_invalid)) ? msg : null;
                    setRecordStatus(isopen, withMsg);
                }
            }
        });
    }

    public void UpdateRecordTime(long time) {
        if (mRealTimeManager != null && mRealTimeManager.getIsRecord() && time > 0) {
            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
            timeFormat.setTimeZone(TimeZone.getTimeZone("GMT00:00:00"));
            Long timeLong = Long.valueOf(time);
            final String timeStr = timeFormat.format(timeLong);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    mRecordTimeText.setText(timeStr);
                }
            });
        }
    }

    public void setRecordStatus(boolean isOpen, String closeWithMsg) {
        if (mRecordAni_Alpha == null) {
            mRecordAni_Alpha = new AlphaAnimation(1.0f, 0.0f);
            mRecordAni_Alpha.setDuration(1000);
            mRecordAni_Alpha.setRepeatCount(Animation.INFINITE);
            mRecordAni_Alpha.setRepeatMode(Animation.REVERSE);
        }

        mMainHandler.removeCallbacks(mRecordTimeHideRunnable);
        if (isOpen) {
            mRecordTimeLayout.setVisibility(View.VISIBLE);
            mRecordIcon.setVisibility(View.VISIBLE);
            mRecordTimeText.setText("00:00:00");
        } else {
            mRecordAni_Alpha.cancel();
            if (TextUtils.isEmpty(closeWithMsg)) {
                mRecordIcon.setVisibility(View.VISIBLE);
                mRecordTimeText.setText("00:00:00");
                mRecordTimeLayout.setVisibility(View.INVISIBLE);
            } else {
                mRecordTimeLayout.setVisibility(View.VISIBLE);
                mRecordIcon.setVisibility(View.GONE);
                mRecordTimeText.setText(closeWithMsg);
                mMainHandler.postDelayed(mRecordTimeHideRunnable, 3 * 1000);
            }
        }
    }

    private Runnable mRecordTimeHideRunnable = new Runnable() {
        @Override
        public void run() {
            mRecordTimeText.setText("00:00:00");
            mRecordTimeLayout.setVisibility(View.INVISIBLE);
        }
    };

    public void UpdateVolume(final float volume) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (isRecording) {
                    mVolumeBar.setProgress((int) volume);
                }
            }
        });
    }

    public void NotifyStreamBrake() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
//                mVideoPromptBanner.show(getString(R.string.video_brake_change_tip),
//                        getString(R.string.video_brake_change_tip), new Runnable() {
//                            @Override
//                            public void run() {
//                                //                        onChangeQuality(mLQBtn);
//                                mRealTimeManager.changeQuality(APlayManager.ResoDefine.RESO_VGA);
//                            }
//                        });
//                setStreamStatus();
                CameraToast.show(VideoPlayActivity.this, R.string.video_brake_change_tip, Toast.LENGTH_SHORT);
            }
        });
    }

    //endregion

    private void updateCameraListMenuLP() {
        View v = findViewById(R.id.filter_menu);
        if (v == null) {
            return;
        }

        float itemHeight = DensityUtil.dip2px(40);
        int itemsCount = (mTitleAdapter != null ? mTitleAdapter.getItemCount() : 0);
        int requestHeight = (int) (itemsCount * itemHeight + v.getPaddingTop() + v.getPaddingBottom());

        int screenHeight = SysConfig.BASE_SCREEN_HEIGHT;
        int screenW = SysConfig.BASE_SCREEN_WIDTH;
        if (SysConfig.BASE_SCREEN_HEIGHT < SysConfig.BASE_SCREEN_WIDTH) {
            screenHeight = SysConfig.BASE_SCREEN_WIDTH;
            screenW = SysConfig.BASE_SCREEN_HEIGHT;
        }
        int maxHeight;
        if (isPortrait()) {
            maxHeight = screenHeight - Utils.convertDpToPixel(45 + 107) - DensityUtil.getStatusHeight(this);
        } else {
            maxHeight = screenW - Utils.convertDpToPixel(90);
        }

        mCameraList.measure(MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED),
                MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED));

        ViewGroup.LayoutParams lp = v.getLayoutParams();
        lp.height = Math.min(maxHeight, requestHeight);
        v.requestLayout();
    }

    //region handleCamera

    private Object handleCamera(int actionCode, Object... args) {
        /*switch (actionCode) {
            case Actions.Camera.LOCAL_CACHE: {
                CameraList cameraList = (CameraList) args[0];
                // sort坑爹呀
                int size = cameraList.cameras.size();
                Camera[] listArray = cameraList.cameras.toArray(new Camera[size]);
        
                if (listArray.length > 1) {
                    //mTitleAdapter = new ArrayAdapter<Camera>(this, R.layout.camera_spinner_item, listArray);
                    mTitleAdapter = new TitleHeadListAdapter(this);
                    mTitleAdapter.setmCurrtSn(mCamera.getSN());
                    mTitleAdapter.setData(cameraList.cameras);
                    for (int i = 0; i < mTitleAdapter.getItemCount(); i++) {
                        if (mCamera.getSN().equals(mTitleAdapter.getItem(i).getSN())) {
                            mCamera = mTitleAdapter.getItem(i);
                            break;
                        }
                    }
        
                    setCameraSpinner();
                }
            }
            return Boolean.TRUE;
        }*/
        return Actions.ACTION_NOT_PROCESSED;
    }

    private void playTo(int chang) {
        if (mTitleAdapter != null) {
            int index = mTitleAdapter.getPosition(mCamera);
            int toIndex = index + chang;
            if (toIndex < 0) {
                mVideoPromptBanner.show(R.string.my_video_play_swipe_change_is_first);
                return;
            } else if (toIndex > mTitleAdapter.getItemCount() - 1) {
                mVideoPromptBanner.show(R.string.my_video_play_swipe_change_is_last);
                return;
            }
            playIndex(toIndex);
            //AccUtil.getInstance().mRtickNoSn.addStat(Stat.CAMERA_SWITCHED_LANDSPACE, 1);
        }
    }

    private void playIndex(int index) {
        Camera camera = mTitleAdapter.getItem(index);
        playNew(camera);
    }

    private void playNew(Camera camera) {
        if (!camera.getSN().equals(mCamera.getSN())) {

            Preferences.setVideoScale(mCamera.getSN(), mTextureView.getScale());

            if (mRealTimeManager != null) {
                mRealTimeManager.stopPlayNow();
            }
            mPendingShowPlayNewWhenChangeCamera = true;
            mCamera = camera;
            if (mVideoTimeText != null) {
                mVideoTimeText.setVisibility(mCamera.getSupportObj().withTimeShowInStream() ? View.GONE : View.VISIBLE);
            }
            //            buildJP2PInfo();
            mSn = mCamera.sn;
            mCurrentNightMode = -1;
            setMicState();
            mAudioTalkBtn.resetAlreadyInit();
            mAudioTalkBtn.restoreLast(mCamera.sn);
            mAudioTalkBtn.getOnChangeStateListener().onChange(Preferences.getIsMic(mCamera.sn));
            manageCamera();
            startVideo();
            onCameraChange();
            if (isPortrait()) {
                //AccUtil.getInstance().rtick.addStat(mRealTimeManager.mCameraSN, Stat.VIDEO_SWITCH_CAMERA_PORTRAIT);
            } else {
                //AccUtil.getInstance().rtick.addStat(mRealTimeManager.mCameraSN, Stat.VIDEO_SWITCH_CAMERA_LAND);
            }
        }
    }

    private void onCameraChange() {
        if (mSoundPlayView != null && isS) {
            mSoundPlayView.animatorOut(0);
            isS = false;
        }
        if (mRealTimeManager != null && mRealTimeManager.getIsRecord()) {
            clickRecord();
        }
        restoreVideoPrefer();
    }

    private void manageScreenTouch(final View view) {
        view.setLongClickable(true);
        view.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                return mDetector.onTouchEvent(motionEvent);
            }
        });
    }

    private void closeStream(){
        savePreference();
        isBackFinish = true;
        mOrientationListener.disable();
        mNoStreamView.setVisibility(View.VISIBLE);
        if (isVideoPlay()) {
            mNoStreamView.setImageDrawable(null);
        }
        mNoStreamView.setBackgroundResource(R.color.black);
        if (mRealTimeManager.getPlayType() == APlayManager.PlayTypes.RealMine
                || mRealTimeManager.getPlayType() == APlayManager.PlayTypes.RealDemo
                || mRealTimeManager.getPlayType() == APlayManager.PlayTypes.RealShare) {
            mRealTimeManager.setMute(true);
            mRealTimeManager.snapShot(APlayManager.SnapShotTypes.Stop);
        }
        mTextureView.setVisibility(View.INVISIBLE);
        stopVideo();
        mRealTimeManager.stopStream();
        VideoPlayActivity.this.finish();
    }

    //endregion

    //endregion
}
