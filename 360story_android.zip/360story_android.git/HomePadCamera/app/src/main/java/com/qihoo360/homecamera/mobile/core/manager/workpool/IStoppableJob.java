
package com.qihoo360.homecamera.mobile.core.manager.workpool;

public interface IStoppableJob<T> {
    T doJob();

    void stop();

    boolean isStopped();
}
