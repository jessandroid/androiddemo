
package com.qihoo360.homecamera.machine.fragment;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qihoo.sdk.report.QHStatAgent;
import com.qihoo360.homecamera.device.config.StoryMachineConsts;
import com.qihoo360.homecamera.machine.business.JsonManager;
import com.qihoo360.homecamera.machine.business.PlayConfig;
import com.qihoo360.homecamera.machine.business.SettingTask;
import com.qihoo360.homecamera.machine.business.TaskExecutor;
import com.qihoo360.homecamera.machine.entity.MachineDeviceInfo;
import com.qihoo360.homecamera.machine.manager.MachinePlayInfoManager;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.db.CommonWrapper;
import com.qihoo360.homecamera.mobile.entity.DeviceInfo;
import com.qihoo360.homecamera.mobile.entity.SpaceInfoList;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.ui.fragment.BaseFragment;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.Preferences;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.ref.WeakReference;

import butterknife.Bind;
import butterknife.ButterKnife;
import rx.Single;
import rx.SingleSubscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

public class AboutMachineFragment extends BaseFragment implements ActionListener {

    private static AboutMachineFragment doubanmeifragment;
    private DeviceInfo devInfo;
    private RelativeLayout rlMachineStorage;
    private ImageView ivMachineBg;
    private View line;
    public String device_type;
    private View mView;

    @Bind(R.id.tv_machine_model)
    TextView tv_machine_model;//故事机型号

    @Bind(R.id.tv_machine_wifi)
    TextView tv_machine_wifi;//故事机wifi

    @Bind(R.id.tv_machine_wifi_strength)
    TextView tv_machine_wifi_strength;//wifi信号强度

    @Bind(R.id.tv_machine_serial_number)
    TextView tv_machine_serial_number; //序列号

    @Bind(R.id.tv_machine_ip)
    TextView tv_machine_ip;//IP

    @Bind(R.id.tv_machine_mac)
    TextView tv_machine_mac;//MAC

    @Bind(R.id.tv_machine_storage)
    TextView tv_machine_storage;//存储空间

    @Bind(R.id.tv_machine_battery_level)
    TextView tv_machine_battery_level;//电池电量

    @Bind(R.id.tv_machine_system_version)
    TextView tv_machine_system_version;//系统版本号

    public AboutMachineFragment() {
        super();
    }

    private SpaceInfoList mSpaceInfoList;

    public static AboutMachineFragment getInstance(DeviceInfo deviceInfo) {
        doubanmeifragment = new AboutMachineFragment();
        Bundle args = new Bundle();
        args.putParcelable(DeviceInfo.class.getSimpleName(), deviceInfo);
        doubanmeifragment.setArguments(args);
        return doubanmeifragment;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MachinePlayInfoManager.getInstance().registerActionListener(this);
        GlobalManager.getInstance().getUserInfoManager().registerActionListener(this);
        if (getArguments() != null) {
            devInfo = getArguments().getParcelable(DeviceInfo.class.getSimpleName());
            device_type = devInfo.deviceType;
//            device_type = StoryMachineConsts.VALUE_SET_MACHINE_TYPE_605;
            if(devInfo!=null){
                return;
            }
        }

    }

    @Override
    public void onDetach() {
        super.onDetach();
        MachinePlayInfoManager.getInstance().removeActionListener(this);
        GlobalManager.getInstance().getUserInfoManager().registerActionListener(this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.fragment_machine_about, container, false);
        ButterKnife.bind(this, mView);

        /**
         * 设备为605时，将"云存储空间"隐藏
         * 设备为603时，将"云存储空间"显示
         */
        rlMachineStorage = (RelativeLayout) mView.findViewById(R.id.rl_machine_storage);
        line = mView.findViewById(R.id.v_line);
        ivMachineBg = (ImageView) mView.findViewById(R.id.iv_machine_bg);
        if (device_type != null && device_type.equals(StoryMachineConsts.VALUE_SET_MACHINE_TYPE_605)) {
            rlMachineStorage.setVisibility(View.GONE);
            line.setVisibility(View.GONE);
            ivMachineBg.setBackgroundResource(R.drawable.two_machine_bg_605);
        } else if (device_type != null && device_type.equals(StoryMachineConsts.VALUE_SET_MACHINE_TYPE_603)) {
            rlMachineStorage.setVisibility(View.VISIBLE);
            line.setVisibility(View.VISIBLE);
            ivMachineBg.setBackgroundResource(R.drawable.two_machine_bg);
        } else{
            ivMachineBg.setBackgroundResource(R.drawable.two_machine_bg);
        }

        return mView;
    }

    @Override
    public boolean onTabSwitched() {
        return false;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if(!TextUtils.isEmpty(Preferences.getSpace(devInfo.getSn()))){
            tv_machine_storage.setText(Preferences.getSpace(devInfo.getSn()));
        }

        //先加载数据库的信息
        Single.create(new Single.OnSubscribe<MachineDeviceInfo>() {
            @Override
            public void call(SingleSubscriber<? super MachineDeviceInfo> singleSubscriber) {
                try {
                    MachineDeviceInfo deviceInfo = CommonWrapper.getInstance(getActivity()).getLocalToClazz(devInfo.getSn(), CommonWrapper.TYPE_MACHINE_DEVICE_INFO, MachineDeviceInfo.class);
                    singleSubscriber.onSuccess(deviceInfo);
                } catch (java.lang.InstantiationException e) {
                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        }).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Action1<MachineDeviceInfo>() {
                    @Override
                    public void call(MachineDeviceInfo deviceInfo) {
                        if(deviceInfo!=null){
                            updateInfo(deviceInfo);
                        }
                    }
                });

        GlobalManager.getInstance().getUserInfoManager().asyncGetSpaceInfo(devInfo.getSn());
        doGetDeviceInfo();
    }

    @Override
    public void dump(String prefix, FileDescriptor fd, PrintWriter writer, String[] args) {
        super.dump(prefix, fd, writer, args);
    }

    @Override
    public Object actionPerformed(int actionCode, Object... args) {
        switch (actionCode) {
            case Actions.MachinePlayInfo.NOTIFY_MACHINE_DEVICE_INFO:{
                String sn = (String)args[1];
                String from = (String)args[2];
                if(TextUtils.equals(sn, devInfo.getSn()) && TextUtils.equals(from, PlayConfig.CmdFrom.MACHINEINFOPAGE)){
                    MachineDeviceInfo info = (MachineDeviceInfo)args[0];
                    if(info!=null){
                        updateInfo(info);
                    }
                }
                return Boolean.TRUE;
            }

            case Actions.UserInfo.GET_SPACE_INFO_SUCCESS: {
                mSpaceInfoList = (SpaceInfoList) args[0];
                if (mSpaceInfoList != null) {
                    for (int i = 0; i < mSpaceInfoList.data.size(); i++) {
                        SpaceInfoList.SpaceInfo spaceInfo = mSpaceInfoList.data.get(i);
                        if (SpaceInfoList.SpaceInfo.SPACE_INFO_TOTAL.equalsIgnoreCase(spaceInfo.stype)) {
                            String spaceString = String.format(getString(R.string.story_machine_storage_value), Utils.formatSize(Constants.TotalDiscSpace), Utils.formatSize(Constants.TotalDiscSpace - spaceInfo.used / 1024));
                            tv_machine_storage.setText(spaceString);
                            Preferences.setSpace(devInfo.getSn(), spaceString);
                            break;
                        }
                    }
                }
                return Boolean.TRUE;
            }

            case Actions.UserInfo.GET_SPACE_INFO_FAIL: {
                return Boolean.TRUE;
            }
        }
        return null;
    }

    @Override
    public int getProperty() {
        return 0;
    }

    private void updateInfo(MachineDeviceInfo info){
        if(info.deviceInfo!=null){
            tv_machine_model.setText(info.deviceInfo.getModel());
            tv_machine_wifi.setText(info.deviceInfo.getWifiSsid());
            tv_machine_wifi_strength.setText(info.deviceInfo.getWifiSignal()+"%");
            tv_machine_serial_number.setText(info.deviceInfo.getSerialno());
            tv_machine_ip.setText(info.deviceInfo.getIp());
            tv_machine_mac.setText(info.deviceInfo.getMac());
            tv_machine_system_version.setText(info.deviceInfo.getSystemVersion());
            if (info.deviceInfo.getBatteryLevel() != null){
                tv_machine_battery_level.setText(info.deviceInfo.getBatteryLevel()+"%");
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        QHStatAgent.onPageEnd(getActivity(), "AboutPadFragment");
        CLog.i("yanggang", "AboutPadFragment onPageEnd");
        super.onPause();
    }

    private void doGetDeviceInfo(){
        TaskExecutor.Execute(new SettingTask(getActivity(), devInfo.getSn(), PlayConfig.CommandType.GETDEVICEINFO, JsonManager.getPlayStatusContent(), new MyHandler(this), PlayConfig.CmdFrom.MACHINEINFOPAGE));
    }

    //指令失败异常处理
    static class MyHandler extends Handler {

        WeakReference<AboutMachineFragment> aboutMachineFragmentWeakReference;

        MyHandler(AboutMachineFragment aboutMachineFragment) {
            aboutMachineFragmentWeakReference = new WeakReference<>(aboutMachineFragment);
        }

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if(aboutMachineFragmentWeakReference.get()!=null){
                aboutMachineFragmentWeakReference.get().handlerCmdExcept((String)msg.obj);
            }
        }
    }

    private void handlerCmdExcept(String cmd){

        if(TextUtils.equals(cmd, PlayConfig.CommandType.GETDEVICEINFO)){
            //TODO 获取故事机信息失败,不用处理
        }
    }

}
