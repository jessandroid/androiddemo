package com.qihoo360.homecamera.machine.ui.adapter;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;
import android.os.Handler;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.jakewharton.rxbinding.view.RxView;
import com.qihoo360.homecamera.machine.activity.MachineAlbumActivity;
import com.qihoo360.homecamera.machine.business.PlayConfig;
import com.qihoo360.homecamera.machine.entity.MachineSong;
import com.qihoo360.homecamera.machine.entity.SongEntity;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.db.MachineSongWrapper;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.Preferences;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.TimeUnit;

import rx.Observable;
import rx.Observer;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action0;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

/**
 * Created by zhangtao-iri on 2016/10/31.
 */
public class SongListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{

    private int currentListType;

    private String playUniqueId;

    private int playType;

    private ItemClickListener mItemListener;

    private CopyOnWriteArrayList<SongEntity> mSongList; //儿歌列表

    private Context mContext;

    public SongListAdapter(int listType, ItemClickListener listener, Context context){
        this.currentListType = listType;
        this.mItemListener = listener;
        mSongList = new CopyOnWriteArrayList<>();
        this.mContext = context;
    }

    //设置数据
    public void setData(CopyOnWriteArrayList<SongEntity> songList) {
        this.mSongList = songList;
        notifyDataSetChanged();
    }

    public void setSelectSong(String uniqueId, int type){
        playUniqueId = uniqueId;
        playType = type;
        notifyDataSetChanged();
    }

    public SongEntity getItem(int p){
        return (mSongList.size() > p) ? mSongList.get(p) : null;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.common_list_item, parent, false);
        return new MyViewHold(view);
    }

    @Override
    public long getItemId(int position) {
        return super.getItemId(position);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {

        if(holder instanceof MyViewHold){
            // 歌曲信息
            final SongEntity song = mSongList.get(position);
            final MyViewHold myHold = (MyViewHold)holder;
            myHold.sName.setText(song.getTitle());

            if(!TextUtils.isEmpty(playUniqueId)){
                myHold.playIcon.setVisibility((TextUtils.equals(playUniqueId, song.getUniqueid()) && (playType==song.type)) ? View.VISIBLE : View.GONE);
                myHold.sortNum.setVisibility((TextUtils.equals(playUniqueId, song.getUniqueid()) && (playType==song.type)) ? View.GONE : View.VISIBLE);
                myHold.sName.setTextColor((TextUtils.equals(playUniqueId, song.getUniqueid()) && (playType==song.type)) ? Color.parseColor("#FF495C") : Color.parseColor("#4d4d4d"));
                if(myHold.playIcon.getVisibility() == View.VISIBLE){
                    final AnimationDrawable ad = (AnimationDrawable) myHold.playIcon.getBackground();
                    if(!ad.isRunning()){
                        mHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                ad.start();
                            }
                        });
                    }
                } else {
                    final AnimationDrawable ad = (AnimationDrawable) myHold.playIcon.getBackground();
                    mHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            ad.selectDrawable(0);
                            ad.stop();
                        }
                    });

                }
            }else{
                myHold.sortNum.setVisibility(View.VISIBLE);
                myHold.playIcon.setVisibility(View.GONE);
                myHold.sName.setTextColor(Color.parseColor("#4d4d4d"));
                final AnimationDrawable ad = (AnimationDrawable) myHold.playIcon.getBackground();
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        ad.selectDrawable(0);
                        ad.stop();
                    }
                });

            }

            if(myHold.sortNum.getVisibility() == View.VISIBLE){
                myHold.sortNum.setText(String.valueOf(position+1));
            }

            //收藏状态
            if (currentListType == MachineAlbumActivity.FAVORLIST){
                myHold.heartIcon.setImageResource(song.isFavor ? R.drawable.delete : R.drawable.heart_gray);
            }else{
                myHold.heartIcon.setImageResource(song.isFavor ? R.drawable.heart_red : R.drawable.heart_gray);

            }

            //播放动作
            RxView.clicks(myHold.itemView).throttleFirst(300, TimeUnit.MILLISECONDS).subscribe(new Action1<Void>() {
                @Override
                public void call(Void aVoid) {
                    if(!Utils.isNetworkAvailable(mContext)){
                        CameraToast.show(null, R.string.network_disabled, Toast.LENGTH_SHORT);
                        return;
                    }
                    if(mItemListener != null) {
                        mItemListener.click(position);
                    }
                }
            });

            RxView.clicks(myHold.playButton).throttleFirst(300, TimeUnit.MILLISECONDS).subscribe(new Action1<Void>() {
                @Override
                public void call(Void aVoid) {
                    if(!Utils.isNetworkAvailable(mContext)){
                        CameraToast.show(null, R.string.network_disabled, Toast.LENGTH_SHORT);
                        return;
                    }
                    if(mItemListener != null) {
                        mItemListener.click(position);
                    }
                }
            });

            //收藏动作
            RxView.clicks(myHold.heartIcon).throttleFirst(300, TimeUnit.MILLISECONDS).subscribe(new Action1<Void>() {
                @Override
                public void call(Void aVoid) {
                    Observable.create(new Observable.OnSubscribe<Boolean>() {
                        @Override
                        public void call(Subscriber<? super Boolean> subscriber) {
                            subscriber.onNext(MachineSongWrapper.getInstance().isSongFavor(Preferences.getSelectedPad(), song.getUniqueid()));
                            subscriber.onCompleted();
                        }
                    }).subscribeOn(Schedulers.io())
                      .observeOn(AndroidSchedulers.mainThread()).subscribe(new Action1<Boolean>() {
                        @Override
                        public void call(Boolean aBoolean) {
                            if(!Utils.isNetworkAvailable(mContext)){
                                CameraToast.show(null, R.string.network_disabled, Toast.LENGTH_SHORT);
                                return;
                            }
                            mItemListener.doFavor(!aBoolean, position);
                            if (currentListType == MachineAlbumActivity.FAVORLIST) {
                                myHold.heartIcon.setImageResource(song.isFavor ? R.drawable.delete : R.drawable.heart_gray);
                            }else{
                                myHold.heartIcon.setImageResource(!aBoolean ? R.drawable.heart_red : R.drawable.heart_gray);
                            }

                        }
                    });
                }
            });

        }
    }

    @Override
    public int getItemViewType(int position) {
        return super.getItemViewType(position);
    }

    @Override
    public int getItemCount() {
        return mSongList!=null ? mSongList.size() : 0;
    }

    public class MyViewHold extends RecyclerView.ViewHolder{

        public TextView sortNum;
        public ImageView playIcon;
        public TextView sName;
        public ImageView heartIcon;
        public ImageView playButton;

        public MyViewHold(View itemView) {
            super(itemView);
            sortNum = (TextView) itemView.findViewById(R.id.sort_num);
            playIcon = (ImageView) itemView.findViewById(R.id.playing_icon);
            sName = (TextView) itemView.findViewById(R.id.title_name);
            heartIcon = (ImageView) itemView.findViewById(R.id.heart_icon);
            playButton = (ImageView) itemView.findViewById(R.id.play_icon);
        }
    }

    public interface ItemClickListener {
        void click(int pos);
        void doFavor(boolean isFavor, int pos);
    }

    private Handler mHandler = new Handler();
}
