package com.qihoo360.homecamera.mobile.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

import com.qihoo360.homecamera.mobile.entity.PhoneRecord;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.util.ArrayList;

/**
 * Created by zhaojunbo on 2016/4/29.
 * desc:
 */
public class PhoneRecordWrapper extends AbstractWrapper {

    public static final String TABLE_NAME = "phone_record";
    private volatile  static PhoneRecordWrapper mInstance;
    @SuppressWarnings("unused")
    private Context mContext;

    public static PhoneRecordWrapper getInstance(Context context) {
        if (mInstance == null) {
            synchronized (PhoneRecordWrapper.class) {
                if (mInstance == null) {
                    mInstance = new PhoneRecordWrapper(context.getApplicationContext());
                }
            }
        }
        return mInstance;
    }

    public static void destroyPhoneRecordWrapper() {
        if (mInstance != null) {
            mInstance = null;
        }
    }

    private PhoneRecordWrapper(Context context) {
        this.mContext = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int toVersion) {

    }

    @Override
    public void onOpen(SQLiteDatabase db) {

    }

    @Override
    public void execSQL(SQLiteDatabase db, String sql) {
        super.execSQL(db, sql);
    }

    @Override
    public void execSQL(SQLiteDatabase db, String sql, String[] bindArgs) {
        super.execSQL(db, sql, bindArgs);
    }

    @Override
    public void dropTable(SQLiteDatabase db, String tableName) {
        super.dropTable(db, tableName);
    }

    @Override
    public void renameTable(SQLiteDatabase db, String tableName, String newTableName) {
        super.renameTable(db, tableName, newTableName);
    }

    public synchronized boolean insertPhoneRecord(String sn, String qid, long start_call_time, long start_connect_time, long end_time, int is_accept, int is_outgoing) {
        long effectCount = 0;
        SQLiteDatabase db = GlobalManager.getInstance().config().db.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(Field.SN, sn);
        values.put(Field.QID, qid);
        values.put(Field.START_CALL_TIME, start_call_time);
        values.put(Field.START_CONNECT_TIME, start_connect_time);
        values.put(Field.END_TIME, end_time);
        values.put(Field.INITIATIVE_TERMED, is_accept);
        values.put(Field.IS_OUT_GOING, is_outgoing);
        effectCount = db.insert(TABLE_NAME, null, values);
        return effectCount != 0;
    }

    public long getCallTime(String sn) {
        long time = 0;
        SQLiteDatabase db = GlobalManager.getInstance().config().db.getWritableDatabase();
        StringBuffer sb = new StringBuffer("");
        sb.append("select sum(end_time - start_connect_time) from ");
        sb.append(TABLE_NAME);
        sb.append(" where start_connect_time <> -1 and sn='" + sn + "'");
        try {
            SQLiteStatement statement = db.compileStatement(sb.toString());
            time = statement.simpleQueryForLong();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }
        return time;
    }

    public ArrayList<PhoneRecord> getAllPhoneRecordBySn(String sn) {
        SQLiteDatabase db = GlobalManager.getInstance().config().db.getReadableDatabase();
        ArrayList<PhoneRecord> phoneRecordList = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = db.query(TABLE_NAME, null, "sn = ? order by _id desc", new String[]{sn}, null, null, null);
            while (cursor.moveToNext()) {
                PhoneRecord phoneRecord = new PhoneRecord();
                phoneRecord.ID = cursor.getString(cursor.getColumnIndex(Field.ID));
                phoneRecord.SN = cursor.getString(cursor.getColumnIndex(Field.SN));
                phoneRecord.QID = cursor.getString(cursor.getColumnIndex(Field.QID));
                phoneRecord.START_CALL_TIME = cursor.getString(cursor.getColumnIndex(Field.START_CALL_TIME));
                phoneRecord.START_CONNECT_TIME = cursor.getString(cursor.getColumnIndex(Field.START_CONNECT_TIME));
                phoneRecord.END_TIME = cursor.getString(cursor.getColumnIndex(Field.END_TIME));
                phoneRecord.INITIATIVE_TERMED = cursor.getString(cursor.getColumnIndex(Field.INITIATIVE_TERMED));
                phoneRecord.IS_OUT_GOING = cursor.getString(cursor.getColumnIndex(Field.IS_OUT_GOING));
                phoneRecord.IS_PROEDSSED = cursor.getString(cursor.getColumnIndex(Field.IS_PROCESSED));
                phoneRecordList.add(phoneRecord);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return phoneRecordList;
    }

    public ArrayList<PhoneRecord> getAllNotProcessedwPhoneRecordBySn(String sn) {
        SQLiteDatabase db = GlobalManager.getInstance().config().db.getReadableDatabase();
        ArrayList<PhoneRecord> phoneRecordList = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = db.query(TABLE_NAME, null, "sn = ? and is_processed = 0 and is_outgoing = 0 and start_connect_time = -1 and initiative_termed = 0 order by _id desc", new String[]{sn}, null, null, null);
            while (cursor.moveToNext()) {
                PhoneRecord phoneRecord = new PhoneRecord();
                phoneRecord.ID = cursor.getString(cursor.getColumnIndex(Field.ID));
                phoneRecord.SN = cursor.getString(cursor.getColumnIndex(Field.SN));
                phoneRecord.QID = cursor.getString(cursor.getColumnIndex(Field.QID));
                phoneRecord.START_CALL_TIME = cursor.getString(cursor.getColumnIndex(Field.START_CALL_TIME));
                phoneRecord.START_CONNECT_TIME = cursor.getString(cursor.getColumnIndex(Field.START_CONNECT_TIME));
                phoneRecord.END_TIME = cursor.getString(cursor.getColumnIndex(Field.END_TIME));
                phoneRecord.INITIATIVE_TERMED = cursor.getString(cursor.getColumnIndex(Field.INITIATIVE_TERMED));
                phoneRecord.IS_OUT_GOING = cursor.getString(cursor.getColumnIndex(Field.IS_OUT_GOING));
                phoneRecord.IS_PROEDSSED = cursor.getString(cursor.getColumnIndex(Field.IS_PROCESSED));
                phoneRecordList.add(phoneRecord);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return phoneRecordList;
    }

    public ArrayList<String> getAllNotProcessedPhoneRecord() {
        SQLiteDatabase db = GlobalManager.getInstance().config().db.getReadableDatabase();
        ArrayList<String> snList = new ArrayList<>();
        Cursor cursor = null;
        try {
            cursor = db.query(TABLE_NAME, null, "is_processed = 0 and is_outgoing = 0 and start_connect_time = -1 and initiative_termed = 0 order by _id asc", new String[]{}, null, null, null);
            while (cursor.moveToNext()) {
                snList.add(cursor.getString(cursor.getColumnIndex(Field.SN)));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            Utils.close(cursor);
        }
        return snList;
    }

    /**
     * 最近一次未查看未接来电
     * @param sn
     * @return
     */
    public PhoneRecord getLastPhoneRecordBySn(String sn) {
        SQLiteDatabase db = GlobalManager.getInstance().config().db.getReadableDatabase();
        PhoneRecord phoneRecord = new PhoneRecord();
        Cursor cursor = null;
        try {
            cursor = db.query(TABLE_NAME, null, "sn = ? and is_processed = 0 and is_outgoing = 0", new String[]{sn}, null, null, null);
            while (cursor.moveToNext()) {
                phoneRecord.ID = cursor.getString(cursor.getColumnIndex(Field.ID));
                phoneRecord.SN = cursor.getString(cursor.getColumnIndex(Field.SN));
                phoneRecord.QID = cursor.getString(cursor.getColumnIndex(Field.QID));
                phoneRecord.START_CALL_TIME = cursor.getString(cursor.getColumnIndex(Field.START_CALL_TIME));
                phoneRecord.START_CONNECT_TIME = cursor.getString(cursor.getColumnIndex(Field.START_CONNECT_TIME));
                phoneRecord.END_TIME = cursor.getString(cursor.getColumnIndex(Field.END_TIME));
                phoneRecord.INITIATIVE_TERMED = cursor.getString(cursor.getColumnIndex(Field.INITIATIVE_TERMED));
                phoneRecord.IS_OUT_GOING = cursor.getString(cursor.getColumnIndex(Field.IS_OUT_GOING));
                phoneRecord.IS_PROEDSSED = cursor.getString(cursor.getColumnIndex(Field.IS_PROCESSED));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return phoneRecord;
    }

    /**
     * 更新指定未接电话状态
     * @param sn
     * @return
     */
    public synchronized int updatePhoneRecordStateBySn(String sn) {
        SQLiteDatabase db = GlobalManager.getInstance().config().db.getReadableDatabase();
        int effectCount = 0;
        ContentValues values = new ContentValues();
        values.put("is_processed", 1);
        effectCount = db.update(TABLE_NAME, values, "sn=?", new String[]{
                sn
        });
        return effectCount;
    }

    /**
     * 更新全部未接电话状态
     * @return
     */
    public int updateAllPhoneRecordStateBySn() {
        SQLiteDatabase db = GlobalManager.getInstance().config().db.getReadableDatabase();
        int effectCount = 0;
        ContentValues values = new ContentValues();
        values.put("is_processed", 1);
        effectCount = db.update(TABLE_NAME, values, "", new String[]{});
        return effectCount;
    }

    public class Field {
        public static final String SN = "sn";
        public static final String QID = "qid";
        public static final String START_CALL_TIME = "start_call_time";
        public static final String START_CONNECT_TIME = "start_connect_time";
        public static final String END_TIME = "end_time";
        public static final String INITIATIVE_TERMED = "initiative_termed";
        public static final String IS_OUT_GOING = "is_outgoing";
        public static final String IS_PROCESSED = "is_processed";
        public static final String ID = "_id";
    }
}
