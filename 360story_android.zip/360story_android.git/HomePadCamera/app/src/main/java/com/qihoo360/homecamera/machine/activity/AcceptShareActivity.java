
package com.qihoo360.homecamera.machine.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.SysConfig;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.zbar.lib.CaptureActivity;
import com.qihoo360.homecamera.mobile.activity.BaseActivity;

public class AcceptShareActivity extends MachineBaseActivity implements View.OnClickListener{

    private ImageView bg;
    private Bitmap bmp;

    private LinearLayout mShareWordBt;

    @Override
    protected void onCreate(Bundle arg0) {
        super.onCreate(arg0);
        setTintManagerQWork(true);
        tintManager.setStatusBarTintColor(Color.parseColor("#0000aeff"));
        setContentView(R.layout.activity_accept_share);
        bg = (ImageView) findViewById(R.id.accept_bg);
        bg.setMaxWidth(SysConfig.BASE_SCREEN_WIDTH);
        bg.setMaxHeight(SysConfig.BASE_SCREEN_HEIGHT);
        bmp = Utils.getBitmap(R.drawable.bg_machine_add);
        bg.setImageBitmap(bmp);

        mShareWordBt = (LinearLayout) findViewById(R.id.ll_share_word);
        mShareWordBt.setOnClickListener(this);
    }

    @Override
    protected void onDestroy() {
        if (bmp != null) {
            bmp.recycle();
            bmp = null;
        }
        super.onDestroy();
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bt_share_scan:
                startActivity(new Intent(this, CaptureActivity.class));
                overridePendingTransition(0, 0);
                break;

            case R.id.ll_share_word:
                startActivity(new Intent(this, ShareWordActivity.class));
                overridePendingTransition(0, 0);
                break;

            default:
                break;
        }
    }
}
