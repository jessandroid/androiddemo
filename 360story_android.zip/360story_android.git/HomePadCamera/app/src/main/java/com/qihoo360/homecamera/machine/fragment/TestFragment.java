package com.qihoo360.homecamera.machine.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.ui.fragment.BaseFragment;

/**
 * Created by lixin3-s on 2016/11/8.
 */
public class TestFragment  extends BaseFragment {


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_machine_about, container, false);
        return view;
    }

    @Override
    public boolean onTabSwitched() {
        return false;
    }
}
