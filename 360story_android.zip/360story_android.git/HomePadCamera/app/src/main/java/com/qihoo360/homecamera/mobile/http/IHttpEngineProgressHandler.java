
package com.qihoo360.homecamera.mobile.http;


import org.apache.http.HttpEntityEnclosingRequest;
import org.apache.http.HttpResponse;

public interface IHttpEngineProgressHandler {

    void onRequest(HttpEntityEnclosingRequest request);

    void onServerResponse(HttpResponse response);

    void onProgress(long progress, long total) throws InterruptedException;

    void onError(int errorCode, String errorMessage);
}
