
package com.qihoo360.homecamera.machine.activity;

import android.content.ClipData;
import android.content.ClipDescription;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.ContentObserver;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.qihoo360.homecamera.machine.business.TaskExecutor;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.activity.BaseActivity;

import org.json.JSONObject;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by zhaojunbo on 2015/12/10.
 * desc:
 */
public class ShareWordActivity extends MachineBaseActivity implements View.OnClickListener {

    private static final int TASKGETSHAREINFO = 1;
    private static final int TASKACCEPTSHARE = 2;

    private ImageView mBackIv;
    private EditText mShareWordEt;
    private Button mShareWordOkBt;
    private SmsObserver mSmsObserver;
    private ClipboardManager mClipboardManager = null;
    private Uri SMS_INBOX = Uri.parse("content://sms/");
    private ClipboardManager.OnPrimaryClipChangedListener mOnPrimaryClipChangedListener;
    private String mShareWord;
    private String mSharerName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initView();

        mSmsObserver = new SmsObserver(this, smsHandler);
        getContentResolver().registerContentObserver(SMS_INBOX, true, mSmsObserver);
        mClipboardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);

    }

    private void initView() {
        setTintManagerQWork(true);
        tintManager.setStatusBarTintColor(Color.parseColor("#0000aeff"));
        setContentView(R.layout.activity_add_machine_share_word);
        mBackIv = (ImageView) findViewById(R.id.iv_back);
        mBackIv.setOnClickListener(this);
        mShareWordEt = (EditText) findViewById(R.id.et_share_word);
        mShareWordOkBt = (Button) findViewById(R.id.bt_share_word_ok);
        mShareWordOkBt.setOnClickListener(this);
    }

    private void initAndGetClipBoard() {
        ClipData.Item item = null;
        if (!mClipboardManager.hasPrimaryClip() && TextUtils.isEmpty(mShareWordEt.getText())) {
            showSoftInput();
            return;
        }
        if (mClipboardManager != null && mClipboardManager.getPrimaryClipDescription() != null) {
            if (mClipboardManager.getPrimaryClipDescription().hasMimeType(
                    ClipDescription.MIMETYPE_TEXT_PLAIN)) {
                ClipData cdText = mClipboardManager.getPrimaryClip();
                item = cdText.getItemAt(0);
                if (item.getText() != null) {
                    getPatternCode(item.getText().toString());

                    ClipData textCd = ClipData.newPlainText("", "");
                    mClipboardManager.setPrimaryClip(textCd);
                } else if (item.getText() == null && TextUtils.isEmpty(mShareWordEt.getText())) {
                    showSoftInput();
                }
            }
        }
    }

    private void showSoftInput() {
        mShareWordEt.setFocusable(true);
        mShareWordEt.setFocusableInTouchMode(true);
        mShareWordEt.requestFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.showSoftInput(mShareWordEt, InputMethodManager.SHOW_FORCED);
    }

    private void getPatternCode(String body) {
        String result = null;
        Pattern pattern = Pattern.compile("shareCode=([a-zA-Z0-9]{8})&|^([a-zA-Z0-9]{8})$", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(body);
        if (matcher.find()) {
            result = matcher.group(1);
            if (result == null) {
                result = matcher.group(2);
            }
        }
        if (result != null) {
            mShareWordEt.setText(result);
            mShareWordEt.setSelection(result.length());
        } else if (result == null && TextUtils.isEmpty(mShareWordEt.getText())) {
            showSoftInput();
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bt_share_word_ok:
                mShareWord = mShareWordEt.getText().toString();
                if (!TextUtils.isEmpty(mShareWord)) {
                    //TaskExecutor.Execute(new TaskGetShareInfo());
                }
                break;
            case R.id.iv_back:
                finish();
                break;
        }
    }

    // TODO 暂时注释
//    class TaskGetShareInfo implements Runnable {
//        @Override
//        public void run() {
//            handler.obtainMessage(Constants.TaskState.ISRUNING).sendToTarget();
//            try {
//                Message successMsg = handler.obtainMessage();
//                successMsg.what = Constants.TaskState.SUCCESS;
//                successMsg.arg1 = TASKGETSHAREINFO;
//                JSONObject params = new JSONObject();
//                params.put("shareCode", mShareWord);
//                CameraHttpApi cameraHttpApi = new CameraHttpApi();
//                ShareHostInfo response =
//                        cameraHttpApi.doCommonRequest(params, CameraHttpApi.URL_SHARE_GET_INFO,
//                                ShareHostInfo.class);
//                successMsg.obj = response;
//                handler.sendMessage(successMsg);
//
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }
//    }
//
//    class TaskAcceptShare implements Runnable {
//        @Override
//        public void run() {
//            handler.obtainMessage(Constants.TaskState.ISRUNING).sendToTarget();
//            try {
//                Message successMsg = handler.obtainMessage();
//                successMsg.what = Constants.TaskState.SUCCESS;
//                successMsg.arg1 = TASKACCEPTSHARE;
//                JSONObject params = new JSONObject();
//                params.put("shareCode", mShareWord);
//                CameraHttpApi cameraHttpApi = new CameraHttpApi();
//                Head response =
//                        cameraHttpApi.doCommonRequest(params, CameraHttpApi.URL_SHARE_ACCEPT,
//                                Head.class);
//                successMsg.obj = response;
//                handler.sendMessage(successMsg);
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }
//    }
//
//    @Override
//    protected void doMessage(Message msg) {
//        switch (msg.arg1) {
//            case TASKGETSHAREINFO:
//                ShareHostInfo shareHostInfo = (ShareHostInfo) msg.obj;
//                if (shareHostInfo.getErrorCode() == Constants.Http.ERROR_CODE_SUCCEED) {
//                    mSharerName = shareHostInfo.getNickName();
//                    TaskExecutor.Execute(new TaskAcceptShare());
//                } else if (shareHostInfo.getErrorCode() == Constants.Http.ERROR_SHARE_CODE_OVERDUE) {
//                    CameraToast.show(ShareWordActivity.this, R.string.share_word_add_failed, Toast.LENGTH_SHORT);
//                } else {
//                    CameraToast.show(ShareWordActivity.this, shareHostInfo.getErrorMsg(), Toast.LENGTH_SHORT);
//                }
//                break;
//            case TASKACCEPTSHARE:
//                Head response = (Head) msg.obj;
//                if (response.getErrorCode() == Constants.Http.ERROR_CODE_SUCCEED) {
//                    Intent broadcast = new Intent(Const.ACTION_CAMERA_REF);
//                    CLog.d("ACTION_CAMERA_REF");
//                    sendStickyBroadcast(broadcast);
//                    Intent activityIntent =
//                            new Intent(ShareWordActivity.this, TabMainActivity.class);
//                    activityIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                    activityIntent.putExtra("fromShareCode", true);
//                    activityIntent.putExtra("sharerName", mSharerName);
//                    startActivity(activityIntent);
//                    finish();
//                } else {
//                    CameraToast.show(ShareWordActivity.this, response.getErrorMsg(), Toast.LENGTH_SHORT);
//                }
//                break;
//
//            default:
//                break;
//        }
//    }

    public Handler smsHandler = new Handler() {
        public void handleMessage(Message msg) {
        };
    };

    public void getSmsFromPhone() {
        ContentResolver cr = getContentResolver();
        String[] projection = new String[] {
                "body", "address", "person"
        };
        String where = " date >  "
                + (System.currentTimeMillis() - 10 * 60 * 1000);
        Cursor cur = cr.query(SMS_INBOX, projection, where, null, "date desc");
        if (null == cur)
            return;
        if (cur.moveToNext()) {
            String body = cur.getString(cur.getColumnIndex("body"));
            getPatternCode(body);
        }
    }

    class SmsObserver extends ContentObserver {

        public SmsObserver(Context context, Handler handler) {
            super(handler);
        }

        @Override
        public void onChange(boolean selfChange) {
            super.onChange(selfChange);
            getSmsFromPhone();
        }
    }

    @Override
    public void finish() {
        mClipboardManager.removePrimaryClipChangedListener(mOnPrimaryClipChangedListener);
        getContentResolver().unregisterContentObserver(mSmsObserver);
        super.finish();
    }

    @Override
    protected void onResume() {
        initAndGetClipBoard();
        super.onResume();
    }
}
