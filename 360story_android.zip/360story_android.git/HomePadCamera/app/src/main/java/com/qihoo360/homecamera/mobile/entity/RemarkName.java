package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2015/7/23
 * Time: 10:58
 * To change this template use File | Settings | File Templates.
 */
public class RemarkName extends Head{

    public String nickName;

    public String defNick;

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        out.writeString(nickName);
        out.writeString(defNick);
    }

    public static final Parcelable.Creator<RemarkName> CREATOR = new Parcelable.Creator<RemarkName>() {
        @Override
        public RemarkName createFromParcel(Parcel source) {
            return new RemarkName(source);
        }

        @Override
        public RemarkName[] newArray(int size) {
            return new RemarkName[size];
        }
    };

    private RemarkName(Parcel in) {
        nickName = in.readString();
        nickName = in.readString();
    }


}
