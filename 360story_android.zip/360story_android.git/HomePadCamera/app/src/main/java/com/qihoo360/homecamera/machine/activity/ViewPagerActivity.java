/**
 * ****************************************************************************
 * Copyright 2011, 2012 Chris Banes.
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 * *****************************************************************************
 */

package com.qihoo360.homecamera.machine.activity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.entity.MediaFiles;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.utils.imageloader.ImageLoaderHelper;
import com.qihoo360.homecamera.mobile.utils.share.SocialShareType;
import com.qihoo360.homecamera.mobile.widget.CamAlertDialog;
import com.qihoo360.homecamera.mobile.widget.gallary.HackyViewPager;
import com.qihoo360.homecamera.mobile.widget.gallary.PhotoView;
import com.qihoo360.homecamera.mobile.widget.gallary.PhotoViewAttacher;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class ViewPagerActivity extends MachineBaseActivity {
    private static final String ISLOCKED_ARG = "isLocked";

    private ViewPager mViewPager;
    private DisplayImageOptions options;

    private MenuItem menuLockItem;
    private ArrayList<MediaFiles> mediaFileses;
    private int position;
    private int mediaid;
    private String path;

    private TextView tv_title;

    private TextView tv_time;

    private SamplePagerAdapter adapter;

    // 防止分享按钮多次点击标志
    private boolean isMagicClickable = true;

    private int mShareType = SocialShareType.TYPE_SCREENSHOTS;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setFastClickable(true);
        setTintManagerQWork(true);
        tintManager.setTintColor(Color.parseColor("#212121"));
        // DisplayImageOptions.Builder builder = new
        // DisplayImageOptions.Builder();
        // builder.showImageForEmptyUri(R.drawable.camera_default_icon_bg);
        // builder.showImageOnFail(R.drawable.camera_default_icon_bg);
        // builder.cacheInMemory(true);
        // builder.cacheOnDisk(false);
        // builder.considerExifParams(true);
        // builder.bitmapConfig(Bitmap.Config.RGB_565);
        // builder.imageScaleType(ImageScaleType.EXACTLY_STRETCHED);//
        // 设置图片以如何的编码方式显示
        // options = builder.build();

        options = new DisplayImageOptions.Builder().cloneFrom(ImageLoaderHelper.DEFAULT_DISPLAY_OPTIONS)
                .showImageForEmptyUri(R.drawable.camera_default_icon_bg)
                .showImageOnFail(R.drawable.camera_default_icon_bg)
                .imageScaleType(ImageScaleType.EXACTLY_STRETCHED)
                .build();
        mediaid = getIntent().getIntExtra("mediaid", -1);
        path = getIntent().getStringExtra("path");
        mShareType = getIntent().getIntExtra("shareType", SocialShareType.TYPE_SCREENSHOTS);

        // TODO FileWrapper
        mediaFileses = new ArrayList<MediaFiles>(); // 暂时为空
        //mediaFileses = FileWrapper.getInstance(Utils.getContext()).getFileListByType(MediaFiles.TYPE.IMAGE);
        if (!TextUtils.isEmpty(path)) {
            for (int i = 0; i < mediaFileses.size(); i++) {
                if (TextUtils.equals(mediaFileses.get(i).getPath(), path)) {
                    position = i;
                    break;
                }
            }
        }
        if (mediaFileses.size() < 1) {
            CameraToast.show(R.string.img_media_error, Toast.LENGTH_SHORT);
            finish();
            return;
        }
        if (mediaid != -1) {
            for (MediaFiles mediaFiles : mediaFileses) {
                if (mediaFiles.getId() == mediaid) {
                    position = mediaFileses.indexOf(mediaFiles);
                    break;
                }
            }
        }

        setContentView(R.layout.activity_view_pager);
        tv_title = (TextView) findViewById(R.id.tv_title);
        tv_time = (TextView) findViewById(R.id.tv_time);

        mViewPager = (HackyViewPager) findViewById(R.id.view_pager);
        adapter = new SamplePagerAdapter(this, mediaFileses);

        mViewPager.setAdapter(adapter);

        mViewPager.setOnPageChangeListener(new OnPageChangeListener() {
            @SuppressLint("SimpleDateFormat")
            @Override
            public void onPageSelected(int arg0) {
                MediaFiles mediaFile = mediaFileses.get(mViewPager.getCurrentItem());
                tv_title.setText(mediaFile.getCamera_name());
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm");
                tv_time.setText(format.format(mediaFile.getCreate_time()));
            }

            @Override
            public void onPageScrolled(int arg0, float arg1, int arg2) {
            }

            @Override
            public void onPageScrollStateChanged(int arg0) {
            }
        });

        mViewPager.setCurrentItem(position, true);
        if (position == 0) {
            upDateTitle();
        }
        if (savedInstanceState != null) {
            boolean isLocked = savedInstanceState.getBoolean(ISLOCKED_ARG, false);
            ((HackyViewPager) mViewPager).setLocked(isLocked);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        isMagicClickable = true;
    }

    @Override
    protected void onDestroy() {
        //setFastClickable(false);
        super.onDestroy();
    }

    @SuppressLint("SimpleDateFormat")
    private void upDateTitle() {
        MediaFiles mediaFile = mediaFileses.get(mViewPager.getCurrentItem());
        tv_title.setText(mediaFile.getCamera_name());
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        tv_time.setText(format.format(mediaFile.getCreate_time()));
    }

    public class SamplePagerAdapter extends PagerAdapter {

        private ArrayList<MediaFiles> list;
        private LayoutInflater mLayoutInflater;

        public SamplePagerAdapter(Context mContext, ArrayList<MediaFiles> list) {
            this.list = list;
            mLayoutInflater = LayoutInflater.from(mContext);
        }

        @Override
        public int getCount() {
            return list.size();
        }

        public int getItemPosition(Object object) {
            return POSITION_NONE;
        }

        @Override
        public Object instantiateItem(ViewGroup container, final int position) {

            View page = mLayoutInflater.inflate(R.layout.ac_image_pager, null);
            final PhotoView photoView = (PhotoView) page.findViewById(R.id.photo_view);
            photoView.setmWatermark(R.drawable.img_water_mark);
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
            photoView.setmFootnote(dateFormat.format(mediaFileses.get(position).getCreate_time()));
            String ph = "file:///" + mediaFileses.get(position).getPath();
            ImageLoader.getInstance().displayImage(ph, photoView, options, new ImageLoadingListener() {
                @Override
                public void onLoadingStarted(String arg0, View arg1) {
                }

                @Override
                public void onLoadingFailed(String arg0, View arg1, FailReason arg2) {
                }

                @Override
                public void onLoadingComplete(String arg0, View arg1, Bitmap arg2) {
                    photoView.setShowMask(true);
                }

                @Override
                public void onLoadingCancelled(String arg0, View arg1) {
                }
            });
            photoView.setOnPhotoTapListener(new PhotoViewAttacher.OnPhotoTapListener() {
                @Override
                public void onPhotoTap(View view, float x, float y) {
                    // TODO 这里需要继续修改。

                    /*
                     * if (show) { bottomView.setVisibility(View.GONE);
                     * titlView.setVisibility(View.GONE); show = false; } else { show = true;
                     * bottomView.setVisibility(View.VISIBLE); titlView.setVisibility(View.VISIBLE);
                     * }
                     */
                }
            });
            photoView.setTag("php");
            container.addView(page);
            return page;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            CLog.d("destroyItem");
            container.removeView((View) object);
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            CLog.d("isViewFromObject");
            return view == object;
        }

    }

    @Override
    public void onBackPressed() {
        setResult(200);
        finish();
    }

    private void toggleViewPagerScrolling() {
        if (isViewPagerActive()) {
            ((HackyViewPager) mViewPager).toggleLock();
        }
    }

    private void toggleLockBtnTitle() {
        boolean isLocked = false;
        if (isViewPagerActive()) {
            isLocked = ((HackyViewPager) mViewPager).isLocked();
        }
        String title = (isLocked) ? getString(R.string.menu_unlock) : getString(R.string.menu_lock);
        if (menuLockItem != null) {
            menuLockItem.setTitle(title);
        }
    }

    private boolean isViewPagerActive() {
        return (mViewPager != null && mViewPager instanceof HackyViewPager);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (isViewPagerActive()) {
            outState.putBoolean(ISLOCKED_ARG, ((HackyViewPager) mViewPager).isLocked());
        }
        super.onSaveInstanceState(outState);
    }

    public void share(View view) {
        // TODO 填充分享代码
//        Intent intent = new Intent(ViewPagerActivity.this, PhotoShareToAppActivity.class);
//        intent.putExtra("camera", getIntent().getParcelableExtra("camera"));
//        intent.putExtra("shareType", mShareType);
//        intent.putExtra(PhotoShareToAppActivity.SHAREABLE, mediaFileses.get(mViewPager.getCurrentItem()));
//        startActivity(intent);
    }

    /**
     * 魔拍分享
     * @param view
     */
    public void shareMagic(View view) {
        if (!isMagicClickable) {
            return;
        }
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        //暂时注掉
//        ShareImageActivity.startActivity(ViewPagerActivity.this, wrapPublicCameraObj(), mediaFileses.get(mViewPager.getCurrentItem()).getPath(), mShareType,
//                dateFormat.format(mediaFileses.get(mViewPager.getCurrentItem()).getCreate_time()));
        isMagicClickable = false;
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_trash:
                showDeleteDialog();
                break;

            default:
                break;
        }
    }

    private void showDeleteDialog() {
        CamAlertDialog.Builder builder = new CamAlertDialog.Builder(this);
        builder.setTitle(Utils.getContext().getString(R.string.delete_pic));
        builder.setPositiveButton(Utils.getContext().getString(R.string.ok),
                new CamAlertDialog.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        deleteFile();
                    }
                });
        builder.setNegativeButton(getString(R.string.cancel), null);
        builder.show();
    }

    private void deleteFile() {
        // TODO FileWrapper
//        final String path = mediaFileses.get(mViewPager.getCurrentItem()).getPath();
//        mediaFileses.remove(mViewPager.getCurrentItem());
//        adapter.notifyDataSetChanged();
//        AsyncTask.SERIAL_EXECUTOR.execute(new Runnable() {
//            @Override
//            public void run() {
//                Utils.getContext()
//                        .getContentResolver()
//                        .delete(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
//                                MediaStore.Images.Media.DATA + " = '" + path + "'", null);
//                FileWrapper.getInstance(Utils.getContext()).delByPath(path, true);
//            }
//        });
//        if (mediaFileses.size() < 1) {
//            onBackPressed();
//        } else {
//            upDateTitle();
//        }
    }
}
