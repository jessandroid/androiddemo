
package com.qihoo360.homecamera.machine.business;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import com.google.gson.Gson;
import com.qihoo360.homecamera.device.config.StoryMachineConsts;
import com.qihoo360.homecamera.machine.config.MachineDefaultClientConfig;
import com.qihoo360.homecamera.machine.entity.FavorResultEntity;
import com.qihoo360.homecamera.machine.entity.LocalSetting;
import com.qihoo360.homecamera.machine.entity.MachineDeviceInfo;
import com.qihoo360.homecamera.machine.entity.MachinePlaySingle;
import com.qihoo360.homecamera.machine.entity.MachineSong;
import com.qihoo360.homecamera.machine.entity.PlayControlReceipt;
import com.qihoo360.homecamera.machine.entity.PlayListReceipt;
import com.qihoo360.homecamera.machine.entity.SongEntity;
import com.qihoo360.homecamera.machine.entity.UpgradeReceipt;
import com.qihoo360.homecamera.machine.manager.MachinePlayInfoManager;
import com.qihoo360.homecamera.mobile.BuildConfig;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.db.CommonWrapper;
import com.qihoo360.homecamera.mobile.db.MachineSongWrapper;
import com.qihoo360.homecamera.mobile.entity.Head;
import com.qihoo360.homecamera.mobile.http.OkHttpUtils;
import com.qihoo360.homecamera.mobile.http.request.RequestCall;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.Preferences;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * 设置IPC任务
 * 
 * @author zhangtao
 */
public class SettingTask implements Runnable {


    private String cmd;     //指令名称

    private String content; //指令数据内容，json串

    private final Handler handler;

    private String from;

    private Context mContext;

    private String mSn;


    public SettingTask(Context context, String cmd, String content, Handler handler, String from) {
        this.mContext = context;
        this.cmd = cmd;
        this.content = content;
        this.handler = handler;
        this.from = from;
    }

    public SettingTask(Context context, String sn, String cmd, String content, Handler handler, String from) {
        this.mContext = context;
        this.cmd = cmd;
        this.content = content;
        this.handler = handler;
        this.from = from;
        this.mSn = sn;
    }


    @Override
    public void run() {

        try {
            Map<String, String> param = new HashMap<>();
            if(TextUtils.isEmpty(mSn)){
                param.put("sn", Preferences.getSelectedPad());
            }else{
                param.put("sn", mSn);
            }
            param.put("cmd", cmd);
            param.put("content", content);//json字符串
            param.put("device", "story");
            param.put("funcType","toIpc");
            param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
            //异步等待请求
            String responseStr = OkHttpUtils.machinePost().params(param).headers(null).url(MachineDefaultClientConfig.APP_CMD_SEND).build().excuteAysnRequest(mContext,TextUtils.equals(cmd, PlayConfig.CommandType.NOTIFYFMUPGRADE) ? RequestCall.UPGRADE_TIME_OUT : RequestCall.COMMON_TIME_OUT);
            Head head = new Gson().fromJson(responseStr, Head.class);
            if(head!=null && head.errorCode!=0){
                Message msg = new Message();
                msg.obj = cmd;
                //TODO 此次异步请求失败了,也有可能是时间问题放弃的
                if(head.errorCode == -18){//过时
                    //TODO 不做任何操作
                }else{
                    //TODO -14是超时， -20是故事机离线
                    msg.arg1 = head.errorCode;
                    handler.sendMessage(msg);
                }
                CLog.e("zt", "接收指令回复失败 cmd:"+cmd);
            }else{
                //TODO 针对不同的命令进行处理
                CLog.e("zt","收到push返回消息");
                handlerResult(cmd, responseStr);
            }
        } catch (Exception e) {
            handler.obtainMessage(Constants.TaskState.EXCEPITON).sendToTarget();
        }

    }

    private void handlerResult(String command, String rps){

        String content = "";
        String senderSn = "";
        JSONObject jo;
        try {
             jo = new JSONObject(rps);
             JSONObject dataJo = jo.getJSONObject("data");
             content = dataJo.getString("content");
             senderSn = dataJo.getJSONObject("senderInfo").getString("sn");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        if(!TextUtils.isEmpty(content)){
            if(TextUtils.equals(command, PlayConfig.CommandType.PLAYCONTROL) || TextUtils.equals(command, PlayConfig.CommandType.GETPLAYSTATUS)){//播放控制的回执或者获取播放状态的回执
                //收到一条播放控制的指令
                //TODO 告诉播放管理器
                PlayControlReceipt playControlReceipt = new Gson().fromJson(content, PlayControlReceipt.class);
                if(playControlReceipt.resultCode==0){
                    MachinePlaySingle playSingle = new MachinePlaySingle();
                    playSingle.setMediaInfo(playControlReceipt.getMediaInfo());
                    playSingle.setPageId(playControlReceipt.getPageId());
                    playSingle.setStatus(playControlReceipt.getStatus());
                    playSingle.setUnique(playControlReceipt.getUnique());
                    CLog.e("zt","异步等待更新播放状态");
                    MachinePlayInfoManager.getInstance().notifySinglePlayUpdate(playSingle, cmd, from, senderSn);
                }else if(playControlReceipt.resultCode==1){
                    //TODO 故事机正在忙
                    MachinePlayInfoManager.getInstance().notifyMachineBusy(cmd, from, senderSn);
                }else if(playControlReceipt.resultCode==2){
                    //TODO 故事机闲着
                    MachinePlayInfoManager.getInstance().notifyMachineFree(cmd, senderSn);
                }else if(playControlReceipt.resultCode==3){
                    //列表为空
                    MachinePlayInfoManager.getInstance().notifyPlayListEmpty(cmd, senderSn);
                }
            }else if(TextUtils.equals(command, PlayConfig.CommandType.GETPLAYLIST)){//获取某个列表的回执
                //主动获取一些列表
                PlayListReceipt playListReceipt = new Gson().fromJson(content, PlayListReceipt.class);
                if(playListReceipt.resultCode==0){//成功，列表需要更新
                    //TODO 先进行入库操作，然后进行处理
                    ArrayList<MachineSong> machineSongList = new ArrayList<>();
                    for(SongEntity song : playListReceipt.getMediaList()){
                        MachineSong machineSong = new MachineSong();
                        machineSong.sn = Preferences.getSelectedPad();
                        machineSong.unique = playListReceipt.getUnique();
                        machineSong.md5 = playListReceipt.getMd5();
                        machineSong.uniqueid = song.uniqueid;
                        machineSong.title = song.title;
                        machineSong.mediaurl = song.mediaurl;
                        machineSong.type = song.type;
                        machineSong.srclogo = song.srclogo;
                        machineSong.src = song.src;
                        machineSong.typeFrom = playListReceipt.getType();
                        machineSongList.add(machineSong);
                    }
                    if(machineSongList.size()>0){
                        MachineSongWrapper.getInstance().updateSongList(machineSongList);
                    }else{
                        MachineSong machineSong = new MachineSong();
                        machineSong.sn = Preferences.getSelectedPad();
                        machineSong.unique = playListReceipt.getUnique();
                        machineSong.typeFrom = playListReceipt.getType();
                        MachineSongWrapper.getInstance().deleteList(machineSong);
                    }
                    //TODO 通知页面有新的列表更新（进入收藏列表，还有就是用户播放故事机内置列表）
                    MachinePlayInfoManager.getInstance().notifyListUpdate(playListReceipt.getType(), cmd, from, senderSn);
                }else if(playListReceipt.resultCode==1){//成功，列表已经最新，无需更新
                    //TODO  只需通知即可
                    MachinePlayInfoManager.getInstance().notifyListUpdate(playListReceipt.getType(), cmd, from, senderSn);
                }else if(playListReceipt.resultCode==3){//成功，列表为空
                    ArrayList<MachineSong> machineSongList = new ArrayList<>();
                    MachineSong song = new MachineSong();
                    song.typeFrom = playListReceipt.getType();
                    song.unique = playListReceipt.getUnique();
                    song.sn = Preferences.getSelectedPad();
                    machineSongList.add(song);
                    MachineSongWrapper.getInstance().clearTable(machineSongList);//清空该列表
                    //TODO 通知页面有新的列表更新（进入收藏列表，还有就是用户播放故事机内置列表）
                    MachinePlayInfoManager.getInstance().notifyListUpdate(playListReceipt.getType(), cmd, from, senderSn);
                }
            }else if(TextUtils.equals(command, PlayConfig.CommandType.DOLOCALSETTING) || TextUtils.equals(command, PlayConfig.CommandType.GETLOCALSETTING)){
                //TODO 通知播放页更新设置状态,并存入数据库
                CommonWrapper.getInstance(mContext).writeBySnWithType(senderSn, content, CommonWrapper.TYPE_MACHINE_LOCAL_SETTING);
                LocalSetting localSetting = new Gson().fromJson(content, LocalSetting.class);
                MachinePlayInfoManager.getInstance().notifyLocalSettingUpdate(localSetting, senderSn);
            }else if(TextUtils.equals(command, PlayConfig.CommandType.DOFAVOR)){//收藏操作的回执
                CLog.e("zt","收到收藏操作回执");
                FavorResultEntity favorResultEntity = new Gson().fromJson(content, FavorResultEntity.class);
                MachinePlayInfoManager.getInstance().notifyFavorResultUpdate(favorResultEntity, from, senderSn);
            }else if(TextUtils.equals(command, PlayConfig.CommandType.GETDEVICEINFO)){//收到获取故事机信息的回执
                CLog.e("zt","收到获取到故事机信息的回执");
                CommonWrapper.getInstance(mContext).writeBySnWithType(senderSn, content, CommonWrapper.TYPE_MACHINE_DEVICE_INFO);
                MachineDeviceInfo deviceInfo = new Gson().fromJson(content, MachineDeviceInfo.class);
                MachinePlayInfoManager.getInstance().notifyDeviceInfoUpdate(deviceInfo, senderSn, from);
            }else if(TextUtils.equals(command, PlayConfig.CommandType.NOTIFYFMUPGRADE)){//通知故事机升级的指令回执
                CLog.e("zt","收到故事机固件升级的回执");
                UpgradeReceipt upgradeReceipt = new Gson().fromJson(content, UpgradeReceipt.class);
                MachinePlayInfoManager.getInstance().notifyGetUpgradeInfo(upgradeReceipt, senderSn, from);
            }
        }

    }
}
