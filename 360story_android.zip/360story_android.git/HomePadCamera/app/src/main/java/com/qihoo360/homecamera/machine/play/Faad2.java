package com.qihoo360.homecamera.machine.play;

/**
 * Created by harrison on 2017/5/12.
 */

public class Faad2 {

    static {
        System.loadLibrary("faad2-lib");
    }
    public native boolean convertToWav(String aac_filename, String wav_filename);

}
