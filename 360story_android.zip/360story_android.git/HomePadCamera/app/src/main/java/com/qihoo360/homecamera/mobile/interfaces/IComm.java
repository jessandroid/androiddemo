
package com.qihoo360.homecamera.mobile.interfaces;

import com.qihoo360.homecamera.mobile.entity.InnerMsg;

/** phone service 和 Activity 直接沟通的接口 */
public interface IComm {
	 void onMessage(InnerMsg msg);
}
