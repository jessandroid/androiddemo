
package com.qihoo360.homecamera.mobile.interfaces;

import android.content.Context;


/**
 * @author songzhaochun
 *
 */
public interface IAppConfig {

    String get(String p1, String p2);
    String getExternalDataStoreDir(Context context);
}
