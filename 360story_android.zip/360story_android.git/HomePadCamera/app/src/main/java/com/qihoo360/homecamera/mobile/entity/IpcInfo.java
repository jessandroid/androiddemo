package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by yanggang on 2016/5/12.
 */
public class IpcInfo implements Parcelable {
    public String sn;
    public String title;
    public String coverUrl;

    public static final Parcelable.Creator<IpcInfo> CREATOR = new Parcelable.Creator<IpcInfo>() {
        @Override
        public IpcInfo createFromParcel(Parcel source) {
            return new IpcInfo(source);
        }

        @Override
        public IpcInfo[] newArray(int size) {
            return new IpcInfo[size];
        }
    };

    private IpcInfo(Parcel in) {
        sn = in.readString();
        title = in.readString();
        coverUrl = in.readString();
    }

    @Override
    public void writeToParcel(Parcel out, int flags) {
        out.writeString(sn);
        out.writeString(title);
        out.writeString(coverUrl);
    }

    @Override
    public int describeContents() {
        return 0;
    }
}
