package com.qihoo360.homecamera.machine.activity;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.qihoo360.homecamera.device.config.StoryMachineConsts;
import com.qihoo360.homecamera.machine.business.TaskExecutor;
import com.qihoo360.homecamera.machine.entity.Wifi;
import com.qihoo360.homecamera.machine.ui.widget.RoundProgressBar;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.SysConfig;
import com.qihoo360.homecamera.mobile.activity.BaseActivity;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.FileUtil;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.widget.CamAlertDialog;
import com.qihoo360.voicebarcode.Sender;

import java.io.File;

public class AddCameraSoundActivity extends MachineBaseActivity
        implements
            View.OnClickListener,
            RoundProgressBar.PlayingListener {

    private static final int SOUND1_COMPLETE = 1001;
    private Wifi wifi;;
    private MediaPlayer mMediaPlayer;
    private File sound;

    int count = 0;
    private int clickCount = 0;
    private int maxCount = 3;

    private Button btnQRScanComplete;
    private RoundProgressBar btn_sound;
    private TextView guide_title;
    private View fl_btn;
    private View sendQrView;
    private View add_sound_guide, hand_with_phone, camera_gray;
    private View tv_guide2;
    private TextView mErrorView;
    private ImageView iv_sound_bg;
    private Bitmap addBgBmp;
    private String setup_type;

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case SOUND1_COMPLETE:
                    soundComplete();
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        super.onCreate(savedInstanceState);

        wifi = (Wifi) getIntent().getSerializableExtra("Wifi");
        setup_type = getIntent().getStringExtra(StoryMachineConsts.KEY_SET_WIFI_FROM);
        initView();
        setView();
        initAnimation();
        initSound();
    }

    /********** 初始化相关 **********/
    private void initView() {
        setTintManagerQWork(true);
        tintManager.setStatusBarTintColor(Color.parseColor("#0000aeff"));
        setContentView(R.layout.activity_add_camera_sound);
        iv_sound_bg = (ImageView) findViewById(R.id.iv_sound_bg);
        guide_title = (TextView) findViewById(R.id.tv_add_guide2_title);
        fl_btn = findViewById(R.id.fl_btn_sound);
        tv_guide2 = findViewById(R.id.tv_add_guide2);
        sendQrView = findViewById(R.id.iv_send_qr);
        btn_sound = (RoundProgressBar) findViewById(R.id.btn_sound);
        btnQRScanComplete = (Button) findViewById(R.id.btn_QRscan_complete);
        mErrorView = (TextView) findViewById(R.id.btn_add_camera_error);
    }

    private void setView() {
        iv_sound_bg.setMaxWidth(SysConfig.BASE_SCREEN_WIDTH);
        iv_sound_bg.setMaxHeight(SysConfig.BASE_SCREEN_HEIGHT);
        addBgBmp = Utils.getBitmap(R.drawable.bg_machine_add);
        iv_sound_bg.setImageBitmap(addBgBmp);
        
        TextView tv_add_title = (TextView) findViewById(R.id.tv_add_title);
        tv_add_title.setText(getString(R.string.add_second_step));
        btn_sound.setPlayingListener(this);
        btnQRScanComplete.setEnabled(false);
        mErrorView.setText(Html.fromHtml("<u>" + getString(R.string.add_camera_sound_error)
                + "</u>"));
        mErrorView.setVisibility(View.GONE);
        mErrorView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LayoutInflater inflater = LayoutInflater.from(AddCameraSoundActivity.this);
                View viewDialog = inflater.inflate(R.layout.item_add_camera_sound_toast, null);
                View closeBtn = viewDialog.findViewById(R.id.toast_close_iv);

                final CamAlertDialog camAlertDialog =
                        new CamAlertDialog(AddCameraSoundActivity.this, R.style.Dialog_Fullscreen);
                camAlertDialog.setContentView(viewDialog);
                closeBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        camAlertDialog.dismiss();
                    }
                });

                camAlertDialog.show();
            }
        });
    }

    private void initAnimation() {
        add_sound_guide = findViewById(R.id.add_sound_guide);
        camera_gray = findViewById(R.id.camera_gray);
        hand_with_phone = findViewById(R.id.hand_with_phone);

        Animation a1 = AnimationUtils.loadAnimation(this, R.anim.left_in_camera);
        final Animation a2 = AnimationUtils.loadAnimation(this, R.anim.right_in_hand);

        a1.setAnimationListener(new AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                hand_with_phone.setVisibility(View.VISIBLE);
                hand_with_phone.startAnimation(a2);
            }
        });
        camera_gray.startAnimation(a1);
    }

    /********** 生命周期相关 **********/
    @Override
    protected void onStart() {
        super.onStart();
        CLog.d("onStart...");
        registerReceiver(mHeadsetReceiver, new IntentFilter("android.intent.action.HEADSET_PLUG"));
        loadSound();
    }

    @Override
    protected void onStop() {
        super.onStop();
        unregisterReceiver(mHeadsetReceiver);
        btn_sound.stop();
        onStopCompletion();
    }

    @Override
    public void onBackPressed() {
        if(mMediaPlayer != null && mMediaPlayer.isPlaying()) {
            mMediaPlayer.stop();
        }
        handler.removeCallbacksAndMessages(null);
        finish();
        overridePendingTransition(0, 0);
    }

    @Override
    protected void onDestroy() {
        if (addBgBmp != null) {
            addBgBmp.recycle();
        }
        super.onDestroy();
        if (mMediaPlayer != null) {
            mMediaPlayer.release();
        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_QRscan_complete) {
            if (Utils.isNetworkAvailable(Utils.getContext())) {
                Intent intent = new Intent(this, AddCameraWaitActivity.class);
                intent.putExtra("Wifi", wifi);
                intent.putExtra(StoryMachineConsts.KEY_SET_WIFI_FROM,setup_type);
                startActivity(intent);
                overridePendingTransition(0, 0);
            } else {
                CameraToast.show(this, getString(R.string.network_disabled), Toast.LENGTH_SHORT);
            }
        } else if (v.getId() == R.id.iv_send_qr) {
            CLog.d("Change to QR");
            if (mMediaPlayer != null) {
                mMediaPlayer.stop();
            }
            btn_sound.stop();
            Intent intent = new Intent(this, AddCameraQRActivity.class);
            intent.putExtra("Wifi", wifi);
            startActivity(intent);
            finish();
            overridePendingTransition(0, 0);
        }
    }

    /********** 工具方法 **********/
    @SuppressLint("UseSparseArrays")
    public void initSound() {
        mMediaPlayer = MediaPlayer.create(this, R.raw.sound1);
        if (mMediaPlayer != null) {
            mMediaPlayer.setOnCompletionListener(new OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    handler.sendEmptyMessage(SOUND1_COMPLETE);
                }
            });
            mMediaPlayer.start();
        }

    }

    private void loadSound() {
        if (wifi != null) {
            sound = new File(FileUtil.getmSDCacheDir(), "sound_wav.wav");
            if (sound.exists()) {
                sound.delete();
            }
            TaskExecutor.Execute(new Runnable() {
                @Override
                public void run() {
                    if (Sender.createWav(wifi.getQRcode(), sound.getAbsolutePath())) {
                        try {
                            btn_sound.loadSound(sound);
                        } catch (Exception e) {
                            e.printStackTrace();
                            CameraToast.show(getString(R.string.sound_code_fail, 102), Toast.LENGTH_SHORT);
                        }
                    } else {
                        int error = Sender.getErrorCode();
                        if (error == 1) {
                            CameraToast.show(R.string.sound_fail_text_too_long, Toast.LENGTH_SHORT);
                        }
                        //101 - 写入wav文件失败   指定保存WAV文件的路径不存在或无权限写入
                        CameraToast.show(getString(R.string.sound_code_fail, error), Toast.LENGTH_SHORT);
                    }
                }
            });
        }
    }

    protected void soundComplete() {
        if (mMediaPlayer != null) {
            mMediaPlayer.release();
        }
        mMediaPlayer = MediaPlayer.create(AddCameraSoundActivity.this, R.raw.sound2);
        if (mMediaPlayer != null) {
            mMediaPlayer.start();
        }
        fl_btn.setVisibility(View.INVISIBLE);
        add_sound_guide.setVisibility(View.GONE);
        sendQrView.setVisibility(View.INVISIBLE);
        String exchange = getString(R.string.add_sound_guide2);
        guide_title.setText(Html.fromHtml(exchange));
        Animation aa = AnimationUtils.loadAnimation(this, R.anim.alpha_animator_add);
        final Animation aa2 = AnimationUtils.loadAnimation(this, R.anim.alpha_animator_add);
        aa.setAnimationListener(new AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {}

            @Override
            public void onAnimationRepeat(Animation animation) {}

            @Override
            public void onAnimationEnd(Animation animation) {
                fl_btn.setVisibility(View.VISIBLE);
                mErrorView.setVisibility(View.VISIBLE);
                fl_btn.startAnimation(aa2);
                mErrorView.startAnimation(aa2);
            }
        });
        guide_title.startAnimation(aa);
    };

    /********** 内部类 **********/
    BroadcastReceiver mHeadsetReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            int state = intent.getIntExtra("state", 2);
            if (btn_sound.isPlaying() && state == 1) {
                CameraToast.show(getString(R.string.please_pull_headset), Toast.LENGTH_SHORT);
            }
        }
    };

    @Override
    public void onPlay() {
        if (mMediaPlayer != null) {
            mMediaPlayer.stop();
        }
        tv_guide2.setVisibility(View.INVISIBLE);
        btnQRScanComplete.setEnabled(false);
        guide_title.setText(R.string.add_sound_guide3);
    }

    @Override
    public void onCompletion() {
        btnQRScanComplete.setEnabled(true);
        btnQRScanComplete.setText(getString(R.string.add_sound_tip));
        String guide4 = getString(R.string.add_sound_guide4);
        tv_guide2.setVisibility(View.INVISIBLE);
        guide_title.setText(Html.fromHtml(guide4));

        Animation aa = AnimationUtils.loadAnimation(this, R.anim.alpha_animator_add);
        final Animation aa2 = AnimationUtils.loadAnimation(this, R.anim.alpha_animator_add);
        aa.setAnimationListener(new AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {}

            @Override
            public void onAnimationRepeat(Animation animation) {}

            @Override
            public void onAnimationEnd(Animation animation) {
                tv_guide2.setVisibility(View.VISIBLE);
                tv_guide2.startAnimation(aa2);
            }
        });
        guide_title.startAnimation(aa);

        clickCount++;
        //连续发送三次声波，会弹出二维码添加功能，故事机不需要这个功能，注掉
//        if (clickCount == maxCount) {
//            if (sendQrView.getVisibility() != View.VISIBLE) {
//                sendQrView.setVisibility(View.VISIBLE);
//                sendQrView.startAnimation(aa);
//            }
//        }
    }

    public void onStopCompletion() {
        btnQRScanComplete.setEnabled(true);
        String guide4 = getString(R.string.add_sound_guide4);
        tv_guide2.setVisibility(View.INVISIBLE);
        guide_title.setText(Html.fromHtml(guide4));

        Animation aa = AnimationUtils.loadAnimation(this, R.anim.alpha_animator_add);
        final Animation aa2 = AnimationUtils.loadAnimation(this, R.anim.alpha_animator_add);
        aa.setAnimationListener(new AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {}

            @Override
            public void onAnimationRepeat(Animation animation) {}

            @Override
            public void onAnimationEnd(Animation animation) {
                tv_guide2.setVisibility(View.VISIBLE);
                tv_guide2.startAnimation(aa2);
            }
        });
        guide_title.startAnimation(aa);

        if (clickCount == maxCount) {
            if (sendQrView.getVisibility() != View.VISIBLE) {
                sendQrView.setVisibility(View.VISIBLE);
                sendQrView.startAnimation(aa);
            }
        }
    }
}
