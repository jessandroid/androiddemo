package com.qihoo360.homecamera.machine.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * 故事机单曲实体类
 * Created by zhangchao-pd on 2016/11/18.
 */
public class PlayControlReceipt extends BaseCmdReceipt implements Parcelable {

    private SongEntity mediaInfo;//正在播放儿歌或者故事的信息

    private String unique;//所属专辑的unique

    private int pageid;  //属于专辑列表的第几页

    private String playstatus;//播放状态  play表示播放新的歌曲，pause表示暂停，resume表示继续

    public PlayControlReceipt() {
    }

    public String getStatus() {
        return playstatus;
    }

    public void setStatus(String playstatus) {
        this.playstatus = playstatus;
    }

    public int getPageId() {
        return pageid;
    }

    public void setPageId(int pageId) {
        this.pageid = pageId;
    }

    public String getUnique() {
        return unique;
    }

    public void setUnique(String unique) {
        this.unique = unique;
    }

    public SongEntity getMediaInfo() {
        return mediaInfo;
    }

    public void setMediaInfo(SongEntity mediaInfo) {
        this.mediaInfo = mediaInfo;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(this.mediaInfo, flags);
        dest.writeString(this.unique);
        dest.writeInt(this.pageid);
        dest.writeString(this.playstatus);
    }

    protected PlayControlReceipt(Parcel in) {
        this.mediaInfo = in.readParcelable(SongEntity.class.getClassLoader());
        this.unique = in.readString();
        this.pageid = in.readInt();
        this.playstatus = in.readString();
    }

    public static final Creator<PlayControlReceipt> CREATOR = new Creator<PlayControlReceipt>() {
        @Override
        public PlayControlReceipt createFromParcel(Parcel source) {
            return new PlayControlReceipt(source);
        }

        @Override
        public PlayControlReceipt[] newArray(int size) {
            return new PlayControlReceipt[size];
        }
    };
}
