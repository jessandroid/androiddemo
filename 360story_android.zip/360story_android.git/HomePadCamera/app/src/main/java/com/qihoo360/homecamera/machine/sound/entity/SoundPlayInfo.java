package com.qihoo360.homecamera.machine.sound.entity;

import com.qihoo360.homecamera.mobile.entity.Head;

import java.util.ArrayList;

/**
 * @author chengxiangyu
 * 播放结构
 */
public class SoundPlayInfo extends Head {
    private static final long serialVersionUID = 7825851759245808639L;
    public ArrayList<SoundInfo> data;
	
	public class SoundInfo{
	    
		public int songId;
		public String songImg;
		public String songName;
		public String songUrl;
		public int songType;
		public long songSize;
		public String songMd5;
		public String songSrc;
		public String songAlbumName;
		public String songSingerName;
		
		public int getSongType() {
			return songType;
		}
		public void setSongType(int songType) {
			this.songType = songType;
		}
		public long getSongSize() {
			return songSize;
		}
		public void setSongSize(long songSize) {
			this.songSize = songSize;
		}
		public String getSongMd5() {
			return songMd5;
		}
		public void setSongMd5(String songMd5) {
			this.songMd5 = songMd5;
		}
		public String getSongSrc() {
			return songSrc;
		}
		public void setSongSrc(String songSrc) {
			this.songSrc = songSrc;
		}
		public int getSongId() {
			return songId;
		}
		public void setSongId(int songId) {
			this.songId = songId;
		}
		public String getSongImg() {
			return songImg;
		}
		public void setSongImg(String songImg) {
			this.songImg = songImg;
		}
		public String getSongName() {
			return songName;
		}
		public void setSongName(String songName) {
			this.songName = songName;
		}
		public String getSongUrl() {
			return songUrl;
		}
		public void setSongUrl(String songUrl) {
			this.songUrl = songUrl;
		}
		public String getSongAlbumName() {
			return songAlbumName;
		}
		public void setSongAlbumName(String songAlbumName) {
			this.songAlbumName = songAlbumName;
		}
		public String getSongSingerName() {
			return songSingerName;
		}
		public void setSongSingerName(String songSingerName) {
			this.songSingerName = songSingerName;
		}
	}
}
