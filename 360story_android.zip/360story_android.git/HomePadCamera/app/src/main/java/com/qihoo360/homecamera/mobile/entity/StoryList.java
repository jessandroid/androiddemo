package com.qihoo360.homecamera.mobile.entity;

import android.annotation.SuppressLint;
import android.os.Parcel;

import java.util.List;


@SuppressLint("ParcelCreator")
public class StoryList extends Head {

    public int total;
    public List<Story> data;
    public String title;
    public boolean isFromDB = false;

    public StoryList() {
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeTypedList(data);


    }

    protected StoryList(Parcel in) {
        super(in);
        this.data = in.createTypedArrayList(Story.CREATOR);

    }

    public static final Creator<StoryList> CREATOR = new Creator<StoryList>() {
        @Override
        public StoryList createFromParcel(Parcel source) {
            return new StoryList(source);
        }

        @Override
        public StoryList[] newArray(int size) {
            return new StoryList[size];
        }
    };
}
