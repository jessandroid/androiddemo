package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;

import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.FileUtil;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.text.ParseException;
import java.util.Date;

/**
 * Created by zhaojunbo on 2016/1/20.
 * desc:
 */
public class ImageInfoEntity extends Head {

    public long imageId;
    public String uid;
    public String utitle;
    public String src;
    public String fileName;
    public String sn;// sn
    public int envType;// envType
    public long playtime;// totalTime
    public String oriName;
    public Preview preview;
    public File file;
    public String filePath;
    public Down down;
    public Thumbnail thumbnail;
    //请求到达服务器时间
    public Date createTime;
    public int ftype;
    public boolean isChecked = false;
    public boolean isTitle = false;
    public String title;
    public String ipcTitle;
    //上传时间
    public String triggerTime;


    public static class Preview implements Parcelable {
        public String url;
        public String token;

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(this.url);
            dest.writeString(this.token);
        }

        public Preview() {
        }

        protected Preview(Parcel in) {
            this.url = in.readString();
            this.token = in.readString();
        }

        public static final Creator<Preview> CREATOR = new Creator<Preview>() {
            @Override
            public Preview createFromParcel(Parcel source) {
                return new Preview(source);
            }

            @Override
            public Preview[] newArray(int size) {
                return new Preview[size];
            }
        };

        public boolean isEqualWith(Preview preview) {
            if (preview == null) {
                return false;
            }
            if (!this.url.equals(preview.url)) {
                return false;
            }
            if (!this.token.equals(preview.token)) {
                return false;
            }
            return true;
        }
    }

    public static class File implements Parcelable {
        public String url;
        public String token;

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(this.url);
            dest.writeString(this.token);
        }

        public File() {
        }

        protected File(Parcel in) {
            this.url = in.readString();
            this.token = in.readString();
        }

        public static final Creator<File> CREATOR = new Creator<File>() {
            @Override
            public File createFromParcel(Parcel source) {
                return new File(source);
            }

            @Override
            public File[] newArray(int size) {
                return new File[size];
            }
        };

        public boolean isEqualWith(File file) {
            if (file == null) {
                return false;
            }
            if (!this.url.equals(file.url)) {
                return false;
            }
            if (!this.token.equals(file.token)) {
                return false;
            }
            return true;
        }
    }

    public static class Down implements Parcelable {
        public String url;
        public String token;

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(this.url);
            dest.writeString(this.token);
        }

        public Down() {
        }

        protected Down(Parcel in) {
            this.url = in.readString();
            this.token = in.readString();
        }

        public static final Creator<Down> CREATOR = new Creator<Down>() {
            @Override
            public Down createFromParcel(Parcel source) {
                return new Down(source);
            }

            @Override
            public Down[] newArray(int size) {
                return new Down[size];
            }
        };

        public boolean isEqualWith(Down down) {
            if (down == null) {
                return false;
            }
            if (!this.url.equals(down.url)) {
                return false;
            }
            if (!this.token.equals(down.token)) {
                return false;
            }
            return true;
        }
    }

    public static class Thumbnail implements Parcelable {
        public String url;
        public String token;

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(this.url);
            dest.writeString(this.token);
        }

        public Thumbnail() {
        }

        protected Thumbnail(Parcel in) {
            this.url = in.readString();
            this.token = in.readString();
        }

        public static final Creator<Thumbnail> CREATOR = new Creator<Thumbnail>() {
            @Override
            public Thumbnail createFromParcel(Parcel source) {
                return new Thumbnail(source);
            }

            @Override
            public Thumbnail[] newArray(int size) {
                return new Thumbnail[size];
            }
        };

        public boolean isEqualWith(Thumbnail thumbnail) {
            if (thumbnail == null) {
                return false;
            }
            if (!this.url.equals(thumbnail.url)) {
                return false;
            }
            if (!this.token.equals(thumbnail.token)) {
                return false;
            }
            return true;
        }
    }

    public String getThumbFilePath() {
        Date now = new Date();
        //String imgDate = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(now);
        String imgDate = getDate().toString();
        filePath = FileUtil.getEventFile().getAbsolutePath() + "/" + imgDate + ".jpg";
        return filePath;
    }

    public String getThumbPath() {
        return filePath;
    }

    public String getVideoPath() {
        return FileUtil.getEventFile().getAbsolutePath();
    }

    public String getVideoName() {
        return fileName;
    }


    /**
     * 有两个字段
     * createTime : 请求到达服务器时间
     * triggerTime: 上传时间
     *
     * triggerTime 是后添加字段, 若有合理值使用该字段用于展示时间
     * 若无该字段 默认值是"0000-00-00 00:00:00" 此时使用createTime字段
     * 作为展示
     *
     */
    public Date getDate() {
        Date triggerDate = null;

        try {
            String defaultTriggerTime = "0000-00-00 00:00:00";

            if (!TextUtils.isEmpty(triggerTime)){
                if (!triggerTime.equalsIgnoreCase(defaultTriggerTime)){
                    triggerDate = Utils.DATE_FORMAT_3.parse(triggerTime);
                }
            }
        } catch (ParseException e) {
            CLog.e(String.format("the e is %s ", e.getMessage()));
        }

        if (triggerDate != null){
            return triggerDate;
        }

        return createTime;
    }

    public String getDateString() {
        Date date = getDate();
        if (date != null) {
            StringBuffer stringBuffer = new StringBuffer();
            String dateStr = Utils.formatDay(Utils.DATE_FORMAT_5.format(date));
            stringBuffer.append(dateStr);
            if (TextUtils.equals(dateStr, "今天") || TextUtils.equals(dateStr, "昨天")) {
                stringBuffer.append(" ");
                return stringBuffer.append(Utils.DATE_FORMAT_9.format(date)).toString();
            }
            return Utils.formatDay(Utils.DATE_FORMAT_10.format(date));
        } else {
            return "";
        }
    }

    public String getHourAndMinString(){
        Date date = getDate();
        if(TextUtils.isEmpty(null)){
            return Utils.DATE_FORMAT_9.format(date);
        }
        return "";
    }

    public ImageInfoEntity(boolean isTitle, String title) {
        this.isTitle = isTitle;
        this.title = title;
    }

    public String getThumbUrl() {
        return preview.url + "&Authorization=" + preview.token;
    }

    public boolean isEqualWith(ImageInfoEntity imageInfoEntity) {
        if (imageInfoEntity == null) {
            return false;
        }
        if (this.imageId == imageInfoEntity.imageId &&
                this.sn.equals(imageInfoEntity.sn) &&
                this.uid.equals(imageInfoEntity.uid) &&
                this.utitle.equals(imageInfoEntity.utitle) &&
                this.src.equals(imageInfoEntity.src) &&
                this.fileName.equals(imageInfoEntity.fileName) &&
                this.playtime == imageInfoEntity.playtime &&
                this.oriName.equals(imageInfoEntity.oriName) &&
                //不比较 数据相同时 下面的url和token都会变化
//                this.preview.isEqualWith(imageInfoEntity.preview) &&
//                this.file.isEqualWith(imageInfoEntity.file) &&
//                this.down.isEqualWith(imageInfoEntity.down) &&
                this.createTime.compareTo(imageInfoEntity.createTime) == 0 &&
                this.triggerTime.equals(imageInfoEntity.triggerTime) &&
                this.ftype == imageInfoEntity.ftype &&
                this.envType == imageInfoEntity.envType) {
//                &&
//                this.isChecked == imageInfoEntity.isChecked) {
            return true;
        }
        return false;
    }

    public boolean isPhoto(){
        return ftype == 0;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeLong(this.imageId);
        dest.writeString(this.uid);
        dest.writeString(this.utitle);
        dest.writeString(this.src);
        dest.writeString(this.fileName);
        dest.writeString(this.sn);
        dest.writeInt(this.envType);
        dest.writeLong(this.playtime);
        dest.writeString(this.oriName);
        dest.writeParcelable(this.preview, flags);
        dest.writeParcelable(this.file, flags);
        dest.writeString(this.filePath);
        dest.writeParcelable(this.down, flags);
        dest.writeParcelable(this.thumbnail, flags);
        dest.writeLong(this.createTime != null ? this.createTime.getTime() : -1);
        dest.writeInt(this.ftype);
        dest.writeByte(this.isChecked ? (byte) 1 : (byte) 0);
        dest.writeByte(this.isTitle ? (byte) 1 : (byte) 0);
        dest.writeString(this.title);
        dest.writeString(this.ipcTitle);
        dest.writeString(this.triggerTime);
    }

    protected ImageInfoEntity(Parcel in) {
        super(in);
        this.imageId = in.readLong();
        this.uid = in.readString();
        this.utitle = in.readString();
        this.src = in.readString();
        this.fileName = in.readString();
        this.sn = in.readString();
        this.envType = in.readInt();
        this.playtime = in.readLong();
        this.oriName = in.readString();
        this.preview = in.readParcelable(Preview.class.getClassLoader());
        this.file = in.readParcelable(File.class.getClassLoader());
        this.filePath = in.readString();
        this.down = in.readParcelable(Down.class.getClassLoader());
        this.thumbnail = in.readParcelable(Thumbnail.class.getClassLoader());
        long tmpCreateTime = in.readLong();
        this.createTime = tmpCreateTime == -1 ? null : new Date(tmpCreateTime);
        this.ftype = in.readInt();
        this.isChecked = in.readByte() != 0;
        this.isTitle = in.readByte() != 0;
        this.title = in.readString();
        this.ipcTitle = in.readString();
        this.triggerTime = in.readString();
    }

    public static final Creator<ImageInfoEntity> CREATOR = new Creator<ImageInfoEntity>() {
        @Override
        public ImageInfoEntity createFromParcel(Parcel source) {
            return new ImageInfoEntity(source);
        }

        @Override
        public ImageInfoEntity[] newArray(int size) {
            return new ImageInfoEntity[size];
        }
    };
}
