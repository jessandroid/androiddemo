
package com.qihoo360.homecamera.mobile.activity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.Target;
import com.google.gson.Gson;
import com.qihoo360.homecamera.device.config.StoryMachineConsts;
import com.qihoo360.homecamera.mobile.BuildConfig;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.adapter.ChooseInviteWaysAdapter;
import com.qihoo360.homecamera.mobile.config.DefaultClientConfig;
import com.qihoo360.homecamera.mobile.db.PadInfoWrapper;
import com.qihoo360.homecamera.mobile.entity.AlbumShareEntity;
import com.qihoo360.homecamera.mobile.entity.DeviceInfo;
import com.qihoo360.homecamera.mobile.entity.ImageInfoEntity;
import com.qihoo360.homecamera.mobile.entity.ShareStoryEntity;
import com.qihoo360.homecamera.mobile.entity.ShareWayInfo;
import com.qihoo360.homecamera.mobile.http.OkHttpUtils;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.ImageCache;
import com.qihoo360.homecamera.mobile.utils.QHStatAgentHelper;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.utils.share.ShareToWeChatAndWeibo;
import com.sina.weibo.sdk.api.share.BaseResponse;
import com.sina.weibo.sdk.api.share.IWeiboHandler;
import com.sina.weibo.sdk.constant.WBConstants;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * 隐患:分享的包名过滤的包名是写死的,分享app包名不会变?
 *
 * @author Administrator
 */
public class PhotoShareToAppActivity extends BaseActivity implements IWeiboHandler.Response, AdapterView.OnItemClickListener, View.OnClickListener {

    private static int fromClass;
    //社交软件分享辅助类
    private ShareToWeChatAndWeibo shareToWeChatAndWeibo;

    private static boolean handledShareEvent = false;
    private RelativeLayout mCloseIv;

    public static AlbumShareEntity mediaEntity = null;

    private static ImageInfoEntity mEvent;
    private String imagePath;
    private static String mSn;

    private int choosedShareType;
    private static boolean isNeedGetInfo;

    public static void startActivity(ArrayList<ImageInfoEntity> list, Context context) {
        Intent intent = new Intent();
        intent.setComponent(new ComponentName(context, PhotoShareToAppActivity.class));
        context.startActivity(intent);
    }

    public static void startActivityFromEntity(AlbumShareEntity entity, Context context) {
        mediaEntity = entity;
        handledShareEvent = false;
        isNeedGetInfo = false;
        Intent intent = new Intent();
        intent.setComponent(new ComponentName(context, PhotoShareToAppActivity.class));
        context.startActivity(intent);
    }

    public static void startActivityFromImageEntity(ImageInfoEntity iie, Context context) {
        mEvent = iie;
        if (mEvent == null) {
            return;
        }
        mSn = mEvent.sn;
        handledShareEvent = false;
        isNeedGetInfo = true;
        Intent intent = new Intent();
        intent.setComponent(new ComponentName(context, PhotoShareToAppActivity.class));
        context.startActivity(intent);
    }


    @Override
    public void onBackPressed() {
        if (mediaEntity != null) {
            mediaEntity = null;
        }
        super.onBackPressed();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTintManagerQWork(true);
        tintManager.setTintColor(Color.parseColor("#212121"));
        setContentView(R.layout.album_photo_share_to_app);

        shareToWeChatAndWeibo = new ShareToWeChatAndWeibo(Utils.context);
        if (savedInstanceState != null) {
            if (getIntent() != null) {
                try {
                    shareToWeChatAndWeibo.handleWeiboResponse(getIntent(), this);
                } catch (Exception e){
                    e.printStackTrace();
                }

            }
        }
//        initQQData();

        initView();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (handledShareEvent) {
            finish();
        }
    }

    private void initView() {

        View bgArea = findViewById(R.id.bg_area);
        if (bgArea != null) {
            bgArea.setOnClickListener(this);
        }

        List<ShareWayInfo> list = new ArrayList<ShareWayInfo>() {
        };
        list.add(new ShareWayInfo(R.drawable.icon_wechat, getString(R.string.record_weichat)));
        list.add(new ShareWayInfo(R.drawable.icon_pengyouquan, getString(R.string.record_pengyouquan)));
        list.add(new ShareWayInfo(R.drawable.icon_sina, getString(R.string.record_sina)));
        list.add(new ShareWayInfo(R.drawable.icon_qq, getString(R.string.qq)));

        GridView cameraShareGv = (GridView) findViewById(R.id.gv_share);
        final ChooseInviteWaysAdapter adapter = new ChooseInviteWaysAdapter(this, list, list.size());
        if (cameraShareGv != null) {
            cameraShareGv.setOnItemClickListener(this);
            cameraShareGv.setNumColumns(list.size());
            cameraShareGv.setAdapter(adapter);
        }

        mCloseIv = (RelativeLayout) findViewById(R.id.iv_close);
        if (mCloseIv != null) {
            mCloseIv.setOnClickListener(this);
        }
    }

    @Override
    public void finish() {
        if (mediaEntity != null) {
            mediaEntity = null;
        }
        super.finish();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        CLog.d(TAG, "onNewIntent->shareToWeChatAndWeibo=" + shareToWeChatAndWeibo);
        if (shareToWeChatAndWeibo != null) {
            shareToWeChatAndWeibo.handleWeiboResponse(intent, this);
        }
        super.onNewIntent(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    Intent intent) {
        CLog.e("ShareToWeChatAndWeibo", "---------onActivityResult==shareToWeChatAndWeibo=" + shareToWeChatAndWeibo);
        if (shareToWeChatAndWeibo != null) {
            shareToWeChatAndWeibo.onActivityResult(requestCode, resultCode, intent);
        }
        super.onActivityResult(requestCode, resultCode, intent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (shareToWeChatAndWeibo != null) {
            shareToWeChatAndWeibo.onDestroy();
            shareToWeChatAndWeibo = null;
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.bg_area:
            case R.id.iv_close:
                finish();
                break;
        }
    }

    private void chooseModeToText(int pos) {
        CLog.i("test2", "chooseModeToText called");
        String title = null;
        String content = null;
        switch (pos) {
            case 0:
                if (mediaEntity.type == AlbumShareEntity.TYPE_IMAGE) {
                    QHStatAgentHelper.commitCommonEvent("S_Video_xg003");//小视频微信分享次数
                    title = getString(R.string.vedio_self_wx_title);
                    content = getString(R.string.vedio_self_wx_content);
                    shareToWeChatAndWeibo.shareCameraWX(mediaEntity.image, title, content, mediaEntity.url, false, true, mSn);
                } else {
                    switch (mediaEntity.type) {
                        case AlbumShareEntity.TYPE_VIDEO_CATCH:
                            QHStatAgentHelper.commitCommonEvent("S_Video_xg003");//小视频微信分享次数
                            title = getWXTitle();
                            content = getTitleByDevice();
                            break;
                        case AlbumShareEntity.TYPE_VIDEO_SELF:
                            QHStatAgentHelper.commitCommonEvent("S_Video_xg003");//小视频微信分享次数
                            title = getString(R.string.vedio_self_wx_title);
                            content = getString(R.string.vedio_self_wx_content);
                            break;
                        case AlbumShareEntity.TYPE_VIDEO_AR:
                            QHStatAgentHelper.commitCommonEvent("S_Video_xg003");//小视频微信分享次数
                            title = getString(R.string.vedio_ar_wx_title);
                            content = getString(R.string.vedio_ar_wx_content);
                            break;
                        case AlbumShareEntity.TYPE_VIDEO_LISTEN:
                            QHStatAgentHelper.commitCommonEvent("S_Record_yl011");//微信分享次数
                            title = getString(R.string.vedio_listen_wx_title);
                            content = getString(R.string.vedio_listen_wx_content);
                            break;
                        case AlbumShareEntity.TYPE_STORY:
                            QHStatAgentHelper.commitCommonEvent("S_Record_yl011");//微信分享次数
                            title = getString(R.string.story_wx_title);
                            content = getString(R.string.story_wx_content, mediaEntity.info);
                            break;
                    }
                    shareToWeChatAndWeibo.shareCameraWX(mediaEntity.image, title, content, mediaEntity.url, false, false, mSn);
                }
                QHStatAgentHelper.doVideoShareStick(QHStatAgentHelper.WECHATTYPE);
                break;
            case 1:
                if (mediaEntity.type == AlbumShareEntity.TYPE_IMAGE) {
                    title = getString(R.string.vedio_self_wx_title);
                    content = "";
                    QHStatAgentHelper.commitCommonEvent("S_Video_xg005");//小视频朋友圈分享次数
                    shareToWeChatAndWeibo.shareCameraWX(mediaEntity.image, title, content, mediaEntity.url, true, true, mSn);
                } else {
                    switch (mediaEntity.type) {
                        case AlbumShareEntity.TYPE_VIDEO_CATCH:
                            title = getTitleByDevice();
                            QHStatAgentHelper.commitCommonEvent("S_Video_xg005");//小视频朋友圈分享次数
                            content = "";
                            break;
                        case AlbumShareEntity.TYPE_VIDEO_SELF:
                            title = getString(R.string.vedio_self_wb_content);
                            QHStatAgentHelper.commitCommonEvent("S_Video_xg005");//小视频朋友圈分享次数
                            content = "";
                            break;
                        case AlbumShareEntity.TYPE_VIDEO_AR:
                            title = getString(R.string.vedio_ar_wb_content);
                            QHStatAgentHelper.commitCommonEvent("S_Video_xg005");//小视频朋友圈分享次数
                            content = "";
                            break;
                        case AlbumShareEntity.TYPE_VIDEO_LISTEN:
                            QHStatAgentHelper.commitCommonEvent("S_Record_yl013");//朋友圈分享次数
                            title = getString(R.string.vedio_listen_wb_content);
                            content = "";
                            break;
                        case AlbumShareEntity.TYPE_STORY:
                            QHStatAgentHelper.commitCommonEvent("S_Record_yl013");//朋友圈分享次数
                            title = getString(R.string.story_wx_content, mediaEntity.info);
                            content = "";
                            break;
                    }
                    shareToWeChatAndWeibo.shareCameraWX(mediaEntity.image, title, content, mediaEntity.url, true, false, mSn);
                }
                QHStatAgentHelper.doVideoShareStick(QHStatAgentHelper.MOMENTSTYPE);
                break;
            case 2:
                if (mediaEntity != null) {
                    if (mediaEntity.type == AlbumShareEntity.TYPE_IMAGE) {
                        content = getString(R.string.vedio_self_wb_content);
                        shareToWeChatAndWeibo.shareCameraWB(mediaEntity.image, content, mediaEntity.url, this, true, mSn);
                        QHStatAgentHelper.commitCommonEvent("S_Video_xg007");//小视频微博分享次数

                    } else {
                        switch (mediaEntity.type) {
                            case AlbumShareEntity.TYPE_VIDEO_CATCH:
                                content = getTitleByDevice();
                                QHStatAgentHelper.commitCommonEvent("S_Video_xg007");//小视频微博分享次数
                                break;
                            case AlbumShareEntity.TYPE_VIDEO_SELF:
                                content = getString(R.string.vedio_self_wb_content);
                                QHStatAgentHelper.commitCommonEvent("S_Video_xg007");//小视频微博分享次数
                                break;
                            case AlbumShareEntity.TYPE_VIDEO_AR:
                                content = getString(R.string.vedio_ar_wb_content);
                                QHStatAgentHelper.commitCommonEvent("S_Video_xg007");//小视频微博分享次数
                                break;
                            case AlbumShareEntity.TYPE_VIDEO_LISTEN:
                                content = getString(R.string.vedio_listen_wb_content);
                                QHStatAgentHelper.commitCommonEvent("S_Record_yl015");//微博分享次数
                                break;
                            case AlbumShareEntity.TYPE_STORY:
                                content = getString(R.string.story_wx_content, mediaEntity.info);
                                QHStatAgentHelper.commitCommonEvent("S_Record_yl015");//微博分享次数
                                break;
                        }
                        shareToWeChatAndWeibo.shareCameraWB(mediaEntity.image, content, mediaEntity.url, this, false, mSn);
                    }
                }
                QHStatAgentHelper.doVideoShareStick(QHStatAgentHelper.WEIBOTYPE);
                break;
            case 3:
                if (mediaEntity.type == AlbumShareEntity.TYPE_IMAGE) {
                    title = getString(R.string.vedio_self_wx_title);
                    content = getString(R.string.vedio_self_wx_content);
                    shareToWeChatAndWeibo.shareCameraQQ(mediaEntity.image, title, content, mediaEntity.url, this, true);
                    QHStatAgentHelper.commitCommonEvent("S_Video_xg009");//小视频QQ分享次数

                } else {
                    switch (mediaEntity.type) {
                        case AlbumShareEntity.TYPE_VIDEO_CATCH:
                            title = getString(R.string.vedio_catch_wx_title);
                            content = getTitleByDevice();
                            QHStatAgentHelper.commitCommonEvent("S_Video_xg009");//小视频QQ分享次数
                            break;
                        case AlbumShareEntity.TYPE_VIDEO_SELF:
                            title = getString(R.string.vedio_self_wx_title);
                            content = getString(R.string.vedio_self_wx_content);
                            QHStatAgentHelper.commitCommonEvent("S_Video_xg009");//小视频QQ分享次数
                            break;
                        case AlbumShareEntity.TYPE_VIDEO_AR:
                            title = getString(R.string.vedio_ar_wx_title);
                            content = getString(R.string.vedio_ar_wx_content);
                            QHStatAgentHelper.commitCommonEvent("S_Video_xg009");//小视频QQ分享次数
                            break;
                        case AlbumShareEntity.TYPE_VIDEO_LISTEN:
                            title = getString(R.string.vedio_listen_wx_title);
                            content = getString(R.string.vedio_listen_wx_content);
                            QHStatAgentHelper.commitCommonEvent("S_Record_yl017");//QQ分享次数
                            break;
                        case AlbumShareEntity.TYPE_STORY:
                            title = getString(R.string.story_wx_title);
                            content = getString(R.string.story_wx_content, mediaEntity.info);
                            QHStatAgentHelper.commitCommonEvent("S_Record_yl017");//QQ分享次数
                            break;
                    }
                    shareToWeChatAndWeibo.shareCameraQQ(mediaEntity.image, title, content, mediaEntity.url, this, false);
                }
                QHStatAgentHelper.doVideoShareStick(QHStatAgentHelper.QQTYPE);
                break;
            default:
                break;
        }
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        choosedShareType = i;
        if (isNeedGetInfo) {
            getShareInfo();
        } else {
            chooseModeToText(choosedShareType);
        }
        handledShareEvent = true;
    }

    @Override
    public void onResponse(BaseResponse baseResponse) {
        switch (baseResponse.errCode) {
            case WBConstants.ErrorCode.ERR_OK:
                CLog.d(TAG, "onResponse-?>ERR_OK");
                CameraToast.showToast(this, R.string.share_weibo_send_success);
                break;
            case WBConstants.ErrorCode.ERR_CANCEL:
                CLog.d(TAG, "onResponse-?>ERR_CANCEL");
                CameraToast.showToast(this, R.string.share_weibo_send_cancel);
                break;
            case WBConstants.ErrorCode.ERR_FAIL:
                CLog.d(TAG, "onResponse-?>ERR_FAIL");
                CameraToast.showToast(this, R.string.share_weibo_send_failed);
                break;
        }
    }

    public void getShareInfo() {
        if (!Utils.isNetworkAvailable(this)) {
            CameraToast.show(getString(R.string.network_disabled), Toast.LENGTH_SHORT);
            return;
        }

        if (mEvent != null) {
            //TODO  产品不让显示这个
//            showTipsDialog(getString(R.string.getting_share_url), R.drawable.icon_loading, 10000, true);
            imagePath = null;
            Observable.create(new Observable.OnSubscribe<ShareStoryEntity>() {
                @Override
                public void call(Subscriber<? super ShareStoryEntity> subscriber) {
                    String iPath = null;
                    if (mEvent.ftype == 0) {
                        iPath = ImageCache.getInstance().checkCache(mEvent.fileName, ImageCache.ORIGINAL);
                        if (TextUtils.isEmpty(iPath)) {
                            iPath = mEvent.file.url + "&Authorization=" + mEvent.file.token;
                        }
                    } else {
                        iPath = ImageCache.getInstance().checkCache(mEvent.fileName, ImageCache.PREVIEW);
                        if (TextUtils.isEmpty(iPath)) {
                            iPath = mEvent.preview.url + "&Authorization=" + mEvent.preview.token;
                        }
                    }

                    try {
                        File file = Glide.with(Utils.context)
                                .load(iPath)
                                .downloadOnly(Target.SIZE_ORIGINAL, Target.SIZE_ORIGINAL).get();
                        if (file != null) {
                            imagePath = file.getAbsolutePath();//makeWaterMark(file.getAbsolutePath());
                        }
                    } catch (InterruptedException e) {
                    } catch (ExecutionException e) {
                    }

                    if (imagePath != null) {
                        if (mEvent.ftype == 0) {
                            subscriber.onNext(null);
                        } else {
                            //分享视频
                            Map<String, String> param = new HashMap<String, String>();
                            param.put("sn", mSn);
                            param.put("id", String.valueOf(mEvent.imageId));
                            param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                            String responseStr = OkHttpUtils.post().params(param).headers(null).url(DefaultClientConfig.SHARE_STORY_URL).build().execute();
                            Gson gson = new Gson();
                            ShareStoryEntity shareStoryEntity = gson.fromJson(responseStr, ShareStoryEntity.class);
                            if (shareStoryEntity != null && shareStoryEntity.errorCode == 0) {
                                subscriber.onNext(shareStoryEntity);
                            } else {
                                subscriber.onError(new Throwable(responseStr));
                            }
                        }
                    } else {
                        subscriber.onError(new Throwable());
                    }
                    subscriber.onCompleted();
                }
            }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Subscriber<ShareStoryEntity>() {
                @Override
                public void onCompleted() {
                    hideTipsDialog();
                }

                @Override
                public void onError(Throwable e) {
                    hideTipsDialog();

                    CameraToast.show(Utils.getContext(), R.string.get_share_url_fail, Toast.LENGTH_LONG);
                }

                @Override
                public void onNext(ShareStoryEntity shareStoryEntity) {
                    hideTipsDialog();

                    mediaEntity = new AlbumShareEntity();
                    if (mEvent.ftype == 0) {
                        mediaEntity.type = AlbumShareEntity.TYPE_IMAGE;
                    } else {
                        if (mEvent.envType > 0)
                            mediaEntity.type = mEvent.envType;
                        else
                            mediaEntity.type = AlbumShareEntity.TYPE_VIDEO_CATCH;
                    }
                    mediaEntity.image = imagePath;
                    if (mEvent.ftype == 0) {
                        mediaEntity.url = null;
                    } else {
                        String url = shareStoryEntity.getShareUrl(String.valueOf(mEvent.imageId), "album", mSn);
                        mediaEntity.url = url;
                    }
                    chooseModeToText(choosedShareType);
                }
            });
        } else {
            CameraToast.showToast(this, "数据异常");
        }
    }

    private String getTitleByDevice(){
        if(!TextUtils.isEmpty(mSn)){
            DeviceInfo deviceInfo = PadInfoWrapper.getInstance().getPadBySn(mSn);
            if(deviceInfo.isStoryMachine()){
                return getString(R.string.vedio_catch_wx_content_machine);
            }else{
                getString(R.string.vedio_catch_wx_content);
            }
        }
        return getString(R.string.vedio_catch_wx_content);
    }

    private String getWXTitle(){
        if(!TextUtils.isEmpty(mSn)){
            DeviceInfo deviceInfo = PadInfoWrapper.getInstance().getPadBySn(mSn);
            if(deviceInfo.isStoryMachine()){
                return getString(R.string.vedio_catch_wx_title_machine);
            }else{
                getString(R.string.vedio_catch_wx_title);
            }
        }
        return getString(R.string.vedio_catch_wx_title);
    }
}
