
package com.qihoo360.homecamera.mobile.core.manager;

/**
 * 图片压缩
 * Created by Administrator on 2015/4/20.
 */
public class CompressManager {


    private static final int REQUEST_CODE = 0x0001;

    static {
        System.loadLibrary("image");
    }


    public native  boolean processImage(String inFilePath, String outFilePath,int quality);

}
