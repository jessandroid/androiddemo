
package com.qihoo360.homecamera.mobile.core.beans;

import java.io.Serializable;

public class CallInfo implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = -8908091762914224540L;

    public int callType; // 1,双向；2，监控

    public String targetName;

    public String targetNumber;

    public String avatarUrl;


}
