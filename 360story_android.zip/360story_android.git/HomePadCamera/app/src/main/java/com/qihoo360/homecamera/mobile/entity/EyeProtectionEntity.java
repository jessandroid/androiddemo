package com.qihoo360.homecamera.mobile.entity;

/**
 * Created by zhaojunbo on 2016/9/2.
 * desc:
 */
public class EyeProtectionEntity {

    public String usingTime;
    public String restTime;
    public String isOpen;

}
