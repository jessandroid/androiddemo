
package com.qihoo360.homecamera.mobile.http.builder;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.MediaType;
import okhttp3.RequestBody;
import okhttp3.internal.Util;
import okio.Buffer;
import okio.BufferedSink;

/**
 * This class is 4 the json
 * User: Administrator
 * Date: 2016/1/29
 * Time: 12:09
 * To change this template use File | Settings | File Templates.
 */
public class NewFormBody extends RequestBody {

    public static final MediaType CONTENT_TYPE = MediaType.parse("application/json; charset=utf-8");

    private final List<String> encodedNames;
    private final List<String> encodedValues;

    private NewFormBody(List<String> encodedNames, List<String> encodedValues) {
        this.encodedNames = Util.immutableList(encodedNames);
        this.encodedValues = Util.immutableList(encodedValues);
    }

    public int size() {
        return this.encodedNames.size();
    }

    public MediaType contentType() {
        return CONTENT_TYPE;
    }

    public long contentLength() {
        return this.writeOrCountBytes((BufferedSink) null, true);
    }

    public void writeTo(BufferedSink sink) throws IOException {
        this.writeOrCountBytes(sink, false);
    }

    public List<String> getEncodedValues() {
        return encodedValues;
    }

    public List<String> getEncodedNames() {
        return encodedNames;
    }

    private long writeOrCountBytes(BufferedSink sink, boolean countBytes) {
        long byteCount = 0L;
        Buffer buffer;
        if (countBytes) {
            buffer = new Buffer();
        } else {
            buffer = sink.buffer();
        }

        int i = 0;

        for (int size = this.encodedNames.size(); i < size; ++i) {
            if (i > 0) {
                buffer.writeByte(38);
            }
            buffer.writeUtf8(this.encodedNames.get(i));
            buffer.writeByte(61);
            buffer.writeUtf8(this.encodedValues.get(i));
        }

        if (countBytes) {
            byteCount = buffer.size();
            buffer.clear();
        }

        return byteCount;
    }

    public static final class Builder {
        private final List<String> names = new ArrayList();
        private final List<String> values = new ArrayList();

        public Builder() {
        }

        public NewFormBody.Builder add(String name, String value) {
            this.names.add(name);
            this.values.add(value);
            return this;
        }

        public NewFormBody.Builder addEncoded(String name, String value) {
            this.names.add(name);
            this.values.add(value);
            return this;
        }

        public NewFormBody build() {
            return new NewFormBody(this.names, this.values);
        }
    }

}
