package com.qihoo360.homecamera.mobile.callback;

import android.content.Context;
import android.graphics.Bitmap;

import com.qihoo360.accounts.api.auth.model.UserTokenInfo;

/**
 * When Login
 * Created by Administrator on 2014/11/10.
 */
public interface LoginUiHandler {
    Context getApplicationContext();

    void onNeedCaptcha();
    void handleCaptchaSuccess();
    void handleCaptchaError(int errorCode);
    void handleNeedDynamicPwd(String errorMsg);

    String getUserCaptcha();
    void showCaptchaView(Bitmap bitmap);

    void handleLoginSuccess(UserTokenInfo info, String sessionId, String pushKey, String A, String B, String C);
    void handleLoginError(int errorType, int errorCode, String errorMessage);
}
