
package com.qihoo360.homecamera.mobile.adapter;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.justalk.cloud.lemon.MtcCall;
import com.justalk.cloud.lemon.MtcCallConstants;
import com.justalk.cloud.lemon.MtcCli;
import com.justalk.cloud.lemon.MtcCliConstants;
import com.justalk.cloud.lemon.MtcUser;
import com.justalk.cloud.lemon.MtcUserConstants;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.activity.OutgoingCallActivity;
import com.qihoo360.homecamera.mobile.activity.VideoCallInnerActivity;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.entity.CallInfoEntity;
import com.qihoo360.homecamera.mobile.entity.DeviceInfo;
import com.qihoo360.homecamera.mobile.interfaces.CameraSettingCallBack;
import com.qihoo360.homecamera.mobile.ui.NewSwitchView;
import com.qihoo360.homecamera.mobile.ui.dialog.BaseDialogFactory;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CameraToast;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

/**
 * ----------Dragon be here!----------/
 * 　　　┏┓　　　┏┓
 * 　　┏┛┻━━━┛┻┓
 * 　　┃　　　　　　　┃
 * 　　┃　　　━　　　┃
 * 　　┃　┳┛　┗┳　┃
 * 　　┃　　　　　　　┃
 * 　　┃　　　┻　　　┃
 * 　　┃　　　　　　　┃
 * 　　┗━┓　　　┏━┛
 * 　　　　┃　　　┃神兽保佑
 * 　　　　┃　　　┃代码无BUG！
 * 　　　　┃　　　┗━━━┓
 * 　　　　┃　　　　　　　┣┓
 * 　　　　┃　　　　　　　┏┛
 * 　　　　┗┓┓┏━┳┓┏┛
 * 　　　　　┃┫┫　┃┫┫
 * 　　　　　┗┻┛　┗┻┛
 * ━━━━━━神兽出没━━━━━━by:tomcat
 */
public class VideoCallAdapter extends BaseAdapter implements OnClickListener {

    public WeakReference<Activity> activityWeakReference;
    private final Context mContext;
    public CameraSettingCallBack cameraSettingCallBack;
    private ArrayList<DeviceInfo> mList = new ArrayList<DeviceInfo>();
    private NewSwitchView mSwitchView;
    private boolean isChecked;

    public VideoCallAdapter(Context context, CameraSettingCallBack cameraSettingCallBack) {
        if (context != null) {
            activityWeakReference = new WeakReference<Activity>((Activity) context);
        }
        mContext = activityWeakReference.get();
        this.cameraSettingCallBack = cameraSettingCallBack;
    }

    public void setAdapterData(ArrayList<DeviceInfo> list) {
        mList = list;
        notifyDataSetChanged();
        CLog.i(mList.size() + "");
    }

    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public Object getItem(int position) {
        return mList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = View.inflate(mContext, R.layout.video_call_item, null);

            holder.screenImageView = (ImageView) convertView.findViewById(R.id.device_screen);
            holder.mPic = (RelativeLayout) convertView.findViewById(R.id.video_call_item_layout2);
            holder.mSetting = (ImageView) convertView.findViewById(R.id.video_call_item_setting);
            holder.mDel = (ImageView) convertView.findViewById(R.id.video_call_item_del);
            holder.mAddress = (TextView) convertView.findViewById(R.id.video_call_item_address);
            holder.mSwitchLinearLayout = (LinearLayout) convertView.findViewById(R.id.video_call_item_layout3);
            holder.mSwitchLinearLayout.addView(holder.switchView);
            holder.mName = (TextView) convertView.findViewById(R.id.video_call_item_name);
            holder.mTime = (TextView) convertView.findViewById(R.id.video_call_item_time);
            holder.mDayCount = (TextView) convertView.findViewById(R.id.video_call_item_day_count);
/*            holder.mBluelayout = (RelativeLayout) convertView.findViewById(R.id.video_call_item_layout4);
            holder.mRedlayout = (RelativeLayout) convertView.findViewById(R.id.video_call_item_layout5);*/
            holder.mShare = (TextView) convertView.findViewById(R.id.tv_paramaters_change);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        final DeviceInfo dInfo = mList.get(position);

        if (dInfo.getRole() == 1) {
            holder.mDel.setVisibility(View.GONE);
            holder.mSetting.setVisibility(View.VISIBLE);
        } else {
            holder.mDel.setVisibility(View.VISIBLE);
            holder.mSetting.setVisibility(View.GONE);
        }
        holder.mAddress.setText(dInfo.getTitle());

        final String uriString = TextUtils.isEmpty(dInfo.getLocalCoverImg()) ? dInfo.getCoverUrl() : dInfo.getLocalCoverImg();
        CLog.d(uriString);
        Glide.with(mContext)
                .load(uriString)
                .placeholder(R.drawable.ic_launcher)
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .skipMemoryCache(true)
                .priority(Priority.HIGH)
                .error(R.drawable.ic_launcher)
                .into(holder.screenImageView);
        CLog.e("call_inner", dInfo.getCoverUrl() + ":" + dInfo.getLocalCoverImg());
        CLog.e("call_inner", "choice:" + uriString);
        holder.mAddress.setText(dInfo.getTitle());
        holder.screenImageView.setOnClickListener(this);
        holder.screenImageView.setTag(dInfo);
        holder.mSetting.setOnClickListener(this);
        holder.mSetting.setTag(dInfo);
        holder.mDel.setOnClickListener(this);
        holder.mDel.setTag(dInfo);
        holder.mPic.setOnClickListener(this);
//        holder.mBluelayout.setOnClickListener(this);
//        holder.mRedlayout.setOnClickListener(this);
        holder.mShare.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
        if (holder.switchView != null) {
            holder.switchView.setOnCheckedChangeListener(new NewSwitchView.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(boolean isChecked) {
                    if (!isChecked) {
                        return;
                    }

                    if (MtcCli.Mtc_CliGetState() == MtcCliConstants.EN_MTC_CLI_STATE_LOGINED) {
                        Intent outGoingCallIntent = new Intent(mContext, OutgoingCallActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putParcelable("deviceInfo", dInfo);
                        outGoingCallIntent.putExtras(bundle);
                        mContext.startActivity(outGoingCallIntent);

                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                String uri = MtcUser.Mtc_UserFormUri(
                                        MtcUserConstants.EN_MTC_USER_ID_USERNAME, dInfo.getSn());//13221690634//401000000017
                                JSONObject jsonObject = new JSONObject();
                                try {
                                    jsonObject.put(MtcCall.MtcCallInfoHasVideoKey, true);
                                    jsonObject.put(MtcCall.MtcCallInfoDisplayNameKey, "dddd");
                                    jsonObject.put(MtcCall.MtcCallInfoPeerDisplayNameKey,
                                            "bbb");
                                    jsonObject.put(MtcCallConstants.MtcCallInfoServerUserDataKey, "{\"callType\":\"0\"}");
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                Constants.CALL_TYPE = Constants.NON_AUTO_CALL;
                                int result = MtcCall.Mtc_CallJ(uri, 0, jsonObject.toString());
                                Constants.CallState.put(result, new CallInfoEntity(dInfo.getSn(), Constants.NON_AUTO_CALL));
                            }
                        }).start();
                    } else {
                        CameraToast.show("视频通话服务连接中...", Toast.LENGTH_SHORT);
                        holder.switchView.setChecked(true);
                    }

                    mSwitchView = holder.switchView;
                }
            });
        }
        return convertView;
    }

    public void restorePosition() {
        if (mSwitchView != null) {
            mSwitchView.setChecked(true);
        }
    }

    private static class ViewHolder {
        private ImageView mSetting; // 设置

        private ImageView screenImageView;

        private TextView mAddress; // 连接对方的标题

        private RelativeLayout mPic; // 顶部展示的图片

        private LinearLayout mSwitchLinearLayout; // 视频滑动块

        private TextView mTime; // 来电时间

//        private RelativeLayout mBluelayout; // 蓝色背景的Layout
//
//        private RelativeLayout mRedlayout; // 红色背景的Layout

        private TextView mName; // 来自XX的名字

        private TextView mDayCount; // 天数

        private ImageView mGoBuy; // 到商城购买

        private TextView mShare; // 分享

        private ImageView mDel;

        private NewSwitchView switchView;
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.device_screen: {
                if (MtcCli.Mtc_CliGetState() == MtcCliConstants.EN_MTC_CLI_STATE_LOGINED) {
                    final DeviceInfo dInfo = (DeviceInfo) v.getTag();
                    Intent videoCallInnerIntent = new Intent(mContext, VideoCallInnerActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putParcelable("deviceInfo", dInfo);
                    videoCallInnerIntent.putExtras(bundle);
                    mContext.startActivity(videoCallInnerIntent);
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            String uri = MtcUser.Mtc_UserFormUri(
                                    MtcUserConstants.EN_MTC_USER_ID_USERNAME, dInfo.getSn());//13221690634//401000000017
                            JSONObject jsonObject = new JSONObject();
                            try {
                                jsonObject.put(MtcCall.MtcCallInfoHasVideoKey, true);
                                jsonObject.put(MtcCall.MtcCallInfoDisplayNameKey, "dddd");
                                jsonObject.put(MtcCall.MtcCallInfoPeerDisplayNameKey,
                                        "bbb");
                                jsonObject.put(MtcCallConstants.MtcCallInfoServerUserDataKey, "{\"callType\":\"1\"}");
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            Constants.CALL_TYPE = Constants.AUTO_CALL;
                            int result = MtcCall.Mtc_CallJ(uri, 0, jsonObject.toString());
                            Constants.CallState.put(result, new CallInfoEntity(dInfo.getSn(), Constants.AUTO_CALL));
                        }
                    }).start();
                } else {
                    CameraToast.show("视频通话服务连接中...", Toast.LENGTH_SHORT);
                }

                break;
            }
            case R.id.video_call_item_layout2:// 顶部展示的图片的Layout
                CLog.i("顶部展示的图片的Layout");
                break;

            case R.id.video_call_item_layout4:// 蓝色背景的Layout
                CLog.i("蓝色背景的Layout");
                break;

            case R.id.video_call_item_layout5:// 红色背景的Layout
                CLog.i("红色背景的Layout");
                break;
            case R.id.video_call_item_setting: {// 设置
                CLog.i("设置");
                /**
                 *TODO 原来这里是弹出删除或者解绑的dialog
                 * modify by tomcat
                 * 修改为暂时跳转一个设置的activity
                 */
                /*   DeviceInfo dInfos = (DeviceInfo) v.getTag();
                   removeDeviceDialog(dInfos);*/

                DeviceInfo dInfo = (DeviceInfo) v.getTag();
                this.cameraSettingCallBack.setting(dInfo);

                break;

            }
            case R.id.video_call_item_del:
                DeviceInfo dInfo = (DeviceInfo) v.getTag();
                this.cameraSettingCallBack.del(dInfo);
                break;
            default:
                CLog.i("default!!! :");
                break;
        }

    }

    /**
     * 删除设备对话框
     */
    private BaseDialogFactory dialogFactory;

    private void removeDeviceDialog(final DeviceInfo dInfo) {
        if (dialogFactory != null) {
            dialogFactory.destory();
            dialogFactory = null;
        }
        dialogFactory = new BaseDialogFactory(mContext, R.layout.remove_device_dialog);
        Dialog mDialog = dialogFactory.createDialog();
        mDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {

            @Override
            public void onCancel(DialogInterface dialog) {

                dialogFactory = null;
            }
        });
        View view = dialogFactory.getDialogContentView();
        TextView btnOK = (TextView) view.findViewById(R.id.remove_device_dialog_ok);
        TextView btnCancle = (TextView) view.findViewById(R.id.remove_device_dialog_cancel);

        btnOK.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
//                GlobalManager.getInstance().getCameraManager().asyncLoadUnBindDevice(dInfo.getSn());
                dialogFactory.destory();
            }
        });
        btnCancle.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                dialogFactory.destory();
            }
        });
        dialogFactory.show();
    }

}
