package com.qihoo360.homecamera.machine.popwin;


import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qihoo360.homecamera.machine.fragment.StoryPlayerFragment;
import com.qihoo360.homecamera.mobile.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lixin3-s on 2016/11/16.
 */
public abstract class BaseDialog extends BasePopWin implements View.OnClickListener {

    private TextView mTextOk,mTextCancel;
    private View mViewDivider;
    protected boolean isOnlyShowOkButton;
    private ButtonClickListener mListener;
    protected View containerView;
    protected LinearLayout mLLContainer;
    public BaseDialog(StoryPlayerFragment fragment, View parent) {
        this(fragment, parent, false);
    }

    public BaseDialog(StoryPlayerFragment fragment, View parent, boolean onlyShowOkButton) {
        super(fragment.getActivity(), parent);
        isOnlyShowOkButton = onlyShowOkButton;
    }

    @Override
    int getLayoutId() {
        return R.layout.machine_dialog_base_layout;
    }

    @Override
    void initView() {
        mTextOk = (TextView) contentView.findViewById(R.id.text_machine_dialog_ok);
        mTextCancel = (TextView) contentView.findViewById(R.id.text_machine_dialog_cancel);
        mViewDivider = contentView.findViewById(R.id.view_machine_dialog_divider);
        mLLContainer = (LinearLayout) contentView.findViewById(R.id.ll_machine_dialog_container);
        updateNavButton();
    }

    protected void setContainer(int layoutId) {
        containerView = LayoutInflater.from(context).inflate(layoutId,null);
        mLLContainer.addView(containerView);
        initContainerView();
    }

    abstract void initContainerView() ;
    private void updateNavButton() {
        if (isOnlyShowOkButton) {
            mTextOk.setVisibility(View.VISIBLE);
            mTextCancel.setVisibility(View.GONE);
            mViewDivider.setVisibility(View.GONE);
        } else {
            mTextOk.setVisibility(View.VISIBLE);
            mTextCancel.setVisibility(View.VISIBLE);
            mViewDivider.setVisibility(View.VISIBLE);
        }
    }

    public void setButton(String ok,String cancel, ButtonClickListener listener) {
        if (ok != null) {
            mTextOk.setText(ok);
        }
        if (cancel != null) {
            mTextCancel.setText(cancel);
        }
        this.mListener = listener;
        mTextOk.setOnClickListener(this);
        mTextCancel.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.text_machine_dialog_ok :
                if (mListener != null) {
                    mListener.onClick(true);
                }
            break;
            case R.id.text_machine_dialog_cancel :
                if (mListener != null) {
                    mListener.onClick(false);
                }
            break;
        }
    }

    public interface ButtonClickListener {
        void onClick(boolean isOk);
    }
}
