
package com.qihoo360.homecamera.mobile.http.builder;

import com.qihoo360.homecamera.mobile.config.DefaultClientConfig;
import com.qihoo360.homecamera.mobile.http.request.GetRequest;
import com.qihoo360.homecamera.mobile.http.request.RequestCall;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by zhy on 15/12/14.
 */
public class GetBuilder extends OkHttpRequestBuilder {

    private boolean cookie = true;
    private boolean https = true;
    private String upUrl ;
    private  boolean isStatic;

    @Override
    public RequestCall build() {
        if (params != null && DefaultClientConfig.IS_HTTP_GET) {
            url = appendParams(url, params);
        }
        return new GetRequest(url, tag, params, headers,cookie).build();
    }

    @Override
    public OkHttpRequestBuilder isDebug(boolean debug) {
        this.debug = debug;
        return this;
    }

    @Override
    public OkHttpRequestBuilder isHttps(boolean https) {
        this.https = https;
        return this;
    }

    @Override
    public OkHttpRequestBuilder isLogUpload(String up) {
        this.upUrl = up;
        return this;
    }


    public GetBuilder withOutCookie(){
        this.cookie = false;
        return this;
    }

    public GetBuilder httpsRequest(boolean https){
        this.https  = https;
        return this;
    }

    private String appendParams(String url, Map<String, String> params) {
        StringBuilder sb = new StringBuilder();
        sb.append(url + "?");
        if (params != null && !params.isEmpty()) {
            for (String key : params.keySet()) {
                sb.append(key).append("=").append(params.get(key)).append("&");
            }
        }
        sb = sb.deleteCharAt(sb.length() - 1);
        return sb.toString();
    }

    @Override
    public GetBuilder url(String url) {
        if (isStatic){
            this.url = url;
        }else {
            this.url = Utils.getUrl(url, this.https);
        }
        return this;
    }

    @Override
    public OkHttpRequestBuilder isStatic(boolean isStatic) {
        this.isStatic = isStatic;
        return this;
    }


    @Override
    public GetBuilder tag(Object tag) {
        this.tag = tag;
        return this;
    }

    @Override
    public GetBuilder addParams(String key, String val) {
        if (this.params == null) {
            params = new LinkedHashMap<String, String>();
        }
        params.put(key, val);
        return this;
    }

    @Override
    public GetBuilder addHeader(String key, String val) {
        if (this.headers == null) {
            headers = new LinkedHashMap<String, String>();
        }
        headers.put(key, val);
        return this;
    }
}
