package com.qihoo360.homecamera.machine.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by zhangtao-iri on 2016/12/20.
 */
public class LocalSetting extends BaseCmdReceipt implements Parcelable{

    public Data localSettings;

    public static class Data implements Parcelable{

        public String circulation; //single-单曲循环，list-列表循环

        public int childlock;   //童锁开关，1-锁定，0解锁

        public long shutdownDelaySeconds; //// 关闭为-1，0相当于立即关机

        public int volume_max;

        public int led_indicator;

        public String getCirculation() {
            return circulation;
        }

        public void setCirculation(String circulation) {
            this.circulation = circulation;
        }

        public long getShutdownDelaySeconds() {
            return shutdownDelaySeconds;
        }

        public void setShutdownDelaySeconds(long shutdownDelaySeconds) {
            this.shutdownDelaySeconds = shutdownDelaySeconds;
        }

        public int getChildlock() {
            return childlock;
        }

        public void setChildlock(int childlock) {
            this.childlock = childlock;
        }

        public int getLed_indicator() {
            return led_indicator;
        }

        public void setLed_indicator(int led_indicator) {
            this.led_indicator = led_indicator;
        }

        public int getVolume_max() {
            return volume_max;
        }

        public void setVolume_max(int volume_max) {
            this.volume_max = volume_max;
        }

        public Data() {
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(this.circulation);
            dest.writeInt(this.childlock);
            dest.writeLong(this.shutdownDelaySeconds);
            dest.writeInt(this.volume_max);
            dest.writeInt(this.led_indicator);
        }

        protected Data(Parcel in) {
            this.circulation = in.readString();
            this.childlock = in.readInt();
            this.shutdownDelaySeconds = in.readLong();
            this.volume_max = in.readInt();
            this.led_indicator = in.readInt();
        }

        public static final Creator<Data> CREATOR = new Creator<Data>() {
            @Override
            public Data createFromParcel(Parcel source) {
                return new Data(source);
            }

            @Override
            public Data[] newArray(int size) {
                return new Data[size];
            }
        };
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(this.localSettings, flags);
    }

    public LocalSetting() {
    }

    protected LocalSetting(Parcel in) {
        this.localSettings = in.readParcelable(Data.class.getClassLoader());
    }

    public static final Creator<LocalSetting> CREATOR = new Creator<LocalSetting>() {
        @Override
        public LocalSetting createFromParcel(Parcel source) {
            return new LocalSetting(source);
        }

        @Override
        public LocalSetting[] newArray(int size) {
            return new LocalSetting[size];
        }
    };
}
