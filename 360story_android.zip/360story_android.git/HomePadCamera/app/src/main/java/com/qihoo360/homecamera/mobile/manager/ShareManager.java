package com.qihoo360.homecamera.mobile.manager;

import android.app.Application;
import android.text.TextUtils;

import com.qihoo360.homecamera.machine.config.MachineDebugConfig;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionPublisherWithThreadPoolBase;
import com.qihoo360.homecamera.mobile.core.manager.workpool.PoolThreadFactory;
import com.qihoo360.homecamera.mobile.core.net.Api;
import com.qihoo360.homecamera.mobile.core.net.MachineApi;
import com.qihoo360.homecamera.mobile.db.CommonWrapper;
import com.qihoo360.homecamera.mobile.entity.DeviceInfo;
import com.qihoo360.homecamera.mobile.entity.Head;
import com.qihoo360.homecamera.mobile.entity.ShareAcceptEntity;
import com.qihoo360.homecamera.mobile.entity.ShareGetInfoEntity;
import com.qihoo360.homecamera.mobile.entity.ShareGetListEntity;
import com.qihoo360.homecamera.mobile.entity.ShareGetSharingListEntitiy;
import com.qihoo360.homecamera.mobile.entity.ShareShareEntity;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.util.Date;
import java.util.concurrent.Executors;

/**
 * Created by zhaojunbo on 2016/1/21.
 * desc:
 */
public class ShareManager extends ActionPublisherWithThreadPoolBase {

    private final String mPoolNameHighPriority, mPoolNameLowPriority;
    private final Application mApp;

    public ShareManager(Application app) {
        this.mApp = app;
        mPoolNameHighPriority = "ShareManager-high-priority-" + Utils.DATE_FORMAT_3.format(new Date());
        mPoolNameLowPriority = "ShareManager-low-priority-" + Utils.DATE_FORMAT_3.format(new Date());
        mThreadPool.initPool(mPoolNameHighPriority, Executors.newFixedThreadPool(3));
        mThreadPool.initPool(mPoolNameLowPriority,
                Executors.newCachedThreadPool(new PoolThreadFactory(mPoolNameLowPriority)));
    }

    public void asyncShareShare(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("ShareShare", args));
    }

    public void asyncShareGetInfo(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("ShareGetInfo", args));
    }

    public void asyncShareAccept(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("ShareAccept", args));
    }

    public void asyncShareCancel(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("ShareCancel", args));
    }

    public void asyncShareCancelSharing(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("ShareCancelSharing", args));
    }

    public void asyncShareGetList(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("ShareGetList", args));
    }

    public void asyncShareGetSharingList(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("ShareGetSharingList", args));
    }

    public void asyncShareFriendDevice(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("ShareFriendDevice", args));
    }

    public void asyncShareFriendCancel(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("ShareFriendCancel", args));
    }

    public void asyncShareSetRemark(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("ShareSetRemark", args));
    }

    @Override
    protected void asyncDoNamedJob(String jobName, Object... args) {
        if (TextUtils.equals(jobName, "ShareShare")) {
            if (args.length == 6) {
                doShareShare((String) args[0], (String) args[1], (String) args[2], (String) args[3], (String) args[4], (String)args[5]);
            } else if (args.length == 5) {
                doShareShare((String) args[0], (String) args[1], (String) args[2], (String) args[3], (String) args[4]);
            } else {
                doShareShare((String) args[0], (String) args[1], (String) args[2], (String)args[3]);
            }
        } else if (TextUtils.equals(jobName, "ShareGetInfo")) {
            doShareGetInfo((String) args[0]);
        } else if (TextUtils.equals(jobName, "ShareAccept")) {
            if (args.length == 6) {
                doShareAccept((String) args[0], (String) args[1], (String) args[2], (String) args[3], (String) args[4], (String) args[5]);
            } else {
                doShareAccept((String) args[0], (String) args[1], (String) args[2], (String) args[3], (String) args[4]);
            }

        } else if (TextUtils.equals(jobName, "ShareCancel")) {
            if (args.length == 2) {
                doShareCancel((String) args[0], (String) args[1]);
            } else {
                doShareCancel((String) args[0], (String) args[1], (String) args[2]);
            }

        } else if (TextUtils.equals(jobName, "ShareCancelSharing")) {
            doShareCancelSharing((String) args[0], (String) args[1]);
        } else if (TextUtils.equals(jobName, "ShareGetList")) {
            doShareGetList((String) args[0], (String) args[1], (String) args[2]);
        } else if (TextUtils.equals(jobName, "ShareGetSharingList")) {
            doShareGetSharingList((String) args[0]);
        } else if (TextUtils.equals(jobName, "ShareFriendDevice")) {
            doShareFriendDevice((String) args[0], (String) args[1]);
        } else if (TextUtils.equals(jobName, "ShareFriendCancel")) {
            doShareFriendCancel((String) args[0], (String) args[1]);
        } else if (TextUtils.equals(jobName, "ShareSetRemark")) {
            doShareSetRemark((String) args[0], (String) args[1], (String) args[2], (String) args[3]);
        }
    }

    public void doShareShare(String sn, String type, String phone, String device) {
        doShareShare(sn, type, phone, "", "", device);
    }

    public void doShareShare(String sn, String type, String phone, String relation, String device) {
        doShareShare(sn, type, phone, relation, "", device);
    }

    /**
     * 分享设备
     * @param sn
     * @param type 1：面对面二维码  2：手机号
     * @param phone type=2时必须
     * @param relation
     * @param Acl
     */
    public void doShareShare(String sn, String type, String phone, String relation, String Acl, String device) {
        ShareShareEntity shareShareEntity;

        shareShareEntity = Api.Camera.postShareShare(sn, type, phone, relation, Acl, device);

        if (shareShareEntity == null) {
            publishAction(Actions.Share.SHARE_SHARE_FAIL);
        } else if (shareShareEntity.errorCode != 0) {
            publishAction(Actions.Share.SHARE_SHARE_FAIL, shareShareEntity.errorCode, shareShareEntity.errorMsg);
        } else {
            publishAction(Actions.Share.SHARE_SHARE_SUCCESS, shareShareEntity, type);
        }
    }

    public void doShareGetInfo(String shareCode) {
        ShareGetInfoEntity shareGetInfoEntity = Api.Camera.postShareGetInfo(shareCode);
        if (shareGetInfoEntity == null) {
            publishAction(Actions.Share.SHARE_GET_SHARING_INFO_FAIL);
        } else if (shareGetInfoEntity.errorCode != 0) {
            publishAction(Actions.Share.SHARE_GET_SHARING_INFO_FAIL, shareGetInfoEntity.errorMsg);
        } else {
            publishAction(Actions.Share.SHARE_GET_SHARING_INFO_SUCCESS, shareGetInfoEntity);
        }
    }

    public void doShareAccept(String sn, String code, String directConnect, String startAt, String source) {
        doShareAccept(sn, code, directConnect, "", startAt, source);
    }

    public void doShareAccept(String sn, String code, String directConnect, String relation, String startAt, String source) {

        ShareAcceptEntity deviceInfo = Api.Camera.postShareAccept(sn, code, relation, startAt, source);

        if (deviceInfo == null) {
            publishAction(Actions.Share.SHARE_ACCEPT_FAIL);
        } else if (deviceInfo.errorCode != 0) {
            publishAction(Actions.Share.SHARE_ACCEPT_FAIL, deviceInfo.errorCode, deviceInfo.errorMsg, directConnect);
        } else {
            publishAction(Actions.Share.SHARE_ACCEPT_SUCCESS, directConnect, deviceInfo.data.sn);
        }
    }

    public void doShareCancel(String sn, String shareQid) {
        Head deviceInfo = Api.Camera.postShareCancel(sn, shareQid, "");
        if (deviceInfo == null) {
            publishAction(Actions.Share.SHARE_CANCEL_FAIL);
        } else if (deviceInfo.errorCode != 0) {
            publishAction(Actions.Share.SHARE_CANCEL_FAIL, deviceInfo.errorCode);
        } else {
            publishAction(Actions.Share.SHARE_CANCEL_SUCCESS,sn);
        }
    }

    public void doShareCancel(String sn, String shareQid, String phone) {
        Head deviceInfo = Api.Camera.postShareCancel(sn, shareQid, phone);
        if (deviceInfo == null) {
            publishAction(Actions.Share.SHARE_CANCEL_FAIL);
        } else if (deviceInfo.errorCode != 0) {
            publishAction(Actions.Share.SHARE_CANCEL_FAIL, deviceInfo.errorCode);
        } else {
            publishAction(Actions.Share.SHARE_CANCEL_SUCCESS);
        }
    }

    public void doShareCancelSharing(String sn, String code) {
        Head deviceInfo = Api.Camera.postShareCancelSharing(sn, code);
        if (deviceInfo == null) {
            publishAction(Actions.Share.SHARE_CANCEL_SHARING_FAIL);
        } else if (deviceInfo.errorCode != 0) {
            publishAction(Actions.Share.SHARE_CANCEL_SHARING_FAIL, deviceInfo.errorCode);
        } else {
            publishAction(Actions.Share.SHARE_CANCEL_SHARING_SUCCESS);
        }
    }

    public void doShareGetList(String sn, String page, String count) {
        try {
            ShareGetListEntity deviceInfo = CommonWrapper.getInstance(this.mApp).getLocalToClazz(sn, CommonWrapper.TYPE_SHARE_GETLIST_INFO, ShareGetListEntity.class);
            if (deviceInfo != null) {
                publishAction(Actions.Share.SHARE_GET_LIST_SUCCESS, deviceInfo);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        ShareGetListEntity deviceInfo;
//        if (MachineDebugConfig.DEBUG && DeviceInfo.isStoryMachine(sn)) {
//            deviceInfo = MachineApi.Machine.postShareGetList(sn, page, count);
//        } else {
            deviceInfo = Api.Camera.postShareGetList(sn, page, count);
//        }
        if (deviceInfo == null) {
            publishAction(Actions.Share.SHARE_GET_LIST_FAIL);
        } else if (deviceInfo.errorCode != 0) {
            publishAction(Actions.Share.SHARE_GET_LIST_FAIL, deviceInfo.errorMsg);
        } else {
            if (deviceInfo.errorCode == 0) {
                CommonWrapper.getInstance(this.mApp).writeBySnWithType(sn, deviceInfo.toJson(), CommonWrapper.TYPE_SHARE_GETLIST_INFO);
            }
            publishAction(Actions.Share.SHARE_GET_LIST_SUCCESS, deviceInfo);
        }
    }

    public void doShareGetSharingList(String sn) {
        ShareGetSharingListEntitiy shareGetSharingListEntitiy = Api.Camera.postShareGetSharingList(sn);
        if (shareGetSharingListEntitiy == null) {
            publishAction(Actions.Share.SHARE_GET_SHARING_LIST_FAIL);
        } else if (shareGetSharingListEntitiy.errorCode != 0) {
            publishAction(Actions.Share.SHARE_GET_SHARING_LIST_FAIL, shareGetSharingListEntitiy.errorCode);
        } else {
            publishAction(Actions.Share.SHARE_GET_SHARING_LIST_SUCCESS, shareGetSharingListEntitiy);
        }
    }

    public void doShareFriendDevice(String sn, String shareCode) {
        Head head = Api.Camera.postShareFriendDevice(sn, shareCode);
        if (head == null) {
            publishAction(Actions.Share.SHARE_FRIEND_FAIL);
        } else if (head.errorCode != 0) {
            publishAction(Actions.Share.SHARE_FRIEND_FAIL, head.errorCode);
        } else {
            publishAction(Actions.Share.SHARE_FRIEND_SUCCESS);
        }
    }

    public void doShareFriendCancel(String rspsSN, String rqstSN) {
        Head head = Api.Camera.postShareFriendCancel(rspsSN, rqstSN);
        if (head == null) {
            publishAction(Actions.Share.SHARE_FRIEND_CANCEL_FAIL);
        } else if (head.errorCode != 0) {
            publishAction(Actions.Share.SHARE_FRIEND_CANCEL_FAIL, head.errorMsg);
        } else {
            publishAction(Actions.Share.SHARE_FRIEND_CANCEL_SUCCESS);
        }
    }

    public void doShareSetRemark(String sn, String sqid, String newRemark, String oldRemark) {
        Head head = Api.Camera.postShareSetRemark(sn, sqid, newRemark);
        if (head == null) {
            publishAction(Actions.Share.SHARE_SET_REMARK_FAIL);
        } else if (head.errorCode != 0) {
            publishAction(Actions.Share.SHARE_SET_REMARK_FAIL, head.errorMsg, oldRemark);
        } else {
            publishAction(Actions.Share.SHARE_SET_REMARK_SUCCESS);
        }
    }
}
