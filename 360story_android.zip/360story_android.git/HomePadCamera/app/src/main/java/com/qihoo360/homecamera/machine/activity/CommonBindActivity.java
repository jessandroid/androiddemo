package com.qihoo360.homecamera.machine.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.view.View;

import com.qihoo360.homecamera.machine.fragment.CommonBindFragment;
import com.qihoo360.homecamera.mobile.R;

/**
 * Created by zhangtao-iri on 2017/1/5.
 */
public class CommonBindActivity extends MachineBaseActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_machine_album);

        findViewById(R.id.btn_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CommonBindActivity.this.finish();
            }
        });

        FragmentTransaction beginTransaction = getSupportFragmentManager().beginTransaction();
        beginTransaction.replace(R.id.common_fragment, CommonBindFragment.newInstance()).commitAllowingStateLoss();
    }

    public static void startCommonBindActivity(Context context){
        Intent intent = new Intent(context, CommonBindActivity.class);
        context.startActivity(intent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
