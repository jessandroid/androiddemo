package com.qihoo360.homecamera.mobile.entity;

import java.io.Serializable;


/**
 * Created by Administrator on 2015/4/21.
 */
public class ImageInfo implements Serializable {
    private static final long serialVersionUID = -1983219773720463690L;
    private transient byte[] dataTemp;
    private String data;
    private int width;
    private int height;
    private String path;
    private IMAGETYPE imgType;

    private String snapshotUrl;
    private String thumbnailUrl;
    
    public String getSnapshotUrl() {
        return snapshotUrl;
    }

    public void setSnapshotUrl(String snapshotUrl) {
        this.snapshotUrl = snapshotUrl;
    }

    public String getThumbnailUrl() {
        return thumbnailUrl;
    }

    public void setThumbnailUrl(String thumbnailUrl) {
        this.thumbnailUrl = thumbnailUrl;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
        
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public byte[] getDataTemp() {
        return dataTemp;
    }

    public void setDataTemp(byte[] dataTemp) {
        this.dataTemp = dataTemp;
        data = new String(dataTemp);
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public IMAGETYPE getImgType() {
        return imgType;
    }

    public void setImgType(IMAGETYPE imgType) {
        this.imgType = imgType;
    }


    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public enum IMAGETYPE{
        JPEG,PNG
    }
}
