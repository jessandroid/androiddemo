
package com.qihoo360.homecamera.mobile.core.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class PrefUtil implements PrefKeys {

    private final SharedPreferences mPref;

    public PrefUtil(Context context, String prefName) {
        mPref = context.getSharedPreferences(prefName, Context.MODE_PRIVATE);
    }

    public void putString(String key, String value) {
        putString(key, value, true);
    }

    public void putString(String key, String value, boolean commit) {
        Editor editor = mPref.edit().putString(key, value);
        if (commit) {
            editor.commit();
        }
    }

    public boolean remove(String key) {
        if (mPref.contains(key)) {
            return mPref.edit().remove(key).commit();
        } else {
            return false;
        }
    }

    public String getString(String key, String defValue) {
        return mPref.getString(key, defValue);
    }

    public boolean getBoolean(String key, boolean defValue) {
        return mPref.getBoolean(key, defValue);
    }

    public void putBoolean(String key, boolean value) {
        Editor editor = mPref.edit().putBoolean(key, value);
        editor.commit();
    }

    public int getInt(String key) {
        return mPref.getInt(key, 0);
    }

    public int getInt(String key, int dv) {
        return mPref.getInt(key, dv);
    }

    public Long getLong(String key) {
        return mPref.getLong(key, 0);
    }

    public void putLong(String key, long value) {
        Editor editor = mPref.edit().putLong(key, value);
        editor.commit();
    }

    public void putInt(String key, int value) {
        Editor editor = mPref.edit().putInt(key, value);
        editor.commit();
    }
}
