package com.qihoo360.homecamera.machine.myvideoplay;

import android.content.Context;
import android.util.AttributeSet;

import com.qihoo360.homecamera.machine.ui.widget.FilterMenuWrapper;


public class TitleHeadListMenuWrapper extends FilterMenuWrapper {

    public TitleHeadListMenuWrapper(Context context) {
        super(context);
    }

    public TitleHeadListMenuWrapper(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public void onSpaceTouch() {
        super.onSpaceTouch();
    }
}
