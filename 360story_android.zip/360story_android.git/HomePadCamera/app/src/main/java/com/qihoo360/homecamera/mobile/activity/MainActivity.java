
package com.qihoo360.homecamera.mobile.activity;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.NotificationManager;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.justalk.cloud.lemon.MtcCall;
import com.justalk.cloud.lemon.MtcCallConstants;
import com.qihoo360.homecamera.device.config.StoryMachineConsts;
import com.qihoo360.homecamera.machine.activity.CommonBindActivity;
import com.qihoo360.homecamera.machine.activity.MachineBaseActivity;
import com.qihoo360.homecamera.machine.activity.MachineSettingActivity;
import com.qihoo360.homecamera.machine.business.RxBus;
import com.qihoo360.homecamera.machine.entity.FamilyMessageEntity;
import com.qihoo360.homecamera.machine.fragment.CommonBindFragment;
import com.qihoo360.homecamera.machine.manager.MachinePlayInfoManager;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.adapter.MainDeviceRecycleAdapter;
import com.qihoo360.homecamera.mobile.adapter.MainViewPagerAdapter;
import com.qihoo360.homecamera.mobile.config.Const;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.db.PadInfoWrapper;
import com.qihoo360.homecamera.mobile.entity.CommonMessageEntity;
import com.qihoo360.homecamera.mobile.entity.Contacts;
import com.qihoo360.homecamera.mobile.entity.DeviceInfo;
import com.qihoo360.homecamera.mobile.entity.MessageInfoEntity;
import com.qihoo360.homecamera.mobile.entity.Setting;
import com.qihoo360.homecamera.mobile.entity.ShareWayInfo;
import com.qihoo360.homecamera.mobile.entity.Update;
import com.qihoo360.homecamera.mobile.entity.UpdateBatch;
import com.qihoo360.homecamera.mobile.image.my.GlideCircleTransform;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.manager.VersionManager;
import com.qihoo360.homecamera.mobile.service.JustalkService;
import com.qihoo360.homecamera.mobile.service.MessageService;
import com.qihoo360.homecamera.mobile.service.MyJobService;
import com.qihoo360.homecamera.mobile.ui.SystemBarTintManager;
import com.qihoo360.homecamera.mobile.ui.fragment.ChatFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.HomePhotoShowAllDayDetailFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.KibotMainFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.MachineMainFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.NewDeviceFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.PadHeadFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.PersonCenterFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.StoryFragment;
import com.qihoo360.homecamera.mobile.ui.tabview.CommonTabLayout;
import com.qihoo360.homecamera.mobile.ui.tabview.listener.CustomTabEntity;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.CompatibilitySupport;
import com.qihoo360.homecamera.mobile.utils.Preferences;
import com.qihoo360.homecamera.mobile.utils.QHStatAgentHelper;
import com.qihoo360.homecamera.mobile.utils.ShareNotificationReceiver;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.widget.CamAlertDialog;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.File;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import rx.Observable;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

public class MainActivity extends MachineBaseActivity implements OnClickListener,
        ActionListener, MainDeviceRecycleAdapter.OnViewClick, NewDeviceFragment.OnFragmentInteractionListener {

    public static final int CAMERA_SETTING_CHANGE = 1200; // 视频通话索引值
    private static final int MYJOBID = 1;
    public static final int VIDEO_CALL_INDEX = 0; // 视频通话索引值
    public static final int COAX_BABY_INDEX = 2; // 哄娃助手
    public static final int HOME_PHOTO_INDEX = 1; // 家庭相册索引值
    public static final int SHOW_STORY_LIST = 3; // k故事
    public static final String SWITCH_TAB_INDEX = "select_tab_index";//选择tab的index

    private JobScheduler jobScheduler;

    private HomePhotoShowAllDayDetailFragment mHomePhotoShowAllDayFragment;
    private RelativeLayout mBottomAreaRL;

    private BroadcastReceiver mCallIncomingReceiver;

    public RelativeLayout rootView;
    public CommonTabLayout bottom;

    public ImageButton menuBtn;
    public ImageView dropDownMenu;
    private PopupWindow window;
    private ArrayList<Setting> stringlist = new ArrayList<>();

    public View view2;
    private ListView list;
    public ArrayList<DeviceInfo> deviceInfoArrayList;
    public DeviceInfo deviceInfo;
    public View appbar;
    public TextView choose;
    private ImageView topMsgTip;

    public int selected = 0;
    private StoryFragment storyFragment;
    private CamAlertDialog delDialog;
    private ArrayList<CustomTabEntity> mTabEntities = new ArrayList<>();
    private ArrayList<CustomTabEntity> mMachineTabEntities = new ArrayList<>();
    public String[] mTitles;
    public String[] mMachineTitles;

    private int[] mIconUnselectIds = {
            R.drawable.video_call_disable, R.drawable.home_pic_disable, R.drawable.coax_baby,
            R.drawable.children_story_normal
    };

    private int[] mIconSelectIds = {
            R.drawable.video_call_pressed, R.drawable.home_pic_pressed, R.drawable.coax_baby_hover,
            R.drawable.children_story
    };

    private ArrayList<Fragment> fragments;
    private ArrayList<Fragment> mMachinefragments;
    private PersonCenterFragment mPersonCenterFragment;
    public TextView titleView;
    public MainDeviceRecycleAdapter mainDeviceRecycleAdapter;
    public PopupWindow popupWindow;
    public ImageButton story_history;
    public ImageView enter_player;
    public ImageView main_head_img;
    public ImageView main_head_img_profile;
    private NewDeviceFragment newDeviceFragment;
    public ImageView mRedPotIv;
    private volatile int po = -1;
    private boolean bHasShowNoDiscAlert = false; //提示空间不足
    //更新
    private String ACTION = "com.qihoo.psdk.remote";
    private VersionManager versionManager;

    //邀请家人
    private CamAlertDialog inviteDialog;
    private File mTmpFile;
    private File mOutputFile;
    private Bitmap bitmap;
    private View firstGuideView;
    private View firstGuideViewChat;
    private ChatFragment chatFragment;
    private MainViewPagerAdapter mMainViewPagerAdapter;
    private boolean mIsMachineViewMode = false;

    //新的
    private KibotMainFragment kibotMainFragment;
    private MachineMainFragment machineMainFragment;
    private CommonBindFragment bindFragment;

    public final static int KIBOTTYPE = 0;
    public final static int MACHINETYPE = 1;
    public final static int MACHINETYPE_605 = 2;
    private boolean needReceiveAction = false;
    private boolean isFromBindRefresh = false;
    private boolean isNeedSelectChat = false;//是否需要切换到家庭群界面
    private boolean isFromOncreate = false;
    private FragmentTransaction fragmentTransaction;
    public View title_layout;
    public View backView;
    public View head_layout;
    public View story_search;
    private CamAlertDialog.Builder mAddFamilyDialog;

    private Subscription rxSbscription;

    private View profileLead;//引导页面

    // 获取手机状态栏高度
    public int getStatusBarHeight() {
        Class<?> c = null;
        Object obj = null;
        Field field = null;
        int x = 0, statusBarHeight = 0;
        try {
            c = Class.forName("com.android.internal.R$dimen");
            obj = c.newInstance();
            field = c.getField("status_bar_height");
            x = Integer.parseInt(field.get(obj).toString());
            statusBarHeight = getResources().getDimensionPixelSize(x);
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        return statusBarHeight;
    }

    @TargetApi(Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Constants.IS_LOGIN = true;
        CLog.e("zt","mainactivity onCreate");
        isFromOncreate = true;
        deviceInfoArrayList = new ArrayList<>();
        mTitles = Utils.context.getResources().getStringArray(R.array.main_bottom_title);
        fragments = new ArrayList<>();
        mMachinefragments = new ArrayList<>();
        setContentView(R.layout.demo_main);
        rootView = (RelativeLayout) findViewById(R.id.rootView);
        profileLead = findViewById(R.id.profile_lead);
        profileLead.setOnClickListener(this);
        appbar = findViewById(R.id.appbar);
        topMsgTip = (ImageView) findViewById(R.id.msg_tip);

        view2 = appbar.findViewById(R.id.view2);
        backView = appbar.findViewById(R.id.back_zone);
        Utils.ensureVisbility(backView, View.GONE);
        backView.setOnClickListener(this);

        head_layout = appbar.findViewById(R.id.layout_head);
        head_layout.setOnClickListener(this);
        main_head_img = (ImageView) appbar.findViewById(R.id.main_head_img);
        main_head_img_profile = (ImageView) appbar.findViewById(R.id.main_head_img_profile);
        titleView = (TextView) appbar.findViewById(R.id.story_title);

        menuBtn = (ImageButton) appbar.findViewById(R.id.home_menu);
        dropDownMenu = (ImageView) appbar.findViewById(R.id.arrow_down);
        story_history = (ImageButton) appbar.findViewById(R.id.story_history);
        enter_player = (ImageView) appbar.findViewById(R.id.enter_player);
        mRedPotIv = (ImageView) appbar.findViewById(R.id.iv_red_pot);
        choose = (TextView) appbar.findViewById(R.id.choose);
        title_layout = appbar.findViewById(R.id.title_layout);
        title_layout.setOnClickListener(this);
        story_search = appbar.findViewById(R.id.story_search);
        story_search.setOnClickListener(this);

        versionManager = new VersionManager(this);
        // TODO: 2016/12/13  注册机器人的广播----------------------------需要---------start
        GlobalManager.getInstance().getNeverKillManager().registerActionListener(this);
        GlobalManager.getInstance().getCommonManager().registerActionListener(this);
        GlobalManager.getInstance().getCameraManager().registerActionListener(this);
        MachinePlayInfoManager.getInstance().registerActionListener(this);
        GlobalManager.getInstance().getUserInfoManager().registerActionListener(this);
        if (CompatibilitySupport.isGreatOrEqual50()) {
            jobScheduler = (JobScheduler) getSystemService(JOB_SCHEDULER_SERVICE);
            createJobSchedulerInfo();
        }
        CLog.e("----------------------> " + new Date().getTime());
        if (getIntent() != null && getIntent().getExtras() != null) {
            if (getIntent().getBooleanExtra(PrivateActivity.class.getSimpleName() + "Addfamily", false)) {
                String sn = getIntent().getStringExtra("sn");
                String qid = getIntent().getStringExtra("qid");
                Intent intent = new Intent(this, PrivateActivity.class);
                intent.putExtra(PrivateActivity.class.getSimpleName(), true);
                intent.putExtra("sn", sn);
                intent.putExtra("qid", qid);
                startActivity(intent);
            } else if(getIntent().hasExtra("info")){
                String info = getIntent().getExtras().getString("info");
                CLog.e("zhaojunbo", info);
                startCall(info);

                int nSwitchTabIndex = getIntent().getIntExtra(SWITCH_TAB_INDEX, -1);
                switchTabIndex(nSwitchTabIndex);
            }
            if(getIntent().hasExtra("messageEntity")) {
                //聊天消息notification的点击调转
                FamilyMessageEntity entity = getIntent().getParcelableExtra("messageEntity");
                if (entity != null) {
                    if (TextUtils.equals(Preferences.getSelectedPad(), entity.getSn())) {
                        //就在当前故事机
                        isNeedSelectChat = true;
                        addFragment();
                    } else {
                        //切换到当前故事机
                        Preferences.saveSelectedPad(entity.getSn());
                        needReceiveAction = true;
                        isFromBindRefresh = false;
                        isNeedSelectChat = true;
                        //刷新机器
                        GlobalManager.getInstance().getCameraManager().asyncMainLoadMyCamera(0);
                    }
                }else{
                    addFragment();
                }
            }else{
                addFragment();
            }
        }else{
            addFragment();
        }
        checkUpdate();
        CLog.i("test2", "main a onCreate cost = " + CLog.endTimer("onCreate"));
        startPush();
        mainDeviceRecycleAdapter = new MainDeviceRecycleAdapter(deviceInfoArrayList, this);
        mainDeviceRecycleAdapter.setOnViewClick(this);

        //未接来电的提醒
        rxSbscription = RxBus.getInstance().toObservable().observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Action1<Object>() {
                    @Override
                    public void call(Object o) {
                        String tmp = (String)o;
                        if(o instanceof String){
                            if(!TextUtils.isEmpty(tmp) && !TextUtils.equals(Preferences.getSelectedPad(), tmp)){
                                // 如果不是当前设备
                                if(mainDeviceRecycleAdapter!=null){
                                    showListRedDot(tmp);
                                    showTopMsg(true);
                                }
                            }
                        }
                    }
                });

        //是否显示引导页
        Utils.ensureVisbility(profileLead, Preferences.getProfileLead() ? View.GONE : View.VISIBLE);
        //初始化popuopwindow
        initSharePopupWindow();
    }

    //故事机需要切到第几页,机器人忽略
    private void addFragment() {
        String sn = Preferences.getSelectedPad();
        if (!TextUtils.isEmpty(sn)) {
            deviceInfo = getDeviceBySn(sn);
            if (deviceInfo != null) {
                if (!deviceInfo.isStoryMachine()) {
                    if (machineMainFragment != null && machineMainFragment.isAdded()) {
                        getSupportFragmentManager().beginTransaction().remove(machineMainFragment).commitAllowingStateLoss();
                        machineMainFragment = null;
                    }
                    kibotMainFragment = KibotMainFragment.newInstance();
                    getSupportFragmentManager().beginTransaction().replace(R.id.main_content, kibotMainFragment)
                            .commitAllowingStateLoss();
                    kibotMainFragment.doChangeDevice(deviceInfo);
                } else {
                    if (kibotMainFragment != null && kibotMainFragment.isAdded()) {
                        getSupportFragmentManager().beginTransaction().remove(kibotMainFragment).commitAllowingStateLoss();
                        kibotMainFragment = null;
                    }
                    machineMainFragment = MachineMainFragment.newInstance();
                    getSupportFragmentManager().beginTransaction().replace(R.id.main_content, machineMainFragment).commitAllowingStateLoss();
                    machineMainFragment.doChangeDevice(deviceInfo);
                    if(isNeedSelectChat){
                        isNeedSelectChat = false;
                        Observable.timer(500, TimeUnit.MILLISECONDS).subscribeOn(Schedulers.io())
                                .observeOn(AndroidSchedulers.mainThread())
                                .subscribe(new Action1<Long>() {
                                    @Override
                                    public void call(Long aLong) {
                                        machineMainFragment.selectChatTap();
                                    }
                                });
                    }
                }
            } else {
                needReceiveAction = true;
            }
        } else {
            CLog.e("zt", "addFragment sn为空");
            needReceiveAction = true;
        }
        GlobalManager.getInstance().getCameraManager().asyncMainLoadMyCamera(0);
    }

    //type ---需要被切换到的模式
    public void changeType(boolean flag, int type) {
        if (flag) {
            switch (type) {
                case KIBOTTYPE://切换到机器人
                    if (machineMainFragment != null && machineMainFragment.isAdded()) {
                        getSupportFragmentManager().beginTransaction().remove(machineMainFragment)
                                .commitAllowingStateLoss();
                        machineMainFragment = null;
                    }
                    if (kibotMainFragment == null) {
                        kibotMainFragment = KibotMainFragment.newInstance();
                    }
                    getSupportFragmentManager().beginTransaction().replace(R.id.main_content, kibotMainFragment)
                            .commitAllowingStateLoss();
                    GlobalManager.getInstance().getCameraManager().publishAction(Actions.Camera.SELECTED_CAMERA);
                    break;
                case MACHINETYPE://切换到故事机
//                    if (kibotMainFragment != null && kibotMainFragment.isAdded()) {
//                        getSupportFragmentManager().beginTransaction().remove(kibotMainFragment)
//                                .commitAllowingStateLoss();
//                        kibotMainFragment = null;
//                    }
//                    if (machineMainFragment != null && machineMainFragment.isAdded()) {
//                        getSupportFragmentManager().beginTransaction().remove(machineMainFragment)
//                                .commitAllowingStateLoss();
//                        machineMainFragment = null;
//                    }
//                    if (machineMainFragment == null) {
//                        machineMainFragment = MachineMainFragment.newInstance();
//                    }
//                    getSupportFragmentManager().beginTransaction().replace(R.id.main_content, machineMainFragment).commitAllowingStateLoss();
//                    GlobalManager.getInstance().getCameraManager().publishAction(Actions.Camera.SELECTED_CAMERA_M);
//                    break;

                case MACHINETYPE_605:
                    if (kibotMainFragment != null && kibotMainFragment.isAdded()) {
                        getSupportFragmentManager().beginTransaction().remove(kibotMainFragment)
                                .commitAllowingStateLoss();
                        kibotMainFragment = null;
                    }
                    if (machineMainFragment != null && machineMainFragment.isAdded()) {
                        getSupportFragmentManager().beginTransaction().remove(machineMainFragment)
                                .commitAllowingStateLoss();
                        machineMainFragment = null;
                    }
                    if (machineMainFragment == null) {
                        machineMainFragment = MachineMainFragment.newInstance();
                    }
                    getSupportFragmentManager().beginTransaction().replace(R.id.main_content, machineMainFragment).commitAllowingStateLoss();
                    GlobalManager.getInstance().getCameraManager().publishAction(Actions.Camera.SELECTED_CAMERA_M);
                    break;

            }
        }else{
            //同一种设备切换，fragment不变，刷新
            GlobalManager.getInstance().getCameraManager().publishAction(Actions.Camera.CHANGE_TO_OTHER_DEVICE);
            switch (type){
                case KIBOTTYPE://切换到机器人
                    GlobalManager.getInstance().getCameraManager().publishAction(Actions.Camera.SELECTED_CAMERA);
                    break;

                case MACHINETYPE:
                    GlobalManager.getInstance().getCameraManager().publishAction(Actions.Camera.SELECTED_CAMERA_M);
                    GlobalManager.getInstance().getCameraManager().publishAction(Actions.Camera.UPDATE_FAMILY_GROUP_DATA);
                    GlobalManager.getInstance().getCameraManager().publishAction(Actions.Camera.CHANGE_TO_STORY_MACHINE);
                    break;
            }
        }
    }

    private void addBindFragment() {
        if (bindFragment == null) {
            bindFragment = CommonBindFragment.newInstance();
        }
        getSupportFragmentManager().beginTransaction().replace(R.id.main_content, bindFragment).commitAllowingStateLoss();
    }

    private void showAddFamilyDialog() {
        mAddFamilyDialog = new CamAlertDialog.Builder(this).setTitle(R.string.bind_success_titie)
                .setMessage(getString(R.string.add_family_title))
                .setNegativeButton(R.string.tips_23, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).setPositiveButton(R.string.now_invite, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(final DialogInterface dialogInterface, int i) {
                        //TODO 进入分享界面, 区分是故事机还是机器人
                        if(deviceInfo.isStoryMachine()){
                            showBindPhone();
                        }else{
                            showPopupWindow(appbar);
                        }
                    }
                });

        mAddFamilyDialog.show();
    }


    //添加家人
    private void initSharePopupWindow() {
        List<ShareWayInfo> list = new ArrayList<ShareWayInfo>() {
        };
        list.add(new ShareWayInfo(R.drawable.share_qr, "面对面扫码添加"));
        list.add(new ShareWayInfo(R.drawable.share_phone, "手机号添加"));
        list.add(new ShareWayInfo(R.drawable.share_robot, "机器人+机器人"));
        initPopupWindow(list, new IOnChooseCallback() {
            @Override
            public void onItemChoose(int pos) {
                switch (pos) {
                    case 0:
                        qrShare();
                        break;
                    case 1:
                        showBindPhone();
                        break;
                    case 2:
                        showInviteFriend();
                        break;
                }
            }
        });
    }

    private void startPush() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    CLog.e("push", "---->startPush");
                    if (Constants.IS_LOGIN) {
                        startService(new Intent(MainActivity.this, MessageService.class));
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private List<Map<String, Object>> initListData() {

        List<Map<String, Object>> data = new ArrayList<Map<String, Object>>();
        Map<String, Object> map = new HashMap<String, Object>();
        String[] a = getResources().getStringArray(R.array.main_menu_array);

        map = new HashMap<String, Object>();
        map.put("title", a[0]);
        map.put("img", getResources().getDrawable(R.drawable.icon_add));
        data.add(map);

        map = new HashMap<String, Object>();
        map.put("title", a[1]);
        map.put("img", getResources().getDrawable(R.drawable.icon_setting));
        data.add(map);

        return data;
    }

    // TODO: 2016/12/13 这里需要处理是否有机器人然后去再去做初始化justtalk -------------------------------------start
    @Override
    protected void onStart() {
        super.onStart();
        startService(new Intent(MainActivity.this, JustalkService.class));
    }

    // TODO: 2016/12/13 这里需要处理是否有机器人然后去再去做初始化justtalk -------------------------------------end

    //intent信息 切换tab
    public void switchTabIndex(int nIndex) {
        if (nIndex < 0) {
            return;
        }
        if(kibotMainFragment!=null && kibotMainFragment.isAdded()){
            kibotMainFragment.switchTabIndex(nIndex);
        }else if(machineMainFragment!=null && machineMainFragment.isAdded()){
            machineMainFragment.switchTabIndex(nIndex);
        }
    }

    public void startCall(String info) {
        try {

            if (TextUtils.isEmpty(info)) {
                return;
            }

            JSONObject json = (JSONObject) new JSONTokener(info).nextValue();
            int callId = json.getInt(MtcCallConstants.MtcCallIdKey);
            CLog.justalkFile("startCall------>callId:" + callId);
            DeviceInfo deviceInfo = PadInfoWrapper.getInstance().getPadBySn(MtcCall.Mtc_CallGetPeerName(callId));
            QHStatAgentHelper.startCallStick(callId + "", "call_incoming", "0",
                    deviceInfo == null ? "" : deviceInfo.getRelationTitle(), MtcCall.Mtc_CallGetPeerName(callId));

            Bundle bundle = new Bundle();
            bundle.putBoolean("outgoing", true);
            bundle.putInt("callId", callId);
            bundle.putInt("from", OutgoingCallActivity.VIDEO_BECALLED);
            Intent outGoingCallIntent = new Intent(MainActivity.this, OutgoingCallActivity.class);
            outGoingCallIntent.putExtras(bundle);
            outGoingCallIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(outGoingCallIntent);
            CLog.justalkFile("startCall------>startActivity--->callId:" + callId);
            CLog.e("zhaojunbo", "启动OutgoingCallActivity");

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    //todo 这里是每10000 毫秒启动一次service 的机制
    private static final int TIMEINTERVAL = 10*60*1000;
    public void createJobSchedulerInfo() {
        ComponentName jobService = new ComponentName(getPackageName(), MyJobService.class.getName());
        JobInfo jobInfo = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            jobInfo = new JobInfo.Builder(MYJOBID, jobService).setPeriodic(TIMEINTERVAL).build();
            int jobId = jobScheduler.schedule(jobInfo);
            if (jobId > 0) {
                CLog.d("succ");
            } else {
                CLog.d("fail");
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        GlobalManager.getInstance().getSearchWordManager().removeActionListener(this);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent != null && intent.getExtras() != null) {
            if(intent.hasExtra("info")){
                String info = intent.getExtras().getString("info");
                CLog.justalkFile("onNewIntent------>info:" + info);
                startCall(info);

                int nSwitchTabIndex = intent.getIntExtra(SWITCH_TAB_INDEX, -1);
                switchTabIndex(nSwitchTabIndex);
            }else if(intent.hasExtra("messageEntity")){
                //聊天消息notification的点击调转
                FamilyMessageEntity entity = intent.getParcelableExtra("messageEntity");
                if(entity!=null){
                    if(TextUtils.equals(Preferences.getSelectedPad(), entity.getSn())){
                        //就在当前故事机
                        if(getCurrentTabNum()!=3){
                            if(machineMainFragment!=null){
                                machineMainFragment.selectChatTap();
                            }
                        }
                    }else{
                        //切换到当前故事机
                        Preferences.saveSelectedPad(entity.getSn());
                        needReceiveAction = true;
                        isFromBindRefresh = false;
                        isNeedSelectChat = true;
                        //刷新机器
                        GlobalManager.getInstance().getCameraManager().asyncMainLoadMyCamera(0);
                    }
                }
            }else if(intent.hasExtra("kibot_lock_message")){
                MessageInfoEntity entity = intent.getParcelableExtra("messageEntity");
                if(entity!=null){
                    if(TextUtils.equals(Preferences.getSelectedPad(), entity.data.sn)){
                        Intent shareMessageIntent = new Intent();
                        shareMessageIntent.setAction(Const.ROBOT_LOCK_SCREEN_RECEIPT);
                        Bundle mBundle = new Bundle();
                        mBundle.putParcelable("message", entity);
                        mBundle.putInt("message_type", CommonMessageEntity.ROBOT_LOCK_SCREEN_RECEIPT);
                        shareMessageIntent.putExtras(mBundle);
                        CLog.d("lock", entity.toString());
                        sendBroadcast(shareMessageIntent);
                    }
                }
            }else if(intent.hasExtra(StoryMachineConsts.KEY_PUSH_MESSAGE_ONLINE)){{
                String sn  = intent.getStringExtra(StoryMachineConsts.KEY_PUSH_MESSAGE_ONLINE);
                if (TextUtils.equals(Preferences.getSelectedPad(),sn)){
                    if (getCurrentTabNum() != 0){
                        if(machineMainFragment!=null){
                            machineMainFragment.selectStoryLibraryTap();
                        }
                    }
                }else{
                    Preferences.saveSelectedPad(sn);
                    needReceiveAction = true;
                    isFromBindRefresh = false;
                    isNeedSelectChat = false;
                    //刷新机器
                    GlobalManager.getInstance().getCameraManager().asyncMainLoadMyCamera(0);
                }

            }}
        }
        startPush();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        /*  boolean isConsum = false;
        if (chatFragment != null && chatFragment.ekBar != null) {
            isConsum = chatFragment.ekBar.dispatchKeyEventInFullScreen(event);
        }*/
        return /*isConsum ? isConsum : */ super.dispatchKeyEvent(event);
    }

    @Override
    public void onDestroy() {
        if (delDialog != null) {
            delDialog.dismiss();
            delDialog = null;
        }
        if (camAlertDialog != null) {
            camAlertDialog.dismiss();
            camAlertDialog = null;
        }
        if (inviteDialog != null) {
            inviteDialog.dismiss();
            inviteDialog = null;
        }
        if (mCallIncomingReceiver != null) {
            LocalBroadcastManager.getInstance(this).unregisterReceiver(mCallIncomingReceiver);
        }
        GlobalManager.getInstance().getNeverKillManager().removeActionListener(this);
        GlobalManager.getInstance().getCameraManager().removeActionListener(this);
        GlobalManager.getInstance().getCommonManager().removeActionListener(this);
        GlobalManager.getInstance().getUserInfoManager().registerActionListener(this);
        MachinePlayInfoManager.getInstance().registerActionListener(this);
        //        LocalBroadcastManager.getInstance(this).unregisterReceiver(mImTextDidReceiver);
        storyFragment = null;

        //主程序退出，关闭通知栏的通知
        if (ShareNotificationReceiver.mImageInfoEntityArrayList.size() > 0) {
            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE))
                    .cancel(Constants.NOTIFYCATION_SHORT_VIDEO);
        }
        for (int i = 0; i < Constants.CommonMessageList.size(); i++) {
            CommonMessageEntity commonMessageEntity = Constants.CommonMessageList.get(i);
            if (!commonMessageEntity.hasShow) {
                ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE))
                        .cancel(commonMessageEntity.getId());
            }
        }

        if(rxSbscription!=null && !rxSbscription.isUnsubscribed()){
            rxSbscription.unsubscribe();
        }

        if(!TextUtils.isEmpty(Preferences.getNewVersion())){
            showAvatarRedDot(true);
        }
        super.onDestroy();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.layout_head: {
                Intent intent = new Intent(this, PersonCenterActivity.class);
                intent.putParcelableArrayListExtra("devList", deviceInfoArrayList);
                startActivity(intent);
                Utils.ensureVisbility(mRedPotIv, View.GONE);
                break;
            }
            case R.id.view2:
                break;
            case R.id.title_layout:
                if (mainDeviceRecycleAdapter.getItemCount() > 1) {
                    showPopMenuDevice();
                    dropDownMenu.setImageResource(R.drawable.arrow_up_white);
                }
                break;
            case R.id.first_guide_view: {
                Utils.ensureVisbility(View.GONE, firstGuideView);
                Preferences.setIsShowGuideChat(true);
                break;
            }
            case R.id.first_chat_guide_view: {
                Utils.ensureVisbility(View.GONE, firstGuideViewChat);
                Preferences.setIsShowGuideChatFrag(true);
                break;
            }
            case R.id.home_menu: {
                handleAdd();
                break;
            }

            case R.id.choose: {
                int MODEL = TextUtils.equals(choose.getText(), getString(R.string.choose)) ? Actions.Story.CHOOSE_MODEL
                        : Actions.Story.UNCHOOSE_MODEL;
                String text = TextUtils.equals(choose.getText(), getString(R.string.choose))
                        ? getString(R.string.cancel) : getString(R.string.choose);
                if (selected == SHOW_STORY_LIST) {
                    GlobalManager.getInstance().getStorymanager().publishAction(MODEL);
                }
                if (selected == HOME_PHOTO_INDEX) {
                    if (MODEL == Actions.Story.CHOOSE_MODEL) {
                        mHomePhotoShowAllDayFragment.chooseMode();
                    } else if (MODEL == Actions.Story.UNCHOOSE_MODEL) {
                        mHomePhotoShowAllDayFragment.unChooseMode();
                    }
                }
                choose.setText(text);
                break;
            }
            case R.id.tv_select_picture:
                break;

            case R.id.iv_float_camera:
                break;

            case R.id.iv_float_style:
                break;

            case R.id.iv_delete:
                showDeleteDialog();
                break;

            case R.id.iv_download:
                mHomePhotoShowAllDayFragment.downloadImage();
                break;

            case R.id.iv_share:
                mHomePhotoShowAllDayFragment.showShareDialog();
                break;

            case R.id.story_history:
                if (deviceInfo != null && !TextUtils.isEmpty(deviceInfo.sn)) {
                    Bundle b = new Bundle();
                    b.putParcelable("deviceInfo", deviceInfo);
                    Intent intent = new Intent(this, StoryHistoryListAllActivity.class);
                    intent.putExtra("Bundle", b);
                    startActivity(intent);
                }
                break;

            case R.id.back_zone:
                if (machineMainFragment != null && machineMainFragment.isAdded()) {
                    machineMainFragment.doBackOperate();
                }
                needShowTopMsg();
                break;

            case R.id.story_search://故事机的搜索按钮
                if (machineMainFragment != null && machineMainFragment.isAdded()) {
                    machineMainFragment.doSearch();
                }
                break;

            case R.id.profile_lead:
                Utils.ensureVisbility(profileLead, View.GONE);
                Preferences.setProfileLead(true);
                break;
        }
    }

    public void setChooseMode(boolean isChoose) {
        if (selected == HOME_PHOTO_INDEX) {
            int MODEL = TextUtils.equals(choose.getText(), getString(R.string.choose)) ? Actions.Story.CHOOSE_MODEL
                    : Actions.Story.UNCHOOSE_MODEL;
            String text = TextUtils.equals(choose.getText(), getString(R.string.choose)) ? getString(R.string.cancel)
                    : getString(R.string.choose);

            if (isChoose && MODEL != Actions.Story.CHOOSE_MODEL) {
                mHomePhotoShowAllDayFragment.chooseMode();
                choose.setText(text);
            } else if (!isChoose && MODEL == Actions.Story.UNCHOOSE_MODEL) {
                mHomePhotoShowAllDayFragment.unChooseMode();
                choose.setText(text);
            }

            Utils.ensureVisbility(View.GONE, story_history, menuBtn);
        }
    }

    public void setPhotoSelectState(boolean isShow) {
        if (selected == HOME_PHOTO_INDEX) {
            if (isShow) {
                if (choose.getVisibility() != View.VISIBLE) {
                    Utils.ensureVisbility(View.VISIBLE, choose);
                }
            } else {
                if (choose.getVisibility() != View.GONE) {
                    Utils.ensureVisbility(View.GONE, choose);
                }
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (kibotMainFragment != null && kibotMainFragment.isAdded()) {
            kibotMainFragment.onBackPressed();
        } else if(machineMainFragment != null && machineMainFragment.isAdded()){
            machineMainFragment.onBackPressed();
        }else if(bindFragment!=null && bindFragment.isAdded()){
            bindFragment.onBackPressed();
        }
    }

    protected void intoImageCROP(Uri uri, String path) {
        mUserHeadUri = Uri.fromFile(new File(path));
        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.setDataAndType(uri, "image/*");
        // 下面这个crop=true是设置在开启的Intent中设置显示的VIEW可裁剪
        intent.putExtra("crop", "true");
        // aspectX aspectY 是宽高的比例
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);
        // outputX outputY 是裁剪图片宽高
        intent.putExtra("outputX", 200);
        intent.putExtra("outputY", 200);
        intent.putExtra("return-data", false);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, mUserHeadUri); // pass temp file

        if (Utils.isIntentSafe(intent)) {
            startActivityForResult(intent, PadHeadFragment.REQUEST_CROP_PHOTO);
        } else {
            CameraToast.show("您的手机暂不支持裁剪，将后续支持，请谅解！", Toast.LENGTH_SHORT);
        }
    }

    public static Uri getImageContentUri(Context context, String absPath) {
        Uri resultUri = null;
        CLog.i("test2", "getImageContentUri: " + absPath);
        Cursor cursor = null;
        try {
            cursor = context.getContentResolver().query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, new String[] {
                            MediaStore.Images.Media._ID
                    }, MediaStore.Images.Media.DATA + "=? ", new String[] {
                            absPath
                    }, null);

            if (cursor != null && cursor.moveToFirst()) {
                int id = cursor.getInt(cursor.getColumnIndex(MediaStore.MediaColumns._ID));
                resultUri = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, Integer.toString(id));
                return resultUri;

            } else if (!absPath.isEmpty()) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DATA, absPath);
                return resultUri = context.getContentResolver().insert(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            Utils.close(cursor);
        }
        return resultUri;

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case PadHeadFragment.REQUEST_CROP_PHOTO: {
                if (mUserHeadUri != null && resultCode == RESULT_OK) {
                    mPersonCenterFragment.ModifyUserHead(mUserHeadUri.getPath());
                }
                break;
            }
            case EventPagerActivity.EVENT_PAGE:
                switch (resultCode) {
                    case EventPagerActivity.EVENT_PAGE_SELECT:
                        break;
                    case EventPagerActivity.EVENT_PAGE_UNSELECT:
                        break;
                    default:
                        break;
                }
                break;
            case CAMERA_SETTING_CHANGE:
                if (data != null) {
                    String title = data.getStringExtra("title");
                    if (!TextUtils.isEmpty(title)) {
                        deviceInfo.setTitle(title);
                    }
                }
                break;
            case Constants.PHONE_LIST:
                if (data != null) {
                    final Contacts contact = (Contacts) data.getSerializableExtra("contact");
                    if (contact != null && !TextUtils.isEmpty(contact.getPhoneNumber())) {
                        showCommonDialog(getString(R.string.tips_21),
                                getString(R.string.tips_22, contact.getPhoneNumber()),
                                getString(R.string.tips_23), getString(R.string.tips_24), "", false,
                                new ICommonDialog() {
                                    @Override
                                    public void onRightButtonClick(boolean... isChecked) {
                                        try {
                                            GlobalManager.getInstance().getShareManager().asyncShareShare(
                                                    deviceInfo.getSn(), "3",
                                                    Utils.checkPhoneNum(contact.getPhoneNumber()),
                                                    deviceInfo.isStoryMachine() ? Constants.DeviceType.STORYMACHINE
                                                            : Constants.DeviceType.KIBOTMACHINE);
                                            showTipsDialog(getString(R.string.tips_25), R.drawable.icon_loading, true);
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    }

                                    @Override
                                    public void onLeftButtonClick(boolean... isChecked) {

                                    }

                                    @Override
                                    public void onDialogCancel() {

                                    }
                                });
                    }
                }
                break;
            default:
                break;
        }
    }

    public void showToolBar(int visible) {
        Utils.ensureVisbility(mBottomAreaRL, visible);
    }

    public void setBottomTabVisable(boolean isShow) {
        //TODO 交给kibotMaiFragment去处理
        if (kibotMainFragment != null && kibotMainFragment.isAdded()) {
            kibotMainFragment.setBottomTabVisable(isShow);
        }
    }

    private void showDeleteDialog() {
        CamAlertDialog.Builder builder = new CamAlertDialog.Builder(this);
        builder.setTitle(Utils.getContext().getString(R.string.delete_pic));
        builder.setPositiveButton(Utils.getContext().getString(R.string.ok),
                new CamAlertDialog.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        deleteFile();
                    }
                });
        builder.setNegativeButton(Utils.getString(R.string.cancel), null);
        delDialog = builder.show();
    }

    private void deleteFile() {
        mHomePhotoShowAllDayFragment.deletePic();
    }

    @Override
    protected void onResume() {
        super.onResume();
        CLog.e("time--->", CLog.endTimer("time"));
        GlobalManager.getInstance().getSearchWordManager().registerActionListener(this);
        //PhoneRecordWrapper.getInstance(MainActivity.this).getCallTime(deviceInfo.sn);
    }

    private void needPopupWindow() {
        boolean hasMessage = false;
        for (int i = 0; i < Constants.CommonMessageList.size(); i++) {
            CommonMessageEntity commonMessageEntity = Constants.CommonMessageList.get(i);
            if (!commonMessageEntity.hasShow) {
                hasMessage = true;
            }
        }
        if (hasMessage) {
            Intent intent = new Intent(this, HideActivity.class);
            startActivity(intent);
        }
    }

    @Override
    public Object actionPerformed(int actionCode, Object... args) {
        switch (actionCode) {
            case Actions.Common.CHANGE_TOPBAR_TITLE: {
                if (titleView != null) {
                    String title = (String) args[0];
                    if(deviceInfo!=null){
                        if(deviceInfo.isStoryMachine()){
                            titleView.setText(String.format(getString(R.string.my_machine_title), title));
                        }else{
                            titleView.setText(String.format(getString(R.string.my_kibot_title), title));
                        }

                        QHStatAgentHelper.reportDevicePageOpenEvent(deviceInfo);
                    }

                }
                return Boolean.TRUE;
            }

            case Actions.Share.SHARE_RESPONSE_FAIL: {
                if (args == null || args.length == 0) {
                    CameraToast.showErrorToast(Utils.context, R.string.add_family_fail);
                } else {
                    CameraToast.showErrorToast((String) args[0]);
                }
                return Boolean.TRUE;
            }

            case Actions.Share.SHARE_RESPONSE_SUCCESS: {
                String agree = (String) args[1];
                CameraToast.showToast(Utils.context,
                        agree.equals("0") ? R.string.refuse_family_succ : R.string.add_family_succ);
                return Boolean.TRUE;
            }

            case Actions.Share.SHARE_FRIEND_RESPONSE_SUCCESS: {
                String agree = (String) args[0];
                //刷新机器人成员管理列表
                if (agree.equals("1")) {
                    Intent refreshInvitedAndInvitingListIntent = new Intent();
                    refreshInvitedAndInvitingListIntent.setAction(Const.BROADCAST_REFRESH_INVITED_AND_INVITING_LIST);
                    sendBroadcast(refreshInvitedAndInvitingListIntent);
                }
                CameraToast.showToast(Utils.context,
                        agree.equals("0") ? R.string.refuse_family_succ : R.string.add_friend_succ);
                return Boolean.TRUE;
            }

            case Actions.Share.SHARE_FRIEND_RESPONSE_FAIL: {
                if (args == null || args.length == 0) {
                    CameraToast.showErrorToast(Utils.context, R.string.add_family_fail);
                } else {
                    CameraToast.showErrorToast((String) args[0]);
                }
                return Boolean.TRUE;
            }

            case Actions.Common.UPDATE: {
                int type = (int) args[1];
                if (type == VersionManager.REQUEST_SOURCE_MAIN) {
                    showAvatarRedDot(true);
                    update = (Update) args[0];
                    handerUpdate(update);
                }
                return Boolean.TRUE;
            }

            case Actions.Common.DOWNLOAD_NOW: {
                int type = (int) args[1];
                if (type == VersionManager.REQUEST_SOURCE_MAIN) {
                    downLoadApk((Update) args[0]);
                }
                return Boolean.TRUE;
            }

            case Actions.Common.FORCE_UPDATE: {//需要强制升级,弹窗
                int type = (int) args[1];
                if (type == 1) {
                    showAvatarRedDot(true);
                    update = (Update) args[0];
                    if (update.getResult().isForce == Update.FORCE_TYPE_FORCE) {
                        handerUpdate(update);
                    }
                }

                return Boolean.TRUE;
            }

            case Actions.Common.IS_THE_NEWEST: {
                Preferences.saveNewVersion("");
                return Boolean.TRUE;
            }

            case Actions.Camera.CAMERA_LIST_ACTION: {
                deviceInfoArrayList = PadInfoWrapper.getInstance().getAllPad();
                if (needReceiveAction) {
                    needReceiveAction = false;
                    String sn = "";
                    if (deviceInfoArrayList.size() > 0) {
                        if (!TextUtils.isEmpty(Preferences.getSelectedPad())) {
                            sn = Preferences.getSelectedPad();
                            deviceInfo = getDeviceBySn(sn);
                        } else {
                            //选中上一次的设备，如果没有记录则选中自己是主人的设备
                            for (int i = 0; i < deviceInfoArrayList.size(); i++) {
                                if (deviceInfoArrayList.get(i).role == 1) {
                                    Preferences.saveSelectedPad(deviceInfoArrayList.get(i).sn);
                                    deviceInfo = deviceInfoArrayList.get(i);
                                    sn = deviceInfo.sn;
                                    break;
                                }
                            }
                        }
                        if (TextUtils.isEmpty(sn)) {
                            Preferences.saveSelectedPad(deviceInfoArrayList.get(0).sn);
                            deviceInfo = deviceInfoArrayList.get(0);
                        }
                        addFragment();
                        if (isFromBindRefresh) {
                            isFromBindRefresh = false;
                            showAddFamilyDialog();
                        }
                        //TODO 在此做故事机固件的升级的批量检测,批量借口偶暂时不支持，暂且注掉
                        if(isFromOncreate){
                            isFromOncreate = false;
//                            if(deviceInfoArrayList!=null && deviceInfoArrayList.size()>0){
//                                doBatchUpdateCheck(deviceInfoArrayList);
//                            }
                        }
                    } else {
                        //TODO without bind any devices will show bind guide fragment
                        titleView.setText(getString(R.string.bind_device));
                        Utils.ensureVisbility(menuBtn, View.GONE);
                        Utils.ensureVisbility(dropDownMenu, View.GONE);
                        Utils.ensureVisbility(story_search, View.GONE);
                        Utils.ensureVisbility(enter_player, View.GONE);
                        if(head_layout!=null){
                            Utils.ensureVisbility(head_layout, View.VISIBLE);
                        }
                        addBindFragment();
                    }
                    setMain_head_img();
                } else {
                    CLog.e("zt", "机器人获取到设备列表");
                    String sn = Preferences.getSelectedPad();
                    getDeviceBySn(sn);
                    if (deviceInfoArrayList.size() > 0) {
                        HashMap<String, Integer> snAnPosition = new HashMap<>();
                        HashMap<String, Integer> rolePosititon = new HashMap<>();
                        for (int i = 0; i < deviceInfoArrayList.size(); i++) {
                            snAnPosition.put(deviceInfoArrayList.get(i).sn, i);
                            if (deviceInfoArrayList.get(i).role == 1) {
                                rolePosititon.put(deviceInfoArrayList.get(i).sn, po);
                            }
                        }
                        if (TextUtils.isEmpty(sn)) {
                            for (int i = 0; i < deviceInfoArrayList.size(); i++) {
                                if (deviceInfoArrayList.get(i).role == 1) {
                                    Preferences.saveSelectedPad(deviceInfoArrayList.get(i).sn);
                                    deviceInfo = deviceInfoArrayList.get(i);
                                    deviceInfo.checked = true;
                                    sn = deviceInfo.sn;
                                    break;
                                }
                            }
                        } else {
                            DeviceInfo di = PadInfoWrapper.getInstance().getPadBySn(sn);
                            if (di != null) {
                                if (!TextUtils.isEmpty(di.sn)) {
                                    deviceInfo = di;
                                    deviceInfoArrayList.get(snAnPosition.get(di.sn)).checked = true;
                                } else {
                                    deviceInfo = new DeviceInfo();
                                    if (TextUtils.isEmpty(deviceInfo.sn)) {
                                        for (int i = 0; i < deviceInfoArrayList.size(); i++) {
                                            if (deviceInfoArrayList.get(i).role == 1) {
                                                deviceInfoArrayList.get(i).checked = true;
                                                Preferences.saveSelectedPad(deviceInfoArrayList.get(i).sn);
                                                deviceInfo = deviceInfoArrayList.get(i);
                                                sn = deviceInfo.sn;
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        //如果没有查到上次选中的设备，或者属于自己的设备，则选中第一个
                        if (TextUtils.isEmpty(sn)) {
                            deviceInfoArrayList.get(0).checked = true;
                            Preferences.saveSelectedPad(deviceInfoArrayList.get(0).sn);
                            deviceInfo = deviceInfoArrayList.get(0);
                        }
                        //TODO 大于1台设备显示下拉菜单,只有在第一个TAB才要显示
                        if (deviceInfoArrayList.size() >= 2) {
                            Utils.ensureVisbility(dropDownMenu, getCurrentTabNum() == 0 ? View.VISIBLE : View.GONE);
                        } else {
                            Utils.ensureVisbility(dropDownMenu, getCurrentTabNum() == 0 ? View.INVISIBLE : View.GONE);
                        }
                        mainDeviceRecycleAdapter.setData(deviceInfoArrayList, null);

                    } else {//没有设备
                        GlobalManager.getInstance().getCameraManager().publishAction(Actions.Camera.DEVICE_LIST_EMPTY);
                        Utils.ensureVisbility(View.GONE, menuBtn, story_history);
                        Utils.ensureVisbility(View.GONE, dropDownMenu);
                        deviceInfo = new DeviceInfo();
                    }
                    setMain_head_img();
                    if (!deviceInfo.isStoryMachine()) {
                        GlobalManager.getInstance().getCameraManager().publishAction(Actions.Camera.SELECTED_CAMERA);
                    } else {
                        GlobalManager.getInstance().getCameraManager().publishAction(Actions.Camera.SELECTED_CAMERA_M);
                    }
                    CLog.d(Const.WLJIELOGTAG, "------------------->");
                    GlobalManager.getInstance().getCameraManager()
                            .publishAction(Actions.Camera.LOAD_CAMERA_LIST_DO_ACTION, deviceInfoArrayList, deviceInfo);
                }
                return Boolean.TRUE;
            }

            //TODO 故事机绑定成功,切到刚绑定成功的设备上
            case Actions.Common.BIND_SUCCESS_UPDATE: {
                needReceiveAction = true;
                isFromBindRefresh = true;
                //刷新机器
                GlobalManager.getInstance().getCameraManager().asyncMainLoadMyCamera(0);
                return Boolean.TRUE;
            }

            //TODO 故事机解绑别的设备成功
            case Actions.Common.UNBIND_SUCCESS_UPDATE: {
                needReceiveAction = true;
                isFromBindRefresh = false;
                //刷新机器
                GlobalManager.getInstance().getCameraManager().asyncMainLoadMyCamera(0);
                return Boolean.TRUE;
            }

            //设备被人解绑
            case Actions.Common.HAS_UNBINDED_UPDATE:{
                needReceiveAction = true;
                isFromBindRefresh = false;
                //刷新机器
                boolean isCurrentDevice = (boolean)args[0];
                if(isCurrentDevice){
                    Preferences.saveSelectedPad("");
                }
                GlobalManager.getInstance().getCameraManager().asyncMainLoadMyCamera(0);
                return Boolean.TRUE;
            }

            //有新的聊天消息到达
            case Actions.MachinePlayInfo.NOTIFY_CHAT_MESSAGE_REACHED:{
                FamilyMessageEntity messageEntity = (FamilyMessageEntity)args[0];
                if(messageEntity!=null){
                    if(TextUtils.equals(messageEntity.getSn(), Preferences.getSelectedPad())){
                        if(getCurrentTabNum()==3){
                            //刚好在家庭群tab,不需要做任何提醒
                            Preferences.saveChatMsgTip(messageEntity.getSn(), false);
                        }else{
                            //不在家庭群tab,需要在家庭群tab上给出红点提示
                            if(machineMainFragment!=null){
                                machineMainFragment.showRedDot();
                            }
                        }
                    }else{//不在当前故事机，需要在列表中进行消息提醒
                        showListRedDot(messageEntity.getSn());
                        //TODO 在列表顶部显示红点提示
                        showTopMsg(true);
                    }
                }
                return Boolean.TRUE;
            }

            //故事机在线状态发生了变化
            case Actions.MachinePlayInfo.NOTIFY_MACHINE_ONLINE_STATE_CHANGED: {
                //刷新故事机的在线状态
                GlobalManager.getInstance().getCameraManager().asyncLoadMyCamera(0);
                return Boolean.TRUE;
            }

            //设备头像修改了,需要更新到最新的
            case Actions.UserInfo.APP_UPDATE_INFO_SUCCESS: {
                GlobalManager.getInstance().getCameraManager().asyncLoadMyCamera(0);
                return Boolean.TRUE;
            }
        }
        return null;
    }

    private DeviceInfo getDeviceBySn(String sn) {
        DeviceInfo device = PadInfoWrapper.getInstance().getPadBySn(sn);
        return device;
    }

    @Override
    public int getProperty() {
        return 0;
    }

    public int dip2px(float dpValue) {
        final float scale = getResources().getDisplayMetrics().density;
        return (int) (dpValue * scale + 0.5f);
    }

    public void backgroundAlpha(float bgAlpha) {
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.alpha = bgAlpha; //0.0-1.0
        getWindow().setAttributes(lp);
    }

    public void showPopMenuDevice() {
        Rect frame = new Rect();
        getWindow().getDecorView().getWindowVisibleDisplayFrame(frame);
        int offsetY = frame.top + dip2px(50);
        int offsetX = dip2px(10);
        backgroundAlpha(1);
        View popView = LayoutInflater.from(this).inflate(R.layout.popupwindow_menu, null);
        Utils.ensureVisbility(View.GONE, popView.findViewById(R.id.lv_menu));
        RecyclerView myList = (RecyclerView) popView.findViewById(R.id.device_checkList);
        Utils.ensureVisbility(View.VISIBLE, myList);
        myList.setLayoutManager(new LinearLayoutManager(this));
        myList.setAdapter(mainDeviceRecycleAdapter);
        mainDeviceRecycleAdapter.setOnViewClick(this);
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int screenHeight = dm.heightPixels;
        if (deviceInfoArrayList.size() > 10) {
            popupWindow = new PopupWindow(popView, ViewGroup.LayoutParams.MATCH_PARENT, screenHeight / 2, true);
        } else {
            popupWindow = new PopupWindow(popView, ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT, true);
        }
        popupWindow.setBackgroundDrawable(new BitmapDrawable(getResources(), (Bitmap) null));
        popupWindow.setOutsideTouchable(true);
        popupWindow.setAnimationStyle(android.R.style.Animation_Dialog);
        popupWindow.showAtLocation(rootView, Gravity.LEFT | Gravity.TOP, offsetX, offsetY);

        // 设置背景颜色变暗
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.alpha = 0.6f;
        getWindow().setAttributes(lp);

        popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                dropDownMenu.setImageResource(R.drawable.arrow_down_white);

                WindowManager.LayoutParams lp = getWindow().getAttributes();
                lp.alpha = 1f;
                getWindow().setAttributes(lp);
            }
        });
    }

    @TargetApi(19)
    public static void setTranslucentStatus(Activity activity, boolean on) {
        if (Build.VERSION.SDK_INT == Build.VERSION_CODES.KITKAT) {
            SystemBarTintManager tintManager = new SystemBarTintManager(activity);
            tintManager.setStatusBarTintEnabled(true);
            tintManager.setNavigationBarTintEnabled(false);
            tintManager.setStatusBarTintColor(activity.getResources().getColor(R.color.colorPrimary));
        }
    }

    //切换设备
    @Override
    public void click(int po) {
        int lastPosition = mainDeviceRecycleAdapter.p;

        DeviceInfo lastDeviceInfo = mainDeviceRecycleAdapter.getItem(lastPosition);
        lastDeviceInfo.checked = false;
        mainDeviceRecycleAdapter.notifyItemChanged(lastPosition);

        DeviceInfo deviceInfoTemp = mainDeviceRecycleAdapter.getItem(po);
        deviceInfoTemp.checked = true;
        mainDeviceRecycleAdapter.notifyItemChanged(po);
        mainDeviceRecycleAdapter.cancleRedPot(deviceInfoTemp.sn);
        boolean flag = !(deviceInfoTemp.deviceType).equals(deviceInfo.deviceType) ;
        this.deviceInfo = deviceInfoTemp;
        Preferences.saveSelectedPad(deviceInfoTemp.sn);
        int deviceType = Utils.getDeviceType(deviceInfoTemp.deviceType);
        changeType(flag, deviceType);
        setMain_head_img();
        GlobalManager.getInstance().getCameraManager().publishAction(Actions.Camera.LOAD_OK);
        CLog.d(Const.WLJIELOGTAG, "-------------->time");
        if (!deviceInfoTemp.isStoryMachine()) {
            if (null != kibotMainFragment){
                kibotMainFragment.doChangeDevice(deviceInfo);
            }
        } else {
            if (null != machineMainFragment){
                machineMainFragment.doChangeDevice(deviceInfo);
            }

        }
        popupWindow.dismiss();
    }


    @Override
    public void clearTopMsg() {
        Utils.ensureVisbility(topMsgTip, View.GONE);
    }

    @Override
    public void showTopMsgTip() {
        if(topMsgTip!=null){
            showTopMsg(true);
        }
    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }

    @Override
    protected void onStop() {
        super.onStop();
        Glide.with(this).onStop();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Glide.with(this).resumeRequests();
    }

    private void checkUpdate() {
        if (Utils.isNetworkAvailable(this)) {
            GlobalManager.getInstance().getCommonManager().checkNewVersion(VersionManager.REQUEST_SOURCE_MAIN);
        }
    }

    private void handerUpdate(Update update) {
        if (update.result.isForce == Update.FORCE_TYPE_FORCE || //强升必须弹窗
                update.result.isForce == Update.FORCE_TYPE_POPUP) { // 弹窗提醒，每次都弹，但是可以继续使用
            showUpdateDailog(update);
        } else {
            if(isTaskTop()){
                if (Preferences.getPreTime() == 0) {
                    Preferences.savePreTime(System.currentTimeMillis());
                    showUpdateDailog(update);
                } else {
                    if (Utils.isOver24Hour(Preferences.getPreTime())) {
                        showUpdateDailog(update);
                        Preferences.savePreTime(System.currentTimeMillis());
                    }
                }
            }
        }
    }

    public void setMain_head_img() {
        String avatarUrl = AccUtil.getInstance().getAvatorUrl();
        Glide.with(Utils.context).load(avatarUrl)
                .placeholder(R.drawable.default_profile)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .transform(new GlideCircleTransform(Utils.context))
                .priority(Priority.HIGH)
                .error(R.drawable.default_profile)
                .crossFade().into(main_head_img);
    }

    public void showAvator(boolean show) {
        Utils.ensureVisbility(show ? View.VISIBLE : View.INVISIBLE, view2);
    }

    private void showInviteFriend() {
        // 平板加平板
        Intent intent = new Intent(this, BindDeviceFrameActivity.class);
        intent.putExtra("mode", BindDeviceFrameActivity.MODE_FRIEND_FIND);
        intent.putExtra("sn", deviceInfo.getSn());
        startActivity(intent);
    }

    private void showBindPhone() {
        // 手机号直接绑定
        Intent intent = new Intent(this, BindDeviceFrameActivity.class);
        intent.putExtra("mode", BindDeviceFrameActivity.MODE_BIND_PHONE);
        intent.putExtra("sn", deviceInfo.getSn());
        intent.putExtra(StoryMachineConsts.KEY_SET_DEVICE_TYPE,deviceInfo.deviceType);
        startActivity(intent);
    }

    private void sendtoWChat() {
        if (Utils.isNetworkAvailable(this)) {
            GlobalManager.getInstance().getShareManager().asyncShareShare(deviceInfo.getSn(), "2", "",
                    deviceInfo.isStoryMachine() ? Constants.DeviceType.STORYMACHINE
                            : Constants.DeviceType.KIBOTMACHINE);
        } else {
            CameraToast.show(null, R.string.network_disabled, Toast.LENGTH_SHORT);
        }
    }

    private void sendtoSMS() {
        if (Utils.isNetworkAvailable(this)) {
            Intent intent = new Intent(this, ChooseContactActivity.class);
            intent.putExtra(Constants.SHARE_TYPE, Constants.ShareType.SHARE_TYPE_MOBILE);
            startActivityForResult(intent, Constants.PHONE_LIST);
        } else {
            CameraToast.show(null, R.string.network_disabled, Toast.LENGTH_SHORT);
        }
    }

    private void qrShare() {
        if (Utils.isNetworkAvailable(this)) {
            Intent intent = new Intent(this, ShareQRActivity.class);
            intent.putExtra("sn", deviceInfo.getSn());
            intent.putExtra(Constants.SHARE_TYPE, Constants.ShareType.SHARE_TYPE_QRCODE);
            startActivityForResult(intent, Constants.PHONE_QR);
        } else {
            CameraToast.show(null, R.string.network_disabled, Toast.LENGTH_SHORT);
        }
    }

    @Override
    protected void pushMessageNotify(CommonMessageEntity messageEntity) {
        if (messageEntity.messageType == CommonMessageEntity.ROBOT_LOCK_SCREEN_RECEIPT) {
            MessageInfoEntity messageInfoEntity = (MessageInfoEntity) messageEntity.data;
            if(messageInfoEntity.data!=null && TextUtils.equals(messageInfoEntity.data.senderInfo.sn, Preferences.getSelectedPad())){
                kibotMainFragment.handlerMessage(messageEntity);
            }
        }
    }

    /**
     * 设置下拉选择设备列表按钮是否可点击
     *
     * @param clickable
     */
    void setDeviceSelectViewClickable(boolean clickable) {
        if (view2 != null) {
            view2.setClickable(clickable);
        }
    }

    @Override
    public void finish() {
        super.finish();
    }

    //获取当前在第几个tab
    public int getCurrentTabNum() {
        if (machineMainFragment != null && machineMainFragment.isAdded()) {
            return machineMainFragment.selected;
        } else if (kibotMainFragment != null && kibotMainFragment.isAdded()) {
            return kibotMainFragment.selected;
        }
        return 0;
    }

    //是否切换小视频tab
    public boolean selectSmallVideo(){
        if (machineMainFragment != null && machineMainFragment.isAdded()) {
            return machineMainFragment.selected == 2;
        } else if (kibotMainFragment != null && kibotMainFragment.isAdded()) {
            return kibotMainFragment.selected == 1;
        }
        return false;
    }

    //是否切换到家庭群tab
    public boolean selectFamilyGroup(){
        if (machineMainFragment != null && machineMainFragment.isAdded()) {
            return machineMainFragment.selected == 3;
        }
        return false;
    }

    @Override
    public void onSaveInstanceState(Bundle outState, PersistableBundle outPersistentState) {
        super.onSaveInstanceState(outState, outPersistentState);
        CLog.e("zt","mainactivity onSaveInstanceState");
    }


    //显示列表中的红点
    public void showListRedDot(String sn){
        if(mainDeviceRecycleAdapter!=null){
            mainDeviceRecycleAdapter.setRedPot(sn);
        }
    }

    //显示title上的消息提醒
    public void showTopMsg(boolean show){
        if(show){
            if (machineMainFragment != null && machineMainFragment.isAdded() && machineMainFragment.selected==0 && machineMainFragment.isFirstPage()) {
                Utils.ensureVisbility(topMsgTip, View.VISIBLE);
            } else if (kibotMainFragment != null && kibotMainFragment.isAdded() && kibotMainFragment.selected==0) {
                Utils.ensureVisbility(topMsgTip, View.VISIBLE);
            }
        }else{
            Utils.ensureVisbility(topMsgTip, View.GONE);
        }
    }

    //显示用户头像上的红点
    public void showAvatarRedDot(boolean show){
        Utils.ensureVisbility(mRedPotIv, show ? View.VISIBLE : View.GONE);
    }

    //切回主tab,是否显示消息
    public void needShowTopMsg(){
        if(mainDeviceRecycleAdapter!=null){
            mainDeviceRecycleAdapter.needShowTopMsg();
        }
    }

    //TODO 故事机固件批量升级检测
    private void doBatchUpdateCheck(ArrayList<DeviceInfo> deviceInfoList){
        ArrayList<DeviceInfo> cloneList = deviceInfoList;
        if(deviceInfoList.size() > 0){
            Observable.just(cloneList)
                    .subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .flatMap(new Func1<ArrayList<DeviceInfo>, Observable<JSONArray>>(){
                        @Override
                        public Observable<JSONArray> call(ArrayList<DeviceInfo> deviceInfos) {
                            ArrayList<DeviceInfo> tmpList = new ArrayList<>();
                            for(DeviceInfo deviceInfo : deviceInfos){
                                if(deviceInfo.isStoryMachine()){
                                    tmpList.add(deviceInfo);
                                }
                            }
                            JSONArray array = new JSONArray();
                            if(deviceInfos.size()>0 && versionManager!=null){//存在故事机
                                for(DeviceInfo deInfo : deviceInfos){
                                    if(!TextUtils.isEmpty(deInfo.version)){
                                        String[] tmp = deInfo.version.split("|");
                                        if(tmp!=null && tmp.length==2){
                                            String version = tmp[0];
                                            int versionCode= Integer.valueOf(tmp[1]);
                                            try{
                                                JSONObject jo = new JSONObject();
                                                jo.put("from", "mpc_and"); // 固定写法
                                                jo.put("taskId", UUID.randomUUID().toString()); // 生成唯一标识就行,用于排查问题
                                                jo.put("projectId", "4"); // 项目id,与后台网站申请的一样
                                                jo.put("appId", "360Smartstory_fm_update");//appid
                                                jo.put("appType", "2"); // 1表示软件版本（app），2表示硬件版本（固件等）
                                                jo.put("version", version);
                                                jo.put("versionCode", versionCode);
                                                jo.put("deviceId", deInfo.getSn());
                                            }catch (JSONException e){
                                                e.printStackTrace();
                                            }
                                        }
                                    }
                                }
                            }
                            return Observable.just(array);
                        }
                    })
                    .observeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Action1<JSONArray>() {
                        @Override
                        public void call(JSONArray jsonArray) {
                            if(jsonArray!=null && jsonArray.length()>0){
                                UpdateBatch updateBatch = versionManager.checkFmVersionBatch(jsonArray);
                                if(updateBatch.getErrorCode()==0){
                                }
                            }
                        }
                    });
        }
    }

    public void showPopMenuSetting() {
        Rect frame = new Rect();
        getWindow().getDecorView().getWindowVisibleDisplayFrame(frame);
        int offsetY = frame.top + dip2px(50+4);
        int offsetX = dip2px(5);
        View parentView = LayoutInflater.from(this).inflate(R.layout.demo_main, null);
        final View popView = LayoutInflater.from(this).inflate(R.layout.popupwindow_setting, null);
        final PopupWindow popupWindow = new PopupWindow(popView, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true);
        final View inviteView = popView.findViewById(R.id.invite);
        View devideLine = popView.findViewById(R.id.splite);

        //邀请家人
        inviteView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss();
                if(deviceInfo.isStoryMachine()){
                    showBindPhone();
                }else{
                    showPopupWindow(appbar);
                }
            }
        });

        //绑定设备
        popView.findViewById(R.id.bing).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss();
                //进入绑定页面
                CommonBindActivity.startCommonBindActivity(MainActivity.this);
            }
        });

        popView.findViewById(R.id.device_manage).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss();
                //进入设置中心
                if(deviceInfo.isStoryMachine()){
                    Intent intent = new Intent(MainActivity.this, MachineSettingActivity.class);
                    intent.putExtra("dev", deviceInfo);
                    startActivityForResult(intent, 1200);
                }else{
                    Intent intent = new Intent(MainActivity.this, CameraSettingActivity.class);
                    intent.putExtra("dev", deviceInfo);
                    startActivityForResult(intent, 1200);
                }
            }
        });

        if(deviceInfo!=null){
            if(deviceInfo.getRole()==1){
                Utils.ensureVisbility(devideLine, View.VISIBLE);
                Utils.ensureVisbility(inviteView, View.VISIBLE);
            }else{
                Utils.ensureVisbility(devideLine, View.GONE);
                Utils.ensureVisbility(inviteView, View.GONE);
            }
        }

        popupWindow.setBackgroundDrawable(new BitmapDrawable(getResources(), (Bitmap) null));
        popupWindow.setOutsideTouchable(true);
        popupWindow.setAnimationStyle(android.R.style.Animation_Dialog);
        popupWindow.showAtLocation(parentView, Gravity.RIGHT | Gravity.TOP, offsetX, offsetY);

        // 设置背景颜色变暗
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.alpha = 0.6f;
        getWindow().setAttributes(lp);

        popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                WindowManager.LayoutParams lp = getWindow().getAttributes();
                lp.alpha = 1f;
                getWindow().setAttributes(lp);
            }
        });
    }

    public void handleAdd(){
        showPopMenuSetting();
    }

}
