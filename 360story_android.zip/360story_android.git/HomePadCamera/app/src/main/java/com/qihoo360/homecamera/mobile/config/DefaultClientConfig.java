
package com.qihoo360.homecamera.mobile.config;

import com.qihoo360.homecamera.mobile.BuildConfig;

public class DefaultClientConfig {

    public static final String FROM = "mpc_pingmuban_and";
    public static final String SIGN_KEY = "d707015fa";
    public static final String CRYPT_KEY = "7b8a6d63";


    public static final int HTTP_TIME_OUT = 1000 * 200;

    private static final int APPID = 2030;

    private static final String DEFAULT_KEY = "51dd2b87308056da9f280b8e18b8bc79";

    private static final String SERVER_DO_MAIN = "qlogin.txl.360.cn";

    private static final int CLIENT_VERSION = 101;

    private static final String PHONE_SERVICE = "com.qihoo360.homecamera.mobile.service.PhoneService";

    private static final String IM_SERVICE = "com.qihoo360.homecamera.mobile.service.ImService";

    public static final String DB_Prefix = "_db";

    /**
     * int appid, String defaultKey, String server, int clientVersion, String
     * phoneService, String imService
     */
    // public static ClientConfig Config = new ClientConfig(APPID, DEFAULT_KEY,
    // SERVER_DO_MAIN, CLIENT_VERSION, PHONE_SERVICE, IM_SERVICE);


    public static String DeviceId = "device_id";
    public static boolean IS_HTTP_GET = false;
    public static String LOGINED_USER = "LOGINED_USER";

    public static final String HOST = "q.kibot.360.cn";
    // TODO: 2016/6/15  kibot.360.cn故事
    public static final String STORY_HOST = "kibot.360.cn";
    public static final String APP_NAME = "360kibot";

    // private static Random _rand = new Random();

    /**
     * test server: 111.206.56.90 bjcc online server: 111.206.52.96 online
     * domain: qlogin.txl.360.cn 2030 51dd2b87308056da9f280b8e18b8bc79 2060
     * 5518b28f4c672a594440701b51dd2b87
     */


    // url 信息---------------------------------------------
    public static final String APP_SERVER_DOMAIN_DEFAULT = "https://q.kibot.360.cn";
    public static final String APP_SERVER_DOMAIN_TEST ="https://101.199.102.207"; // 新测试环境ip

    public static final String APP_SERVER_DOMAIN_HTTP_DEFAULT = "http://q.kibot.360.cn"; // 线上
    public static final String APP_SERVER_DOMAIN_HTTP_TEST ="http://101.199.102.207"; // 新测试环境ip

    public static final String APP_SERVER_DOMAIN_HTTP_SP ="http://kibot.360.cn";
    public static final String APP_SERVER_DOMAIN_HTTP_TEST_SP ="http://10.108.213.193";

    public static String APP_SERVER_DOMAIN; // HTTPS线上
    public static String APP_SERVER_DOMAIN_HTTP; // HTTP
    public static int abount = 0;

    static {
        if (BuildConfig.isDebug) {
            APP_SERVER_DOMAIN = APP_SERVER_DOMAIN_TEST;
        } else {
            APP_SERVER_DOMAIN = APP_SERVER_DOMAIN_DEFAULT;
        }
    }

    static {
        if (BuildConfig.isDebug) {
            APP_SERVER_DOMAIN_HTTP = APP_SERVER_DOMAIN_HTTP_TEST;
        } else {
            APP_SERVER_DOMAIN_HTTP = APP_SERVER_DOMAIN_HTTP_DEFAULT;
        }
    }

    public static final String APP_LOGIN_URL = "/app/login";

    public static final String APP_LOGOUT_URL = "/app/logout";

    public static final String APP_GETLIST_URL = "/app/getList";

    public static final String BIND_DEVICE_URL = "/app/bind";

    public static final String UN_BIND_DEVICE_URL = "/app/unbind";

    public static final String SHARE_SHARE_URL = "/share/share";
    public static final String SHARE_ACCEPT_URL = "/share/accept";
    public static final String SHARE_CANCEL_URL = "/share/cancel";
    public static final String SHARE_CANCEL_SHARING_URL = "/share/cancelSharing";//已经废弃
    public static final String SHARE_GET_LIST_URL = "/share/getList";
    public static final String SHARE_GET_SHARING_LIST_URL = "/share/getSharingList";//已经废弃
    public static final String SHARE_GETINFO_URL = "/share/getInfo";
    public static final String SHARE_REQUEST_URL = "/share/request";
    public static final String SHARE_RESPONSE_URL = "/share/response";
    public static final String SHARE_SET_REMARK_URL = "/share/remarkName";
    public static final String SET_ACL = "/share/setAcl";
    public static final String UPDATE_TITLE_HEAD_URL = "/app/updateTitle";
    public static final String APP_ALBUM_LIST_URL = "/appAlbum/list";
    public static final String APP_VIDEO_LIST_URL = "/videoClip/getlist";
    public static final String APP_VIDEO_DELETE_URL = "/videoClip/delete";
    //小视频分享
    public static final String APP_VIDEO_CREATE_SHARE = "/videoClip/createShare";
    public static final String APP_VIDEO_GET_SHARE_INFO = "/videoClip/getShareInfo";

    public static final String SEARCH_WORD_KEY_URL = "/story/getSug";
    public static final String SEARCH_WORD_URL = "/story/search";

    public static final String VOICE_IDIOM_URL = "/stories/c/voiceIdiom/t/voiceIdiom/list/%d.html";
    public static final String VOICE_ALLEGORY_URL = "/stories/c/voiceAllegory/t/voiceAllegory/list/%d.html";
    public static final String VOICE_FAIRYTALE_URL = "/stories/c/voiceFairyTale/t/voiceFairyTale/list/%d.html ";


    public static final String APP_GET_INFO_URL = "/app/getInfo";
    public static final String APP_UPDATE_INFO_URL = "/app/updateInfo";
    public static final String SHARE_SET_RELATION_URL = "/share/setRelation";
    //upload---------------------------------// STOPSHIP: 2016/3/2

    //机器人中录制音频文件的上传的=接口
    public static final String UPLOAD_STEP_ONE = "/storyRecord/upload";
    public static final String UPLOAD_STEP_TWO = "/storyRecord/addInfo";

    public static final String SHARE_STORY_URL = "/storyRecord/createShare";



    //成语故事	http://pad.jia.360.cn/stories/c/voiceIdiom/t/voiceIdiom/list/1.html	末尾数字是不同页面，从1开始，翻页更换数字即可
    public static final String VOICEIDIOM_URL = "http://kibot.360.cn/stories/c/voiceIdiom/t/voiceIdiom/list/%d.html";
    //寓言故事	http://pad.jia.360.cn/stories/c/voiceAllegory/t/voiceAllegory/list/1.html	末尾数字是不同页面，从1开始，翻页更换数字即可
    public static final String VOICEALLEGORY_URL = "http://kibot.360.cn/stories/c/voiceAllegory/t/voiceAllegory/list/%d.html";
    //童话故事	http://pad.jia.360.cn/stories/c/voiceFairyTale/t/voiceFairyTale/list/1.html	末尾数字是不同页面，从1开始，翻页更换数字即可
    public static final String VOICEFAIRYTALE_URL = "http://kibot.360.cn/stories/c/voiceFairyTale/t/voiceFairyTale/list/%d.html";

    //已录故事
    /**
     * sn	IPC的序列化	string	是
     * page	分页页码	int	否	默认0
     * count	每页的数量	int	否	默认10， 最大值50
     */
    public static final String RECORDED_URL = "/storyRecord/getList";
    public static final String DEL_RECORD_STORY_URL = "/storyRecord/deleteInfo";

    /**
     * APP升级服务的地址
     */
    public static final String APP_UPDATE = "https://ota2.jia.360.cn/upgrade/getNewVersion";
    //批量升级
    public static final String FM_UPDATE_BATCH = "https://ota2.jia.360.cn/upgrade/getBatchNew";

    public static final String PERSION_SET_SETTING = "/setting/set";
    public static final String PERSION_GET_SETTING = "/setting/get";
    public static final String PERSION_GET_SPACE_INFO = "/space/getInfo";

    public static final String SHARE_STORY_HTML5 = "http://kibot.360.cn/stories/story.html?act=%s&uname=%s&uimg=%s&time%s&vurl=%s&purl=%s";

    public static final String GET_IPC_ALL = "/setting/getIpcAll";
    public static final String SET_SETTING_SETIPCSOME = "/setting/setIpcSome";

    public static final String COMMAND_MESSAGE = "/app/command";

    public static final String KIBOT_DEVICE = "kibot";
    public static final String STORY_DEVICE = "story";

    //故事搜索页面URL
    public static final String STORY_SEARCH_URL = "https://kibot.360.cn/story/search.html";
    //故事机家庭群中音频文件的上传
    public static final String CHAT_GET_UPLOADINFO = "/chat/getUploadInfo";
    //故事机家庭群的消息发送
    public static final String CHAT_SEND_MSG = "/chat/sendMsg";
    //取消360账号的url
    public static final String CANCLE_ACCOUNT_URL = "http://i.360.cn/cancel/wap?src=mpc_pingmuban_and&skin=blue&client=app&isShowSuccess=1&appJumpNotify=1&quc_lang=zh_CN";
}
