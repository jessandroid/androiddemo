package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

/**
 * Created by zhaojunbo on 2016/1/22.
 * desc:
 */
public class ShareGetListEntity extends Head{

    public Data data;

    public static class Data implements Parcelable {
        public ArrayList<ShareUserEntity> data = new ArrayList<ShareUserEntity>();

        public String total;

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeTypedList(data);
            dest.writeString(this.total);
        }

        public Data() {
        }

        protected Data(Parcel in) {
            this.data = in.createTypedArrayList(ShareUserEntity.CREATOR);
            this.total = in.readString();
        }

        public static final Creator<Data> CREATOR = new Creator<Data>() {
            public Data createFromParcel(Parcel source) {
                return new Data(source);
            }

            public Data[] newArray(int size) {
                return new Data[size];
            }
        };
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(this.data, 0);
    }

    public ShareGetListEntity() {
    }

    protected ShareGetListEntity(Parcel in) {
        this.data = in.readParcelable(Data.class.getClassLoader());
    }

    public static final Parcelable.Creator<ShareGetListEntity> CREATOR = new Parcelable.Creator<ShareGetListEntity>() {
        public ShareGetListEntity createFromParcel(Parcel source) {
            return new ShareGetListEntity(source);
        }

        public ShareGetListEntity[] newArray(int size) {
            return new ShareGetListEntity[size];
        }
    };
}
