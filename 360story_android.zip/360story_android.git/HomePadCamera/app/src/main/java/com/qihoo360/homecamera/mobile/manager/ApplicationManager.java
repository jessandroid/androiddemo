package com.qihoo360.homecamera.mobile.manager;

import com.qihoo360.homecamera.mobile.core.manager.util.ActionPublisherWithThreadPoolBase;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/1/22
 * Time: 14:39
 * To change this template use File | Settings | File Templates.
 */
public class ApplicationManager extends ActionPublisherWithThreadPoolBase {
    @Override
    protected void asyncDoNamedJob(String jobName, Object... args) {

    }
}
