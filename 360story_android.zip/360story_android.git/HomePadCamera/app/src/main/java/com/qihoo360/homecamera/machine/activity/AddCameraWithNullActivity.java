
package com.qihoo360.homecamera.machine.activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.activity.BaseActivity;
import com.qihoo360.homecamera.mobile.utils.Utils;

/**
 * Created by wdynetposa on 2015/5/6.
 */
public class AddCameraWithNullActivity extends MachineBaseActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTintManagerQWork(true);
        tintManager.setStatusBarTintColor(Color.parseColor("#F0F0F0"));
        setContentView(R.layout.activity_add_camera_with_null);

        Utils.ensureVisbility(View.GONE, findViewById(R.id.btn_buy_camera));
    }

    public void onNext(View v) {
        switch (v.getId()) {
            case R.id.btn_conn_camera:
                Intent intentCoon = new Intent(this, SetupGuideActivity.class);
                intentCoon.putExtra("directSource", 2);
                startActivity(intentCoon);
                finish();
                break;
            case R.id.btn_buy_camera:
                Intent intentBuy = new Intent(this, MoreActivity.class);
                intentBuy.putExtra("fragmentId", MoreActivity.PURCHASE_FRAGMENT);
                startActivity(intentBuy);
                break;
        }
    }
}
