package com.qihoo360.homecamera.machine.ui.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.TextView;

import com.aspsine.swipetoloadlayout.SwipeLoadMoreTrigger;
import com.aspsine.swipetoloadlayout.SwipeRefreshTrigger;
import com.aspsine.swipetoloadlayout.SwipeTrigger;

/**
 * Created by zhangtao-iri on 2016/12/30.
 */
public class CustomRefreshHeadView extends TextView implements SwipeRefreshTrigger, SwipeTrigger, SwipeLoadMoreTrigger {

    public CustomRefreshHeadView(Context context) {
        super(context);
    }

    public CustomRefreshHeadView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CustomRefreshHeadView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    private boolean uploaderOver = false;
    private boolean downLoaderOver = false;
    private boolean loadMore = false;
    private boolean isCompleted = false;
    @Override
    public void onRefresh() {
        loadMore = false;
        setText("正在加载数据...");
    }

    @Override
    public void onPrepare() {
        isCompleted = false;
        setText("开始加载数据");
    }

    @Override
    public void onMove(int i, boolean b, boolean b1) {
        if(!isCompleted){
            setText("开始加载数据");
        }
    }

    @Override
    public void onRelease() {
    }

    @Override
    public void onComplete() {
        isCompleted = true;
        if(loadMore){
            if(downLoaderOver){
                setText("没有更多了");
            }else{
                setText("加载成功");
            }
        }else{
            if(uploaderOver){
                setText("没有更多了");
            }else{
                setText("加载成功");
            }
        }
    }

    @Override
    public void onReset() {
        setText("");
    }

    @Override
    public void onLoadMore() {
        loadMore = true;
        setText("正在加载数据...");
    }

    public void setUpLoadOver(boolean isOver){
        this.uploaderOver = isOver;
    }

    public void setDownLoaderOver(boolean isOver){
        this.downLoaderOver = isOver;
    }

}
