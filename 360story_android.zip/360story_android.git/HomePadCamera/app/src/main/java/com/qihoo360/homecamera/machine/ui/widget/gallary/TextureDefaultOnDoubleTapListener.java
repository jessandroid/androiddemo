package com.qihoo360.homecamera.machine.ui.widget.gallary;

import android.graphics.RectF;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.TextureView;

/**
 * Provided default implementation of GestureDetector.OnDoubleTapListener, to be overriden with custom behavior, if needed
 * <p>&nbsp;</p>
 * To be used via {@link uk.co.senab.photoview.TextureViewAttacher#setOnDoubleTapListener(GestureDetector.OnDoubleTapListener)}
 */
public class TextureDefaultOnDoubleTapListener implements GestureDetector.OnDoubleTapListener {

    private TextureViewAttacher TextureViewAttacher;

    /**
     * Default constructor
     *
     * @param TextureViewAttacher TextureViewAttacher to bind to
     */
    public TextureDefaultOnDoubleTapListener(TextureViewAttacher TextureViewAttacher) {
        setPhotoViewAttacher(TextureViewAttacher);
    }

    /**
     * Allows to change TextureViewAttacher within range of single instance
     *
     * @param newPhotoViewAttacher TextureViewAttacher to bind to
     */
    public void setPhotoViewAttacher(TextureViewAttacher newPhotoViewAttacher) {
        this.TextureViewAttacher = newPhotoViewAttacher;
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent e) {
        if (this.TextureViewAttacher == null)
            return false;

        TextureView imageView = TextureViewAttacher.getImageView();

        if (null != TextureViewAttacher.getOnPhotoTapListener()) {
            final RectF displayRect = TextureViewAttacher.getDisplayRect();

            if (null != displayRect) {
                final float x = e.getX(), y = e.getY();

                // Check to see if the user tapped on the photo
                if (displayRect.contains(x, y)) {

                    float xResult = (x - displayRect.left)
                            / displayRect.width();
                    float yResult = (y - displayRect.top)
                            / displayRect.height();

                    TextureViewAttacher.getOnPhotoTapListener().onPhotoTap(imageView, xResult, yResult);
                    return true;
                }
            }
        }
        if (null != TextureViewAttacher.getOnViewTapListener()) {
            TextureViewAttacher.getOnViewTapListener().onViewTap(imageView, e.getX(), e.getY());
        }

        return false;
    }

    @Override
    public boolean onDoubleTap(MotionEvent ev) {
        if (TextureViewAttacher == null)
            return false;

        try {
            float scale = TextureViewAttacher.getScale();
            float x = ev.getX();
            float y = ev.getY();

            if (scale < TextureViewAttacher.getMediumScale()) {
                TextureViewAttacher.setScale(TextureViewAttacher.getMediumScale(), x, y, true);
            } else if (scale >= TextureViewAttacher.getMediumScale() && scale < TextureViewAttacher.getMaximumScale()) {
                TextureViewAttacher.setScale(TextureViewAttacher.getMaximumScale(), x, y, true);
            } else {
                TextureViewAttacher.setScale(TextureViewAttacher.getMinimumScale(), x, y, true);
            }

            // TODO 统计
//            if (AndroidUtil.isPortrait()) {
//                AccUtil.getInstance().mRtickNoSn.addStat(Stat.VIDEO_ZOOM_DEFAULT_PORTRAIT,1);
//            }else{
//                AccUtil.getInstance().mRtickNoSn.addStat(Stat.VIDEO_ZOOM_DEFAULT_LAND,1);
//            }
        } catch (ArrayIndexOutOfBoundsException e) {
            // Can sometimes happen when getX() and getY() is called
        }

        return true;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent e) {
        // Wait for the confirmed onDoubleTap() instead
        return false;
    }

}
