package com.qihoo360.homecamera.mobile.db;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.qihoo360.homecamera.mobile.entity.UploadToken;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.utils.MD5Util;

import java.util.ArrayList;
import java.util.List;


public class FileUploadWrapper extends AbstractWrapper {

    private static FileUploadWrapper fileUploadWrapper;
    private static final String TABLE_NAME = "upload_tab";

    private FileUploadWrapper() {

    }

    public synchronized static FileUploadWrapper getInstance() {
        if (fileUploadWrapper == null) {
            fileUploadWrapper = new FileUploadWrapper();
        }
        return fileUploadWrapper;
    }


    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int toVersion) {
        switch (toVersion) {
            case 2:
                break;
            default:
                break;
        }
    }

    @Override
    public void onOpen(SQLiteDatabase db) {

    }


    public void setUserToken(UploadToken uploadToken, int errorCode, String sn) {
        synchronized (FileUploadWrapper.class) {
            SQLiteDatabase sqLiteDatabase = GlobalManager.getInstance().config().db.getWritableDatabase();
            if (sqLiteDatabase == null) {
                return;
            }
            try {
                sqLiteDatabase.beginTransaction();
                fileUploadWrapper.write(sqLiteDatabase, uploadToken, errorCode, sn);
                sqLiteDatabase.setTransactionSuccessful();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (sqLiteDatabase != null) {
                    sqLiteDatabase.endTransaction();
                }
            }
        }
    }


    // FIXME: 2016/3/22 写入数据库
    private void write(SQLiteDatabase db, UploadToken uploadToken, int errorCode, String sn) {
        synchronized (FileUploadWrapper.class) {
            ContentValues values = new ContentValues();
            values.put(Field.KEY_SN, sn);
            values.put(Field.KEY_ERROR_CODE, errorCode);
            values.put(Field.KEY_FLASH, uploadToken.uploadOOS.toJson());
            values.put(Field.KEY_TITLE_MD5, MD5Util.getMD5code(uploadToken.name));
            values.put(Field.KEY_V_1, uploadToken.toJson());
            try {
                if (exist(sn, MD5Util.getMD5code(uploadToken.name))) {
                    db.update(TABLE_NAME, values, "sn=?", new String[]{sn});
                } else {
                    values.put(Field.KEY_SN, sn);
                    db.insert(TABLE_NAME, null, values);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private boolean exist(String sn, String title) throws Exception {
        boolean exist = false;
        if (TextUtils.isEmpty(sn) || TextUtils.isEmpty(title)) {
            throw new Exception("sn or code is null");
        }
        long queryRes = queryQidCount(sn, title);
        if (queryRes > 0) {
            exist = true;
        }
        return exist;
    }

    /**
     * find uploadToke
     *
     * @param sn
     * @param errorCode
     * @return
     */
    public List<UploadToken> getPublicTokeList(String sn, int errorCode) {
        List<UploadToken> uploadTokens = new ArrayList<>();
        SQLiteDatabase db = GlobalManager.getInstance().config().db.getReadableDatabase();
        Cursor cursor = null;
        Gson gson = new Gson();
        try {
            if (errorCode > 0) {
                cursor = db.query(TABLE_NAME, null, "sn = ? ", new String[]{sn}, null, null, "_id DESC");
            } else {
                cursor = db.query(TABLE_NAME, null, "sn = ? and " + Field.KEY_ERROR_CODE + " = ?", new String[]{sn, String.valueOf(errorCode)}, null, null, "_id DESC");
            }
            while (cursor.moveToNext()) {
                String arg_1 = cursor.getString(cursor.getColumnIndex(Field.KEY_V_1));
                int _id = cursor.getInt(cursor.getColumnIndex(Field.KEY_ID));
                UploadToken uploadToken = gson.fromJson(arg_1, UploadToken.class);
                uploadToken._id = _id;
                uploadTokens.add(uploadToken);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return uploadTokens;
    }


    public void delFileToke(UploadToken uploadToken) {
        synchronized (FileUploadWrapper.class) {
            SQLiteDatabase sqLiteDatabase = GlobalManager.getInstance().config().db.getWritableDatabase();

            try {
                ContentValues values = new ContentValues();
                sqLiteDatabase.beginTransaction();
                sqLiteDatabase.delete(TABLE_NAME, Field.KEY_ID + " = ?", new String[]{String.valueOf(uploadToken._id)});
                sqLiteDatabase.setTransactionSuccessful();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (sqLiteDatabase != null) {
                    sqLiteDatabase.endTransaction();
                }
            }
        }
    }


    public int totalCount(String sn, int errorCode) {
        int count = 0;
        SQLiteDatabase db = GlobalManager.getInstance().config().db.getReadableDatabase();
        Cursor cursor = null;
        Gson gson = new Gson();
        try {
            cursor = db.query(TABLE_NAME, null, "sn = ? and " + Field.KEY_ERROR_CODE + " = ?", new String[]{sn, String.valueOf(errorCode)}, null, null, null);
            count = cursor.getColumnCount();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return count;
    }


    public Long queryQidCount(String sn, String title) {
        long count = 0;
        SQLiteDatabase db = GlobalManager.getInstance().config().db.getReadableDatabase();
        StringBuffer sb = new StringBuffer("");
        sb.append("select count(_id) from ");
        sb.append(TABLE_NAME);
        sb.append(" where " + Field.KEY_SN + "='" + sn + "' and " + Field.KEY_TITLE_MD5 + " ='" + title + "'");
        try {
            SQLiteStatement statement = db.compileStatement(sb.toString());
            count = statement.simpleQueryForLong();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }
        return count;
    }

    public UploadToken getUploadToken(String title, String sn) {
        SQLiteDatabase db = GlobalManager.getInstance().config().db.getReadableDatabase();
        UploadToken uploadToken = null;
        Cursor cursor = null;
        Gson gson = new Gson();
        try {
            cursor = db.query(TABLE_NAME, null, "sn = ? and " + Field.KEY_TITLE_MD5 + " = ?", new String[]{sn, MD5Util.getMD5code(title)}, null, null, null);
            while (cursor.moveToNext()) {
                String arg_1 = cursor.getString(cursor.getColumnIndex(Field.KEY_V_1));
                uploadToken = gson.fromJson(arg_1, UploadToken.class);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return uploadToken;
    }


    public class Field {
        public static final String KEY_ID = "_id";
        public static final String KEY_FLASH = "flash";
        public static final String KEY_SN = "sn";
        public static final String KEY_ERROR_CODE = "error_code";
        public static final String KEY_TITLE_MD5 = "title_md5";
        public static final String KEY_V_1 = "v_1";
        public static final String KEY_V_2 = "v_2";
        public static final String KEY_V_3 = "v_3";
        public static final String KEY_V_4 = "v_4";
        public static final String KEY_V_5 = "v_5";
        public static final String KEY_V_6 = "v_6";
    }

}
