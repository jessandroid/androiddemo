
package com.qihoo360.homecamera.mobile.adapter;

import android.app.Activity;
import android.content.Context;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.GenericRequestBuilder;
import com.bumptech.glide.Glide;
import com.bumptech.glide.ListPreloader;
import com.bumptech.glide.Priority;
import com.bumptech.glide.RequestManager;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.entity.Story;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.DensityUtil;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class StoryListAllAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> implements ListPreloader.PreloadModelProvider<Story> {

    private final Context context;
    private final int screenWidth;
    private final int pading;
    private List<Story> list = new ArrayList<>();
    private OnItemOption onItemOption;
    private int itemCount = 0;
    public List<Story> checkedList = new ArrayList<>();
    private boolean onBind;

    private static final int TYPE_HEADER = 0;
    private static final int TYPE_ITEM = 1;
    private static final int TYPE_FOOTER = 2;
    private int totalCount = 0;
    private boolean showMore = false;
    public RequestManager requestManager;

    public StoryListAllAdapter(List<Story> list, OnItemOption onItemOption, int itemCount, Context context) {
        this.list = list;
        this.onItemOption = onItemOption;
        this.itemCount = itemCount;
        this.context = context;
        DisplayMetrics dm = new DisplayMetrics();
        ((Activity) context).getWindowManager().getDefaultDisplay().getMetrics(dm);
        screenWidth = dm.widthPixels;
        pading = DensityUtil.dip2px(9);
        requestManager = Glide.with(Utils.context);
    }

    public boolean getCheckModel() {
        return onItemOption.isCheckModel();
    }

    public List<Story> getCheckedStoryList() {
        return checkedList;
    }

    public void dataChanage(List data) {
        this.list = data;
        notifyDataSetChanged();
    }

    @Override
    public int getItemViewType(int position) {
        if (position != list.size()) {
            return TYPE_ITEM;
        } else {
            return TYPE_FOOTER;
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        if (viewType == TYPE_ITEM) {
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_item_for_show, parent, false);
            return new ViewHolderItem(view, list);
        } else {
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.no_more_layout, parent, false);
            return new ViewHolderItemFooter(view);
        }
    }

    public void showNoMore(boolean flag) {
        showMore = flag;
        notifyItemChanged(list.size() + 1);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        if (holder instanceof ViewHolderItem) {
            if (list.size() > 0) {
                int temp = position;
                CLog.d(temp);
                ViewHolderItem viewHolder = (ViewHolderItem) holder;
                if (getCheckModel()) {
                    viewHolder.ch.setVisibility(View.VISIBLE);
                } else {
                    viewHolder.ch.setVisibility(View.GONE);
                    checkedList.clear();
                }
                final int finalTemp = temp;
                viewHolder.card_item.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        onItemOption.clickStory(finalTemp, list.get(finalTemp));
                    }
                });
                onBind = true;

                viewHolder.ch.setChecked(list.get(temp).checked);

                onBind = false;
                viewHolder.story_time_long.setText(list.get(temp).duration);
                viewHolder.info_text.setText(list.get(temp).name);
                viewHolder.story_time_.setText(list.get(temp).duration);
                if (itemCount != 3) {
                    viewHolder.creat_time.setText(TextUtils.isEmpty(list.get(temp).des) ? "小编很懒" : list.get(temp).des);
                } else {
                    viewHolder.creat_time.setText(list.get(temp).getCreate_time());
                }
                int height16vs9 = DensityUtil.getHeight16vs9((Activity) context, screenWidth - pading * 2);
                viewHolder.image_head.setLayoutParams(new RelativeLayout.LayoutParams(screenWidth, height16vs9));
                Glide.with(context).load(TextUtils.isEmpty(list.get(temp).listCover_url) ? list.get(temp).cover : list.get(temp).listCover_url)
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .priority(Priority.LOW)
                        .dontAnimate()
                        .thumbnail(0.1f)
                        .override(screenWidth, height16vs9)
                        .placeholder(R.drawable.moren_icon_story_on_line)
                        .into(viewHolder.image_head);
                int V = list.get(temp).isRecord ? View.VISIBLE : View.GONE;
                viewHolder.has_record.setVisibility(V);

            }
        } else {
            ViewHolderItemFooter viewHolder = (ViewHolderItemFooter) holder;
            int v = list.size() > 5 && showMore ? View.VISIBLE : View.GONE;
            viewHolder.mView.setVisibility(v);
        }
    }

    @Override
    public int getItemCount() {
        int count = list.size() + 1;
        return count;
    }

    public boolean isHeader(int position) {
        if (position == 0 && itemCount == 3)
            return true;
        else
            return false;
    }

    public void setTotalCount(int total) {
        totalCount = total;
        if (itemCount == 3) {
            notifyItemChanged(0);
        }
    }

    @Override
    public List<Story> getPreloadItems(int position) {
        return Collections.singletonList(list.get(position));
    }

    @Override
    public GenericRequestBuilder getPreloadRequestBuilder(Story item) {
        return requestManager.load(TextUtils.isEmpty(item.listCover_url) ? item.cover : item.listCover_url);
    }

    public class ViewHolderItem extends RecyclerView.ViewHolder implements CompoundButton.OnCheckedChangeListener {
        public View mView;
        public TextView info_text;
        public ImageView image_head;
        public CardView card_item;
        public TextView story_time_long;
        public CheckBox ch;
        public List<Story> list;
        public TextView creat_time;
        public TextView story_time_;
        public ImageView has_record;

        public ViewHolderItem(View view, List<Story> list) {
            super(view);
            mView = view;
            this.list = list;
            info_text = (TextView) view.findViewById(R.id.info_text);
            card_item = (CardView) view.findViewById(R.id.card_item);
            story_time_long = (TextView) view.findViewById(R.id.story_time_long);
            image_head = (ImageView) view.findViewById(R.id.image_head);
            ch = (CheckBox) view.findViewById(R.id.checkbox);
            creat_time = (TextView) view.findViewById(R.id.creat_time);
            story_time_ = (TextView) view.findViewById(R.id.story_time_);
            has_record = (ImageView) view.findViewById(R.id.has_record);
            has_record.setVisibility(View.GONE);
            int height16vs9 = DensityUtil.getHeight16vs9((Activity) context, screenWidth - pading * 2);
            CLog.d("height:" + height16vs9 + "width:" + screenWidth);
            image_head.setLayoutParams(new RelativeLayout.LayoutParams(screenWidth - pading * 2, height16vs9));
        }

        @Override
        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
            if (onBind) {
                notifyDataSetChanged();
            }
        }
    }

    public class ViewHolderItemFooter extends RecyclerView.ViewHolder {
        public View mView;

        public ViewHolderItemFooter(View view) {
            super(view);
            mView = view;

        }
    }


    private boolean isPositionFooter(int position) {
        return position == list.size() + 1;
    }


    public interface OnItemOption {

        public void clickStory(int po, Story st);

        public boolean isCheckModel();

        public List<Story> checkedStory();
    }

}
