package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

/**
 * Created by zhaojunbo on 2016/3/21.
 * desc:
 */
public class SearchWordEntity extends Head {

    public Data data;

    public static class Data implements Parcelable{

        public ArrayList<String> data;

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeStringList(this.data);
        }

        public Data() {
        }

        protected Data(Parcel in) {
            this.data = in.createStringArrayList();
        }

        public static final Creator<Data> CREATOR = new Creator<Data>() {
            public Data createFromParcel(Parcel source) {
                return new Data(source);
            }

            public Data[] newArray(int size) {
                return new Data[size];
            }
        };
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeParcelable(this.data, 0);
    }

    public SearchWordEntity() {
    }

    protected SearchWordEntity(Parcel in) {
        super(in);
        this.data = in.readParcelable(Data.class.getClassLoader());
    }

    public static final Creator<SearchWordEntity> CREATOR = new Creator<SearchWordEntity>() {
        public SearchWordEntity createFromParcel(Parcel source) {
            return new SearchWordEntity(source);
        }

        public SearchWordEntity[] newArray(int size) {
            return new SearchWordEntity[size];
        }
    };
}
