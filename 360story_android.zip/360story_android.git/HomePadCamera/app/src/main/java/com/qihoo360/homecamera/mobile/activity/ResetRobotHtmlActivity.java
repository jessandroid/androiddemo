package com.qihoo360.homecamera.mobile.activity;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.TextView;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;

/**
 * Created by hyuan on 2016/9/6.
 */
public class ResetRobotHtmlActivity  extends BaseActivity implements View.OnClickListener, ActionListener {

    private static final String url = "http://kibot.360.cn/mobile/app/restore.html";

    private TextView mTitleTxtView;
    private ImageView mBackBtnView;
    private WebView mWebView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reset_robot_html);
        mTitleTxtView = (TextView) findViewById(R.id.title_string);
        mTitleTxtView.setText("机器人恢复出厂设置");
        mBackBtnView = (ImageView) findViewById(R.id.back_zone);
        mBackBtnView.setOnClickListener(this);
        mWebView = (WebView) findViewById(R.id.webView);
        mWebView.loadUrl(url);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.back_zone: {
                finish();
                break;
            }
        }
    }

    @Override
    public Object actionPerformed(int actionCode, Object... args) {
        return true;
    }

    @Override
    public int getProperty() {
        return 0;
    }
}
