package com.qihoo360.homecamera.mobile.download;

/**
 * Created by Tomcat on 2015/7/14.
 */
public class Constants {

    public static final class HTTP {
        public static final int CONNECT_TIME_OUT = 10 * 1000;
        public static final int READ_TIME_OUT = 10*1000;
        public static final String GET = "GET";
    }
}
