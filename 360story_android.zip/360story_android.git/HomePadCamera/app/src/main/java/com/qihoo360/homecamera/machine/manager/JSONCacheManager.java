package com.qihoo360.homecamera.machine.manager;

import android.os.AsyncTask;

import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;

// cache json string as a file
public class JSONCacheManager {

    private final static class JSONCacheManagerHolder {
        public static JSONCacheManager instance = new JSONCacheManager();
    }

    public static JSONCacheManager getInstance() {
        return JSONCacheManagerHolder.instance;
    }

    private String cachePath;

    private JSONCacheManager() {
        // empty
    }

    public void init() {
        File cacheDirFile = new File(Utils.mergePathWithTailName(Utils.getContext().getFilesDir().getAbsolutePath(), "cache/"));
        if (!cacheDirFile.exists()) {
            cacheDirFile.mkdirs();
        }
        cachePath = cacheDirFile.getAbsolutePath();
    }

    public void saveCache(String fileName, String content) {
        new CacheWriter(Utils.mergePathWithTailName(cachePath, fileName), content).executeOnExecutor(AsyncTask.SERIAL_EXECUTOR);
    }

    public String readCache(String fileName) {
        File jsonFile = new File(Utils.mergePathWithTailName(cachePath, fileName));
        if (jsonFile != null && jsonFile.exists()) {
            String json = null;
            InputStream is = null;
            try {
                is = new FileInputStream(jsonFile);
                int size = is.available();
                byte[] buffer = new byte[size];
                is.read(buffer);
                json = new String(buffer, "UTF-8");
                CLog.d("get cache Json string:" + json);
            } catch (Exception ex) {
                ex.printStackTrace();
            } finally {
                Utils.closeCloseable(is);
            }
            return json;
        }
        return null;
    }

    private static class CacheWriter extends AsyncTask<Void, Void, Void> {

        String path;
        String content;

        CacheWriter(String path, String content) {
            this.path = path;
            this.content = content;
        }

        @Override
        protected Void doInBackground(Void... params) {
            saveFile();
            return null;
        }

        public boolean saveFile() {
            boolean ret = false;
            BufferedWriter writer = null;
            try {
                writer = new BufferedWriter(new FileWriter(path));
                writer.write(content);
                ret = true;
                CLog.d("saveFile ok, content:" + content + ", path:" + path);
            } catch (Exception e) {
                ret = false;
                CLog.d("JSONCacheManager", "saveFile fail", e);
            } finally {
                Utils.closeCloseable(writer);
            }
            CLog.d("saveFile end");
            return ret;
        }
    }
}
