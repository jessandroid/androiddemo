
package com.qihoo360.homecamera.machine.fragment;

import android.os.Bundle;
import android.view.View;

import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.ui.fragment.HomePhotoShowAllDayDetailFragment;


public class MachineCaptureVideoFragment extends HomePhotoShowAllDayDetailFragment implements ActionListener, View.OnClickListener {

    public static MachineCaptureVideoFragment newInstance() {
        Bundle args = new Bundle();
        MachineCaptureVideoFragment fragment = new MachineCaptureVideoFragment();
        fragment.setArguments(args);
        return fragment;
    }


    //warning 这里不允许删除
    public MachineCaptureVideoFragment() {

    }


}
