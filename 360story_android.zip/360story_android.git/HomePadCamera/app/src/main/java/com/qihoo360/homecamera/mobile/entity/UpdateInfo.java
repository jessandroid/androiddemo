package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.Gson;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/5/3
 * Time: 10:27
 * To change this template use File | Settings | File Templates.
 */
public class UpdateInfo implements Parcelable {
    public int _id;
    public String title;
    public String version;
    public int versionCode;
    public String size; // 字节
    public String md5;          //加密字符串
    public String downUrl;
    public String fastSize;
    public String fastMd5;
    public String fastDownUrl; // 快升文件
    public String description; // 版本描述
    public String recommand;   // 推荐程度
    public int hasNew;         //1：有新版本（可升级) 0：已是最新版本
    public int isForce;        //是否强制升级 0：强制升级  1：正常升级  2：静默升级  3：弹窗升级
    public String extend;
    public String publishTime;

    // 下列是原来版本
    public String localpath;  //下载完的APK 保存在本地的路径
    public int isIgnored;     //是否忽略该版本的升级 0--不忽略  1--忽略


    protected UpdateInfo(Parcel in) {
        _id = in.readInt();
        title = in.readString();
        version = in.readString();
        versionCode = in.readInt();
        size = in.readString();
        md5 = in.readString();
        downUrl = in.readString();
        fastSize = in.readString();
        fastMd5 = in.readString();
        fastDownUrl = in.readString();
        description = in.readString();
        recommand = in.readString();
        hasNew = in.readInt();
        isForce = in.readInt();
        extend = in.readString();
        publishTime = in.readString();
        localpath = in.readString();
        isIgnored = in.readInt();
    }

    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDownUrl() {
        return downUrl;
    }

    public void setDownUrl(String downUrl) {
        this.downUrl = downUrl;
    }

    public int getIsForce() {
        return isForce;
    }

    public void setIsForce(int isForce) {
        this.isForce = isForce;
    }

    public int getHasNew() {
        return hasNew;
    }

    public void setHasNew(int hasNew) {
        this.hasNew = hasNew;
    }

    /**
     * 是否有最新版本
     *
     * @return
     */
    public boolean hasNewVersion() {
        return hasNew == 1;
    }
    public String getLocalpath() {
        return localpath;
    }

    public void setLocalpath(String localpath) {
        this.localpath = localpath;
    }

    public String getMd5() {
        return md5;
    }

    public void setMd5(String md5) {
        this.md5 = md5;
    }

    public String getRecommand() {
        return recommand;
    }

    public void setRecommand(String recommand) {
        this.recommand = recommand;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public int getVersionCode() {
        return versionCode;
    }

    public void setVersionCode(int versionCode) {
        this.versionCode = versionCode;
    }

    public void setIsIgnored(int isIgnored) {
        this.isIgnored = isIgnored;
    }

    public int getIsIgnored() {
        return isIgnored;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getFastSize() {
        return fastSize;
    }

    public void setFastSize(String fastSize) {
        this.fastSize = fastSize;
    }

    public String getFastMd5() {
        return fastMd5;
    }

    public void setFastMd5(String fastMd5) {
        this.fastMd5 = fastMd5;
    }

    public String getFastDownUrl() {
        return fastDownUrl;
    }

    public void setFastDownUrl(String fastDownUrl) {
        this.fastDownUrl = fastDownUrl;
    }

    public String getExtend() {
        return extend;
    }

    public void setExtend(String extend) {
        this.extend = extend;
    }

    public String getPublishTime() {
        return publishTime;
    }

    public void setPublishTime(String publishTime) {
        this.publishTime = publishTime;
    }

    public String tojson() {
        Gson gson = new Gson();
        return gson.toJson(this);
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(_id);
        dest.writeString(title);
        dest.writeString(version);
        dest.writeInt(versionCode);
        dest.writeString(size);
        dest.writeString(md5);
        dest.writeString(downUrl);
        dest.writeString(fastSize);
        dest.writeString(fastMd5);
        dest.writeString(fastDownUrl);
        dest.writeString(description);
        dest.writeString(recommand);
        dest.writeInt(hasNew);
        dest.writeInt(isForce);
        dest.writeString(extend);
        dest.writeString(publishTime);
        dest.writeString(localpath);
        dest.writeInt(isIgnored);
    }


    public static final Creator<UpdateInfo> CREATOR = new Creator<UpdateInfo>() {
        @Override
        public UpdateInfo createFromParcel(Parcel in) {
            return new UpdateInfo(in);
        }

        @Override
        public UpdateInfo[] newArray(int size) {
            return new UpdateInfo[size];
        }
    };


}
