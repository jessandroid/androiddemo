package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by zhaojunbo on 2016/2/15.
 * desc:
 */
public class ShareWayInfo implements Parcelable {
    public int imageResourceId;
    public String wayName;

    public ShareWayInfo(int imageResourceId, String wayName) {
        this.imageResourceId = imageResourceId;
        this.wayName = wayName;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.imageResourceId);
        dest.writeString(this.wayName);
    }

    protected ShareWayInfo(Parcel in) {
        this.imageResourceId = in.readInt();
        this.wayName = in.readString();
    }

    public static final Parcelable.Creator<ShareWayInfo> CREATOR = new Parcelable.Creator<ShareWayInfo>() {
        @Override
        public ShareWayInfo createFromParcel(Parcel source) {
            return new ShareWayInfo(source);
        }

        @Override
        public ShareWayInfo[] newArray(int size) {
            return new ShareWayInfo[size];
        }
    };
}
