package com.qihoo360.homecamera.mobile.entity;

/**
 * 领域对象基础接口
 */
public interface CameraType {
}
