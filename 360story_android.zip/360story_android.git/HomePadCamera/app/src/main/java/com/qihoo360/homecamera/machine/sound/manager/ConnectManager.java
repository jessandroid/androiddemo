package com.qihoo360.homecamera.machine.sound.manager;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

/**
 * @author chengxiangyu
 * 网络连接管理类
 */
public class ConnectManager {
	
	private boolean isConnect = true;//是不是能联网
	private boolean isRegister = false;
	private Context mContext = null;
	private ConnectionChangeReceiver myReceiver;
	private static ConnectManager mConnectManager = null;
	
	public static ConnectManager getInstance(Context context) {
		if(mConnectManager == null){
			mConnectManager = new ConnectManager(context.getApplicationContext());
		}
		return mConnectManager;
	}
	
	public ConnectManager(Context context) {
		mContext = context;
		init(context);
	}
	
	private class ConnectionChangeReceiver extends BroadcastReceiver {
	    @Override
	    public void onReceive(Context context, Intent intent) {
	    	if(intent == null||intent.getAction() == null){
	    		return;
	    	}
	    	init(context);
	    }
	}
	
	private void init(Context context) {
		try {
			ConnectivityManager connectivityManager=(ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
	        NetworkInfo  mobNetInfo=connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
	        NetworkInfo  wifiNetInfo=connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
	        
	        if (!mobNetInfo.isConnected() && !wifiNetInfo.isConnected()) {
	        	isConnect = false;
	        }else {
	        	isConnect = true;
	        }
		} catch (Exception e) {
			isConnect = true;//如果出现异常，为了功能的正常使用，暂时定为true
		}
		
	}
	
	public boolean getConnect() {
		if(!isRegister){
			init(mContext);
		}
		return isConnect;
	}
	
	public  void registerReceiver(){
		if(isRegister)
			return;
		try {
			IntentFilter filter=new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
	        myReceiver=new ConnectionChangeReceiver();
	        mContext.registerReceiver(myReceiver, filter);
	        isRegister = true;
		} catch (Exception e) {
		}
    }
	
	public  void unregisterReceiver(){
		if(!isRegister)
			return;
		try {
			mContext.unregisterReceiver(myReceiver);
			isRegister = false;
		} catch (Exception e) {
		}
		
    }
}
