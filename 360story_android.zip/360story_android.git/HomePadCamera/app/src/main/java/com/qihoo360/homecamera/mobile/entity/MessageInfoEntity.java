package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

/**
 * Created by zhaojunbo on 2016/1/29.
 * desc:
 */
public class MessageInfoEntity implements Parcelable {

    public String type;
    public String time;
    public String title;
    public String message;
    public String device;
    public Data data;

    public static class Data implements Parcelable {
        public IpcInfo ipcInfo;
        public ReqUserInfo reqUserInfo;
        public String sn;
        public String title;
        public String phone;
        public String ownerPhone;
        public String operatorRole;
        public AppInfo appInfo;
        public IpcInfo rqstIpcInfo;
        public IpcInfo rspsIpcInfo;
        public String relation;
        public SenderInfo senderInfo;
        public String cmd;
        public CommandReceipt content;
        public String isOnline;

        public Data() {
        }

        public String getRelationTitle() {
            try {
                if (relation != null) {
                    Gson gson = new Gson();
                    RelationInfoEntity relationInfoEntity = gson.fromJson(relation, RelationInfoEntity.class);
                    return relationInfoEntity.relation_title;
                }
            } catch (JsonSyntaxException e) {
                e.printStackTrace();
            }
            return "";
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeParcelable(this.ipcInfo, flags);
            dest.writeParcelable(this.reqUserInfo, flags);
            dest.writeString(this.sn);
            dest.writeString(this.title);
            dest.writeString(this.phone);
            dest.writeString(this.ownerPhone);
            dest.writeString(this.operatorRole);
            dest.writeParcelable(this.appInfo, flags);
            dest.writeParcelable(this.rqstIpcInfo, flags);
            dest.writeParcelable(this.rspsIpcInfo, flags);
            dest.writeString(this.relation);
            dest.writeParcelable(this.senderInfo, flags);
            dest.writeString(this.cmd);
            dest.writeParcelable(this.content, flags);
            dest.writeString(this.isOnline);
        }

        protected Data(Parcel in) {
            this.ipcInfo = in.readParcelable(IpcInfo.class.getClassLoader());
            this.reqUserInfo = in.readParcelable(ReqUserInfo.class.getClassLoader());
            this.sn = in.readString();
            this.title = in.readString();
            this.phone = in.readString();
            this.ownerPhone = in.readString();
            this.operatorRole = in.readString();
            this.appInfo = in.readParcelable(AppInfo.class.getClassLoader());
            this.rqstIpcInfo = in.readParcelable(IpcInfo.class.getClassLoader());
            this.rspsIpcInfo = in.readParcelable(IpcInfo.class.getClassLoader());
            this.relation = in.readString();
            this.senderInfo = in.readParcelable(SenderInfo.class.getClassLoader());
            this.cmd = in.readString();
            this.content = in.readParcelable(CommandReceipt.class.getClassLoader());
            this.isOnline = in.readString();
        }

        public static final Creator<Data> CREATOR = new Creator<Data>() {
            @Override
            public Data createFromParcel(Parcel source) {
                return new Data(source);
            }

            @Override
            public Data[] newArray(int size) {
                return new Data[size];
            }
        };
    }

    public MessageInfoEntity() {
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.type);
        dest.writeString(this.time);
        dest.writeString(this.title);
        dest.writeString(this.message);
        dest.writeString(this.device);
        dest.writeParcelable(this.data, flags);
    }

    protected MessageInfoEntity(Parcel in) {
        this.type = in.readString();
        this.time = in.readString();
        this.title = in.readString();
        this.message = in.readString();
        this.device = in.readString();
        this.data = in.readParcelable(Data.class.getClassLoader());
    }

    public static final Creator<MessageInfoEntity> CREATOR = new Creator<MessageInfoEntity>() {
        @Override
        public MessageInfoEntity createFromParcel(Parcel source) {
            return new MessageInfoEntity(source);
        }

        @Override
        public MessageInfoEntity[] newArray(int size) {
            return new MessageInfoEntity[size];
        }
    };
}
