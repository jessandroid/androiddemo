package com.qihoo360.homecamera.mobile.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qihoo360.accounts.api.CoreConstant;
import com.qihoo360.accounts.api.auth.QucRpc;
import com.qihoo360.accounts.api.auth.i.IQucRpcListener;
import com.qihoo360.accounts.api.auth.p.ClientAuthKey;
import com.qihoo360.accounts.api.auth.p.model.RpcResponseInfo;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.adapter.ContryCodeAdapter;
import com.qihoo360.homecamera.mobile.config.DefaultClientConfig;
import com.qihoo360.homecamera.mobile.entity.CountryCode;
import com.qihoo360.homecamera.mobile.entity.InnerMsg;
import com.qihoo360.homecamera.mobile.ui.fragment.LoginFragment;
import com.qihoo360.homecamera.mobile.widget.sortlistview.CharacterParser;
import com.qihoo360.homecamera.mobile.widget.sortlistview.PinyinComparator;
import com.qihoo360.homecamera.mobile.widget.sortlistview.SideBar;

import net.sourceforge.pinyin4j.PinyinHelper;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2015/11/20
 * Time: 11:06
 * To change this template use File | Settings | File Templates.
 */
public class CountryCodeListActivity extends BaseActivity implements IQucRpcListener, ContryCodeAdapter.OnItemClick {

    private CountryCode countryCode = new CountryCode();

    private boolean mSendSmsPending;
    private static String method = "CommonAccount.findAccountPwd";
    private ClientAuthKey mAuthKey;
    private ContryCodeAdapter contryCodeAdapter;
    private ListView listViews;
    private List<CountryCode> countryCodes;
    private CharacterParser characterParser;
    private PinyinComparator pinyinComparator;
    private TextView tvNofriends;
    private int lastFirstVisibleItem = -1;
    private LinearLayout titleLayout;
    private TextView title;
    private SideBar sideBar;
    private TextView dialog;
    private LinearLayout loading;
    private ProgressBar progressBar;
    private TextView message;
    private RelativeLayout layout;

    @Override
    protected void onCreate(Bundle arg0) {
        super.onCreate(arg0);
        setTintManagerQWork(false);
        setContentView(R.layout.contry_code_layout);
        countryCodes = new ArrayList<CountryCode>();
        characterParser = CharacterParser.getInstance();
        pinyinComparator = new PinyinComparator();
        titleLayout = (LinearLayout) findViewById(R.id.title_layout);
        listViews = (ListView) findViewById(R.id.contry_code_list);
        loading = (LinearLayout) findViewById(R.id.loading_data);
        progressBar = (ProgressBar) findViewById(R.id.prg);
        message = (TextView) findViewById(R.id.message);
        loading.setVisibility(View.VISIBLE);
        layout = (RelativeLayout) findViewById(R.id.click_for_country_code);


        contryCodeAdapter = new ContryCodeAdapter(this, countryCodes);
        listViews.setAdapter(contryCodeAdapter);
        mAuthKey = new ClientAuthKey(DefaultClientConfig.FROM, DefaultClientConfig.SIGN_KEY, DefaultClientConfig.CRYPT_KEY);
        loadData();
        tvNofriends = (TextView) findViewById(R.id.title_layout_no_friends);
        title = (TextView) this.findViewById(R.id.title_layout_catalog);
        sideBar = (SideBar) findViewById(R.id.sidrbar);
        dialog = (TextView) findViewById(R.id.dialog);
        sideBar.setTextView(dialog);
        message.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadData();
            }
        });

        findViewById(R.id.back_zone).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        findViewById(R.id.search_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // FIXME: 2015/11/23 输入框弹出
            }
        });
        sideBar.setOnTouchUpListener(new SideBar.OnTouchUpListener() {
            @Override
            public void onTouchUpListener(TextView textView) {
                textView.setVisibility(View.INVISIBLE);
            }
        });
        listViews.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                dialog.setVisibility(View.INVISIBLE);
                return false;
            }
        });

        sideBar.setOnTouchingLetterChangedListener(new SideBar.OnTouchingLetterChangedListener() {

            @Override
            public void onTouchingLetterChanged(String s) {
                int position = contryCodeAdapter.getPositionForSection(s.charAt(0));
                if (position != -1) {
                    listViews.setSelection(position);
                }
            }
        });

    }


    public int getSectionForPosition(int position) {
        if (position < countryCodes.size()) {
            return countryCodes.get(position).getSortLetters().charAt(0);
        } else {
            return 0;
        }
    }


    public void loadData() {
        QucRpc getStateList = new QucRpc(this, mAuthKey, getMainLooper(), this);
        ArrayList<NameValuePair> params = new ArrayList<NameValuePair>();
        params.add(new BasicNameValuePair("language", getString(com.qihoo360.accounts.R.string.language)));
        getStateList.request("CommonAccount.getStateList", params, null, null,
                CoreConstant.ResponseDataType.RESPONSE_STRING, "data");

    }

    public int getPositionForSection(int section) {
        for (int i = 0; i < countryCodes.size(); i++) {
            String sortStr = countryCodes.get(i).getSortLetters();
            char firstChar = sortStr.toUpperCase().charAt(0);
            if (firstChar == section) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public void finish() {
        Intent intent = getIntent();
        intent.putExtra("contry_code", countryCode);
        setResult(LoginFragment.CONTRY_RESULT, intent);
        super.finish();
    }

    @Override
    public void onRpcSuccess(RpcResponseInfo rpcResponseInfo) {
        loading.setVisibility(View.GONE);
        String string = rpcResponseInfo.getString();
        JSONArray jsonArray = null;
        try {
            jsonArray = new JSONArray(string);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                countryCodes.add(new CountryCode(jsonObject.getString("state"), jsonObject.getString("zone"), jsonObject.getString("pattern")));
            }
            filledData(countryCodes);
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void onRpcError(int i, int i1, String s, RpcResponseInfo rpcResponseInfo) {
        message.setText(s);
        progressBar.setVisibility(View.GONE);

    }

    // 判断字符串是否包含有中文
    public static boolean isChinese(String str) {
        String regex = "[\\u4e00-\\u9fa5]";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(str);
        return matcher.find();
    }

    private String pinyin(char c) {
        String[] pinyins = PinyinHelper.toHanyuPinyinStringArray(c);
        if (pinyins == null) {
            return null;
        }
        return pinyins[0];
    }

    private List<CountryCode> filledData(List<CountryCode> countryCodes) {
        List<CountryCode> mSortList = new ArrayList<CountryCode>();

        try {
            for (int i = 0; i < countryCodes.size(); i++) {
                CountryCode sortModel = new CountryCode();
                sortModel.setCountryName(countryCodes.get(i).getCountryName());
                sortModel.setCountryCode(countryCodes.get(i).getCountryCode());
                // 汉字转换成拼音
//            String pinyin = characterParser.getSelling(countryCodes.get(i).getCountryName());

                String target = countryCodes.get(i).getCountryName();
                String pinyin = "";
                if (isChinese(target)) {
                    pinyin = pinyin(target.charAt(0));
                } else {
                    pinyin = characterParser.getSelling(target);
                }

                String sortString = pinyin.substring(0, 1).toUpperCase();

                if (sortString.matches("[A-Z]")) {
                    sortModel.setSortLetters(sortString.toUpperCase());
                } else {
                    sortModel.setSortLetters("#");
                }
                mSortList.add(sortModel);
            }
            Collections.sort(mSortList, pinyinComparator);
            contryCodeAdapter.updateListView(mSortList);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return mSortList;

    }


    private void filledData(String filterStr) {
        List<CountryCode> filterDateList = new ArrayList<CountryCode>();

        if (TextUtils.isEmpty(filterStr)) {
            filterDateList = countryCodes;
            tvNofriends.setVisibility(View.GONE);
        } else {
            filterDateList.clear();
            for (CountryCode sortModel : countryCodes) {
                String name = sortModel.getCountryName();
                if (name.indexOf(filterStr.toString()) != -1
                        || characterParser.getSelling(name).startsWith(
                        filterStr.toString())) {
                    filterDateList.add(sortModel);
                }
            }
        }

        // 根据a-z进行排序
        Collections.sort(filterDateList, pinyinComparator);
        contryCodeAdapter.updateListView(filterDateList);
        if (filterDateList.size() == 0) {
            tvNofriends.setVisibility(View.VISIBLE);
        }
    }


    @Override
    public void onItemClick(CountryCode countryCode) {
        this.countryCode = countryCode;
        finish();
    }

    @Override
    protected void switchMode(boolean speaker_mode) {
        super.switchMode(speaker_mode);
    }

    @Override
    public void onMessage(InnerMsg imsg) {
        super.onMessage(imsg);
    }

    @Override
    public void setTintManagerQWork(boolean work) {
        super.setTintManagerQWork(work);
    }
}
