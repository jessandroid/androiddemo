package com.qihoo360.homecamera.device.config;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhangchao-pd on 2016/11/29.
 */

public class DeviceConsts {
    public static final String DEVICE_TYPE_DEFAULT = "9999";
    public static final String DEVICE_TYPE_ROBOT = "1";
    public static final String DEVICE_TYPE_STORYMACHINE = "2";
    public static final String DEVICE_TYPE_STORYMACHINE_603 = "2";
    public static final String DEVICE_TYPE_STORYMACHINE_605 = "3";

    public static class Support {
        private static final List<String> supportDeviceTypeList = new ArrayList<String>() {
            {
                add(DEVICE_TYPE_ROBOT);
                add(DEVICE_TYPE_STORYMACHINE);
                add(DEVICE_TYPE_STORYMACHINE_603);
                add(DEVICE_TYPE_STORYMACHINE_605);
            }
        };

        /**
         * 设备类型是否支持
         * @param deviceType
         * @return
         */
        public static boolean isDeviceTypeSupport(String deviceType) {
            return supportDeviceTypeList.contains(deviceType);
        }
    }
}
