package com.qihoo360.homecamera.mobile.manager;

import android.app.Application;
import android.content.Context;
import android.graphics.Bitmap;
import android.text.TextUtils;
import android.view.View;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;
import com.qihoo360.homecamera.mobile.BuildConfig;
import com.qihoo360.homecamera.mobile.SysConfig;
import com.qihoo360.homecamera.mobile.config.Const;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionPublisherWithThreadPoolBase;
import com.qihoo360.homecamera.mobile.core.manager.workpool.PoolThreadFactory;
import com.qihoo360.homecamera.mobile.db.AppUpdateWrapper;
import com.qihoo360.homecamera.mobile.db.CommonWrapper;
import com.qihoo360.homecamera.mobile.entity.Update;
import com.qihoo360.homecamera.mobile.model.Splash;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.FileUtil;
import com.qihoo360.homecamera.mobile.utils.ImageUtil;
import com.qihoo360.homecamera.mobile.utils.TimeUtilNew;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.tencent.open.utils.Util;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.Executors;

import static android.content.ContentValues.TAG;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/4/18
 * Time: 19:04
 * To change this template use File | Settings | File Templates.
 */
public class CommonManager extends ActionPublisherWithThreadPoolBase {
    /**
     * APP检测版本更新
     */
    public static final String ACTION_CHECK_UPDATE = "CheckUpdate";
    public static final String ACTION_SPLASH = "splash";
    /*
     *故事机固件升级检测
     */
    public static final String ACTION_FM_CHECK_UPDATE = "fm_check_update";

    private final String mPoolNameHighPriority, mPoolNameLowPriority;
    private final Application mApp;

    public CommonManager(Application app) {
        this.mApp = app;
        mPoolNameHighPriority = "CommonManager-high-priority-" + Utils.DATE_FORMAT_3.format(new Date());
        mPoolNameLowPriority = "CommonManager-low-priority-" + Utils.DATE_FORMAT_3.format(new Date());
        mThreadPool.initPool(mPoolNameHighPriority, Executors.newFixedThreadPool(3));
        mThreadPool.initPool(mPoolNameLowPriority, Executors.newCachedThreadPool(new PoolThreadFactory(mPoolNameLowPriority)));
    }

    /**
     * app检测新版本
     *
     * @param type VersionManager中的常量
     */
    public void checkNewVersion(int type) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob(ACTION_CHECK_UPDATE, type));
    }

    /**
     *故事机检测固件升级
     * @param from 升级来源
     * @param version 当前版本
     * @param  versionCode 当前版本号
     */
    public void checkFMNewVersion(int from, String version, int versionCode, String sn){
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob(ACTION_FM_CHECK_UPDATE, from, version, versionCode, sn));
    }

    public void getShareInfo() {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("getshareinfo"));
    }

    public void asyncSplash() {
        mThreadPool.submit(mPoolNameLowPriority, new NamedAsyncJob(ACTION_SPLASH, mApp));
    }

    private void doGetShareInfo() {

    }

    /**
     * 异步操作版本更新(app更新)
     *
     * @param type
     */
    private void doCheckNewVersion(int type) {

        Update updateNew = VersionManager.checkVersion(type);
        if (updateNew != null && updateNew.result != null && updateNew.errorCode == 0) {

            if (!updateNew.result.hasNewVersion()) {//不需要更新
                // 手动检测更新时，已经最新版本，需要清空记录，不显示红点
                if (type == VersionManager.REQUEST_SOURCE_PERSONAL) {
                    AppUpdateWrapper.getInstance().deleteInfo();//清空数据库
                }

                publishAction(Actions.Common.IS_THE_NEWEST, type);//TODO  通知页面已经是最新版本

            } else {//有升级需要更新
                if (updateNew.result.isForce == Update.FORCE_TYPE_FORCE) {//需要强制更新
                    FileUtil.deleteDirectory(FileUtil.getInstance().getDownloadFile());//删除之前的升级apk
                    publishAction(Actions.Common.FORCE_UPDATE, updateNew, type);//TODO  通知闪屏页更新（特殊情况：闪屏没网跳过了  则mainactivity需要捕捉）
                    return;
                }
                //非强制更新
                if (type == VersionManager.REQUEST_SOURCE_SPLASH) {
                    publishAction(Actions.Common.UPDATE, type);
                } else {
                    String filePath = FileUtil.getInstance().getDownloadFile().getAbsolutePath() + "/" + updateNew.result.getTitle();
                    if (AppUpdateWrapper.getInstance().exist(updateNew.result.getVersionCode()) && Util.fileExists(filePath)) {//数据库存在该版本的更新信息，已经下载好了
                        Update sqlUpdate = AppUpdateWrapper.getInstance().readUpDate(updateNew.result.getVersionCode());//读取数据库中的版本信息
                        sqlUpdate.result.setDescription(updateNew.getResult().getDescription());//新的更新信息中的描述可能改修改了
                        sqlUpdate.result.setIsForce(updateNew.getResult().getIsForce());//新的更新信息中的描述可能改修改了
                        publishAction(Actions.Common.UPDATE, sqlUpdate, type);//TODO  通知页面进行更新
                    } else {
                        FileUtil.deleteDirectory(FileUtil.getInstance().getDownloadFile());//删除之前的升级apk
                        AppUpdateWrapper.getInstance().deleteInfo();//清空数据库
                        //如果是wifi状态，需要先下载
                        if (type == VersionManager.REQUEST_SOURCE_MAIN) {
                            if (Utils.isWifi(Utils.getContext())) {
                                publishAction(Actions.Common.DOWNLOAD_NOW, updateNew, type);//TODO  通知MAINACTIVITY页面进行下载
                            } else {//弹窗更新
                                publishAction(Actions.Common.UPDATE, updateNew, type);//TODO  通知MAINACTIVITY页面进行下载
                            }
                        } else if (type == VersionManager.REQUEST_SOURCE_PERSONAL) {
                            publishAction(Actions.Common.UPDATE, updateNew, type);//TODO  通知关于页面进行更新，需要弹窗
                        }
                    }
                }
            }
        } else {
            //只有手动的时候才提示获取更新信息失败
            if (type == VersionManager.REQUEST_SOURCE_PERSONAL) {
                publishAction(Actions.Common.GET_UPDATE_FAILED, type);//TODO  通知页面获取更新信息失败
            }
        }
    }

    private String showResponseResult(HttpResponse response) {
        String result = "";
        if (null == response) {
            return result;
        }

        HttpEntity httpEntity = response.getEntity();
        try {
            InputStream inputStream = httpEntity.getContent();
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    inputStream));
            String line = "";
            while (null != (line = reader.readLine())) {
                result += line;

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }

    private void doAsynLoadSplash(Context context, String url) {
        CommonWrapper commonWrapper = CommonWrapper.getInstance(context);
        Splash splash = commonWrapper.readSplashData();
        try {
            String u = TextUtils.isEmpty(url) ? Const.URL_SPLASH_IMAGE_V2 : url;

            HttpGet httpGet = new HttpGet(u);
            HttpClient httpClient = new DefaultHttpClient();
            if (BuildConfig.isDebug) {
                httpGet.setHeader("Host", "kibot.360.cn");
            }
            HttpResponse response = httpClient.execute(httpGet);
            String splashList = showResponseResult(response);
            if (!TextUtils.isEmpty(splashList)) {
                Gson gson = new Gson();
                Type listType = new TypeToken<ArrayList<Splash>>() {
                }.getType();

                ArrayList<Splash> splashs = gson.fromJson(splashList, listType);
                if (splashs != null && splashs.size() > 0) {
                    for (int i = 0; i < splashs.size(); i++) {
                        Splash ptl = splashs.get(i);
                        CLog.e(TAG, "asynLoadSplash -> Splash[" + ptl + "]");
                        if (ptl != null) {
                            if (TextUtils.isEmpty(ptl.getImageServeLocal())) {
                                commonWrapper.delSplash(ptl);
                                return;
                            }
                            if (ptl.judgeEventIsAvaliable() && !ptl.isEndTimeExpired()) {
                                ptl.setImageServeLocal(String.format(ptl.getImageServeLocal(), SysConfig.screenWidth, SysConfig.screenHeight));
                                CLog.e(TAG, "asynLoadSplash -> ptl.getImageServeLocal() = " + ptl.getImageServeLocal());
                                DownImage(ptl.getImageServeLocal(), ptl);
                            }
                        }
                    }
                }
                if (!TextUtils.isEmpty(splash.getFromDate()) && !TextUtils.isEmpty(splash.getEndDate())) {
                    long fromDate = TimeUtilNew.getMillis(splash.getFromDate());
                    long endDate = TimeUtilNew.getMillis(splash.getEndDate());
                    long current = System.currentTimeMillis();
                    if (current >= fromDate && current <= endDate) {
                        if (splash == null || !TextUtils.equals(splash.getImageServeLocal(), splash.getImageServeLocal())) {
                            DownImage(splash.getImageServeLocal(), splash);
                        } else {
                            File f = new File(splash.getImageServeLocal());
                            if (f.exists() == false) {
                                DownImage(splash.getImageServeLocal(), splash);
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void DownImage(final String url, final Splash splash) {
        int count = 0;
        ImageLoader.getInstance().loadImage(splash.getImageServeLocal(), new ImageLoadingListener() {
            @Override
            public void onLoadingStarted(String s, View view) {

            }

            @Override
            public void onLoadingFailed(String s, View view, FailReason failReason) {

                CLog.e("snapPath: 失败了。。。。");
            }

            @SuppressWarnings("static-access")
            @Override
            public void onLoadingComplete(String s, View view, final Bitmap bitmap) {
                try {
                    final String snapPath = FileUtil.getInstance().getSplashFile().getAbsolutePath()
                            + "/"
                            + splash.getFromDate() + "_" + splash.getEndDate() + splash.getLastImgName();
                    CLog.e("snapPath:" + snapPath);
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                File file = new File(snapPath);
                                if (file.exists()) {
                                    file.delete();
                                    file.createNewFile();
                                } else {
                                    file.createNewFile();
                                }
                                if (ImageUtil.bitmap2File(bitmap, snapPath)) {
                                    splash.setIamgeLocal(snapPath);
                                    //    CommonWrapper.getInstance(mApp).delSplash(splash);
                                    CommonWrapper.getInstance(mApp).writeSplash(url, splash);
                                    CLog.i("test1", "CommonWrapper url = " + url);
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }).start();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onLoadingCancelled(String s, View view) {

            }
        });
    }

    @Override
    protected void asyncDoNamedJob(String jobName, Object... args) {
        CLog.d("-------------->");
        if (TextUtils.equals(ACTION_CHECK_UPDATE, jobName)) {
            doCheckNewVersion((Integer) args[0]);
        } else if (TextUtils.equals("getshareinfo", jobName)) {
            doGetShareInfo();
        } else if (TextUtils.equals(ACTION_SPLASH, jobName)) {
            doAsynLoadSplash(mApp, Const.URL_SPLASH_IMAGE_V2);
        }else if(TextUtils.equals(ACTION_FM_CHECK_UPDATE, jobName)){
            doFMCheckNewVersion((int) args[0], (String)args[1], (int) args[2], (String)args[3]);
        }
    }

    //检测故事机固件升级
    private void doFMCheckNewVersion(int from, String version, int versionCode, String sn){
        Update update = VersionManager.checkFMVersion(version, versionCode, sn);
        publishAction(Actions.Common.GET_FM_UPGRADE_INFO, from, update);
    }

    public void notifyUpdateFmUpState(boolean hasUpdate){
        publishAction(Actions.Common.NOTIFY_FM_UPDATE, hasUpdate);
    }
}

