
package com.qihoo360.homecamera.machine.activity;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.telephony.TelephonyManager;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver.OnPreDrawListener;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;
import android.widget.ViewFlipper;

import com.google.gson.Gson;
import com.qihoo360.homecamera.device.config.StoryMachineConsts;
import com.qihoo360.homecamera.machine.business.TaskExecutor;
import com.qihoo360.homecamera.machine.entity.BindResult;
import com.qihoo360.homecamera.machine.entity.MachineDeviceInfo;
import com.qihoo360.homecamera.machine.entity.Wifi;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.SysConfig;
import com.qihoo360.homecamera.mobile.activity.MainActivity;
import com.qihoo360.homecamera.mobile.activity.SettingDetialActivity;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.net.MachineApi;
import com.qihoo360.homecamera.mobile.db.CommonWrapper;
import com.qihoo360.homecamera.mobile.db.PadInfoWrapper;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.ActivityUtils;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.Preferences;
import com.qihoo360.homecamera.mobile.utils.QHStatAgentHelper;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.widget.CamAlertDialog;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import rx.Observable;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.subscriptions.CompositeSubscription;

public class AddCameraWaitActivity extends MachineBaseActivity{

    public static final int MSG_COUNT_DOWN = 3;
    public static final int MSG_SCAN_PERIOD = 4;
    public static final int LINK_PERIOD = 20000;
    private String setup_type;
    public int Max = 120;
    InputFilter inputFilter = new InputFilter() {

        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest,
                int dstart, int dend) {
            int len = getWordCount(source.toString()) + getWordCount(dest.toString());
            if (len > 16) {
                CameraToast.show(R.string.acc_text_size_limit_toast, Toast.LENGTH_SHORT);
                return "";
            }
            return source;
        }

        public int getWordCount(String s) {

            s = s.replaceAll("[^\\x00-\\xff]", "**");
            int length = s.length();
            return length;
        }
    };
    private boolean isRun = true;
    private Wifi wifi;
    private PollClaimTask mPollClaimTask;
    private int progress = Max;
    private TextView tvcountDown;
    private CamAlertDialog dialog;
    private ViewFlipper vfAddGuide;
    private EditText et_add_name;
    private TextView tv_add_title, tv_add_waiting_title, tv_add_waiting_des;
    private String sn;
    private ArrayList<String> sns;
    private ImageView iv_wait_bg;
    private Bitmap addBgBmp;
    private String taskId;
    private CompositeSubscription mLoadDataSubscription;
    private Subscription mSubscription;

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            AddCameraWaitActivity.this.doMessage(msg);
        }
    };


    private MediaPlayer mMediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        super.onCreate(savedInstanceState);
        wifi = (Wifi) getIntent().getSerializableExtra("Wifi");
        CLog.e("WIFI:S:" + wifi.getSSID() + ";P:" + wifi.getPASSWORD() + ";TS:"
                + wifi.getTIMESTAMP() + ";Q:" + wifi.getQID() + ";;");
        sns = getIntent().getExtras().getStringArrayList("sns");
        setup_type = getIntent().getStringExtra(StoryMachineConsts.KEY_SET_WIFI_FROM);
        if (wifi == null) {
            Toast.makeText(this, R.string.wifi_error, Toast.LENGTH_SHORT).show();
            finish();
        }
        mLoadDataSubscription = new CompositeSubscription();
        initView();
        setView();
        initSound();

        if (Utils.isNetworkAvailable(Utils.getContext())) {
            if (sns != null) {
                //                startSmartConfig();
            } else {
                action();
            }
            handler.sendEmptyMessage(MSG_COUNT_DOWN);
        } else {
            Toast.makeText(this, R.string.network_disabled, Toast.LENGTH_SHORT).show();
        }
    }

    /********** 初始化相关 **********/
    private void initView() {
        setTintManagerQWork(true);
        tintManager.setStatusBarTintColor(Color.parseColor("#0000aeff"));
        setContentView(R.layout.activity_add_waiting);
        iv_wait_bg = (ImageView) findViewById(R.id.iv_wait_bg);
        vfAddGuide = (ViewFlipper) findViewById(R.id.vf_add_guide);
        tv_add_title = (TextView) findViewById(R.id.tv_add_title);
        tv_add_waiting_title = (TextView) findViewById(R.id.tv_add_waiting_title);
        tv_add_waiting_des = (TextView) findViewById(R.id.tv_add_waiting_des);
        tv_add_waiting_des.setSelected(true);
        et_add_name = (EditText) findViewById(R.id.et_add_name);
        tvcountDown = (TextView) findViewById(R.id.tv_count_down);
    }

    @SuppressLint("ResourceAsColor")
    private void setView() {
        iv_wait_bg.setMaxWidth(SysConfig.BASE_SCREEN_WIDTH);
        iv_wait_bg.setMaxHeight(SysConfig.BASE_SCREEN_HEIGHT);
        addBgBmp = Utils.getBitmap(R.drawable.bg_machine_add);
        iv_wait_bg.setImageBitmap(addBgBmp);

        findViewById(R.id.btn_back).setVisibility(View.VISIBLE);
        findViewById(R.id.btn_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        tv_add_title.setText(getString(R.string.add_second_step));
        tvcountDown.setText(String.valueOf(Max));

        ImageView connecting_dot = (ImageView) findViewById(R.id.add_connecting_dot);
        final AnimationDrawable animation = (AnimationDrawable) connecting_dot.getDrawable();
        connecting_dot.getViewTreeObserver().addOnPreDrawListener(new OnPreDrawListener() {
            @Override
            public boolean onPreDraw() {
                animation.start();
                return true;
            }
        });

        et_add_name.setOnEditorActionListener(new OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    onClick(findViewById(R.id.btn_add_complete));
                }
                return false;
            }
        });
        et_add_name.setFilters(new InputFilter[] {
                inputFilter
        });

        et_add_name.setHintTextColor(getResources().getColor(R.color.hint_text_color));
    }

    //    private void startSmartConfig() {
    //        taskId = UUID.randomUUID().toString();
    //        AirLink.initial(this);
    //        startLink();
    //    }

    private void initSound(){
        mMediaPlayer = MediaPlayer.create(this, R.raw.connectwifi);
        if (mMediaPlayer != null) {
            mMediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    if (mMediaPlayer != null) {
                        mSubscription = Observable.timer(100, TimeUnit.MILLISECONDS).observeOn(AndroidSchedulers.mainThread()).subscribe(
                                new Action1<Long>() {
                                    @Override
                                    public void call(Long aLong) {
                                        if(mMediaPlayer!=null){
                                            mMediaPlayer.release();
                                        }
                                        mMediaPlayer = MediaPlayer.create(AddCameraWaitActivity.this, R.raw.needtime);
                                        if(mMediaPlayer!=null){
                                            mMediaPlayer.start();
                                        }
                                    }
                                }
                        );
                        mLoadDataSubscription.add(mSubscription);
                    }
                }
            });
            mMediaPlayer.start();
        }
    }

    private void action() {
        if (mPollClaimTask == null) {
            mPollClaimTask = new PollClaimTask();
            TaskExecutor.Execute(mPollClaimTask);
        }
    }

    /********** 生命周期相关 **********/
    @Override
    public void onBackPressed() {
        if (isRun) {
            showCancelAddDialog();
        }else{
            if(mMediaPlayer!=null && mMediaPlayer.isPlaying()){
                mMediaPlayer.stop();
            }
            this.finish();
        }
    }

    @Override
    protected void onDestroy() {
        if (addBgBmp != null) {
            addBgBmp.recycle();
        }
        mPollClaimTask = null;
        if(mLoadDataSubscription!=null){
            mLoadDataSubscription.clear();
        }
        if(mMediaPlayer!=null){
            mMediaPlayer.release();
        }
        super.onDestroy();
        stopRunning();
    }

    /********** 工具方法 **********/

    private void setKeyboardFocus(final EditText primaryTextField) {
        (new Handler()).postDelayed(new Runnable() {
            public void run() {
                // 模拟点击事件
                MotionEvent motionDown =
                        MotionEvent.obtain(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(),
                                MotionEvent.ACTION_DOWN, 0, 0, 0);
                MotionEvent motionUp =
                        MotionEvent.obtain(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(),
                                MotionEvent.ACTION_UP, 0, 0, 0);

                primaryTextField.dispatchTouchEvent(motionDown);
                primaryTextField.dispatchTouchEvent(motionUp);

                motionDown.recycle();
                motionUp.recycle();

                primaryTextField.setSelection(primaryTextField.length());
            }
        }, 100);
    }

    private BindResult bindClaim() {
        CLog.d("start bindClaim...");
        return MachineApi.Machine.doAppBind(wifi.getTIMESTAMP());
    }

    private void showAddFailureDialog() {
        TextView addFailedTitle;
        TextView bindStoryMachineRepeat;

        if (dialog != null && dialog.isShowing()){
            dialog.dismiss();
        }else{
            final CamAlertDialog.Builder builder = new CamAlertDialog.Builder(this);
            dialog = builder.create();
            View root = LayoutInflater.from(this).inflate(R.layout.dialog_add_camera_failed, null);
            dialog.setContentView(root);

            root.findViewById(R.id.more_solution).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //更多解决方法
                    showMoreSolution(R.layout.more_solution_dialog);
                }
            });
            addFailedTitle = (TextView) root.findViewById(R.id.tv_add_failed_title);
            bindStoryMachineRepeat = (TextView) root.findViewById(R.id.bind_story_machine_repeat);
            if (setup_type.equals(StoryMachineConsts.VALUE_SET_WIFI_FROM_BIND)){
                addFailedTitle.setText(this.getResources().getString(R.string.add_failed_title));
                bindStoryMachineRepeat.setText(this.getResources().getString(R.string.kc_add_camera_repeat));
            }else{
                addFailedTitle.setText(this.getResources().getString(R.string.add_failed_title_connect_wifi));
                bindStoryMachineRepeat.setText(this.getResources().getString(R.string.kc_add_camera_repeat_connect_wifi));
            }

            bindStoryMachineRepeat.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(AddCameraWaitActivity.this, SetupGuideActivity.class);
                    intent.putExtra(StoryMachineConsts.KEY_SET_WIFI_FROM,setup_type);
                    startActivity(intent);
                    overridePendingTransition(0, 0);
                    AddCameraWaitActivity.this.finish();
                    dialog.dismiss();
                }
            });

            root.findViewById(R.id.dialog_cancel).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    skipToMainActivity();
                    dialog.dismiss();
                }
            });

            dialog.setCancelable(true);
            dialog.show();
        }
    }

    public void showMoreSolution(int layoutID) {
        LayoutInflater inflater = LayoutInflater.from(this);
        View viewDialog = inflater.inflate(layoutID, null);
        View closeBtn = viewDialog.findViewById(R.id.toast_close_iv);
        final CamAlertDialog camAlertDialog = new CamAlertDialog(this, R.style.Dialog_Fullscreen);
        camAlertDialog.setContentView(viewDialog);
        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                camAlertDialog.dismiss();
            }
        });
        camAlertDialog.show();
    }
    protected void showCamDialog(String title, String msg, boolean isLongError) {
        if (dialog != null && dialog.isShowing())
            dialog.dismiss();
        CamAlertDialog.Builder dialog = new CamAlertDialog.Builder(this);
        dialog.setTitle(title);
        dialog.setMessage(msg);
        dialog.setMessageLeft(isLongError);
        dialog.setIsError(true);
        dialog.setPositiveButton(getString(R.string.exit), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                skipToMainActivity();
            };
        });
        CamAlertDialog d = dialog.show();
        d.setOnKeyListener(new DialogInterface.OnKeyListener() {

            @Override
            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                    dialog.dismiss();
                    skipToMainActivity();
                }
                return false;
            }
        });
    }

    private void showCancelAddDialog() {
        CamAlertDialog.Builder dialog = new CamAlertDialog.Builder(this);
        if (setup_type.equals(StoryMachineConsts.VALUE_SET_WIFI_FROM_BIND)){
            dialog.setMessage(R.string.add_camera_cancel);
        }else{
            dialog.setMessage(R.string.add_camera_cancel_connect_wifi);
        }
        dialog.setNegativeButton(getString(R.string.exit), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                if(mMediaPlayer!=null && mMediaPlayer.isPlaying()){
                    mMediaPlayer.stop();
                }
                stopRunning();
                skipToMainActivity();
            };
        });
        dialog.setPositiveButton(getString(R.string.continue_wait), null);
        dialog.show();
    }



    public void showNetworkSettingDialog(final Context context, String message) {
        if (1 == ((TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE))
                .getSimState()) {
            CamAlertDialog.Builder builder = new CamAlertDialog.Builder(context);
            // builder.setTitle(R.string.no_network_title);
            if (message == null) {
                builder.setMessage(context.getString(R.string.open_network));
            } else {
                builder.setMessage(message);
            }
            builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Intent i = new Intent();
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    i.setAction(android.provider.Settings.ACTION_WIFI_SETTINGS);
                    context.startActivity(i);
                    stopRunning();
                }

            });
            builder.setNegativeButton(R.string.cancel, null);
            dialog = builder.show();
        } else {
            CamAlertDialog.Builder builder = new CamAlertDialog.Builder(context);
            View optionsView =
                    LayoutInflater.from(context).inflate(R.layout.item_network_setting_options,
                            null);
            final RadioGroup rg = (RadioGroup) optionsView.findViewById(R.id.network_setting_group);
            builder.setView(optionsView);
            // builder.setTitle(R.string.no_network_title);
            builder.setMessage(message);
            builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Intent i = new Intent();
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    int id = rg.getCheckedRadioButtonId();
                    if (id == R.id.set_wifi_entry) {
                        i.setAction(android.provider.Settings.ACTION_WIFI_SETTINGS);
                    } else if (id == R.id.set_mobile_entry) {
                        i.setAction(android.provider.Settings.ACTION_DATA_ROAMING_SETTINGS);
                    }
                    context.startActivity(i);
                    stopRunning();
                }

            });
            builder.setNegativeButton(R.string.cancel, null);
            dialog = builder.show();
        }
    }

    private void claim() {
        Message message = handler.obtainMessage();
        message.what = Constants.TaskState.SUCCESS;
        message.obj = bindClaim();
        if (isRun) {
            handler.sendMessage(message);
        }
    }

    private void onAddSuccessed() {
        //绑定成功
        if(PadInfoWrapper.getInstance().existQidPadInfo(AccUtil.getInstance().getQID(), sn)){//管理员再次绑定，已经在我的设备列表里面
            //如果本地缓存有故事机信息，需要更新缓存中的wifi信息
            try {
                MachineDeviceInfo deviceInfo = CommonWrapper.getInstance(this).getLocalToClazz(sn, CommonWrapper.TYPE_MACHINE_DEVICE_INFO, MachineDeviceInfo.class);
                if(deviceInfo!=null){
                    deviceInfo.deviceInfo.setWifiSignal(wifi.getSSID());
                    String json = new Gson().toJson(deviceInfo);
                    CommonWrapper.getInstance(this).writeBySnWithType(sn, json, CommonWrapper.TYPE_MACHINE_DEVICE_INFO);
                }
            } catch (InstantiationException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
            CameraToast.show("故事机网络重置成功", Toast.LENGTH_SHORT);
            startActivity(new Intent(this, MainActivity.class));
            this.finish();
        }else{
            Intent intent = new Intent(this, SettingDetialActivity.class);
            intent.putExtra("sn", sn);
            intent.putExtra("bind_succeed", true);
            intent.putExtra("key", Constants.SettingCameraItem.PAD_HEAD_BIND_ITEM);
            startActivity(intent);
            this.finish();
        }
    }

    public void OnCommit(View v) {
        if (isRun) {
            showCancelAddDialog();
        } else {
            onBack();
        }
    }

    protected void doMessage(Message msg) {

        switch (msg.what) {
            case Constants.TaskState.SUCCESS:
                handleBindResult(msg);
                break;
            case MSG_COUNT_DOWN:
                handleCountDown();
                break;
            case MSG_SCAN_PERIOD:
                if (isRun) {
                    action();
                }
                break;
            default:
                break;
        }

    }

    private boolean isChinese() {
        String ssid = wifi.getSSID();
        return Utils.isContainChinese(ssid);
    }

    private void handleCountDown() {
        if (progress < 0) {
            stopRunning();
            showAddFailureDialog();
            //打点，绑定失败
            QHStatAgentHelper.doMachineStoryBindStick(QHStatAgentHelper.BINDTYPE, 1);
            CLog.d("Claim:" + "请求超时！");
        } else {
            if (progress < 112) {
                tv_add_waiting_title.setText(R.string.add_connecting_camera);
            }
            tvcountDown.setText(String.valueOf(progress) + getString(R.string.add_second));
            handler.sendEmptyMessageDelayed(MSG_COUNT_DOWN, 1000);
        }
        progress--;
    }

    private void handleBindResult(Message msg) {
        if (msg.obj != null) {
            BindResult head = (BindResult) msg.obj;
            //            Toast.makeText(this, head.getErrorMsg()+"  "+head.getErrorCode(), 0).show();
            switch (head.errorCode) {
                case 0:
                    stopRunning();
                    sn = head.data.sn;
                    String nickName = head.data.nickName;
                    if (TextUtils.isEmpty(nickName)){
                        onAddSuccessed();
                        CLog.d("Claim:" + "200 :" + head.errorMsg);
                        if (head.data != null) {
                            CLog.d("Claim:" + "sn:" + head.data.sn);
                        }
                        //打点 绑定成功
                        QHStatAgentHelper.doMachineStoryBindStick(QHStatAgentHelper.BINDTYPE, 0);
                    } else{
                        if (setup_type != null && setup_type.equals(StoryMachineConsts.VALUE_SET_WIFI_FROM_WIFI)) {
                            onAddSuccessed();
                            CLog.d("Claim:" + "200 :" + head.errorMsg);
                            if (head.data != null) {
                                CLog.d("Claim:" + "sn:" + head.data.sn);
                            }
                        }else if(setup_type != null && setup_type.equals(StoryMachineConsts.VALUE_SET_WIFI_FROM_BIND)){
                            nickName = " " + nickName + " ";
                            showCamDialog(getString(R.string.kc_add_camera_fail_added),
                                    getString(R.string.add_error_conflict_msg_name, nickName), true);
                        }
                    }

                    break;

                case 404:
                    stopRunning();
                    showCamDialog(getString(R.string.kc_add_camera_fail),
                            getString(R.string.error_response_not_found), false);
                    CLog.d("Claim:" + "404 :" + head.errorMsg);
                    break;

                case 9://已经被绑定
                    stopRunning();
                    String account = head.data.nickName;
                    if (TextUtils.isEmpty(account)) {
                        showCamDialog(getString(R.string.kc_add_camera_fail_added),
                                getString(R.string.add_error_conflict_msg), true);
                    } else {
                        if (setup_type != null && setup_type.equals(StoryMachineConsts.VALUE_SET_WIFI_FROM_WIFI)) {
                            CameraToast.show("故事机网络重置成功", Toast.LENGTH_SHORT);
                            skipToMainActivity();
                        } else if (setup_type != null && setup_type.equals(StoryMachineConsts.VALUE_SET_WIFI_FROM_BIND)) {
                            account = " " + account + " ";
                            showCamDialog(getString(R.string.kc_add_camera_fail_added),
                                    getString(R.string.add_error_conflict_msg_name, account), true);
                        }
                    }
                    CLog.d("Claim:" + "9 :" + head.errorMsg);
                    break;

                default:
                    CLog.d("Claim:" + head.errorMsg + "  " + head.errorCode);
                    break;
            }
        }
    }

    private void stopRunning() {
        isRun = false;
        handler.removeCallbacksAndMessages(null);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_add_complete:
                InputMethodManager imm =
                        (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(et_add_name.getWindowToken(), 0); // 强

                String name = et_add_name.getText().toString().trim();
                if (TextUtils.isEmpty(name)) {
                    name = getString(R.string.my_camera);
                }
                TaskExecutor.Execute(new ModifyDeviceInfoTask(name));
                //TODO 弹窗提醒添加故事机成功
                showAddSusDialog();
                break;
            default:
                break;
        }
    }

    /********** 内部类 **********/
    class PollClaimTask implements Runnable {
        @Override
        public void run() {
            while (isRun) {
                try {
                    claim();
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    class ModifyDeviceInfoTask implements Runnable {
        private final String name;

        public ModifyDeviceInfoTask(String name) {
            this.name = name;
        }

        @Override
        public void run() {
//            try {
//                JSONObject params = new JSONObject();
//                params.put("sn", sn);
//                params.put("title", name);
//                CameraHttpApi cameraHttpApi = new CameraHttpApi();
//                cameraHttpApi.doCommonRequest(params, CameraHttpApi.URL_APP_MODIFY_DEVICE_INFO,
//                        Head.class);
//            } catch (JSONException e) {
//                e.printStackTrace();
//                GlobalManager.getInstance().myCameraManager().asynLoadFromServer(false);
//                handler.obtainMessage(Constants.TaskState.EXCEPITON).sendToTarget();
//            }
        }
    }

    //添加故事机成功，弹出提示
    private void showAddSusDialog() {
        Dialog dialog = new Dialog(this, R.style.Dialog_General);
        View root = LayoutInflater.from(this).inflate(R.layout.dialog_add_machine_success, null);
        dialog.setContentView(root);
        dialog.setCancelable(false);
        root.findViewById(R.id.goto_see_machine).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //TODO 添加故事机成功，需要进入那个设备
                Preferences.saveSelectedPad(sn);
                GlobalManager.getInstance().getCommonManager().publishAction(Actions.Common.BIND_SUCCESS_UPDATE);
                ActivityUtils.startActivityAndFinish(AddCameraWaitActivity.this, MainActivity.class);
            }
        });
        dialog.show();
    }

    private void skipToMainActivity(){
        Intent intent = new Intent(AddCameraWaitActivity.this, MainActivity.class);
        startActivity(intent);
        overridePendingTransition(0, 0);
        AddCameraWaitActivity.this.finish();
    }
}
