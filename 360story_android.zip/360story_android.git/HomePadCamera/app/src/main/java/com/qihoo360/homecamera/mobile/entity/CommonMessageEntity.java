package com.qihoo360.homecamera.mobile.entity;

/**
 * Created by zhaojunbo on 2016/4/28.
 * desc:
 */
public class CommonMessageEntity<T> {

    /**
     * 0,家人申请
     * 1,平板加平板申请
     * 2,主人已同意，客人弹窗告知，进而跳转关系选择
     */
    public final static int FAMILY_BIND = 0;

    public final static int FRIEND_BIND = 1;

    public final static int MASTER_AGREE = 2;

    public final static int FRIEND_AGREE = 3;

    public final static int FRIEND_REJECT = 4;

    public final static int FRIEND_CANCEL = 5;

    public final static int MASTER_REFUSE = 6;

    public final static int MASTER_ADD = 7;

    public final static int CANCEL_SHARE = 8;

    public final static int KIBOT_UNBIND = 9;

    public final static int ALREADY_BIND = 10;

    public final static int KIBOT_LOW_BATTERY = 11;

    public final static int ROBOT_LOCK_SCREEN_RECEIPT = 12;

    public int id = -1;
    /**
     * 0未弹出，1已弹出，2已消失
     */
    public boolean hasShow = false;
    public int messageType = -1;
    public T data;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

}
