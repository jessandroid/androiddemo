
package com.qihoo360.homecamera.machine.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Message;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.gson.Gson;
import com.qihoo360.homecamera.device.config.StoryMachineConsts;
import com.qihoo360.homecamera.machine.business.JsonManager;
import com.qihoo360.homecamera.machine.business.PlayConfig;
import com.qihoo360.homecamera.machine.business.SettingTask;
import com.qihoo360.homecamera.machine.business.TaskExecutor;
import com.qihoo360.homecamera.machine.config.MachineConsts;
import com.qihoo360.homecamera.machine.entity.LocalSetting;
import com.qihoo360.homecamera.machine.entity.MachineDeviceInfo;
import com.qihoo360.homecamera.machine.entity.UpgradeReceipt;
import com.qihoo360.homecamera.machine.manager.MachinePlayInfoManager;
import com.qihoo360.homecamera.machine.util.NetUtil;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.activity.BindDeviceFrameActivity;
import com.qihoo360.homecamera.mobile.activity.MainActivity;
import com.qihoo360.homecamera.mobile.activity.SettingDetialActivity;
import com.qihoo360.homecamera.mobile.activity.UnbindMachineActivity;
import com.qihoo360.homecamera.mobile.adapter.FamilyMemberAdapter;
import com.qihoo360.homecamera.mobile.config.Const;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.db.CommonWrapper;
import com.qihoo360.homecamera.mobile.db.FamilyGroupWrapper;
import com.qihoo360.homecamera.mobile.db.MachineSongWrapper;
import com.qihoo360.homecamera.mobile.db.PadInfoWrapper;
import com.qihoo360.homecamera.mobile.db.PhoneRecordWrapper;
import com.qihoo360.homecamera.mobile.entity.AppGetInfoEntity;
import com.qihoo360.homecamera.mobile.entity.BabyInfoEntity;
import com.qihoo360.homecamera.mobile.entity.Contacts;
import com.qihoo360.homecamera.mobile.entity.DeviceInfo;
import com.qihoo360.homecamera.mobile.entity.Head;
import com.qihoo360.homecamera.mobile.entity.IpcAllEntity;
import com.qihoo360.homecamera.mobile.entity.RelationInfoEntity;
import com.qihoo360.homecamera.mobile.entity.ShareGetListEntity;
import com.qihoo360.homecamera.mobile.entity.ShareUserEntity;
import com.qihoo360.homecamera.mobile.entity.Update;
import com.qihoo360.homecamera.mobile.entity.UpdateInfo;
import com.qihoo360.homecamera.mobile.http.OkHttpUtils;
import com.qihoo360.homecamera.mobile.image.my.GlideCircleTransform;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.manager.VersionManager;
import com.qihoo360.homecamera.mobile.ui.fragment.PadRelaxActivity;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.PhoneUtil;
import com.qihoo360.homecamera.mobile.utils.Preferences;
import com.qihoo360.homecamera.mobile.utils.QHStatAgentHelper;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.widget.CamAlertDialog;
import com.qihoo360.homecamera.mobile.widget.NumSeekBar;
import com.qihoo360.homecamera.mobile.widget.SettingItem;
import com.qihoo360.homecamera.mobile.widget.TextViewWithFont;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import rx.Single;
import rx.SingleSubscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

public class MachineSettingActivity extends MachineBaseActivity implements View.OnClickListener, ActionListener, SettingItem.ISwitchListener, SeekBar.OnSeekBarChangeListener{

    public final static int CHANGE_TITLE = 1001;
    public final static int EDIT_FAMILY = 1002;
    private DeviceInfo dev;
    private TextView del;
    private AppGetInfoEntity mAppGetInfoEntity;
    private BabyInfoEntity mBabyInfoEntity;
    private RelationInfoEntity mRelationInfoEntity;
    private ImageView mAvatorIv;
    private TextView mBabyNameTv;
    private TextView mBabySexTv;
    private TextView mBabyBirthTv;
    private TextView mBabyAgeTv;
    private TextView mRelaxTv;
    private int mSelect;
    private TextView setingTip;

    private RecyclerView mMemberRecycle;
    private FamilyMemberAdapter mFamilyMemberAdapter;

    private ImageView mMasterIv;
    private TextView mMasterTv;
    private RelativeLayout mMemberMoreRl;
    private TextView mMemberMoreTv;
    private ImageView mMemberMoreIv;
    private boolean mIsMemberExpand = false;
    private LinearLayout lightSetZone;
    private View lightLine;

    private CamAlertDialog camAlertDialog;
    private BroadcastReceiver refreshInvitedAndInvitingListReceiver;

    private NumSeekBar mVolumeSetting;
    private SettingItem settingItemChildLock;
    private SettingItem settingItemVideoCatch;
    private SettingItem settingItemIndicateLight;
    private SettingItem settingItemFirmwareUpdate;//故事机系统升级检测
    private SettingItem settingItemReconnectWifi;//重连wifi
    private RelativeLayout rlReconnectWifi;//重连wifi
    private RelativeLayout fmUpdateZone;
    private LinearLayout volumeZone;
    private TextView mVolumnPercent;
    private TextViewWithFont textVersion;//故事机系统版本
    private View spaceZone;
    private LinearLayout mLlSettingItemChildLock;

    private boolean lockChanged = false;
    private boolean indicatorChanged = false;
    private boolean volumeChanged = false;
    private int currentVolume;

    private final static int NULLINT = -1000;

    private boolean isOnline = true;
    private MachineDeviceInfo machineDeviceInfo;

    private VersionManager versionManager;
    private boolean isFromOwn = false;
    private TextView tvStoryMachineVersion;
    private boolean isUserCheckNewVersion = false;
    private RelativeLayout rlStoryMachineInfo;
    private String device_type;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.machine_setting);
        if(getIntent()!=null){
            if(getIntent().hasExtra("dev")){
                dev = getIntent().getParcelableExtra("dev");
                device_type = dev.deviceType;

            }
        }
        if (dev == null || TextUtils.isEmpty(dev.sn)) {
            finish();
        }
        initView();

        loadMachineDeviceInfoFromDB();

        refreshInvitedAndInvitingListReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                refreshList();
            }
        };
        GlobalManager.getInstance().getCommonManager().registerActionListener(this);
        registerReceiver(refreshInvitedAndInvitingListReceiver, new IntentFilter(Const.BROADCAST_REFRESH_INVITED_AND_INVITING_LIST));

        GlobalManager.getInstance().getUserInfoManager().registerActionListener(this);
        GlobalManager.getInstance().getShareManager().registerActionListener(this);
        GlobalManager.getInstance().getNeverKillManager().registerActionListener(this);
        GlobalManager.getInstance().getCameraManager().registerActionListener(this);
        MachinePlayInfoManager.getInstance().registerActionListener(this);
        GlobalManager.getInstance().getMachineSettingManager().registerActionListener(this);

        //现在缓存本地的设置
        settingItemVideoCatch.setChecked(Preferences.getVideoSwitchState(dev.getSn()));
        LocalSetting setting = null;
        try {
            setting = CommonWrapper.getInstance(this).getLocalToClazz(dev.getSn(), CommonWrapper.TYPE_MACHINE_LOCAL_SETTING, LocalSetting.class);
            if(setting!=null){
                handlerLocalSetting(setting);
            }
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }

        //向服务端拉取最新的
        doGetSetingCmd();
        doGetDeviceInfo();
        GlobalManager.getInstance().getMachineSettingManager().aysnGetMachineVideoCatch(dev.getSn());
    }

    @Override
    protected void onResume() {
        GlobalManager.getInstance().getUserInfoManager().asyncAppGetInfo(dev.getSn());
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    private void initView() {
        ImageView back_zone = (ImageView) findViewById(R.id.back_zone);
        Utils.ensuerSetOnclick(this, back_zone);

        TextViewWithFont title_string = (TextViewWithFont) findViewById(R.id.title_string);
        if (title_string != null) {
            title_string.setText(R.string.story_machine_setting);
        }

        RelativeLayout mBabyInfoRl = (RelativeLayout) findViewById(R.id.rl_baby_info);
        RelativeLayout mRelaxRl = (RelativeLayout) findViewById(R.id.rl_relax);

        mAvatorIv = (ImageView) findViewById(R.id.circle_image_view);
        mBabyNameTv = (TextView) findViewById(R.id.tv_baby_name);
        mBabySexTv = (TextView) findViewById(R.id.tv_baby_sex);
        mBabyBirthTv = (TextView) findViewById(R.id.tv_baby_birth);
        mBabyAgeTv = (TextView) findViewById(R.id.tv_baby_age);
        mBabyBirthTv.setText(Utils.DATE_FORMAT_5.format(System.currentTimeMillis()));
        mBabyAgeTv.setText(PhoneUtil.formatSecond(this, System.currentTimeMillis()));
        mRelaxTv = (TextView) findViewById(R.id.tv_relax);
        ImageView mInfoArrowIv = (ImageView) findViewById(R.id.iv_info_arrow);
        ImageView mArrowRelaxRightIv = (ImageView) findViewById(R.id.iv_arrow_relax_right);

        mMasterIv = (ImageView) findViewById(R.id.master_circle_image_view);
        mMasterTv = (TextView) findViewById(R.id.tv_master_name);
        mMemberMoreRl = (RelativeLayout) findViewById(R.id.rl_member_more);
        mMemberMoreRl.setOnClickListener(this);
        mMemberMoreRl.setVisibility(View.GONE);
        mMemberMoreTv = (TextView) findViewById(R.id.tv_member_more);
        mMemberMoreIv = (ImageView) findViewById(R.id.iv_member_more);
        tvStoryMachineVersion = (TextView) findViewById(R.id.tv_story_machine_version);

        setingTip = (TextView) findViewById(R.id.seting_tip);

        spaceZone = findViewById(R.id.space_zone);
        //小视频开关设置
        settingItemVideoCatch = (SettingItem) findViewById(R.id.setting_item_video_catch);
        settingItemVideoCatch.setSwitchChangeListener(this);
        if (device_type != null && device_type.equals(StoryMachineConsts.VALUE_SET_MACHINE_TYPE_605)){
            settingItemVideoCatch.setVisibility(View.GONE);
        }

        //童锁开关设置
        settingItemChildLock = (SettingItem) findViewById(R.id.setting_item_child_lock_switch);
        settingItemChildLock.setSwitchChangeListener(this);
        mLlSettingItemChildLock = (LinearLayout) findViewById(R.id.ll_setting_item_child_lock);

        //指示灯开关设置
        lightSetZone = (LinearLayout) findViewById(R.id.light_set_zone);
        settingItemIndicateLight = (SettingItem) findViewById(R.id.setting_item_indicate_light_switch);
        settingItemIndicateLight.setSwitchChangeListener(this);
        lightLine = findViewById(R.id.light_line);

        //最大音量设置
        volumeZone = (LinearLayout) findViewById(R.id.volume_zone);
        mVolumeSetting = (NumSeekBar) findViewById(R.id.volume_setting);
        mVolumnPercent = (TextView) findViewById(R.id.volumn_percent);
        mVolumeSetting.setOnSeekBarChangeListener(this);
        if (device_type != null && device_type.equals(StoryMachineConsts.VALUE_SET_MACHINE_TYPE_605)){
            volumeZone.setVisibility(View.GONE);
            lightLine.setVisibility(View.GONE);
        }else {
            volumeZone.setVisibility(View.VISIBLE);
            lightLine.setVisibility(View.VISIBLE);
        }

        //故事机固件升级
        fmUpdateZone = (RelativeLayout) findViewById(R.id.fm_update_zone);
        settingItemFirmwareUpdate = (SettingItem) findViewById(R.id.setting_item_firmware_update);
        textVersion = (TextViewWithFont) findViewById(R.id.text_check_new_version);

        //重连wifi
        settingItemReconnectWifi = (SettingItem) findViewById(R.id.setting_item_reconnect_wifi);
        rlReconnectWifi = (RelativeLayout) findViewById(R.id.rl_reconnect_wifi);
        rlReconnectWifi.setOnClickListener(this);


        //故事机信息
//        SettingItem settingMachineInfo = (SettingItem) findViewById(R.id.setting_item_story_machine_info);
        TextView settingMachineInfo = (TextView) findViewById(R.id.setting_item_story_machine_info);
        settingMachineInfo.setOnClickListener(this);

        rlStoryMachineInfo = (RelativeLayout) findViewById(R.id.rl_story_machine_info);
        rlStoryMachineInfo.setOnClickListener(this);

        SettingItem storyMachineButtonDescription = (SettingItem) findViewById(R.id.setting_item_story_machine_button_description);
        storyMachineButtonDescription.setOnClickListener(this);

        Utils.ensuerSetOnclick(this, mBabyInfoRl, mRelaxRl, settingMachineInfo, settingItemReconnectWifi, settingItemFirmwareUpdate);
        Utils.ensureVisbility(View.VISIBLE, mInfoArrowIv);
        Utils.ensureVisbility(View.INVISIBLE, mArrowRelaxRightIv);


        View delview = findViewById(R.id.del_device);
        if (delview != null) {
            del = (TextView) delview.findViewById(R.id.del_text);
            delview.setOnClickListener(this);
        }

        mFamilyMemberAdapter = new FamilyMemberAdapter(this, dev.getRole() == 1);
        mFamilyMemberAdapter.setOnViewClick(new FamilyMemberAdapter.OnViewClick() {
            @Override
            public void onNewFamily() {
                // 故事机只有手机号添加，直接进入手机号添加页面
                showBindPhone();
            }

            @Override
            public void onEditFamily(ShareUserEntity deviceInfo) {

                Intent intent = new Intent(MachineSettingActivity.this, SettingDetialActivity.class);
                intent.putExtra("key", Constants.SettingCameraItem.PAD_EDIT_FAMILY_ITEM);
                intent.putExtra("shareUserEntity", deviceInfo);
                intent.putExtra(DeviceInfo.class.getSimpleName(), dev);
                startActivityForResult(intent, EDIT_FAMILY);
            }
        });
        mMemberRecycle = (RecyclerView) findViewById(R.id.member_recycle);
        //
        mMemberRecycle.setLayoutManager(new GridLayoutManager(this, 5));
        mMemberRecycle.setAdapter(mFamilyMemberAdapter);

        camAlertDialog = new CamAlertDialog(this, R.style.dialog_custom, false);
        View optionsView = LayoutInflater.from(this).inflate(R.layout.play_video_dialog_layout, null);
        TextView title = (TextView) optionsView.findViewById(R.id.title);
        title.setText(Utils.getString(R.string.invite_family_watch_together));
        ImageView close = (ImageView) optionsView.findViewById(R.id.close);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                camAlertDialog.dismiss();
            }
        });

        camAlertDialog.setContentView(optionsView);
        camAlertDialog.setCancelable(true);

        if (dev.getRole() != 1) {
            //我不是管理员
            Utils.ensureVisbility(setingTip, View.GONE);
            //小视频开关设置
            Utils.ensureVisbility(settingItemVideoCatch, View.GONE);
            //童锁开关设置
            Utils.ensureVisbility(mLlSettingItemChildLock, View.GONE);
            //指示灯开关设置
            Utils.ensureVisbility(lightSetZone, View.GONE);
            //最大音量设置
            Utils.ensureVisbility(volumeZone, View.GONE);
//            //重连wifi
//            Utils.ensureVisbility(settingItemReconnectWifi, View.GONE);
            //故事机固件升级
            Utils.ensureVisbility(fmUpdateZone, View.GONE);
            Utils.ensureVisbility(spaceZone, View.VISIBLE);
//            settingMachineInfo.hideDivideLine();
        }else{
            if(Preferences.getFmUp(dev.getSn())){
                settingItemFirmwareUpdate.showRightImage(R.drawable.has_new);
                textVersion.setText(Preferences.getFmSystemCode(dev.getSn()));
            }else{
                settingItemFirmwareUpdate.hideRightImage();
                textVersion.setText(getString(R.string.check_new_version));
            }
        }

        currentVolume = mVolumeSetting.getProgress();
    }


    @Override
    public void onClick(View view) {
        Intent intent = new Intent(MachineSettingActivity.this, MachineSettingDetialActivity.class);
        intent.putExtra(DeviceInfo.class.getSimpleName(), dev);
        switch (view.getId()) {
            case R.id.back_zone: {
                OkHttpUtils.getInstance().cancelTag(this);
                finish();
                break;
            }
            case R.id.rl_relax:
            case R.id.rl_baby_info: {
                if (dev.getRole() == 1) {
                    intent.putExtra("appGetInfoEntity", mAppGetInfoEntity);
                    intent.putExtra("babyInfoEntity", mBabyInfoEntity);
                    intent.putExtra("relationInfoEntity", mRelationInfoEntity);
                    intent.putExtra("key", Constants.SettingCameraItem.PAD_HEAD_ITEM);
                    intent.putExtra("sn", dev.sn);
                    intent.putExtra("unset", isUnset());
                    startActivityForResult(intent, CHANGE_TITLE);
                } else {
                    Intent relaxIntent = new Intent(this, PadRelaxActivity.class);
                    relaxIntent.putExtra("relationInfoEntity", mRelationInfoEntity);
                    relaxIntent.putExtra("sn", dev.sn);
                    relaxIntent.putExtra("is_master", false);
                    relaxIntent.putExtra("unset", isUnset());
                    startActivityForResult(relaxIntent, 1005);
                }
                break;
            }
            case R.id.del_device: {
                if (dev != null) {
                    if (dev.getRole() != 1) {
                        showCommonDialog(getString(R.string.remove_device_dialog_tips), getString(dev.getRole() == 1 ? R.string.remove_story_device_dialog_content_1 : R.string.remove_story_device_dialog_content),
                                getString(R.string.remove_device_dialog_ok), getString(R.string.remove_device_dialog_cancel),
                                new ArrayList<String>() {{
                                    add(getString(R.string.check_tips));
                                    add(getString(R.string.check_tips_1));
                                }},
                                dev.getRole() == 1, new ICommonDialog() {
                                    @Override
                                    public void onRightButtonClick(boolean... isChecked) {

                                    }

                                    @Override
                                    public void onLeftButtonClick(boolean... isChecked) {
                                        if (dev.getRole() == 1) {
                                            GlobalManager.getInstance().getCameraManager().asyncLoadUnBindDevice(dev.getSn(), isChecked[0] ? "1" : "0", isChecked[1] ? "1" : "0");
                                        } else {
                                            isFromOwn = true;
                                            GlobalManager.getInstance().getShareManager().asyncShareCancel(dev.getSn(), dev.getQid());
                                        }
                                        showTipsDialog(getString(R.string.tips_49), R.drawable.icon_loading, 10000, true);
                                    }

                                    @Override
                                    public void onDialogCancel() {

                                    }
                                });
                    } else {
                        Intent intent1 = new Intent(MachineSettingActivity.this, UnbindMachineActivity.class);
                        intent1.putExtra(DeviceInfo.class.getSimpleName(), dev);
                        startActivity(intent1);
                    }
                } else {
                    CameraToast.show(this, "DEV 是空的", Toast.LENGTH_LONG);
                    finish();
                }
                break;
            }
            case R.id.rl_member_more: {
                mIsMemberExpand = !mIsMemberExpand;
                if (mIsMemberExpand) {
                    mMemberMoreIv.setImageResource(R.drawable.cam_setting_up_arrow);
                    mFamilyMemberAdapter.setMaxCount(0);
                } else {
                    mMemberMoreIv.setImageResource(R.drawable.cam_setting_down_arrow);
                    int maxCount = 10;
                    mFamilyMemberAdapter.setMaxCount((dev.getRole() == 1 ? maxCount - 1 : maxCount));
                }
                break;
            }

            //故事机信息
            case R.id.rl_story_machine_info: {
                intent.putExtra("key", MachineConsts.SettingMachineItem.MACHINE_ABOUT_ITEM);
                startActivity(intent);
                break;
            }
            //故事机信息
            case R.id.setting_item_story_machine_info:{
                intent.putExtra("key", MachineConsts.SettingMachineItem.MACHINE_ABOUT_ITEM);
                startActivity(intent);
                break;
            }

            //固件升级检测
            case R.id.setting_item_firmware_update: {
                isUserCheckNewVersion = true;
                if (isOnline) {
                    if (mProgressDialog != null) {
                        mProgressDialog.show();
                    }
                    if (dev != null && dev.getRole() == 1) {
                        //只有主人才有权限升级固件
                        if (!TextUtils.isEmpty(dev.version)) {
                            String[] tmp = dev.version.split("|");
                            if (tmp != null && tmp.length == 2) {
                                GlobalManager.getInstance().getCommonManager().checkFMNewVersion(VersionManager.REQUEST_SOURCE_PERSONAL, tmp[0], Integer.valueOf(tmp[1]), dev.getSn());
                            } else {
                                doGetDeviceInfo();
                            }
                        } else {
                            doGetDeviceInfo();
                        }
                    }
                } else {
                    CameraToast.show(this, getString(R.string.story_machine_offline), Toast.LENGTH_SHORT);
                    isUserCheckNewVersion = false;
                }
                break;
            }

            //重连wifi
            case R.id.setting_item_reconnect_wifi: {
                reconnectWifi();
                break;
            }

            //重连wifi
            case R.id.rl_reconnect_wifi: {
                reconnectWifi();
                break;
            }
            case R.id.setting_item_story_machine_button_description:{
                //TODO 功能体测后，去掉下面这行代码
//                Toast.makeText(this,"故事机按键说明",Toast.LENGTH_LONG).show();
                intent.putExtra("key", Constants.SettingCameraItem.MACHINE_SETTING_STORY_MACHINE_KEY_INTRODUCTION);
                startActivity(intent);

                break;
            }


        }
    }

    public boolean isUnset() {
        if (mRelationInfoEntity == null || mBabyInfoEntity == null) {
            return true;
        }
        if (dev.getRole() == 1) {
            return TextUtils.isEmpty(mRelationInfoEntity.relation_title) || mBabyInfoEntity.babysex == -1;
        } else {
            return TextUtils.isEmpty(mRelationInfoEntity.relation_title);
        }
    }

    @Override
    public void finish() {
        if (camAlertDialog != null) {
            camAlertDialog.dismiss();
        }
        if (mBabyInfoEntity != null && !TextUtils.isEmpty(mBabyInfoEntity.babyname)) {
            Intent intent = new Intent();
            intent.putExtra("title", mBabyInfoEntity.babyname);
            setResult(MainActivity.CAMERA_SETTING_CHANGE, intent);
        }
        super.finish();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Constants.TAG_LIST.remove(8);
        Constants.TAG_LIST.add("其他");
        OkHttpUtils.getInstance().cancelTag(this);
        GlobalManager.getInstance().getCommonManager().removeActionListener(this);
        GlobalManager.getInstance().getUserInfoManager().removeActionListener(this);
        GlobalManager.getInstance().getShareManager().removeActionListener(this);
        GlobalManager.getInstance().getNeverKillManager().removeActionListener(this);
        GlobalManager.getInstance().getCameraManager().removeActionListener(this);
        MachinePlayInfoManager.getInstance().removeActionListener(this);
        GlobalManager.getInstance().getMachineSettingManager().removeActionListener(this);
        unregisterReceiver(refreshInvitedAndInvitingListReceiver);
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case CHANGE_TITLE:
                if (data != null && !TextUtils.isEmpty(data.getStringExtra("babyInfo"))) {
                    String babyInfo = data.getStringExtra("babyInfo");
                    String filePath = data.getStringExtra("filePath");
                    Gson gson = new Gson();
                    mBabyInfoEntity = gson.fromJson(babyInfo, BabyInfoEntity.class);
                    if (mAppGetInfoEntity != null ) {
                        if(!TextUtils.isEmpty(filePath)){
                            mAppGetInfoEntity.data.avatarUrl = filePath;
                        }
                        refreshView(mAppGetInfoEntity.data.avatarUrl);
                    }
                }
                break;

            case 1005:
                if (data != null) {
                    mSelect = data.getIntExtra("select", 0);
                    mRelaxTv.setText(Constants.TAG_LIST.get(mSelect));
                }
                break;

            case Constants.PHONE_LIST:
                if (data != null) {
                    final Contacts contact = (Contacts) data.getSerializableExtra("contact");
                    if (contact != null && !TextUtils.isEmpty(contact.getPhoneNumber())) {
                        showCommonDialog(getString(R.string.tips_21),
                                getString(R.string.tips_22, contact.getPhoneNumber()),
                                getString(R.string.tips_23), getString(R.string.tips_24), "", false, new ICommonDialog() {
                                    @Override
                                    public void onRightButtonClick(boolean... isChecked) {
                                        try {
                                            GlobalManager.getInstance().getShareManager().asyncShareShare(dev.getSn(), "3", Utils.checkPhoneNum(contact.getPhoneNumber()), Constants.DeviceType.STORYMACHINE);
                                            showTipsDialog(getString(R.string.tips_25), R.drawable.icon_loading, true);
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    }

                                    @Override
                                    public void onLeftButtonClick(boolean... isChecked) {

                                    }

                                    @Override
                                    public void onDialogCancel() {

                                    }
                                });
                    }
                }
                break;

            case EDIT_FAMILY:
                refreshList();
                break;
         /*   case PadHeadFragment.REQUEST_CROP_PHOTO: {
                if (mUserHeadBitmap != null) {
                    modifyUserHead(mUserHeadBitmap);
                    CameraToast.show("读取图片成功", Toast.LENGTH_SHORT);
                } else {
                    CameraToast.show("读取图片失败", Toast.LENGTH_SHORT);
                }
                break;
            }*/
            default:
                break;
        }
    }

    @Override
    public Object actionPerformed(int actionCode, Object... args) {
        switch (actionCode) {
            case  Actions.Common.EXIT:{
                finish();
                return Boolean.TRUE;
            }
            case Actions.UserInfo.APP_GET_INFO_SUCCESS: {
                mAppGetInfoEntity = (AppGetInfoEntity) args[0];
                String extend = mAppGetInfoEntity.data.babyInfo;
                Gson gson = new Gson();
                mBabyInfoEntity = gson.fromJson(extend, BabyInfoEntity.class);
                String relation = mAppGetInfoEntity.data.relation;
                mRelationInfoEntity = gson.fromJson(relation, RelationInfoEntity.class);
                refreshView(mAppGetInfoEntity.data.avatarUrl);

                refreshList();

                return Boolean.TRUE;
            }
            case Actions.UserInfo.APP_GET_INFO_FAIL: {
                mMemberMoreRl.setVisibility(View.GONE);
                hideTipsDialog();
                if (args != null && args.length > 0) {
                    CameraToast.showErrorToast((String) args[0]);
                }
                return Boolean.TRUE;
            }

            case Actions.Share.SHARE_GET_LIST_SUCCESS: {
                hideTipsDialog();
                ShareGetListEntity shareGetListEntity = (ShareGetListEntity) args[0];
                if (shareGetListEntity != null) {
                    int size = shareGetListEntity.data.data.size();
                    for (int i = 0; i < size; ++i) {
                        ShareUserEntity entity = shareGetListEntity.data.data.get(i);
                        if (entity.role.equals("1")) {
                            Glide.with(MachineSettingActivity.this)
                                    .load(entity.imgUrl)
                                    .transform(new GlideCircleTransform(Utils.context))
                                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                                    .error(R.drawable.icon_avator_empty)
                                    .into(mMasterIv);

                            String name = (entity.getRelationId() == 0 && entity.getRelation().equals("未设置")) ? entity.nickName : entity.getRelation();
                            name = TextUtils.isEmpty(name) ? entity.phone : name;
                            name = TextUtils.isEmpty(name) ? entity.userName : name;
                            if (entity.phone != null && entity.phone.equals(AccUtil.getInstance().getSecPhoneNumber())) {
                                name = "我(" + name + ")";
                            }

                            mMasterTv.setText(name);

                            shareGetListEntity.data.data.remove(entity);
                            break;
                        }
                    }

                    int maxCount = 10;
                    maxCount = (dev.getRole() == 1 ? maxCount - 1 : maxCount);
                    size = shareGetListEntity.data.data.size();
                    if (size > maxCount) {
                        mMemberMoreRl.setVisibility(View.VISIBLE);
                        mMemberMoreTv.setText(getString(R.string.member_more, size));
                        if (mIsMemberExpand) {
                            maxCount = size;
                        }
                    } else {
                        mMemberMoreRl.setVisibility(View.GONE);
                        maxCount = size;
                    }

                    mFamilyMemberAdapter.setData(shareGetListEntity, maxCount);
                    if (mFamilyMemberAdapter.getShareListCount() > maxCount) {
                        Utils.ensureVisbility(View.VISIBLE, mMemberMoreRl);
                    } else {
                        Utils.ensureVisbility(View.GONE, mMemberMoreRl);
                    }
                }
                return Boolean.TRUE;
            }
            case Actions.Share.SHARE_GET_LIST_FAIL: {
                hideTipsDialog();
                if (args == null || args.length == 0) {
                    CameraToast.showErrorToast(this, "发送请求失败");
                } else {
                    CameraToast.showErrorToast(args[0] + "");
                }
                return Boolean.TRUE;
            }

            case Actions.Share.SHARE_CANCEL_SUCCESS: {
                hideTipsDialog();
                if(isFromOwn){
                    CameraToast.showToast(this, R.string.unbind_device_suc);
                }
                if (Preferences.getSelectedPad().equals(dev.getSn())) {
                    Preferences.saveSelectedPad("");
                }
                Single.create(new Single.OnSubscribe<Object>() {
                    @Override
                    public void call(SingleSubscriber<? super Object> singleSubscriber) {
                        FamilyGroupWrapper.getInstance().cleanData(dev.getSn());
                        MachineSongWrapper.getInstance().cleanSongData(dev.getSn());
                        singleSubscriber.onSuccess(new Object());
                    }
                }).subscribeOn(Schedulers.io())
                   .subscribe();
                PadInfoWrapper.getInstance().deletePadBySnQid(dev.getSn(), AccUtil.getInstance().getQID());
//                GlobalManager.getInstance().getCameraManager().publishAction(Actions.Camera.CAMERA_LIST_ACTION);
                GlobalManager.getInstance().getCameraManager().publishAction(Actions.Camera.DELTET_SN, dev.getSn());
                GlobalManager.getInstance().getCommonManager().publishAction(Actions.Common.UNBIND_SUCCESS_UPDATE, dev.getSn());
                if(isFromOwn){
                    finish();
                }
                //打点,解绑成功
                QHStatAgentHelper.doMachineStoryBindStick(QHStatAgentHelper.UNBINDTYPE, 0);
                return Boolean.TRUE;
            }

            case Actions.Share.SHARE_CANCEL_FAIL: {
                CameraToast.showErrorToast(this, R.string.unbind_device_fail);
                hideTipsDialog();
                //打点,解绑失败
                QHStatAgentHelper.doMachineStoryBindStick(QHStatAgentHelper.UNBINDTYPE, 1);
                return Boolean.TRUE;
            }

            case Actions.Share.SHARE_RESPONSE_SUCCESS: {
                refreshList();
                return Boolean.TRUE;
            }

            case Actions.Camera.UN_BIND_DEVICE_SUCCESS: {
                //TODO 清空聊天数据库
                //清空该sn下的聊天记录
                Single.create(new Single.OnSubscribe<Object>() {
                    @Override
                    public void call(SingleSubscriber<? super Object> singleSubscriber) {
                        FamilyGroupWrapper.getInstance().cleanData(dev.getSn());
                        MachineSongWrapper.getInstance().cleanSongData(dev.getSn());
                        singleSubscriber.onSuccess(new Object());
                    }
                }).subscribeOn(Schedulers.io())
                  .subscribe();
                PhoneRecordWrapper.getInstance(MachineSettingActivity.this).updatePhoneRecordStateBySn(dev.getSn());
                CameraToast.showToast(Utils.context, R.string.unbind_device_suc);
                hideTipsDialog();
                finish();
                //打点,解绑成功
                QHStatAgentHelper.doMachineStoryBindStick(QHStatAgentHelper.UNBINDTYPE, 0);
                return Boolean.TRUE;
            }

            case Actions.Camera.UN_BIND_DEVICE_FAIL: {
                CameraToast.showToast(Utils.context, R.string.unbind_device_fail);
                hideTipsDialog();
                //打点,解绑失败
                QHStatAgentHelper.doMachineStoryBindStick(QHStatAgentHelper.UNBINDTYPE, 1);
                return Boolean.TRUE;
            }

            case Actions.Share.SHARE_FRIEND_RESPONSE_SUCCESS: {
                String agree = (String) args[0];
                //刷新机器人成员管理列表
                if (agree.equals("1")) {
                    refreshList();
                }
                return Boolean.TRUE;
            }

            case Actions.MachinePlayInfo.NOTIFY_LOCAL_SETTING_UPDATE:{
                String sn = (String)args[1];
                if(TextUtils.equals(sn, dev.getSn())){
                    handlerLocalSetting((LocalSetting) args[0]);
                }
                return Boolean.TRUE;
            }

            case Actions.GlobalActionCode.SETTING_MACHINE_VIDEO_CAPTRUE:{

                Head head = (Head)args[0];
                if(head.getErrorCode()==0){
                    //TODO 不需要处理
                    Preferences.saveVideoSwitchState(dev.getSn(), settingItemVideoCatch.getChecked());
                    //打点
                    HashMap<String,String> map = new HashMap<>();
                    map.put("type", "videotape");
                    map.put("state", settingItemVideoCatch.getChecked() ? "on" : "off");
                    if(mBabyInfoEntity!=null){
                        map.put("sex", mBabyInfoEntity.babysex == 0 ? getString(R.string.baby_sex_male) : getString(R.string.baby_sex_female));
                        map.put("age", String.valueOf(mBabyInfoEntity.babybirth));
                    }
                    map.put("identity", mRelationInfoEntity.relation_title);
                    QHStatAgentHelper.doMachineSettingStick(map);
                }else{
                    //TODO 设置失败
                    settingItemVideoCatch.setChecked(!settingItemVideoCatch.getChecked());
                }
                return Boolean.TRUE;
            }

            case Actions.GlobalActionCode.GETTING_MACHINE_VIDEO_CAPTRUE:{

                IpcAllEntity settingResponse = (IpcAllEntity)args[0];
                if(settingResponse!=null){
                    if(settingResponse.data.settings!=null && settingResponse.data.settings.capture_video!=null && !TextUtils.isEmpty(settingResponse.data.settings.capture_video)){
                        Preferences.saveVideoSwitchState(dev.getSn(), TextUtils.equals(settingResponse.data.settings.capture_video, String.valueOf(1)));
                        settingItemVideoCatch.setChecked(TextUtils.equals(settingResponse.data.settings.capture_video, String.valueOf(1)));
                    }else{
                        Preferences.saveVideoSwitchState(dev.getSn(), true);
                        settingItemVideoCatch.setChecked(true);
                    }
                }
                return Boolean.TRUE;
            }

            //获取到故事机信息
            case Actions.MachinePlayInfo.NOTIFY_MACHINE_DEVICE_INFO:{
                String sn = (String)args[1];
                String from = (String)args[2];
                if(TextUtils.equals(sn, dev.getSn()) && TextUtils.equals(from, PlayConfig.CmdFrom.SETINGPAGE)){
                    machineDeviceInfo = (MachineDeviceInfo)args[0];
                    //检测固件是否有升级
                    if(machineDeviceInfo!=null && !TextUtils.isEmpty(machineDeviceInfo.deviceInfo.getSystemVersion()) && !TextUtils.isEmpty(machineDeviceInfo.deviceInfo.getSystemCode())){
                        GlobalManager.getInstance().getCommonManager().checkFMNewVersion(VersionManager.REQUEST_SOURCE_PERSONAL, machineDeviceInfo.deviceInfo.systemVersion, Integer.valueOf(machineDeviceInfo.deviceInfo.systemCode), dev.getSn());
                        updateStoryMachineVersion(machineDeviceInfo.deviceInfo.getSystemVersion());
                    }
                }
                return Boolean.TRUE;
            }

            //获取到故事机固件升级信息
            case Actions.Common.GET_FM_UPGRADE_INFO:{

                int from  = (int)args[0];
                if(from == VersionManager.REQUEST_SOURCE_PERSONAL){
                    Update update = (Update)args[1];
                    dismissProcessDialog();
                    if(update!=null && update.getResult()!=null){
                        UpdateInfo updateInfo = update.getResult();
                        if (updateInfo.getHasNew() == 1) {//有新版本
                            //TODO 弹窗提醒用户进行固件升级
                            versionManager = new VersionManager(this, dev.getSn(), Integer.valueOf(machineDeviceInfo.deviceInfo.systemCode), PlayConfig.CmdFrom.SETINGPAGE, handler);
                            versionManager.showFMUpdateDialog(updateInfo);
                            Preferences.saveFmUp(dev.getSn(), true);
                            Preferences.setFMSystemCode(dev.getSn(), machineDeviceInfo.deviceInfo.systemVersion);
                            GlobalManager.getInstance().getCommonManager().publishAction(Actions.Common.NOTIFY_FM_UPDATE, true);
                            textVersion.setText(machineDeviceInfo.deviceInfo.systemVersion);
                        }else{
                            textVersion.setText(getString(R.string.check_new_version));
                            settingItemFirmwareUpdate.hideRightImage();
                            Preferences.saveFmUp(dev.getSn(), false);
                            Preferences.setFMSystemCode(dev.getSn(), "");
                            GlobalManager.getInstance().getCommonManager().publishAction(Actions.Common.NOTIFY_FM_UPDATE, false);
                            if (isUserCheckNewVersion){
                                CameraToast.show(this, getString(R.string.firmware_newest_tip), Toast.LENGTH_SHORT);
                            }

                        }
                    }else{
                        CameraToast.show(getString(R.string.get_deviceInfo_failed), Toast.LENGTH_SHORT);
                    }
                }
                return Boolean.TRUE;
            }

            //固件升级的回复push
            case Actions.MachinePlayInfo.NOTIFY_GET_UPGRADE_RECEIPT:{
                String from = (String)args[2];
                String sn = (String)args[1];
                if(!TextUtils.isEmpty(from) && !TextUtils.isEmpty(sn) && TextUtils.equals(from, PlayConfig.CmdFrom.SETINGPAGE) && TextUtils.equals(sn, dev.getSn())){
                    UpgradeReceipt upgradeReceipt = (UpgradeReceipt) args[0];
                    if(upgradeReceipt!=null){

                        switch(upgradeReceipt.resultCode){
                            case 0:  //TODO 刷机成功
                                if(versionManager!=null){
                                    versionManager.setUpdateSuccess(new VersionManager.SuccessCallBackInterface() {
                                        @Override
                                        public void updateSuccessCallBack() {
                                            CameraToast.show(MachineSettingActivity.this, getString(R.string.machine_fm_upgrade_success), Toast.LENGTH_SHORT);
                                            Preferences.saveFmUp(dev.getSn(), false);
                                            //清除new
                                            settingItemFirmwareUpdate.hideRightImage();
                                            //TODO  通知个人中心页修改有无固件更新的提醒状态
                                            GlobalManager.getInstance().getCommonManager().publishAction(Actions.Common.NOTIFY_FM_UPDATE, false);
                                        }
                                    });
                                }
                                break;

                            case 1:  //TODO 刷机失败，已经回退到出厂版本
                                if(versionManager!=null){
                                    versionManager.closeFmLoadingDialog();
                                }
                                CameraToast.show(this, "刷机失败，已经回退到出厂版本", Toast.LENGTH_SHORT);
                                break;

                            case 2:  //TODO 电池电量不足，取消刷机
                                if(versionManager!=null){
                                    versionManager.closeFmLoadingDialog();
                                }
                                CameraToast.show(this, getString(R.string.machine_fm_upgrade_no_power), Toast.LENGTH_SHORT);
                                break;
                        }
                    }
                }
                return Boolean.TRUE;
            }

        }
        return null;
    }

    private void refreshView(String url) {
        mBabyNameTv.setText(mBabyInfoEntity.babyname);
        if (mBabyInfoEntity.babysex != -1) {
            mBabySexTv.setText(mBabyInfoEntity.babysex == 0 ? getString(R.string.baby_sex_male) : getString(R.string.baby_sex_female));
        } else {
            mBabySexTv.setText(getString(R.string.tips_56));
        }

        mBabyBirthTv.setText(Utils.DATE_FORMAT_5.format(mBabyInfoEntity.babybirth * 1000));
        mBabyAgeTv.setText(PhoneUtil.formatSecond(this, mBabyInfoEntity.babybirth * 1000));
        if (mRelationInfoEntity == null) {
            mRelationInfoEntity = new RelationInfoEntity(mSelect, Constants.TAG_LIST.get(mSelect));
        }
        if (mRelationInfoEntity.relation_tag == 8) {
            Constants.TAG_LIST.remove(8);
            Constants.TAG_LIST.add(mRelationInfoEntity.relation_title);
        }
        if (dev.getRole() == 1) {
            mRelaxTv.setText(TextUtils.isEmpty(mRelationInfoEntity.relation_title) || mBabyInfoEntity.babysex == -1 ? getString(R.string.baby_relax_unset) : mRelationInfoEntity.relation_title);
        } else {
            mRelaxTv.setText(TextUtils.isEmpty(mRelationInfoEntity.relation_title) ? getString(R.string.baby_relax_unset) : mRelationInfoEntity.relation_title);
        }
        CLog.e("camera_setting", url);

        Glide.with(MachineSettingActivity.this)
                .load(url)
                .transform(new GlideCircleTransform(Utils.context))
                .centerCrop()
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .placeholder(R.drawable.icon_avator_empty)
                .into(mAvatorIv);

    }

    @Override
    public int getProperty() {
        return 0;
    }

    public String getSn() {
        return dev.getSn();
    }

    private void showInviteFriend() {
        // 平板加平板
        Intent intent = new Intent(this, BindDeviceFrameActivity.class);
        intent.putExtra("mode", BindDeviceFrameActivity.MODE_FRIEND_FIND);
        intent.putExtra("sn", dev.getSn());
        startActivity(intent);
    }

    private void showBindPhone() {
        // 手机号直接绑定
        Intent intent = new Intent(this, BindDeviceFrameActivity.class);
        intent.putExtra(StoryMachineConsts.KEY_SET_DEVICE_TYPE,device_type);
        intent.putExtra("mode", BindDeviceFrameActivity.MODE_BIND_PHONE);
        intent.putExtra("sn", dev.getSn());
        startActivity(intent);
    }

    private void sendtoWChat() {
        if (Utils.isNetworkAvailable(this)) {
            GlobalManager.getInstance().getShareManager().asyncShareShare(dev.getSn(), "2", "", Constants.DeviceType.STORYMACHINE);
        } else {
            CameraToast.show(null, R.string.network_disabled, Toast.LENGTH_SHORT);
        }
    }

    public void refreshList() {
        GlobalManager.getInstance().getShareManager().asyncShareGetList(dev.getSn(), "0", "50");
    }


    @Override
    public void onSwitchChange(View v, boolean b) {
    }

    //各种开关设置
    @Override
    public void onSwitchClick(View v, boolean b) {
        switch (v.getId()) {
            //童锁
            case R.id.setting_item_child_lock_switch:
                if(!Utils.isNetworkAvailable(this)){
                    settingItemChildLock.setChecked(!settingItemChildLock.getChecked());
                    CameraToast.show(this, getString(R.string.network_error_toast), Toast.LENGTH_SHORT);
                    return;
                }
                if(isOnline){
                    lockChanged = true;
                    settingItemChildLock.setChecked(b);
                    doLocalSettingCmd(b ? 1 :0, NULLINT, NULLINT);
                }else{
                    settingItemChildLock.setChecked(!settingItemChildLock.getChecked());
                    CameraToast.show(this, getString(R.string.story_machine_offline), Toast.LENGTH_SHORT);
                }
                break;

            //指示灯
            case R.id.setting_item_indicate_light_switch:
                if(!Utils.isNetworkAvailable(this)){
                    settingItemIndicateLight.setChecked(!settingItemIndicateLight.getChecked());
                    CameraToast.show(this, getString(R.string.network_error_toast), Toast.LENGTH_SHORT);
                    return;
                }
                if(isOnline){
                    indicatorChanged = true;
                    settingItemIndicateLight.setChecked(b);
                    doLocalSettingCmd(NULLINT, b ? 1 :0, NULLINT);
                }else{
                    settingItemIndicateLight.setChecked(!settingItemIndicateLight.getChecked());
                    CameraToast.show(this, getString(R.string.story_machine_offline), Toast.LENGTH_SHORT);
                }
                break;

            //小视频抓拍开关
            case R.id.setting_item_video_catch:
                if(!Utils.isNetworkAvailable(this)){
                    CameraToast.show(this, getString(R.string.network_error_toast), Toast.LENGTH_SHORT);
                    return;
                }
                settingItemVideoCatch.setChecked(b);
                //调用设置接口
                JSONObject jo = new JSONObject();
                try {
                    jo.put("capture_video", String.valueOf(b ? 1 : 0));
                    GlobalManager.getInstance().getMachineSettingManager().asynSetMachineVideoCatch(jo.toString(), dev.getSn());
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
        }
    }

    //-------------------------------------------最大音量设置-------------------------------------//
    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {
        CLog.e("zt","在设置中设置最大音量");
        if(!Utils.isNetworkAvailable(this)){
            mVolumeSetting.setProgress(currentVolume);
            CameraToast.show(this, getString(R.string.network_error_toast), Toast.LENGTH_SHORT);
            return;
        }
        if(isOnline){
            volumeChanged = true;
            doLocalSettingCmd(NULLINT, NULLINT, seekBar.getProgress());
        }else{
            mVolumeSetting.setProgress(currentVolume);
            CameraToast.show(this, getString(R.string.story_machine_offline), Toast.LENGTH_SHORT);
        }

    }
    //----------------------------------------------end-------------------------------------------//

    //发送本地设置操作指令,在故事机设置需要设置童锁、指示灯和最大音量
    private void doLocalSettingCmd(int lockType, int ledIndicator, int maxVolume) {

        JSONObject setting = new JSONObject();
        try {
            if (lockType != NULLINT) {
                setting.put("childlock", lockType);
            }
            if (ledIndicator != NULLINT) {
                setting.put("led_indicator", ledIndicator);
            }
            if (maxVolume != NULLINT) {
                setting.put("volume_max", maxVolume);
            }
            TaskExecutor.Execute(new SettingTask(this, dev.getSn(), PlayConfig.CommandType.DOLOCALSETTING, JsonManager.getLocalSetting(setting), handler, PlayConfig.CmdFrom.SETINGPAGE));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    //发送获取本地设置的指令
    private void doGetSetingCmd(){
        TaskExecutor.Execute(new SettingTask(this, dev.getSn(), PlayConfig.CommandType.GETLOCALSETTING, JsonManager.getPlayStatusContent(), handler, PlayConfig.CmdFrom.SETINGPAGE));
    }

    //更新开关状态
    private void handlerLocalSetting(LocalSetting setting){
        if(setting!=null){
            settingItemChildLock.setChecked(setting.localSettings.getChildlock()==1);
            settingItemIndicateLight.setChecked(setting.localSettings.getLed_indicator()==1);
            mVolumeSetting.setProgress(setting.localSettings.getVolume_max());
            currentVolume = setting.localSettings.getVolume_max();
            mVolumnPercent.setText(currentVolume+"%");
            HashMap<String, String> map = new HashMap<>();
            if(mBabyInfoEntity!=null){
                map.put("sex", mBabyInfoEntity.babysex == 0 ? getString(R.string.baby_sex_male) : getString(R.string.baby_sex_female));
                map.put("age", String.valueOf(mBabyInfoEntity.babybirth));
            }
            if(mRelationInfoEntity!=null){
                map.put("identity", mRelationInfoEntity.relation_title);
            }
            if(lockChanged){
                lockChanged = false;
                //打点
                map.put("type","lock");
                map.put("state",settingItemChildLock.getChecked() ? "on" : "off");
                QHStatAgentHelper.doMachineSettingStick(map);
            }
            if(indicatorChanged){
                indicatorChanged = false;
                //打点
                map.put("type","light");
                map.put("state",settingItemIndicateLight.getChecked() ? "on" : "off");
                QHStatAgentHelper.doMachineSettingStick(map);
            }
            if(volumeChanged){
                map.put("type","poweroff");
                map.put("volumeMax", String.valueOf(currentVolume));
                QHStatAgentHelper.doMachineSettingStick(map);
                volumeChanged = false;
            }

        }
    }

    //处理handler消息
    @Override
    protected void doMessage(Message msg) {
        super.doMessage(msg);
        handlerCmdExcept((String)msg.obj, msg.arg1);
    }

    private void handlerCmdExcept(String cmd, int errorCode){
        if(TextUtils.equals(cmd, PlayConfig.CommandType.DOLOCALSETTING)){
            //进行 童锁、指示灯和最大音量设置失败
            if(lockChanged){
                lockChanged = false;
                settingItemChildLock.setChecked(!settingItemChildLock.getChecked());
            }

            if(indicatorChanged){
                indicatorChanged = false;
                settingItemIndicateLight.setChecked(!settingItemIndicateLight.getChecked());
            }

            if(volumeChanged){
                volumeChanged = false;
                mVolumeSetting.setProgress(currentVolume);
            }
            if(errorCode == -20){//故事机离线了
                isOnline = false;
                CameraToast.show(this, getString(R.string.story_machine_offline), Toast.LENGTH_SHORT);
            }else{
                CameraToast.show(this, getString(R.string.tips_39), Toast.LENGTH_SHORT);
            }
        }else if(TextUtils.equals(cmd, PlayConfig.CommandType.GETLOCALSETTING)){
            //从服务端获取设置失败，不需要处理
            if(errorCode == -20){//故事机离线了
                isOnline = false;
            }
        }else if(TextUtils.equals(cmd, PlayConfig.CommandType.NOTIFYFMUPGRADE)){
            //TODO 固件升级失败
            if(versionManager!=null){
                versionManager.closeFmLoadingDialog();
                versionManager.showFailedDialog();
            }
        }else if(TextUtils.equals(cmd, PlayConfig.CommandType.GETDEVICEINFO)){
            dismissProcessDialog();
            CameraToast.show(getString(R.string.get_deviceInfo_failed), Toast.LENGTH_SHORT);
        }
    }

    /**
     * 获取故事机信息
     */
    private void doGetDeviceInfo(){
        TaskExecutor.Execute(new SettingTask(this, dev.getSn(), PlayConfig.CommandType.GETDEVICEINFO, JsonManager.getPlayStatusContent(), handler, PlayConfig.CmdFrom.SETINGPAGE));
    }

    /**
     * 更新故事机版本号
     * @param version
     */
    private void updateStoryMachineVersion(String version){
        tvStoryMachineVersion.setVisibility(View.VISIBLE);
        tvStoryMachineVersion.setText(getApplicationContext().getResources().getString(R.string.story_machine_info_tip)+ version);
    }

    /**
     * 加载数据库中的故事机信息
     */
    private void loadMachineDeviceInfoFromDB() {
        //先加载数据库的信息
        Single.create(new Single.OnSubscribe<MachineDeviceInfo>() {
            @Override
            public void call(SingleSubscriber<? super MachineDeviceInfo> singleSubscriber) {
                try {
                    MachineDeviceInfo deviceInfo = CommonWrapper.getInstance(MachineSettingActivity.this).getLocalToClazz(dev.getSn(), CommonWrapper.TYPE_MACHINE_DEVICE_INFO, MachineDeviceInfo.class);
                    singleSubscriber.onSuccess(deviceInfo);
                } catch (java.lang.InstantiationException e) {
                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        }).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Action1<MachineDeviceInfo>() {
                    @Override
                    public void call(MachineDeviceInfo deviceInfo) {
                        if (deviceInfo != null) {
                            updateStoryMachineVersion(deviceInfo.deviceInfo.systemVersion);
                        } else {
                            tvStoryMachineVersion.setVisibility(View.GONE);
                        }
                    }
                });
    }

    /**
     * 连接wifi
     */
    private void reconnectWifi() {
        if (NetUtil.isNetworkAvailable(MachineSettingActivity.this) &&
                NetUtil.getNetworkState(MachineSettingActivity.this) == NetUtil.NETWORN_WIFI) {
            Intent intentWifi = new Intent(MachineSettingActivity.this, SetupGuideActivity.class);
            intentWifi.putExtra(StoryMachineConsts.KEY_SET_WIFI_FROM, StoryMachineConsts.VALUE_SET_WIFI_FROM_WIFI);
            startActivity(intentWifi);
        } else {
            Toast.makeText(MachineSettingActivity.this, MachineSettingActivity.this.getResources()
                    .getString(R.string.no_network_config_wifi_failed), Toast.LENGTH_SHORT).show();
        }

    }


}
