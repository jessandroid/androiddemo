package com.qihoo360.homecamera.mobile.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.db.PadInfoWrapper;
import com.qihoo360.homecamera.mobile.db.PhoneRecordWrapper;
import com.qihoo360.homecamera.mobile.entity.DeviceInfo;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.Preferences;
import com.qihoo360.homecamera.mobile.utils.Utils;

/**
 * Created by hyuan on 2016/9/5.
 */
public class DeleteDeviceActivity  extends BaseActivity implements View.OnClickListener, ActionListener {
    private static final String url = "http://kibot.360.cn/mobile/app/restore.html";
    public static boolean DO_UNBIND = false;

    private TextView mTitleTxtView;
    private ImageView mBackBtnView;
    private LinearLayout mDeleteDataLayout;
    private LinearLayout mResetRobotLayout;
    private TextView mRestRobotTxtView;
    private Button mDeleteConfirm;
    private ImageView mDeleteCheckBox;
    private ImageView mResetCheckBox;

    private DeviceInfo devInfo;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_del_device);
        initView();
        initListener();
        Intent intent = getIntent();
        devInfo = intent.getParcelableExtra(DeviceInfo.class.getSimpleName());
        DO_UNBIND = false;
    }

    private void initView(){
        mTitleTxtView = (TextView) findViewById(R.id.title_string);
        mTitleTxtView.setText("解除绑定");
        mBackBtnView = (ImageView) findViewById(R.id.back_zone);
        mDeleteDataLayout = (LinearLayout) findViewById(R.id.delete_data_ly);
        mResetRobotLayout = (LinearLayout) findViewById(R.id.reset_robot_ly);
        mRestRobotTxtView = (TextView) findViewById(R.id.reset_robot_txt);
        mDeleteConfirm = (Button) findViewById(R.id.delete_confirm);
        mDeleteCheckBox = (ImageView) findViewById(R.id.delete_button);
        mResetCheckBox = (ImageView) findViewById(R.id.reset_button);
    }

    private void initListener(){
        mBackBtnView.setOnClickListener(this);
        mDeleteDataLayout.setOnClickListener(this);
        mResetRobotLayout.setOnClickListener(this);
        mRestRobotTxtView.setOnClickListener(this);
        mDeleteConfirm.setOnClickListener(this);
        //mDeleteCheckBox.setOnClickListener(this);
        //mResetCheckBox.setOnClickListener(this);
        layoutClick(mDeleteDataLayout);
        GlobalManager.getInstance().getCameraManager().registerActionListener(this);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        GlobalManager.getInstance().getCameraManager().removeActionListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.back_zone: {
                finish();
                break;
            }
            case R.id.delete_button:
            case R.id.delete_data_ly:{
                layoutClick(v);
                break;
            }
            case R.id.reset_button:
            case R.id.reset_robot_ly:{
                layoutClick(v);
                break;
            }
            case R.id.reset_robot_txt:{
                Intent intent1 = new Intent(DeleteDeviceActivity.this, WebViewActivity.class);
                intent1.putExtra("url", url);
                startActivity(intent1);
                break;
            }
            case R.id.delete_confirm:{
                if (devInfo.getRole() == 1) {
                    GlobalManager.getInstance().getCameraManager().asyncLoadUnBindDevice(devInfo.getSn(), mDeleteDataClick ? "1" : "0", "1");
                } else {
                    GlobalManager.getInstance().getShareManager().asyncShareCancel(devInfo.getSn(), devInfo.getQid());
                }
                showTipsDialog(getString(R.string.tips_49), R.drawable.icon_loading, 10000, true);
                break;
            }
        }
    }

    private boolean mDeleteDataClick = false;
    private boolean mResetRobotClick = false;
    private void layoutClick(View v){
        switch (v.getId()) {
            case R.id.delete_data_ly:{
                if (mDeleteDataClick) {
                    mDeleteDataClick = false;
                    mDeleteDataLayout.setBackgroundResource(R.drawable.layout_border_gray);
                    mDeleteCheckBox.setBackgroundResource(R.drawable.icon_check_box);
                } else {
                    mDeleteDataClick = true;
                    mDeleteDataLayout.setBackgroundResource(R.drawable.layout_border_red);
                    mDeleteCheckBox.setBackgroundResource(R.drawable.icon_check_box_pressed);
                }
                break;
            }
            case R.id.reset_robot_ly:{
                if (mResetRobotClick) {
                    mResetRobotClick = false;
                    mResetRobotLayout.setBackgroundResource(R.drawable.layout_border_gray);
                    mResetCheckBox.setBackgroundResource(R.drawable.icon_check_box);
                } else {
                    mResetRobotClick = true;
                    mResetRobotLayout.setBackgroundResource(R.drawable.layout_border_red);
                    mResetCheckBox.setBackgroundResource(R.drawable.icon_check_box_pressed);
                }
                break;
            }
        }
    }

    @Override
    public Object actionPerformed(int actionCode, Object... args) {
        switch (actionCode) {
            case Actions.Camera.UN_BIND_DEVICE_SUCCESS: {
                GlobalManager.getInstance().getPadSettingManager().asyncDelAcl(devInfo.getSn());
                PhoneRecordWrapper.getInstance(DeleteDeviceActivity.this).updatePhoneRecordStateBySn(devInfo.getSn());
                CameraToast.showToast(Utils.context, R.string.unbind_device_suc);
                hideTipsDialog();
                DO_UNBIND = true;
                GlobalManager.getInstance().getCommonManager().publishAction(Actions.Common.EXIT);
                GlobalManager.getInstance().getCommonManager().publishAction(Actions.Common.UNBIND_SUCCESS_UPDATE);
                finish();
                return Boolean.TRUE;
            }
            case Actions.Share.SHARE_CANCEL_SUCCESS: {
                CameraToast.showToast(this, R.string.unbind_device_suc);
                hideTipsDialog();
                if (Preferences.getSelectedPad().equals(devInfo.getSn())) {
                    Preferences.saveSelectedPad("");
                }
                PadInfoWrapper.getInstance().deletePadBySnQid(devInfo.getSn(), AccUtil.getInstance().getQID());
                GlobalManager.getInstance().getPadSettingManager().asyncDelAcl(devInfo.getSn());
                GlobalManager.getInstance().getCameraManager().asyncLoadMyCamera(0);
                GlobalManager.getInstance().getCameraManager().publishAction(Actions.Camera.CAMERA_LIST_ACTION);
                GlobalManager.getInstance().getCameraManager().publishAction(Actions.Camera.DELTET_SN, devInfo.getSn());
                DO_UNBIND = true;
                GlobalManager.getInstance().getCommonManager().publishAction(Actions.Common.EXIT);
                finish();
                return Boolean.TRUE;
            }
            case Actions.Camera.UN_BIND_DEVICE_FAIL: {
                CameraToast.showToast(Utils.context, R.string.unbind_device_fail);
                hideTipsDialog();
                DO_UNBIND = false;
                return Boolean.TRUE;
            }
            case Actions.Share.SHARE_CANCEL_FAIL: {
                CameraToast.showErrorToast(this, R.string.unbind_device_fail);
                hideTipsDialog();
                DO_UNBIND = false;
                return Boolean.TRUE;
            }
        }
        return null;
    }

    @Override
    public int getProperty() {
        return 0;
    }
}
