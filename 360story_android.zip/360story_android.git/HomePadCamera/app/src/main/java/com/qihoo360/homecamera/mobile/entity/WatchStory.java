package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

/**
 * Created by zhaojunbo on 2016/3/28.
 * desc:
 */
public class WatchStory extends Head {

    public int total;
    public ArrayList<Data> data;

    public static class Data implements Parcelable {
        public String id;
        public String name;
        public String coverUrl;
        public String listCoverUrl;
        public String duration;
        public String size;
        public String videoUrl;
        public String intro;
        public String weight;
        public String from;
        public String recordTime;
        public String createTime ;

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(this.id);
            dest.writeString(this.name);
            dest.writeString(this.coverUrl);
            dest.writeString(this.listCoverUrl);
            dest.writeString(this.duration);
            dest.writeString(this.size);
            dest.writeString(this.videoUrl);
            dest.writeString(this.intro);
            dest.writeString(this.weight);
            dest.writeString(this.from);
            dest.writeString(this.recordTime);
            dest.writeString(this.createTime);
        }

        public Data() {
        }

        protected Data(Parcel in) {
            this.id = in.readString();
            this.name = in.readString();
            this.coverUrl = in.readString();
            this.listCoverUrl = in.readString();
            this.duration = in.readString();
            this.size = in.readString();
            this.videoUrl = in.readString();
            this.intro = in.readString();
            this.weight = in.readString();
            this.from = in.readString();
            this.recordTime = in.readString();
            this.createTime = in.readString();
        }

        public static final Creator<Data> CREATOR = new Creator<Data>() {
            @Override
            public Data createFromParcel(Parcel source) {
                return new Data(source);
            }

            @Override
            public Data[] newArray(int size) {
                return new Data[size];
            }
        };
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.total);
        dest.writeTypedList(data);
    }

    public WatchStory() {
    }

    protected WatchStory(Parcel in) {
        this.total = in.readInt();
        this.data = in.createTypedArrayList(Data.CREATOR);
    }

    public static final Creator<WatchStory> CREATOR = new Creator<WatchStory>() {
        @Override
        public WatchStory createFromParcel(Parcel source) {
            return new WatchStory(source);
        }

        @Override
        public WatchStory[] newArray(int size) {
            return new WatchStory[size];
        }
    };
}

