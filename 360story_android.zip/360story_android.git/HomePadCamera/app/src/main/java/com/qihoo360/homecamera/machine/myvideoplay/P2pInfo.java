package com.qihoo360.homecamera.machine.myvideoplay;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

public class P2pInfo implements Parcelable{
    public String ip;
    public String ukey;
    public String playKey;
    public int port = 80;

    protected P2pInfo(Parcel in) {
        ip = in.readString();
        ukey = in.readString();
        playKey = in.readString();
        port = in.readInt();
    }

    public static final Creator<P2pInfo> CREATOR = new Creator<P2pInfo>() {
        @Override
        public P2pInfo createFromParcel(Parcel in) {
            return new P2pInfo(in);
        }

        @Override
        public P2pInfo[] newArray(int size) {
            return new P2pInfo[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(ip);
        dest.writeString(ukey);
        dest.writeString(playKey);
        dest.writeInt(port);
    }
}
