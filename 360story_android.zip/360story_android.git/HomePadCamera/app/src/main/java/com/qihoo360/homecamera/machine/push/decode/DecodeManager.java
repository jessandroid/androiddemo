package com.qihoo360.homecamera.machine.push.decode;

/**
 * 解密工具
 * @author zhangchao-pd
 *
 */
public class DecodeManager {
	
	/**
	 * base64解密工具
	 */
	private DecodeBase64 mDecodeBase64 = new DecodeBase64();
	
	/**
	 * AES解密工具
	 */
	private DecodeAES mDecodeAES = new DecodeAES();
	
	/**
	 * AES解密密钥
	 */
	private String mSecretKey = "";
	
	/**
	 * AES解密向量参数
	 */
	private String mIVParam = "";
	
	public void setSecretKey(String secretKey) {
		mSecretKey = secretKey;
	}
	
	public void setIVParam(String ivParam) {
		mIVParam = ivParam;
	}
	
	/**
	 * 解密
	 * @param encodeContent
	 * @return
	 */
	public String decode(String encodeContent) {
		
		String decodeContent = null;
		
		try {

			// base64解密
			byte[] decodeBase64 = mDecodeBase64.decode(encodeContent);
			
			// aes解密
			decodeContent = mDecodeAES.decode(mSecretKey, decodeBase64, mIVParam);

		} catch(Exception e) {
		}
		
		return decodeContent;
	}
}
