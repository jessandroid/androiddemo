package com.qihoo360.homecamera.mobile.image.my;

import android.app.ActivityManager;
import android.content.Context;

import com.bumptech.glide.Glide;
import com.bumptech.glide.GlideBuilder;
import com.bumptech.glide.load.engine.bitmap_recycle.LruBitmapPool;
import com.bumptech.glide.load.engine.cache.DiskCache;
import com.bumptech.glide.load.engine.cache.DiskLruCacheWrapper;
import com.bumptech.glide.load.engine.cache.LruResourceCache;
import com.bumptech.glide.load.engine.cache.MemorySizeCalculator;
import com.bumptech.glide.load.model.GlideUrl;
import com.bumptech.glide.module.GlideModule;
import com.bumptech.glide.request.target.ViewTarget;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.io.File;
import java.io.InputStream;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/2/17
 * Time: 16:03
 * To change this template use File | Settings | File Templates.
 */
public class MyGlideModule implements GlideModule {


    private int inMemoryCacheSize;

    @Override
    public void applyOptions(final Context context, GlideBuilder builder) {
        ViewTarget.setTagId(R.id.glide_tag_id); // 设置别的get/set tag id，以免占用View默认的
        ActivityManager mActivityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        MemorySizeCalculator calculator = new MemorySizeCalculator(Utils.context);

        int defaultMemoryCacheSize = calculator.getMemoryCacheSize();
        int defaultBitmapPoolSize = calculator.getBitmapPoolSize();


        int customMemoryCacheSize = (int) (1.2 * defaultMemoryCacheSize);
        int customBitmapPoolSize = (int) (1.2 * defaultBitmapPoolSize);

        int heapLimitMB = mActivityManager.getMemoryClass();


        if (heapLimitMB >= 128) {
            inMemoryCacheSize = 10 * 1024 * 1024;
        } else if (heapLimitMB >= 64) {
            inMemoryCacheSize = 5 * 1024 * 1024;
        } else {
            inMemoryCacheSize = 1 * 1024 * 1024;
        }

        StringBuffer sb = new StringBuffer();
        sb.append("defaultMemoryCacheSize:").append(defaultMemoryCacheSize).append("\n   defaultBitmapPoolSize:").append(defaultBitmapPoolSize)
                .append("\n customMemoryCacheSize:").append(customMemoryCacheSize).append("\n customBitmapPoolSize:").append(customBitmapPoolSize)
                .append("\n heapLimitMB:").append(heapLimitMB).append("\n inMemoryCacheSize:").append(inMemoryCacheSize);

        CLog.d(sb.toString());


        builder.setMemoryCache(new LruResourceCache(customMemoryCacheSize));
        builder.setBitmapPool(new LruBitmapPool(customBitmapPoolSize));

        builder.setDiskCache(new DiskCache.Factory() {
            @Override
            public DiskCache build() {
                File cacheLocation = new File(context.getExternalCacheDir(), ".cache_dir_name");
                cacheLocation.mkdirs();
                DiskCache diskCache = DiskLruCacheWrapper.get(cacheLocation, 20 * 1024 * 1024);
                return diskCache;
            }
        });
    }

    @Override
    public void registerComponents(Context context, Glide glide) {
        glide.register(GlideUrl.class, InputStream.class, new OkHttpsUrlLoader.Factory());
    }

}
