
package com.qihoo360.homecamera.mobile.db;

import android.annotation.SuppressLint;
import android.database.AbstractCursor;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.provider.MediaStore.Images.ImageColumns;
import android.provider.MediaStore.MediaColumns;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class CombinedDateSortedCursor extends AbstractCursor {
    public final static String[] PROJECTION = new String[] {
            MediaColumns._ID, MediaColumns.DATE_ADDED, MediaColumns.DATA, MediaColumns.DISPLAY_NAME, MediaColumns.MIME_TYPE, MediaColumns.TITLE, ImageColumns.BUCKET_ID,
            ImageColumns.BUCKET_DISPLAY_NAME, ImageColumns.DATE_TAKEN, ImageColumns.SIZE
    };

    public final static class ColumnIndex {
        public final static int ID = 0;
        public final static int DATE_ADDED = 1;
        public final static int DATA = 2;
        public final static int DISPLAY_NAME = 3;
        public final static int MIME_TYPE = 4;
        public final static int TITLE = 5;
        public final static int BUCKET_ID = 6;
        public final static int BUCKET_DISPLAY_NAME = 7;
        public final static int DATE_TAKEN = 8;
        public final static int SIZE = 9;
    }

    private final int mDateColumnIndex;
    private ArrayList<CursorPositionInfo> mPositionInfo;
    private final Cursor[] mCursors;
    private Cursor mCursor;

    /**
     * 
     * @param cursors
     * @param dateColumnIndex Column index of the date field in cursor.
     */
    public CombinedDateSortedCursor(Cursor[] cursors, int dateColumnIndex) {
        mCursors = cursors;
        mDateColumnIndex = dateColumnIndex;
        for (int i = 0; i < mCursors.length; i++) {
            if (mCursors[i] == null)
                continue;
            mCursors[i].registerDataSetObserver(mObserver);
        }
        updatePositionInfo();
    }

    private final void updatePositionInfo() {
        final ArrayList<CursorPositionInfo> sortInfoList = new ArrayList<CursorPositionInfo>(getCount());
        for (int i = 0; i < mCursors.length; i++) {
            final Cursor cursor = mCursors[i];
            cursor.moveToPosition(-1);
            while (cursor.moveToNext() == true) {
                sortInfoList.add(new CursorPositionInfo(cursor.getLong(mDateColumnIndex), cursor, cursor.getPosition()));
            }
            cursor.moveToPosition(-1);
        }
        Collections.sort(sortInfoList, DATE_COMPARATOR);
        mPositionInfo = sortInfoList;

        // set default cursor to point at the first cursor. Some method may be called before invoking first move.
        if (sortInfoList.size() > 0) {
            mCursor = sortInfoList.get(0).cursor;
        }
        mCursor.close();
    }

    @Override
    public boolean onMove(int oldPosition, int newPosition) {
        if (newPosition >= mPositionInfo.size()) {
            return false;
        }
        final CursorPositionInfo info = mPositionInfo.get(newPosition);
        mCursor = info.cursor;
        mCursor.moveToPosition(info.positionInCursor);
        return true;
    }

    @Override
    public int getCount() {
        int count = 0;
        int length = mCursors.length;
        for (int i = 0; i < length; i++) {
            if (mCursors[i] != null) {
                count += mCursors[i].getCount();
            }
        }
        return count;
    }

    @Override
    public String getString(int column) {
        return mCursor.getString(column);
    }

    @Override
    public short getShort(int column) {
        return mCursor.getShort(column);
    }

    @Override
    public int getInt(int column) {
        return mCursor.getInt(column);
    }

    @Override
    public long getLong(int column) {
        return mCursor.getLong(column);
    }

    @Override
    public float getFloat(int column) {
        return mCursor.getFloat(column);
    }

    @Override
    public double getDouble(int column) {
        return mCursor.getDouble(column);
    }

    @SuppressLint("NewApi")
    @Override
    public int getType(int column) {
        return mCursor.getType(column);
    }

    @Override
    public boolean isNull(int column) {
        return mCursor.isNull(column);
    }

    @Override
    public byte[] getBlob(int column) {
        return mCursor.getBlob(column);
    }

    @Override
    public String[] getColumnNames() {
        if (mCursor != null) {
            return mCursor.getColumnNames();
        } else {
            return new String[0];
        }
    }

    @Override
    public void deactivate() {
        int length = mCursors.length;
        for (int i = 0; i < length; i++) {
            if (mCursors[i] != null) {
                mCursors[i].deactivate();
            }
        }
        super.deactivate();
    }

    @Override
    public void close() {
        int length = mCursors.length;
        for (int i = 0; i < length; i++) {
            if (mCursors[i] == null)
                continue;
            mCursors[i].close();
        }
        super.close();
    }

    @Override
    public void registerContentObserver(ContentObserver observer) {
        int length = mCursors.length;
        for (int i = 0; i < length; i++) {
            if (mCursors[i] != null) {
                mCursors[i].registerContentObserver(observer);
            }
        }
    }

    @Override
    public void unregisterContentObserver(ContentObserver observer) {
        int length = mCursors.length;
        for (int i = 0; i < length; i++) {
            if (mCursors[i] != null) {
                mCursors[i].unregisterContentObserver(observer);
            }
        }
    }

    @Override
    public void registerDataSetObserver(DataSetObserver observer) {
        int length = mCursors.length;
        for (int i = 0; i < length; i++) {
            if (mCursors[i] != null) {
                mCursors[i].registerDataSetObserver(observer);
            }
        }
    }

    @Override
    public void unregisterDataSetObserver(DataSetObserver observer) {
        int length = mCursors.length;
        for (int i = 0; i < length; i++) {
            if (mCursors[i] != null) {
                mCursors[i].unregisterDataSetObserver(observer);
            }
        }
    }

    @SuppressWarnings("deprecation")
    @Override
    public boolean requery() {
        int length = mCursors.length;
        for (int i = 0; i < length; i++) {
            if (mCursors[i] == null) {
                continue;
            }

            if (mCursors[i].requery() == false) {
                return false;
            }
        }

        return true;
    }

    private final DataSetObserver mObserver = new DataSetObserver() {

        @Override
        public void onChanged() {
            mPos = -1;
        }

        @Override
        public void onInvalidated() {
            mPos = -1;
        }
    };

    private static class CursorPositionInfo {
        final long date;
        final Cursor cursor;
        final int positionInCursor;

        CursorPositionInfo(long date, Cursor cursor, int positionInCursor) {
            this.date = date;
            this.cursor = cursor;
            this.positionInCursor = positionInCursor;
        }
    }

    private static Comparator<CursorPositionInfo> DATE_COMPARATOR = new Comparator<CursorPositionInfo>() {

        @Override
        public int compare(CursorPositionInfo lhs, CursorPositionInfo rhs) {
            int compare = (int) (lhs.date - rhs.date);
            return -compare;
        }
    };
}
