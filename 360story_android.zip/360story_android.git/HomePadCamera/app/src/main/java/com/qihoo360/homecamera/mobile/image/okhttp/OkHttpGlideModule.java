package com.qihoo360.homecamera.mobile.image.okhttp;

import android.app.ActivityManager;
import android.content.Context;

import com.bumptech.glide.Glide;
import com.bumptech.glide.GlideBuilder;
import com.bumptech.glide.load.DecodeFormat;
import com.bumptech.glide.load.engine.cache.DiskCache;
import com.bumptech.glide.load.engine.cache.DiskLruCacheWrapper;
import com.bumptech.glide.load.engine.cache.LruResourceCache;
import com.bumptech.glide.load.model.GlideUrl;
import com.bumptech.glide.module.GlideModule;
import com.bumptech.glide.request.target.ViewTarget;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.image.listener.GlideProgressListener;

import java.io.File;
import java.io.InputStream;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/3/3
 * Time: 10:40
 * To change this template use File | Settings | File Templates.
 */
public class OkHttpGlideModule implements GlideModule {


    private int inMemoryCacheSize;

    @Override
    public void applyOptions(final Context context, GlideBuilder builder) {
        ViewTarget.setTagId(R.id.glide_tag_id); // 设置别的get/set tag id，以免占用View默认的
        builder.setDecodeFormat(DecodeFormat.PREFER_RGB_565); // 设置图片质量为高质量
        ActivityManager mActivityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        int heapLimitMB = mActivityManager.getMemoryClass();
        if (heapLimitMB >= 128) {
            inMemoryCacheSize = 10 * 1024 * 1024;
        } else if (heapLimitMB >= 64) {
            inMemoryCacheSize = 5 * 1024 * 1024;
        } else {
            inMemoryCacheSize = 1 * 1024 * 1024;
        }
        builder.setMemoryCache(new LruResourceCache(inMemoryCacheSize));
        builder.setDiskCache(new DiskCache.Factory() {
            @Override
            public DiskCache build() {
                File cacheLocation = new File(context.getExternalCacheDir(), ".cache_dir_name");
                cacheLocation.mkdirs();
                if (context.getExternalCacheDir().isFile()) {
                    context.getExternalCacheDir().delete();
                }
                cacheLocation.mkdirs();
                return DiskLruCacheWrapper.get(cacheLocation, 20 * 1024 * 1024);
            }
        });
    }

    @Override
    public void registerComponents(Context context, Glide glide) {
        glide.register(GlideUrl.class, InputStream.class, new OkHttpUrlLoader.Factory(GlideProgressListener.getGlideOkHttpClient()));

    }

}
