
package com.qihoo360.homecamera.mobile.manager;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;

import com.justalk.cloud.lemon.MtcApi;
import com.justalk.cloud.lemon.MtcCli;
import com.justalk.cloud.lemon.MtcCliConstants;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.qihoo360.homecamera.machine.manager.AppServerManager;
import com.qihoo360.homecamera.machine.manager.MachineManager;
import com.qihoo360.homecamera.machine.manager.MachineSettingManager;
import com.qihoo360.homecamera.machine.net.CameraHttpApi;
import com.qihoo360.homecamera.mobile.activity.RuntimeConfig;
import com.qihoo360.homecamera.mobile.config.DefaultClientConfig;
import com.qihoo360.homecamera.mobile.core.util.Stoppable;
import com.qihoo360.homecamera.mobile.db.AppUpdateWrapper;
import com.qihoo360.homecamera.mobile.db.CommandMessageWraper;
import com.qihoo360.homecamera.mobile.db.CommonWrapper;
import com.qihoo360.homecamera.mobile.db.FamilyGroupWrapper;
import com.qihoo360.homecamera.mobile.db.FileUploadWrapper;
import com.qihoo360.homecamera.mobile.db.LocalDB;
import com.qihoo360.homecamera.mobile.db.MachineSongWrapper;
import com.qihoo360.homecamera.mobile.db.PadInfoWrapper;
import com.qihoo360.homecamera.mobile.db.StoryAndVideoCacheWrapper;
import com.qihoo360.homecamera.mobile.db.StoryCacheWrapper;
import com.qihoo360.homecamera.mobile.db.StoryDownLoadWrapper;
import com.qihoo360.homecamera.mobile.db.UserWrapper;
import com.qihoo360.homecamera.mobile.http.OkHttpUtils;
import com.qihoo360.homecamera.mobile.service.JustalkService;
import com.qihoo360.homecamera.mobile.service.MyJobService;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CompatibilitySupport;
import com.qihoo360.homecamera.mobile.utils.FileUtil;
import com.qihoo360.homecamera.mobile.utils.Preferences;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.utils.imageloader.CameraLoggedInUserImageDownloader;
import com.qihoo360.homecamera.mobile.utils.imageloader.ImageLoaderHelper;
import com.qihoo360.homecamera.mobile.utils.share.ShareToWeChatAndWeibo;

import java.io.File;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/1/11
 * Time: 15:56
 * To change this template use File | Settings | File Templates.
 */
public class GlobalManager implements Stoppable {

    private final static String TAG = "GlobalManager";

    private static GlobalManager sInstance;
    private CameraManager cameraManager;
    private UserInfoManager userInfoManager;
    private ShareManager shareManager;
    private NeverKillManager neverKillManager;
    private PushManager pushManager;
    private AlbumManager albumManager;
    private SearchWordManager searchWordManager;
    private StoryManager storymanager;
    private CommonManager commonManager;
    private CommandMessageManager commandMessageManager;
	private MachineSettingManager machineSettingManager;    
	private boolean mIsStopped = false;
    private static final String Tag = GlobalManager.class.getSimpleName();
    private static Application sContext;
    private static AccUtil accUtil;
    private RuntimeConfig mRuntimeConfig;
    private LocalManager mLocalManager;
//    private ApplicationManager applicationManager;
    private ShareToWeChatAndWeibo shareToWeChatAndWeibo;
    private PadSettingManager mPadSettingManager;
    private MachineManager machineManager;
    private AppServerManager mAppServerManager;

    private GlobalManager() {
        mRuntimeConfig = new RuntimeConfig();
    }

    public RuntimeConfig config() {
        return mRuntimeConfig;
    }

    public static GlobalManager getInstance() {
        if (sInstance == null) {
            synchronized (GlobalManager.class) {
                if (sInstance == null) {
                    sInstance = new GlobalManager();
                }
            }
        }
        return sInstance;
    }

    public void initDB() {
        mRuntimeConfig.db.addWrapper(UserWrapper.getInstance(sContext));
        mRuntimeConfig.db.addWrapper(FileUploadWrapper.getInstance());
        mRuntimeConfig.db.addWrapper(StoryDownLoadWrapper.getInstance());
        mRuntimeConfig.db.addWrapper(StoryCacheWrapper.getInstance());
        mRuntimeConfig.db.addWrapper(AppUpdateWrapper.getInstance());
        mRuntimeConfig.db.addWrapper(PadInfoWrapper.getInstance());
        mRuntimeConfig.db.addWrapper(StoryAndVideoCacheWrapper.getInstance());
        mRuntimeConfig.db.addWrapper(CommonWrapper.getInstance(sContext));
        mRuntimeConfig.db.addWrapper(CommandMessageWraper.getInstance());
        mRuntimeConfig.db.addWrapper(MachineSongWrapper.getInstance());
        mRuntimeConfig.db.addWrapper(FamilyGroupWrapper.getInstance());
        // TODO FileWrapper
        //mRuntimeConfig.db.addWrapper(FileWrapper.getInstance(sContext));
    }

    @SuppressWarnings("static-access")
    public static void imageLoaderAutoInit(Context context) {
        File ImageLoadCache = FileUtil.getInstance().getmSDCacheDir();
        if (!ImageLoader.getInstance().isInited()) {
            CameraLoggedInUserImageDownloader loader = new CameraLoggedInUserImageDownloader(
                    context.getApplicationContext());
            ImageLoaderHelper.setUpImageLoader(context, ImageLoadCache, null, loader, loader);
        }
    }

    public void init(Application app) {
        sContext = app;
        accUtil = AccUtil.getInstance();
        String qid = accUtil.getQID();
        imageLoaderAutoInit(sContext);
        if (!TextUtils.isEmpty(qid)) {
            GlobalManager.getInstance().login();
            initDB();
        }
    }

//    public ApplicationManager applicationManager() {
//        if (null == applicationManager) {
//            applicationManager = new ApplicationManager();
//        }
//        return applicationManager;
//    }

    public CameraManager getCameraManager() {
        if (cameraManager == null) {
            cameraManager = new CameraManager((Application) Utils.getContext());
        }
        return cameraManager;
    }

    public PadSettingManager getPadSettingManager() {
        if (mPadSettingManager == null) {
            mPadSettingManager = new PadSettingManager((Application) Utils.getContext());
        }
        return mPadSettingManager;
    }

    public UserInfoManager getUserInfoManager() {
        if (userInfoManager == null) {
            userInfoManager = new UserInfoManager((Application) Utils.getContext());
        }
        return userInfoManager;
    }

    public ShareManager getShareManager() {
        if (shareManager == null) {
            shareManager = new ShareManager((Application) Utils.getContext());
        }
        return shareManager;
    }

    public NeverKillManager getNeverKillManager() {
        if (neverKillManager == null) {
            neverKillManager = new NeverKillManager((Application) Utils.getContext());
        }
        return neverKillManager;
    }

    public PushManager getPushManager() {
        if (pushManager == null) {
            pushManager = new PushManager((Application) Utils.getContext());
        }
        return pushManager;
    }

    public AlbumManager getAlbumManager() {
        if (albumManager == null) {
            albumManager = new AlbumManager((Application) Utils.getContext());
        }
        return albumManager;
    }

    public SearchWordManager getSearchWordManager() {
        if (searchWordManager == null) {
            searchWordManager = new SearchWordManager((Application) Utils.getContext());
        }
        return searchWordManager;
    }

    public CommonManager getCommonManager() {
        if (commonManager == null) {
            commonManager = new CommonManager((Application) Utils.getContext());
        }
        return commonManager;
    }

    public StoryManager getStorymanager() {
        if (storymanager == null) {
            storymanager = new StoryManager((Application) Utils.getContext());
        }
        return storymanager;
    }

    public CommandMessageManager getCommandMessageManager() {
        if (commandMessageManager == null) {
            commandMessageManager = new CommandMessageManager((Application) Utils.getContext());
        }
        return commandMessageManager;
    }

    public MachineManager getMachineManager() {
        if(machineManager == null) {
            machineManager = new MachineManager();
        }
        return machineManager;
    }

    private final Stoppable[] getStoppable() {
        return Utils.asArray(cameraManager, userInfoManager, shareManager, neverKillManager,
                albumManager, searchWordManager, storymanager, commonManager);
    }

    public void initDatabase() {
        CLog.d(TAG, "----initDatabase----");
        if (accUtil != null) {
            RuntimeConfig config = mRuntimeConfig;
            LocalDB.destroyLocalDB();
            config.db = LocalDB.getInstances(sContext, AccUtil.getInstance().getQID() + DefaultClientConfig.DB_Prefix);

            CLog.d(TAG, "----initDatabase----db = " + config.db);
        }
    }

    public void login() {
        setUnStopped();
        initDatabase();
        initConfig();
        getCameraManager();
        getUserInfoManager();
        getShareManager();
        getNeverKillManager();
        getAlbumManager();
        getSearchWordManager();
        getCommonManager();
        getStorymanager();
        getShareToWeChatAndWeibo();
    }

    private void initConfig() {
        mRuntimeConfig.cameraHttpApi = new CameraHttpApi(false);
        mRuntimeConfig.cameraHttpsApi = new CameraHttpApi();
        mRuntimeConfig.liveHttpsApi = new CameraHttpApi();
    }

    public ShareToWeChatAndWeibo getShareToWeChatAndWeibo() {
        if (shareToWeChatAndWeibo == null) {
            shareToWeChatAndWeibo = new ShareToWeChatAndWeibo(sContext);
        }
        return shareToWeChatAndWeibo;
    }

    @Override
    public void stopNow() {
        CLog.d(Tag, "############## Stopping GlobalManager.");
        mIsStopped = true;
        for (Stoppable stoppable : getStoppable()) {
            try {
                if (stoppable != null) {
                    CLog.d(Tag, "Stopping " + stoppable.getClass().getName());
                    stoppable.stopNow();
                }
            } catch (Throwable e) {
                e.printStackTrace();
            }
        }
        CLog.d(Tag, "############## GlobalManager Stopped");

    }

    @Override
    public boolean isStopped() {
        return mIsStopped;
    }

    public void setUnStopped() {
        mIsStopped = false;
    }

    @Override
    public void destroyNow() {
        CLog.d(Tag, "############## Destroying GlobalManager.");
        mIsStopped = true;
        for (Stoppable stoppable : getStoppable()) {
            try {
                if (stoppable != null) {
                    CLog.d(Tag, "Destroying " + stoppable.getClass().getName());
                    if (isStopped()) {
                        stoppable.destroyNow();
                    }
                }
            } catch (Throwable e) {
                e.printStackTrace();
            }
        }
        cameraManager = null;
        userInfoManager = null;
        shareManager = null;
        neverKillManager = null;
        albumManager = null;
        searchWordManager = null;
        storymanager = null;
        commonManager = null;
        shareToWeChatAndWeibo = null;
        sInstance = null;
        CLog.d(Tag, "############## GlobalManager Destroyed.");
    }

    public LocalManager getLocalManager() {
        if (mLocalManager == null) {
            mLocalManager = new LocalManager(sContext);
        }
        return mLocalManager;
    }


    public MachineSettingManager getMachineSettingManager() {
        if (machineSettingManager == null) {
            machineSettingManager = new MachineSettingManager((Application) Utils.getContext());
        }
        return machineSettingManager;
    }

    public static void logout(Context context) {
        CLog.justalkFile("logout----->" + System.currentTimeMillis());
        if (JustalkService.mAlreadyInit && MtcCli.Mtc_CliGetState() == MtcCliConstants.EN_MTC_CLI_STATE_LOGINED) {
            MtcApi.logout();
        }
        CLog.justalkFile("<------------" + System.currentTimeMillis());
        PadInfoWrapper.getInstance().deletePadByQid(AccUtil.getInstance().getQID());
        Preferences.logoutClearQidAndSessionId();
        Preferences.saveSelectedPad("");
        AccUtil.getInstance().removeUserToken();
        if(CompatibilitySupport.isGreatOrEqual50()){
            CLog.d("phone service startCommond now ");
            context.stopService(new Intent(context, MyJobService.class));
        }
//        UserWrapper.destroyUserWrapper();
        OkHttpUtils.getInstance().clearOkHttpUtils();
    }


    public AppServerManager getAppServerManager() {
        if (mAppServerManager == null) {
            mAppServerManager = new AppServerManager();
        }
        return mAppServerManager;
    }


}
