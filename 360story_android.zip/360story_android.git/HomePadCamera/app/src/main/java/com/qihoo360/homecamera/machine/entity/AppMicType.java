
package com.qihoo360.homecamera.machine.entity;


import android.annotation.SuppressLint;

import com.qihoo360.homecamera.mobile.entity.Head;

/**
 * Created by wangdan-qhwl on 2015/8/14.
 */
@SuppressLint("ParcelCreator")
@SuppressWarnings("serial")
public class AppMicType extends Head {
    // 半双工
    public int mic_type;
    // 全双工
    public VoiceConf result;
}
