package com.qihoo360.homecamera.mobile.model;

import android.os.Handler;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.db.CommandMessageWraper;
import com.qihoo360.homecamera.mobile.entity.CommandMessage;
import com.qihoo360.homecamera.mobile.entity.CommandReceipt;
import com.qihoo360.homecamera.mobile.entity.CommandResponse;
import com.qihoo360.homecamera.mobile.interfaces.CommandMessageInterface;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.QHStatAgentHelper;
import com.qihoo360.homecamera.mobile.utils.TimeUtilNew;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.UUID;

/**
 * Created by hyuan on 2016/9/27.
 */
public class CommandMessageProxy implements ActionListener {
    public static final int SEND = 1;
    public static final int RECEIVE = 2;

    public static final int EVENT_TYPE_TEXT = 1;
    public static final int EVENT_TYPE_IMAGE = 2;
    public static final int EVENT_TYPE_OPERATION = 3;
    public static final int EVENT_TYPE_CUSTOM = 4;
    public static final int EVENT_TYPE_EMPTY = 5;

    public static final int MESSAGE_TYPE_ACT = 1;
    public static final int MESSAGE_TYPE_EAT = 2;
    public static final int MESSAGE_TYPE_WHASH = 3;
    public static final int MESSAGE_TYPE_NOT_PLAY = 4;
    public static final int MESSAGE_TYPE_TIRED = 5;
    public static final int MESSAGE_TYPE_PLAY = 6;
    public static final int MESSAGE_TYPE_DRINK = 7;

    public static final int MESSAGE_TYPE_CUSTOM = 8; //自定义
    public static final int MESSAGE_TYPE_UNLOCK = 9; //解锁
    public static final int MESSAGE_TYPE_REMOTE_VIEW = 10;//远程查看



    public static final int MESSAGE_TYPE_TIME_LINE = -1;

    public static final int RESPONSE_ROBOT_ONLINE = 0;
    public static final int RESPONSE_ROBOT_NOT_ONLINE = 1;
    public static final int RESPONSE_NET_WORK_WRONG = 2;

    public static final int ACTION_SN_CHANGE = -99;
    public static final int ACTION_TO_STOP_VIDEO = -100;

    public static final int CHAT_MODE_VIDEO = 1;
    public static final int CHAT_MODE_NORMAL = 2;

    private static final String cmd = "lock_screen";
    private static int message_size = 30;
    private String mRecvSn = "";
    private String mQid = "";
    private ArrayList<CommandMessage> commandList = new ArrayList<>();
    private CommandMessageInterface mCallBack;
    //private CommandMessage cmdMsg;
    private static CommandMessageProxy instance = null;
    private int messageTotal = 30;
    private ArrayList<String> notProcessPushMessages = new ArrayList<>();

    private Handler mHandler = new Handler();
    private Runnable mWaitForPushRunnable = new Runnable() {
        @Override
        public void run() {
            if (notProcessPushMessages.size() == 0) return;
            long currentTime = System.currentTimeMillis();
            for (int i = 0; i < notProcessPushMessages.size(); i++){
                for (int j = commandList.size() - 1; j >= 0; j--){
                    if (commandList.get(j).taskId.equals(notProcessPushMessages.get(i))){
                        long d = currentTime - commandList.get(j).timeExecute;
                        if (d > 30000){
                            CLog.justalkFile("time out, monitor a push message.");
                            String str = "{\"taskId\": \"" + notProcessPushMessages.get(i) + "\"" +  ",\"status\":-1}";
                            Gson gson = new Gson();
                            CommandReceipt receipt = gson.fromJson(str, CommandReceipt.class);
                            processPushMessage(receipt);
                            mHandler.postDelayed(mWaitForPushRunnable, 1000);
                            return;
                        }
                    }
                }
            }
            mHandler.postDelayed(mWaitForPushRunnable, 1000);
        }
    };

    public static CommandMessageProxy getInstance(){
        if (instance == null){
            instance = new CommandMessageProxy();
        }
        return instance;
    }

    private void CommandMessageProxy(){

    }

    public boolean init(String sn, String qid, CommandMessageInterface callBack) {
        if (sn == null || TextUtils.isEmpty(sn) || qid == null || TextUtils.isEmpty(qid))
            return false;
        commandList.clear();
        CLog.e("cmd", "init,sn:" + sn + ",qid:" + qid);
        mRecvSn = sn;
        mQid = qid;
        GlobalManager.getInstance().getCommandMessageManager().registerActionListener(this);
        GlobalManager.getInstance().getCameraManager().registerActionListener(this);
        GlobalManager.getInstance().getCommandMessageManager().asyncGetCmdMsgList(mRecvSn, mQid, messageTotal);
        mCallBack = callBack;
        CLog.e("cmd", "init,sn:" + sn + ",qid:" + qid);
        return true;
    }

    public boolean sendCmd(int messageType, String message, String image, long lockTime) {
        if (mRecvSn == null || TextUtils.isEmpty(mRecvSn)) return false;
        if (lockTime != 999) {
            lockTime *= 60;
        } else {
            Calendar now = Calendar.getInstance();
            Calendar end = Calendar.getInstance();
            now.setTimeInMillis(System.currentTimeMillis());
            end.setTimeInMillis(System.currentTimeMillis());
//            大于6点锁到明天6点 小于6点锁到今天6点
            //1.凌晨12点后，早上6点之前，发送指令后，文案为：
//            睡觉时间，锁屏到今天早上6点
//            2.早上6点后，凌晨12点前，发送指令时，文案为：
//            睡觉时间，锁屏到明天早上6点

            int nHour = now.getTime().getHours();
            if (nHour < 6){
                end.set(Calendar.HOUR_OF_DAY, 0);
                message = "睡觉时间，锁屏到今天早上6点";
            }else {
                end.set(Calendar.HOUR_OF_DAY, 24);
                message = "睡觉时间，锁屏到明天早上6点";
            }

            lockTime = end.getTimeInMillis() - now.getTimeInMillis() + 6 * 3600 * 1000;
            lockTime = lockTime / 1000;
        }
        long timeStamp = System.currentTimeMillis();
        String taskId = buildTaskId();
        String content = wrappMessage(message, messageType, lockTime, taskId);
        CommandMessage cmdMsg = new CommandMessage();
        if (content != null) {
            cmdMsg.trickContent = content;
            cmdMsg.content = message;
            cmdMsg.sendOrReceive = SEND;
            cmdMsg.timeExecute = timeStamp;
            cmdMsg.sendState = 0;
            cmdMsg.taskId = taskId;
            cmdMsg.messageType = messageType;
            cmdMsg.sn = mRecvSn;
            cmdMsg.qid = mQid;
            cmdMsg.imagUrl = image;
            cmdMsg.lockTime = (int) lockTime;
            //commandList.add(cmdMsg);
            appendMessage(cmdMsg);
            GlobalManager.getInstance().getCommandMessageManager().asyncSendCmdMsg(cmdMsg, false);
            if (mCallBack != null)
                mCallBack.onMessage(Actions.CommandMessage.GET_LIST_SUCCESS);
        }
        CLog.e("cmd", "sendCmd ");
        return true;
    }

    public ArrayList<CommandMessage> getCurrentMessageList() {
        return commandList;
    }

    private String wrappMessage(String message, int type, long lockTime, String taskId) {
        try {
            JSONObject contentObject = new JSONObject();
            contentObject.put("taskId", taskId);
            contentObject.put("type", type);
            contentObject.put("lockTime", lockTime);
            contentObject.put("wording", message);
            return contentObject.toString();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    private String buildTaskId() {
        return UUID.randomUUID().toString();//.replaceAll("-", "");
        //return System.currentTimeMillis() + "";
    }

    private String lastObject = "";

    private void appendMessage(CommandMessage cmdMsg) {
        commandList.add(cmdMsg);
        saveCommandMessageToDB(cmdMsg);
    }

    public CommandMessage getCommandMessage(String taskId) {
        for (int i = 0; i < commandList.size(); i++) {
            if (taskId.equals(commandList.get(i).taskId)) {
                return commandList.get(i);
            }
        }
        return CommandMessageWraper.getInstance().getCommandMessage(taskId, mRecvSn, mQid);
    }

    public void refresh() {
        messageTotal += 30;
        GlobalManager.getInstance().getCommandMessageManager().asyncGetCmdMsgList(mRecvSn, mQid, messageTotal);
    }

    private void saveCommandMessageToDB(CommandMessage cmdMsg) {
        GlobalManager.getInstance().getCommandMessageManager().asyncInsertCmdMsg(cmdMsg);
    }

    private String currentPushMessageTaskId = "";

    public void processPushMessage(CommandReceipt receipt) {
        for (int i = 0; i < notProcessPushMessages.size(); i++){
            if (notProcessPushMessages.get(i).equals(receipt.taskId)) {
                notProcessPushMessages.remove(i);
                break;
            }
        }
        if (currentPushMessageTaskId.equals(receipt.taskId)) return;
        currentPushMessageTaskId = receipt.taskId;
        CommandMessage cmdMsg = new CommandMessage();
        String messageContent = "";
        for (int i = 0; i < commandList.size(); i++) {
            if (receipt.taskId.equals(commandList.get(i).taskId)) {
                if (commandList.get(i).sendOrReceive == RECEIVE){
                    CLog.justalkFile("multiple push message");
                    return;
                }
                messageContent = commandList.get(i).content;
                cmdMsg.messageType = commandList.get(i).messageType;
            }
        }
        CLog.justalkFile("begin process push message task id = " + receipt.taskId);
        cmdMsg.executeSuccess = false;
        switch (receipt.status) {
            case 1: {
                cmdMsg.executeSuccess = true;
                if (cmdMsg.messageType == MESSAGE_TYPE_ACT) {
                    messageContent = "巴迪正在告诉小主人";
                } else if(cmdMsg.messageType == MESSAGE_TYPE_UNLOCK){
                    messageContent = "巴迪已解锁";
                } else {
                    messageContent = "巴迪遵命";
                }
                break;
            }
            case 2: {
                messageContent = "执行失败，机器人已进入夜间休息模式";
                break;
            }
            case 3: {
                messageContent = "执行失败，机器人正在进行视频通话";
                break;
            }
            case 4: {
                messageContent = "机器人正在锁屏休息哦，请稍候再试吧";
                break;
            }
            case 5: {
                messageContent = "请将机器人升级为最新版，才能使用该功能哦";
                break;
            }
            case 6: {
                messageContent = "巴迪还不认识这些字哦";
                break;
            }
            case -1:{
                messageContent = "网络不给力，请稍后再试";
                break;
            }
            default:
                break;
        }
        cmdMsg.content = messageContent;
        cmdMsg.sendOrReceive = RECEIVE;
        cmdMsg.timeExecute = System.currentTimeMillis();
        cmdMsg.sendState = 0;
        cmdMsg.taskId = receipt.taskId;
        cmdMsg.qid = mQid;
        cmdMsg.sn = mRecvSn;
        CLog.justalkFile("save push message to db");
        appendMessage(cmdMsg);
        if (mCallBack != null){
            mCallBack.onMessage(Actions.CommandMessage.GET_LIST_SUCCESS);
            CLog.justalkFile("show push message");
        }
        GlobalManager.getInstance().getCommandMessageManager().asyncGetCmdMsgList(mRecvSn, mQid, messageTotal);
        CLog.justalkFile("get message from db, invoke get list");
        QdasProcess(cmdMsg.messageType, cmdMsg.executeSuccess, receipt.status);
    }

    private int mChatMode = CHAT_MODE_NORMAL;
    public void setChatMode(int nMode){
        mChatMode = nMode;
    }

    public void QdasProcess(int actionType, boolean success, int failedType) {
        HashMap<String, String> map = new HashMap<String, String>();
        String action = "";
        String failedReason = "" + failedType;
        switch (actionType) {
            case MESSAGE_TYPE_ACT:
                action = "actBuddy";
                break;
            case MESSAGE_TYPE_DRINK:
                action = "drink";
                break;
            case MESSAGE_TYPE_EAT:
                action = "eat";
                break;
            case MESSAGE_TYPE_NOT_PLAY:
                action = "sleep";
                break;
            case MESSAGE_TYPE_PLAY:
                action = "play";
                break;
            case MESSAGE_TYPE_TIRED:
                action = "tired";
                break;
            case MESSAGE_TYPE_WHASH:
                action = "wash";
                break;
            case MESSAGE_TYPE_UNLOCK:
                action = "unlock";
                break;
        }

        String from = "default";
        if (mChatMode == CHAT_MODE_VIDEO){
            from = "monitor";
        }

        map.put("from", from);
        map.put("type", action);
        map.put("success", success ? "Y" : "N");
        map.put("fail_reason", failedReason);
        QHStatAgentHelper.commitCommonEventHash("robotResponse", map);
    }

    public class SortComparator implements Comparator {
        @Override
        public int compare(Object lhs, Object rhs) {
            CommandMessage a = (CommandMessage) lhs;
            CommandMessage b = (CommandMessage) rhs;
            long c = a.timeExecute - b.timeExecute;
            int d = (int) c;
            return d;
        }
    }

    private String formateMessageTimeNew(long lastTime) {
        String res = "";
        String date = TimeUtilNew.getCustomStrByMill(lastTime);
        String time = TimeUtilNew.getHMDate(lastTime);
        StringBuffer sb = new StringBuffer(date).append(" ").append(time);
        res = sb.toString();
        return res;
    }


    private String formateMessageTime(long lastTime) {
        Calendar now = Calendar.getInstance();
        Calendar last = Calendar.getInstance();
        now.setTimeInMillis(System.currentTimeMillis());
        last.setTimeInMillis(lastTime);
        int duration = now.get(Calendar.DAY_OF_MONTH) - last.get(Calendar.DAY_OF_MONTH);
        String dataStr = "";
        // if (duration < 0) return null;
        switch (duration) {
            case 0: {
                dataStr = "今天 ";
                break;
            }
            case 1: {
                dataStr = "昨天 ";
                break;
            }
            case 3: {
                dataStr = "前天 ";
                break;
            }
            default: {
                dataStr += last.get(Calendar.YEAR) + "-" + last.get(Calendar.MONTH)
                        + "-" + last.get(Calendar.DAY_OF_MONTH) + " ";
                break;
            }
        }
        int hour = last.get(Calendar.HOUR_OF_DAY);
        if (hour < 10)
            dataStr += "0" + hour + ":";
        else
            dataStr += "" + hour + ":";
        int minute = last.get(Calendar.MINUTE);
        if (minute < 10)
            dataStr += "0" + minute + " ";
        else
            dataStr += "" + minute + " ";
        return dataStr;
    }

    @Override
    public Object actionPerformed(int actionCode, Object... args) {
        switch (actionCode) {
            case Actions.CommandMessage.GET_INSTANCE_FAIL: {
                if (mCallBack != null)
                    mCallBack.onMessage(actionCode);
                return Boolean.TRUE;
            }
            case Actions.CommandMessage.GET_INSTANCE_SUCCESS: {
                if (mCallBack != null)
                    mCallBack.onMessage(actionCode);
                return Boolean.TRUE;
            }
            case Actions.CommandMessage.GET_LIST_FAIL: {
                CLog.justalkFile("get message list from db failed.");
                CLog.e("get message list from db failed.");
//                if (mCallBack != null)
//                    mCallBack.onMessage(actionCode);
                return Boolean.TRUE;
            }
            case Actions.CommandMessage.GET_LIST_SUCCESS: {
                commandList.clear();
                ArrayList<CommandMessage> tempList = (ArrayList<CommandMessage>) args[0];
                Comparator comp = new SortComparator();
                Collections.sort(tempList, comp);
                long duration = 0;
                int lastLineIndex = 0;
                for (int i = 0; i < tempList.size(); i++) {
                    if (tempList.get(i).sendState == 0) {
                        tempList.get(i).sendState = 1;
                    }
                    if (tempList.get(i).content == null) continue;
                    if (i > 0)
                        duration = tempList.get(i).timeExecute - tempList.get(lastLineIndex).timeExecute;
                    CLog.e("timeMessage", "message (" + i +
                            ":" + tempList.size() + ")" + formateMessageTime(tempList.get(i).timeExecute)
                            + ",interval:" + (duration / 1000 / 60));
                    if (i == 0 || (duration / 1000 / 60) >= 5) {
                        CommandMessage cmd = new CommandMessage();
                        cmd.messageType = MESSAGE_TYPE_TIME_LINE;
                        cmd.content = formateMessageTimeNew(tempList.get(i).timeExecute);
                        if (cmd.content != null) {
                            commandList.add(cmd);
                            CLog.e("timeMessage", "insert time line before(" + i +
                                    ":" + tempList.size() + ")" + tempList.get(i).content + " at:" + cmd.content);
                        }
                        duration = 0;
                        lastLineIndex = i;
                    }
                    commandList.add(tempList.get(i));
                }
                if (mCallBack != null)
                    mCallBack.onMessage(actionCode);
                return Boolean.TRUE;
            }
            case Actions.CommandMessage.SET_INSTANCE_FAIL: {
                CLog.justalkFile("insert message to db failed.");
                CLog.e("insert message to db failed.");
                //GlobalManager.getInstance().getCommandMessageManager().asyncGetCmdMsgList(mRecvSn, mQid);
                return Boolean.TRUE;
            }
            case Actions.CommandMessage.SET_INSTANCE_SUCCESS: {
                CLog.justalkFile("insert message to db success.");
                CLog.e("insert message to db success.");
                //GlobalManager.getInstance().getCommandMessageManager().asyncGetCmdMsgList(mRecvSn, mQid);
                return Boolean.TRUE;
            }
            case Actions.CommandMessage.SEND_COMMAND: {
                CommandResponse response = (CommandResponse) args[0];
                final CommandMessage msg = (CommandMessage) args[1];
                boolean retry = (boolean) args[2];
                int responesType = RESPONSE_ROBOT_NOT_ONLINE;
                msg.sendOrReceive = SEND;
                if (response.data != null) {
                    if (response.data.online) {
                        notProcessPushMessages.add(msg.taskId);
                        responesType = RESPONSE_ROBOT_ONLINE;
                        msg.sendState = 2;
                        CLog.justalkFile("send message successfully, robot online.");
                    } else {
                        msg.sendState = 1;
                        CLog.justalkFile("send message successfully, robot not online.");
                    }
                } else {
                    msg.sendState = 1;
                    responesType = RESPONSE_NET_WORK_WRONG;
                    CLog.justalkFile("send message failed, network is worse");
                }
                msg.sn = mRecvSn;
                msg.qid = mQid;
                GlobalManager.getInstance().getCommandMessageManager().asyncUpdateCmdMsg(msg);
                if (!retry) {
                    //appendMessage(msg);
                    CLog.e("cmd", "send new message: cmdMsg.sendState:" + msg.sendState);
                    if (mCallBack != null)
                        mCallBack.onMessage(actionCode, responesType);
                } else {
                    //GlobalManager.getInstance().getCommandMessageManager().asyncUpdateCmdMsg(msg);
                    CLog.e("cmd", "try send message again: cmdMsg.sendState:" + msg.sendState);
                    if (mCallBack != null)
                        mCallBack.onMessage(actionCode, responesType);
                }
                if (responesType == RESPONSE_ROBOT_ONLINE){
                    mHandler.removeCallbacks(mWaitForPushRunnable);
                    mHandler.postDelayed(mWaitForPushRunnable, 10000);
                }
                return Boolean.TRUE;
            }
            case Actions.CommandMessage.UPDATE_COMMAND: {
                GlobalManager.getInstance().getCommandMessageManager().asyncGetCmdMsgList(mRecvSn, mQid, messageTotal);
                return Boolean.TRUE;
            }
            case Actions.Camera.LOAD_OK:
            case Actions.Camera.MODIFY_TITLE_HEAD_SUCCESS:
            case Actions.Camera.UN_BIND_DEVICE_SUCCESS:
            case Actions.Camera.DELTET_SN:
            case Actions.Camera.SELECTED_CAMERA:
            case Actions.Camera.BIND_DEVICE_SUCCESS:
            case Actions.Camera.CAMERA_LIST_ACTION:{
                if (mCallBack != null){
                    mCallBack.onMessage(ACTION_SN_CHANGE);
                }

                if (actionCode == Actions.Camera.UN_BIND_DEVICE_SUCCESS ||
                        actionCode == Actions.Camera.SELECTED_CAMERA){
                    if (mCallBack != null){
                        mCallBack.onMessage(ACTION_TO_STOP_VIDEO);
                    }
                }

                return Boolean.TRUE;
            }
        }
        return null;
    }

    public void sendAgain(String taskId) {
        if (taskId == null) return;
        for (int i = 0; i < commandList.size(); i++) {
            if (taskId.equals(commandList.get(i).taskId)) {
                String content = wrappMessage(commandList.get(i).content, commandList.get(i).messageType, commandList.get(i).lockTime, taskId);
                commandList.get(i).trickContent = content;
                commandList.get(i).sn = mRecvSn;
                commandList.get(i).qid = mQid;
                commandList.get(i).sendState = 0;
                notProcessPushMessages.add(taskId);
                GlobalManager.getInstance().getCommandMessageManager().asyncSendCmdMsg(commandList.get(i), true);
                if (mCallBack != null)
                    mCallBack.onMessage(Actions.CommandMessage.GET_LIST_SUCCESS);
                break;
            }
        }
    }

    @Override
    public int getProperty() {
        return 0;
    }

    public void destroy() {
        GlobalManager.getInstance().getCommandMessageManager().removeActionListener(this);
        GlobalManager.getInstance().getCameraManager().removeActionListener(this);
    }
}
