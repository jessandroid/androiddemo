package com.qihoo360.homecamera.machine.entity;

import java.io.Serializable;

/**
 * Created by wangdan-qhwl on 2016/3/23.
 */
public class PublicCameraSupport implements Serializable {
    public int cloud;
    public int stream_v2;
}
