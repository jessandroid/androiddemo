
package com.qihoo360.homecamera.machine.entity;

import android.content.res.TypedArray;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.entity.Head;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.util.Calendar;

public class Weather extends Head {
    private static final long serialVersionUID = 4432493340912354791L;
    public int img = -1;//天气代号
    public String info;
    public String temperature;
    public AQI aqi;

    public class AQI {
        public String pm25;
        public String quality;
    }
    
    public static int getIconResourceId(int type) {
        int weatherType = getWeatherType(type);
        TypedArray weatherIcs = Utils.getContext().getResources().obtainTypedArray(R.array.weather_ic);
        int id = weatherIcs.getResourceId(weatherType, R.drawable.clockweather_w_face);
        weatherIcs.recycle();
        
        if(weatherType == 1 || weatherType == 2) {
            int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
            if(hour > 20 || hour < 6) {
                if(weatherType == 1) {
                    id = R.drawable.clockweather_w1_night;
                }else if(weatherType == 2) {
                    id = R.drawable.clockweather_w2_night;
                }
            }
        }
        return id;
    }

    public static int getWeatherType(int type) {
        switch (type) {
            case 0:
            case 1:
            case 2:
                type += 1;
                break;

            case 3:
                type = 8;
                break;
            case 4:
                type = 9;
                break;
            case 5:
                type = 18;
                break;
            case 6:
                type = 10;
                break;
            case 7:
                type = 4;
                break;
            case 8:
                type = 5;
                break;
            case 9:
                type = 6;
                break;
            case 10:
                type = 7;
                break;
            case 11:
                type = 7;
                break;
            case 12:
                type = 7;
                break;
            case 13:
                type = 15;
                break;
            case 14:
                type = 11;
                break;
            case 15:
                type = 12;
                break;
            case 16:
                type = 13;
                break;
            case 17:
                type = 14;
                break;
            case 18:
                type = 16;
                break;
            case 19:
                type = 4;
                break;
            case 20:
                type = 17;
                break;
            case 21:
                type = 4;
                break;
            case 22:
                type = 5;
                break;
            case 23:
                type = 6;
                break;
            case 24:
                type = 7;
                break;
            case 25:
                type = 7;
                break;
            case 26:
                type = 11;
                break;
            case 27:
                type = 12;
                break;
            case 28:
                type = 13;
                break;
            case 29:
                type = 17;
                break;
            case 30:
                type = 17;
                break;
            case 31:
                type = 17;
                break;
            case 32:
                type = 17;
                break;
            case 33:
                type = 17;
                break;
            case 34:
                type = 17;
                break;
            case 35:
                type = 9;
                break;
            case 36:
                type = 4;
                break;
            case 37:
                type = 9;
                break;
            case 38:
                type = 9;
                break;
            case 39:
                type = 17;
                break;
            case 40:
                type = 4;
                break;
            case 41:
                type = 18;
                break;
            case 42:
                type = 18;
                break;
            case 43:
                type = 18;
                break;

            default:
                type = -1;
                break;
        }
        return type;
    }

}
