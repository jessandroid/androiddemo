package com.qihoo360.homecamera.machine.business;

import android.os.Handler;
import android.os.Message;

import com.google.gson.Gson;
import com.qihoo360.homecamera.machine.entity.LocalSettingEntity;
import com.qihoo360.homecamera.machine.entity.SongEntity;
import com.qihoo360.homecamera.mobile.utils.CLog;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.UUID;

/**
 * Created by zhangtao-iri on 2016/12/22.
 */
public class JsonManager {

    //生成发送播放控制的content
    public static String getPlayControlContent(String playStatus, SongEntity songEntity, String unique, int pageId){

        JSONObject jo = new JSONObject();
        try {
            jo.put("taskid", UUID.randomUUID().toString());
            jo.put("playstatus", playStatus);
            jo.put("unique", unique);
            jo.put("pageid", pageId);
            jo.put("mediaInfo", new JSONObject(new Gson().toJson(songEntity==null ? new SongEntity() : songEntity)));

        } catch (JSONException e) {
            e.printStackTrace();
        }
        CLog.e("zt","播放请求JSON:"+jo.toString());
        return jo.toString();
    }

    //生成发送播放控制的content
    public static String getPrevOrNextContent(String playStatus){

        JSONObject jo = new JSONObject();
        try {
            jo.put("taskid", UUID.randomUUID().toString());
            jo.put("playstatus", playStatus);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        CLog.e("zt", "请求播放上一首活下一首的json:"+jo.toString());
        return jo.toString();
    }

    //生成发送获取播放状态的content或者是获取本地设置
    public static String getPlayStatusContent(){

        JSONObject jo = new JSONObject();
        try {
            jo.put("taskid", UUID.randomUUID().toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        CLog.e("zt", "请求播放状态的json:"+jo.toString());
        return jo.toString();
    }

    //生成发送获取各种列表的content
    public static String getPlayListContent(int listType, String unique, String md5){
        JSONObject jo = new JSONObject();
        try {
            jo.put("taskid", UUID.randomUUID().toString());
            jo.put("type", listType);
            jo.put("unique", unique);
            jo.put("md5", md5);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        CLog.e("zt", "请求列表的json:"+jo.toString());
        return jo.toString();

    }

    //生成发送收藏命令的content
    public static String getStoryFavor(String operation, SongEntity songEntity, String unique, int pageId){

        JSONObject jo = new JSONObject();
        try {
            jo.put("taskid", UUID.randomUUID().toString());
            jo.put("operation", operation);
            jo.put("unique", unique);
            jo.put("pageid", pageId);
            jo.put("mediaInfo", new JSONObject(new Gson().toJson(songEntity==null ? new SongEntity() : songEntity)));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        CLog.e("zt","收藏请求JSON:"+jo.toString());
        return jo.toString();
    }

    //生成发送进行本地设置的conetent
    public static String getLocalSetting(JSONObject setJson){

        JSONObject jo = new JSONObject();
        try {
            jo.put("taskid", UUID.randomUUID().toString());
            jo.put("localSettings", setJson);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        CLog.e("zt","获取设置请求JSON:"+jo.toString());
        return jo.toString();
    }

    //生成通知故事机进行固件升级的json
    public static String getSendFMUpgrade(int codeFrom, int codeTo){
        JSONObject jo = new JSONObject();
        try {
            jo.put("taskid", UUID.randomUUID().toString());
            jo.put("codefrom", codeFrom);
            jo.put("codeto", codeTo);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jo.toString();
    }
}
