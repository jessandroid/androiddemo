package com.qihoo360.homecamera.machine.adapter;

import android.support.v4.view.PagerAdapter;
import android.view.View;
import android.view.ViewGroup;

import com.qihoo360.homecamera.mobile.R;

import java.util.List;

import butterknife.OnClick;

/**
 * Created by zhangtao-iri on 2017/2/16.
 */
public class ExpressionAdapter extends PagerAdapter{

    private List<View> mViewList;
    private ExpressInterface mExpressInterface;

    public ExpressionAdapter(List<View> viewList, ExpressInterface expressInterface){
        this.mViewList = viewList;
        this.mExpressInterface = expressInterface;
    }

    @Override
    public int getCount() {
        return mViewList == null ? 0 : mViewList.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        container.addView(mViewList.get(position));
        if(position==0){
            mViewList.get(position).findViewById(R.id.expression_img1).setOnClickListener(new MyClick(1));
            mViewList.get(position).findViewById(R.id.expression_img2).setOnClickListener(new MyClick(2));
            mViewList.get(position).findViewById(R.id.expression_img3).setOnClickListener(new MyClick(3));
            mViewList.get(position).findViewById(R.id.expression_img4).setOnClickListener(new MyClick(4));
            mViewList.get(position).findViewById(R.id.expression_img5).setOnClickListener(new MyClick(5));
            mViewList.get(position).findViewById(R.id.expression_img6).setOnClickListener(new MyClick(6));
            mViewList.get(position).findViewById(R.id.expression_img7).setOnClickListener(new MyClick(7));
            mViewList.get(position).findViewById(R.id.expression_img8).setOnClickListener(new MyClick(8));
        }else if(position==1){

        }
        return mViewList.get(position);
    }

    @Override
    public int getItemPosition(Object object) {
        return POSITION_NONE;
    }

    class MyClick implements View.OnClickListener{
        private int mId;
        public MyClick(int id){
            this.mId = id;
        }
        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.expression_img1:
                case R.id.expression_img2:
                case R.id.expression_img3:
                case R.id.expression_img4:
                case R.id.expression_img5:
                case R.id.expression_img6:
                case R.id.expression_img7:
                case R.id.expression_img8:
                    mExpressInterface.sendExpress(mId);
                    break;
            }
        }
    }

    public interface ExpressInterface{
        public void sendExpress(int emojiId);
    }
}
