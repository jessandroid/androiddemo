package com.qihoo360.homecamera.machine.entity;

/**
 * Created by zhangtao-iri on 2017/1/16.
 */
public class UpgradeReceipt extends BaseCmdReceipt{

    public int codefrom;

    public int codeto;

    public int getCodefrom() {
        return codefrom;
    }

    public void setCodefrom(int codefrom) {
        this.codefrom = codefrom;
    }

    public int getCodeto() {
        return codeto;
    }

    public void setCodeto(int codeto) {
        this.codeto = codeto;
    }
}
