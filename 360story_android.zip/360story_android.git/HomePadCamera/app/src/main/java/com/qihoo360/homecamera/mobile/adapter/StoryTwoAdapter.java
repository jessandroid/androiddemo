package com.qihoo360.homecamera.mobile.adapter;

import android.content.Context;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.qihoo360.homecamera.mobile.entity.StoryList;
import com.qihoo360.homecamera.mobile.ui.fragment.StoryShowView;

import java.util.List;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/3/15
 * Time: 12:15
 * To change this template use File | Settings | File Templates.
 */
public class StoryTwoAdapter extends RecyclerView.Adapter<StoryTwoAdapter.ViewHolder> {

    private List<StoryList> list;
    private Context context;

    public StoryTwoAdapter(Context context, List<StoryList> list) {
        this.context = context;
        this.list = list;
    }

    public void dataChanage(List<StoryList> storyLists){
        this.list = storyLists;
        notifyDataSetChanged();
    }

    @Override
    public StoryTwoAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        StoryShowView view = new StoryShowView(context);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        view.setLayoutParams(layoutParams);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(StoryTwoAdapter.ViewHolder holder, final int position) {
//        CLog.d("list.get(position)---->"+list.get(position).title);
        StoryShowView storyShowView = (StoryShowView) holder.mView;
        storyShowView.initListData(list.get(position));
    }

    @Override
    public int getItemCount() {
        return list.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View mView;
        public ImageView image_head;
        public CardView card_item;

        public ViewHolder(View view) {
            super(view);
            mView = view;
        }

    }
}