package com.qihoo360.homecamera.machine.videoplay;

import android.content.Context;

import com.qihoo.jia.play.jnibase.GL2JNILib;
import com.qihoo360.homecamera.machine.play.APlayManager;
import com.qihoo360.homecamera.mobile.utils.CLog;

public class GLRendererImpl implements GLProducerThread.GLRenderer {

    private int mWidth;
    private int mHeight;

    private long mVideoHandle;

    public interface GLRenderWrapper {
        APlayManager getPlayManager();
    }

    private GLRenderWrapper mWrapper;

//    public GLRendererImpl(Context ctx) {
//
//    }

    public GLRendererImpl(Context ctx, GLRenderWrapper wrapper) {
        mWrapper = wrapper;
    }

//    public void setGLRenderWrapper(GLRenderWrapper wrapper) {
//        mWrapper = wrapper;
//    }

    public void setViewport(int width, int height) {
        mWidth = width;
        mHeight = height;
    }

    public void setViewport(int ox, int oy, int width, int height) {
        mOx = ox;
        mOy = oy;
        mWidth = width;
        mHeight = height;
    }

    private int mOx;
    private int mOy;

    public void initGL() {
        mVideoHandle = GL2JNILib.init(mWidth, mHeight);
        GL2JNILib.setViewport(mVideoHandle, mOx, mOy, mWidth, mHeight);
        CLog.e("GLProducerThread", "GLRendererImpl initGL mVideoHandle:" + mVideoHandle + ", mWrapper:" + mWrapper + ", manager:" + mWrapper.getPlayManager());
        if (mWrapper != null && mWrapper.getPlayManager() != null) {
            CLog.e("cx_debug initGL mOx：" + mOx + " mOy " + mOy + " width " + mWidth + " height " + mHeight);
            mWrapper.getPlayManager().setVideoViewHandle(mVideoHandle);
        }
    }

    public void resize(int width, int height) {
        mWidth = width;
        mHeight = height;
        GL2JNILib.setViewport(mVideoHandle, mOx, mOy, width, height);
        CLog.e("cx_debug resize mOx：" + mOx + " mOy " + mOy + " width " + width + " height " + height);
    }

    public void resize(int ox, int oy, int width, int height) {
        mOx = ox;
        mOy = oy;
        mWidth = width;
        mHeight = height;
        GL2JNILib.setViewport(mVideoHandle, mOx, mOy, width, height);
        CLog.e("cx_debug resize mOx：" + mOx + " mOy " + mOy + " width " + width + " height " + height);
    }

    @Override
    public void drawFrame() {
        CLog.e("GLProducerThread", "drawFrame mVideoHandle:" + mVideoHandle + ", " + Thread.currentThread());
        GL2JNILib.step(mVideoHandle);
    }

    public long getVideoHandle() {
        return mVideoHandle;
    }

}
