package com.qihoo360.homecamera.machine.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by zhangtao-iri on 2017/1/11.
 */
public class MachineDeviceInfo extends BaseCmdReceipt{


    public Data deviceInfo;

    public class Data implements Parcelable{
        public String model;    // 故事机型号
        public String serialno; // 故事机序列号
        public String ip;       // ip地址
        public String mac;      // mac地址
        public String spaceTotal;// 总存储空间
        public String spaceFree; //剩余空间
        public String wifiSignal;//wifi信号强度
        public String wifiSsid;  //wifi SSID名称
        public String systemVersion;  //系统版本号
        public String systemCode;//系统升级版本号
        public String batteryLevel;//电池电量

        public String getSystemCode() {
            return systemCode;
        }

        public void setSystemCode(String systemCode) {
            this.systemCode = systemCode;
        }

        public String getModel() {
            return model;
        }

        public void setModel(String model) {
            this.model = model;
        }

        public String getSystemVersion() {
            return systemVersion;
        }

        public void setSystemVersion(String systemVersion) {
            this.systemVersion = systemVersion;
        }

        public String getWifiSsid() {
            return wifiSsid;
        }

        public void setWifiSsid(String wifiSsid) {
            this.wifiSsid = wifiSsid;
        }

        public String getWifiSignal() {
            return wifiSignal;
        }

        public void setWifiSignal(String wifiSignal) {
            this.wifiSignal = wifiSignal;
        }

        public String getBatteryLevel() {
            return batteryLevel;
        }

        public void setBatteryLevel(String batteryLevel) {
            this.batteryLevel = batteryLevel;
        }

        public String getSpaceFree() {
            return spaceFree;
        }

        public void setSpaceFree(String spaceFree) {
            this.spaceFree = spaceFree;
        }

        public String getSpaceTotal() {
            return spaceTotal;
        }

        public void setSpaceTotal(String spaceTotal) {
            this.spaceTotal = spaceTotal;
        }

        public String getMac() {
            return mac;
        }

        public void setMac(String mac) {
            this.mac = mac;
        }

        public String getIp() {
            return ip;
        }

        public void setIp(String ip) {
            this.ip = ip;
        }

        public String getSerialno() {
            return serialno;
        }

        public void setSerialno(String serialno) {
            this.serialno = serialno;
        }

        public Creator<Data> getCREATOR() {
            return CREATOR;
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(this.model);
            dest.writeString(this.serialno);
            dest.writeString(this.ip);
            dest.writeString(this.mac);
            dest.writeString(this.spaceTotal);
            dest.writeString(this.spaceFree);
            dest.writeString(this.wifiSignal);
            dest.writeString(this.wifiSsid);
            dest.writeString(this.systemVersion);
            dest.writeString(this.systemCode);
            dest.writeString(this.batteryLevel);
        }

        public Data() {
        }

        protected Data(Parcel in) {
            this.model = in.readString();
            this.serialno = in.readString();
            this.ip = in.readString();
            this.mac = in.readString();
            this.spaceTotal = in.readString();
            this.spaceFree = in.readString();
            this.wifiSignal = in.readString();
            this.wifiSsid = in.readString();
            this.systemVersion = in.readString();
            this.systemCode = in.readString();
            this.batteryLevel = in.readString();
        }

        public  final Creator<Data> CREATOR = new Creator<Data>() {
            @Override
            public Data createFromParcel(Parcel source) {
                return new Data(source);
            }

            @Override
            public Data[] newArray(int size) {
                return new Data[size];
            }
        };
    }

}
