package com.qihoo360.homecamera.machine.popwin;


import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;
import android.os.Handler;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.aspsine.swipetoloadlayout.OnLoadMoreListener;
import com.aspsine.swipetoloadlayout.OnRefreshListener;
import com.aspsine.swipetoloadlayout.SwipeToLoadLayout;
import com.jakewharton.rxbinding.view.RxView;
import com.qihoo360.homecamera.machine.business.PlayConfig;
import com.qihoo360.homecamera.machine.config.MachineConsts;
import com.qihoo360.homecamera.machine.entity.MachinePlayInfo;
import com.qihoo360.homecamera.machine.entity.MachinePlaySingle;
import com.qihoo360.homecamera.machine.entity.SongEntity;
import com.qihoo360.homecamera.machine.entity.SongListResponse;
import com.qihoo360.homecamera.machine.fragment.StoryPlayerFragment;
import com.qihoo360.homecamera.machine.ui.widget.CustomRefreshHeadView;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.core.net.MachineApi;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.widget.TextViewWithFont;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import rx.functions.Action1;

/**
 * Created by lixin3-s on 2016/11/15.
 */
public class StoryPlayerPopWin extends BasePopWin implements OnRefreshListener, OnLoadMoreListener{

    public SwipeToLoadLayout swipeToLoadLayout;
    public RecyclerView mRecyclerView;
    public List<SongEntity> mData;
    public Adapter adapter;
    public StoryPopWinInterface storyPopWinInterface;
    private LinearLayoutManager linearLayoutManager;
    private TextViewWithFont playerSum;

    private MachinePlaySingle playSingle;

    public int upPage;     //向上加载到了第几页
    public int downPage;   //向下加载到了第几页
    public int currentPage;//当前页
    public int totalPage;  //一共多少

    public CustomRefreshHeadView headView;
    public CustomRefreshHeadView rootView;

    private boolean move =false;
    private int mIndex = 0;

    public StoryPlayerPopWin(StoryPlayerFragment fragment, View parent, StoryPopWinInterface popWinInterface) {
        super(fragment.getActivity(), parent);
        this.storyPopWinInterface = popWinInterface;
    }

    @Override
    int getLayoutId() {
        return R.layout.story_player_list;
    }

    @Override
    void initView() {
        swipeToLoadLayout = (SwipeToLoadLayout) contentView.findViewById(R.id.swipe_container);
        swipeToLoadLayout.setOnRefreshListener(this);
        swipeToLoadLayout.setOnLoadMoreListener(this);
        headView = (CustomRefreshHeadView)contentView.findViewById(R.id.swipe_refresh_header);
        rootView = (CustomRefreshHeadView)contentView.findViewById(R.id.swipe_load_more_footer);
        mRecyclerView = (RecyclerView) contentView.findViewById(R.id.swipe_target);
        playerSum = (TextViewWithFont) contentView.findViewById(R.id.player_sum);
        linearLayoutManager = new LinearLayoutManager(context);
        adapter = new Adapter(context, mData);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mRecyclerView.setAdapter(adapter);
    }

    public void setLoadingComplete(){
        swipeToLoadLayout.setRefreshing(false);
        swipeToLoadLayout.setLoadingMore(false);
    }

    public void setData(ArrayList<SongEntity> songList, MachinePlaySingle single){
        rootView.setDownLoaderOver(false);
        headView.setUpLoadOver(false);
        adapter.mData = songList;
        this.playSingle = single;
        upPage = downPage = currentPage = playSingle.getPageId();
        adapter.notifyDataSetChanged();
        if(TextUtils.equals(playSingle.getUnique(), PlayConfig.FAVORUNIQUE)){
            swipeToLoadLayout.setEnabled(false);
            swipeToLoadLayout.setRefreshEnabled(false);
            swipeToLoadLayout.setLoadMoreEnabled(false);
        }else if(PlayConfig.isOnlineType(playSingle.getMediaInfo().getType())){
            swipeToLoadLayout.setEnabled(true);
            swipeToLoadLayout.setRefreshEnabled(true);
            swipeToLoadLayout.setLoadMoreEnabled(true);
        }else{
            swipeToLoadLayout.setEnabled(false);
            swipeToLoadLayout.setRefreshEnabled(false);
            swipeToLoadLayout.setLoadMoreEnabled(false);
        }
    }

    public void addMore(ArrayList<SongEntity> songList){
        adapter.mData = songList;
        adapter.notifyDataSetChanged();
    }

    public void setSectedSong(String uniqueId){
        adapter.playUniqueId = uniqueId;
        adapter.notifyDataSetChanged();
        for(int i=0; i<adapter.mData.size(); i++){
            SongEntity songEntity = adapter.mData.get(i);
            if(TextUtils.equals(adapter.playUniqueId, songEntity.getUniqueid())){
                mRecyclerView.stopScroll();
                linearLayoutManager.scrollToPositionWithOffset(i ,0);
                return;
            }
        }
    }

    public void setSectedSongNoScroll(String uniqueId){
        adapter.playUniqueId = uniqueId;
        adapter.notifyDataSetChanged();
    }

    public void setPlaySum(int sum){
        playerSum.setText(String.format(context.getString(R.string.player_list_sum), sum));
    }

    @Override
    public void onRefresh() {
        if((upPage-1)>0){
            storyPopWinInterface.loadMore(upPage - 1);
        }else{
            headView.setUpLoadOver(true);
            setLoadingComplete();
        }
    }

    @Override
    public void onLoadMore() {
        if(downPage+1<=totalPage){
            storyPopWinInterface.loadMore(downPage + 1);
        }else{
            rootView.setDownLoaderOver(true);
            setLoadingComplete();
        }
    }

    class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {

        public List<SongEntity> mData;
        public String playUniqueId;

        Context mContext;
        public Adapter(Context context, List<SongEntity> data) {
            mData = new ArrayList<>();
            mData = data;
            mContext = context;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(mContext).inflate(R.layout.list_item_player_story_list, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, final int position) {
            SongEntity songEntity = mData.get(position);
            holder.sName.setText(songEntity.getTitle());

            if(!TextUtils.isEmpty(playUniqueId)){
                holder.playIcon.setVisibility(TextUtils.equals(playUniqueId, songEntity.getUniqueid()) ? View.VISIBLE : View.GONE);
                holder.sName.setTextColor(TextUtils.equals(playUniqueId, songEntity.getUniqueid()) ? Color.parseColor("#FF495C") : Color.parseColor("#4d4d4d"));
                if(holder.playIcon.getVisibility() == View.VISIBLE){
                    final AnimationDrawable ad = (AnimationDrawable) holder.playIcon.getBackground();
                    if(!ad.isRunning()){
                        mHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                ad.start();
                            }
                        });
                    }
                }else{
                    final AnimationDrawable ad = (AnimationDrawable) holder.playIcon.getBackground();
                    mHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            ad.selectDrawable(0);
                            ad.stop();
                        }
                    });
                }
            }else{
                holder.sName.setTextColor(Color.parseColor("#4d4d4d"));
                holder.playIcon.setVisibility(View.GONE);
                final AnimationDrawable ad = (AnimationDrawable) holder.playIcon.getBackground();
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        ad.selectDrawable(0);
                        ad.stop();
                    }
                });
            }

            RxView.clicks(holder.itemView).throttleFirst(300, TimeUnit.MILLISECONDS).subscribe(new Action1<Void>() {
                @Override
                public void call(Void aVoid) {
                    if(!Utils.isNetworkAvailable(mContext)){
                        CameraToast.show(null, R.string.network_disabled, Toast.LENGTH_SHORT);
                        return;
                    }
                    storyPopWinInterface.OnItemClick(position);
                }
            });
        }

        @Override
        public int getItemCount() {
            return mData != null ? mData.size() : 0;
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            ImageView playIcon;
            TextView  sName;
            public ViewHolder(View itemView) {
                super(itemView);
                playIcon = (ImageView) itemView.findViewById(R.id.playing_icon);
                sName = (TextView) itemView.findViewById(R.id.title_name);
            }
        }
    }

    private Handler mHandler = new Handler();

    public interface StoryPopWinInterface{
        void OnItemClick(int p);
        void loadMore(int pageId);
    }
}
