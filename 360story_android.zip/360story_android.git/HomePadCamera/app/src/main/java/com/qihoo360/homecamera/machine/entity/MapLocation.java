package com.qihoo360.homecamera.machine.entity;

import android.text.TextUtils;

import com.qihoo360.homecamera.machine.util.JSONUtils;

import java.io.Serializable;

/**
 * Created by wdynetposa on 2014/12/5.
 */
public class MapLocation implements Serializable {
    private static final long serialVersionUID = -7406696271250365071L;

    public enum ChooseTypes {
        None, Point
    }

    public String City = "";

    private ChooseTypes type;
    private String poiId;
    private String title = "";
    private String snippet = "";

    private String province = "";
    private String city = "";
    private String adName = "";

    /**维度*/
    private double latitude ;
    /**经度*/
    private double longitude;

    public ChooseTypes getType() {
        return type;
    }

    public void setType(ChooseTypes type) {
        this.type = type;
    }

    public String getPoiId() {
        return poiId;
    }

    public void setPoiId(String poiId) {
        this.poiId = poiId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSnippet() {
        return snippet;
    }

    public void setSnippet(String snippet) {
        this.snippet = snippet;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        if (TextUtils.isEmpty(city)) {
            this.city = City;
        } else {
            this.city = city;
        }
    }

    public String getAdName() {
        return adName;
    }

    public void setAdName(String adName) {
        this.adName = adName;
    }

    // 其他
    public String getLocationPub() {
        if (type == ChooseTypes.None) {
            return "";
        }

        String locationPub;
        if (!TextUtils.isEmpty(province) && !TextUtils.isEmpty(city) && !province.equals(city)) {
            locationPub = setPubInfo(1);
        } else if (!TextUtils.isEmpty(city)) {
            if (!TextUtils.isEmpty(adName)) {
                locationPub = setPubInfo(2);
            } else {
                locationPub = setPubInfo(3);
            }
        } else {
            locationPub = title;
        }

        return locationPub;
    }

    private String setPubInfo(int info) {
        switch (info) {
            case 1:
                return String.format("%s·%s·%s", province, city, title);
            case 2:
                return String.format("%s·%s·%s", city, adName, title);
            case 3:
                return String.format("%s·%s", city, title);
        }
        return "";
    }

    public String getLocationInfo() {
        if (type == ChooseTypes.None) {
            return "";
        }
        String locationInfo = JSONUtils.toJson(this);
        return locationInfo;
    }

    /**维度*/
    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    /**经度*/
    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }
}
