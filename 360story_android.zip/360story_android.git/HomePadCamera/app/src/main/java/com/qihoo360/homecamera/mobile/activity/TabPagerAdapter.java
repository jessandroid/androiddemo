package com.qihoo360.homecamera.mobile.activity;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.view.View;

import java.util.List;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/4/16
 * Time: 14:44
 * To change this template use File | Settings | File Templates.
 */
public class TabPagerAdapter extends FragmentPagerAdapter {

    FragmentManager fragmentManager;
    List<Fragment> fragments;

    public TabPagerAdapter(FragmentManager fm,List<Fragment> fragments) {
        super(fm);
        this.fragmentManager = fm;
        this.fragments = fragments;
    }


    @Override
    public int getCount() {
        return fragments.size();
    }

    @Override
    public int getItemPosition(Object object) {
        return super.getItemPosition(object);
    }

    @Override
    public Fragment getItem(int position) {
        return fragments.get(position);
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return false;
    }

}
