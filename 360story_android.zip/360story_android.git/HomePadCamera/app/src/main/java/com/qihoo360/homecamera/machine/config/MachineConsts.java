package com.qihoo360.homecamera.machine.config;

import android.text.TextUtils;

/**
 * Created by lixin3-s on 2016/11/7.
 */
public class MachineConsts {

    public static class SettingMachineItem {

        public static final String MACHINE_ABOUT_ITEM = "MACHINE_ABOUT_ITEM";
    }

    // aes加密私钥
    public static final String AEC_KEY = "sfe023f_9fd&fwfl";

    public static final String SN = "sn";
    public static final String DEVICEINFO = "deviceInfo";
    public static final String ALBUM_ID = "album_id";
    public static final String IS_DEMO = "is_demo";

}
