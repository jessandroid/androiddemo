package com.qihoo360.homecamera.machine.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.CycleInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.qihoo360.homecamera.machine.entity.Wifi;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.activity.BaseActivity;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.FileUtil;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.util.Hashtable;

public class AddCameraQRActivity extends MachineBaseActivity implements View.OnClickListener {

    private int QR_WIDTH = 200, QR_HEIGHT = 200;
    private int LOGO_WIDTH = QR_WIDTH / 5, LOGO_HEIGHT = QR_HEIGHT / 5;
    private ViewTreeObserver vto2;
    private Wifi wifi;
    private Button btnQRscanComplete;
    private boolean ISSMALL = false;
    private View sendVoiceView;
    Animation failedAnimation;

    private MediaPlayer mMediaPlayer;

    Handler handlerTime = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_camera_qr);

        TextView tv_add_title = (TextView) findViewById(R.id.tv_add_title);
        tv_add_title.setText(getString(R.string.add_second_step));

        if (!Utils.isChinese()) {
            findViewById(R.id.tv_add_guide2_title).setVisibility(View.GONE);
        }

        sendVoiceView = findViewById(R.id.iv_send_sound);
        sendVoiceView.setOnClickListener(this);

        btnQRscanComplete = (Button) findViewById(R.id.btn_QRscan_complete);
        btnQRscanComplete.setOnClickListener(this);

        failedAnimation = AnimationUtils.loadAnimation(this, R.anim.right_in_notification);

        img_QR = (ImageView) findViewById(R.id.img_QR);
        vto2 = img_QR.getViewTreeObserver();
        wifi = (Wifi) getIntent().getSerializableExtra("Wifi");
        vto2.addOnGlobalLayoutListener(new OnGlobalLayoutListener() {
            @SuppressWarnings("deprecation")
            @Override
            public void onGlobalLayout() {
                img_QR.getViewTreeObserver().removeGlobalOnLayoutListener(this);
                if (img_QR.getWidth() < img_QR.getHeight()) {
                    QR_WIDTH = img_QR.getWidth();
                    QR_HEIGHT = QR_WIDTH;
                    ISSMALL = false;
                } else {
                    QR_WIDTH = img_QR.getHeight();
                    QR_HEIGHT = QR_WIDTH;
                    ISSMALL = true;
                }

                initSounds();

                LOGO_WIDTH = QR_WIDTH / 5;
                LOGO_HEIGHT = LOGO_WIDTH;
                try {
                    if (wifi != null) {
                        createQRImage(wifi.getQRcode());
                    }
                } catch (WriterException e) {
                    e.printStackTrace();
                }
            }
        });

        handlerTime.postDelayed(runnable, 60000);
    }

    @Override
    protected void onStop() {
        super.onStop();
        mMediaPlayer.stop();
        handlerTime.removeCallbacks(runnable);
    }

    public void createQRImage(String url, Bitmap logo) throws WriterException {

        Hashtable<EncodeHintType, Object> hints = new Hashtable<EncodeHintType, Object>();
        if (ISSMALL) {
            hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.M);
        } else {
            hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
        }
        hints.put(EncodeHintType.CHARACTER_SET, "utf-8");
        hints.put(EncodeHintType.MARGIN, 1);

        BitMatrix matrix =
                new MultiFormatWriter().encode(url, BarcodeFormat.QR_CODE, QR_WIDTH, QR_HEIGHT,
                        hints);
        int width = matrix.getWidth();
        int height = matrix.getHeight();
        int halfW = width / 2;
        int halfH = height / 2;
        int[] pixels = new int[width * height];
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                if (x > halfW - LOGO_WIDTH / 2 && x < halfW + LOGO_WIDTH / 2
                        && y > halfH - LOGO_HEIGHT / 2 && y < halfH + LOGO_HEIGHT / 2) {

                    pixels[y * width + x] =
                            logo.getPixel(x - halfW + LOGO_WIDTH / 2, y - halfH + LOGO_HEIGHT / 2);
                } else {
                    if (matrix.get(x, y)) {
                        pixels[y * width + x] = 0xff000000;
                    } else {
                        pixels[y * width + x] = 0xffffffff;
                    }
                }

            }
        }
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        bitmap.setPixels(pixels, 0, width, 0, 0, width, height);
        img_QR.setImageBitmap(bitmap);
    }

    public void createQRImage(String url) throws WriterException {
        Hashtable<EncodeHintType, Object> hints = new Hashtable<EncodeHintType, Object>();
        if (ISSMALL) {
            hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.M);
        } else {
            hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
        }
        hints.put(EncodeHintType.CHARACTER_SET, "utf-8");
        hints.put(EncodeHintType.MARGIN, 1);

        BitMatrix matrix =
                new MultiFormatWriter().encode(url, BarcodeFormat.QR_CODE, QR_WIDTH, QR_HEIGHT,
                        hints);
        int width = matrix.getWidth();
        int height = matrix.getHeight();
        int[] pixels = new int[width * height];
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                if (matrix.get(x, y)) {
                    pixels[y * width + x] = 0xff000000;
                } else {
                    pixels[y * width + x] = 0xffffffff;
                }
            }
        }
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        bitmap.setPixels(pixels, 0, width, 0, 0, width, height);
        img_QR.setImageBitmap(bitmap);
    }

    @Override
    public void onClick(View arg0) {
        if (arg0.getId() == R.id.btn_QRscan_complete) {
            if (Utils.isNetworkAvailable(Utils.getContext())) {
                Intent intent = new Intent(this, AddCameraWaitActivity.class);
                intent.putExtra("Wifi", wifi);
                startActivity(intent);
                finish();
                overridePendingTransition(0, 0);
            } else {
                CameraToast.show(this, getString(R.string.network_disabled), 0);
            }
        } else if (arg0.getId() == R.id.iv_send_sound) {
            CLog.d("Change to Sound");
            if (testStorage()) {
                mMediaPlayer.stop();
                Intent intent = new Intent(this, AddCameraSoundActivity.class);
                intent.putExtra("Wifi", wifi);
                startActivity(intent);
                finish();
                overridePendingTransition(0, 0);
            }
        }
    }

    private boolean testStorage() {
        if (FileUtil.getInstance().getAvailableSpare() > 10) return true;

        CameraToast.show(AddCameraQRActivity.this, R.string.sound_no_storage, Toast.LENGTH_SHORT);
        return false;
    }

    @SuppressLint("UseSparseArrays")
    public void initSounds() {
        mMediaPlayer = MediaPlayer.create(this, R.raw.scan);
        mMediaPlayer.start();
    }

    Runnable runnable = new Runnable() {
        @Override
        public void run() {
            setFailed();
            handlerTime.removeCallbacks(runnable);
        }
    };
    private ImageView img_QR;

    public void setFailed() {
        CLog.d("setFailed");
        sendVoiceView.startAnimation(shakeAnimation(5));
    }

    public Animation shakeAnimation(int CycleTimes) {
        Animation translateAnimation = new TranslateAnimation(3, -3, 3, -3);
        translateAnimation.setInterpolator(new CycleInterpolator(CycleTimes));
        translateAnimation.setDuration(500);
        return translateAnimation;
    }

    @Override
    public void onBackPressed() {
        finish();
        overridePendingTransition(0, 0);
    }
}
