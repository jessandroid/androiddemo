package com.qihoo360.homecamera.mobile.activity;

import android.content.ClipData;
import android.content.ClipDescription;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.ContentObserver;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.entity.InnerMsg;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.ui.fragment.PadRelaxActivity;
import com.qihoo360.homecamera.mobile.utils.CameraToast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by zhaojunbo on 2015/12/10.
 * desc:
 */
public class ShareWordActivity extends BaseActivity implements View.OnClickListener, ActionListener {

    private static final int TASKGETSHAREINFO = 1;
    private static final int TASKACCEPTSHARE = 2;

    private ImageView mBackIv;
    private EditText mShareWordEt;
    private Button mShareWordOkBt;
    private SmsObserver mSmsObserver;
    private ClipboardManager mClipboardManager = null;
    private Uri SMS_INBOX = Uri.parse("content://sms/");
    private ClipboardManager.OnPrimaryClipChangedListener mOnPrimaryClipChangedListener;
    private String mShareWord;
    private String mSharerName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        initView();

        mSmsObserver = new SmsObserver(this, smsHandler);
        getContentResolver().registerContentObserver(SMS_INBOX, true, mSmsObserver);
        mClipboardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        GlobalManager.getInstance().getShareManager().registerActionListener(this);
    }

    private void initView() {
        setTintManagerQWork(true);
        tintManager.setStatusBarTintColor(Color.parseColor("#0000aeff"));
        setContentView(R.layout.activity_add_camera_share_word);
        mBackIv = (ImageView) findViewById(R.id.iv_back);
        mBackIv.setOnClickListener(this);
        mShareWordEt = (EditText) findViewById(R.id.et_share_word);
        mShareWordOkBt = (Button) findViewById(R.id.bt_share_word_ok);
        mShareWordOkBt.setOnClickListener(this);
    }

    private void initAndGetClipBoard(){
        ClipData.Item item = null;
        if(!mClipboardManager.hasPrimaryClip() && TextUtils.isEmpty(mShareWordEt.getText())){
            showSoftInput();
            return ;
        }
        if (mClipboardManager.getPrimaryClipDescription().hasMimeType(
                ClipDescription.MIMETYPE_TEXT_PLAIN)) {
            ClipData cdText = mClipboardManager.getPrimaryClip();
            item = cdText.getItemAt(0);
            if(item.getText() != null){
                getPatternCode(item.getText().toString());

                ClipData textCd = ClipData.newPlainText("", "");
                mClipboardManager.setPrimaryClip(textCd);
            } else if (item.getText() == null && TextUtils.isEmpty(mShareWordEt.getText())) {
                showSoftInput();
            }
        }
    }

    private void showSoftInput() {
        mShareWordEt.setFocusable(true);
        mShareWordEt.setFocusableInTouchMode(true);
        mShareWordEt.requestFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.showSoftInput(mShareWordEt, InputMethodManager.SHOW_FORCED);
    }

    private void getPatternCode(String body) {
        String result = null;
        Pattern pattern = Pattern.compile("shareCode=([a-zA-Z0-9]{8})&|^([a-zA-Z0-9]{8})$" , Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(body);
        if (matcher.find()) {
            result = matcher.group(1);
            if (result == null) {
                result = matcher.group(2);
            }
        }
        if (result != null) {
            mShareWordEt.setText(result);
            mShareWordEt.setSelection(result.length());
        } else if(result == null && TextUtils.isEmpty(mShareWordEt.getText())) {
            showSoftInput();
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bt_share_word_ok:
                mShareWord = mShareWordEt.getText().toString();
                if (!TextUtils.isEmpty(mShareWord)) {
                    GlobalManager.getInstance().getShareManager().asyncShareAccept("", mShareWord, "1");
                }
                break;
            case R.id.iv_back:
                finish();
                break;
        }
    }

    @Override
    public Object actionPerformed(int actionCode, Object... args) {
        switch (actionCode) {
            case Actions.Share.SHARE_ACCEPT_SUCCESS: {
                getProgressDialog().dismiss();
                CameraToast.showToast(this, "添加摄像机成功");
                if (((String) args[0]).equals("1")) {
                    Intent relaxIntent = new Intent(this, PadRelaxActivity.class);
                    relaxIntent.putExtra("sn", (String) args[1]);
                    relaxIntent.putExtra("is_master", false);
                    startActivity(relaxIntent);
                }
                setResult(1002);
                finish();
                return Boolean.TRUE;
            }
            case Actions.Share.SHARE_ACCEPT_FAIL: {
                getProgressDialog().dismiss();
                CameraToast.showErrorToast(ShareWordActivity.this, (String) args[1]);
//                if ((int) args[0] == 26) {
//                    CameraToast.showErrorToast(ShareWordActivity.this, R.string.tips_31);
//                }  else if((int) args[0] == 61) {
//                    CameraToast.showErrorToast(ShareWordActivity.this, (String) args[1]);
//                } else {
//                    CameraToast.showErrorToast(ShareWordActivity.this, R.string.tips_30);
//                }
                return Boolean.TRUE;
            }

            default:
                break;
        }
        return null;
    }

    public Handler smsHandler = new Handler() {
        public void handleMessage(Message msg) {
        }
    };

    public void getSmsFromPhone() {
        ContentResolver cr = getContentResolver();
        String[] projection = new String[] { "body","address","person"};
        String where = " date >  "
                + (System.currentTimeMillis() - 10 * 60 * 1000);
        Cursor cur = cr.query(SMS_INBOX, projection, where, null, "date desc");
        if (null == cur)
            return;
        if (cur.moveToNext()) {
            String body = cur.getString(cur.getColumnIndex("body"));
            getPatternCode(body);
        }
        cur.close();
    }

    class SmsObserver extends ContentObserver {

        public SmsObserver(Context context, Handler handler) {
            super(handler);
        }

        @Override
        public void onChange(boolean selfChange) {
            super.onChange(selfChange);
            getSmsFromPhone();
        }
    }

    @Override
    public void finish() {
        mClipboardManager.removePrimaryClipChangedListener(mOnPrimaryClipChangedListener);
        getContentResolver().unregisterContentObserver(mSmsObserver);
        super.finish();
    }

    @Override
    protected void onResume() {
        initAndGetClipBoard();
        super.onResume();
    }

    @Override
    protected void switchMode(boolean speaker_mode) {
        super.switchMode(speaker_mode);
    }

    @Override
    public void onMessage(InnerMsg imsg) {
        super.onMessage(imsg);
    }

    @Override
    public void setTintManagerQWork(boolean work) {
        super.setTintManagerQWork(work);
    }

    @Override
    public int getProperty() {
        return 0;
    }

    @Override
    protected void onDestroy() {
        GlobalManager.getInstance().getShareManager().removeActionListener(this);
        super.onDestroy();
    }
}
