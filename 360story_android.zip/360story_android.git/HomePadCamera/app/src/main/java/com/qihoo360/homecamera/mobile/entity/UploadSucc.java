package com.qihoo360.homecamera.mobile.entity;

import com.google.gson.Gson;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/3/2
 * Time: 15:15
 * To change this template use File | Settings | File Templates.
 */
public class UploadSucc {

    /**
     * bucket : pad-master-album-sh
     * object : bf2d03f0335739b96cbbf4dfc801ff37.jpg
     * fsize : 483477
     * fhash : 38fe3128f3ccdf34384c941500c71ba12be87456
     */

    private String bucket;
    private String object;
    private String fsize;
    private String fhash;
    public int errorCode;
    public String ems;

    public void setBucket(String bucket) {
        this.bucket = bucket;
    }

    public void setObject(String object) {
        this.object = object;
    }

    public void setFsize(String fsize) {
        this.fsize = fsize;
    }

    public void setFhash(String fhash) {
        this.fhash = fhash;
    }

    public String getBucket() {
        return bucket;
    }

    public String getObject() {
        return object;
    }

    public String getFsize() {
        return fsize;
    }

    public String getFhash() {
        return fhash;
    }

    @Override
    public String toString() {
        Gson gson = new Gson();
        return gson.toJson(this);
    }
}
