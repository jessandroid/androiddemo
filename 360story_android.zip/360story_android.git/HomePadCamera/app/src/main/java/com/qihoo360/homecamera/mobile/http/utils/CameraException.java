
package com.qihoo360.homecamera.mobile.http.utils;

import com.qihoo360.homecamera.mobile.entity.Head;

import java.io.IOException;

/**
 * User: Tomcat
 * Date: 2016/1/18
 * Time: 16:28
 * To change this template use File | Settings | File Templates.
 */
public class CameraException extends IOException {

    private static final long serialVersionUID = 1L;

    private int errorCode;

    public CameraException(String message) {
        super(message);
    }

    public CameraException(int errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
    }

    public int getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }

    public Head head() {
        Head head = new Head();
        head.errorCode = this.errorCode;
        head.errorMsg = this.getMessage();
        return head;
    }

}
