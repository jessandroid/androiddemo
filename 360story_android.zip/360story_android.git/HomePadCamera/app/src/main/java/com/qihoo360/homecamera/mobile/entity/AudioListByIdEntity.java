package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

/**
 * Created by zhaojunbo on 2016/3/26.
 * desc:
 */
public class AudioListByIdEntity extends Head{

    public Data data;

    public static class Data implements Parcelable {

        public AlbumInfo albumInfo;
        public PageInfo pageInfo;
        public ArrayList<DetailListInfo> data;

        public static class AlbumInfo implements Parcelable{
            public String albumId;
            public String title;
            public String imageUrl;
            public String describe;
            public String contentNum;
            public String playNum;

            @Override
            public int describeContents() {
                return 0;
            }

            @Override
            public void writeToParcel(Parcel dest, int flags) {
                dest.writeString(this.albumId);
                dest.writeString(this.title);
                dest.writeString(this.imageUrl);
                dest.writeString(this.describe);
                dest.writeString(this.contentNum);
                dest.writeString(this.playNum);
            }

            public AlbumInfo() {
            }

            protected AlbumInfo(Parcel in) {
                this.albumId = in.readString();
                this.title = in.readString();
                this.imageUrl = in.readString();
                this.describe = in.readString();
                this.contentNum = in.readString();
                this.playNum = in.readString();
            }

            public static final Creator<AlbumInfo> CREATOR = new Creator<AlbumInfo>() {
                public AlbumInfo createFromParcel(Parcel source) {
                    return new AlbumInfo(source);
                }

                public AlbumInfo[] newArray(int size) {
                    return new AlbumInfo[size];
                }
            };
        }

        public static class PageInfo implements Parcelable{
            public int totalPage ;
            public int page;
            public int pageSize;
            public int sortType;

            @Override
            public int describeContents() {
                return 0;
            }

            @Override
            public void writeToParcel(Parcel dest, int flags) {
                dest.writeInt(this.totalPage);
                dest.writeInt(this.page);
                dest.writeInt(this.pageSize);
                dest.writeInt(this.sortType);
            }

            public PageInfo() {
            }

            protected PageInfo(Parcel in) {
                this.totalPage = in.readInt();
                this.page = in.readInt();
                this.pageSize = in.readInt();
                this.sortType = in.readInt();
            }

            public static final Creator<PageInfo> CREATOR = new Creator<PageInfo>() {
                public PageInfo createFromParcel(Parcel source) {
                    return new PageInfo(source);
                }

                public PageInfo[] newArray(int size) {
                    return new PageInfo[size];
                }
            };
        }

        public static class DetailListInfo implements Parcelable {
            public String audiId;
            public String title;
            public String albumId;
            public String duration;
            public String playNum;
            public String audi32Size;
            public String audi64Size;
            public String audi32Url;
            public String audi64Url;
            public String displayOrder;

            @Override
            public int describeContents() {
                return 0;
            }

            @Override
            public void writeToParcel(Parcel dest, int flags) {
                dest.writeString(this.audiId);
                dest.writeString(this.title);
                dest.writeString(this.albumId);
                dest.writeString(this.duration);
                dest.writeString(this.playNum);
                dest.writeString(this.audi32Size);
                dest.writeString(this.audi64Size);
                dest.writeString(this.audi32Url);
                dest.writeString(this.audi64Url);
                dest.writeString(this.displayOrder);
            }

            public DetailListInfo() {
            }

            protected DetailListInfo(Parcel in) {
                this.audiId = in.readString();
                this.title = in.readString();
                this.albumId = in.readString();
                this.duration = in.readString();
                this.playNum = in.readString();
                this.audi32Size = in.readString();
                this.audi64Size = in.readString();
                this.audi32Url = in.readString();
                this.audi64Url = in.readString();
                this.displayOrder = in.readString();
            }

            public static final Creator<DetailListInfo> CREATOR = new Creator<DetailListInfo>() {
                public DetailListInfo createFromParcel(Parcel source) {
                    return new DetailListInfo(source);
                }

                public DetailListInfo[] newArray(int size) {
                    return new DetailListInfo[size];
                }
            };
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeParcelable(this.albumInfo, 0);
            dest.writeParcelable(this.pageInfo, 0);
            dest.writeTypedList(data);
        }

        public Data() {
        }

        protected Data(Parcel in) {
            this.albumInfo = in.readParcelable(AlbumInfo.class.getClassLoader());
            this.pageInfo = in.readParcelable(PageInfo.class.getClassLoader());
            this.data = in.createTypedArrayList(DetailListInfo.CREATOR);
        }

        public static final Creator<Data> CREATOR = new Creator<Data>() {
            public Data createFromParcel(Parcel source) {
                return new Data(source);
            }

            public Data[] newArray(int size) {
                return new Data[size];
            }
        };
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeParcelable(this.data, 0);
    }

    public AudioListByIdEntity() {
    }

    protected AudioListByIdEntity(Parcel in) {
        super(in);
        this.data = in.readParcelable(Data.class.getClassLoader());
    }

    public static final Creator<AudioListByIdEntity> CREATOR = new Creator<AudioListByIdEntity>() {
        public AudioListByIdEntity createFromParcel(Parcel source) {
            return new AudioListByIdEntity(source);
        }

        public AudioListByIdEntity[] newArray(int size) {
            return new AudioListByIdEntity[size];
        }
    };
}
