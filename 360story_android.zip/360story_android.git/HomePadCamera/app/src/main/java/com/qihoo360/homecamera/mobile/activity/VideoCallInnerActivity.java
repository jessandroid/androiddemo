
package com.qihoo360.homecamera.mobile.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.media.AudioManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.justalk.cloud.lemon.MtcApi;
import com.justalk.cloud.lemon.MtcBuddy;
import com.justalk.cloud.lemon.MtcBuddyConstants;
import com.justalk.cloud.lemon.MtcCall;
import com.justalk.cloud.lemon.MtcCallConstants;
import com.justalk.cloud.lemon.MtcCallExt;
import com.justalk.cloud.lemon.MtcCli;
import com.justalk.cloud.lemon.MtcCliConstants;
import com.justalk.cloud.lemon.MtcConstants;
import com.justalk.cloud.lemon.MtcMdm;
import com.justalk.cloud.lemon.MtcMediaConstants;
import com.justalk.cloud.lemon.MtcUser;
import com.justalk.cloud.lemon.MtcUserConstants;
import com.justalk.cloud.zmf.Zmf;
import com.justalk.cloud.zmf.ZmfAudio;
import com.justalk.cloud.zmf.ZmfObserver;
import com.justalk.cloud.zmf.ZmfVideo;
import com.qihoo360.homecamera.mobile.BuildConfig;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.config.Const;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.ui.NewSwitchView;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.PhoneUtil;
import com.qihoo360.homecamera.mobile.utils.Preferences;
import com.qihoo360.homecamera.mobile.utils.QHStatAgentHelper;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.widget.TextViewWithFont;
import com.qihoo360.homecamera.mobile.widget.howling.HowlingWindowMgr;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

/**
 * 视频监控
 *
 * @author lvpeng-s
 */
public class VideoCallInnerActivity extends InnerOrOutgoingBaseActivity implements OnClickListener, ZmfObserver {

    private TextViewWithFont mCommonTime;
    private ImageView mCommonShotScreenLayout;
    private LinearLayout mLoadingAreaLl;
    private ImageView mInnerLoading;

    public final static String PAD_HOWLING = "1";
    public final static String PAD_HOWLING_END = "0";

    private NewSwitchView mSwitchView;
    private SurfaceView mRemoteView;
    private ViewGroup mViewMain;
    private BroadcastReceiver mCallConnectingReceiver;
    private BroadcastReceiver mCallTermedkReceiver;
    private BroadcastReceiver mCallTalkingReceiver;
    private BroadcastReceiver mCallAlertedReceiver;
    private BroadcastReceiver mOutgoingCallCloseReceiver;
    private BroadcastReceiver mAccountChangeReceiver;
    private BroadcastReceiver mInnerCloseReceiver;
    private BroadcastReceiver mCallNetworkStatusChangedReceiver;
    private BroadcastReceiver mCallVideoReceiveStatusChangedReceiver;
    private BroadcastReceiver mMtcBuddyQueryLoginPropertiesOkNotification;
    private BroadcastReceiver mMtcBuddyQueryLoginPropertiesDidFailNotification;
    private BroadcastReceiver mMediaHowlingDetectedReceiver;
    private BroadcastReceiver mMediaHowlingEndReceiver;
    private BroadcastReceiver mMCallInfoReceiver;
    private int mCallSecond = 0;
    private Runnable mTimerRunnable;
    private Runnable mAutoVideoShotDelay;
    private Runnable mRetryDelay;
    private int mRetrySeconds = 0;
    private boolean mConnecting = true;
    private boolean mIsFinish = false;
    private LinearLayout mRetryLl;
    private TextView mDisableTipsTv;
    private ImageView mBgInnerIv;
    private boolean mHasShowDisconnected = false;
    private Runnable mDisconnectedRunnable;
    private Runnable mNoiseRunnable;
    private Runnable mStopCallRunnable;
    private Runnable mToolBarShowRunnable;
    private View mSnapshotSplash;
    private boolean hasPreFinish = false;
    private boolean hasFinish = false;

    private LinearLayout mBottomToolBar;
    private LinearLayout mRightToolBar;
    private RelativeLayout mTopToolBar;
    private boolean bToolBarShowing = false;

    private TextView mNetworkSpeed;
    private ImageView mNetworkSpeedArrow;
    private LinearLayout mNetWorkSpeedLayout;
    private Runnable mNetworkSpeedCheckRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        Intent intent = getIntent();
        if (intent == null || intent.getExtras() == null) {
            return;
        }
        mDeviceInfo = intent.getExtras().getParcelable("deviceInfo");
        Constants.IS_CALLING_OR_INNER = true;
        Constants.IS_INNER = true;
        Constants.HAS_SHOW_NOISE_HIGH = false;
        mIsRecording = false;

        initReceiver();
        initRunnable();
        initView();
        startCall();
        if (!Utils.isNetworkAvailable(this)) {
            mStopCallRunnable = new Runnable() {
                @Override
                public void run() {
                    //showCustomToast(getResources().getString(R.string.net_tips_1), Toast.LENGTH_SHORT);
                    callInterrupt(getString(R.string.net_tips_1), MtcCallConstants.EN_MTC_CALL_TERM_STATUS_NORMAL);
                }
            };
            mTimerHandler.postDelayed(mStopCallRunnable, 3000);
        }
        bToolBarShowing = true;
        mNetWorkSpeedLayout.setVisibility(View.GONE);
        mTimerHandler.postDelayed(mToolBarShowRunnable, 3000);
    }

    private void showToolBar(boolean show){
        if (!mRecordBtnIv.isEnabled() || !mCommonShotScreenLayout.isEnabled()) {
            mNetWorkSpeedLayout.setVisibility(View.GONE);
            mBottomToolBar.setVisibility(View.VISIBLE);
            mRightToolBar.setVisibility(View.VISIBLE);
            mTopToolBar.setVisibility(View.VISIBLE);
            return;
        }
        if (mBottomToolBar != null && mRightToolBar != null && mTopToolBar != null && mNetWorkSpeedLayout != null){
            mBottomToolBar.setVisibility(show ? View.VISIBLE : View.GONE);
            mRightToolBar.setVisibility(show ? View.VISIBLE : View.GONE);
            mTopToolBar.setVisibility(show ? View.VISIBLE : View.GONE);
            mNetWorkSpeedLayout.setVisibility(show ? View.VISIBLE : View.GONE);
            if (mIsRecording){
                mTopToolBar.setVisibility(View.VISIBLE);
            }
        }
        bToolBarShowing = show;
    }

    private void startCall() {
        LocalBroadcastManager.getInstance(this).registerReceiver(mCallTalkingReceiver, new IntentFilter(MtcCallConstants.MtcCallTalkingNotification));
        LocalBroadcastManager.getInstance(this).registerReceiver(mCallAlertedReceiver, new IntentFilter(MtcCallConstants.MtcCallAlertedNotification));
        LocalBroadcastManager.getInstance(this).registerReceiver(mCallConnectingReceiver, new IntentFilter(MtcCallConstants.MtcCallConnectingNotification));
        LocalBroadcastManager.getInstance(this).registerReceiver(mCallTermedkReceiver, new IntentFilter(MtcCallConstants.MtcCallTermedNotification));
        LocalBroadcastManager.getInstance(this).registerReceiver(mCallNetworkStatusChangedReceiver, new IntentFilter(MtcCallConstants.MtcCallNetworkStatusChangedNotification));
        LocalBroadcastManager.getInstance(this).registerReceiver(mCallVideoReceiveStatusChangedReceiver, new IntentFilter(MtcCallConstants.MtcCallVideoReceiveStatusChangedNotification));
//        LocalBroadcastManager.getInstance(this).registerReceiver(mMtcBuddyQueryLoginPropertiesOkNotification, new IntentFilter(MtcBuddyConstants.MtcBuddyQueryLoginPropertiesOkNotification));
//        LocalBroadcastManager.getInstance(this).registerReceiver(mMtcBuddyQueryLoginPropertiesDidFailNotification, new IntentFilter(MtcBuddyConstants.MtcBuddyQueryLoginPropertiesDidFailNotification));
        LocalBroadcastManager.getInstance(this).registerReceiver(mMediaHowlingDetectedReceiver, new IntentFilter(MtcMediaConstants.MtcMediaHowlingDetectedNotification));
        LocalBroadcastManager.getInstance(this).registerReceiver(mMediaHowlingEndReceiver, new IntentFilter(MtcMediaConstants.MtcMediaHowlingEndNotification));
        LocalBroadcastManager.getInstance(this).registerReceiver(mMCallInfoReceiver, new IntentFilter(MtcCallConstants.MtcCallInfoReceivedNotification));
        callJustalk(1);
    }

    private void initRunnable() {
        mTimerRunnable = new Runnable() {
            @Override
            public void run() {
                if (!mConnecting) {
                    mCallSecond++;
                }
                if (!mIsRecording) {
                    mCommonTime.setText(PhoneUtil.formatTime(mCallSecond));
                } else {
                    mCommonTime.setText(PhoneUtil.formatTime(mRecordingSecond));
                    mRecordingSecond++;
                }
                if (mTimerHandler != null) {
                    mTimerHandler.postDelayed(mTimerRunnable, 1000);
                }
            }
        };

        mDisconnectedRunnable = new Runnable() {
            @Override
            public void run() {
                showCustomToast(getString(R.string.tips_15), Toast.LENGTH_SHORT);
                CLog.e("zhaojunbo", getString(R.string.tips_15));
                preFinish();
            }
        };

        mVideoShotRunnable = new Runnable() {
            @Override
            public void run() {
                if (mShotFrameLayout != null) {
                    mShotFrameLayout.setVisibility(View.INVISIBLE);
                }
            }
        };

        mAutoVideoShotDelay = new Runnable() {
            @Override
            public void run() {
                saveCoverImg();
            }
        };

        mRetryDelay = new Runnable() {
            @Override
            public void run() {
                if (mRetrySeconds >= 15) {
                    callInterrupt(getString(R.string.tips_38), MtcCallConstants.EN_MTC_CALL_TERM_STATUS_NORMAL);
                    return;
//                    if (MtcCli.Mtc_CliGetState() == MtcCliConstants.EN_MTC_CLI_STATE_LOGINED) {
//                        callInterrupt(getString(R.string.tips_38), MtcCallConstants.EN_MTC_CALL_TERM_STATUS_NORMAL);
//                        return;
//                    } else {
//                        callInterrupt(getString(R.string.tips_39), MtcCallConstants.EN_MTC_CALL_TERM_STATUS_NORMAL);
//                    }

                }

                if (mRetrySeconds == 3) {
                    String uri = MtcUser.Mtc_UserFormUri(MtcUserConstants.EN_MTC_USER_ID_USERNAME, mDeviceInfo.getSn());
                    MtcBuddy.Mtc_BuddyQueryLoginProperties(0, uri);
//                    callInterrupt(getString(R.string.tips_87), MtcCallConstants.EN_MTC_CALL_TERM_STATUS_NORMAL);
                }
                if (mRetrySeconds == 7) {
                    //showCustomToast("对方网络不太稳定，请稍候...", Toast.LENGTH_SHORT);
                }
                mRetrySeconds++;
                if (mTimerHandler != null) {
                    mTimerHandler.postDelayed(mRetryDelay, 1000);
                }
            }
        };

        mNoiseRunnable = new Runnable() {
            @Override
            public void run() {
                //showCustomToast(getString(R.string.tips_70), Toast.LENGTH_LONG);
                if (Preferences.getIsShowHowlingTips() == false){
                    CLog.e("howling", "showing toast");
                    //showHowlingDialog();
                    HowlingWindowMgr.show(VideoCallInnerActivity.this, getString(R.string.tips_70));
                    Constants.HAS_SHOW_NOISE_HIGH = true;
                }
            }
        };

        mToolBarShowRunnable = new Runnable() {
            @Override
            public void run() {
                showToolBar(false);
            }
        };

        mNetworkSpeedCheckRunnable = new Runnable() {
            @Override
            public void run() {
                String msg = MtcCall.Mtc_CallVideoGetStatus(mCallId, MtcCallConstants.MTC_CALL_STATUS_RECV_BITRATE
                        | MtcCallConstants.MTC_CALL_STATUS_SEND_BITRATE);
                String speed = "0";
                try {
                    JSONObject json = (JSONObject) new JSONTokener(msg).nextValue();
                    speed = json.getString("MtcRecvBitRateKey") + "KB/S";
                } catch (Exception e){
                    e.printStackTrace();
                    return;
                }
                mNetworkSpeed.setText(speed);
                mTimerHandler.postDelayed(mNetworkSpeedCheckRunnable, 5000);
                CLog.e("hyuan","Mtc_CallVideoGetStatus get:" + msg);
                //CLog.justalkFile("Mtc_CallVideoGetStatus get MtcRecvBitRateKey:" + speed);
            }
        };

        mTimerHandler.postDelayed(mRetryDelay, 1000);
    }

    @Override
    protected void initReceiver() {
        Zmf.addObserver(this);
        mCallTermedkReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                CLog.e("justalk", "mCallTermedkReceiver===============");
                if (!judgeNeedProcess(intent, mCallId)) {
                    return;
                }

                try {
                    String info = intent.getStringExtra(MtcApi.EXTRA_INFO);
                    CLog.json("phone_call", info);
                    JSONObject json = (JSONObject) new JSONTokener(info).nextValue();
                    int dwStatusCode = json.getInt(MtcCallConstants.MtcCallStatusCodeKey);
                    String state = json.optString(MtcCallConstants.MtcCallDescriptionKey);
                    int callId = json.getInt(MtcCallConstants.MtcCallIdKey);
                    if (callId != mCallId) {
                        return;
                    }
                    QHStatAgentHelper.uploadEndCallStick(callId + "", dwStatusCode + "", 0 + "");
                    switch (dwStatusCode) {
                        case Constants.TermReason.TERM_MONITOR_DISABLED:
                            //showCustomToast(getString(R.string.tips_37), Toast.LENGTH_LONG);
                            CLog.justalkFile("mCallTermedkReceiver----->TERM_MONITOR_DISABLED， callId:" + mCallId);
                            callInterrupt(getString(R.string.tips_37), Constants.TermReason.TERM_MONITOR_DISABLED);
                            break;
                        case Constants.TermReason.TERM_SHARE_REMOVED:
                            if (!mIsFinish) {
                                mIsFinish = true;
                                showCustomToast(getString(R.string.net_tips_3), Toast.LENGTH_SHORT);
                                CLog.justalkFile("mCallTermedkReceiver----->TERM_SHARE_REMOVED， callId:" + mCallId);
                                preFinish();
                            }
                            break;
//                        case MtcCallConstants.EN_MTC_CALL_TERM_STATUS_BUSY:
//                            if (!mIsFinish) {
//                                mIsFinish = true;
//                                showCustomToast("对方忙", Toast.LENGTH_LONG);
//                                CLog.justalkFile("mCallTermedkReceiver----->EN_MTC_CALL_TERM_STATUS_BUSY， callId:" + mCallId);
//                                preFinish();
//                            }
//                            break;
                        case Constants.TermReason.TERM_NO_DISTURB:
                            callInterrupt(getString(R.string.tips_77), Constants.TermReason.TERM_NO_DISTURB);
                            CLog.justalkFile("mCallTermedkReceiver----->TERM_NO_DISTURB， callId:" + mCallId);
                            break;
                        case Constants.TermReason.TERM_NO_DISTURB_INTERRUPT:
                            callInterrupt(getString(R.string.tips_76), Constants.TermReason.TERM_NO_DISTURB_INTERRUPT);
                            CLog.justalkFile("mCallTermedkReceiver----->TERM_NO_DISTURB_INTERRUPT， callId:" + mCallId);
                            break;
                        case Constants.TermReason.TERM_CALL_INTERRUPT_MONITOR:
                            callInterrupt(getString(R.string.tips_85), Constants.TermReason.TERM_CALL_INTERRUPT_MONITOR);
                            CLog.justalkFile("mCallTermedkReceiver----->TERM_CALL_INTERRUPT_MONITOR， callId:" + mCallId);
                            break;
                        case MtcCallConstants.EN_MTC_CALL_TERM_STATUS_BUSY:
                            callInterrupt(getString(R.string.tips_52), MtcCallConstants.EN_MTC_CALL_TERM_STATUS_BUSY);
                            CLog.justalkFile("mCallTermedkReceiver----->EN_MTC_CALL_TERM_STATUS_BUSY， callId:" + mCallId);
                            break;
                        case Constants.TermReason.TERM_MONITOR_INTERRUPT:
                            callInterrupt(getString(R.string.tips_50), Constants.TermReason.TERM_MONITOR_INTERRUPT);
                            CLog.justalkFile("mCallTermedkReceiver----->TERM_MONITOR_INTERRUPT， callId:" + mCallId);
                            break;
//                            if (!mIsFinish) {
//                                mIsFinish = true;
//                                showCustomToast("对方忙，即将退出查看", Toast.LENGTH_LONG);
//                                CLog.justalkFile("mCallTermedkReceiver----->TERM_MONITOR_INTERRUPT， callId:" + mCallId);
//                                preFinish();
//                            }
//                            break;
                        case Constants.TermReason.TERM_NO_AUTHORITY:
                            //showCustomToast(getString(R.string.manger_close_remote_watch), Toast.LENGTH_LONG);
                            callInterrupt(getString(R.string.manger_close_remote_watch), Constants.TermReason.TERM_MONITOR_INTERRUPT);
                            CLog.justalkFile("mCallTermedkReceiver----->TERM_NO_AUTHORITY， callId:" + mCallId);
                            break;
                        default:
                            if (!mIsFinish) {
                                mIsFinish = true;
                                CLog.justalkFile("mCallTermedkReceiver----->default0， callId:" + mCallId);
                                if (state != null && !TextUtils.isEmpty(state)) {
                                    JSONObject msg = new JSONObject(state);
                                    showCustomToast(msg.optString("reason_msg", ""), Toast.LENGTH_LONG);
                                    CLog.justalkFile("mCallTermedkReceiver----->default1， callId:" + mCallId + ",reason_msg:" + msg.optString("reason_msg", ""));
                                } else {
                                    if (MtcCli.Mtc_CliGetState() == MtcCliConstants.EN_MTC_CLI_STATE_LOGINED) {
                                        showCustomToast(getString(R.string.net_tips_5), Toast.LENGTH_LONG);
                                        return;
                                    } else {
                                        showCustomToast(getString(R.string.net_tips_1), Toast.LENGTH_LONG);
                                    }
                                    CLog.justalkFile("mCallTermedkReceiver----->default2， callId:" + mCallId + ",LOGINED:" + (MtcCli.Mtc_CliGetState() == MtcCliConstants.EN_MTC_CLI_STATE_LOGINED));
                                }
                                preFinish();
                            }
                    }
                    CLog.e("zhaojunbo", "对方挂机" + json);
                } catch (Exception e) {
                    e.printStackTrace();
                    return;
                }
                mRecordBtnIv.setEnabled(false);
                mCommonShotScreenLayout.setEnabled(false);
                showToolBar(true);
            }
        };

        mCallTalkingReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!judgeNeedProcess(intent, mCallId)) {
                    return;
                }
                QHStatAgentHelper.addCallTimeStick(QHStatAgentHelper.TALKING, mCallId + "");
                if (mInnerLoading != null) {
                    mInnerLoading.clearAnimation();
                }
                startMonitorCall();
                mConnecting = false;
                mLoadingAreaLl.setVisibility(View.GONE);
                mTimerHandler.removeCallbacks(mRetryDelay);
                showInnerBg(false);
                mRecordBtnIv.setEnabled(true);
                mCommonShotScreenLayout.setEnabled(true);
                startTimeCount();
                mTimerHandler.postDelayed(mAutoVideoShotDelay, 2000);
                mNetWorkSpeedLayout.setVisibility(View.VISIBLE);
                mTimerHandler.removeCallbacks(mToolBarShowRunnable);
                mTimerHandler.postDelayed(mToolBarShowRunnable, 3000);
            }
        };

        mMediaHowlingDetectedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                boolean needProcess = judgeNeedProcess(intent, mCallId);
                CLog.e("howling", "phone howling call id = " + mCallId + ", toast showing = " +
                        Constants.HAS_SHOW_NOISE_HIGH + ", need process=" + needProcess);
                if (!needProcess) {
                    return;
                }
                if (Preferences.getIsShowHowlingTips() == false) {
                    CLog.e("howling", "wait for 3s to show toast");
                    mTimerHandler.removeCallbacks(mNoiseRunnable);
                    mTimerHandler.postDelayed(mNoiseRunnable, 3 * 1000);
                    //Constants.HAS_SHOW_NOISE_HIGH = true;
                }
            }
        };

        mMediaHowlingEndReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                CLog.e("howling", "phone howling end, disturb toast show.");
                if (!judgeNeedProcess(intent, mCallId)) {
                    return;
                }
                mTimerHandler.removeCallbacks(mNoiseRunnable);
            }
        };

        mMCallInfoReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                CLog.e("hyuan", "receive pad message");
                if (!judgeNeedProcess(intent, mCallId)) {
                    return;
                }
                String msg = "";
                try {
                    String info = intent.getStringExtra(MtcApi.EXTRA_INFO);
                    JSONObject json = (JSONObject) new JSONTokener(info).nextValue();
                    msg = json.getString(MtcCallConstants.MtcCallBodyKey);
                } catch (Exception e){
                    e.printStackTrace();
                    return;
                }
                CLog.e("hyuan", "receive pad message:" + msg);
                if (PAD_HOWLING.equals(msg)){
                    CLog.e("howling", "receive pad howling start message");
                    if (Preferences.getIsShowHowlingTips() == false) {
                        CLog.e("howling", "wait for 3s to show toast");
                        mTimerHandler.removeCallbacks(mNoiseRunnable);
                        mTimerHandler.postDelayed(mNoiseRunnable, 3 * 1000);
                        //Constants.HAS_SHOW_NOISE_HIGH = true;
                    }
                }
                else if (PAD_HOWLING_END.equals(msg)){
                    CLog.e("howling", "receive pad howling end message, disturb toast show.");
                    mTimerHandler.removeCallbacks(mNoiseRunnable);
                    Constants.HAS_SHOW_NOISE_HIGH = false;
                }
            }
        };

        mCallAlertedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!judgeNeedProcess(intent, mCallId)) {
                    return;
                }
                QHStatAgentHelper.addCallTimeStick(QHStatAgentHelper.ACCEPT_ALERT, mCallId + "");
                CLog.e("outgoing", "电话回铃");
            }
        };

        mAccountChangeReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                accountChangeCloseCall();
                CLog.e("zhaojunbo", "mAccountChangeReceiver");
            }
        };

        mCallNetworkStatusChangedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!judgeNeedProcess(intent, mCallId)) {
                    return;
                }
                try {
                    String info = intent.getStringExtra(MtcApi.EXTRA_INFO);
                    JSONObject json = (JSONObject) new JSONTokener(info).nextValue();
                    int iStatus = json.getInt(MtcCallConstants.MtcCallNetworkStatusKey);
//                    switch (iStatus){
//                        case MtcCallConstants.EN_MTC_NET_STATUS_BAD:
//                        case MtcCallConstants.EN_MTC_NET_STATUS_VERY_BAD:
//                        case MtcCallConstants.EN_MTC_NET_STATUS_DISCONNECTED: {
//                            mNetworkSpeed.setTextColor(getResources().getColor(R.color.net_work_bad));
//                            mNetworkSpeedArrow.setImageDrawable(getResources().getDrawable(R.drawable.arrow_network_bad));
//                            break;
//                        }
//                        case MtcCallConstants.EN_MTC_NET_STATUS_GOOD:
//                        case MtcCallConstants.EN_MTC_NET_STATUS_VERY_GOOD:{
//                            mNetworkSpeed.setTextColor(getResources().getColor(R.color.net_work_good));
//                            mNetworkSpeedArrow.setImageDrawable(getResources().getDrawable(R.drawable.arrow_network_good));
//                            break;
//                        }
//                        case MtcCallConstants.EN_MTC_NET_STATUS_NORMAL: {
//                            mNetworkSpeed.setTextColor(getResources().getColor(R.color.net_work_normal));
//                            mNetworkSpeedArrow.setImageDrawable(getResources().getDrawable(R.drawable.arrow_network_normal));
//                            break;
//                        }
//                    }
                    String speed = json.getString(MtcCallConstants.MtcCallReceiveCurBitRateKey) + "KB/S";
                    boolean isSend = json.getBoolean(MtcCallConstants.MtcCallIsSendKey);
                    CLog.e("hyuan","Network state change MtcCallReceiveCurBitRateKey:" + speed + ", isSend:" + isSend);
                    if (!isSend){
                        mTimerHandler.removeCallbacks(mNetworkSpeedCheckRunnable);
                        mNetworkSpeed.setText(speed);
                        // CLog.justalkFile("MTC notify network change at speed(MtcCallReceiveCurBitRateKey):" + speed);
                    }
                    mTimerHandler.postDelayed(mNetworkSpeedCheckRunnable, 5000);

                    if (iStatus == MtcCallConstants.EN_MTC_NET_STATUS_DISCONNECTED) {
                        if (!mHasShowDisconnected) {
                            mHasShowDisconnected = true;
                            mTimerHandler.postDelayed(mDisconnectedRunnable, 20000);
                        }
                    } else {
                        mHasShowDisconnected = false;
                        mTimerHandler.removeCallbacks(mDisconnectedRunnable);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };

        mInnerCloseReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                preFinish();
                CLog.e("zhaojunbo", "mInnerCloseReceiver");
            }
        };

        mCallVideoReceiveStatusChangedReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!judgeNeedProcess(intent, mCallId)) {
                    return;
                }
                try {
                    String info = intent.getStringExtra(MtcApi.EXTRA_INFO);
                    CLog.json("phone_call", info);
                    JSONObject json = (JSONObject) new JSONTokener(info).nextValue();
                    int state = json.getInt(MtcCallConstants.MtcCallVideoStatusKey);
                    switch (state) {
                        case MtcCallConstants.EN_MTC_CALL_TRANSMISSION_CAMOFF:
                            mHasNoVideo = true;
                            break;
                        case MtcCallConstants.EN_MTC_CALL_TRANSMISSION_PAUSE:
                            mHasNoVideo = true;
                            break;
//                        case MtcCallConstants.EN_MTC_CALL_TRANSMISSION_PAUSE4QOS:
//                            mHasNoVideo = true;
//                            break;
                        default:
                            break;
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };

        mMtcBuddyQueryLoginPropertiesOkNotification = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                //CameraToast.show("QueryLoginOk", Toast.LENGTH_SHORT);
                try {
                    String info = intent.getStringExtra(MtcApi.EXTRA_INFO);
                    JSONObject json = (JSONObject) new JSONTokener(info).nextValue();
                    int state = json.getInt(MtcBuddyConstants.MtcBuddyStatusKey);
                    switch (state) {
                        case MtcCliConstants.MTC_ACCOUNT_STATUS_ERR:
                        case MtcCliConstants.MTC_ACCOUNT_STATUS_NOT_FOUND:
                        case MtcCliConstants.MTC_ACCOUNT_STATUS_OFFLINE:
                            callInterrupt(getString(R.string.tips_87), MtcCallConstants.EN_MTC_CALL_TERM_STATUS_NORMAL);
                            break;
                        case MtcCliConstants.MTC_ACCOUNT_STATUS_PUSH:
                        case MtcCliConstants.MTC_ACCOUNT_STATUS_ONLINE:
                            break;
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };

        mMtcBuddyQueryLoginPropertiesDidFailNotification = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
//                callInterrupt(getString(R.string.tips_87), MtcCallConstants.EN_MTC_CALL_TERM_STATUS_NORMAL);
            }
        };

        mCallConnectingReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (!judgeNeedProcess(intent, mCallId)) {
                    return;
                }
                QHStatAgentHelper.addCallTimeStick(QHStatAgentHelper.CONNECTING, mCallId + "");
                MtcCallExt.Mtc_CallArsSetVideoParm(mCallId, 300000, 900000, 7, 15);


                //startMonitorCall();
            }
        };

        mOutgoingCallCloseReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                CLog.e("phone_call", "收到关闭广播");
                restartMonitor();
            }
        };

        registerReceiver(mOutgoingCallCloseReceiver, new IntentFilter(Const.BROADCAST_SEND_CLOSE_BROADCAST));
        registerReceiver(mInnerCloseReceiver, new IntentFilter(Const.BROADCAST_INNER_CLOSE));
        registerReceiver(mAccountChangeReceiver, new IntentFilter(Const.BROADCAST_ACCOUNT_CHANGE));

        super.initReceiver();
    }

    private void callInterrupt(String tips, int type) {
        showInnerBg(true);
        mCommonTime.setText(PhoneUtil.formatTime(0));
        mTimerHandler.removeCallbacksAndMessages(null);
        mDisableTipsTv.setText(tips);
        mRetryLl.setVisibility(View.VISIBLE);
        mLoadingAreaLl.setVisibility(View.GONE);
        if (mIsRecording) {
            stopRecordDoodleVideo(mCallId);
        }
        closeCall(type, "主动挂断");
    }

    private void initView() {
        setWindow();
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.kibot_video_call_inner_landscape);
        mCommonTime = (TextViewWithFont) findViewById(R.id.common_video_call_inner_time);
        ImageView mCommonBack = (ImageView) findViewById(R.id.common_video_call_inner_back);
        mRecordingIv = (ImageView) findViewById(R.id.iv_recoding);
        mCommonPreviewImg = (ImageView) findViewById(R.id.common_video_call_inner_shot_screen_preview);
        LinearLayout mCommonSwitchViewLayout = (LinearLayout) findViewById(R.id.common_video_call_inner_switch_layout);
        mRecordBtnIv = (ImageView) findViewById(R.id.common_video_call_inner_video_layout);
        mCommonShotScreenLayout = (ImageView) findViewById(R.id.common_video_call_inner_shot_screen_layout);
        mSwitchView = (NewSwitchView) findViewById(R.id.inner_switch);
        mNetworkSpeed = (TextView) findViewById(R.id.network_speed);
        mNetworkSpeedArrow = (ImageView) findViewById(R.id.network_speed_arrow);
        mNetWorkSpeedLayout = (LinearLayout) findViewById(R.id.network_speed_layout);
        if (mSwitchView != null) {
            mSwitchView.setOnCheckedChangeListener(new NewSwitchView.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(boolean isChecked) {
                    if (!isChecked) {
                        return;
                    }
                    mTimerHandler.removeCallbacks(mRetryDelay);
                    showInnerBg(false);
                    if (mIsRecording) {
                        mRecordBtnIv.performClick();
                        mRecordBtnIv.setEnabled(false);
                    }
                    //打开preFinish()返回首页
                    //closeCall(MtcCallConstants.EN_MTC_CALL_TERM_STATUS_NORMAL, "主动挂断");
                    preFinish();
                    CLog.e("justalk", "onCheckedChanged--->监控挂断");
                    Intent outGoingCallIntent = new Intent(VideoCallInnerActivity.this, OutgoingCallActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putParcelable("deviceInfo", mDeviceInfo);
                    bundle.putInt("from_inner", 1);
                    outGoingCallIntent.putExtras(bundle);
                    startActivityForResult(outGoingCallIntent, 2001);
//                    mSwitchView.setChecked(true);
                }
            });
        }
        mRecordBtnIv.setEnabled(false);
        mCommonShotScreenLayout.setEnabled(false);
        Button checkRateBt = (Button) findViewById(R.id.bt_check_rate);
        Utils.ensureVisbility(BuildConfig.isDebug ? View.VISIBLE : View.GONE, checkRateBt);
        mLoadingAreaLl = (LinearLayout) findViewById(R.id.ll_loading_area);
        mShotFrameLayout = (FrameLayout) findViewById(R.id.frame);
        mInnerLoading = (ImageView) findViewById(R.id.iv_inner_loading);
        mRetryLl = (LinearLayout) findViewById(R.id.ll_retry);
        mDisableTipsTv = (TextView) findViewById(R.id.tv_disable_tips);
        mBgInnerIv = (ImageView) findViewById(R.id.iv_bg_inner);
        mSnapshotSplash = findViewById(R.id.snapshotSplash);
        mRetryLl.setOnClickListener(this);
        Animation anim = AnimationUtils.loadAnimation(this, R.anim.rotate_icon);
        mInnerLoading.startAnimation(anim);
        showInnerBg(true);
        mConnecting = true;
        resetTimeCount();
        Utils.ensuerSetOnclick(this, mCommonBack, mCommonPreviewImg, mCommonSwitchViewLayout, mRecordBtnIv, mCommonShotScreenLayout, checkRateBt);

        mTopToolBar = (RelativeLayout) findViewById(R.id.top_tool_bar_layout);
        mTopToolBar.setOnClickListener(this);
        mRightToolBar = (LinearLayout) findViewById(R.id.right_tool_bar_layout);
        mBottomToolBar = (LinearLayout) findViewById(R.id.common_video_call_inner_switch_layout);
        View ly = findViewById(R.id.touch_view);
        ly.setOnClickListener(this);
    }

    private void showInnerBg(boolean show) {
        if (mDeviceInfo != null && mBgInnerIv != null) {
            mBgInnerIv.setVisibility(show ? View.VISIBLE : View.GONE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1 && this.isDestroyed() == false) {
                Glide.with(this)
                        .load(TextUtils.isEmpty(mDeviceInfo.getCoverUrl()) ? R.drawable.device_moren_icon : mDeviceInfo.getCoverUrl())
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .placeholder(R.drawable.device_moren_icon)
                        .dontAnimate()
                        .priority(Priority.HIGH)
                        .into(mBgInnerIv);
            }
        }
    }

    private void restartMonitor() {
        if (mLoadingAreaLl != null) {
            mRetryLl.setVisibility(View.GONE);
            mLoadingAreaLl.setVisibility(View.VISIBLE);
            mRetrySeconds = 0;
            mTimerHandler.postDelayed(mRetryDelay, 1000);
            showInnerBg(true);
            Animation anim = AnimationUtils.loadAnimation(this, R.anim.rotate_icon);
            mInnerLoading.startAnimation(anim);
            mConnecting = true;
            mRecordBtnIv.setEnabled(false);
            mCommonShotScreenLayout.setEnabled(false);
        }
        startCall();
        resetTimeCount();
        showToolBar(true);
    }

    @Override
    public void onDestroy() {
        if (mInnerCloseReceiver != null)
            unregisterReceiver(mInnerCloseReceiver);
        if (mOutgoingCallCloseReceiver != null)
            unregisterReceiver(mOutgoingCallCloseReceiver);
        if (mAccountChangeReceiver != null)
            unregisterReceiver(mAccountChangeReceiver);
        if (!hasFinish) {
            hasFinish = true;
            try {
                closeCall(MtcCallConstants.EN_MTC_CALL_TERM_STATUS_NORMAL, "主动挂断");
                CLog.e("justalk", "onDestroy--->监控挂断");
                Constants.IS_CALLING_OR_INNER = false;
                Constants.IS_INNER = false;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        super.onDestroy();
    }

    @Override
    public void onLowMemory() {
        Constants.IS_CALLING_OR_INNER = false;
        Constants.IS_INNER = false;
        preFinish();
        super.onLowMemory();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.common_video_call_inner_back: // 返回
                preFinish();
                break;
            case R.id.common_video_call_inner_video_layout: // 录像
                PhoneUtil.playVideoRecordSound();
                recordVideo();
                break;
            case R.id.common_video_call_inner_shot_screen_layout: // 截屏
                PhoneUtil.playSnapshotSound();
                showSnapShotEffect(mSnapshotSplash);
                takeShot();
                break;
            case R.id.ll_retry:
                if (Utils.isNetworkAvailable(this)) {
                    mRetryLl.setVisibility(View.GONE);
                    mLoadingAreaLl.setVisibility(View.VISIBLE);
                    mTimerHandler.removeCallbacks(mRetryDelay);
                    showInnerBg(false);
                    restartMonitor();
                }
                break;
            case R.id.bt_check_rate:
                showState();
                break;
            case R.id.top_tool_bar_layout:
            case R.id.touch_view:
                showToolBar(!bToolBarShowing);
                break;
            default:
                break;
        }
        if (mTimerHandler != null && mToolBarShowRunnable != null) {
            mTimerHandler.removeCallbacks(mToolBarShowRunnable);
            mTimerHandler.postDelayed(mToolBarShowRunnable, 3000);
        }
    }

    @Override
    public void onBackPressed() {
        preFinish();
    }

    private void createVideoViews() {
        Context context = getApplicationContext();
        mViewMain = (FrameLayout) findViewById(R.id.fl_background);
        // 为对端视频创建显示窗口
        mRemoteView = ZmfVideo.renderNew(context);
        mRemoteView.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        mViewMain.addView(mRemoteView, 0);
        ZmfVideo.renderStart(mRemoteView);
    }

    private void startMonitorCall() {
        setCallMode();
        MtcCall.Mtc_CallHasAudio(1);
        createVideoViews();
        ZmfVideo.renderAdd(mRemoteView, MtcCall.Mtc_CallGetName(mCallId), 0, ZmfVideo.RENDER_AUTO);
        ZmfVideo.renderRotate(mRemoteView, 0);


        MtcCall.Mtc_CallHasVideo(1);
        int result = MtcCall.Mtc_CallAnswer(mCallId, 0, true, true);
        if (MtcConstants.ZOK != result) {
            closeCall(MtcCallConstants.EN_MTC_CALL_TERM_STATUS_NORMAL, "");
            CLog.e("justalk", "startMonitorCall--->监控挂断");
        }
    }

    @Override
    protected void audioStart() {
        new AsyncTask<Void, Void, Void>() {

            @Override
            protected Void doInBackground(Void... params) {
                synchronized (VideoCallInnerActivity.this) {
                    int ret = ZmfAudio.outputStart(MtcMdm.Mtc_MdmGetAndroidAudioOutputDevice(), 0, 0);
                    CLog.e("audio", "ZmfAudio.outputStart");
                    if (ret != 0) {
                        ZmfAudio.inputStopAll();
                        ZmfAudio.outputStopAll();
                        if (mAudioManager != null) {
                            if (AudioManager.MODE_NORMAL != mAudioManager.getMode()) {
                                mAudioManager.setMode(AudioManager.MODE_NORMAL);
                            }
                        }
                        ZmfAudio.outputStart(
                                MtcMdm.Mtc_MdmGetAndroidAudioOutputDevice(), 0, 0);
                    }
                }
                return null;
            }
        }.execute();
    }

    private void closeCall(int type, String msg) {
        CLog.startTimer("time");
        CLog.e("phone_call", "监控挂断" + mCallId + type + "msg" + msg);
        MtcCall.Mtc_CallTerm(mCallId, type, msg);
        mtcCallTermed();
        QHStatAgentHelper.addCallTimeStick(QHStatAgentHelper.END, mCallId + "");
        QHStatAgentHelper.uploadEndCallStick(mCallId + "", type + "", 0 + "");

        if (mCallConnectingReceiver != null)
            LocalBroadcastManager.getInstance(this).unregisterReceiver(mCallConnectingReceiver);
        if (mCallTermedkReceiver != null)
            LocalBroadcastManager.getInstance(this).unregisterReceiver(mCallTermedkReceiver);
        if (mCallTalkingReceiver != null)
            LocalBroadcastManager.getInstance(this).unregisterReceiver(mCallTalkingReceiver);
        if (mCallAlertedReceiver != null)
            LocalBroadcastManager.getInstance(this).unregisterReceiver(mCallAlertedReceiver);
        if (mCallNetworkStatusChangedReceiver != null)
            LocalBroadcastManager.getInstance(this).unregisterReceiver(mCallNetworkStatusChangedReceiver);
        if (mCallVideoReceiveStatusChangedReceiver != null)
            LocalBroadcastManager.getInstance(this).unregisterReceiver(mCallVideoReceiveStatusChangedReceiver);
        Zmf.removeObserver(this);
//        if (mMtcBuddyQueryLoginPropertiesOkNotification != null)
//            LocalBroadcastManager.getInstance(this).unregisterReceiver(mMtcBuddyQueryLoginPropertiesOkNotification);
//        if (mMtcBuddyQueryLoginPropertiesDidFailNotification != null)
//            LocalBroadcastManager.getInstance(this).unregisterReceiver(mMtcBuddyQueryLoginPropertiesDidFailNotification);
        if (mMediaHowlingDetectedReceiver != null) {
            LocalBroadcastManager.getInstance(this).unregisterReceiver(mMediaHowlingDetectedReceiver);
        }
        if (mMediaHowlingEndReceiver != null) {
            LocalBroadcastManager.getInstance(this).unregisterReceiver(mMediaHowlingEndReceiver);
        }
        if (mMCallInfoReceiver != null) {
            LocalBroadcastManager.getInstance(this).unregisterReceiver(mMCallInfoReceiver);
        }
    }

    private void accountChangeCloseCall() {
        closeCall(Constants.TermReason.TERM_OTHER_LOGOUT, "被踢出");
        CLog.e("justalk", "accountChangeCloseCall--->监控挂断");
    }

    public void mtcCallTermed() {
        clearCallMode();
        mtcCallStopVideo(mCallId);
    }

    public void mtcCallStopVideo(int callId) {
        MtcCall.Mtc_CallCameraDetach(callId);
        ZmfVideo.captureStopAll();
        if (mRemoteView != null) {
            ZmfVideo.renderRemoveAll(mRemoteView);
            ZmfVideo.renderStop(mRemoteView);
            if (!hasPreFinish) {
                mViewMain.removeView(mRemoteView);
                mRemoteView = null;
            }
        }
    }

    private void resetTimeCount() {
        mTimerHandler.removeCallbacks(mTimerRunnable);
        mCallSecond = 0;
        mRecordingSecond = 0;
        mCommonTime.setText(getString(R.string.default_time));
    }

    private void startTimeCount() {
        mTimerHandler.postDelayed(mTimerRunnable, 1000);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        int type = getStreamType();
        switch (keyCode) {
            case KeyEvent.KEYCODE_VOLUME_DOWN:
                mAudioManager.adjustStreamVolume(type, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI);
                return true;
            case KeyEvent.KEYCODE_VOLUME_UP:
                mAudioManager.adjustStreamVolume(type, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI);
                return true;
            case KeyEvent.KEYCODE_VOLUME_MUTE:
                mAudioManager.setStreamVolume(type, 0, AudioManager.FLAG_SHOW_UI);
                return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void preFinish() {
        hasPreFinish = true;
        saveCoverImg();
        mTimerHandler.removeCallbacks(mRetryDelay);
        if (mNoiseRunnable != null){
            mTimerHandler.removeCallbacks(mNoiseRunnable);
        }
        finish();
    }

    @Override
    public void finish() {
        if (!hasFinish) {
            hasFinish = true;
            mTimerHandler.removeCallbacksAndMessages(null);
            try {
                if (mIsRecording) {
                    stopRecordDoodleVideo(mCallId);
                }
                closeCall(MtcCallConstants.EN_MTC_CALL_TERM_STATUS_NORMAL, "主动挂断");
                CLog.e("justalk", "finish--->监控挂断");
                Constants.IS_CALLING_OR_INNER = false;
                Constants.IS_INNER = false;
                CLog.e("callinner", "unregisterReceiver--mInnerCloseReceiver");
            } catch (Exception e) {
                e.printStackTrace();
            }
            super.finish();
        }
    }

    @Override
    protected void changeTo3G() {
        if (Constants.NEED_4G_TOAST) {
            showCustomToast("正在使用移动网络，将会产生手机流量", Toast.LENGTH_SHORT);
        }
    }

    @Override
    protected void wifiDisconnect() {
//        showCustomToast("您的手机网络已断开，请稍后重试", Toast.LENGTH_SHORT);
//        preFinish();
    }

    @Override
    protected void onPause() {
        callInterrupt(getString(R.string.tips_54), MtcCallConstants.EN_MTC_CALL_TERM_STATUS_BUSY);
        mRecordBtnIv.setEnabled(false);
        mCommonShotScreenLayout.setEnabled(false);
        showToolBar(true);
        super.onPause();
    }

    @Override
    public void handleNotification(int arg0, JSONObject arg1) {
        switch (arg0) {
            case Zmf.VideoErrorOccurred: {
                break;
            }
            case Zmf.AudioErrorOccurred: {
                ZmfAudio.inputStopAll();
                ZmfAudio.outputStopAll();
                audioStart();
                break;
            }
        }

    }
}
