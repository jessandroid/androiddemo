package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by yanggang on 2016/5/12.
 */
public class ReqUserInfo implements Parcelable {
    public String qid;
    public String userName;
    public String phone;
    public String nickName;
    public String imgUrl;

    public static final Parcelable.Creator<ReqUserInfo> CREATOR = new Parcelable.Creator<ReqUserInfo>() {
        @Override
        public ReqUserInfo createFromParcel(Parcel source) {
            return new ReqUserInfo(source);
        }

        @Override
        public ReqUserInfo[] newArray(int size) {
            return new ReqUserInfo[size];
        }
    };

    private ReqUserInfo(Parcel in) {
        qid = in.readString();
        userName = in.readString();
        phone = in.readString();
        nickName = in.readString();
        imgUrl = in.readString();
    }

    @Override
    public void writeToParcel(Parcel out, int flags) {
        out.writeString(qid);
        out.writeString(userName);
        out.writeString(phone);
        out.writeString(nickName);
        out.writeString(imgUrl);
    }

    @Override
    public int describeContents() {
        return 0;
    }
}
