package com.qihoo360.homecamera.machine.sound;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.qihoo360.homecamera.machine.sound.entity.SoundPlayInfo;
import com.qihoo360.homecamera.machine.sound.entity.SoundPlayInfo.SoundInfo;
import com.qihoo360.homecamera.machine.sound.manager.ConnectManager;
import com.qihoo360.homecamera.machine.sound.manager.SoundInfoManager;
import com.qihoo360.homecamera.machine.sound.manager.SoundTask;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.SysConfig;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.DensityUtil;
import com.qihoo360.homecamera.mobile.utils.imageloader.ImageLoaderHelper;
import com.qihoo360.homecamera.mobile.widget.listview.PullToRefreshBase;
import com.qihoo360.homecamera.mobile.widget.listview.PullToRefreshGridView;

public class SoundGridView extends RelativeLayout implements OnClickListener{
	
	private static final int BASE_ID = 100000; 
	private Context mContext;
    private boolean isShow = false;
    
    private RelativeLayout mImgBack;
    
    private LayoutInflater inflater;
    private LayoutInflater mInflater;
    private PullToRefreshGridView mGridView;
    private SoundInfoManager mSoundInfoManager;
    private SoundPlayInfo mSoundPlayInfo = null;
    private SoundBoxAdapter mAdapter;
    
    private View lastView = null;//记录最后一次的view
    private int lastPosition = -1;//记录最后一次的play位置
    
    private boolean isVideoPlay = false;
    
    private String mSn = "456";
    
    public SoundGridView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public SoundGridView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(context);
    }

    public SoundGridView(Context context) {
        super(context);
        init(context);
    }

    public void setSn(String sn) {
    	mSn = sn;
    	mSoundInfoManager = SoundInfoManager.getInstance(mSn);
        mSoundPlayInfo = mSoundInfoManager.getSoundPlayInfo();
	}
    
    // 初始化
    private void init(Context context) {
    	mContext = context;
        inflater = LayoutInflater.from(context);
        mInflater = LayoutInflater.from(context);
        inflater.inflate(R.layout.sound_list, this);
        mGridView = (PullToRefreshGridView) findViewById(R.id.grid_sound_view);
        mGridView.getRefreshableView().setSelector(new ColorDrawable(Color.TRANSPARENT));
        mGridView.setMode(PullToRefreshBase.Mode.DISABLED);
        mImgBack = (RelativeLayout) findViewById(R.id.image_back);
        mImgBack.setOnClickListener(this);
        
        mGridView.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            	if(!ConnectManager.getInstance(mContext).getConnect()){
        			//如果断网则提示
        			CameraToast.show(mContext, R.string.sound_play_disconnect,
                            Toast.LENGTH_LONG);
        			return;
        		}
            	if(!isVideoPlay){
            		CameraToast.show(mContext, R.string.sound_play_connect_play_error,
			                    Toast.LENGTH_LONG);
            		return;
            	}
            		if(listener != null&&mSoundPlayInfo != null&&mSoundPlayInfo.data!=null&&mSoundPlayInfo.data.size()>position){
            			mSoundInfoManager.playNum = position;
     					listener.soundReady(mSoundPlayInfo.data.get(position), SoundTask.SOUND_PLAY);
						// TODO 统计
     					//AccUtil.getInstance().rtick.addStat(mSn, Stat.MY_CAMERA_PLAY_SONG);
     					try {
     						if(lastView.getId() == BASE_ID+lastPosition){
     			    			//如果id不相等，则说明之前记录的itemview 已经刷新出了屏幕，则不需要刷新了
     			    			try {
     			        			mAdapter.getView(lastPosition, lastView, mGridView);
     			    			} catch (Exception e) {
     			    			}
     			    		}
     						mAdapter.getView(position, view, parent);
     					} catch (Exception e) {
     					}
     				}
            }
        });
        
        mAdapter = new SoundBoxAdapter();
        mGridView.setAdapter(mAdapter);
    }
    
    public void finishRefresh() {
        if (mGridView != null && mGridView.isRefreshing()) {
            mGridView.onRefreshComplete();
        }
    }
    

    public void onDestroy() {
    	//TODO 由于开始时设计的只支持了一个摄像头，最后发现多个摄像头的时候会出现状态不同步问题，由于发版在即，在原来架构上临时修改出一套方案，mSoundInfoManager会有多个，很多资源会重复利用，多次回收会有问题，所以暂时先不回收，等重新架构再回收
        //下版本重新写此逻辑
    	/*if (mSoundInfoManager != null) {
            mSoundInfoManager.onDestroy();
            mSoundInfoManager = null;
        }*/
    }
    
    private OnItemListener listener;
    public void setOnItemListener(OnItemListener listener) {
        this.listener = listener;
    }
    
    public interface OnItemListener {        
        /**
         * 播放接口
         * @param info
         * @param state
         */
        void soundReady(SoundInfo info, int state);
        
        void onClick(View v);
    }
    
    /**
     * 退出动画
     * @param duration
     */
    public void animatorOut(int duration) {
        ViewPropertyAnimator animator = animate();
        animator.setDuration(duration);
        animator.translationX(SysConfig.BASE_SCREEN_WIDTH);
        animator.start();
        isShow = false;
    }
    
    /**
     * 进入动画
     * @param duration
     */
    public void animatorIn(int duration) {
        setVisibility(View.VISIBLE);
        ViewPropertyAnimator animator = animate();
        animator.setDuration(duration);
        animator.x(SysConfig.BASE_SCREEN_WIDTH);
        animator.translationX(0);
        animator.start();
        isShow = true;
    }
    
    public boolean isShow() {
        return isShow;
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.image_back:
                animatorOut(200);
                break;
        }
        
        if(listener != null) {
            listener.onClick(v);
        }
    }
    
    public void update(String sn,int type,boolean isVideoPlay) {
    	if(mSoundInfoManager == null){
    		mSn = sn;
            mSoundInfoManager = SoundInfoManager.getInstance(mSn);
            mSoundPlayInfo = mSoundInfoManager.getSoundPlayInfo();
    	}
    	this.isVideoPlay = isVideoPlay;
    	if(type ==0)
    		mSoundPlayInfo = mSoundInfoManager.getSoundPlayInfo();
    	
    	if(lastView != null&&lastPosition >= 0){
    		//如果能找到对应界面，先刷新对应界面
    		if(lastView.getId() == BASE_ID+lastPosition){
    			//如果id不相等，则说明之前记录的itemview 已经刷新出了屏幕，则不需要刷新了
    			try {
        			mAdapter.getView(lastPosition, lastView, mGridView);
    			} catch (Exception e) {
    			}
    		}
    	} else {
    		mAdapter.notifyDataSetChanged();
    	}
	}
    
    
    public class SoundBoxAdapter extends BaseAdapter {

    	private DisplayImageOptions options;

    	public SoundBoxAdapter() {
    		if (options == null) {
    			options = new DisplayImageOptions.Builder()
    					.cloneFrom(ImageLoaderHelper.DEFAULT_LOCAL_DISPLAY_OPTIONS)
    					.showImageForEmptyUri(R.drawable.sound_item_icon_default)
    					.showImageOnFail(R.drawable.sound_item_icon_default)
    					.showImageOnLoading(R.drawable.sound_item_icon_default).build();
    		}
    	}
    	
    	@Override
		public int getCount() {
			if(mSoundPlayInfo==null){
				return 0;
			} else 
			return mSoundPlayInfo.data.size();
		}

		@Override
		public Object getItem(int position) {
			if(mSoundPlayInfo==null||position>=mSoundPlayInfo.data.size()){
				return null;
			} else 
			return mSoundPlayInfo.data.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

    	public View getView(int position, View convertView, ViewGroup parent) {
    		if(mSoundPlayInfo==null||position>=mSoundPlayInfo.data.size()){
				return convertView;
			}
    		 SoundInfo info = mSoundPlayInfo.data.get(position);
    		if (info == null) {
    			return null;
    		}
    		ViewHolder viewHolder = null;
    		if (convertView == null) {
    			viewHolder = new ViewHolder();
    				convertView = mInflater.inflate(
    						R.layout.sound_list_item, null);
    				viewHolder.icon = (ImageView) convertView
    						.findViewById(R.id.img_icon);
    				viewHolder.wave = (SoundWaveView) convertView
    						.findViewById(R.id.wave_view);
    				viewHolder.wave.setSelfAni(false);
    				viewHolder.puase = (ImageView) convertView
    						.findViewById(R.id.image_pause);
    				viewHolder.clickView = (View) convertView
    						.findViewById(R.id.img_click_view);
    				viewHolder.title = (TextView) convertView
    						.findViewById(R.id.text_title);
    				int imageWidth = (SysConfig.BASE_SCREEN_WIDTH - DensityUtil.dip2px(55))/3;
    				
    				LayoutParams  params = (LayoutParams) viewHolder.icon.getLayoutParams();
    				params.height = imageWidth;
    				params.width = imageWidth;
    				
    				LayoutParams  paramsClick = (LayoutParams) viewHolder.clickView .getLayoutParams();
    				paramsClick.height = imageWidth;
    				paramsClick.width = imageWidth;
    				
    			convertView.setTag(viewHolder);
    		} else {
    			viewHolder = (ViewHolder) convertView.getTag();
    		}
    		convertView.setId(BASE_ID+position);
    		if(mSoundInfoManager != null&&position == mSoundInfoManager.playNum&&SoundInfoManager.getInstance(mSn).playState != SoundTask.SOUND_STOP){
    			viewHolder.wave.setVisibility(View.VISIBLE);
    			if(SoundInfoManager.getInstance(mSn).playState == SoundTask.SOUND_PAUSE||!isVideoPlay){
	        		viewHolder.wave.stopAni();
	        	} else {
	        		viewHolder.wave.startAni();
	        	}
    			viewHolder.puase.setVisibility(View.GONE);
    			lastView = convertView;//记录历史状态
    			lastPosition = position;
    		} else {
    			viewHolder.wave.setVisibility(View.GONE);
    			viewHolder.puase.setVisibility(View.VISIBLE);
    		}
    		
    		if(TextUtils.isEmpty(viewHolder.iconStr)||TextUtils.isEmpty(info.getSongImg())||!viewHolder.iconStr.equals(info.getSongImg())){
    			//目前的imageloader有问题，同地址图片刷新会闪一下。所以自己手动检测，如果地址记录是空的、或者图片地址不一样再刷新
    			ImageLoader.getInstance().displayImage(info.getSongImg(), viewHolder.icon, options);
    			viewHolder.iconStr = info.getSongImg();
    		}
    		
    		viewHolder.title.setText(info.getSongName());
    		return convertView;
    	}

    	class ViewHolder {
    	    public TextView title;
    		public ImageView icon;
    		public View clickView;
    		//public String titleStr = null;//用于缓存标题
    		public String iconStr = null;//用于缓存图片地址，如果地址一样，则不刷新
    		public SoundWaveView wave;
    		public ImageView puase;
    	}
    }
}
