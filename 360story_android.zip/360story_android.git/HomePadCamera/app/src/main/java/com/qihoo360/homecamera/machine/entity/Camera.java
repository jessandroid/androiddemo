
package com.qihoo360.homecamera.machine.entity;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;
import com.qihoo360.homecamera.machine.myvideoplay.P2pInfo;
import com.qihoo360.homecamera.machine.util.JSONUtils;
import com.qihoo360.homecamera.mobile.entity.Head;

public class Camera extends Head implements CameraType, Parcelable, Comparable<Camera> {

    public int id = 0;
    public int state = 0; // 0: offline 1: online
    public String titlePhone = "我的看家手机";
    public String description;
    public Firmware firmware = new Firmware();
    public String url = "";
    public String thumbnail = "";
    public String thumbnail_local = "";
    public String location = "";
    public String title = "360故事机";//故事机名称
    public int role = 1;// 1是自己的 2家人的
    public String hardware; //故事机硬件参数

    public String sn;
    //public WShareACL acl2 = new WShareACL(); // 1: control 2: view 3: view video live only
    public String owner = "";
    @SerializedName("share")
    public int shareCount = 0;
    @SerializedName("public")
    public int common = 0; // 1: living 0: not living
    public String category = "";
    public long createtime = 0L;
    // 固件状态 int 是 0表示最新，1表示有升级版本，2表示升级中，3表示升级失败,4强制升级
    public int status = 0;
    // 是否强制升级 int 是 1表示是，0表示否
    public int compel = 0;
    // 不需要和服务器交互
    public String locationId = "";

    // 1表示是，0表示否 “我的列表”中默认的摄像机
    public int isDemo = 0;
    public int ipcType = 0; //0是摄像机，1是手机
    public int upgrade = 0; // 0成功 1失败 -1 下载固件失败 -40003 刷固件失败

    public String support;
    public int supportSecure = 0;//安防，这些都要废弃了，使用support自己解析
    public int supportRecord = 0;//录像，这些都要废弃了，使用support自己解析
    public int supportFace = 0;//人脸识别，这些都要废弃了，使用support自己解析
    public int gifStatus;
    public int cloudStatus;//云存状态 0未开通过 1试用中 2购买使用中 3过期

    public int updateNumber = 0;
    public boolean isFirstMyCamera;

    public CameraExtend extend;
    public int test = 1;

    public int upfSucc = 0; // 0 啥也不做 1表示刚刚升级的

    public P2pInfo p2pInfo;

    public Data data;

    public Camera() {}

    protected Camera(Parcel in) {
        super(in);
        id = in.readInt();
        state = in.readInt();
        titlePhone = in.readString();
        description = in.readString();
        firmware = in.readParcelable(Firmware.class.getClassLoader());
        url = in.readString();
        thumbnail = in.readString();
        thumbnail_local = in.readString();
        location = in.readString();
        title = in.readString();
        role = in.readInt();
        hardware = in.readString();
        sn = in.readString();
        owner = in.readString();
        shareCount = in.readInt();
        common = in.readInt();
        category = in.readString();
        createtime = in.readLong();
        status = in.readInt();
        compel = in.readInt();
        locationId = in.readString();
        isDemo = in.readInt();
        ipcType = in.readInt();
        upgrade = in.readInt();
        support = in.readString();
        supportSecure = in.readInt();
        supportRecord = in.readInt();
        supportFace = in.readInt();
        gifStatus = in.readInt();
        cloudStatus = in.readInt();
        updateNumber = in.readInt();
        isFirstMyCamera = in.readByte() != 0;
        extend = in.readParcelable(CameraExtend.class.getClassLoader());
        test = in.readInt();
        upfSucc = in.readInt();
        p2pInfo = in.readParcelable(P2pInfo.class.getClassLoader());
        data = in.readParcelable(Data.class.getClassLoader());
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeInt(id);
        dest.writeInt(state);
        dest.writeString(titlePhone);
        dest.writeString(description);
        dest.writeParcelable(firmware, flags);
        dest.writeString(url);
        dest.writeString(thumbnail);
        dest.writeString(thumbnail_local);
        dest.writeString(location);
        dest.writeString(title);
        dest.writeInt(role);
        dest.writeString(hardware);
        dest.writeString(sn);
        dest.writeString(owner);
        dest.writeInt(shareCount);
        dest.writeInt(common);
        dest.writeString(category);
        dest.writeLong(createtime);
        dest.writeInt(status);
        dest.writeInt(compel);
        dest.writeString(locationId);
        dest.writeInt(isDemo);
        dest.writeInt(ipcType);
        dest.writeInt(upgrade);
        dest.writeString(support);
        dest.writeInt(supportSecure);
        dest.writeInt(supportRecord);
        dest.writeInt(supportFace);
        dest.writeInt(gifStatus);
        dest.writeInt(cloudStatus);
        dest.writeInt(updateNumber);
        dest.writeByte((byte) (isFirstMyCamera ? 1 : 0));
        dest.writeParcelable(extend, flags);
        dest.writeInt(test);
        dest.writeInt(upfSucc);
        dest.writeParcelable(p2pInfo, flags);
        dest.writeParcelable(data, flags);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Camera> CREATOR = new Creator<Camera>() {
        @Override
        public Camera createFromParcel(Parcel in) {
            return new Camera(in);
        }

        @Override
        public Camera[] newArray(int size) {
            return new Camera[size];
        }
    };

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public String getSN() {
        return sn;
    }

    /**
     * 故事机使用字段
     * */
    public static class Data implements Parcelable{

        //故事机
        public String sn;
        public String title;
        public int role;
        public int shareNum;//授权给多少人
        public String coverUrl;//封面图URL
        public String hardware;
        public String version;//IPC的固件版本号
        public int isOnline;//当前在线状态 0：离线   1：在线

        protected Data(Parcel in) {
            sn = in.readString();
            title = in.readString();
            role = in.readInt();
            shareNum = in.readInt();
            coverUrl = in.readString();
            hardware = in.readString();
            version = in.readString();
            isOnline = in.readInt();
        }

        public static final Creator<Data> CREATOR = new Creator<Data>() {
            @Override
            public Data createFromParcel(Parcel in) {
                return new Data(in);
            }

            @Override
            public Data[] newArray(int size) {
                return new Data[size];
            }
        };

        public String getSn() {
            return sn;
        }

        public void setSn(String sn) {
            this.sn = sn;
        }

        public String getTitle() {
            if (TextUtils.isEmpty(title)) {
                return sn;
            } else {
                return title;
            }
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public int getRole() {
            return role;
        }

        public void setRole(int role) {
            this.role = role;
        }

        public int getShareNum() {
            return shareNum;
        }

        public void setShareNum(int shareNum) {
            this.shareNum = shareNum;
        }

        public String getCoverUrl() {
            return coverUrl;
        }

        public void setCoverUrl(String coverUrl) {
            this.coverUrl = coverUrl;
        }

        public String getHardware() {
            return hardware;
        }

        public void setHardware(String hardware) {
            this.hardware = hardware;
        }

        public String getVersion() {
            return version;
        }

        public void setVersion(String version) {
            this.version = version;
        }

        public int getIsOnline() {
            return isOnline;
        }

        public void setIsOnline(int isOnline) {
            this.isOnline = isOnline;
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(sn);
            dest.writeString(title);
            dest.writeInt(role);
            dest.writeInt(shareNum);
            dest.writeString(coverUrl);
            dest.writeString(hardware);
            dest.writeString(version);
            dest.writeInt(isOnline);
        }
    }

    public int getTest() {
        return test;
    }

    public void setTest(int test) {
        this.test = test;
    }

    public static class CameraExtend implements Parcelable {
        public int soft_switch = 1;
        public long image_time = 0;
        public int scene = 999;//摄像机设置的场景模式(0自定义 1看家 2看老人 3看小孩 999场景未打开)
        public int still = 0;//是否开启长时间静止报警，0-关闭 1-开启
        public int sensitive = 0;//敏感度（0=高敏感度 1=低敏感度）

        public CameraExtend(){}

        protected CameraExtend(Parcel in) {
            soft_switch = in.readInt();
            image_time = in.readLong();
            scene = in.readInt();
            still = in.readInt();
            sensitive = in.readInt();
        }

        public static final Creator<CameraExtend> CREATOR = new Creator<CameraExtend>() {
            @Override
            public CameraExtend createFromParcel(Parcel in) {
                return new CameraExtend(in);
            }

            @Override
            public CameraExtend[] newArray(int size) {
                return new CameraExtend[size];
            }
        };

        public int getSoft_switch() {
            return soft_switch;
        }

        public void setSoft_switch(int soft_switch) {
            this.soft_switch = soft_switch;
        }

        public long getImage_time() {
            return image_time;
        }

        public void setImage_time(long image_time) {
            this.image_time = image_time;
        }

        public void setScene(int scene){
            this.setScene(scene);
        }

        public int getScene(){
            return scene;
        }

        public void setStill(int still){
            this.still = still;
        }

        public int getStill(){
            return still;
        }

        public void setSensitive(int sensitive){
            this.sensitive = sensitive;
        }

        public int getSensitive(){
            return sensitive;
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeInt(soft_switch);
            dest.writeLong(image_time);
            dest.writeInt(scene);
            dest.writeInt(still);
            dest.writeInt(sensitive);
        }
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    /* public String getSN() {
         return this.sn;
     }

     public void setSN(String sn) {
         this.sn = sn;
     }*/

    public String getDefaultTitle() {
        if (ipcType == 0) {
            return title;
        } else {
            return titlePhone;
        }
    }

    public String getTitle() {
        if (TextUtils.isEmpty(title)) {
            return sn;
        } else {
            return title;
        }
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getState() {
        if (state == 1) {
            state = 1;
        } else {
            if (status == 2) {
                state = 1;
            } else {
                state = 0;
            }
        }
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public void setFirmware(Firmware firmware) {
        this.firmware = firmware;
    }

    public Firmware getFirmware() {
        if (firmware == null) {
            firmware = new Firmware();
        }
        return firmware;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUrl() {
        return url;
    }

    @Override
    public int compareTo(Camera camera) {
        // TODO 这里做一个说明，和产品沟通过，排序首先是按照role 字段，不区分在线还是离线
        /*  if (this.role == 1){
              if (this.state == 1){// 在线=
                  return 0;
              }
              return -1; //分享的
          }else {
              if (this.state == 1){// 在线=
                  return 0;
              }
              return -1;
          }*/
        if (camera.role == 1) {
            return 0;
        }
        return -1;

    }

    public int getIsDemo() {
        return isDemo;
    }

    public void setIsDemo(int isDemo) {
        this.isDemo = isDemo;
    }

    public int getRole() {
        return role;
    }

    public void setRole(int role) {
        this.role = role;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public int getShareCount() {
        return shareCount;
    }

    public void setShareCount(int shareCount) {
        this.shareCount = shareCount;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public int getCommon() {
        return common;
    }

    public void setCommon(int common) {
        this.common = common;
    }

    public long getCreatetime() {
        return createtime;
    }

    public void setCreatetime(long createtime) {
        this.createtime = createtime;
    }

    public String firmwareToJosnString() {
        Gson goGson = new Gson();
        return goGson.toJson(this.firmware);
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getCompel() {
        return compel;
    }

    public void setCompel(int compel) {
        this.compel = compel;
    }

    public String getThumbnail_local() {
        return thumbnail_local;
    }

    public void setThumbnail_local(String thumbnail_local) {
        this.thumbnail_local = thumbnail_local;
    }

    public String getLocationId() {
        return locationId;
    }

    public void setLocationId(String locationId) {
        this.locationId = locationId;
    }

    public String getThumbnailPath() {
        return !TextUtils.isEmpty(getThumbnail_local()) ? getThumbnail_local() : getThumbnail();
    }

    // 固件升级失败
    public int getUpgrade() {
        return upgrade;
    }

    public void setUpgrade(int upgrade) {
        this.upgrade = upgrade;
    }

    public int getSupportSecure() {
        return supportSecure;
    }

    public String getSupport() {
        return support;
    }

    public void setSupport(String support) {
        this.support = support;
    }

    public String getHardware() {
        return hardware;
    }

    public void setHardware(String hardware) {
        this.hardware = hardware;
    }

    public void setSupportSecure(int supportSecure) {
        this.supportSecure = supportSecure;
    }

    public int getSupportRecord() {
        return supportRecord;
    }

    public void setSupportRecord(int supportRecord) {
        this.supportRecord = supportRecord;
    }

    public int getSupportFace() {
        return supportFace;
    }

    public void setSupportFace(int supportFace) {
        this.supportFace = supportFace;
    }

    public int getGifStatus() {
        return gifStatus;
    }

    public void setGifStatus(int gifStatus) {
        this.gifStatus = gifStatus;
    }

    public int getUpdateNumber() {
        return updateNumber;
    }

    public void setUpdateNumber(int updateNumber) {
        this.updateNumber = updateNumber;
    }

    public CameraHardwareSupport getHardwareObj() {
        CameraHardwareSupport supporHardwaretObj;
        if (!TextUtils.isEmpty(hardware)) {
            supporHardwaretObj = JSONUtils.fromJson(CameraHardwareSupport.class, hardware);
        } else {
            supporHardwaretObj = new CameraHardwareSupport();
        }
        return supporHardwaretObj;
    }

    public boolean isSupportFamilyFace() {
        return getSupportObj().family_face_hd == 1;
    }

    public boolean isMy() {
        return role == 0;
    }

    public CameraSupport getSupportObj() {
        CameraSupport supportObj;
        if (!TextUtils.isEmpty(support)) {
            supportObj = JSONUtils.fromJson(CameraSupport.class, support);
        } else {
            supportObj = new CameraSupport();
        }
        return supportObj;
    }

    public int getCloudStatus() {
        return cloudStatus;
    }

    public void setCloudStatus(int cloudStatus) {
        this.cloudStatus = cloudStatus;
    }

    public CameraExtend getExtend() {
        if(extend!=null){
            return extend;
        }else{
            return new CameraExtend();
        }
    }

    public void setExtend(CameraExtend extend) {
        this.extend = extend;
    }

    @Override
    public String toString() {
        if (TextUtils.isEmpty(title)) {
            return getSN();
        }
        return getTitle();
    }
}
