package com.qihoo360.homecamera.mobile.adapter;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckedTextView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.entity.DeviceInfo;
import com.qihoo360.homecamera.mobile.image.my.GlideCircleTransform;
import com.qihoo360.homecamera.mobile.ui.fragment.NewDeviceFragment;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/4/20
 * Time: 10:35
 * To change this template use File | Settings | File Templates.
 */
public class MainDeviceRecycleAdapter extends RecyclerView.Adapter<MainDeviceRecycleAdapter.ViewHolder> {


    private List<DeviceInfo> deviceInfoList;
    private Context mctx;
    private ArrayList<String> mSn;
    private OnViewClick onViewClick;
    public int p = 0;

    public MainDeviceRecycleAdapter(List<DeviceInfo> deviceInfoList, Context context) {
        this.deviceInfoList = deviceInfoList;
        this.mctx = context;
        mSn = new ArrayList<>();
    }

    public void setOnViewClick(OnViewClick onViewClick) {
        this.onViewClick = onViewClick;
    }

    public void setData(List<DeviceInfo> data, ArrayList<String> sn) {
        if (data.size() == 1) {
            data.get(0).checked = true;
        }
        this.deviceInfoList = data;
        if (sn != null) {
            mSn = sn;
        }
        notifyDataSetChanged();
    }
    public void setRedPot(String sn) {
        if(!mSn.contains(sn)){
            mSn.add(sn);
        }
        notifyDataSetChanged();
    }

    public void cancleRedPot(String sn){
        if(mSn.contains(sn)){
            mSn.remove(sn);
        }
        notifyDataSetChanged();
        if(mSn!=null && mSn.size()==0){
            onViewClick.clearTopMsg();
        }
    }

    //是否需要显示TopMsg
    public void needShowTopMsg(){
        if(mSn!=null && mSn.size()>0){
            onViewClick.showTopMsgTip();
        }
    }

    public void setDeviceState(HashMap<String, Integer> onlineStateMap) {
        notifyDataSetChanged();
    }

    @Override
    public long getItemId(int position) {
        return super.getItemId(position);
    }

    @Override
    public int getItemViewType(int position) {
        return super.getItemViewType(position);
    }

    @Override
    public void onViewRecycled(ViewHolder holder) {
        super.onViewRecycled(holder);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.toolbar_spinner_item_actionbar, parent, false);
        ButterKnife.bind(this, view);
        return new ViewHolder(view);
    }


    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        DeviceInfo device = deviceInfoList.get(position);
        holder.txtItem.setText(getTitleString(device));
        if (device.checked) {
            p = position;
        }
        holder.checkedImage.setVisibility(device.checked ? View.VISIBLE : View.GONE);
        holder.relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onViewClick.click(position);
            }
        });
        Glide.clear(holder.head);
        Glide.with(mctx).load(device.avatarUrl)
                .placeholder(R.drawable.default_profile)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .transform(new GlideCircleTransform(Utils.context))
                .priority(Priority.LOW)
                .crossFade().into(holder.head);

        holder.redPotIv.setVisibility(mSn != null && mSn.contains(device.sn) ? View.VISIBLE : View.GONE);

        if (holder.stateTv != null) {
            holder.stateTv.setVisibility(View.VISIBLE);
            switch (device.isOnline) {
                case NewDeviceFragment.OFFLINE:
                    holder.stateTv.setTextColor(Color.parseColor("#80333333"));
                    holder.txtItem.setTextColor(Color.parseColor("#80333333"));
                    holder.stateTv.setText("[离线]");
                    break;
                case NewDeviceFragment.ONLINE:
                    holder.stateTv.setTextColor(Color.parseColor("#333333"));
                    holder.txtItem.setTextColor(Color.parseColor("#333333"));
                    holder.stateTv.setText("[在线]");
                    break;
            }
        }
    }

    private String getTitleString(DeviceInfo deviceInfo){
        if(TextUtils.isEmpty(deviceInfo.title)){
            return "宝贝"+ (deviceInfo.isStoryMachine() ? "的故事机" : "的机器人");
        }else{
            return deviceInfo.title+ (deviceInfo.isStoryMachine() ? "的故事机" : "的机器人");
        }
    }

    @Override
    public int getItemCount() {
        return deviceInfoList.size();
    }

    public DeviceInfo getItem(int po) {
        if (po < deviceInfoList.size()) {
            return deviceInfoList.get(po);
        }
        return null;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        @Bind(R.id.head)
        ImageView head;
        @Bind(R.id.txt_item)
        CheckedTextView txtItem;
        @Bind(R.id.checkedImage)
        ImageView checkedImage;
        @Bind(R.id.to)
        RelativeLayout relativeLayout;
        @Bind(R.id.iv_red_pot)
        ImageView redPotIv;
        @Bind(R.id.tv_state)
        TextView stateTv;
        @Bind(R.id.head_profile)
        ImageView headProfile;

        public ViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    public interface OnViewClick {
        public void click(int po);
        public void clearTopMsg();
        public void showTopMsgTip();
    }
}
