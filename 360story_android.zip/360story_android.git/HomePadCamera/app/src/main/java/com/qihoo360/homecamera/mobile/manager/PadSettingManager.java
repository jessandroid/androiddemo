package com.qihoo360.homecamera.mobile.manager;

import android.app.Application;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionPublisherWithThreadPoolBase;
import com.qihoo360.homecamera.mobile.core.manager.workpool.PoolThreadFactory;
import com.qihoo360.homecamera.mobile.core.net.Api;
import com.qihoo360.homecamera.mobile.db.CommonWrapper;
import com.qihoo360.homecamera.mobile.entity.Head;
import com.qihoo360.homecamera.mobile.entity.IpcAllEntity;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.util.Date;
import java.util.concurrent.Executors;

/**
 * Created by zhaojunbo on 2016/9/1.
 * desc:
 */
public class PadSettingManager extends ActionPublisherWithThreadPoolBase {
    private final String mPoolNameHighPriority, mPoolNameLowPriority;
    private final Application mApp;

    public PadSettingManager(Application app) {
        this.mApp = app;
        mPoolNameHighPriority = "PadSettingManager-high-priority-" + Utils.DATE_FORMAT_3.format(new Date());
        mPoolNameLowPriority = "PadSettingManager-low-priority-" + Utils.DATE_FORMAT_3.format(new Date());
        mThreadPool.initPool(mPoolNameHighPriority, Executors.newFixedThreadPool(3));
        mThreadPool.initPool(mPoolNameLowPriority,
                Executors.newCachedThreadPool(new PoolThreadFactory(mPoolNameLowPriority)));
    }

    public void asyncGetIpcAll(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("GetIpcAll", args));
    }

    public void asyncSetIpcAll(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("SetIpcAll", args));
    }

    public void asyncSetAcl(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("SetAcl", args));
    }

    public void asyncDelAcl(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("DelAcl", args));
    }

    public void asyncSetIpcPassword(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("SetIpcPassword", args));
    }

    @Override
    protected void asyncDoNamedJob(String jobName, Object... args) {
        if (TextUtils.equals(jobName, "GetIpcAll")) {
            doGetIpcAll((String) args[0]);
        } else if (TextUtils.equals(jobName, "SetIpcAll")) {
            doSetIpcAll((String) args[0], (String) args[1], (Integer) args[2], (Integer) args[3],
                    (Integer) args[4], (Integer) args[5], (Integer) args[6], (Integer) args[7],
                    (Integer) args[8], (Integer) args[9], (Integer) args[10], (Integer) args[11]);
        } else if (TextUtils.equals(jobName, "SetAcl")) {
            doSetAcl((String) args[0], (String) args[1], (String) args[2]);
        } else if (TextUtils.equals(jobName, "DelAcl")){
            doDelIpcAll((String) args[0]);
        } else if(TextUtils.equals(jobName, "SetIpcPassword")){
            doSetIpcPassword((String) args[0], (String) args[1]);
        }
    }

    private void doSetAcl(String sqid, String sn, String aclInfo) {
        Head head = Api.PadSetting.setDoSetAcl(sqid, sn, aclInfo);
        if (head == null) {
            publishAction(Actions.PadSetting.SET_ACL_FAIL);
        } else if (head.errorCode != 0) {
            publishAction(Actions.PadSetting.SET_ACL_FAIL, head.errorMsg);
        } else {
            publishAction(Actions.PadSetting.SET_ACL_SUCCESS);
        }
    }

    private void doGetIpcAll(String sn) {

        try {
            IpcAllEntity ipcAllEntity = CommonWrapper.getInstance(this.mApp).getLocalToClazz(sn, CommonWrapper.TYPE_GET_IPC_ALL, IpcAllEntity.class);
            if (ipcAllEntity != null) {
                publishAction(Actions.PadSetting.GET_SETTING_SUCCESS, ipcAllEntity);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        IpcAllEntity ipcAllEntity = Api.PadSetting.getAllPadSetting(sn);
        if (ipcAllEntity == null) {
            publishAction(Actions.PadSetting.GET_SETTING_NULL);
        } else if (ipcAllEntity.errorCode != 0) {
            publishAction(Actions.PadSetting.GET_SETTING_FAIL, ipcAllEntity.errorMsg);
        } else {
            CommonWrapper.getInstance(this.mApp).writeBySnWithType(sn, ipcAllEntity.toJson(), CommonWrapper.TYPE_GET_IPC_ALL);
            publishAction(Actions.PadSetting.GET_SETTING_SUCCESS, ipcAllEntity);
        }
    }

    private void doDelIpcAll(String sn){
        CommonWrapper.getInstance(this.mApp).delData(sn, CommonWrapper.TYPE_GET_IPC_ALL);
    }

    private void doSetIpcAll(String sn, String settingJson, Integer... args) {
        Head head = Api.PadSetting.setSetting(sn, settingJson);
        if (head.errorCode != 0) {
            publishAction(Actions.PadSetting.SET_SETTING_FAIL, head.errorMsg);
        } else {
            String json = String.format("{\"data\":{\"settings\":{\"night_rest\":\"{\\\"wakeupTime\\\":\\\"%1$02d:%2$02d\\\",\\\"sleepTime\\\":\\\"%3$02d:%4$02d\\\",\\\"isOpen\\\":\\\"%5$d\\\"}\"," +
                            "\"capture_video\":\"%6$d\",\"remote_view\":\"%7$d\",\"eye_protection\":\"{\\\"usingTime\\\":%8$02d,\\\"restTime\\\":%9$02d," +
                            "\\\"isOpen\\\":\\\"%10$d\\\"}\"}}}", (Integer) args[0], (Integer) args[1], (Integer) args[2], (Integer) args[3],
                    (Integer) args[4], (Integer) args[5], (Integer) args[6], (Integer) args[7],
                    (Integer) args[8], (Integer) args[9]);
            Gson gson = new Gson();
            IpcAllEntity ipcAllEntity = gson.fromJson(json, IpcAllEntity.class);
            CommonWrapper.getInstance(this.mApp).writeBySnWithType(sn, ipcAllEntity.toJson(), CommonWrapper.TYPE_GET_IPC_ALL);
            publishAction(Actions.PadSetting.SET_SETTING_SUCCESS);
        }
    }

    private void doSetIpcPassword(String sn, String settingJson){
        Head head = Api.PadSetting.setSetting(sn, settingJson);
        if (head.errorCode != 0) {
            publishAction(Actions.PadSetting.SET_SETTING_PASSWORD_FAIL, head.errorMsg);
        } else {
            publishAction(Actions.PadSetting.SET_SETTING_PASSWORD_SUCCESS);
        }
    }
}

