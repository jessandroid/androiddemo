package com.qihoo360.homecamera.mobile.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.entity.ShareGetSharingEntity;
import com.qihoo360.homecamera.mobile.entity.ShareGetSharingListEntitiy;
import com.qihoo360.homecamera.mobile.widget.TextViewWithFont;

/**
 * Created by zhaojunbo on 2016/2/16.
 * desc:
 */
public class FamilyInvitingAdapter extends BaseAdapter {

    private Context mContext;

    private ShareGetSharingListEntitiy shareGetSharingListEntitiy;

    private IOnDeleteItem iOnDeleteItem;

    public FamilyInvitingAdapter(Context context) {
        mContext = context;
    }

    public void setData(ShareGetSharingListEntitiy shareGetSharingListEntitiy) {
        this.shareGetSharingListEntitiy = shareGetSharingListEntitiy;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        if (shareGetSharingListEntitiy != null && shareGetSharingListEntitiy.data != null && shareGetSharingListEntitiy.data.data != null)
            return shareGetSharingListEntitiy.data.data.size();
        else
            return 0;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final ViewHolder viewHolder;
        if (null == convertView) {
            viewHolder = new ViewHolder();
            LayoutInflater mInflater = LayoutInflater.from(mContext);
            convertView = mInflater.inflate(R.layout.item_family_inviting_item, null);
            viewHolder.mDeleteShareIv = (ImageView) convertView.findViewById(R.id.iv_cancel_share);
            viewHolder.shareStyleTv = (TextViewWithFont) convertView.findViewById(R.id.tv_share_style);
            viewHolder.expireTimeTv = (TextViewWithFont) convertView.findViewById(R.id.tv_expire_time);

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        if (shareGetSharingListEntitiy != null && shareGetSharingListEntitiy.data != null && shareGetSharingListEntitiy.data.data != null) {
            final ShareGetSharingEntity shareGetSharingEntity= shareGetSharingListEntitiy.data.data.get(position);
            switch (shareGetSharingEntity.type) {
                case 1:
                    viewHolder.shareStyleTv.setText("已通过二维码邀请家人");
                    break;
                case 2:
                    viewHolder.shareStyleTv.setText("已通过微信邀请家人");
                    break;
                case 3:
                    viewHolder.shareStyleTv.setText("已通过手机号邀请家人");
                    break;
                case 4:
                    viewHolder.shareStyleTv.setText("已通过摄像机二维码邀请家人");
                    break;
            }
            viewHolder.expireTimeTv.setText(shareGetSharingEntity.expire);
            viewHolder.mDeleteShareIv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    iOnDeleteItem.onDeleteItem(position, shareGetSharingEntity.code);
                }
            });
        }

        return convertView;
    }

    class ViewHolder {
        ImageView mDeleteShareIv;
        TextViewWithFont shareStyleTv;
        TextViewWithFont expireTimeTv;
    }

    public interface IOnDeleteItem {
        void onDeleteItem(int pos, String qid);
    }

    public void setiOnDeleteItem(IOnDeleteItem iOnDeleteItem) {
        this.iOnDeleteItem = iOnDeleteItem;
    }
}
