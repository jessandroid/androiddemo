
package com.qihoo360.homecamera.mobile.entity;

public class InnerMsg {
	public long sid;
	public int status; 
	public int reason;
}
