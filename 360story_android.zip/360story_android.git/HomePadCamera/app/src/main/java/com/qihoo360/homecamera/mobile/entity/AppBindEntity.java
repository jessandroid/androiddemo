package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by zhaojunbo on 2016/2/25.
 * desc:
 */
public class AppBindEntity extends Head {

    public Data data;

    public static class Data implements Parcelable {
        public String sn;
        public String imgUrl;
        public String nickName;

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(this.sn);
            dest.writeString(this.imgUrl);
            dest.writeString(this.nickName);
        }

        public Data() {
        }

        protected Data(Parcel in) {
            this.sn = in.readString();
            this.imgUrl = in.readString();
            this.nickName = in.readString();
        }

        public static final Parcelable.Creator<Data> CREATOR = new Parcelable.Creator<Data>() {
            public Data createFromParcel(Parcel source) {
                return new Data(source);
            }

            public Data[] newArray(int size) {
                return new Data[size];
            }
        };
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(this.data, 0);
    }

    public AppBindEntity() {
    }

    protected AppBindEntity(Parcel in) {
        this.data = in.readParcelable(Data.class.getClassLoader());
    }

    public static final Parcelable.Creator<AppBindEntity> CREATOR = new Parcelable.Creator<AppBindEntity>() {
        public AppBindEntity createFromParcel(Parcel source) {
            return new AppBindEntity(source);
        }

        public AppBindEntity[] newArray(int size) {
            return new AppBindEntity[size];
        }
    };
}
