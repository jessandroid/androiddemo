package com.qihoo360.homecamera.mobile.adapter;

import android.content.Context;
import android.content.pm.PackageManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.entity.ShareWayInfo;

import java.util.List;

/**
 * Created by zhaojunbo on 2016/2/15.
 * desc:
 */
public class ChooseInviteWaysAdapter extends BaseAdapter {

    private List<ShareWayInfo> list;
    LayoutInflater inflater;
    private PackageManager pManager;
    private int mNumColumns;

    public ChooseInviteWaysAdapter(Context context, List<ShareWayInfo> list,int numColumns) {
        inflater = LayoutInflater.from(context);
        this.list = list;
        mNumColumns = numColumns;
        pManager = context.getPackageManager();
    }

    public int getCount() {
        if (list == null)
            return 0;
        return list.size();
    }

    public Object getItem(int position) {
        return list.get(position);
    }

    public long getItemId(int position) {
        return position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder viewHolder = null;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.album_photo_share_to_app_list_item, null);
            viewHolder = new ViewHolder();
            viewHolder.appIcon = (ImageView) convertView.findViewById(R.id.appIcon);
            viewHolder.appName = (TextView) convertView.findViewById(R.id.appName);
            viewHolder.dividerRight = convertView.findViewById(R.id.divider_right);
            viewHolder.dividerBottom = convertView.findViewById(R.id.divider_bottom);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        ShareWayInfo shareWayInfo = list.get(position);
        viewHolder.appIcon.setImageResource(shareWayInfo.imageResourceId);
        viewHolder.appName.setText(shareWayInfo.wayName);
//        viewHolder.dividerRight.setVisibility((position % mNumColumns != mNumColumns - 1) ? View.VISIBLE : View.INVISIBLE);
//        viewHolder.dividerBottom.setVisibility((position < list.size() - list.size() % mNumColumns) ? View.VISIBLE : View.INVISIBLE);
        return convertView;
    }

    class ViewHolder {
        ImageView appIcon;
        TextView appName;
        View dividerRight;
        View dividerBottom;
    }

}