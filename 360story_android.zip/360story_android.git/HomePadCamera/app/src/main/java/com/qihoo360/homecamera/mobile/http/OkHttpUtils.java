
package com.qihoo360.homecamera.mobile.http;

import android.os.Handler;
import android.os.Looper;

import com.qihoo360.homecamera.mobile.BuildConfig;
import com.qihoo360.homecamera.mobile.config.DefaultClientConfig;
import com.qihoo360.homecamera.mobile.env.AppEnv;
import com.qihoo360.homecamera.mobile.http.builder.GetBuilder;
import com.qihoo360.homecamera.mobile.http.builder.MachinePostFormBuilder;
import com.qihoo360.homecamera.mobile.http.builder.PostFile2OOSBuilder;
import com.qihoo360.homecamera.mobile.http.builder.PostFileBuilder;
import com.qihoo360.homecamera.mobile.http.builder.PostFormBuilder;
import com.qihoo360.homecamera.mobile.http.builder.PostStringBuilder;
import com.qihoo360.homecamera.mobile.http.callback.Callback;
import com.qihoo360.homecamera.mobile.http.cookie.SimpleCookieJar;
import com.qihoo360.homecamera.mobile.http.https.HttpsUtils;
import com.qihoo360.homecamera.mobile.http.request.RequestCall;
import com.qihoo360.homecamera.mobile.http.utils.LoggingInterceptor;
import com.qihoo360.homecamera.mobile.utils.CLog;

import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.io.InputStream;
import java.security.Principal;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSession;

import okhttp3.Call;
import okhttp3.OkHttpClient;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * Created by Tom on 15/8/17.
 */
public class OkHttpUtils {

    public static final long READ_MILLISECONDS = 30;
    public static final long CONNECT_MILLISECONDS = 30 * 1000;
    public static final long WRITE_MILLISECONDS = DefaultClientConfig.HTTP_TIME_OUT;

    private static OkHttpUtils mInstance;
    private OkHttpClient mOkHttpClient;
    private Handler mDelivery;

    private OkHttpUtils() {
        OkHttpClient.Builder okHttpClientBuilder = new OkHttpClient.Builder();
        okHttpClientBuilder.readTimeout(READ_MILLISECONDS, TimeUnit.SECONDS);
        okHttpClientBuilder.connectTimeout(CONNECT_MILLISECONDS, TimeUnit.MILLISECONDS);
        okHttpClientBuilder.writeTimeout(WRITE_MILLISECONDS, TimeUnit.MILLISECONDS);
        okHttpClientBuilder.retryOnConnectionFailure(true);
        if (BuildConfig.DEBUG) {
            okHttpClientBuilder.addInterceptor(new LoggingInterceptor());
        }
        SimpleCookieJar simpleCookieJar = new SimpleCookieJar();
        okHttpClientBuilder.cookieJar(simpleCookieJar);
        mDelivery = new Handler(Looper.getMainLooper());
        if (!BuildConfig.isDebug) {
            okHttpClientBuilder.hostnameVerifier(new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) {
                    try {
                        javax.security.cert.X509Certificate[] x509Certificates = session.getPeerCertificateChain();
                        Principal principal = null;
                        for (javax.security.cert.X509Certificate x509Certificate : x509Certificates) {
                            principal = x509Certificate.getSubjectDN();
                            if (principal != null && (StringUtils.contains(principal.getName(), "360.cn"))) {
                                return true;
                            }
                        }
                    } catch (SSLPeerUnverifiedException e) {
                        e.printStackTrace();
                        return false;
                    }
                    return true;
                }
            });
        } else {
            okHttpClientBuilder.hostnameVerifier(new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            });
        }
        mOkHttpClient = okHttpClientBuilder.build();
    }

    private boolean debug;

    public OkHttpUtils debug(boolean isDebug) {
        debug = isDebug;
        return this;
    }

    public static OkHttpUtils getInstance() {
        if (mInstance == null) {
            synchronized (OkHttpUtils.class) {
                if (mInstance == null) {
                    mInstance = new OkHttpUtils();
                }
            }
        }
        return mInstance;
    }

    public void clearOkHttpUtils() {
        synchronized (OkHttpUtils.class) {
            mInstance = null;
        }
    }

    public Handler getDelivery() {
        return mDelivery;
    }

    public OkHttpClient getOkHttpClient() {
        return mOkHttpClient;
    }

    public static GetBuilder get() {
        return new GetBuilder();
    }

    public static PostStringBuilder postString() {
        return new PostStringBuilder();
    }

    public static PostFileBuilder postFile() {
        return new PostFileBuilder();
    }

    public static PostFormBuilder postForm() {
        return new PostFormBuilder();
    }

    public static PostFormBuilder post() {
        return new PostFormBuilder();
    }

    public static PostFormBuilder machinePost() {
        return new MachinePostFormBuilder();
    }

    public static PostFile2OOSBuilder postFile2OOS() {
        return PostFile2OOSBuilder.getInstance();
    }

    public void execute(final RequestCall requestCall, Callback callback) {
        if (AppEnv.DEBUG) {
            CLog.d("{method:" + requestCall.getRequest().method() + ", detail:" + requestCall.getOkHttpRequest().toString() + "}");
        }

        if (callback == null)
            callback = Callback.CALLBACK_DEFAULT;
        final Callback finalCallback = callback;

        requestCall.getCall().enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                sendFailResultCallback(call, e, finalCallback);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.code() >= 400 && response.code() <= 599) {
                    ResponseBody res = null;
                    try {
                        res = response.body();
                        Exception e = new RuntimeException(res.string());
                        e.printStackTrace();
                        sendFailResultCallback(call, e, finalCallback);
                    } catch (IOException e) {
                        e.printStackTrace();
                    } finally {
                        if (res != null) {
                            res.close();
                        }
                    }
                    return;
                }

                try {
                    Object o = finalCallback.parseNetworkResponse(response);
                    sendSuccessResultCallback(o, finalCallback);
                } catch (Exception e) {
                    sendFailResultCallback(call, e, finalCallback);
                }

            }
        });
    }

    public void sendFailResultCallback(final Call call, final Exception e, final Callback callback) {

        if (callback == null)
            return;

        mDelivery.post(new Runnable() {
            @Override
            public void run() {
                callback.onError(call, e);
                callback.onAfter();
            }
        });

    }

    public void sendSuccessResultCallback(final Object object, final Callback callback) {
        if (callback == null)
            return;
        mDelivery.post(new Runnable() {
            @Override
            public void run() {
                callback.onResponse(object);
                callback.onAfter();
            }
        });
    }

    public void cancelTag(Object tag) {
        for (Call call : mOkHttpClient.dispatcher().queuedCalls()) {
            if (tag.equals(call.request().tag())) {
                call.cancel();
            }
        }
        for (Call call : mOkHttpClient.dispatcher().runningCalls()) {
            if (tag.equals(call.request().tag())) {
                call.cancel();
            }
        }
    }

    public void setCertificates(InputStream... certificates) {
        mOkHttpClient = getOkHttpClient().newBuilder()
                .sslSocketFactory(HttpsUtils.getSslSocketFactory(certificates, null, null))
                .build();

    }

    public void setConnectTimeout(int timeout, TimeUnit units) {
        mOkHttpClient = getOkHttpClient().newBuilder()
                .connectTimeout(timeout, units)
                .build();
    }


    public static class METHOD {
        public static final String HEAD = "HEAD";
        public static final String DELETE = "DELETE";
        public static final String PUT = "PUT";
        public static final String PATCH = "PATCH";
    }

}
