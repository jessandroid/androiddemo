package com.qihoo360.homecamera.mobile.entity;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;

import com.google.gson.annotations.SerializedName;
import com.qihoo360.homecamera.mobile.utils.TimeUtilNew;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/3/14
 * Time: 17:48
 * To change this template use File | Settings | File Templates.
 */

@SuppressLint("ParcelCreator")
public class Story extends Head implements Parcelable{
    public String id;
    public String duration;
    public String size;
    @SerializedName("listCoverUrl")
    public String listCover_url;
    @SerializedName("coverUrl")
    public String cover_url;
    @SerializedName("videoUrl")
    public String video_url;
    public int from;
    public String name;
    public String unique;
    @SerializedName("recordTime")
    public String record_time;
    public String weight;
    @SerializedName("createTime")
    public String create_time;
    public List<String> category_ids;
    public List<String> tags;
    public String local;
    public ArrayList<String> cateInfo;
    public String linkUrl;
    public String subtitles_url;
    public boolean checked = false;
    public String mp4_path;
    public String lrc_path;
    public String cover;
    public String sn;
    public String qid;
    public StoryUrl storyUrl;
    @SerializedName("intro")
    public String des = "故事描述";
    public String serverIntID ="";
    public boolean isRecord = false;


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeString(this.id);
        dest.writeString(this.duration);
        dest.writeString(this.size);
        dest.writeString(this.listCover_url);
        dest.writeString(this.cover_url);
        dest.writeString(this.video_url);
        dest.writeInt(this.from);
        dest.writeString(this.name);
        dest.writeString(this.unique);
        dest.writeString(this.record_time);
        dest.writeString(this.weight);
        dest.writeString(this.create_time);
        dest.writeStringList(this.category_ids);
        dest.writeStringList(this.tags);
        dest.writeString(this.local);
        dest.writeStringList(this.cateInfo);
        dest.writeString(this.linkUrl);
        dest.writeString(this.subtitles_url);
        dest.writeByte(checked ? (byte) 1 : (byte) 0);
        dest.writeString(this.mp4_path);
        dest.writeString(this.lrc_path);
        dest.writeString(this.cover);
        dest.writeString(this.sn);
        dest.writeString(this.qid);
        dest.writeParcelable(this.storyUrl, flags);
    }

    public Story() {
    }

    protected Story(Parcel in) {
        super(in);
        this.id = in.readString();
        this.duration = in.readString();
        this.size = in.readString();
        this.listCover_url = in.readString();
        this.cover_url = in.readString();
        this.video_url = in.readString();
        this.from = in.readInt();
        this.name = in.readString();
        this.unique = in.readString();
        this.record_time = in.readString();
        this.weight = in.readString();
        this.create_time = in.readString();
        this.category_ids = in.createStringArrayList();
        this.tags = in.createStringArrayList();
        this.local = in.readString();
        this.cateInfo = in.createStringArrayList();
        this.linkUrl = in.readString();
        this.subtitles_url = in.readString();
        this.checked = in.readByte() != 0;
        this.mp4_path = in.readString();
        this.lrc_path = in.readString();
        this.cover = in.readString();
        this.sn = in.readString();
        this.qid = in.readString();
        this.storyUrl = in.readParcelable(StoryUrl.class.getClassLoader());
    }

    public static final Creator<Story> CREATOR = new Creator<Story>() {
        @Override
        public Story createFromParcel(Parcel source) {
            return new Story(source);
        }

        @Override
        public Story[] newArray(int size) {
            return new Story[size];
        }
    };

    public String getCreate_time() {
        long dt = TimeUtilNew.convertDataTimeToLong(this.create_time,"yyyy-MM-dd HH:mm:ss");
        Date dateN = new Date(dt);
        if (dateN != null) {
            StringBuffer stringBuffer = new StringBuffer();
            String date = Utils.formatDay(Utils.DATE_FORMAT_5.format(dateN));
            stringBuffer.append(date);
            if (TextUtils.equals(date, "今天") || TextUtils.equals(date, "昨天")) {
                stringBuffer.append(" ");
                return stringBuffer.append(Utils.DATE_FORMAT_9.format(dateN)).toString();
            }else {
                return Utils.formatDay(Utils.DATE_FORMAT_10.format(dateN));
            }
        } else {
            return "";
        }
    }
}
