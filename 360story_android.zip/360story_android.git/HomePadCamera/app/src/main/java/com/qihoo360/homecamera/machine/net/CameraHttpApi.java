
package com.qihoo360.homecamera.machine.net;

import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.qihoo360.homecamera.device.config.StoryMachineConsts;
import com.qihoo360.homecamera.machine.config.MachineDefaultClientConfig;
import com.qihoo360.homecamera.machine.entity.HttpResult;
import com.qihoo360.homecamera.mobile.BuildConfig;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.SysConfig;
import com.qihoo360.homecamera.mobile.config.Const;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.entity.Head;
import com.qihoo360.homecamera.mobile.exception.CameraAesException;
import com.qihoo360.homecamera.mobile.http.OkHttpUtils;
import com.qihoo360.homecamera.mobile.http.builder.PostFormBuilder;
import com.qihoo360.homecamera.mobile.http.request.RequestCall;
import com.qihoo360.homecamera.mobile.service.MessageService;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.Utils;

import org.apache.http.protocol.HTTP;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.ConnectException;
import java.net.URLEncoder;
import java.util.Map;
import java.util.UUID;

import javax.net.ssl.SSLHandshakeException;

public class CameraHttpApi {

    private final static String TAG = CameraHttpApi.class.getName();

    // 获取mic类型
    public static final String URL_APP_GET_MIC_TYPE = "/app/getMicType";
    // 获取语音双工
    public static final String URL_APP_GET_VOICE_CONF = "/app/getVoiceConf";
    // 手机看家播放
    public static final String URL_PHONE_WATCH_PLAY = "/mobile/play";

    public static final int IV_AUTO = 0;
    public static final int IV_ON = 1;
    public static final int IV_OFF = 2;

    protected boolean auth = true;

    private HttpApi mHttpApi;

    public CameraHttpApi() {
        super();
        try {
            // mHttpApi = new HttpApi(false, Const.DEFAULT_CLIENT_VERSION); //
            // http
            this.auth = true;
            mHttpApi = buildHttpApid(true, MachineDefaultClientConfig.DEFAULT_CLIENT_VERSION); // https
        } catch (Exception e) {
            e.printStackTrace();
            // this.mHttpApi = new HttpApiWithNoAuth(context,
            // Const.DEFAULT_CLIENT_VERSION);
        }
    }

    public CameraHttpApi(boolean auth) {
        super();
        try {
            this.auth = auth;
            mHttpApi = buildHttpApid(auth, MachineDefaultClientConfig.DEFAULT_CLIENT_VERSION); //
            // http
            // mHttpApi = new HttpApi(auth, Const.DEFAULT_CLIENT_VERSION); //
            // https
        } catch (Exception e) {
            e.printStackTrace();
            // this.mHttpApi = new HttpApiWithNoAuth(context,
            // Const.DEFAULT_CLIENT_VERSION);
        }
    }

    protected HttpApi buildHttpApid(boolean auth, String version) throws Exception {
        return new HttpApi(auth, version);
    }

    protected String getDefaultRemoteUrl(String url) {
        if (auth) {
            if (url.startsWith("https")) {
                return url;
            } else {
                return String.format(MachineDefaultClientConfig.APP_SERVER_DOMAIN, url);
            }
        } else {
            if (url.startsWith("http")) {
                return url;
            } else {
                return String.format(MachineDefaultClientConfig.APP_SERVER_DOMAIN_HTTP, url);
            }
        }
    }

    public static String getRemoteUrl(String url, boolean auth) {
        if (auth) {
            if (url.startsWith("https")) {
                return url;
            } else {
                return String.format(MachineDefaultClientConfig.APP_SERVER_DOMAIN, url);

            }
        } else {
            if (url.startsWith("http")) {
                return url;
            } else {
                return String.format(MachineDefaultClientConfig.APP_SERVER_DOMAIN_HTTP, url);
            }
        }
    }

    /**
     * 通用请求方法
     *
     * @param params 请求参数
     * @param url 请求地址 CameraHttpApi常量里有
     * @param clazz bean.class
     * @return 当clazz.newInstance()异常的时候返回null, 需要上层判断处理; 当 errorCode
     *         为-1时代表服务器响应成功但不是200,需要上层根据statusCode做出判断进行处理 当 errorCode 为其他值时,请参看Constants.Http常量
     */
    public <T extends Head> T doCommonRequestWithOutCookie(JSONObject params, String url,
            Class<? extends T> clazz) {
        try {
            if (!Utils.isNetworkAvailable(Utils.getContext())) {
                T head = clazz.newInstance();
                head.setErrorCode(Constants.Http.ERROR_CODE_NET_UNAVAILABLE);
                head.setErrorMsg(Utils.getString(R.string.network_disabled));
                return head;
            }
            String taskid;
            if (!params.has("taskid")) {
                taskid = UUID.randomUUID().toString();
                params.put("taskid", taskid);
            } else {
                taskid = params.getString("taskid");
            }
            String sn = null;
            if (params.has("sn")) {
                sn = params.getString("sn");
            }

            T t = mHttpApi.executeHttpRequest(getDefaultRemoteUrl(url), params, clazz);
            if (t.getErrorCode() == Constants.Http.ERROR_CODE_UNAUTHORIZED) {// 返回错误码442,帐号互斥
                Context context = Utils.getContext();
                context.sendBroadcast(new Intent(Const.BROADCAST_APP_AGAIN));
            } else if (t.getErrorCode() == Constants.Http.ERROR_CODE_SIDOVERDUE) {
                Context context = Utils.getContext();
                context.sendBroadcast(new Intent(Const.BROADCAST_APP_AGAIN));
            } else if (t.getErrorCode() == Constants.Http.ERROR_CODE_SIDOVERDUE) {
                Context context = Utils.getContext();
                context.sendBroadcast(new Intent(Const.BROADCAST_APP_AGAIN));
            } else if (t.getErrorCode() == Constants.Http.ERROR_CODE_NET_WAP) {
                Context context = Utils.getContext();
                Intent intent = new Intent(MachineDefaultClientConfig.ACTION_COMMON_GLOBAL);
                intent.putExtra("actionCode", Actions.GlobalActionCode.WAP_NET_ERROR);
                context.sendBroadcast(intent);
            }
            return t;
        } catch (Exception e) {
            //Log.e(TAG,"Exception ------> "+e.toString());
            e.printStackTrace();
            return (T) getStatusCode(e, clazz);
        }
    }

    /**
     * 通用请求方法
     *
     * @param params 请求参数
     * @param url 请求地址 CameraHttpApi常量里有
     * @param clazz bean.class
     * @return 当clazz.newInstance()异常的时候返回null, 需要上层判断处理; 当 errorCode
     *         为-1时代表服务器响应成功但不是200,需要上层根据statusCode做出判断进行处理 当 errorCode 为其他值时,请参看Constants.Http常量
     */
    public <T extends Head> T doCommonRequest(JSONObject params, String url,
            Class<? extends T> clazz) {
        try {
            String taskid;
            if (!params.has("taskid")) {
                taskid = UUID.randomUUID().toString();
                params.put("taskid", taskid);
            } else {
                taskid = params.getString("taskid");
            }

            if (!Utils.isNetworkAvailable(Utils.getContext())) {
                T head = clazz.newInstance();
                head.taskid = taskid;
                head.setErrorCode(Constants.Http.ERROR_CODE_NET_UNAVAILABLE);
                head.setErrorMsg(Utils.getString(R.string.network_disabled));
                return head;
            }
            params.put("channel_id", SysConfig.CHANNEL_ID);
            String urls;
            if (url.startsWith("https") || url.startsWith("http")) {
                urls = url;
            } else {
                urls = getDefaultRemoteUrl(url);
            }
            //Log.e(TAG, "urls = " + urls);
//            HttpPost httpPost = mHttpApi.createHttpPost(urls, params, true);

            String sn = null;
            if (params.has("sn")) {
                sn = params.getString("sn");
            }
//
            JSONObject eparams = new JSONObject();
            eparams.put("parad", params.toString());
            eparams.put("from", Const.FROM);

            T t = mHttpApi.executeHttpRequest(urls, eparams, clazz);
            if (t.getErrorCode() == Constants.Http.ERROR_CODE_UNAUTHORIZED) {// 返回错误码442,帐号互斥
                Context context = Utils.getContext();
                context.sendBroadcast(new Intent(Const.BROADCAST_APP_AGAIN));
            } else if (t.getErrorCode() == Constants.Http.ERROR_CODE_SIDOVERDUE) {
                Context context = Utils.getContext();
                context.sendBroadcast(new Intent(Const.BROADCAST_APP_AGAIN));
            } else if (t.getErrorCode() == Constants.Http.ERROR_CODE_NET_WAP) {
                Context context = Utils.getContext();
                Intent intent = new Intent(MachineDefaultClientConfig.ACTION_COMMON_GLOBAL);
                intent.putExtra("actionCode", Actions.GlobalActionCode.WAP_NET_ERROR);
                context.sendBroadcast(intent);
            }
            t.taskid = taskid;
            return t;
        } catch (Exception e) {
            e.printStackTrace();
            return (T) getStatusCode(e, clazz);
        }
    }

    /**
     * 
     * @param url 拼好的完整的请求行
     * @param clazz
     * @return
     */
    public <T extends Head> T doSpecialGetRequest(String url, Class<? extends T> clazz) {
        CLog.d("doSpecialGetRequest:" + url);
        try {
            if (!Utils.isNetworkAvailable(Utils.getContext())) {
                T head = clazz.newInstance();
                head.setErrorCode(Constants.Http.ERROR_CODE_NET_UNAVAILABLE);
                head.setErrorMsg(Utils.getString(R.string.network_disabled));
                return head;
            }

            //mHttpApi.createHttpGet(url, false);
            return mHttpApi.executeHttpGetRequest(url, clazz);
        } catch (Exception e) {
            e.printStackTrace();
            return getStatusCode(e, clazz);
        }
    }

    public String doJsonRequest(String url) throws JSONException {
        Gson g = new Gson();
        Head head = new Head();
        try {
            if (!Utils.isNetworkAvailable(Utils.getContext())) {
                head.errorCode = Constants.Http.ERROR_CODE_NET_UNAVAILABLE;
                head.errorMsg = Utils.getString(R.string.network_disabled);
                return g.toJson(head);
            }
            return mHttpApi.executeHttpRequest4ReturnJson(url);
        } catch (Exception e) {
            e.printStackTrace();
            head.errorCode = Constants.Http.ERROR_CODE_NET_UNAVAILABLE;
            head.errorMsg = Utils.getString(R.string.network_disabled);
            return g.toJson(head);
        }
    }

    public String doJsonRequestWithStatusCode(String url) throws JSONException {
        Gson g = new Gson();
        Head head = new Head();
        try {
            if (!Utils.isNetworkAvailable(Utils.getContext())) {
                head.errorCode = Constants.Http.ERROR_CODE_NET_UNAVAILABLE;
                head.errorMsg = Utils.getString(R.string.network_disabled);
                return g.toJson(head);
            }
            return mHttpApi.executeHttpRequest4ReturnJson(url, true);
        } catch (Exception e) {
            e.printStackTrace();
            head.errorCode = Constants.Http.ERROR_CODE_NET_UNAVAILABLE;
            head.errorMsg = Utils.getString(R.string.network_disabled);
            return g.toJson(head);
        }
    }

    /**
     * 异步通用的post请求 加了超时逻辑,等待push作为返回
     *
     * @param params
     * @param url
     * @param clazz
     * @return 参见doCommonRequest
     */
    public <T extends Head> T doAysnCommonRequest(JSONObject params, String url,
            Class<? extends T> clazz) {
        Utils.getContext().startService(new Intent(Utils.getContext(), MessageService.class));
        try {
            if (!Utils.isNetworkAvailable(Utils.getContext())) {
                T head = clazz.newInstance();
                head.setErrorCode(Constants.Http.ERROR_CODE_NET_UNAVAILABLE);
                head.setErrorMsg(Utils.getString(R.string.network_disabled));
                return head;
            }
            CLog.d("getDefaultRemoteUrl(url):------->" + getDefaultRemoteUrl(url));
            String taskid = "";
            if (!params.has("taskid")) {
                taskid = UUID.randomUUID().toString();
                params.put("taskid", taskid);
            } else {
                taskid = params.getString("taskid");
            }
            T t = mHttpApi.executeAysnHttpRequest(getDefaultRemoteUrl(url), params, clazz, true);
            String sn = "";
            if (params.has("sn")) {
                sn = params.getString("sn");
            }
            params.put("channel_id", SysConfig.CHANNEL_ID);
            //            LogUtil.getInstance().setTimestamp(sn, taskid, LogUtil.TYPE2, LogUtil.T3);
            //            if (t.getErrorCode() != Constants.Http.ERROR_CODE_SUCCEED) {
            //                LogUtil.getInstance().saveLogValue(sn, taskid, LogUtil.TYPE4, t.getErrorCode(), 0, null);
            //            }

            if (t.getErrorCode() == Constants.Http.ERROR_CODE_UNAUTHORIZED) {// 返回错误码442,帐号互斥
                Context context = Utils.getContext();
                context.sendBroadcast(new Intent(Const.BROADCAST_APP_AGAIN));
            } else if (t.getErrorCode() == Constants.Http.ERROR_CODE_NET_WAP) {
                Context context = Utils.getContext();
                Intent intent = new Intent(MachineDefaultClientConfig.ACTION_COMMON_GLOBAL);
                intent.putExtra("actionCode", Actions.GlobalActionCode.WAP_NET_ERROR);
                context.sendBroadcast(intent);
            }
            return t;
        } catch (Exception e) {
            e.printStackTrace();
            return getStatusCode(e, clazz);
        }
    }

    protected static <T extends Head> T getStatusCode(Exception e, Class<? extends T> clazz) {
        try {
            T head = clazz.newInstance();
            if (e instanceof JSONException) {
                head.setErrorCode(Constants.Http.ERROR_CODE_JSON);
                return head;
            } else if (e instanceof CameraAesException) {
                head.setErrorCode(Constants.Http.ERROR_CODE_ENCODING);
                return head;
            } else if (e instanceof NullPointerException) {
                head.setErrorCode(Constants.Http.ERROR_CODE_SSL);
                return head;
            } else if (e instanceof ConnectException) {
                head.setErrorCode(Constants.Http.ERROR_CODE_CONNECTION);
                return head;
            } else if (e instanceof SSLHandshakeException) {
                head.setErrorCode(Constants.Http.ERROR_CODE_SSL_HANDS);
                return head;
            }
            return head;
        } catch (Exception e1) {
            e1.printStackTrace();
            return null;
        }
    }

    //上传图片方法
    public <T extends Head> T uploadFile(String url, Map<String, String> params, File file, Class<? extends T> clazz) {
        try {
            String taskid;
            if (!params.containsKey("taskid")) {
                taskid = UUID.randomUUID().toString();
                params.put("taskid", taskid);
            } else {
                taskid = (String) params.get("taskid");
            }

            params.put("from", MachineDefaultClientConfig.FROM);
            params.put(StoryMachineConsts.PUSH_KEY_VERSION, StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);

            if (!Utils.isNetworkAvailable(Utils.getContext())) {
                T head;
                head = clazz.newInstance();
                head.setErrorCode(Constants.Http.ERROR_CODE_NET_UNAVAILABLE);
                head.setErrorMsg("网络不可用");
                return head;
            }

            T t = null;

            StringBuffer cookies = new StringBuffer();
            if (auth) {
                cookies.append("q").append("=").append(URLEncoder.encode(AccUtil.getInstance().getQ(), HTTP.UTF_8))
                        .append(";");
                cookies.append("t").append("=").append(URLEncoder.encode(AccUtil.getInstance().getT(), HTTP.UTF_8))
                        .append(";");
                cookies.append("qid").append("=").append(AccUtil.getInstance().getQID()).append(";");
                try {
                    if (!TextUtils.isEmpty(AccUtil.getInstance().getSessionId())) {
                        cookies.append("sid").append("=").append(URLEncoder.encode(AccUtil.getInstance()
                                .getSessionId(), HTTP.UTF_8))
                                .append(";");
                    }
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                    CLog.e("UnsupportedEncodingException");
                }
            }

            PostFormBuilder pfb = (PostFormBuilder) OkHttpUtils.post().params(params)
                    .addHeader("cookie", cookies.toString()).url(getDefaultRemoteUrl(url));
            pfb.addFile("imgData", file.getName(), file);
            if (Const.DEBUG) {
                pfb.addHeader("host", "story.kibot.360.cn");
            }

            RequestCall request = pfb.build();

            CLog.d("request:" + request.getOkHttpRequest().toString());

            String content = request.execute();

            if (!TextUtils.isEmpty(content)) {
                JSONObject json = new JSONObject(content);
                // CLog.d("the json  is :" + json);
                json.put("statusCode", 200);
                t = jsonToBeanFromHttp(clazz, json.toString());
            } else {
                t = clazz.newInstance();
                t.setErrorCode(-1);
                t.setErrorMsg("Request exception");
            }
            return t;

        } catch (Exception e) {
            e.printStackTrace();
            return (T) getStatusCode(e, clazz);
        }
    }

    public <T extends Head> T jsonToBeanFromHttp(Class<T> type, String source) {
        Gson gson = new Gson();
        try {
            HttpResult result = gson.fromJson(source, HttpResult.class);
            T head;
            if (result.data != null) {
                head = jsonToBean(type, result.data.toString(), gson);
                head.setErrorCode(result.errorCode);
                head.setErrorMsg(result.errorMsg);
                head.setStatusCode(result.statusCode);
            } else {
                head = gson.fromJson(source, type);
            }
            return head;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static <T> T jsonToBean(Class<T> type, String source, Gson gson) {
        try {
            T result = gson.fromJson(source, type);
            return result;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static <T> String toJson(T obj, Gson gson) {
        String result = gson.toJson(obj);
        return result;
    }
}
