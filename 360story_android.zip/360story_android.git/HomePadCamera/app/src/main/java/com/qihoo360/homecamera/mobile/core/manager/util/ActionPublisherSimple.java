
package com.qihoo360.homecamera.mobile.core.manager.util;

public interface ActionPublisherSimple {
    void registerActionListener(ActionListener listener);
}
