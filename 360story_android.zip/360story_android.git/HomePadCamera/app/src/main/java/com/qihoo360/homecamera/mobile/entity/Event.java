
package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;
import com.qihoo360.homecamera.mobile.config.Constants;

import java.io.Serializable;

public class Event implements CameraType, Serializable, ShareAble {

    public static final int SUBTYPE_IMAGE = 1;
    public static final int SUBTYPE_VIDEO_CLOUD = 2;
    public static final int SUBTYPE_VIDEO_MP4 = 3;

    public static final class TYPE {
        public static final int MOVING = 1;
        public static final int OVERLINE = 2;
        public static final int FACE = 3;
        public static final int PET = 4;
    }

    public static final long serialVersionUID = 8777063686119840714L;
    public int id; // 事件id
    public String imgKey = "";// 服务器给的key
    public String sn;
    @SerializedName("type")
    public int eventType = -1;// 事件类型
    public static int eventDateType = -2;
    public long eventTime = -1; // 事件发生事件
    public String snapUrl = "";
    public String snapPath = ""; // 无用，兼容
    @SerializedName("title")
    public String cameraName = "";
    public String thumbUrl = "";
    public String thumbLocalPath = "";
    public int delPos;
    // public int eventSafeType = -1;// 不知道干啥用的，哪儿都没用到 先注掉 by changxiao

    private boolean isLoadDone;

    public int subType; // 0:image, 1:cloud video, 2:mp4
    public String cloudEvent; // cloud event id
    public String videoUrl; // if mp4
    public String localVideoUrl;
    public long videoSize; // mp4 at present
    public long duration = 5000; // mp4 at present
    public long startTime;

    public int humanCnt;

    public void fillData(Constants.Push push) {
//        this.sn = push.getSN();
//        if (push.type == Constants.Push.TYPE_MOTION) {
////            this.eventType = CameraHttpApi.COMMAND[CameraHttpApi.CMD_SETTING_MOVING].equals(push.value.key) ? TYPE.MOVING
////                    : TYPE.OVERLINE;
//            this.eventType = TYPE.MOVING; // TODO confirm with Wangcheng
//        } else if (push.type == Constants.Push.TYPE_EVENT_FACE) {
//            this.eventType = TYPE.FACE;
//        } else if (push.type == Constants.Push.TYPE_EVENT_PET) {
//            this.eventType = TYPE.PET;
//        }
//        this.eventTime = push.value.eventtime;
//        this.snapUrl = push.value.snap_url;
//        this.thumbUrl = push.value.thumb_url;
//        this.cameraName = push.title;
//        this.imgKey = push.value.imgKey;
//        // this.eventSafeType = push.type;
//        //this.eventShowType = push.value.eventShowType;
//        this.subType = push.subtype;
//        this.cloudEvent = push.value.cloudEvent;
//        this.videoUrl = push.value.video_url;
//        this.startTime = push.value.starttime;
    }

    @Override
    public String getPath() {
//        if (TextUtils.isEmpty(snapPath)) {
//                String imgDate = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(eventTime);
//            if (eventDateType!= TYPE.FACE && eventDateType!= TYPE.PET) {
//                snapPath = FileUtil.getEventFile().getAbsolutePath() + "/" + imgDate + "_" + imgKey + ".jpg";
//            }else {
//                snapPath = FileUtil.getSafeGateFile().getAbsolutePath() + "/" + imgDate + "_" + imgKey + ".jpg";
//            }
//        }
//        return snapPath;
        return "";
    }

    public Event() {
    }

    private Event(Parcel in) {
        this.id = in.readInt();
        this.sn = in.readString();
        this.eventType = in.readInt();
        this.eventTime = in.readLong();
        this.snapUrl = in.readString();
        this.cameraName = in.readString();
        this.thumbUrl = in.readString();
        this.thumbLocalPath = in.readString();
    }

    public static final Parcelable.Creator<Event> CREATOR = new Parcelable.Creator<Event>() {
        public Event createFromParcel(Parcel source) {
            return new Event(source);
        }

        public Event[] newArray(int size) {
            return new Event[size];
        }
    };

    public void setIsImageLoaded(boolean isDone) {
        isLoadDone = isDone;
    }

    public boolean getIsImageLoaded() {
        return isLoadDone;
    }

    public boolean isVideoAlertEvent() {
        //return !TextUtils.isEmpty(cloudEvent) || !TextUtils.isEmpty(videoUrl);
        return subType == SUBTYPE_VIDEO_CLOUD || subType == SUBTYPE_VIDEO_MP4;
    }

    public boolean isMovingEvent() {
        return eventType == TYPE.MOVING;
    }

    public boolean isCloudVideoEvent() {
        return subType == Event.SUBTYPE_VIDEO_CLOUD;
    }

    public boolean isMp4VideoEvent() {
        return subType == Event.SUBTYPE_VIDEO_MP4;
    }

    @Override
    public String toString() {
        return String.format("Event{sn=%s, eventType=%d, subType=%d, imgKey=%s, " +
                "eventTime=%s, thumbUrl=%s, cloudEvent=%s, videoUrl=%s}",
                sn, eventType, subType, imgKey, String.valueOf(eventTime),
                thumbUrl, cloudEvent, videoUrl);
    }

    public void buildEntity() {

    }
}
