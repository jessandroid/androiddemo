
package com.qihoo360.homecamera.machine.entity;

import android.text.TextUtils;

import com.qihoo360.homecamera.machine.util.JSONUtils;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.io.Serializable;

public class PublicCamera extends Replay implements Serializable, Comparable<PublicCamera> {
    /**
     * 
     */
    public static final long serialVersionUID = -3426611883437923894L;

    public String sn;

    public boolean isShow = false;

    public String qid = "";
    public String nickName = "";
    public String imageUrl;

    public String titlePub = "智能摄像机"; // 更新公开摄像机的标题
    public String locationPub; // 更新摄像机的地理位置
    public String locationInfo; // 更新摄像机的详细地理信息
    public Weather weather;

    public String desc = Utils.getContext().getString(R.string.public_camera_des_null); // 更新摄像机的描述
    public String thumbnail;

    public int publicTime = 0;
    public int viewNum = 0;
    public int voteNum = 0;

    public String topicid = "";// 谈谈聊天室ID
    public int channel = 0;
    public String extend = "";

    public int online = 0; // 0表示离线 1表示在线
    public int status = 0; // 0 默认是0 在线。如果是1表示离线，2 表示已经撤销
    public int followNum = 0;

    public String linkTitle;
    public String linkUrl;

    public int isFollow = -1; // 用于获取临时数据

    public int foreshowType = 2;
    public Foreshow foreshow;
    public int state = 1;//记录是否离线

    public PublicCameraSupport support;

    @Override
    public int compareTo(PublicCamera publicCamera) {
        return 0;
    }

    public String getQid() {
        return qid;
    }

    public void setQid(String qid) {
        this.qid = qid;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getTitlePub() {
        return titlePub;
    }

    public void setTitlePub(String titlePub) {
        this.titlePub = titlePub;
    }

    public String getLocationPub() {
        return locationPub;
    }

    public void setLocationPub(String locationPub) {
        this.locationPub = locationPub;
    }

    public String getLocationInfo() {
        return locationInfo;
    }

    public void setLocationInfo(String locationInfo) {
        this.locationInfo = locationInfo;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }


    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public int getViewNum() {
        return viewNum;
    }

    public void setViewNum(int viewNum) {
        this.viewNum = viewNum;
    }

    public int getVoteNum() {
        return voteNum;
    }

    public void setVoteNum(int voteNum) {
        this.voteNum = voteNum;
    }

    public int getPublicTime() {
        return publicTime;
    }

    public void setPublicTime(int publicTime) {
        this.publicTime = publicTime;
    }

    public String getTopicid() {
        return topicid;
    }

    public void setTopicid(String topicid) {
        this.topicid = topicid;
    }

    public int getChannel() {
        return channel;
    }

    public void setChannel(int channel) {
        this.channel = channel;
    }

    public String getExtend() {
        return extend;
    }

    public void setExtend(String extend) {
        this.extend = extend;
    }

    public int getOnline() {
        return online;
    }

    public void setOnline(int online) {
        this.online = online;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getFollowNum() {
        return followNum;
    }

    public void setFollowNum(int followNum) {
        this.followNum = followNum;
    }

    public int getIsFollow() {
        return isFollow;
    }

    public void setIsFollow(int isFollow) {
        this.isFollow = isFollow;
    }

    public String getLinkUrl() {
        return linkUrl;
    }

    public String getLinkTitle() {
        return linkTitle;
    }

    public PublicCameraSupport getSupport() {
        if (support == null) {
            support = new PublicCameraSupport();
        }
        return support;
    }

    // MapLocation
    public MapLocation locationObj;

    public MapLocation getLocationObj() {
        if (locationObj == null) {
            if (!TextUtils.isEmpty(locationInfo)) {
                locationObj = JSONUtils.fromJson(MapLocation.class, locationInfo);
            } else {
                // 兼容
                if (TextUtils.isEmpty(locationPub)) {
                    locationObj = new MapLocation();
                    locationObj.setType(MapLocation.ChooseTypes.None);
                } else {
                    locationObj = new MapLocation();
                    locationObj.setType(MapLocation.ChooseTypes.Point);
                    String city = "";
                    String title;
                    if (locationPub.contains("·")) {
                        city = locationPub.substring(0, locationPub.indexOf("·"));
                        title = locationPub.substring(locationPub.indexOf("·") + 1);
                    } else {
                        title = locationPub;
                    }
                    locationObj.setCity(city);
                    locationObj.setTitle(title);
                    locationObj.setSnippet(title);
                }
            }
        }
        return locationObj;
    }

    public void setLocationObj(MapLocation location) {
        if (location != null) {
            locationObj = location;
            locationInfo = JSONUtils.toJson(location);
            locationPub = location.getLocationPub();
        }
    }

    // Extend
    public PublicExtend extendObj;

    public PublicExtend getExtendObj() {
        if (extendObj == null) {
            if (!TextUtils.isEmpty(extend) && !extend.equals("[]")) {
                extendObj = JSONUtils.fromJson(PublicExtend.class, extend);
            } else {
                extendObj = new PublicExtend();
            }
        }
        return extendObj;
    }

    public void setExtendObj(PublicExtend obj) {
        extendObj = obj;
        extend = JSONUtils.toJson(obj);
    }

    public void synData(PublicCamera camera) {
        CLog.d("updateList-----synData:");
        setTitlePub(camera.getTitlePub());
        setDesc(camera.getDesc());
        setLocationObj(camera.getLocationObj());
        setExtendObj(camera.getExtendObj());
        setViewNum(camera.getViewNum());
        setStatus(camera.getStatus());
        setOnline(camera.getOnline());
        setFollowNum(camera.getFollowNum());
        setVoteNum(camera.getVoteNum());
    }

    public boolean getIsMine() {
        CLog.d("Debug isMine-------------mPublicCamera:" + getQid() + "AccUtil:" + AccUtil.getInstance().getQID());
        return TextUtils.equals(getQid(), AccUtil.getInstance().getQID());
    }

    public String toString(){
        return "[sn="+sn+", qid="+qid+", nickName="+nickName+" imageUrl="+imageUrl+" viewNum="+viewNum+" voteNum="+voteNum+
                " channel="+channel+" followNum="+followNum + " linkTitle="+linkTitle+" linkUrl="+linkUrl+" extend="+extend+"]";
    }
}
