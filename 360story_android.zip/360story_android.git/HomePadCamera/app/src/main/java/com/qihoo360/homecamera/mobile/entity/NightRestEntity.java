package com.qihoo360.homecamera.mobile.entity;

/**
 * Created by zhaojunbo on 2016/9/2.
 * desc:
 */
public class NightRestEntity {

    public String wakeupTime;
    public String sleepTime;
    public String isOpen;

}
