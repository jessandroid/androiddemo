package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by hyuan on 2016/9/9.
 */
public class SenderInfo implements Parcelable  {

    public String sn;
    public String title;
    public String qid;

    public static final Parcelable.Creator<SenderInfo> CREATOR = new Parcelable.Creator<SenderInfo>() {
        @Override
        public SenderInfo createFromParcel(Parcel source) {
            return new SenderInfo(source);
        }

        @Override
        public SenderInfo[] newArray(int size) {
            return new SenderInfo[size];
        }
    };

    private SenderInfo(Parcel in) {
        sn = in.readString();
        title = in.readString();
        qid = in.readString();
    }

    @Override
    public void writeToParcel(Parcel out, int flags) {
        out.writeString(sn);
        out.writeString(title);
        out.writeString(qid);
    }

    @Override
    public int describeContents() {
        return 0;
    }

}
