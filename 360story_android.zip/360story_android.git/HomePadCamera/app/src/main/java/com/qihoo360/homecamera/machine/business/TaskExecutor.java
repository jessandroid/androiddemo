package com.qihoo360.homecamera.machine.business;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * 
 * 线程池
 * 
 */
public class TaskExecutor {

	private static ExecutorService executorService = Executors.newFixedThreadPool(6);

	/*** 私有的默认构造子 */
	private TaskExecutor() {

	}

	/**
	 * * 静态工厂方法
	 */
	@SuppressWarnings("rawtypes")
    public static Future Execute(Runnable task) {
		Future future = null;
		if (executorService.isShutdown()) {
			executorService = Executors.newFixedThreadPool(6);
			future = executorService.submit(task);
		} else {
			future = executorService.submit(task);
		}
		return future;
	}

	/**
	 * * 停止线程池中所有正在执行线程
	 */
	public static void shutdownNow() {
		executorService.shutdownNow();
	}

}
