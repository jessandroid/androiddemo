package com.qihoo360.homecamera.machine.ui.adapter;

import android.content.Context;
import android.graphics.drawable.AnimationDrawable;
import android.os.Handler;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.facebook.stetho.common.Util;
import com.jakewharton.rxbinding.view.RxView;
import com.qihoo360.accounts.base.utils.DesUtil;
import com.qihoo360.homecamera.machine.entity.FamilyMessageEntity;
import com.qihoo360.homecamera.machine.entity.SongEntity;
import com.qihoo360.homecamera.machine.util.ChatTimeFormatUtil;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.db.MachineSongWrapper;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.DensityUtil;
import com.qihoo360.homecamera.mobile.utils.Preferences;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.widget.RoundImageView;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import butterknife.Bind;
import butterknife.ButterKnife;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

/**
 * Created by zhangtao-iri on 2016/10/31.
 */
public class FamilyGroupListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{

    private final static int MY_TEXT_TYPE = 1;
    private final static int MY_VOICE_TYPE = 2;
    private final static int MY_EXPREESION_TYPE = 3;
    private final static int OTHER_TEXT_TYPE = 4;
    private final static int OTHER_VOICE_TYPE = 5;
    private final static int OTHER_EXPRESS_TYPE = 6;

    private ArrayList<FamilyMessageEntity> messageList; //儿歌列表
    private Context mContext;
    private MessageInterface msgInterface;
    private final long FIVEMIUNTE = 5*60*1000;//5分钟的毫秒数

    public FamilyGroupListAdapter(Context context, MessageInterface messageInterface){
        this.mContext = context;
        messageList = new ArrayList<>();
        this.msgInterface = messageInterface;
    }

    //设置数据
    public void setData(ArrayList<FamilyMessageEntity> msgList) {
        this.messageList = msgList;
        notifyDataSetChanged();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        switch (viewType){
            case MY_TEXT_TYPE:
                view = getViewByLayoutId(parent, R.layout.family_group_item_owner_text);
                return new MyTextViewHold(view);

            case MY_VOICE_TYPE:
                view = getViewByLayoutId(parent, R.layout.family_group_item_owner_voice);
                return new MyVoiceViewHold(view);

            case MY_EXPREESION_TYPE:
                view = getViewByLayoutId(parent, R.layout.family_group_item_owner_express);
                return new MyExpreesionViewHold(view);

            case OTHER_TEXT_TYPE:
                view = getViewByLayoutId(parent, R.layout.family_group_item_other_text);
                return new OtherTextViewHold(view);

            case OTHER_VOICE_TYPE:
                view = getViewByLayoutId(parent, R.layout.family_group_item_other_voice);
                return new OtherVoiceViewHold(view);

            case OTHER_EXPRESS_TYPE:
                view = getViewByLayoutId(parent, R.layout.family_group_item_other_express);
                return new OtherExpreesionViewHold(view);
        }
        view = getViewByLayoutId(parent, R.layout.family_group_item_owner_text);
        return new MyTextViewHold(view);
    }

    private View getViewByLayoutId(ViewGroup parent, int layoutId){
        return LayoutInflater.from(parent.getContext()).inflate(layoutId, parent, false);
    }

    @Override
    public long getItemId(int position) {
        return super.getItemId(position);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        final FamilyMessageEntity messageEntity = messageList.get(position);
        if(messageEntity==null){
            return;
        }
        long currentTime = messageEntity.getSendTime();

        if(holder instanceof MyTextViewHold){
            //我的文字消息
            MyTextViewHold myTextViewHold = (MyTextViewHold) holder;
            Glide.with(mContext)
                    .load(messageEntity.getAvatarUrl())
                    .diskCacheStrategy(DiskCacheStrategy.RESULT)
                    .dontAnimate()
                    .placeholder(R.drawable.default_profile_img)
                    .priority(Priority.HIGH)
                    .error(R.drawable.default_profile_img)
                    .into(myTextViewHold.mtProfileImg);
            myTextViewHold.mtMsgContent.setText(messageEntity.getContent());
            if(messageEntity.getMsgState()==0){
                Utils.ensureVisbility(myTextViewHold.mtLoadingZone, View.GONE);
                Utils.ensureVisbility(myTextViewHold.mtMsgLoading, View.GONE);
                Utils.ensureVisbility(myTextViewHold.mtMsgRetry, View.GONE);
            }else if(messageEntity.getMsgState()==1){
                Utils.ensureVisbility(myTextViewHold.mtLoadingZone, View.VISIBLE);
                Utils.ensureVisbility(myTextViewHold.mtMsgLoading, View.GONE);
                Utils.ensureVisbility(myTextViewHold.mtMsgRetry, View.VISIBLE);
            }else if(messageEntity.getMsgState()==2){
                Utils.ensureVisbility(myTextViewHold.mtLoadingZone, View.VISIBLE);
                Utils.ensureVisbility(myTextViewHold.mtMsgLoading, View.VISIBLE);
                Utils.ensureVisbility(myTextViewHold.mtMsgRetry, View.GONE);
            }
            //开启发送loading动画
            if(myTextViewHold.mtMsgLoading.getVisibility() == View.VISIBLE){
                Animation anim = AnimationUtils.loadAnimation(mContext, R.anim.rotate_icon);
                myTextViewHold.mtMsgLoading.startAnimation(anim);
            }else{
                myTextViewHold.mtMsgLoading.clearAnimation();
            }
            //重试点击事件
            if(myTextViewHold.mtMsgRetry.getVisibility() == View.VISIBLE){
                RxView.clicks(myTextViewHold.mtMsgRetry).throttleFirst(300, TimeUnit.MILLISECONDS).observeOn(AndroidSchedulers.mainThread())
                        .subscribe(new Action1<Void>() {
                            @Override
                            public void call(Void aVoid) {
                                msgInterface.clickRetry(position);
                            }
                        });
            }

            if(position==0){
                //如果是第一个必须显示时间
                Utils.ensureVisbility(myTextViewHold.timeZome, View.VISIBLE);
                myTextViewHold.timeText.setText(ChatTimeFormatUtil.getNewChatTime(currentTime));
            }else{
                long preTime = messageList.get(position-1).getSendTime();
                if(currentTime-preTime > FIVEMIUNTE){
                    Utils.ensureVisbility(myTextViewHold.timeZome, View.VISIBLE);
                    myTextViewHold.timeText.setText(ChatTimeFormatUtil.getNewChatTime(currentTime));
                }else{
                    Utils.ensureVisbility(myTextViewHold.timeZome, View.GONE);
                }
            }

        }else if(holder instanceof MyVoiceViewHold){
            MyVoiceViewHold myVoiceViewHold = (MyVoiceViewHold)holder;
            //我的语音消息
            Glide.with(mContext)
                    .load(messageEntity.getAvatarUrl())
                    .diskCacheStrategy(DiskCacheStrategy.RESULT)
                    .dontAnimate()
                    .placeholder(R.drawable.default_profile_img)
                    .priority(Priority.HIGH)
                    .error(R.drawable.default_profile_img)
                    .into(myVoiceViewHold.mvProfileImg);

            myVoiceViewHold.mvVoiceLength.setText(String.format(mContext.getString(R.string.audio_duration), messageEntity.getMsgSize()));
            RelativeLayout.LayoutParams param = (RelativeLayout.LayoutParams) myVoiceViewHold.mvVoiceMsgZone.getLayoutParams();
            param.width = DensityUtil.dip2px(60+5*messageEntity.getMsgSize());
            myVoiceViewHold.mvVoiceMsgZone.setLayoutParams(param);

            RxView.clicks(myVoiceViewHold.mvVoiceMsgZone).observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Action1<Void>() {
                        @Override
                        public void call(Void aVoid) {
                            msgInterface.clickPlayAudio(position);
                        }
                    }
            );
            if(messageEntity.getMsgState()==0){
                Utils.ensureVisbility(myVoiceViewHold.mvLoadingZone, View.GONE);
                Utils.ensureVisbility(myVoiceViewHold.mvMsgLoading, View.GONE);
                Utils.ensureVisbility(myVoiceViewHold.mvMsgRetry, View.GONE);
            }else if(messageEntity.getMsgState()==1){
                Utils.ensureVisbility(myVoiceViewHold.mvLoadingZone, View.VISIBLE);
                Utils.ensureVisbility(myVoiceViewHold.mvMsgLoading, View.GONE);
                Utils.ensureVisbility(myVoiceViewHold.mvMsgRetry, View.VISIBLE);
            }else if(messageEntity.getMsgState()==2){
                Utils.ensureVisbility(myVoiceViewHold.mvLoadingZone, View.VISIBLE);
                Utils.ensureVisbility(myVoiceViewHold.mvMsgLoading, View.VISIBLE);
                Utils.ensureVisbility(myVoiceViewHold.mvMsgRetry, View.GONE);
            }
            //开启发送loading动画
            if(myVoiceViewHold.mvMsgLoading.getVisibility() == View.VISIBLE){
                Animation anim = AnimationUtils.loadAnimation(mContext, R.anim.rotate_icon);
                myVoiceViewHold.mvMsgLoading.startAnimation(anim);
            }else{
                myVoiceViewHold.mvMsgLoading.clearAnimation();
            }
            if(myVoiceViewHold.mvMsgRetry.getVisibility() == View.VISIBLE){
                RxView.clicks(myVoiceViewHold.mvMsgRetry).throttleFirst(300, TimeUnit.MILLISECONDS)
                        .subscribe(new Action1<Void>() {
                            @Override
                            public void call(Void aVoid) {
                                msgInterface.clickRetry(position);
                            }
                        });
            }

            //TODO 是否开启播放动画
            if(messageEntity.getIsPlaying()==0){//不播
                final AnimationDrawable ad = (AnimationDrawable) myVoiceViewHold.mvVoiceAnimation.getBackground();
                CLog.e("zt","ad isRuning:"+ad.isRunning());
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        ad.stop();
                        ad.selectDrawable(0);
                    }
                });
            }else{//播放
                final AnimationDrawable ad = (AnimationDrawable) myVoiceViewHold.mvVoiceAnimation.getBackground();
                if(!ad.isRunning()){
                    mHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            ad.start();
                        }
                    });
                }
            }

            if(position==0){
                //如果是第一个必须显示时间
                Utils.ensureVisbility(myVoiceViewHold.timeZome, View.VISIBLE);
                myVoiceViewHold.timeText.setText(ChatTimeFormatUtil.getNewChatTime(currentTime));
            }else{
                long preTime = messageList.get(position-1).getSendTime();
                if(currentTime-preTime > FIVEMIUNTE){
                    Utils.ensureVisbility(myVoiceViewHold.timeZome, View.VISIBLE);
                    myVoiceViewHold.timeText.setText(ChatTimeFormatUtil.getNewChatTime(currentTime));
                }else{
                    Utils.ensureVisbility(myVoiceViewHold.timeZome, View.GONE);
                }
            }

        }else if(holder instanceof MyExpreesionViewHold){
            //我的表情消息
            MyExpreesionViewHold myExpreesionViewHold = (MyExpreesionViewHold)holder;

            Glide.with(mContext)
                    .load(messageEntity.getAvatarUrl())
                    .diskCacheStrategy(DiskCacheStrategy.RESULT)
                    .dontAnimate()
                    .placeholder(R.drawable.default_profile_img)
                    .priority(Priority.HIGH)
                    .error(R.drawable.default_profile_img)
                    .into(myExpreesionViewHold.meProfileImg);

            //需要根据id去加载不同的图片
            myExpreesionViewHold.meExpreeionImg.setImageResource(getImageById(Integer.valueOf(messageEntity.getContent())));

            if(messageEntity.getMsgState()==0){
                Utils.ensureVisbility(myExpreesionViewHold.meLoadingZone, View.GONE);
                Utils.ensureVisbility(myExpreesionViewHold.meMsgLoading, View.GONE);
                Utils.ensureVisbility(myExpreesionViewHold.meMsgRetry, View.GONE);
            }else if(messageEntity.getMsgState()==1){
                Utils.ensureVisbility(myExpreesionViewHold.meLoadingZone, View.VISIBLE);
                Utils.ensureVisbility(myExpreesionViewHold.meMsgLoading, View.GONE);
                Utils.ensureVisbility(myExpreesionViewHold.meMsgRetry, View.VISIBLE);
            }else if(messageEntity.getMsgState()==2){
                Utils.ensureVisbility(myExpreesionViewHold.meLoadingZone, View.VISIBLE);
                Utils.ensureVisbility(myExpreesionViewHold.meMsgLoading, View.VISIBLE);
                Utils.ensureVisbility(myExpreesionViewHold.meMsgRetry, View.GONE);
            }
            //开启发送loading动画
            if(myExpreesionViewHold.meMsgLoading.getVisibility() == View.VISIBLE){
                Animation anim = AnimationUtils.loadAnimation(mContext, R.anim.rotate_icon);
                myExpreesionViewHold.meMsgLoading.startAnimation(anim);
            }else{
                myExpreesionViewHold.meMsgLoading.clearAnimation();
            }
            //是否开启播放表情语音的动画
            if(messageEntity.getIsPlaying()==0){//不播
                final AnimationDrawable ad = (AnimationDrawable) myExpreesionViewHold.meExpreeVoice.getBackground();
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        ad.stop();
                        ad.selectDrawable(0);
                    }
                });

            }else{//播放
                final AnimationDrawable ad = (AnimationDrawable) myExpreesionViewHold.meExpreeVoice.getBackground();
                if(!ad.isRunning()){
                    mHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            ad.start();
                        }
                    });
                }
            }

            //重试点击事件
            if(myExpreesionViewHold.meMsgRetry.getVisibility() == View.VISIBLE){
                RxView.clicks(myExpreesionViewHold.meMsgRetry).throttleFirst(300, TimeUnit.MILLISECONDS)
                        .subscribe(new Action1<Void>() {
                            @Override
                            public void call(Void aVoid) {
                                msgInterface.clickRetry(position);
                            }
                        });
            }

            RxView.clicks(myExpreesionViewHold.meExpreeionImg).throttleFirst(300, TimeUnit.MILLISECONDS)
                    .subscribe(new Action1<Void>() {
                        @Override
                        public void call(Void aVoid) {
                            msgInterface.clickExpreesion(position);
                        }
                    });

            RxView.clicks(myExpreesionViewHold.meExpreeVoice).throttleFirst(300, TimeUnit.MILLISECONDS)
                    .subscribe(new Action1<Void>() {
                        @Override
                        public void call(Void aVoid) {
                            msgInterface.clickExpreesion(position);
                        }
                    });

            if(position==0){
                //如果是第一个必须显示时间
                Utils.ensureVisbility(myExpreesionViewHold.timeZome, View.VISIBLE);
                myExpreesionViewHold.timeText.setText(ChatTimeFormatUtil.getNewChatTime(currentTime));
            }else{
                long preTime = messageList.get(position-1).getSendTime();
                if(currentTime-preTime > FIVEMIUNTE){
                    Utils.ensureVisbility(myExpreesionViewHold.timeZome, View.VISIBLE);
                    myExpreesionViewHold.timeText.setText(ChatTimeFormatUtil.getNewChatTime(currentTime));
                }else{
                    Utils.ensureVisbility(myExpreesionViewHold.timeZome, View.GONE);
                }
            }

        }else if(holder instanceof OtherTextViewHold){
            //其他的文字消息
            OtherTextViewHold otherTextViewHold = (OtherTextViewHold)holder;

            Glide.with(mContext)
                    .load(messageEntity.getAvatarUrl())
                    .diskCacheStrategy(DiskCacheStrategy.RESULT)
                    .dontAnimate()
                    .placeholder(R.drawable.default_profile_img)
                    .priority(Priority.HIGH)
                    .error(R.drawable.default_profile_img)
                    .into(otherTextViewHold.otProfileImg);

            if(!TextUtils.isEmpty(messageEntity.getContent())){
                otherTextViewHold.otMsgText.setText(messageEntity.getContent());
            }

            if(!TextUtils.isEmpty(messageEntity.getRelation())){
                otherTextViewHold.otRelation.setText(messageEntity.getRelation());
            }

            if(position==0){
                //如果是第一个必须显示时间
                Utils.ensureVisbility(otherTextViewHold.timeZome, View.VISIBLE);
                otherTextViewHold.timeText.setText(ChatTimeFormatUtil.getNewChatTime(currentTime));
            }else{
                long preTime = messageList.get(position-1).getSendTime();
                if(currentTime-preTime > FIVEMIUNTE){
                    Utils.ensureVisbility(otherTextViewHold.timeZome, View.VISIBLE);
                    otherTextViewHold.timeText.setText(ChatTimeFormatUtil.getNewChatTime(currentTime));
                }else{
                    Utils.ensureVisbility(otherTextViewHold.timeZome, View.GONE);
                }
            }

        }else if(holder instanceof OtherVoiceViewHold){
            //其他的语音消息
            OtherVoiceViewHold otherVoiceViewHold = (OtherVoiceViewHold)holder;

            Glide.with(mContext)
                    .load(messageEntity.getAvatarUrl())
                    .diskCacheStrategy(DiskCacheStrategy.RESULT)
                    .dontAnimate()
                    .placeholder(R.drawable.default_profile_img)
                    .priority(Priority.HIGH)
                    .error(R.drawable.default_profile_img)
                    .into(otherVoiceViewHold.ovProfileImg);

            if(!TextUtils.isEmpty(messageEntity.getRelation())){
                otherVoiceViewHold.ovRelation.setText(messageEntity.getRelation());
            }

            otherVoiceViewHold.ovVoiceLength.setText(String.format(mContext.getString(R.string.audio_duration), messageEntity.getMsgSize()));

            RelativeLayout.LayoutParams param = (RelativeLayout.LayoutParams) otherVoiceViewHold.ovVoiceSmgZone.getLayoutParams();
            param.width = DensityUtil.dip2px(60+5*messageEntity.getMsgSize());
            otherVoiceViewHold.ovVoiceSmgZone.setLayoutParams(param);

            Utils.ensureVisbility(otherVoiceViewHold.ovUnreadTip, messageEntity.getHadRead()==0 ? View.GONE : View.VISIBLE);

            RxView.clicks(otherVoiceViewHold.ovVoiceSmgZone).throttleFirst(300, TimeUnit.MILLISECONDS)
                  .subscribe(new Action1<Void>() {
                      @Override
                      public void call(Void aVoid) {
                          msgInterface.clickPlayAudio(position);
                      }
                  });

            //TODO 是否开启播放动画
            if(messageEntity.getIsPlaying()==0){//不播
                final AnimationDrawable ad = (AnimationDrawable) otherVoiceViewHold.ovVoiceAnimation.getBackground();
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        ad.stop();
                        ad.selectDrawable(0);
                    }
                });

            }else{//播放
                final AnimationDrawable ad = (AnimationDrawable) otherVoiceViewHold.ovVoiceAnimation.getBackground();
                if(!ad.isRunning()){
                    mHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            ad.start();
                        }
                    });
                }
            }

            if(position==0){
                //如果是第一个必须显示时间
                Utils.ensureVisbility(otherVoiceViewHold.timeZome, View.VISIBLE);
                otherVoiceViewHold.timeText.setText(ChatTimeFormatUtil.getNewChatTime(currentTime));
            }else{
                long preTime = messageList.get(position-1).getSendTime();
                if(currentTime-preTime > FIVEMIUNTE){
                    Utils.ensureVisbility(otherVoiceViewHold.timeZome, View.VISIBLE);
                    otherVoiceViewHold.timeText.setText(ChatTimeFormatUtil.getNewChatTime(currentTime));
                }else{
                    Utils.ensureVisbility(otherVoiceViewHold.timeZome, View.GONE);
                }
            }

        }else if(holder instanceof OtherExpreesionViewHold){
            //其他的表情消息
            OtherExpreesionViewHold oeExpreesionViewHold = (OtherExpreesionViewHold)holder;

            Glide.with(mContext)
                    .load(messageEntity.getAvatarUrl())
                    .diskCacheStrategy(DiskCacheStrategy.RESULT)
                    .dontAnimate()
                    .placeholder(R.drawable.default_profile_img)
                    .priority(Priority.HIGH)
                    .error(R.drawable.default_profile_img)
                    .into(oeExpreesionViewHold.oeProfileImg);

            //需要根据id去加载不同的图片
            oeExpreesionViewHold.oeExpressionImg.setImageResource(getImageById(Integer.valueOf(messageEntity.getContent())));

            oeExpreesionViewHold.oeRelation.setText(messageEntity.getRelation());

            //是否开启播放表情语音的动画
            if(messageEntity.getIsPlaying()==0){//不播
                final AnimationDrawable ad = (AnimationDrawable) oeExpreesionViewHold.oeExpressionVoice.getBackground();
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        ad.stop();
                        ad.selectDrawable(0);
                    }
                });

            }else{//播放
                final AnimationDrawable ad = (AnimationDrawable) oeExpreesionViewHold.oeExpressionVoice.getBackground();
                if(!ad.isRunning()){
                    mHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            ad.start();
                        }
                    });
                }
            }

            RxView.clicks(oeExpreesionViewHold.oeExpressionImg).throttleFirst(300, TimeUnit.MILLISECONDS)
                    .subscribe(new Action1<Void>() {
                        @Override
                        public void call(Void aVoid) {
                            msgInterface.clickExpreesion(position);
                        }
                    });

            RxView.clicks(oeExpreesionViewHold.oeExpressionVoice).throttleFirst(300, TimeUnit.MILLISECONDS)
                    .subscribe(new Action1<Void>() {
                        @Override
                        public void call(Void aVoid) {
                            msgInterface.clickExpreesion(position);
                        }
                    });

            if(position==0){
                //如果是第一个必须显示时间
                Utils.ensureVisbility(oeExpreesionViewHold.timeZome, View.VISIBLE);
                oeExpreesionViewHold.timeText.setText(ChatTimeFormatUtil.getNewChatTime(currentTime));
            }else{
                long preTime = messageList.get(position-1).getSendTime();
                if(currentTime-preTime > FIVEMIUNTE){
                    Utils.ensureVisbility(oeExpreesionViewHold.timeZome, View.VISIBLE);
                    oeExpreesionViewHold.timeText.setText(ChatTimeFormatUtil.getNewChatTime(currentTime));
                }else{
                    Utils.ensureVisbility(oeExpreesionViewHold.timeZome, View.GONE);
                }
            }
        }
    }

    private int getImageById(int emoId){
        switch (emoId){
            case 1:
                return R.drawable.chating_get_dressed;
            case 2:
                return R.drawable.chating_brush_teeth;
            case 3:

                return R.drawable.chating_wash_hands;
            case 4:
                return R.drawable.chating_have_meal;
            case 5:
                return R.drawable.chating_drink_water;
            case 6:
                return R.drawable.chating_go_to_kindergarten;
            case 7:
                return R.drawable.chating_take_shower;
            case 8:
                return R.drawable.chating_sleep;
        }
        return R.drawable.get_dressed;
    }

    @Override
    public int getItemViewType(int position) {
        FamilyMessageEntity entity = messageList.get(position);
        if(entity.getMsgType()==0 && entity.getOwner()==0){
            return MY_TEXT_TYPE;
        }else if(entity.getMsgType()==0 && entity.getOwner()==1){
            return OTHER_TEXT_TYPE;
        }else if(entity.getMsgType()==1 && entity.getOwner()==0){
            return MY_VOICE_TYPE;
        }else if(entity.getMsgType()==1 && entity.getOwner()==1){
            return OTHER_VOICE_TYPE;
        }else if(entity.getMsgType()==2 && entity.getOwner()==0){
            return MY_EXPREESION_TYPE;
        }else if(entity.getMsgType()==2 && entity.getOwner()==1){
            return OTHER_EXPRESS_TYPE;
        }
        return MY_TEXT_TYPE;
    }

    @Override
    public int getItemCount() {
        return messageList!=null ? messageList.size() : 0;
    }

    //我发的文字
    public class MyTextViewHold extends RecyclerView.ViewHolder{

        @Bind(R.id.my_profile)
        RoundImageView mtProfileImg;//头像

        @Bind(R.id.loading_zone)
        View mtLoadingZone;    //整个发送和重试区域

        @Bind(R.id.msg_loading)
        ImageView mtMsgLoading;//正在发送的按钮

        @Bind(R.id.msg_retry)
        ImageView mtMsgRetry;   //重试按钮

        @Bind(R.id.msg_content)
        TextView mtMsgContent;

        @Bind(R.id.time_zone)
        RelativeLayout timeZome;

        @Bind(R.id.time_text)
        TextView timeText;

        public MyTextViewHold(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    //我发的voice
    public class MyVoiceViewHold extends RecyclerView.ViewHolder{

        @Bind(R.id.my_profile)
        RoundImageView mvProfileImg;

        @Bind(R.id.voice_length)
        TextView mvVoiceLength;//语音大小

        @Bind(R.id.voice_msg_zone)
        ImageView mvVoiceMsgZone;  //语音消息区域

        @Bind(R.id.loading_zone)
        View mvLoadingZone;

        @Bind(R.id.msg_loading)
        ImageView mvMsgLoading;

        @Bind(R.id.msg_retry)
        ImageView mvMsgRetry;

        @Bind(R.id.time_zone)
        RelativeLayout timeZome;

        @Bind(R.id.time_text)
        TextView timeText;

        @Bind(R.id.my_voice_animation)
        ImageView mvVoiceAnimation;

        public MyVoiceViewHold(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    //我发的表情
    public class MyExpreesionViewHold extends RecyclerView.ViewHolder{

        @Bind(R.id.expression_img)
        ImageView meExpreeionImg;  //表情图片

        @Bind(R.id.express_voice)
        ImageView meExpreeVoice;//播放表情语音的动画

        @Bind(R.id.my_profile)
        RoundImageView meProfileImg;

        @Bind(R.id.loading_zone)
        View meLoadingZone;

        @Bind(R.id.msg_loading)
        ImageView meMsgLoading;

        @Bind(R.id.msg_retry)
        ImageView meMsgRetry;

        @Bind(R.id.time_zone)
        RelativeLayout timeZome;

        @Bind(R.id.time_text)
        TextView timeText;

        public MyExpreesionViewHold(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    //其他人发的文字
    public class OtherTextViewHold extends RecyclerView.ViewHolder{

        @Bind(R.id.other_profile)
        RoundImageView otProfileImg;

        @Bind(R.id.reletion)
        TextView otRelation;    //发送者关系

        @Bind(R.id.msg_content)
        TextView otMsgText;     //消息内容

        @Bind(R.id.time_zone)
        RelativeLayout timeZome;

        @Bind(R.id.time_text)
        TextView timeText;

        public OtherTextViewHold(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    //其他人发的voice
    public class OtherVoiceViewHold extends RecyclerView.ViewHolder{

        @Bind(R.id.other_profile)
        RoundImageView ovProfileImg;

        @Bind(R.id.reletion)
        TextView ovRelation;  //发送者关系

        @Bind(R.id.voice_msg_zone)
        View ovVoiceSmgZone;  //语音消息区域

        @Bind(R.id.voice_length)
        TextView ovVoiceLength;//语音大小

        @Bind(R.id.unread_tip)
        ImageView ovUnreadTip;//语音消息未读提醒

        @Bind(R.id.time_zone)
        RelativeLayout timeZome;

        @Bind(R.id.time_text)
        TextView timeText;
        @Bind(R.id.voice_animation)
        ImageView ovVoiceAnimation;

        public OtherVoiceViewHold(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    //其他人发的表情
    public class OtherExpreesionViewHold extends RecyclerView.ViewHolder{

        @Bind(R.id.other_profile)
        RoundImageView oeProfileImg;

        @Bind(R.id.reletion)
        TextView oeRelation;

        @Bind(R.id.expression_img)
        ImageView oeExpressionImg;  //表情图片

        @Bind(R.id.expression_voice)
        ImageView oeExpressionVoice;//播放表情语音的动画

        @Bind(R.id.time_zone)
        RelativeLayout timeZome;

        @Bind(R.id.time_text)
        TextView timeText;

        public OtherExpreesionViewHold(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    private Handler mHandler = new Handler();

    public interface MessageInterface{
        public void clickPlayAudio(int pos);
        public void clickRetry(int pos);
        public void clickExpreesion(int pos);
    }
}
