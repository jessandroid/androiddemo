
package com.qihoo360.homecamera.mobile.config;

import com.qihoo360.accounts.base.common.Constant;
import com.qihoo360.homecamera.mobile.BuildConfig;

import static com.qihoo360.homecamera.mobile.config.DefaultClientConfig.APP_SERVER_DOMAIN_HTTP_SP;
import static com.qihoo360.homecamera.mobile.config.DefaultClientConfig.APP_SERVER_DOMAIN_HTTP_TEST_SP;

/**
 * Created by zhaojunbo on 2016/1/18.
 * desc:
 */
public class Const {

    public static boolean HTTP_FLAG = false;
    public static final boolean DEBUG = true;
    public static int PHONE_CALLING_ID = 0;

    public static final boolean USE_IN_APP_WEB = true;
    public static final String FIND_PWD = "http://i.360.cn/findpwdwap";
    public static final boolean FOR_MONKEY_TEST = false;

    /**
     * TODO 是否需要邮箱注册 默认为需要邮箱注册，当不需要邮箱注册时，可以设置下列值 Constant.VALUE_ADD_ACCOUNT_HAS_EMAIL //需要邮箱注册
     * Constant.VALUE_ADD_ACCOUNT_NO_EMAIL //不需要邮箱注册
     */
    public static int ACCOUNT_REGISTER_NEED_EMAIL = Constant.VALUE_ADD_ACCOUNT_HAS_EMAIL;

    /**
     * TODO 帐号注册类型 默认为注册邮箱需要激活，当不需要激活时，可以设置相应的值 Constant.VALUE_ADD_ACCOUNT_EMAIL_REGISTER
     * //邮箱注册，不需要激活 Constant.VALUE_ADD_ACCOUNT_EMAIL_REGISTER_ACTIVE //邮箱注册，需要激活
     */
    public static int ACCOUNT_REGISTER_EMAIL_ACTIVE = Constant.VALUE_ADD_ACCOUNT_EMAIL_REGISTER_ACTIVE;

    /**
     * TODO 是否需要手机上行短信 默认为下行短信注册，当业务方需要上行时，可以设置相应的值 Constant.VALUE_ADD_ACCOUNT_DOWN_SMS_REGISTER
     * //下行短信注册 Constant.VALUE_ADD_ACCOUNT_UP_SMS_REGISTER //上行短信注册
     */
    public static int ACCOUNT_REGISTER_MOBILE_TYPE = Constant.VALUE_ADD_ACCOUNT_DOWN_SMS_REGISTER;

    public static final String SSO_LOGIN_ACCOUNTS_KEY = "accounts";

    public static final String BROADCAST_APP_PWD_CHANGED = "com.qihoo.jia.PWD_CHANGED";
    public static final String BROADCAST_APP_BIND_PHONE_CHANGED = "com.qihoo.jia.BIND_PHONE_CHANGED";
    public static final String BROADCAST_APP_AGAIN = "com.qihoo.jia.SESSION_ID_OVERTIME";
    public static final String BROADCAST_FAMILY_REQUEST = "com.qihoo.jia.FAMILY_REQUEST";
    public static final String BROADCAST_MASTER_AGREE_AND_REFRESH_LIST = "com.qihoo.jia.MASTER_AGREE_AND_REFRESH_LIST";
    public static final String BROADCAST_REFRESH_INVITED_AND_INVITING_LIST = "com.qihoo.jia.REFRESH_INVITED_AND_INVITING_LIST";
    public static final String BROADCAST_SEND_CLOSE_BROADCAST = "com.qihoo.jia.SEND_CLOSE_BROADCAST";
    public static final String BROADCAST_ACCOUNT_CHANGE = "com.qihoo.jia.ACCOUNT_CHANGE";
    public static final String BROADCAST_INNER_CLOSE = "com.qihoo.jia.INNER_CLOSE";
    public static final String BROADCAST_SHARE_MESSAGE_REFRESH_LIST = "com.qihoo.jia.SHARE_MESSAGE_REFRESH_LIST";
    public static final String BROADCAST_NOTIFY_END_CALLING = "com.qihoo.jia.NOTIFY_END_CALLING";
    public static final String BROADCAST_FRIEND_REQUEST = "com.qihoo.jia.FRIEND_REQUEST";
    public static final String BROADCAST_BATTERY_LOW = "com.qihoo.jia.BROADCAST_BATTERY_LOW";
    public static final String ROBOT_LOCK_SCREEN_RECEIPT = "com.qihoo.jia.ROBOT_LOCK_SCREEN_RECEIPT";
    public static final String FROM = "mpc_pingmuban_and";
    public static final String CLIENT_VERSION_HEADER = "User-Agent";
    public static final String WLJIELOGTAG = "WLJIE-LOG-TAG";

    public final static class FileCategory {
        public final static int GENERAL_FILE = 0;
        public final static int IMAGE = 1;
        public final static int DOCUMENT = 2;
        public final static int MUSIC = 3;
        public final static int VIDEO = 4;

        // Not from server, only used locally
        public final static int ZIP = -1001;
        public final static int TEXT = -1002;
    }

    // 微信APP_ID MD5：0dfa62adafadde2f74b51626edba2fc7
    // public static final String WECHAT_APP_ID = "wx344ec4e81301be10";
    public static final String WECHAT_APP_ID = "wx9c5ce978933eb51c";

    // sina微博APP_KEY
    // public static final String WEIBO_APP_KEY = "1278629738";
    public static final String WEIBO_APP_KEY = "1496192087";
    public static final String WEIBO_App_Secret = "50e5bc0089aec0ccbc0348d480e16a5b";

    public static final String REDIRECT_URL = "https://api.weibo.com/oauth2/default.html";
    public static final String SCOPE = "email,direct_messages_read,direct_messages_write,"
            + "friendships_groups_read,friendships_groups_write,statuses_to_me_read,"
            + "follow_app_official_microblog," + "invitation_write";

    // QQ APP_ID
    public static final String QQ_APP_ID = "1105270177";

    public static final String KIBOT_OFFICAL = "http://kibot.360.cn/wap_index.html";
    public static final String USER_PROTOCOL = "http://kibot.360.cn/story/wap_protocol_license.html";
    public static final String USER_PRIVACY = "http://kibot.360.cn/story/wap_protocol_privacy.html";
    public static final String PROBLEM_URL = "http://kibot.360.cn/mobile/app/question.html";
    public static final String MACHINE_PROBLEM_URL = "http://kibot.360.cn/story/question_list.html";
    public static final String BBS_FORUM = "http://bbs.360.cn/forum-7081-1.html";
    public static final String STORY_MACHINE_BBS_FORUM = "http://bbs.360.cn/forum-7193-1.html";

    public static final String URL_SPLASH_IMAGE_V2 = (BuildConfig.isDebug ? APP_SERVER_DOMAIN_HTTP_TEST_SP
            : APP_SERVER_DOMAIN_HTTP_SP) + "/start/spconfig.json";

    // 缓冲区最小大小 单位M
    public static final long MINAVAILABLESPARE = 10L;
    // 录像时允许最小内存余量 单位M
    public static final long MINAVAILABLESPARE_RECORD = 200L;
}
