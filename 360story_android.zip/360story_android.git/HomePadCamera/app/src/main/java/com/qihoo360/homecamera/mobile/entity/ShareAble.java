package com.qihoo360.homecamera.mobile.entity;

public interface ShareAble {
    public String getPath();
}
