package com.qihoo360.homecamera.mobile.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.entity.ShareGetListEntity;
import com.qihoo360.homecamera.mobile.entity.ShareUserEntity;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.widget.TextViewWithFont;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by yanggang on 2016/6/13.
 */
public class FamilyMemberAdapter extends RecyclerView.Adapter<FamilyMemberAdapter.ViewHolder> {

    private Context mContext;
    private boolean mMaster;//是否为主人
    private int mMaxItemCount = 0;

    private ShareGetListEntity shareGetListEntity;

    private OnViewClick onViewClick;

    public FamilyMemberAdapter(Context context, boolean bMaster) {
        this.mContext = context;
        this.mMaster = bMaster;
    }

    public void setOnViewClick(OnViewClick onViewClick) {
        this.onViewClick = onViewClick;
    }

    public void setData(ShareGetListEntity data, int count) {
        this.shareGetListEntity = data;
        if (count > 0)
            this.mMaxItemCount = count;
        else
            this.mMaxItemCount = this.shareGetListEntity.data.data.size();
        notifyDataSetChanged();
    }

    public int getShareListCount() {
        if (this.shareGetListEntity != null) {
            return this.shareGetListEntity.data.data.size();
        } else {
            return 0;
        }
    }


    public void setMaxCount(int count) {
        if (count > 0)
            this.mMaxItemCount = count;
        else
            this.mMaxItemCount = this.shareGetListEntity.data.data.size();
        notifyDataSetChanged();
    }

    @Override
    public long getItemId(int position) {
        return super.getItemId(position);
    }

    @Override
    public int getItemViewType(int position) {
        return super.getItemViewType(position);
    }

    @Override
    public void onViewRecycled(ViewHolder holder) {
        super.onViewRecycled(holder);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.family_member_item_view, parent, false);
        ButterKnife.bind(this, view);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        if (shareGetListEntity != null && shareGetListEntity.data != null && shareGetListEntity.data.data != null) {
            if (position < shareGetListEntity.data.data.size()) {
                final ShareUserEntity shareUserEntity = shareGetListEntity.data.data.get(position);
                //设置头像
                if (!TextUtils.isEmpty(shareUserEntity.imgUrl)) {
                    Glide.with(mContext)
                            .load(shareUserEntity.imgUrl + (shareUserEntity.imgUrl.contains("?") ? "&from=mpc_pingmuban_and" : "?from=mpc_pingmuban_and"))
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .error(R.drawable.icon_avator_empty)
                            .into(holder.ivAvator);
                } else {
                    holder.ivAvator.setImageResource(R.drawable.icon_avator_empty);
                }
                //根据角色设置显示内容
                if (shareUserEntity.role.equals(String.valueOf(Constants.Role.FRIEND))) {
                    String name = TextUtils.isEmpty(shareUserEntity.remarkName) ? shareUserEntity.nickName : shareUserEntity.remarkName;
                    name = TextUtils.isEmpty(name) ? shareUserEntity.phone : name;
                    if(TextUtils.isEmpty(shareUserEntity.qid)){
                        name = "未注册("+name+")";
                        holder.tvNickname.setText(name);
                    }else{
                        holder.tvNickname.setText(name);
                    }
                    holder.ivRobot.setVisibility(View.VISIBLE);
                } else {//当前成员是自己或者家人的情况
                    String name = TextUtils.isEmpty(shareUserEntity.getRelation()) ? shareUserEntity.nickName : shareUserEntity.getRelation();
                    name = TextUtils.isEmpty(name) ? shareUserEntity.phone : name;
                    //当前成员是自己
                    if (shareUserEntity.phone != null && shareUserEntity.phone.equals(AccUtil.getInstance().getSecPhoneNumber())) {
                        name = "我(" + name + ")";
                        holder.tvNickname.setText(name);
                    }else{
                        if(TextUtils.isEmpty(shareUserEntity.qid)){
                            name = "未注册("+name+")";
                            holder.tvNickname.setText(name);
                        }else{
                            holder.tvNickname.setText(name);
                        }
                    }
                    holder.ivRobot.setVisibility(View.GONE);
                }
                if (mMaster) {//机器人主人是自己
                    holder.rlMemberItem.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onViewClick.onEditFamily(shareUserEntity);
                        }
                    });
                }
            } else {
                if (mMaster) {//当前为最后一项 显示添加的按钮
                    holder.ivAvator.setImageResource(R.drawable.icon_family_member_more);
                    holder.tvNickname.setText("添加");
                    holder.ivRobot.setVisibility(View.GONE);
                    holder.rlMemberItem.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            onViewClick.onNewFamily();
                        }
                    });
                }
            }
        } else {
            if (mMaster) {
                holder.ivAvator.setImageResource(R.drawable.icon_family_member_more);
                holder.tvNickname.setText("添加");
                holder.ivRobot.setVisibility(View.GONE);
                holder.rlMemberItem.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onViewClick.onNewFamily();
                    }
                });
            }
        }
    }

    @Override
    public int getItemCount() {
        if (shareGetListEntity != null && shareGetListEntity.data != null && shareGetListEntity.data.data != null)
            return this.mMaxItemCount + (mMaster ? 1 : 0);
        else
            return (mMaster ? 1 : 0);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        @Bind(R.id.iv_avator)
        ImageView ivAvator;
        @Bind(R.id.iv_robot)
        ImageView ivRobot;
        @Bind(R.id.tv_nickname)
        TextViewWithFont tvNickname;
        @Bind(R.id.ll_member_item)
        RelativeLayout rlMemberItem;

        public ViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    public interface OnViewClick {
        void onNewFamily();

        void onEditFamily(ShareUserEntity deviceInfo);
    }
}
