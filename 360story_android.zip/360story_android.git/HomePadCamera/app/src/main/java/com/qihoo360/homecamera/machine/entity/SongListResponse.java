package com.qihoo360.homecamera.machine.entity;

import com.qihoo360.homecamera.mobile.entity.Head;

import java.util.ArrayList;

/**
 * Created by zhangtao-iri on 2016/12/20.
 */
public class SongListResponse extends Head{

    public int total;

    public int pageSize;

    public String coverurl;//封面图

    public ArrayList<SongEntity> data;
}
