package com.qihoo360.homecamera.machine.activity;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.View;

import com.qihoo360.homecamera.machine.config.MachineConsts;
import com.qihoo360.homecamera.machine.fragment.StoryPlayerFragment;
import com.qihoo360.homecamera.mobile.R;


/**
 * 播放器界面
 */
public class StoryPlayerActivity extends MachineBaseActivity {

    @Override
    protected void onCreate(Bundle arg0) {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE);
        super.onCreate(arg0);
        setContentView(R.layout.activity_story_player);
        FragmentTransaction beginTransaction = getSupportFragmentManager().beginTransaction();
        Fragment fragment = new StoryPlayerFragment();
        beginTransaction.replace(R.id.common_fragment, fragment).commitAllowingStateLoss();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
