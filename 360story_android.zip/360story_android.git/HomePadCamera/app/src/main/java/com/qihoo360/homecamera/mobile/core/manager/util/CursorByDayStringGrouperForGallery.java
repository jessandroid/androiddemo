
package com.qihoo360.homecamera.mobile.core.manager.util;

import android.database.Cursor;

import com.qihoo360.homecamera.mobile.db.IGrouper;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class CursorByDayStringGrouperForGallery implements IGrouper<String, Cursor> {

    private final int mDateColumnIndex;
    private final boolean mColumnIsStringFormat;
    private final Date mDate = new Date();
    private static final long Now_Time = new Date().getTime();
    private static final long One_Day_Time = 24 * 60 * 60 * 1000;
    public final SimpleDateFormat mDateFormat = new SimpleDateFormat("yyyy年M月d日", Locale.CHINA);
    public final SimpleDateFormat mBriefDateFormat = new SimpleDateFormat("M月d日", Locale.CHINA);
    public final SimpleDateFormat mWeekDateFormat = new SimpleDateFormat("EEEE", Locale.CHINA);
    public static final long Today_Time = Now_Time - Now_Time % One_Day_Time;
    public static final long Yesterday_Time = Today_Time - One_Day_Time;
    public static final long More_Time = Yesterday_Time - One_Day_Time;
    private long Year_Time = 0;
    public static final long Week_Time = Now_Time - One_Day_Time * 7;

    public CursorByDayStringGrouperForGallery(int dateColumnIndex, boolean columnIsStringFormat) {
        mDateColumnIndex = dateColumnIndex;
        mColumnIsStringFormat = columnIsStringFormat;

        Calendar yearCalendar = Calendar.getInstance();
        yearCalendar.set(yearCalendar.get(Calendar.YEAR), 0, 1, 0, 0);
        Year_Time = yearCalendar.getTimeInMillis();
    }

    @Override
    public String getGroupData(Cursor entry) {
        long dateTime = 0;
        if (mColumnIsStringFormat) {
            String strTime = entry.getString(mDateColumnIndex);
            try {
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
                dateTime = dateFormat.parse(strTime).getTime();
            } catch (Exception e) {

            }
        } else {
            dateTime = entry.getLong(mDateColumnIndex) * 1000;
        }

        mDate.setTime(dateTime);

        String dates = null;
        if (dateTime >= Today_Time && dateTime < Today_Time + One_Day_Time) {
            dates = "今天";
        } else if (dateTime >= Yesterday_Time && dateTime < Today_Time) {
            dates = "昨天";
        } else if (dateTime >= Week_Time && dateTime < Yesterday_Time) {
            dates = mWeekDateFormat.format(mDate);
        } else if (dateTime >= Year_Time && dateTime < Week_Time) {
            dates = mBriefDateFormat.format(mDate);
        } else {
            dates = mDateFormat.format(mDate);
        }

        return dates;
    }

    @Override
    public boolean isSameGroup(String lastEntryGroupData, String currentEntryGroupData) {
        if (lastEntryGroupData != null && currentEntryGroupData != null) {
            return lastEntryGroupData.equals(currentEntryGroupData);
        } else if (currentEntryGroupData == null && lastEntryGroupData == null) {
            return true;
        }
        return false;
    }
}
