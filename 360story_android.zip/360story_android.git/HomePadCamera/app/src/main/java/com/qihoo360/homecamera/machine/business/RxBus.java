package com.qihoo360.homecamera.machine.business;

import rx.Observable;
import rx.subjects.PublishSubject;
import rx.subjects.SerializedSubject;
import rx.subjects.Subject;

/**
 * Created by zhangtao-iri on 2017/2/27.
 */
public class RxBus {

    public static RxBus rxBus = null;

    public static RxBus getInstance(){
        if(rxBus == null){
            synchronized (RxBus.class){
                rxBus = new RxBus();
            }
        }
        return rxBus;
    }

    private final Subject<Object,Object> bus = new SerializedSubject<>(PublishSubject.create());

    /**
     *
     * 发送消息
     */
    public void send(Object o){
        bus.onNext(o);
    }

    /**
     *
     * 接受消息
     */
    public Observable<Object> toObservable(){
        return bus;
    }

    /**
     *
     * 查看是否有订阅者
     */
    public boolean hasObserver(){
        return bus.hasObservers();
    }
}
