package com.qihoo360.homecamera.machine.fragment;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.qihoo.sdk.report.QHStatAgent;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.activity.BaseActivity;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.entity.AppGetInfoEntity;
import com.qihoo360.homecamera.mobile.entity.BabyInfoEntity;
import com.qihoo360.homecamera.mobile.entity.DeviceInfo;
import com.qihoo360.homecamera.mobile.entity.RelationInfoEntity;
import com.qihoo360.homecamera.mobile.image.my.GlideCircleTransform;
import com.qihoo360.homecamera.machine.activity.MachineSettingDetialActivity;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.ui.fragment.BaseFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.PadRelaxActivity;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.FileUtil;
import com.qihoo360.homecamera.mobile.utils.MagicTextLengthWatcher;
import com.qihoo360.homecamera.mobile.utils.Preferences;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.widget.CircleImageView;
import com.qihoo360.homecamera.mobile.widget.TextViewWithFont;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class MachineBabyInfoFragment extends BaseFragment implements View.OnClickListener, ActionListener {

    public static MachineBabyInfoFragment mPadHeadFragment;
    public DeviceInfo devInfo;
    public CircleImageView mIvHead;
    public ImageView mIvHeadSelect;
    public TextViewWithFont mTvDefaultOne;
    public TextViewWithFont mTvDefaultTwo;
    public TextViewWithFont mTvDefaultThree;
    public Drawable mFirstDrawable;
    public Drawable mSecondDrawable;
    public Drawable mThirdDrawable;
    public Drawable mFirstDrawableSelect;
    public Drawable mSecondDrawableSelect;
    public Drawable mThirdDrawableSelect;
    public PopupWindow popuWindow;
    public View contentView;
    public View mOutsideTouchArea;
    public RelativeLayout mRlCancelArea;
    public TextViewWithFont mTvTakePhotoArea;
    public TextViewWithFont mTvSelectAlbumArea;
    public int crop = 180;
    public static final int TAKE_PICTURE = 50000;
    public static final int TAKE_PICTURE_FROM_CAMERA = 50001;
    public static final int REQUEST_CROP_PHOTO = 50002;
    public File mOutputFile;
    public EditText mBabyNameEt;
    public RadioButton mMaleRb;
    public RadioButton mFemaleRb;
    public TextView mBabyBirthTv;
    public PopupWindow mPopupWindow;
    public View mRootView;
    public long mTimeStamp = 0;
    public Button mBindFinishBt;
    public RelativeLayout mRelaxRl;
    public TextView mRelaxTv;
    public int mSelect;
    public String mTag = "";
    public boolean mHasSetHead = false;
    public boolean mIsFromBind = false;
    public boolean mHasSetBirth = false;

    public List<Integer> mTagList = new ArrayList<Integer>() {
        {
            add(R.string.tag_1);
            add(R.string.tag_2);
            add(R.string.tag_3);
            add(R.string.tag_4);
            add(R.string.tag_5);
            add(R.string.tag_6);
            add(R.string.tag_7);
            add(R.string.tag_8);
            add(R.string.tag_9);
        }
    };

    public List<Integer> mAvatorList = new ArrayList<Integer>() {
        {
            add(R.drawable.icon_father_small);
            add(R.drawable.icon_mother_small);
            add(R.drawable.icon_yeye_small);
            add(R.drawable.icon_nainai_small);
            add(R.drawable.icon_laoye_small);
            add(R.drawable.icon_laolao_small);
            add(R.drawable.icon_brother_small);
            add(R.drawable.icon_sister_small);
            add(R.drawable.icon_other_small);
        }
    };

    public MachineBabyInfoFragment() {
        super();
    }

    public static MachineBabyInfoFragment getInstance(DeviceInfo deviceInfo) {
        mPadHeadFragment = new MachineBabyInfoFragment();
        Bundle args = new Bundle();
        args.putParcelable(DeviceInfo.class.getSimpleName(), deviceInfo);
        mPadHeadFragment.setArguments(args);
        return mPadHeadFragment;
    }

    @Override
    public boolean onTabSwitched() {
        return false;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_pad_head, null);
        mRootView = view;
        mIvHead = (CircleImageView) view.findViewById(R.id.iv_head);
        mIvHead.setOnClickListener(this);
        mBindFinishBt = (Button) view.findViewById(R.id.bt_bind_finish);
        AppGetInfoEntity appGetInfoEntity = ((MachineSettingDetialActivity) getActivity()).getmAppGetInfoEntity();
        if (appGetInfoEntity != null) {
            String avatarUrl = ((MachineSettingDetialActivity) getActivity()).getmAppGetInfoEntity().data.avatarUrl;
            Glide.with(getActivity())
                    .load(TextUtils.isEmpty(avatarUrl) ? R.drawable.icon_avator_empty : avatarUrl)
                    .transform(new GlideCircleTransform(Utils.context))
                    .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                    .error(R.drawable.icon_avator_empty)
                    .into(mIvHead);
            if (!TextUtils.isEmpty(avatarUrl)) {
                mHasSetHead = true;
            }
            //mBindFinishBt.setVisibility(View.GONE);
        } else {
            String sn = ((MachineSettingDetialActivity) getActivity()).getSn();
            if (!TextUtils.isEmpty(sn) && ((MachineSettingDetialActivity) getActivity()).ismBindSucceed()) {
                Preferences.saveSelectedPad(sn);
                GlobalManager.getInstance().getNeverKillManager().publishAction(Actions.Share.SHARE_SHOW_SHARE_DIALOG);
            }
        }

        mIvHeadSelect = (ImageView) view.findViewById(R.id.iv_head_select);
        mTvDefaultOne = (TextViewWithFont) view.findViewById(R.id.tv_default_one);
        mTvDefaultTwo = (TextViewWithFont) view.findViewById(R.id.tv_default_two);
        mTvDefaultThree = (TextViewWithFont) view.findViewById(R.id.tv_default_three);
        mIvHeadSelect.setOnClickListener(this);
        mTvDefaultOne.setOnClickListener(this);
        mTvDefaultTwo.setOnClickListener(this);
        mTvDefaultThree.setOnClickListener(this);
        mBabyNameEt = (EditText) view.findViewById(R.id.et_baby_name);
        if (mIsFromBind) {
            mBabyNameEt.setHintTextColor(Color.parseColor("#888888"));
            mBabyNameEt.setHint(getString(R.string.device_default_name));
        } else {
            mBabyNameEt.setText(((MachineSettingDetialActivity) getActivity()).getmBabyInfoEntity().babyname);
            mBabyNameEt.setSelection(mBabyNameEt.getText().toString().length());
        }
        mBabyNameEt.addTextChangedListener(new MagicTextLengthWatcher(16, mBabyNameEt));
        mBabyBirthTv = (TextView) view.findViewById(R.id.tv_baby_birth);
        mTimeStamp = ((MachineSettingDetialActivity) getActivity()).getmBabyInfoEntity().babybirth;
        mBabyBirthTv.setText(Utils.DATE_FORMAT_5.format(mTimeStamp * 1000));
        mBabyBirthTv.setOnClickListener(this);
        mMaleRb = (RadioButton) view.findViewById(R.id.rb_male);
        mBindFinishBt.setOnClickListener(this);

        mFemaleRb = (RadioButton) view.findViewById(R.id.rb_female);
        switch (((MachineSettingDetialActivity) getActivity()).getmBabyInfoEntity().babysex) {
            case 0:
                mMaleRb.setChecked(true);
                mFemaleRb.setChecked(false);
                break;
            case 1:
                mFemaleRb.setChecked(true);
                mMaleRb.setChecked(false);
                break;
            default:
        }
        mMaleRb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                mFemaleRb.setChecked(!isChecked);
            }
        });
        mFemaleRb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                mMaleRb.setChecked(!isChecked);
            }
        });

        mFirstDrawable = getResources().getDrawable(R.drawable.default_head_1);
        mSecondDrawable = getResources().getDrawable(R.drawable.default_head_2);
        mThirdDrawable = getResources().getDrawable(R.drawable.default_head_3);
        mFirstDrawableSelect = getResources().getDrawable(R.drawable.default_head_1_select);
        mSecondDrawableSelect = getResources().getDrawable(R.drawable.default_head_2_select);
        mThirdDrawableSelect = getResources().getDrawable(R.drawable.default_head_3_select);
        mRelaxRl = (RelativeLayout) view.findViewById(R.id.rl_relax);
        mRelaxRl.setOnClickListener(this);
        mRelaxTv = (TextView) view.findViewById(R.id.tv_relax);
        mSelect = ((MachineSettingDetialActivity) getActivity()).getmRelationInfoEntity().relation_tag;
        mTag = ((MachineSettingDetialActivity) getActivity()).getmRelationInfoEntity().relation_title;
        mRelaxTv.setText(((MachineSettingDetialActivity) getActivity()).getmBabyInfoEntity().babysex == -1 ? getString(R.string.baby_relax_unset) : mTag);
        ((MachineSettingDetialActivity) getActivity()).setUnset(((MachineSettingDetialActivity) getActivity()).getmBabyInfoEntity().babysex == -1);
        initDatePickerWindow();
        File tmpFile = new File(FileUtil.getInstance().getAvatorFile().getAbsolutePath(), "/new_avator.png");
        if (tmpFile.exists()) {
            tmpFile.delete();
        }
        return view;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_head:
            case R.id.iv_head_select:
                initPopupWindow(v);
                break;
            case R.id.tv_default_one:
                mTvDefaultOne.setCompoundDrawablesWithIntrinsicBounds(null, mFirstDrawableSelect, null, null);
                mTvDefaultTwo.setCompoundDrawablesWithIntrinsicBounds(null, mSecondDrawable, null, null);
                mTvDefaultThree.setCompoundDrawablesWithIntrinsicBounds(null, mThirdDrawable, null, null);
                mIvHead.setImageResource(R.drawable.default_head_1);
                break;
            case R.id.tv_default_two:
                mTvDefaultOne.setCompoundDrawablesWithIntrinsicBounds(null, mFirstDrawable, null, null);
                mTvDefaultTwo.setCompoundDrawablesWithIntrinsicBounds(null, mSecondDrawableSelect, null, null);
                mTvDefaultThree.setCompoundDrawablesWithIntrinsicBounds(null, mThirdDrawable, null, null);
                mIvHead.setImageResource(R.drawable.default_head_2);
                break;
            case R.id.tv_default_three:
                mTvDefaultOne.setCompoundDrawablesWithIntrinsicBounds(null, mFirstDrawable, null, null);
                mTvDefaultTwo.setCompoundDrawablesWithIntrinsicBounds(null, mSecondDrawable, null, null);
                mTvDefaultThree.setCompoundDrawablesWithIntrinsicBounds(null, mThirdDrawableSelect, null, null);
                mIvHead.setImageResource(R.drawable.default_head_3);
                break;
            case R.id.tv_baby_birth:
                showDatePickerWindow();
                mHasSetBirth = true;
                break;
            case R.id.bt_bind_finish:
                saveChange(false);
                break;
            case R.id.rl_relax:
                Intent intent = new Intent(getActivity(), PadRelaxActivity.class);
                intent.putExtra("sn", ((MachineSettingDetialActivity) getActivity()).getmSn());
                RelationInfoEntity newRelationInfoEntity = ((MachineSettingDetialActivity) getActivity()).getmNewRelationInfoEntity();
                intent.putExtra("relationInfoEntity", newRelationInfoEntity == null ? ((MachineSettingDetialActivity) getActivity()).getmRelationInfoEntity() : newRelationInfoEntity);
                intent.putExtra("unset", ((MachineSettingDetialActivity) getActivity()).isUnset());
                startActivityForResult(intent, 1005);
                break;
        }
        if (getActivity() != null && getActivity().getCurrentFocus() != null)
            ((InputMethodManager) getActivity().getSystemService(getActivity().INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(getActivity().getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
    }

    @Override
    public void onDestroy() {
        if (popuWindow != null) {
            popuWindow.dismiss();
            popuWindow = null;
        }
        super.onDestroy();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CROP_PHOTO || requestCode == TAKE_PICTURE_FROM_CAMERA) {
            BaseActivity ba = (BaseActivity)getActivity();
            Glide.with(getActivity())
                    .load(ba.mUserHeadPath)
                    .diskCacheStrategy(DiskCacheStrategy.NONE)
                    .skipMemoryCache(true)
                    .diskCacheStrategy(DiskCacheStrategy.NONE)
                    .error(R.drawable.icon_avator_empty)
                    .into(mIvHead);

           /* File tmpFile = new File(FileUtil.getInstance().getAvatorFile().getAbsolutePath(), "/new_avator.png");
            Bitmap bitmap = getBitmapFromUri(Uri.fromFile(new File(tmpFile.getAbsolutePath())), getActivity());//data.getParcelableExtra("data");
            mIvHead.setImageBitmap(bitmap);*/
//            Bitmap bitmap = null;
//            if (data != null) {
//                bitmap = data.getParcelableExtra("data");
//            }
//            if (bitmap == null) {
//                try {
//                    bitmap = BitmapFactory.decodeStream(getActivity().getContentResolver().openInputStream(Uri.fromFile(mTmpFile)));
//                } catch (FileNotFoundException e) {
//                    e.printStackTrace();
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//            if (bitmap != null) {
//                mIvHead.setImageBitmap(bitmap);
//                saveBitmap(bitmap);
//            } else {
//                //CameraToast.show("读取图片失败", Toast.LENGTH_SHORT);
//            }

//            Glide.with(getActivity())
//                    .load(FileUtil.getInstance().getAvatorFile().getAbsolutePath() + "/new_avator.png")
//                    .diskCacheStrategy(DiskCacheStrategy.NONE)
//                    .skipMemoryCache(true)
//                    .diskCacheStrategy(DiskCacheStrategy.NONE)
//                    .error(R.drawable.icon_avator_empty)
//                    .into(mIvHead);
            mHasSetHead = true;
            mTvDefaultOne.setCompoundDrawablesWithIntrinsicBounds(null, mFirstDrawable, null, null);
            mTvDefaultTwo.setCompoundDrawablesWithIntrinsicBounds(null, mSecondDrawable, null, null);
            mTvDefaultThree.setCompoundDrawablesWithIntrinsicBounds(null, mThirdDrawable, null, null);
        } else if (requestCode == 1005 && data != null) {
            mSelect = data.getIntExtra("select", 0);
            mTag = data.getStringExtra("tag");
            mRelaxTv.setText(mTag);
            ((MachineSettingDetialActivity) getActivity()).setUnset(true);
            ((MachineSettingDetialActivity) getActivity()).setNewRelationInfoEntity(mSelect, mTag);
        }
    }

    /**
     * 保存方法
     */
    public void saveBitmap(Bitmap bitmap) {
        mHasSetHead = true;
        File f = new File(FileUtil.getInstance().getAvatorFile().getAbsolutePath() + "/new_avator.png");
        if (f.exists()) {
            f.delete();
        }
        try {
            FileOutputStream out = new FileOutputStream(f);
            bitmap.compress(Bitmap.CompressFormat.PNG, 90, out);
            out.flush();
            out.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        if (getActivity() != null && !isDetached()) {
            MachineSettingDetialActivity sda = (MachineSettingDetialActivity) getActivity();
            if (sda != null && sda.getDeviceInfo() != null && f != null) {
                RelationInfoEntity rie = sda.getmOldRelationInfoEntity();
                BabyInfoEntity bie = sda.getmOldBabyInfoEntity();
                if (rie != null && bie != null) {
                    GlobalManager.getInstance().getUserInfoManager().asyncAppUpdateInfo(sda.getSn(),
                            AccUtil.getInstance().getQID(), rie.toString()
                            , sda.getDeviceInfo().getTitle(), bie.toString(), "new_avator.png", f.getAbsolutePath(), true);
                }
            }
        }

    }

    public void saveBitmap(String path) {
        File f = new File(path);
        mHasSetHead = true;
        if (getActivity() != null && !isDetached()) {
            MachineSettingDetialActivity sda = (MachineSettingDetialActivity) getActivity();
            if (sda != null && sda.getDeviceInfo() != null && f != null) {
                RelationInfoEntity rie = sda.getmOldRelationInfoEntity();
                BabyInfoEntity bie = sda.getmOldBabyInfoEntity();
                if (rie != null && bie != null) {
                    GlobalManager.getInstance().getUserInfoManager().asyncAppUpdateInfo(sda.getSn(),
                            AccUtil.getInstance().getQID(), rie.toString()
                            , sda.getDeviceInfo().getTitle(), bie.toString(), "new_avator.png", f.getAbsolutePath(), true);
                }
            }
        }

    }


    public static Bitmap getBitmapFromUri(Uri uri, Context mContext) {
        try {
            // 读取uri所在的图片
            Bitmap bitmap = MediaStore.Images.Media.getBitmap(mContext.getContentResolver(), uri);
            return bitmap;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static Uri getImageContentUri(Context context, String absPath) {
        Uri resultUri = null;
        CLog.i("test2", "getImageContentUri: " + absPath);
        Cursor cursor = null;
        try {
            cursor = context.getContentResolver().query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                    , new String[]{
                            MediaStore.Images.Media._ID
                    }, MediaStore.Images.Media.DATA + "=? "
                    , new String[]{
                            absPath
                    }, null);

            if (cursor != null && cursor.moveToFirst()) {
                int id = cursor.getInt(cursor.getColumnIndex(MediaStore.MediaColumns._ID));
                resultUri = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, Integer.toString(id));
                return resultUri;

            } else if (!absPath.isEmpty()) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DATA, absPath);
                return resultUri = context.getContentResolver().insert(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            Utils.close(cursor);
        }
        return resultUri;

    }

    public void saveChange(boolean bRunInBackgroung) {
        if (!mHasSetHead) {
            if (!bRunInBackgroung)
                CameraToast.show("请设置宝贝的头像", Toast.LENGTH_SHORT);
            return;
        }
        if (TextUtils.isEmpty(mBabyNameEt.getText().toString())) {
            if (!bRunInBackgroung)
                CameraToast.show("请输入宝贝的昵称", Toast.LENGTH_SHORT);
            return;
        }

        if (mIsFromBind && !mHasSetBirth) {
            if (!bRunInBackgroung)
                CameraToast.show("请设置宝贝的生日", Toast.LENGTH_SHORT);
            return;
        }
        if (mRelaxTv.getText().toString().equals(getString(R.string.baby_relax_unset))) {
            if (!bRunInBackgroung)
                CameraToast.show("请选择您与宝贝的关系", Toast.LENGTH_SHORT);
            return;
        }
        if (!mMaleRb.isChecked() && !mFemaleRb.isChecked()) {
            if (!bRunInBackgroung)
                CameraToast.show("请设置宝贝的性别", Toast.LENGTH_SHORT);
            return;
        }
        BaseActivity ba = (BaseActivity)getActivity();
        if (!bRunInBackgroung && ba != null){
            ba.showTipsDialog("保存中，请稍候...", R.drawable.icon_loading, 8000, true);
        }
//        File tmpFile = new File(FileUtil.getInstance().getAvatorFile().getAbsolutePath(), "/new_avator.png");
        String headUriPath = "";
        String tmpFileName = "";
        String tmpFilePath = "";
        if(ba!=null && ba.mUserHeadUri!=null){
            headUriPath = ba.mUserHeadUri.getPath();
            if(!TextUtils.isEmpty(headUriPath)){
                File tmpFile = new File(headUriPath);
                tmpFileName = tmpFile.getName();
                tmpFilePath = tmpFile.getAbsolutePath();
            }
        }
        GlobalManager.getInstance().getUserInfoManager().asyncAppUpdateInfo(((MachineSettingDetialActivity) getActivity()).getSn(), AccUtil.getInstance().getQID(), String.format("{\"relation_tag\": \"%1$s\",\"relation_title\": \"%2$s\"}", mSelect, mTag)
                , mBabyNameEt.getText().toString(), String.format("{\"babyname\": \"%1$s\",\"babybirth\": %2$s,\"babysex\": %3$d}", mBabyNameEt.getText().toString(), mTimeStamp + "", mMaleRb.isChecked() ? 0 : 1), tmpFileName, tmpFilePath, (bRunInBackgroung ? Boolean.TRUE : Boolean.FALSE));
    }

    @Override
    public Object actionPerformed(int actionCode, Object... args) {
        switch (actionCode) {
            case Actions.UserInfo.APP_UPDATE_INFO_SUCCESS: {
                if (!mIsFromBind) {
                    CameraToast.showToast(Utils.context, R.string.modify_success);
                }
                ((BaseActivity) getActivity()).hideTipsDialog();
                ((BaseActivity) getActivity()).finish();
                return Boolean.TRUE;
            }
            case Actions.UserInfo.APP_UPDATE_INFO_FAIL: {
                if (args == null || args.length == 0) {
                    CameraToast.showErrorToast(getActivity(), R.string.modify_fail);
                } else {
                    CameraToast.showErrorToast((String) args[0]);
                }
                ((BaseActivity) getActivity()).hideTipsDialog();
                return Boolean.TRUE;
            }
        }
        return Actions.ACTION_NOT_PROCESSED;
    }

    @Override
    public int getProperty() {
        return 0;
    }

    public void initDatePickerWindow() {
        LayoutInflater inflater = LayoutInflater.from(getActivity());
        View view = inflater.inflate(R.layout.dialog_date_picker, null);
        mPopupWindow = new PopupWindow(view,
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        mPopupWindow.setBackgroundDrawable(new BitmapDrawable());
        mPopupWindow.setAnimationStyle(R.style.popu_animation);
        mPopupWindow.setFocusable(true);
        mPopupWindow.setOutsideTouchable(true);
        mPopupWindow.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        mPopupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
            }
        });
        final DatePicker datePicker = (DatePicker) view.findViewById(R.id.date_picker);
        datePicker.setCalendarViewShown(false);
        datePicker.setMaxDate(System.currentTimeMillis());
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(mTimeStamp * 1000);
        datePicker.updateDate(c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
        TextView btnOk = (TextView) view.findViewById(R.id.tv_ok);
        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar c = Calendar.getInstance();
                c.set(datePicker.getYear(), datePicker.getMonth(), datePicker.getDayOfMonth());
                mTimeStamp = (long) (c.getTimeInMillis() * 0.001);
                mBabyBirthTv.setText(Utils.DATE_FORMAT_5.format(mTimeStamp * 1000));
                if (mPopupWindow != null) {
                    mPopupWindow.dismiss();
                }
            }
        });
        TextView btnCancel = (TextView) view.findViewById(R.id.tv_cancel);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mPopupWindow != null) {
                    mPopupWindow.dismiss();
                }
            }
        });
    }

    public void showDatePickerWindow() {
        mPopupWindow.showAtLocation(mRootView, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0);
    }


    @Override
    public void onResume() {
        QHStatAgent.onPageStart(getActivity(), "PadHeadFragment");
        CLog.i("yanggang", "PadHeadFragment onPageStart");
        super.onResume();
    }

    @Override
    public void onPause() {
        QHStatAgent.onPageEnd(getActivity(), "PadHeadFragment");
        CLog.i("yanggang", "PadHeadFragment onPageEnd");
        super.onPause();
    }

    public void setmIsFromBind(boolean mIsFromBind) {
        this.mIsFromBind = mIsFromBind;
    }
}
