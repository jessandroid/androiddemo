
package com.qihoo360.homecamera.mobile.config;

import android.os.Environment;

import com.qihoo360.homecamera.mobile.BuildConfig;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.entity.CallInfoEntity;
import com.qihoo360.homecamera.mobile.entity.CommonMessageEntity;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 系统常量
 */
public final class Constants {
    public static String SDCARD_PATH = Environment.getExternalStorageDirectory().getAbsolutePath()
            + File.separator;
    public static final String ID_RECENT_ALBUMS = "-123456";
    public static final int LOG_SAVE_DATE = 5;//日志保留时间
    public static final int NOTIFYCATION_SHORT_VIDEO = 2100;

    public static final String PUB_STRING = "public";
    public static final String PRI_STRING = "private";
    public static final String CARD_STRING = "card";

    public static final String MY_APP_KEY = BuildConfig.isDebug ? "70d8403862dd853542b95096" : "f8845a480e573e3bce0d5096";
    // aes加密私钥
    public static final String AEC_KEY = "sfe023f_9fd&fwfl";
    public static final String UPLOAD_AEC_KEY = "sfe023f_9fd&fwfl";
    public static String TopActivityName;
    public static boolean IS_CALLING_OR_INNER = false;
    public static boolean IS_CALLING = false;
    public static boolean IS_INNER = false;
    public static int INNER_PEER_NAME = -1;
    public static List<CommonMessageEntity> CommonMessageList = new ArrayList<CommonMessageEntity>();
    public static boolean IS_LOGIN = true;

    //非wifi网络弹窗提醒逻辑，在原基础上，将弹窗优化为toast，仅是toast提醒，不做暂停操作。
    //不弹窗 只toast 此处改为true 表面已经弹过窗了
    public static boolean HAS_SHOW_NET_TIPS = true;
    public static boolean NEED_4G_TOAST = true;

    public static boolean STORY_SHOW_DIALOG = true;
    public static boolean HAS_SHOW_NOISE_HIGH = false;

    public static boolean mInitSuccess = true;
    public static boolean mInitVideoSuccess = true;
    public static boolean mInitAudioSuccess = true;
    //是否已经初始化成功
    public static boolean mMtcHasInit = false;


    public static int EMOTICON_CLICK_TEXT = 1;
    public static int EMOTICON_CLICK_BIGIMAGE = 2;

    public interface TermReason {
        public int TERM_ANSWER_ERROR = -8001;//接听错误
        public int TERM_UNKNOW = -8000;//未知
        public int TERM_SHARE_REMOVED = 8000;//分享关系已被主人解除
        public int TERM_OTHER_LOGOUT = 8001;//更换设备登陆
        public int TERM_MONITOR_DISABLED = 8002;//远程查看设置为禁止了
        public int TERM_MONITOR_INTERRUPT = 8003;//中端监控
        public int TERM_NO_DISTURB = 8004;//免打扰模式禁止
        public int TERM_NO_DISTURB_INTERRUPT = 8005;//免打扰模式导致中断
        public int TERM_CALL_INTERRUPT_MONITOR = 8006;//来电话打断远程查看模式
        public int TERM_USER_REFUSE = 8007; //用户拒接
        public int TERM_USER_HANG_UP = 8008;//用户挂断
        public int TERM_NO_AUTHORITY = 8009;//没有权限

        public int TERM_360_MOBILE_ASSIST_OFFLINE = 8201;//手助不在线
    }

    public static List<String> TAG_LIST = new ArrayList<String>() {
        {
            add(Utils.getResources().getString(R.string.tag_1));
            add(Utils.getResources().getString(R.string.tag_2));
            add(Utils.getResources().getString(R.string.tag_3));
            add(Utils.getResources().getString(R.string.tag_4));
            add(Utils.getResources().getString(R.string.tag_5));
            add(Utils.getResources().getString(R.string.tag_6));
            add(Utils.getResources().getString(R.string.tag_7));
            add(Utils.getResources().getString(R.string.tag_8));
            add(Utils.getResources().getString(R.string.tag_9));
        }
    };

    /*
     * 固件常量
     */
    public static final class FirmWare {
        public static final int STATE_NONE_UPDATE = 0;// 没有更新
        public static final int STATE_HAVE_UPDATE = 1;// 有更新
        public static final int STATE_UPDATEING = 2;// 正在升级
        public static final int STATE_UPDATE_FILED = 3;// 升级失败
        public static final int STATE_FORCE_UPDATE = 4;// 强制升级
    }

    /*
     * 固件升级常量
     */
    public static final class upgrade {
        public static final int FIRMWARE_UPGRADE_SUCCEED = 0; // 固件升级成功
        public static final int FIRMWARE_MD5CHECK_FAILURE = -40001; // 下载固件校验失败
        public static final int FIRMWARE_DOWNLOAD_FAILURE = -40002;// 网络异常,下载失败
        public static final int FIRMWARE_INSTALL_FAILURE = -40003;// 固件安装过程失败
        public static final int FIRMWARE_DOWN_LOAD_ERROR = -1;// 下载固件失败
        public static final int FIRMWARE_UPGRAD_TIME_OUT = -2;// 下载超时
        public static final int FIRMWARE_UPGRAD_BACK_FACTORY = 1;// 回退工厂模式
        public static final int FIRMWARE_UPGRAD_UNKNOW_ERROR = -3;// 未知错误
    }

    /*
     * 推送消息常量
     */
    public static final class Push {
        public static final int TYPE_ONLINE = 1;// 上线报警
        public static final int TYPE_OFFLINE = 2;// 离线警报
        public static final int TYPE_MOTION = 3;// 动作警报
        public static final int TYPE_CMDRST = 4;// 异步响应
        // public static final int TYPE_WEB_LOGIN = 6; // web页面登录了
        public static final int TYPE_FORCE_OFFLINE = 7; // 帐号互斥，强制下线
        public static final int TYPE_SESSION_OVERDUE = 8; // session 过期

        public static final int TYPE_SHARE = 8;// 分享通知

        public static final int TYPE_EVENT_FACE = 10;
        public static final int TYPE_EVENT_PET = 11;

        public static final int TYPE_PUBLIC = 12;
        public static final int TYPE_FORESHOW = 13;// 预告
        public static final int TYPE_PUBLIC_ANCHOR = 14;// 主播发起的推送
        public static final int TYPE_MULTI_LOGIN_ATTENTION = 15;// 其他设备登录提醒
        public static final int EVENT_MESSAGE_BOX = 16;// 其他设备登录提醒
        public static final int MESSAGE_BOX = 17;

        // public static final int TYPR_CLOUD_SAVE_PAST_DUE = 9; // 云存储服务到期通知
        // public static final int TYPE_FIRMWARE = 10;// 固件升级
        //
        // public static final int EVENT_AUTHSUCCESS = 11; //表示授权成功
        // public static final int EVENT_AUTHOUTOFDATE = 12; //表示授权已过期
        // public static final int EVENT_DELAUTHED = 13;
        // //删除被授权摄像头(此消息为被授权方发起，授权方接收)
        // public static final int EVENT_DELAUTH = 14;
        // public static final int EVENT_RESOLUTION = 20;//播放模式切换
    }

    /*
     * HTTP常量
     */
    public static final class Http {


        public static final int SUCCESS = 0; // 成功',
        public static final int FAILURE = 1; // 失败',
        public static final int PARAMS_ERROR = 2; // 参数错误',
        public static final int REGISTER_ERROR = 3; // 注册失败，请重试',
        public static final int CODE_INVALID_ERROR = 4; // 激活码失效，请重获取',
        public static final int LOGIN_ERROR = 5; // 登录失败，请重获取',
        public static final int LOGOUT_ERROR = 6; // 注销失败，请重获取',
        public static final int KEEPALIVE_ERROR = 7; // 心跳失败，请重注册',
        public static final int BIND_IPC_ERROR = 8; // 绑定失败，请重试',
        public static final int UNBIND_IPC_ERROR = 9; // 解绑失败，请重试',
        public static final int GET_CONNECT_INFO_ERROR = 10; // 获取播放信息失败',
        public static final int SID_OUTDATE_ERROR = 11; // sid已失效，请重新登录',
        public static final int SID_OUTDATE_OUTSIDE_ERROR = 12; // 获取列表失败，请重试',
        public static final int VERIFY_SIG_ERROR = 13; // 验证签名失败',
        public static final int CREATE_SID_ERROR = 14; // 创建sid失败',
        public static final int CREATE_CODE_ERROR = 15; // 生成激活码失败',
        public static final int REG_STREAM_ERROR = 16; // 注册流服务失败',
        public static final int SAVE_USER_INFO_ERROR = 17; // 保存用户信息失败',
        public static final int AUTHENTICATE_ERROR = 18; // 鉴权失败',
        public static final int VERIFY_QT_ERROR = 19; // 验证QT失败，请重试',
        public static final int SHARE_ERROR = 20; // 分享失败，请重试',
        public static final int OVER_SHARE_MAXNUM_ERROR = 21; // 超过了最大分享数量',
        public static final int GET_SHARE_CODE_ERROR = 22; // 获取分享码失败',
        public static final int SEND_SHARE_SMS_ERROR = 23; // 发送分享短信失败',
        public static final int SHARE_CODE_EXPIRE_ERROR = 24; // 分享码已失效',
        public static final int IPC_IS_UNBIND_ERROR = 25; // 摄像机已经解绑',
        public static final int SHARE_EXIST_ERROR = 26; // 分享关系已经存在',
        public static final int CANCEL_SHARING_ERROR = 27; // 取消分享码失败',
        public static final int CANCEL_SHARE_ERROR = 28; // 取消分享失败',
        public static final int GET_SHARE_LIST_ERROR = 29; // 获取分享列表失败',
        public static final int GET_SHARING_LIST_ERROR = 30; // 获取分享码列表失败',
        public static final int GET_SHARE_INFO_ERROR = 31; // 获取分享信息失败',
        public static final int GET_ADDR_LIST_ERROR = 32; // 获取通讯录失败',
        public static final int ALBUM_LIST_ERROR = 43; // 获取照片列表失败',
        public static final int ALBUM_IMAGE_ERROR = 44; // 照片或视频不存在',
        public static final int ALBUM_MAX_SIZE_ERROR = 45; // 相册超过最大空间限制',
        public static final int ALBUM_IMAGE_MAX_ERROR = 46; // 文件超过最大限制',
        public static final int ALBUM_UPLOAD_ERROR = 47; // 上传失败',
        public static final int ALBUM_DELETE_ERROR = 48; // 上传失败',
        public static final int ALBUM_SHARE_ERROR = 49; // 删除失败',
        public static final int ALBUM_UPLOADSUC_ERROR = 50; // 设置分享失败',
        public static final int ALBUM_MULTIDOWN_ERROR = 51; // 批量下载失败',失败'

        public static final int ERROR_CODE_JSON = -2;// Json解析异常
        public static final int ERROR_CODE_ENCODING = -3;// URL参数编码失败
        public static final int ERROR_CODE_IO = -4;// IO异常
        public static final int ERROR_CODE_DES = -5;// 加解密失败
        public static final int ERROR_UNKNOWN = -6;// 未定义
        public static final int ERROR_CODE_SSL = -7;// SSL通道建立失败
        public static final int ERROR_CODE_SSL_HANDS = -8;// SSL握手异常
        public static final int ERROR_CODE_NET_WAP = -9;// WAP网络
        public static final int ERROR_CODE_ILLEGAL = -10;// HTTP错误参数
        public static final int ERROR_CODE_CONNECTION = -11; // 网络异常
        public static final int ERROR_CODE_NET_UNAVAILABLE = -12;// 网络不可用,手机网没开
        public static final int ERROR_CODE_PUSH_OVERTIME = -14;// 等推送超时
        public static final int ERROR_CODE_SIDOVERDUE = 442; // sid过期
        public static final int ERROR_CODE_UNAUTHORIZED = 452; // 验证用户信息失败
        public static final int ERROR_CODE_DEL_SHARE_CODE_ERROR = 518;
        public static final int ERROR_SOFT_SWITCH_OFF = 625;// 软开关关闭

        public static final int ERROR_CODE_DEVICE_OFFLINE = 43; // 设备离线

        public static final int ERROR_CODE_SUCCEED = 0;// 成功

    }

    /*
     * 任务运行状态
     */
    public static final class TaskState {
        public static final int SUCCESS = 0x1111;// 任务成功
        public static final int FAILURE = 0x1112;// 任务失败
        public static final int ISRUNING = 0x1113;// 任务正在运行
        public static final int PAUSE = 0x1114;// 任务暂停
        public static final int EXCEPITON = 0x1115;// 任务异常
    }

    public static final class SSL {
        public static final String CLIENT_AGREEMENT = "TLS"; // 使用协议
        public static final String CLIENT_KEY_MANAGER = "X509"; // 密钥管理器
        public static final String CLIENT_TRUST_MANAGER = "X509"; // 信任证书管理器
        public static final String CLIENT_KEY_KEYSTORE = "BKS"; // "JKS";//密库，这里用的是BouncyCastle密库
        public static final String CLIENT_TRUST_KEYSTORE = "BKS"; // "JKS";//
    }

    /*
     * 通知栏ID
     */
    public static final class Notify {
        public static final int NORMAL = 0x2222;
        public static final int APP_UPDATE = 0x2223;
        public static final int FIRMWARE_UPDATE = 0x2224;
        public static final int PUBLIC_NOTIFY = 0x2225;
        public static final int FORESHOW_NOTIFY = 0x2225;
        public static final int MULTI_LOGIN = 0x2226;
        public static final int MESSAGE_BOX = 0x2227;
    }

    public static final class ShareType {
        public static final int SHARE_TYPE_WEIXIN = 1; // 微信
        public static final int SHARE_TYPE_MOBILE = 2; // 帐号(手机)分享
        public static final int SHARE_TYPE_QRCODE = 3; // 二维码分享
    }

    //添加家人类型
    public static final class  FuncType{
        public static final String BASE = "base";
        public static final String IPC = "ipc";//手机扫平板二维码
        public static final String KIBOTFRIEND = "kibotFriend"; //平板间好友
        public static final String MOBILE = "mobile"; //手机号分享
        public static final String QRCODE = "qRCode"; //手机二维码分享
    }

    public static final class DeviceType{
        public static final String KIBOTMACHINE = "kibot";
        public static final String STORYMACHINE = "story";
    }


    public static final String[] defaultAlbum = new String[] {
            "/storage/extSdCard/DCIM/Camera", // for samsung external sdcard
            SDCARD_PATH + "DCIM/Camera",
            SDCARD_PATH + "DCIM/100MEDIA",
            SDCARD_PATH + "DCIM/100ANDRO",
            SDCARD_PATH + "Camera"
    };

    public static final String[] screenAlbum = new String[] {
            SDCARD_PATH + "Screenshots",
            SDCARD_PATH + "Pictures/Screenshots",
            SDCARD_PATH + "DCIM/Screenshots",
    };

    public static final String[] cameraSnap = new String[] {
            SDCARD_PATH + "360智能摄像机",
            SDCARD_PATH + "360智能摄像机/我的相册",
            SDCARD_PATH + "360智能摄像机/安全防护",
    };

    public enum SafeTimeTypes {
        None, Whole, Day, Night, Custom
    }

    public enum ITEM_TYPE {
        ITEM_TYPE_HEADER, ITEM_TYPE_CONTENT, ITEM_TYPE_BOTTOM
    }

    /**
     * 视频播发对应的UI状态
     */
    public enum VideoUIStatus {
        NONE, LOADING, RETRY, PLAYING, WAITING, SWITCH_OFF
    }

    /**
     * 视频播发对应的UI状态
     */
    public enum VideoUIStatusRecord {
        NONE, LOADING, RETRY, PLAYING, WAITING
    }

    public enum VideoPlaybackStatus {
        NONE, LOADING, RETRY, PLAYING, WAITING, PAUSE, OVER, ALLOVER
    }

    /*
     * 时光小屋消息通知类型
     */
    public static final class UserSettingNotification {
        public static final int DISABLE = 0x0000;
        public static final int ENABLE = 0x0001;
        public static final int VOICE = 0x0002;
        public static final int SHAKE = 0x0004;
        public static final int ALL = 0x0007;
    }

    public static int userSettingNotification = Constants.UserSettingNotification.ALL;

    /*
     * 云端总存储空间
     */
    public static final int TotalDiscSpace = (5 * 1024 * 1024);    //单位KB
    public static final int GBDiscSpace = (1 * 1024 * 1024);    //单位KB

    /*
     * 设备角色
     */
    public static final class Role {
        public static final int MASTER = 1;
        public static final int FAMILY = 2;
        public static final int FRIEND = 3;
    }

    /*
     * 云空间存储状态
     */
    public static final class SpaceInfo {
        public final static int SPACE_INFO_FREE = 0;
        public final static int SPACE_INFO_FULL = 1;
        public final static int SPACE_INFO_ALREADY_FULL = 2;
    }

    public static final String SHARE_TYPE = "SHARE_TYPE";
    public static final int PHONE_LIST = 20000;
    public static final int PHONE_QR = 40000;

    public static int CALL_TYPE = -1;
    public final static int NON_AUTO_CALL = 0;
    public final static int AUTO_CALL = 1;
    public static Map<Integer, CallInfoEntity> CallState = new HashMap<Integer, CallInfoEntity>();

    public static String json = "{\n" +
            "    \"errorCode\": 0,\n" +
            "    \"errorMsg\": \"成功\",\n" +
            "    \"data\": {\n" +
            "        \"list\": [\n" +
            "            {\n" +
            "                \"imageId\": \"1\",\n" +
            "                \"sn\": \"1111111\",\n" +
            "                \"uid\": \"1\",\n" +
            "                \"utitle\": \"1111111\",\n" +
            "                \"src\": \"1\",\n" +
            "                \"fileName\": \"1111111\",\n" +
            "                \"playtime\": 0,\n" +
            "                \"oriName\": \"啊啊啊\",\n" +
            "                \"preview\": \"http://img5.imgtn.bdimg.com/it/u=183656797,1730936710&fm=206&gp=0.jpg\",\n" +
            "                \"file\": \"1\",\n" +
            "                \"down\": \"http://img5.imgtn.bdimg.com/it/u=183656797,1730936710&fm=206&gp=0.jpg\",\n" +
            "                \"createTime\": \"1454386751\",\n" +
            "                \"ftype\": 0\n" +
            "            },\n" +
            "            {\n" +
            "                \"imageId\": \"2\",\n" +
            "                \"sn\": \"1111111\",\n" +
            "                \"uid\": \"1\",\n" +
            "                \"utitle\": \"1111111\",\n" +
            "                \"src\": \"1\",\n" +
            "                \"fileName\": \"1111111\",\n" +
            "                \"playtime\": 0,\n" +
            "                \"oriName\": \"不不不\",\n" +
            "                \"preview\": \"http://img2.3lian.com/img2007/10/28/122.jpg\",\n" +
            "                \"file\": \"1\",\n" +
            "                \"down\": \"http://img2.3lian.com/img2007/10/28/122.jpg\",\n" +
            "                \"createTime\": \"1454297024\",\n" +
            "                \"ftype\": 0\n" +
            "            },\n" +
            "            {\n" +
            "                \"imageId\": \"3\",\n" +
            "                \"sn\": \"1111111\",\n" +
            "                \"uid\": \"1\",\n" +
            "                \"utitle\": \"1111111\",\n" +
            "                \"src\": \"1\",\n" +
            "                \"fileName\": \"1111111\",\n" +
            "                \"playtime\": 0,\n" +
            "                \"oriName\": \"ccc\",\n" +
            "                \"preview\": \"http://img2.3lian.com/img2007/10/28/123.jpg\",\n" +
            "                \"file\": \"1\",\n" +
            "                \"down\": \"http://img2.3lian.com/img2007/10/28/123.jpg\",\n" +
            "                \"createTime\": \"1454297024\",\n" +
            "                \"ftype\": 0\n" +
            "            },\n" +
            "            {\n" +
            "                \"imageId\": \"3\",\n" +
            "                \"sn\": \"1111111\",\n" +
            "                \"uid\": \"1\",\n" +
            "                \"utitle\": \"1111111\",\n" +
            "                \"src\": \"1\",\n" +
            "                \"fileName\": \"1111111\",\n" +
            "                \"playtime\": 0,\n" +
            "                \"oriName\": \"ccc\",\n" +
            "                \"preview\": \"http://img2.3lian.com/img2007/10/28/123.jpg\",\n" +
            "                \"file\": \"1\",\n" +
            "                \"down\": \"http://img2.3lian.com/img2007/10/28/123.jpg\",\n" +
            "                \"createTime\": \"1454297024\",\n" +
            "                \"ftype\": 0\n" +
            "            },\n" +
            "            {\n" +
            "                \"imageId\": \"3\",\n" +
            "                \"sn\": \"1111111\",\n" +
            "                \"uid\": \"1\",\n" +
            "                \"utitle\": \"1111111\",\n" +
            "                \"src\": \"1\",\n" +
            "                \"fileName\": \"1111111\",\n" +
            "                \"playtime\": 0,\n" +
            "                \"oriName\": \"ccc\",\n" +
            "                \"preview\": \"http://img2.3lian.com/img2007/10/28/123.jpg\",\n" +
            "                \"file\": \"1\",\n" +
            "                \"down\": \"http://img2.3lian.com/img2007/10/28/123.jpg\",\n" +
            "                \"createTime\": \"1454297024\",\n" +
            "                \"ftype\": 0\n" +
            "            },\n" +
            "            {\n" +
            "                \"imageId\": \"3\",\n" +
            "                \"sn\": \"1111111\",\n" +
            "                \"uid\": \"1\",\n" +
            "                \"utitle\": \"1111111\",\n" +
            "                \"src\": \"1\",\n" +
            "                \"fileName\": \"1111111\",\n" +
            "                \"playtime\": 0,\n" +
            "                \"oriName\": \"ccc\",\n" +
            "                \"preview\": \"http://img2.3lian.com/img2007/10/28/123.jpg\",\n" +
            "                \"file\": \"1\",\n" +
            "                \"down\": \"http://img2.3lian.com/img2007/10/28/123.jpg\",\n" +
            "                \"createTime\": \"1454297024\",\n" +
            "                \"ftype\": 0\n" +
            "            },\n" +
            "            {\n" +
            "                \"imageId\": \"3\",\n" +
            "                \"sn\": \"1111111\",\n" +
            "                \"uid\": \"1\",\n" +
            "                \"utitle\": \"1111111\",\n" +
            "                \"src\": \"1\",\n" +
            "                \"fileName\": \"1111111\",\n" +
            "                \"playtime\": 0,\n" +
            "                \"oriName\": \"ccc\",\n" +
            "                \"preview\": \"http://img2.3lian.com/img2007/10/28/123.jpg\",\n" +
            "                \"file\": \"1\",\n" +
            "                \"down\": \"http://img2.3lian.com/img2007/10/28/123.jpg\",\n" +
            "                \"createTime\": \"1454297024\",\n" +
            "                \"ftype\": 0\n" +
            "            },\n" +
            "            {\n" +
            "                \"imageId\": \"3\",\n" +
            "                \"sn\": \"1111111\",\n" +
            "                \"uid\": \"1\",\n" +
            "                \"utitle\": \"1111111\",\n" +
            "                \"src\": \"1\",\n" +
            "                \"fileName\": \"1111111\",\n" +
            "                \"playtime\": 0,\n" +
            "                \"oriName\": \"ccc\",\n" +
            "                \"preview\": \"http://img2.3lian.com/img2007/10/28/123.jpg\",\n" +
            "                \"file\": \"1\",\n" +
            "                \"down\": \"http://img2.3lian.com/img2007/10/28/123.jpg\",\n" +
            "                \"createTime\": \"1454297024\",\n" +
            "                \"ftype\": 0\n" +
            "            },\n" +
            "            {\n" +
            "                \"imageId\": \"3\",\n" +
            "                \"sn\": \"1111111\",\n" +
            "                \"uid\": \"1\",\n" +
            "                \"utitle\": \"1111111\",\n" +
            "                \"src\": \"1\",\n" +
            "                \"fileName\": \"1111111\",\n" +
            "                \"playtime\": 0,\n" +
            "                \"oriName\": \"ccc\",\n" +
            "                \"preview\": \"http://img2.3lian.com/img2007/10/28/123.jpg\",\n" +
            "                \"file\": \"1\",\n" +
            "                \"down\": \"http://img2.3lian.com/img2007/10/28/123.jpg\",\n" +
            "                \"createTime\": \"1454297024\",\n" +
            "                \"ftype\": 0\n" +
            "            },\n" +
            "            {\n" +
            "                \"imageId\": \"3\",\n" +
            "                \"sn\": \"1111111\",\n" +
            "                \"uid\": \"1\",\n" +
            "                \"utitle\": \"1111111\",\n" +
            "                \"src\": \"1\",\n" +
            "                \"fileName\": \"1111111\",\n" +
            "                \"playtime\": 0,\n" +
            "                \"oriName\": \"ccc\",\n" +
            "                \"preview\": \"http://img2.3lian.com/img2007/10/28/123.jpg\",\n" +
            "                \"file\": \"1\",\n" +
            "                \"down\": \"http://img2.3lian.com/img2007/10/28/123.jpg\",\n" +
            "                \"createTime\": \"1454297024\",\n" +
            "                \"ftype\": 0\n" +
            "            },\n" +
            "            {\n" +
            "                \"imageId\": \"3\",\n" +
            "                \"sn\": \"1111111\",\n" +
            "                \"uid\": \"1\",\n" +
            "                \"utitle\": \"1111111\",\n" +
            "                \"src\": \"1\",\n" +
            "                \"fileName\": \"1111111\",\n" +
            "                \"playtime\": 0,\n" +
            "                \"oriName\": \"ccc\",\n" +
            "                \"preview\": \"http://img2.3lian.com/img2007/10/28/123.jpg\",\n" +
            "                \"file\": \"1\",\n" +
            "                \"down\": \"http://img2.3lian.com/img2007/10/28/123.jpg\",\n" +
            "                \"createTime\": \"1454297024\",\n" +
            "                \"ftype\": 0\n" +
            "            },\n" +
            "            {\n" +
            "                \"imageId\": \"3\",\n" +
            "                \"sn\": \"1111111\",\n" +
            "                \"uid\": \"1\",\n" +
            "                \"utitle\": \"1111111\",\n" +
            "                \"src\": \"1\",\n" +
            "                \"fileName\": \"1111111\",\n" +
            "                \"playtime\": 0,\n" +
            "                \"oriName\": \"ccc\",\n" +
            "                \"preview\": \"http://img2.3lian.com/img2007/10/28/123.jpg\",\n" +
            "                \"file\": \"1\",\n" +
            "                \"down\": \"http://img2.3lian.com/img2007/10/28/123.jpg\",\n" +
            "                \"createTime\": \"1454297024\",\n" +
            "                \"ftype\": 0\n" +
            "            },\n" +
            "            {\n" +
            "                \"imageId\": \"2\",\n" +
            "                \"sn\": \"1111111\",\n" +
            "                \"uid\": \"1\",\n" +
            "                \"utitle\": \"1111111\",\n" +
            "                \"src\": \"1\",\n" +
            "                \"fileName\": \"1111111\",\n" +
            "                \"playtime\": 0,\n" +
            "                \"oriName\": \"点点点\",\n" +
            "                \"preview\": \"http://img2.3lian.com/img2007/10/28/124.jpg\",\n" +
            "                \"file\": \"1\",\n" +
            "                \"down\": \"http://img2.3lian.com/img2007/10/28/124.jpg\",\n" +
            "                \"createTime\": \"1454297024\",\n" +
            "                \"ftype\": 0\n" +
            "            },\n" +
            "            {\n" +
            "                \"imageId\": \"2\",\n" +
            "                \"sn\": \"1111111\",\n" +
            "                \"uid\": \"1\",\n" +
            "                \"utitle\": \"1111111\",\n" +
            "                \"src\": \"1\",\n" +
            "                \"fileName\": \"1111111\",\n" +
            "                \"playtime\": 0,\n" +
            "                \"oriName\": \"呃呃呃\",\n" +
            "                \"preview\": \"http://img2.3lian.com/img2007/10/28/125.jpg\",\n" +
            "                \"file\": \"1\",\n" +
            "                \"down\": \"http://img2.3lian.com/img2007/10/28/125.jpg\",\n" +
            "                \"createTime\": \"1454297024\",\n" +
            "                \"ftype\": 0\n" +
            "            },\n" +
            "            {\n" +
            "                \"imageId\": \"2\",\n" +
            "                \"sn\": \"1111111\",\n" +
            "                \"uid\": \"1\",\n" +
            "                \"utitle\": \"1111111\",\n" +
            "                \"src\": \"1\",\n" +
            "                \"fileName\": \"1111111\",\n" +
            "                \"playtime\": 0,\n" +
            "                \"oriName\": \"烦烦烦\",\n" +
            "                \"preview\": \"http://img2.3lian.com/img2007/10/28/126.jpg\",\n" +
            "                \"file\": \"1\",\n" +
            "                \"down\": \"http://img2.3lian.com/img2007/10/28/126.jpg\",\n" +
            "                \"createTime\": \"1454297024\",\n" +
            "                \"ftype\": 0\n" +
            "            },\n" +
            "            {\n" +
            "                \"imageId\": \"2\",\n" +
            "                \"sn\": \"1111111\",\n" +
            "                \"uid\": \"1\",\n" +
            "                \"utitle\": \"1111111\",\n" +
            "                \"src\": \"1\",\n" +
            "                \"fileName\": \"1111111\",\n" +
            "                \"playtime\": 70000,\n" +
            "                \"oriName\": \"嘎嘎嘎\",\n" +
            "                \"preview\": \"http://img2.3lian.com/img2007/10/28/127.jpg\",\n" +
            "                \"file\": \"1\",\n" +
            "                \"down\": \"http://img2.3lian.com/img2007/10/28/127.jpg\",\n" +
            "                \"createTime\": \"1454297024\",\n" +
            "                \"ftype\": 1\n" +
            "            },\n" +
            "            {\n" +
            "                \"imageId\": \"2\",\n" +
            "                \"sn\": \"1111111\",\n" +
            "                \"uid\": \"1\",\n" +
            "                \"utitle\": \"1111111\",\n" +
            "                \"src\": \"1\",\n" +
            "                \"fileName\": \"1111111\",\n" +
            "                \"playtime\": 0,\n" +
            "                \"oriName\": \"不不不\",\n" +
            "                \"preview\": \"http://img2.3lian.com/img2007/10/28/122.jpg\",\n" +
            "                \"file\": \"1\",\n" +
            "                \"down\": \"http://img2.3lian.com/img2007/10/28/122.jpg\",\n" +
            "                \"createTime\": \"1454297024\",\n" +
            "                \"ftype\": 0\n" +
            "            },\n" +
            "            {\n" +
            "                \"imageId\": \"2\",\n" +
            "                \"sn\": \"1111111\",\n" +
            "                \"uid\": \"1\",\n" +
            "                \"utitle\": \"1111111\",\n" +
            "                \"src\": \"1\",\n" +
            "                \"fileName\": \"1111111\",\n" +
            "                \"playtime\": 0,\n" +
            "                \"oriName\": \"不不不\",\n" +
            "                \"preview\": \"http://img2.3lian.com/img2007/10/28/122.jpg\",\n" +
            "                \"file\": \"1\",\n" +
            "                \"down\": \"http://img2.3lian.com/img2007/10/28/122.jpg\",\n" +
            "                \"createTime\": \"1454210650\",\n" +
            "                \"ftype\": 0\n" +
            "            },\n" +
            "            {\n" +
            "                \"imageId\": \"2\",\n" +
            "                \"sn\": \"1111111\",\n" +
            "                \"uid\": \"1\",\n" +
            "                \"utitle\": \"1111111\",\n" +
            "                \"src\": \"1\",\n" +
            "                \"fileName\": \"1111111\",\n" +
            "                \"playtime\": 0,\n" +
            "                \"oriName\": \"不不不\",\n" +
            "                \"preview\": \"http://img2.3lian.com/img2007/10/28/122.jpg\",\n" +
            "                \"file\": \"1\",\n" +
            "                \"down\": \"http://img2.3lian.com/img2007/10/28/122.jpg\",\n" +
            "                \"createTime\": \"1454210650\",\n" +
            "                \"ftype\": 0\n" +
            "            },\n" +
            "            {\n" +
            "                \"imageId\": \"2\",\n" +
            "                \"sn\": \"1111111\",\n" +
            "                \"uid\": \"1\",\n" +
            "                \"utitle\": \"1111111\",\n" +
            "                \"src\": \"1\",\n" +
            "                \"fileName\": \"1111111\",\n" +
            "                \"playtime\": 0,\n" +
            "                \"oriName\": \"不不不\",\n" +
            "                \"preview\": \"http://img2.3lian.com/img2007/10/28/122.jpg\",\n" +
            "                \"file\": \"1\",\n" +
            "                \"down\": \"http://img2.3lian.com/img2007/10/28/122.jpg\",\n" +
            "                \"createTime\": \"1454210650\",\n" +
            "                \"ftype\": 0\n" +
            "            },\n" +
            "            {\n" +
            "                \"imageId\": \"2\",\n" +
            "                \"sn\": \"1111111\",\n" +
            "                \"uid\": \"1\",\n" +
            "                \"utitle\": \"1111111\",\n" +
            "                \"src\": \"1\",\n" +
            "                \"fileName\": \"1111111\",\n" +
            "                \"playtime\": 0,\n" +
            "                \"oriName\": \"uuu\",\n" +
            "                \"preview\": \"http://img2.3lian.com/img2007/10/28/122.jpg\",\n" +
            "                \"file\": \"1\",\n" +
            "                \"down\": \"http://img2.3lian.com/img2007/10/28/122.jpg\",\n" +
            "                \"createTime\": \"1454210650\",\n" +
            "                \"ftype\": 0\n" +
            "            },\n" +
            "            {\n" +
            "                \"imageId\": \"3\",\n" +
            "                \"sn\": \"1111111\",\n" +
            "                \"uid\": \"1\",\n" +
            "                \"utitle\": \"1111111\",\n" +
            "                \"src\": \"1\",\n" +
            "                \"fileName\": \"1111111\",\n" +
            "                \"playtime\": 0,\n" +
            "                \"oriName\": \"哈哈哈\",\n" +
            "                \"preview\": \"http://img2.3lian.com/img2007/10/28/128.jpg\",\n" +
            "                \"file\": \"1\",\n" +
            "                \"down\": \"http://img2.3lian.com/img2007/10/28/128.jpg\",\n" +
            "                \"createTime\": \"1454210650\",\n" +
            "                \"ftype\": 0\n" +
            "            }\n" +
            "        ],\n" +
            "        \"count\": 0\n" +
            "    }\n" +
            "}";

    public static String json2 = "{\n" +
            "    \"errorCode\": 0,\n" +
            "    \"errorMsg\": \"成功\",\n" +
            "    \"data\": {\n" +
            "        \"list\": [\n" +
            "            {\n" +
            "                \"imageId\": \"2\",\n" +
            "                \"sn\": \"1111111\",\n" +
            "                \"uid\": \"1\",\n" +
            "                \"utitle\": \"1111111\",\n" +
            "                \"src\": \"1\",\n" +
            "                \"fileName\": \"1111111\",\n" +
            "                \"playtime\": 0,\n" +
            "                \"oriName\": \"不不不\",\n" +
            "                \"preview\": \"http://img2.3lian.com/img2007/10/28/122.jpg\",\n" +
            "                \"file\": \"1\",\n" +
            "                \"down\": \"http://img2.3lian.com/img2007/10/28/122.jpg\",\n" +
            "                \"createTime\": \"1454297024\",\n" +
            "                \"ftype\": 0\n" +
            "            },\n" +
            "            {\n" +
            "                \"imageId\": \"3\",\n" +
            "                \"sn\": \"1111111\",\n" +
            "                \"uid\": \"1\",\n" +
            "                \"utitle\": \"1111111\",\n" +
            "                \"src\": \"1\",\n" +
            "                \"fileName\": \"1111111\",\n" +
            "                \"playtime\": 0,\n" +
            "                \"oriName\": \"ccc\",\n" +
            "                \"preview\": \"http://img2.3lian.com/img2007/10/28/123.jpg\",\n" +
            "                \"file\": \"1\",\n" +
            "                \"down\": \"http://img2.3lian.com/img2007/10/28/123.jpg\",\n" +
            "                \"createTime\": \"1454297024\",\n" +
            "                \"ftype\": 0\n" +
            "            }\n" +
            "        ],\n" +
            "        \"count\": 0\n" +
            "    }\n" +
            "}";

    public static String json1 = "{\n" +
            "    \"errorCode\": 0,\n" +
            "    \"errorMsg\": \"成功\",\n" +
            "    \"data\": {}\n" +
            "}";

    public static String audioListById = "{\n" +
            "    \"errorCode\":0,\n" +
            "    \"errorMsg\":\"成功\",\n" +
            "    \"data\":{\n" +
            "        \"albumInfo\":{\n" +
            "            \"albumId\":\"101\",\n" +
            "            \"title\":\"世界亲子图画书01\",\n" +
            "            \"imageUrl\":\"http://c3.duotin.com/i1/DT/56diZAffKNbDT0cwabcMAxYe0LgHmdjETTuvgvaZvqM.jpg\",\n" +
            "            \"describe\":\"从零岁开始培养孩子的阅读习惯，这已经成为许多爸爸妈妈的共识。我们的目的，并不是要培养孩子成为早慧的天才，也不是要让读书识字充塞童年的快乐时光。我们的目标，是充分开发孩子的潜能，让阅读成为孩子认知和交流的重要途径，让阅读成为童年快乐生活的一部分。成功的亲子共读的秘诀，是与孩子一起享受阅读的快乐，通过爱的传导，让孩子热爱书籍，让快乐阅读的习惯陪伴孩子终身。\",\n" +
            "            \"contentNum\":\"50\",\n" +
            "            \"playNum\":\"8265\"\n" +
            "        },\n" +
            "        \"pageInfo\":{\n" +
            "            \"totalPage\":50,\n" +
            "            \"page\":1,\n" +
            "            \"pageSize\":1,\n" +
            "            \"sortType\":0\n" +
            "        },\n" +
            "        \"data\":[\n" +
            "            {\n" +
            "                \"audiId\":\"3875\",\n" +
            "                \"title\":\"丁丁点儿\",\n" +
            "                \"albumId\":\"101\",\n" +
            "                \"duration\":\"00:12:11\",\n" +
            "                \"playNum\":\"1504\",\n" +
            "                \"audi32Size\":\"5850835\",\n" +
            "                \"audi64Size\":\"5850835\",\n" +
            "                \"audi32Url\":\"http://c202.duotin.com/M00/2D/A6/wKgB3FRPA02ADWKgAFlG0xSx_zg563.mp3\",\n" +
            "                \"audi64Url\":\"http://c202.duotin.com/M00/2D/A6/wKgB3FRPA02ADWKgAFlG0xSx_zg563.mp3 \",\n" +
            "                \"displayOrder\":\"100001\"\n" +
            "            }\n" +
            "        ]\n" +
            "    }\n" +
            "}\n";

    //平板设置选项
    public interface SettingCameraItem {
        public static final String PAD_HEAD_ITEM = "PAD_HEAD_ITEM";
        public static final String PAD_TITLE_ITEM = "PAD_TITLE_ITEM";
        public static final String PAD_MUTE_ITEM = "PAD_MUTE_ITEM";
        public static final String PAD_SCREENSAVERS_ITEM = "PAD_SCREENSAVERS_ITEM";
        public static final String PAD_HEALTH_ITEM = "PAD_HEALTH_ITEM";
        public static final String PAD_MANAGER_ITEM = "PAD_MANAGER_ITEM";
        public static final String PAD_ABOUT_ITEM = "PAD_ABOUT_ITEM";
        public static final String PAD_HEAD_BIND_ITEM = "PAD_HEAD_BIND_ITEM";
        public static final String PAD_EDIT_FAMILY_ITEM = "PAD_EDIT_FAMILY_ITEM";

        public static final String PAD_PERSONAL_SETTING_ACCOUNT_ITEM = "PAD_PERSONAL_SETTING_ACCOUNT_ITEM";
        public static final String PAD_PERSONAL_SETTING_PROBLEM_ITEM = "PAD_PERSONAL_SETTING_PROBLEM_ITEM";
        public static final String PAD_PERSONAL_SETTING_FEEDBACK_ITEM = "PAD_PERSONAL_SETTING_FEEDBACK_ITEM";
        public static final String PAD_PERSONAL_SETTING_ABOUT_ITEM = "PAD_PERSONAL_SETTING_ABOUT_ITEM";
        public static final String PAD_PERSONAL_SETTING_NOTIFICATION_ITEM = "PAD_PERSONAL_SETTING_NOTIFICATION_ITEM";
        public static final String MACHINE_SETTING_STORY_MACHINE_KEY_INTRODUCTION = "MACHINE_SETTING_STORY_MACHINE_KEY_INTRODUCTION";
    }

    public final static int SUCCEED = 0;
public final static int FAILED = 1;


public static final String TEMP_JSON = "{\n" +
        "    \"errorCode\": 0,\n" +
        "    \"errorMsg\": \"成功\",\n" +
        "    \"data\": {\n" +
        "        \"list\": [\n" +
        "            {\n" +
        "                \"imageId\": \"31\",\n" +
        "                \"sn\": \"36000000000000000006\",\n" +
        "                \"fileName\": \"f227d7690b21c48e540f5ac4874e0375.mp4\",\n" +
        "                \"oriName\": \"video_test4.mp4\",\n" +
        "                \"src\": \"1\",\n" +
        "                \"uid\": \"18446744073709551615\",\n" +
        "                \"utitle\": \"0\",\n" +
        "                \"preview\": {\n" +
        "                    \"url\": \"http://rs-shanghai.oss.yunpan.360.cn/Object.getPreview/pad-master-album-sh/ZjIyN2Q3NjkwYjIxYzQ4ZTU0MGY1YWM0ODc0ZTAzNzUubXA0?e=1459195890&width=100&height=80\",\n" +
        "                    \"token\": \"030f9838e84bbe8f0d364f1eb7c59a8e:5dee660b037a230423794c161fce2f1b\"\n" +
        "                },\n" +
        "                \"file\": {\n" +
        "                    \"url\": \"http://rs-shanghai.oss.yunpan.360.cn/Object.getFile/pad-master-album-sh/ZjIyN2Q3NjkwYjIxYzQ4ZTU0MGY1YWM0ODc0ZTAzNzUubXA0?e=1459195890\",\n" +
        "                    \"token\": \"030f9838e84bbe8f0d364f1eb7c59a8e:ee4cd48e4e5c128615c3dd3ac825c257\"\n" +
        "                },\n" +
        "                \"down\": {\n" +
        "                    \"url\": \"http://rs-shanghai.oss.yunpan.360.cn/Object.getDownloadUrl/pad-master-album-sh/ZjIyN2Q3NjkwYjIxYzQ4ZTU0MGY1YWM0ODc0ZTAzNzUubXA0?e=1459195890\",\n" +
        "                    \"token\": \"030f9838e84bbe8f0d364f1eb7c59a8e:8c5ea037970bc0df0561ac712a977ba4\"\n" +
        "                },\n" +
        "                \"playtime\": \"0\",\n" +
        "                \"createTime\": \"2016-03-29 15:01:40\"\n" +
        "            },\n" +
        "            {\n" +
        "                \"imageId\": \"30\",\n" +
        "                \"sn\": \"36000000000000000006\",\n" +
        "                \"fileName\": \"f227d7690b21c48e540f5ac4874e0375.mp4\",\n" +
        "                \"oriName\": \"video_test3.mp4\",\n" +
        "                \"src\": \"1\",\n" +
        "                \"uid\": \"18446744073709551615\",\n" +
        "                \"utitle\": \"0\",\n" +
        "                \"preview\": {\n" +
        "                    \"url\": \"http://rs-shanghai.oss.yunpan.360.cn/Object.getPreview/pad-master-album-sh/ZjIyN2Q3NjkwYjIxYzQ4ZTU0MGY1YWM0ODc0ZTAzNzUubXA0?e=1459195890&width=100&height=80\",\n" +
        "                    \"token\": \"030f9838e84bbe8f0d364f1eb7c59a8e:5dee660b037a230423794c161fce2f1b\"\n" +
        "                },\n" +
        "                \"file\": {\n" +
        "                    \"url\": \"http://rs-shanghai.oss.yunpan.360.cn/Object.getFile/pad-master-album-sh/ZjIyN2Q3NjkwYjIxYzQ4ZTU0MGY1YWM0ODc0ZTAzNzUubXA0?e=1459195890\",\n" +
        "                    \"token\": \"030f9838e84bbe8f0d364f1eb7c59a8e:ee4cd48e4e5c128615c3dd3ac825c257\"\n" +
        "                },\n" +
        "                \"down\": {\n" +
        "                    \"url\": \"http://rs-shanghai.oss.yunpan.360.cn/Object.getDownloadUrl/pad-master-album-sh/ZjIyN2Q3NjkwYjIxYzQ4ZTU0MGY1YWM0ODc0ZTAzNzUubXA0?e=1459195890\",\n" +
        "                    \"token\": \"030f9838e84bbe8f0d364f1eb7c59a8e:8c5ea037970bc0df0561ac712a977ba4\"\n" +
        "                },\n" +
        "                \"playtime\": \"0\",\n" +
        "                \"createTime\": \"2016-03-29 15:01:34\"\n" +
        "            },\n" +
        "            {\n" +
        "                \"imageId\": \"29\",\n" +
        "                \"sn\": \"36000000000000000006\",\n" +
        "                \"fileName\": \"f227d7690b21c48e540f5ac4874e0375.mp4\",\n" +
        "                \"oriName\": \"video_test2.mp4\",\n" +
        "                \"src\": \"1\",\n" +
        "                \"uid\": \"18446744073709551615\",\n" +
        "                \"utitle\": \"0\",\n" +
        "                \"preview\": {\n" +
        "                    \"url\": \"http://rs-shanghai.oss.yunpan.360.cn/Object.getPreview/pad-master-album-sh/ZjIyN2Q3NjkwYjIxYzQ4ZTU0MGY1YWM0ODc0ZTAzNzUubXA0?e=1459195890&width=100&height=80\",\n" +
        "                    \"token\": \"030f9838e84bbe8f0d364f1eb7c59a8e:5dee660b037a230423794c161fce2f1b\"\n" +
        "                },\n" +
        "                \"file\": {\n" +
        "                    \"url\": \"http://rs-shanghai.oss.yunpan.360.cn/Object.getFile/pad-master-album-sh/ZjIyN2Q3NjkwYjIxYzQ4ZTU0MGY1YWM0ODc0ZTAzNzUubXA0?e=1459195890\",\n" +
        "                    \"token\": \"030f9838e84bbe8f0d364f1eb7c59a8e:ee4cd48e4e5c128615c3dd3ac825c257\"\n" +
        "                },\n" +
        "                \"down\": {\n" +
        "                    \"url\": \"http://rs-shanghai.oss.yunpan.360.cn/Object.getDownloadUrl/pad-master-album-sh/ZjIyN2Q3NjkwYjIxYzQ4ZTU0MGY1YWM0ODc0ZTAzNzUubXA0?e=1459195890\",\n" +
        "                    \"token\": \"030f9838e84bbe8f0d364f1eb7c59a8e:8c5ea037970bc0df0561ac712a977ba4\"\n" +
        "                },\n" +
        "                \"playtime\": \"0\",\n" +
        "                \"createTime\": \"2016-03-29 15:01:28\"\n" +
        "            },\n" +
        "            {\n" +
        "                \"imageId\": \"28\",\n" +
        "                \"sn\": \"36000000000000000006\",\n" +
        "                \"fileName\": \"f227d7690b21c48e540f5ac4874e0375.mp4\",\n" +
        "                \"oriName\": \"video_test1.mp4\",\n" +
        "                \"src\": \"1\",\n" +
        "                \"uid\": \"18446744073709551615\",\n" +
        "                \"utitle\": \"0\",\n" +
        "                \"preview\": {\n" +
        "                    \"url\": \"http://rs-shanghai.oss.yunpan.360.cn/Object.getPreview/pad-master-album-sh/ZjIyN2Q3NjkwYjIxYzQ4ZTU0MGY1YWM0ODc0ZTAzNzUubXA0?e=1459195890&width=100&height=80\",\n" +
        "                    \"token\": \"030f9838e84bbe8f0d364f1eb7c59a8e:5dee660b037a230423794c161fce2f1b\"\n" +
        "                },\n" +
        "                \"file\": {\n" +
        "                    \"url\": \"http://rs-shanghai.oss.yunpan.360.cn/Object.getFile/pad-master-album-sh/ZjIyN2Q3NjkwYjIxYzQ4ZTU0MGY1YWM0ODc0ZTAzNzUubXA0?e=1459195890\",\n" +
        "                    \"token\": \"030f9838e84bbe8f0d364f1eb7c59a8e:ee4cd48e4e5c128615c3dd3ac825c257\"\n" +
        "                },\n" +
        "                \"down\": {\n" +
        "                    \"url\": \"http://rs-shanghai.oss.yunpan.360.cn/Object.getDownloadUrl/pad-master-album-sh/ZjIyN2Q3NjkwYjIxYzQ4ZTU0MGY1YWM0ODc0ZTAzNzUubXA0?e=1459195890\",\n" +
        "                    \"token\": \"030f9838e84bbe8f0d364f1eb7c59a8e:8c5ea037970bc0df0561ac712a977ba4\"\n" +
        "                },\n" +
        "                \"playtime\": \"0\",\n" +
        "                \"createTime\": \"2016-03-29 15:01:22\"\n" +
        "            },\n" +
        "            {\n" +
        "                \"imageId\": \"27\",\n" +
        "                \"sn\": \"36000000000000000006\",\n" +
        "                \"fileName\": \"f227d7690b21c48e540f5ac4874e0375.mp4\",\n" +
        "                \"oriName\": \"video_test1.mp4\",\n" +
        "                \"src\": \"1\",\n" +
        "                \"uid\": \"18446744073709551615\",\n" +
        "                \"utitle\": \"0\",\n" +
        "                \"preview\": {\n" +
        "                    \"url\": \"http://rs-shanghai.oss.yunpan.360.cn/Object.getPreview/pad-master-album-sh/ZjIyN2Q3NjkwYjIxYzQ4ZTU0MGY1YWM0ODc0ZTAzNzUubXA0?e=1459195890&width=100&height=80\",\n" +
        "                    \"token\": \"030f9838e84bbe8f0d364f1eb7c59a8e:5dee660b037a230423794c161fce2f1b\"\n" +
        "                },\n" +
        "                \"file\": {\n" +
        "                    \"url\": \"http://rs-shanghai.oss.yunpan.360.cn/Object.getFile/pad-master-album-sh/ZjIyN2Q3NjkwYjIxYzQ4ZTU0MGY1YWM0ODc0ZTAzNzUubXA0?e=1459195890\",\n" +
        "                    \"token\": \"030f9838e84bbe8f0d364f1eb7c59a8e:ee4cd48e4e5c128615c3dd3ac825c257\"\n" +
        "                },\n" +
        "                \"down\": {\n" +
        "                    \"url\": \"http://rs-shanghai.oss.yunpan.360.cn/Object.getDownloadUrl/pad-master-album-sh/ZjIyN2Q3NjkwYjIxYzQ4ZTU0MGY1YWM0ODc0ZTAzNzUubXA0?e=1459195890\",\n" +
        "                    \"token\": \"030f9838e84bbe8f0d364f1eb7c59a8e:8c5ea037970bc0df0561ac712a977ba4\"\n" +
        "                },\n" +
        "                \"playtime\": \"0\",\n" +
        "                \"createTime\": \"2016-03-29 15:01:20\"\n" +
        "            },\n" +
        "            {\n" +
        "                \"imageId\": \"26\",\n" +
        "                \"sn\": \"36000000000000000006\",\n" +
        "                \"fileName\": \"f227d7690b21c48e540f5ac4874e0375.mp4\",\n" +
        "                \"oriName\": \"video_test1.mp4\",\n" +
        "                \"src\": \"1\",\n" +
        "                \"uid\": \"18446744073709551615\",\n" +
        "                \"utitle\": \"0\",\n" +
        "                \"preview\": {\n" +
        "                    \"url\": \"http://rs-shanghai.oss.yunpan.360.cn/Object.getPreview/pad-master-album-sh/ZjIyN2Q3NjkwYjIxYzQ4ZTU0MGY1YWM0ODc0ZTAzNzUubXA0?e=1459195890&width=100&height=80\",\n" +
        "                    \"token\": \"030f9838e84bbe8f0d364f1eb7c59a8e:5dee660b037a230423794c161fce2f1b\"\n" +
        "                },\n" +
        "                \"file\": {\n" +
        "                    \"url\": \"http://rs-shanghai.oss.yunpan.360.cn/Object.getFile/pad-master-album-sh/ZjIyN2Q3NjkwYjIxYzQ4ZTU0MGY1YWM0ODc0ZTAzNzUubXA0?e=1459195890\",\n" +
        "                    \"token\": \"030f9838e84bbe8f0d364f1eb7c59a8e:ee4cd48e4e5c128615c3dd3ac825c257\"\n" +
        "                },\n" +
        "                \"down\": {\n" +
        "                    \"url\": \"http://rs-shanghai.oss.yunpan.360.cn/Object.getDownloadUrl/pad-master-album-sh/ZjIyN2Q3NjkwYjIxYzQ4ZTU0MGY1YWM0ODc0ZTAzNzUubXA0?e=1459195890\",\n" +
        "                    \"token\": \"030f9838e84bbe8f0d364f1eb7c59a8e:8c5ea037970bc0df0561ac712a977ba4\"\n" +
        "                },\n" +
        "                \"playtime\": \"0\",\n" +
        "                \"createTime\": \"2016-03-28 15:01:17\"\n" +
        "            },\n" +
        "            {\n" +
        "                \"imageId\": \"25\",\n" +
        "                \"sn\": \"36000000000000000006\",\n" +
        "                \"fileName\": \"f227d7690b21c48e540f5ac4874e0375.mp4\",\n" +
        "                \"oriName\": \"video_test1.mp4\",\n" +
        "                \"src\": \"1\",\n" +
        "                \"uid\": \"18446744073709551615\",\n" +
        "                \"utitle\": \"0\",\n" +
        "                \"preview\": {\n" +
        "                    \"url\": \"http://rs-shanghai.oss.yunpan.360.cn/Object.getPreview/pad-master-album-sh/ZjIyN2Q3NjkwYjIxYzQ4ZTU0MGY1YWM0ODc0ZTAzNzUubXA0?e=1459195890&width=100&height=80\",\n" +
        "                    \"token\": \"030f9838e84bbe8f0d364f1eb7c59a8e:5dee660b037a230423794c161fce2f1b\"\n" +
        "                },\n" +
        "                \"file\": {\n" +
        "                    \"url\": \"http://rs-shanghai.oss.yunpan.360.cn/Object.getFile/pad-master-album-sh/ZjIyN2Q3NjkwYjIxYzQ4ZTU0MGY1YWM0ODc0ZTAzNzUubXA0?e=1459195890\",\n" +
        "                    \"token\": \"030f9838e84bbe8f0d364f1eb7c59a8e:ee4cd48e4e5c128615c3dd3ac825c257\"\n" +
        "                },\n" +
        "                \"down\": {\n" +
        "                    \"url\": \"http://rs-shanghai.oss.yunpan.360.cn/Object.getDownloadUrl/pad-master-album-sh/ZjIyN2Q3NjkwYjIxYzQ4ZTU0MGY1YWM0ODc0ZTAzNzUubXA0?e=1459195890\",\n" +
        "                    \"token\": \"030f9838e84bbe8f0d364f1eb7c59a8e:8c5ea037970bc0df0561ac712a977ba4\"\n" +
        "                },\n" +
        "                \"playtime\": \"0\",\n" +
        "                \"createTime\": \"2016-03-27 15:01:14\"\n" +
        "            },\n" +
        "            {\n" +
        "                \"imageId\": \"24\",\n" +
        "                \"sn\": \"36000000000000000006\",\n" +
        "                \"fileName\": \"f227d7690b21c48e540f5ac4874e0375.mp4\",\n" +
        "                \"oriName\": \"video_test.mp4\",\n" +
        "                \"src\": \"1\",\n" +
        "                \"uid\": \"18446744073709551615\",\n" +
        "                \"utitle\": \"0\",\n" +
        "                \"preview\": {\n" +
        "                    \"url\": \"http://rs-shanghai.oss.yunpan.360.cn/Object.getPreview/pad-master-album-sh/ZjIyN2Q3NjkwYjIxYzQ4ZTU0MGY1YWM0ODc0ZTAzNzUubXA0?e=1459195890&width=100&height=80\",\n" +
        "                    \"token\": \"030f9838e84bbe8f0d364f1eb7c59a8e:5dee660b037a230423794c161fce2f1b\"\n" +
        "                },\n" +
        "                \"file\": {\n" +
        "                    \"url\": \"http://rs-shanghai.oss.yunpan.360.cn/Object.getFile/pad-master-album-sh/ZjIyN2Q3NjkwYjIxYzQ4ZTU0MGY1YWM0ODc0ZTAzNzUubXA0?e=1459195890\",\n" +
        "                    \"token\": \"030f9838e84bbe8f0d364f1eb7c59a8e:ee4cd48e4e5c128615c3dd3ac825c257\"\n" +
        "                },\n" +
        "                \"down\": {\n" +
        "                    \"url\": \"http://rs-shanghai.oss.yunpan.360.cn/Object.getDownloadUrl/pad-master-album-sh/ZjIyN2Q3NjkwYjIxYzQ4ZTU0MGY1YWM0ODc0ZTAzNzUubXA0?e=1459195890\",\n" +
        "                    \"token\": \"030f9838e84bbe8f0d364f1eb7c59a8e:8c5ea037970bc0df0561ac712a977ba4\"\n" +
        "                },\n" +
        "                \"playtime\": \"0\",\n" +
        "                \"createTime\": \"2016-03-26 15:00:58\"\n" +
        "            },\n" +
        "            {\n" +
        "                \"imageId\": \"2\",\n" +
        "                \"sn\": \"36000000000000000006\",\n" +
        "                \"fileName\": \"f227d7690b21c48e540f5ac4874e0375.mp4\",\n" +
        "                \"oriName\": \"video_test.mp4\",\n" +
        "                \"src\": \"1\",\n" +
        "                \"uid\": \"18446744073709551615\",\n" +
        "                \"utitle\": \"0\",\n" +
        "                \"preview\": {\n" +
        "                    \"url\": \"http://rs-shanghai.oss.yunpan.360.cn/Object.getPreview/pad-master-album-sh/ZjIyN2Q3NjkwYjIxYzQ4ZTU0MGY1YWM0ODc0ZTAzNzUubXA0?e=1459195890&width=100&height=80\",\n" +
        "                    \"token\": \"030f9838e84bbe8f0d364f1eb7c59a8e:5dee660b037a230423794c161fce2f1b\"\n" +
        "                },\n" +
        "                \"file\": {\n" +
        "                    \"url\": \"http://rs-shanghai.oss.yunpan.360.cn/Object.getFile/pad-master-album-sh/ZjIyN2Q3NjkwYjIxYzQ4ZTU0MGY1YWM0ODc0ZTAzNzUubXA0?e=1459195890\",\n" +
        "                    \"token\": \"030f9838e84bbe8f0d364f1eb7c59a8e:ee4cd48e4e5c128615c3dd3ac825c257\"\n" +
        "                },\n" +
        "                \"down\": {\n" +
        "                    \"url\": \"http://rs-shanghai.oss.yunpan.360.cn/Object.getDownloadUrl/pad-master-album-sh/ZjIyN2Q3NjkwYjIxYzQ4ZTU0MGY1YWM0ODc0ZTAzNzUubXA0?e=1459195890\",\n" +
        "                    \"token\": \"030f9838e84bbe8f0d364f1eb7c59a8e:8c5ea037970bc0df0561ac712a977ba4\"\n" +
        "                },\n" +
        "                \"playtime\": \"0\",\n" +
        "                \"createTime\": \"2016-03-25 11:08:38\"\n" +
        "            },\n" +
        "            {\n" +
        "                \"imageId\": \"1\",\n" +
        "                \"sn\": \"36000000000000000006\",\n" +
        "                \"fileName\": \"f227d7690b21c48e540f5ac4874e0375.mp4\",\n" +
        "                \"oriName\": \"video_test.mp4\",\n" +
        "                \"src\": \"1\",\n" +
        "                \"uid\": \"18446744073709551615\",\n" +
        "                \"utitle\": \"0\",\n" +
        "                \"preview\": {\n" +
        "                    \"url\": \"http://rs-shanghai.oss.yunpan.360.cn/Object.getPreview/pad-master-album-sh/ZjIyN2Q3NjkwYjIxYzQ4ZTU0MGY1YWM0ODc0ZTAzNzUubXA0?e=1459195890&width=100&height=80\",\n" +
        "                    \"token\": \"030f9838e84bbe8f0d364f1eb7c59a8e:5dee660b037a230423794c161fce2f1b\"\n" +
        "                },\n" +
        "                \"file\": {\n" +
        "                    \"url\": \"http://rs-shanghai.oss.yunpan.360.cn/Object.getFile/pad-master-album-sh/ZjIyN2Q3NjkwYjIxYzQ4ZTU0MGY1YWM0ODc0ZTAzNzUubXA0?e=1459195890\",\n" +
        "                    \"token\": \"030f9838e84bbe8f0d364f1eb7c59a8e:ee4cd48e4e5c128615c3dd3ac825c257\"\n" +
        "                },\n" +
        "                \"down\": {\n" +
        "                    \"url\": \"http://rs-shanghai.oss.yunpan.360.cn/Object.getDownloadUrl/pad-master-album-sh/ZjIyN2Q3NjkwYjIxYzQ4ZTU0MGY1YWM0ODc0ZTAzNzUubXA0?e=1459195890\",\n" +
        "                    \"token\": \"030f9838e84bbe8f0d364f1eb7c59a8e:8c5ea037970bc0df0561ac712a977ba4\"\n" +
        "                },\n" +
        "                \"playtime\": \"0\",\n" +
        "                \"createTime\": \"2016-03-25 11:08:36\"\n" +
        "            }\n" +
        "        ],\n" +
        "        \"count\": \"10\"\n" +
        "    }\n" +
        "}";
}
