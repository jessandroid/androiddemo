package com.qihoo360.homecamera.mobile.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.FrameLayout;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.entity.DeviceInfo;
import com.qihoo360.homecamera.mobile.ui.fragment.PadHeadFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.PersonCenterFragment;

import java.util.ArrayList;

public class PersonCenterActivity extends BaseActivity {

    ArrayList<DeviceInfo> devList;
    private FrameLayout frag;
    private PersonCenterFragment personCenterFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        devList = getIntent().getParcelableArrayListExtra("devList");
        if (devList == null) {
            devList = new ArrayList<>();
        }
        setContentView(R.layout.activity_person_center);
        frag = (FrameLayout)findViewById(R.id.person_center_layout);
        personCenterFragment = PersonCenterFragment.newInstance();
        getSupportFragmentManager().beginTransaction().add(R.id.person_center_layout,personCenterFragment).commit();
    }

    public ArrayList<DeviceInfo> getDeviceList() {
        return devList;
    }

    public void setList(ArrayList<DeviceInfo> deviceList){
        if(deviceList!=null){
            devList = deviceList;
        }
    }

    public void removeDevice(String sn) {
        for (int i = 0; i < devList.size(); i++) {
            if (TextUtils.equals(devList.get(i).getSn(), sn)) {
                devList.remove(i);
                break;
            }
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case PadHeadFragment.REQUEST_CROP_PHOTO: {
                if (mUserHeadUri != null && resultCode == RESULT_OK) {
                    personCenterFragment.ModifyUserHead(mUserHeadUri.getPath());
                }
                break;
            }
        }
    }
}
