package com.qihoo360.homecamera.machine.log;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Environment;
import android.telephony.TelephonyManager;
import android.util.Log;

import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.FileUtil;
import com.qihoo360.homecamera.mobile.utils.StorageUtil;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by zhucheng on 4/10/17.
 */

public class CamLogUtils {

    private static final String LOGFILE_NAME = "camera_log.txt";


    private static StringBuffer collectDeviceInfo(Context ctx) {
        // 用来存储设备信息和异常信息
        Map<String, String> infos = new HashMap<String, String>();
        infos.put("androidVersionCode", "" + Build.VERSION.SDK_INT);
        try {
            PackageManager pm = ctx.getPackageManager();
            PackageInfo pi = pm.getPackageInfo(ctx.getPackageName(),
                    PackageManager.GET_ACTIVITIES);
            if (pi != null) {
                String versionName = pi.versionName == null ? "null"
                        : pi.versionName;
                String versionCode = pi.versionCode + "";
                infos.put("versionName", versionName);
                infos.put("versionCode", versionCode);
            }
        } catch (Exception e) {
            CLog.e("LogUtil", "an error occured when collect package info:" + e);
        }
        Field[] fields = Build.class.getDeclaredFields();
        for (Field field : fields) {
            try {
                field.setAccessible(true);
                infos.put(field.getName(), field.get(null).toString());
                CLog.d("LogUtil", field.getName() + " : " + field.get(null));
            } catch (Exception e) {
                CLog.e("LogUtil", "an error occured when collect crash info:" + e);
            }
        }
        // for oom analysis
        ActivityManager am = (ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
        infos.put("maxMemory", String.valueOf(Runtime.getRuntime().maxMemory()));
        infos.put("LargeMemoryClass", String.valueOf(am.getLargeMemoryClass()));
        infos.put("MemoryClass", String.valueOf(am.getMemoryClass()));
        infos.put("DisplayMetrics", ctx.getResources().getDisplayMetrics().toString());

        StringBuffer sb = new StringBuffer();
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
        String timestamp = format.format(System.currentTimeMillis());
        sb.append(timestamp + "\ttype=0\t");
        sb.append("qid=" + AccUtil.getInstance().getQID() + "\t");
        TelephonyManager tm = (TelephonyManager) Utils.getContext()
                .getSystemService(Context.TELEPHONY_SERVICE);
        String deviceId = tm.getDeviceId();
        sb.append("imei=" + deviceId + "\t");
        for (Map.Entry<String, String> entry : infos.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            sb.append(key + "=" + value + "\t");
        }
        sb.append("\r\n");
        return sb;
    }

    @SuppressLint("SdCardPath")
    public static synchronized void saveLog2File(String content) {
        if (!CLog.isFileLog() || Utils.getContext() == null) {
            return;
        }
        FileOutputStream fos1 = null;
        try {
            if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
                File file = new File(FileUtil.getInstance().getLogFile(), LOGFILE_NAME);
                if (file.exists()) {
                    long length = file.length();
                    if (length / 1024 > 1024 * 1) {
                        file.delete();
                    }
                }
                if (!file.exists()) {
                    file.createNewFile();
                    fos1 = new FileOutputStream(file, true);
                    fos1.write(collectDeviceInfo(Utils.getContext()).toString()
                            .getBytes("utf-8"));
                }

                if (CLog.isFileLog()) {
                    Log.d("LogUtil", "记录:" + file.getAbsolutePath());
                }
                if (StorageUtil.byteToMB(StorageUtil.getAvailableExternalMemorySize()) > 10) {
                    if (fos1 == null) {
                        fos1 = new FileOutputStream(file, true);
                    }
                    fos1.write(content.getBytes("utf-8"));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (fos1 != null) {
                try {
                    fos1.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
