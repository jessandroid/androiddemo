
package com.qihoo360.homecamera.mobile.core.util;

import com.qihoo360.homecamera.mobile.core.beans.Response;


public class ManagedRuntimeException extends RuntimeException {

    private static final long serialVersionUID = 6178340654853067026L;
    public Response errorResponse;
    public String nid = "";
    public String apiName = "";
    /**
     * set the two fields below if this is not an network related error, e.g. local io errors, no sdcard errors
     */
    public int errorCode;
    public String errorMessage;

    public ManagedRuntimeException() {
    }

    public ManagedRuntimeException(int errorCode, String errorMessage) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    public ManagedRuntimeException(Response response) {
        super(response == null ? "Unknow error" : ("Response code: " + response.errorNumber + ", message: " + response.errorMessage + "."));
        errorResponse = response;
    }

    public ManagedRuntimeException(String detailMessage, Response response) {
        super(detailMessage);
        errorResponse = response;
    }

    public ManagedRuntimeException(String detailMessage) {
        super(detailMessage);
    }

    public ManagedRuntimeException(String detailMessage, Throwable throwable) {
        super(detailMessage, throwable);
    }

    public ManagedRuntimeException(Throwable throwable) {
        super(throwable);
    }
}
