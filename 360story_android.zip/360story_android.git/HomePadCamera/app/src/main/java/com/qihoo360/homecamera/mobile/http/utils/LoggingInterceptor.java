package com.qihoo360.homecamera.mobile.http.utils;

import com.google.gson.Gson;
import com.qihoo360.homecamera.mobile.entity.Head;
import com.qihoo360.homecamera.mobile.utils.CLog;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okio.Buffer;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/7/21
 * Time: 18:18
 * To change this template use File | Settings | File Templates.
 */
public class LoggingInterceptor implements Interceptor {

    private static final String F_BREAK = " %n";
    private static final String F_URL = " %s";
    private static final String F_TIME = " in %.1fms";
    private static final String F_HEADERS = "%s";
    private static final String F_RESPONSE = F_BREAK + "Response: %d";
    private static final String F_BODY = "body: %s";

    private static final String F_BREAKER = F_BREAK + "-----------------------------------------------" + F_BREAK;
    private static final String F_REQUEST_WITHOUT_BODY = F_URL + F_TIME + F_BREAK + F_HEADERS;
    private static final String F_RESPONSE_WITHOUT_BODY = F_RESPONSE + F_BREAK + F_HEADERS + F_BREAKER;
    private static final String F_REQUEST_WITH_BODY = F_URL + F_TIME + F_BREAK + F_HEADERS + F_BODY + F_BREAK;
    private static final String F_RESPONSE_WITH_BODY = F_RESPONSE + F_BREAK + F_HEADERS + F_BODY + F_BREAK + F_BREAKER;


    @Override
    public Response intercept(Chain chain) throws IOException {
        Request request = chain.request();
        Request.Builder requestBuilder = request.newBuilder();
        Request signedRequest = requestBuilder.build();
        long t1 = System.nanoTime();
        Response response = chain.proceed(signedRequest);
        long t2 = System.nanoTime();
        MediaType contentType = null;
        String bodyString = null;
        if (response.body() != null) {
            contentType = response.body().contentType();
        }
        if (!contentType.type().contains("image")) {
            bodyString = response.body().string();
            double time = (t2 - t1) / 1e6d;
            String log = null;
            switch (request.method()) {
                case "GET":
                    log =
                            String.format("GET " + F_REQUEST_WITHOUT_BODY + F_RESPONSE_WITHOUT_BODY,
                                    signedRequest.url(),
                                    time,
                                    signedRequest.headers(),
                                    response.code(),
                                    response.headers(),
                                    stringifyResponseBody(bodyString));

                    break;
                case "POST":
                    log =
                            String.format("POST " + F_REQUEST_WITH_BODY + F_RESPONSE_WITH_BODY,
                                    signedRequest.url(),
                                    time,
                                    signedRequest.headers(),
                                    stringifyRequestBody(signedRequest),
                                    response.code(),
                                    response.headers(),
                                    stringifyResponseBody(bodyString));
                    break;
                case "PUT":
                    log =
                            String.format("PUT " + F_REQUEST_WITH_BODY + F_RESPONSE_WITH_BODY,
                                    signedRequest.url(),
                                    time,
                                    signedRequest.headers(),
                                    signedRequest.body().toString(),
                                    response.code(),
                                    response.headers(),
                                    stringifyResponseBody(bodyString));
                    break;
                case "DELETE":
                    log = String.format("DELETE " + F_REQUEST_WITHOUT_BODY + F_RESPONSE_WITHOUT_BODY,
                            signedRequest.url(),
                            time,
                            signedRequest.headers(),
                            response.code(),
                            response.headers());
                    break;
            }
            CLog.d(log);
//            Gson gson = new Gson();
//            Head head = gson.fromJson(bodyString, Head.class);
//            if (head == null || head.errorCode != 0) {
//                CLog.justalkFile("http_err_", log);
//            }
            if (response.body() != null) {
                ResponseBody body = ResponseBody.create(contentType, bodyString);
                return response.newBuilder().body(body).build();
            } else {
                return response;
            }
        } else {
            return response;
        }
    }

    private static String stringifyRequestBody(Request request) {
        try {
            final Request copy = request.newBuilder().build();
            final Buffer buffer = new Buffer();
            copy.body().writeTo(buffer);
            return buffer.readUtf8();
        } catch (final IOException e) {
            return "did not work";
        }
    }

    public String stringifyResponseBody(String responseBody) {
        return responseBody;
    }


}
