
package com.qihoo360.homecamera.machine.play.audio;

import android.annotation.SuppressLint;
import android.os.Build;
import android.os.Environment;

import com.qihoo360.homecamera.mobile.utils.CLog;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

@SuppressLint("SdCardPath")
public class VoIPConfig {
    private static final String VoIPConfigFilePath = Environment.getExternalStorageDirectory() + "/aec/voip.conf";
    private static final String KEY_ENABLE_AEC = "enable_aec";
    private static final String KEY_MIC_TYPE = "mic_type";
    private static final String KEY_FAR_CACHE_SIZE = "far_cache_size";
    private static final String KEY_FAR_ADJ = "far_adj";
    private static final String KEY_NEAR_NS = "near_ns";
    private static final String KEY_NEAR_ADJ = "near_adj";
    private static final String KEY_NEAR_VAD = "near_vad";

    private static VqeLookupTable.VqeConfig sVqeConfig = new VqeLookupTable.VqeConfig(Build.BRAND, Build.MODEL);

    public static VqeLookupTable.VqeConfig getVqeConfig() {
        if (!loadConfig()) {
            CLog.e("VoIPConfig", "Load config file failed!");
        }
        return sVqeConfig;
    }

    public static boolean isSupport() {
        File configFile = new File(VoIPConfigFilePath);
        return configFile.exists();
    }

    public static boolean loadConfig() {
        File configFile = new File(VoIPConfigFilePath);
        FileInputStream fis = null;
        byte[] buffer = new byte[10240];

        try {
            File aecDir = configFile.getParentFile();
            if (!aecDir.exists() && aecDir.mkdir()) {
                saveConfig();
            }

            fis = new FileInputStream(configFile);
            int length = fis.read(buffer);
            if (length <= 0) {
                return false;
            }

            JSONObject jsonObj = new JSONObject(new String(buffer));
            if (jsonObj.has(KEY_ENABLE_AEC)) {
                sVqeConfig.mEnableAEC = jsonObj.getBoolean(KEY_ENABLE_AEC);
            }
            if (jsonObj.has(KEY_MIC_TYPE)) {
                sVqeConfig.mAudioSource = jsonObj.getInt(KEY_MIC_TYPE);
            }
            if (jsonObj.has(KEY_FAR_CACHE_SIZE)) {
                sVqeConfig.mFarCacheSizeInMs = jsonObj.getInt(KEY_FAR_CACHE_SIZE);
            }
            if (jsonObj.has(KEY_FAR_ADJ)) {
                sVqeConfig.mFarADJ = jsonObj.getInt(KEY_FAR_ADJ);
            }
            if (jsonObj.has(KEY_NEAR_NS)) {
                sVqeConfig.mNearNs = jsonObj.getInt(KEY_NEAR_NS);
            }
            if (jsonObj.has(KEY_NEAR_ADJ)) {
                sVqeConfig.mNearAdj = jsonObj.getInt(KEY_NEAR_ADJ);
            }
            if (jsonObj.has(KEY_NEAR_VAD)) {
                sVqeConfig.mNearVad = jsonObj.getInt(KEY_NEAR_VAD);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return true;
    }

    public static boolean saveConfig() {
        File configFile = new File(VoIPConfigFilePath);
        FileOutputStream fos = null;
        try {
            JSONObject jsonObj = new JSONObject();
            jsonObj.put(KEY_ENABLE_AEC, sVqeConfig.mEnableAEC);
            jsonObj.put(KEY_MIC_TYPE, sVqeConfig.mAudioSource);
            jsonObj.put(KEY_FAR_CACHE_SIZE, sVqeConfig.mFarCacheSizeInMs);
            jsonObj.put(KEY_FAR_ADJ, sVqeConfig.mFarADJ);
            jsonObj.put(KEY_NEAR_NS, sVqeConfig.mNearNs);
            jsonObj.put(KEY_NEAR_ADJ, sVqeConfig.mNearAdj);
            jsonObj.put(KEY_NEAR_VAD, sVqeConfig.mNearVad);
            fos = new FileOutputStream(configFile);
            fos.write(jsonObj.toString().getBytes());
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return true;
    }
}
