package com.qihoo360.homecamera.machine.push.json;

import org.json.JSONException;
import org.json.JSONObject;

public class PushJsonUtil {
	public static String getValueFromJsonStr(String key, String jsonStr)
			throws JSONException {
		JSONObject jsonObject = new JSONObject(jsonStr);
		return jsonObject.getString(key);
	}
}
