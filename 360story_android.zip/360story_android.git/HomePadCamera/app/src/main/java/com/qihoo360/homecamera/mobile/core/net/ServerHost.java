
package com.qihoo360.homecamera.mobile.core.net;

import java.io.Serializable;

public class ServerHost implements Serializable {

    private static final long serialVersionUID = 7797850905459804178L;
    public String host;
    public String iplist;

    @Override
    public String toString() {
        return "[host=" + host + ", iplist=" + iplist + "]";
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getIplist() {
        return iplist;
    }

    public void setIplist(String iplist) {
        this.iplist = iplist;
    }

}
