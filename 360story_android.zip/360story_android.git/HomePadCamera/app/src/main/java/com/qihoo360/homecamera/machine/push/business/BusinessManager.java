package com.qihoo360.homecamera.machine.push.business;

import java.util.HashMap;
import java.util.Map;

import android.content.Context;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import com.qihoo360.homecamera.machine.log.MachineLogTag;
import com.qihoo360.homecamera.machine.push.PushConsts;
import com.qihoo360.homecamera.machine.push.json.ConvertTypeAdapterFactory;
import com.qihoo360.homecamera.mobile.utils.CLog;

/**
 * push 业务管理器
 * @author zhangtao
 *
 */
public class BusinessManager {
	
	private Map<Integer, BusinessBase> mBusinessMap = new HashMap<>();
	
	public BusinessManager() {
		initBusinessMap();
	}

	/**
	 * 初始化业务处理对应关系
	 */
	private void initBusinessMap() {
		mBusinessMap.clear();
		registerBusiness(PushConsts.Type.PUSH_CMD, new CmdBusiness());	// 故事机状态
	}
	
	/**
	 * 注册业务处理
	 * @param type
	 * @param business
	 */
	private void registerBusiness(int type, BusinessBase business) {
		mBusinessMap.put(type, business);
	}

	/**
	 * 处理push内容
	 * @param content
	 */
	public void handlePushContent(String content) {

		if(null == content) {
			return;
		}
		
		// 解析content
		BusinessBean businessBean = null;
		Gson gson = new GsonBuilder().registerTypeAdapterFactory(new ConvertTypeAdapterFactory(BusinessBean.class)).create();
		try {
			businessBean = gson.fromJson(content, BusinessBean.class);
			CLog.e("zt","解析得的data字符串:"+businessBean.getData());
		} catch (JsonSyntaxException e) {
			CLog.e(MachineLogTag.LOG_TAG_MACHINE, "handlePushContent Json 解析失败 " + e);
		}
		if(null == businessBean) {
			return;
		}
		
		// 根据type字段 解析具体业务
		int type = businessBean.getType();
		BusinessBase business = mBusinessMap.get(type);

		CLog.e(MachineLogTag.LOG_TAG_MACHINE, "handlePushContent Json 解析成功 业务type为" + type);

		if(null != business) {
			// 将数据给具体业务处理类去处理
			business.dispose(businessBean);//
		}
	}
}
