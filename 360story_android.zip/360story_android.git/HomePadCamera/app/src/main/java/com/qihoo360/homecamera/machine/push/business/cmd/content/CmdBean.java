package com.qihoo360.homecamera.machine.push.business.cmd.content;

import android.text.TextUtils;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.qihoo360.homecamera.machine.push.json.ConvertType;

/**
 * Created by zhangchao-pd on 2016/11/22.
 */

public class CmdBean extends ContentBase {

    private String cmd;

    @ConvertType(oriType = JsonObject.class)
    private String content;

    public String getCmd() {
        return cmd;
    }

    public void setCmd(String cmd) {
        this.cmd = cmd;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    /**
     * @param tClass 具体业务需要获取的content字段的类
     * @param <T>    具体业务需要获取的content字段的类结构
     * @return 具体业务需要获取的content字段的类的实例
     */
    public <T> T getContent(Class<T> tClass) {
        if (TextUtils.isEmpty(content)) {
            return null;
        }
        T object = null;
        try {
            object = new Gson().fromJson(content, tClass);
        } catch (JsonSyntaxException e) {
            e.printStackTrace();
        }
        return object;
    }
}
