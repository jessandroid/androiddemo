package com.qihoo360.homecamera.mobile.entity;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/1/25
 * Time: 18:06
 * To change this template use File | Settings | File Templates.
 */
public class DevieSetting extends Head {
}
