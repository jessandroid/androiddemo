package com.qihoo360.homecamera.machine.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.qihoo360.homecamera.mobile.ui.fragment.BaseFragment;

/**
 * Created by zhangchao-pd on 2016/11/18.
 */

public abstract class MachineBaseFragment extends BaseFragment {

    protected ViewGroup mRootView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mRootView = (ViewGroup) inflater.inflate(getRootViewLayoutId(), container, false);
        return mRootView;
    }

    public abstract int getRootViewLayoutId();

    @Override
    public boolean onTabSwitched() {
        return false;
    }
}
