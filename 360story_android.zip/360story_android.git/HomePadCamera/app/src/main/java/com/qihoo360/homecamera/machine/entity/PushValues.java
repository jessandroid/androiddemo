
package com.qihoo360.homecamera.machine.entity;

import android.annotation.SuppressLint;

import com.google.gson.JsonElement;
import com.qihoo360.homecamera.machine.util.JSONUtils;
import com.qihoo360.homecamera.mobile.entity.Head;

@SuppressLint("ParcelCreator")
public class PushValues extends Head {
    private static final long serialVersionUID = 1L;

    public String command;// 请求命令
    public String key;
    private JsonElement data;

    // 报警信息
    public long eventtime;
    public String snap_url;// 截图地址
    public String thumb_url;// 缩略图
    public String imgKey;
    public int eventShowType;
    public String eventId;
    public String eventUrl;

    public String cloudEvent;
    public String video_url;
    public long starttime;

    // 公众信息
    public int type;
    public String title;
    public String content;
    
    //Radar
    public String sqid;
    public int isOwner;
//    public RadarBean userInfo;
    public Camera ipcInfo;

    public String timezone;

    public int tag_id;
    public String tag_name;
    public String thmb_url;

    // video message
    public String ipc_name;
    public String image_url;
    public long duration;

    public <T> T getData(Class<T> clazz) {
        return JSONUtils.fromJson(clazz, data.toString());
    }

    public String getData() {
        return this.data.toString();
    }
}
