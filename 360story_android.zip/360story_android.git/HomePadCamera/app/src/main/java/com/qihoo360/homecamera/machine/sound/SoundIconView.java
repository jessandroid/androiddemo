package com.qihoo360.homecamera.machine.sound;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PaintFlagsDrawFilter;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Xfermode;
import android.graphics.drawable.BitmapDrawable;
import android.support.v4.view.ViewCompat;
import android.util.AttributeSet;
import android.widget.ImageView;

/**
 * @author chengxiangyu 截取圆形图片
 */
public class SoundIconView extends ImageView {

	private int radius = 0;
	private float angle = 0;
	private boolean isRunning = false;
	private boolean isLayer = false;//是否添加浮层

	private Paint mPaint;
	private Paint mPaintMaskCircle;
	private RectF mBitmapRectF;
	private Xfermode mXfermodeSrcIn;
	private PaintFlagsDrawFilter mPaintFlagsDrawFilter;

	public SoundIconView(Context context) {
		super(context);
		init();
	}

	public SoundIconView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
	}

	public SoundIconView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		init();
	}

	private void init() {
		mPaint = new Paint();
		mPaint.setAntiAlias(true);
		mPaintMaskCircle = new Paint();
		mPaintMaskCircle.setARGB(76, 0, 0, 0);
		this.setScaleType(ScaleType.CENTER_CROP);
		mXfermodeSrcIn = new PorterDuffXfermode(Mode.SRC_IN);
		mPaintFlagsDrawFilter = new PaintFlagsDrawFilter(0, Paint.ANTI_ALIAS_FLAG
				| Paint.FILTER_BITMAP_FLAG);
	}

	public boolean isRunning() {
		return isRunning;
	}

	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
		radius = (getMeasuredWidth() < getMeasuredHeight() ? getMeasuredWidth() : getMeasuredHeight()) / 2;
		mBitmapRectF = new RectF(0, 0, getMeasuredWidth(), getMeasuredHeight());
	}

	@Override
	protected void onDraw(Canvas canvas) {
		if (getDrawable() == null
				|| !(getDrawable() instanceof BitmapDrawable)
				|| ((BitmapDrawable)getDrawable()).getBitmap() == null) {
			super.onDraw(canvas);
			return;
		}
		canvas.setDrawFilter(mPaintFlagsDrawFilter);
		canvas.saveLayer(0, 0, getMeasuredWidth(), getMeasuredHeight(), mPaint, Canvas.ALL_SAVE_FLAG);
		mPaint.setColor(Color.WHITE);
		canvas.drawCircle(getMeasuredWidth() / 2, getMeasuredHeight() / 2, radius, mPaint);
		mPaint.setXfermode(mXfermodeSrcIn);
		canvas.save();
		canvas.rotate(angle, getMeasuredWidth() / 2, getMeasuredHeight() / 2);
		if (getImageMatrix() == null) {
			canvas.drawBitmap(((BitmapDrawable)getDrawable()).getBitmap(), null, mBitmapRectF, mPaint);
		} else {
			canvas.drawBitmap(((BitmapDrawable) getDrawable()).getBitmap(), getImageMatrix(), mPaint);
		}
		canvas.restore();
		canvas.restore();
		mPaint.reset();
		if (isLayer) {
			canvas.drawCircle(getMeasuredWidth() / 2, getMeasuredHeight() / 2, radius, mPaintMaskCircle);
		}
		if(isRunning){
			angle = (angle + 1.5f) % 360f;
			ViewCompat.postInvalidateOnAnimation(this);
		}
	}

	/**
	 * 
	 */
	public void startAni() {
		if(!isRunning){
			isRunning = true;
			postInvalidate();
		}
	}

	public void stopAni() {
		isRunning = false;
		angle = 0;
	}

	/**
	 * @return 是否添加浮层
	 */
	public boolean isLayer() {
		return isLayer;
	}

	/**
	 * @param isLayer 是否添加浮层
	 */
	public void setLayer(boolean isLayer) {
		this.isLayer = isLayer;
	}
}