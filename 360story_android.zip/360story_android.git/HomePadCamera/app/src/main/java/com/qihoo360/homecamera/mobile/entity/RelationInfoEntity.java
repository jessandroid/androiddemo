package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by zhaojunbo on 2016/4/26.
 * desc:
 */
public class RelationInfoEntity implements Parcelable {
    public int relation_tag = 0;
    public String relation_title = "";

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.relation_tag);
        dest.writeString(this.relation_title);
    }

    public RelationInfoEntity(int relationTag, String relationTitle) {
        relation_tag = relationTag;
        relation_title = relationTitle;
    }

    protected RelationInfoEntity(Parcel in) {
        this.relation_tag = in.readInt();
        this.relation_title = in.readString();
    }

    public static final Parcelable.Creator<RelationInfoEntity> CREATOR = new Parcelable.Creator<RelationInfoEntity>() {
        @Override
        public RelationInfoEntity createFromParcel(Parcel source) {
            return new RelationInfoEntity(source);
        }

        @Override
        public RelationInfoEntity[] newArray(int size) {
            return new RelationInfoEntity[size];
        }
    };

    @Override
    public String toString() {
        return String.format("{\"relation_tag\": %1$s,\"relation_title\": \"%2$s\"}", relation_tag, relation_title);
    }
}