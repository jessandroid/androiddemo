
package com.qihoo360.homecamera.mobile.activity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.AnimationDrawable;
import android.media.SoundPool;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.text.method.ScrollingMovementMethod;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.qihoo.pushsdk.utils.LogUtils;
import com.qihoo.sdk.report.QHStatAgent;
import com.qihoo360.homecamera.device.config.StoryMachineConsts;
import com.qihoo360.homecamera.machine.util.DateUtils;
import com.qihoo360.homecamera.machine.util.NetUtil;
import com.qihoo360.homecamera.mobile.ApplicationCamera;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.db.CommonWrapper;
import com.qihoo360.homecamera.mobile.download.CallBack;
import com.qihoo360.homecamera.mobile.download.DownloadException;
import com.qihoo360.homecamera.mobile.download.DownloadManager;
import com.qihoo360.homecamera.mobile.download.DownloadRequest;
import com.qihoo360.homecamera.mobile.entity.Update;
import com.qihoo360.homecamera.mobile.entity.UpdateInfo;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.manager.VersionManager;
import com.qihoo360.homecamera.mobile.model.Splash;
import com.qihoo360.homecamera.mobile.ui.dialog.BaseDialogFactory;
import com.qihoo360.homecamera.mobile.ui.tabview.listener.CustomTabEntity;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.ConstantUtils;
import com.qihoo360.homecamera.mobile.utils.FileUtil;
import com.qihoo360.homecamera.mobile.utils.MD5Util;
import com.qihoo360.homecamera.mobile.utils.Preferences;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.widget.CamAlertDialog;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

/**
 * 闪屏页
 *
 * @author lvpeng-s
 */
public class SplashActivity extends AppCompatActivity implements ActionListener {
    private static final String TAG = "SplashActivity";

    private static final int ACTION_LOGIN = 0;
    private static final int ACTION_MAIN = 1;
    private static final int ACTION_EXIT_SPLASH = 2;
    private int SPLASH_DISPLAY_LENGTH = 1000;

    private static IntentHandler intentHandler;
    private MyHandler handler;
    private ArrayList<CustomTabEntity> mTabEntities = new ArrayList<>();
    private static boolean bNeedSwitch = false;    // 需要跳转到小视频页面

    private AnimationDrawable rocketAnimation;
    private SoundPool soundPool;
    private int soundId;
    private boolean flag;
    private Button n;

    public CamAlertDialog camAlertDialog;
    private DownloadManager downloadManager;
    private CamAlertDialog progressDialog;
    private ProgressBar progressBar;
    private TextView cancleLoad;
    private TextView updateTip;
    private String sid;
    private String loginedSession;
    private boolean hasDownload = false;
    private TextView progress;
    private Timer timer;
    private TimerTask timerTask;
    private int progresssb = 0;
    private BaseDialogFactory mCommonDialogFactory;
    private boolean mHasTurned = false;

    private ImageView splashBg, defaultImg;
    private FrameLayout skipZone;
    private Splash splash = new Splash();
    private Bitmap bgBmp;
    private int currentDate = -1;
    private final static String SPLASH_URL = "https://kids.360.cn/dispatch?target=160830-promotion5&from=360jqr";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        hideBottomUIMenu();
        setContentView(R.layout.splashscreen);
        CLog.startTimer("test");
        if (!isTaskRoot()) {
            finish();
            return;
        }
        handler = new MyHandler(this);
        sid = AccUtil.getInstance().getQID();
        loginedSession = AccUtil.getInstance().getLoginSuccessSessionId();
        if (!TextUtils.isEmpty(sid) && !TextUtils.isEmpty(loginedSession)) {
            GlobalManager.getInstance().initDatabase();
            splash = CommonWrapper.getInstance(this).readSplashData();
        }

        intentHandler = new IntentHandler(this);

        init();
        GlobalManager.getInstance().getCommonManager().registerActionListener(this);
        //检查更新
        intentHandler.sendEmptyMessageDelayed(ACTION_EXIT_SPLASH, 3000);
        handler.sendEmptyMessageDelayed(ACTION_LOGIN, SPLASH_DISPLAY_LENGTH * 3);
        new Thread(new Runnable() {
            @Override
            public void run() {
                checkUpdate();
            }
        }).start();
        CLog.d("test---" + CLog.endTimer("test"));
        FileUtil.clearCache(FileUtil.getInstance().getErrorLog().getAbsolutePath());
        FileUtil.clearCache(LogUtils.getLogPath());
    }

    private boolean mHasJumpUrl = false;
//    private final static int REQUEST_CODE_SPLASH_URL = 1001;
//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//
//        CLog.e(TAG,"---onActivityResult-------requestCode = " + requestCode);
//
//        if (requestCode == REQUEST_CODE_SPLASH_URL){
//            if (mHasJumpUrl){
//                intentHandler.sendEmptyMessage(ACTION_MAIN);
//            }
//        }
//    }

    private void init() {
        splashBg = (ImageView) findViewById(R.id.splash_bg);
        progress = (TextView) findViewById(R.id.progress);

        CLog.e(TAG,"---init-------time = " + System.currentTimeMillis());
        defaultImg = (ImageView) findViewById(R.id.tes);
        setBackgroundForSplash();
        setSplashListener();
        skipZone = (FrameLayout) findViewById(R.id.skip_zone);
        if (!TextUtils.isEmpty(splash.getEndDate()) && !TextUtils.isEmpty(splash.getFromDate())) {
            splashBg.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {
                        CLog.e(TAG,"---splashBg onClick-------time = " + System.currentTimeMillis());
                        if (!TextUtils.isEmpty(splash.getDestinationUrl())) {

                            mHasJumpUrl = true;

                            //不跳mainactivity
                            removeMsg();

                            handler.removeMessages(0);
                            Intent intent = new Intent(Intent.ACTION_VIEW);
                            Uri content_url = Uri.parse(splash.getDestinationUrl());
                            intent.setData(content_url);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        CameraToast.showToast(SplashActivity.this, R.string.web_browser_failed);
                    }
                }
            });
        }

        skipZone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                handler.removeMessages(ACTION_LOGIN);
                handler.sendEmptyMessage(ACTION_LOGIN);
            }
        });

        if (Preferences.getSplashPreference()) {
            if (splash == null || TextUtils.isEmpty(splash.getIamgeLocal())) {
                defaultSplahShow();
            } else {
                int splashShowCount = splash.getSplashShowCount();
                CommonWrapper.getInstance(this).setSplashShowCount(splash.getImageServeLocal(), splashShowCount + 1);
                try {
                    handler.sendEmptyMessageDelayed(0, SPLASH_DISPLAY_LENGTH * 3);
                    File f = new File(splash.getIamgeLocal());
                    if (f.exists()) {
                        bgBmp = BitmapFactory.decodeStream(new FileInputStream(new File(splash.getIamgeLocal())));
                        Utils.ensureVisbility(View.VISIBLE, skipZone);
                        Utils.ensureVisbility(View.GONE, defaultImg);
                        if (bgBmp != null) {
                            if (!bgBmp.isRecycled()) {
                                splashBg.setImageBitmap(bgBmp);
                            }
                        }
                    } else {
                        defaultSplahShow();
                    }
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
        } else {
            defaultSplahShow();
        }
    }

    private void setBackgroundForSplash() {
        if (isInSplashDisplayTime()) {
            defaultImg.setBackgroundResource(R.drawable.splash_new);

        } else {
            defaultImg.setBackgroundResource(R.drawable.splash);
        }

    }
    private void setSplashListener(){
        defaultImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isInSplashDisplayTime()&& NetUtil.isNetworkAvailable(SplashActivity.this)){
                    openSplashWebpage(SPLASH_URL);
                }
            }
        });
    }

    private void openSplashWebpage(String splashUrl){
        final Uri uri = Uri.parse(splashUrl);
        final Intent it = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(it);

    }

    private boolean isInSplashDisplayTime(){
        currentDate = DateUtils.getIntDate();
        if (currentDate >= StoryMachineConsts.SPLASH_START_TIME && currentDate <= StoryMachineConsts.SPLASH_END_TIME) {
            return true;
        }else{
            return  false;
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.popup_menu, menu);
        return true;
    }


    //toolbar的开始菜单开关
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    protected void onResume() {
        super.onResume();
        QHStatAgent.onResume(this);
        if (hasDownload) {//下载好了，安装过程去下了
            if (camAlertDialog != null) {
                camAlertDialog.show();
            }
        }

        if (mHasJumpUrl){
            intentHandler.sendEmptyMessage(ACTION_MAIN);
        }

    }

    @Override
    protected void onPause() {
        super.onPause();
        QHStatAgent.onPause(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mCommonDialogFactory != null) {
            mCommonDialogFactory.destory();
            mCommonDialogFactory = null;
        }
        GlobalManager.getInstance().getCommonManager().removeActionListener(this);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            ((ApplicationCamera) getApplication()).setJiaApplicationExit(false);
            handler.removeMessages(ACTION_LOGIN);
            finish();
            return true;
        }
        return false;
    }

    private void defaultSplahShow() {
        Utils.ensureVisbility(View.GONE, skipZone);
        Utils.ensureVisbility(View.VISIBLE, defaultImg);
        handler.sendEmptyMessageDelayed(ACTION_LOGIN, SPLASH_DISPLAY_LENGTH * 1 / 2);
    }


    public static class IntentHandler extends Handler {

        WeakReference<SplashActivity> contextWeakReference;
        SplashActivity activity;

        public IntentHandler(SplashActivity context) {
            if (context != null) {
                contextWeakReference = new WeakReference<SplashActivity>(context);
                activity = contextWeakReference.get();
            } else {
                new Exception("activity  is null");
            }

            String sid = AccUtil.getInstance().getQID();
            String loginedSession = AccUtil.getInstance().getLoginSuccessSessionId();

            if (!TextUtils.isEmpty(sid) && !TextUtils.isEmpty(loginedSession)) {
                GlobalManager.getInstance().getCommonManager().asyncSplash();
            }

        }

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case ACTION_LOGIN: {
                    Intent intent = new Intent(activity, LoginAndRegisterActivity.class);
                    activity.startActivity(intent);
                    activity.finish();
                    break;
                }
                case ACTION_MAIN: {
                    CLog.e(TAG, "---ACTION_MAIN-------time = " + System.currentTimeMillis());
                    if (!TextUtils.isEmpty(AccUtil.getInstance().getQID())) {
                        Intent intent = new Intent(activity, MainActivity.class);
                        if (bNeedSwitch) {
                            intent.putExtra("switch", Boolean.TRUE);
                        }
                        CLog.e("check", "SplashActivity");
                        if (!activity.mHasTurned) {
                            activity.mHasTurned = true;
                            activity.startActivity(intent);
                        }
                        activity.finish();
                    }
                    break;
                }
                case ACTION_EXIT_SPLASH:
                    activity.exitSplash();
                    break;
            }
        }
    }

    private void checkUpdate() {
        if (Utils.isNetworkAvailable(this)) {
            GlobalManager.getInstance().getCommonManager().checkNewVersion(VersionManager.REQUEST_SOURCE_SPLASH);
        } else {
            intentHandler.removeMessages(ACTION_EXIT_SPLASH);
            exitSplash();
        }
    }

    public void showUpdateDailog(final Update update, boolean isIgnored) {
        camAlertDialog = new CamAlertDialog.Builder(SplashActivity.this).create();
        View view = LayoutInflater.from(Utils.context).inflate(R.layout.update_layout, null);
        camAlertDialog.setContentView(view);
        camAlertDialog.setCancelable(false);

        TextView desTextVeiw = (TextView) view.findViewById(R.id.desc);
        TextView updateText = (TextView) view.findViewById(R.id.update_name);
        desTextVeiw.setMovementMethod(new ScrollingMovementMethod());
        updateText.setText(getString(R.string.last_version, update.result.getVersion()));
        desTextVeiw.setText(update.result.getDescription());

        View sure = view.findViewById(R.id.sure);
        View cancel = view.findViewById(R.id.cancel);
        ((TextView) view.findViewById(R.id.negative_btn)).setText("退出应用");

        //下载需要区分wifi和wap网络
        sure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                camAlertDialog.dismiss();
                if (hasDownload) {
                    //下载完了立即安装
                    String path = FileUtil.getInstance().getDownloadFile().getAbsolutePath() + "/" + update.result.getTitle();
                    //进行MD5验证
                    try {
                        if (TextUtils.equals(MD5Util.md5Hex(new File(path)), update.result.getMd5())) {
                            // 写入db todo
                            Intent intent = new Intent();
                            intent.setAction(android.content.Intent.ACTION_VIEW);
                            intent.setDataAndType(Uri.parse("file://" + path), "application/vnd.android.package-archive");
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            Utils.getContext().startActivity(intent);
                        } else {
                            CameraToast.show("安装包已损坏，请到官网下载安装！", Toast.LENGTH_SHORT);
                            ((ApplicationCamera) Utils.context).AppExit();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    if (Utils.isNetworkAvailable(SplashActivity.this)) {
                        if (Utils.isWifi(Utils.context)) {
                            downLoadApk(update);
                        } else {
                            //如果是wap网络，则需要弹窗提示用户继续使用wap网络下载
                            showWapLoad(update);
                        }
                    } else {
                        showLoadDialog();
                        updateTip.setText("下载过程遇到问题");
                    }
                }
            }
        });

        //以后再说
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (update.result.isForce == Update.FORCE_TYPE_FORCE) {
                    camAlertDialog.dismiss();
                    //TODO 退出应用
                    finish();
                } else {
                    intentHandler.sendEmptyMessage(ACTION_EXIT_SPLASH);
                }
            }
        });
        camAlertDialog.show();
    }

    public void downLoadApk(Update update) {
        UpdateInfo info = update.result;
        if (!TextUtils.isEmpty(info.downUrl)) {
            DownloadRequest request = new DownloadRequest.Builder()
                    .setTitle(update.result.getTitle())
                    .setUri(info.downUrl)
                    .setFolder(FileUtil.getInstance().getDownloadFile())
                    .setNeedCookie(false)
                    .build();
            downloadManager = DownloadManager.getInstance();
            downloadManager.download(request, "apk", new DownloadCallback(update));
        } else {
            CameraToast.show("DonwLoad url is null", Toast.LENGTH_SHORT);
        }
    }

    private class DownloadCallback implements CallBack {
        Update update;
        int tmp;

        public DownloadCallback(Update update) {
            this.update = update;
            this.tmp = 0;
        }

        @Override
        public void onStarted() {
            CLog.e("zt", "down onStarted");
            showLoadDialog();
        }

        @Override
        public void onConnecting() {

        }

        @Override
        public void onConnected(long total, boolean isRangeSupport) {

        }

        @Override
        public void onProgress(long finished, long total, int progress) {
            CLog.e("zt", "down progress:" + progress);
            if (progress > 100 || (tmp == progress)) {
                return;
            } else {
                progressBar.setProgress(progress);
                updateTip.setText("正在下载" + progress + "%");
            }
            tmp = progress;
        }

        @Override
        public void onCompleted() {
            hasDownload = true;
            progressDialog.dismiss();
            update.getResult().setLocalpath(FileUtil.getInstance().getDownloadFile().getAbsolutePath() + "/" + update.result.getTitle());
            String path = FileUtil.getInstance().getDownloadFile().getAbsolutePath() + "/" + update.result.getTitle();
            //进行MD5验证
            try {
                if (TextUtils.equals(MD5Util.md5Hex(new File(update.result.getLocalpath())), update.result.getMd5())) {
                    // 写入db todo
                    Intent intent = new Intent();
                    intent.setAction(android.content.Intent.ACTION_VIEW);
                    intent.setDataAndType(Uri.parse("file://" + path), "application/vnd.android.package-archive");
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                } else {
                    CameraToast.show("安装包已损坏，请到官网下载安装！", Toast.LENGTH_SHORT);
                    exitSplash();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

        }

        @Override
        public void onDownloadPaused() {

        }

        @Override
        public void onDownloadCanceled() {

        }

        @Override
        public void onFailed(DownloadException e) {
            CLog.e("error is :" + e.getErrorMessage());
            updateTip.setText("下载过程遇到问题");
        }
    }

    private void showLoadDialog() {
        progressDialog = new CamAlertDialog.Builder(SplashActivity.this).create();
        progressDialog.getWindow().setGravity(Gravity.CENTER);
        View view = LayoutInflater.from(Utils.context).inflate(R.layout.update_item, null);
        progressDialog.setContentView(view);
        progressDialog.setCancelable(false);
        progressBar = (ProgressBar) view.findViewById(R.id.load_progress);
        updateTip = (TextView) view.findViewById(R.id.load_tip);
        cancleLoad = (TextView) view.findViewById(R.id.cancle_load);
        cancleLoad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.dismiss();
                if (downloadManager != null) {
                    downloadManager.cancel("apk");
                }
                SplashActivity.this.finish();
            }
        });
        progressDialog.show();
        progressBar.setProgress(0);
    }

    public void showWapLoad(final Update update) {
        if (!Constants.HAS_SHOW_NET_TIPS) {
            Dialog dialog = showCommonDialog("", getString(R.string.tips_44), getString(R.string.tips_45), getString(R.string.tips_46), "", false, new SplashActivity.ICommonDialog() {
                @Override
                public void onRightButtonClick(boolean isChecked) {
                    Constants.HAS_SHOW_NET_TIPS = true;
                    downLoadApk(update);
                }

                @Override
                public void onLeftButtonClick(boolean isChecked) {
                    if (update.result.isForce == Update.FORCE_TYPE_FORCE) {
                    } else {
                        //TODO 再次弹强制升级的窗
                        showLoadDialog();
                    }
                }

                @Override
                public void onDialogCancel() {
                }
            });
            dialog.setCancelable(false);
        } else {
            downLoadApk(update);
        }


    }

    @Override
    public Object actionPerformed(int actionCode, Object... args) {
        switch (actionCode) {

            case Actions.Common.FORCE_UPDATE: {//需要强制更新
                removeMsg();
                int type = (int) args[1];
                if (type == VersionManager.REQUEST_SOURCE_SPLASH) {
                    showUpdateDailog((Update) args[0], true);
                }
                return Boolean.TRUE;
            }

            case Actions.Common.IS_THE_NEWEST:
            case Actions.Common.GET_UPDATE_FAILED:
            case Actions.Common.UPDATE: {
                removeMsg();
                exitSplash();
                return Boolean.TRUE;
            }
        }
        return null;
    }

    @Override
    public int getProperty() {
        return 0;
    }

    static class MyHandler extends Handler {

        WeakReference<SplashActivity> mHostActivity;

        MyHandler(SplashActivity hostActivity) {
            mHostActivity = new WeakReference<SplashActivity>(hostActivity);
        }

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            SplashActivity hostActivity = mHostActivity.get();
            if (hostActivity != null) {
//                GlobalManager.getInstance().getCommonManager().asyncSplash();
            }
        }
    }

    private void exitSplash() {
        CLog.e(TAG,"---exitSplash-------time = " + System.currentTimeMillis());
        if (TextUtils.isEmpty(sid) || TextUtils.isEmpty(loginedSession)) {
            intentHandler.sendEmptyMessageDelayed(ACTION_LOGIN, ConstantUtils.SPLASH_DURATION_TIME);
        } else {
            intentHandler.sendEmptyMessageDelayed(ACTION_MAIN, ConstantUtils.SPLASH_DURATION_TIME);
            CLog.e(TAG,"---intentHandler.sendEmptyMessageDelayed(ACTION_MAIN-------time = " + System.currentTimeMillis());
        }
    }

    private void removeMsg() {
        CLog.e(TAG,"---removeMsg-------time = " + System.currentTimeMillis());
        intentHandler.removeMessages(ACTION_EXIT_SPLASH);
        intentHandler.removeMessages(ACTION_LOGIN);
        intentHandler.removeMessages(ACTION_MAIN);
    }

    @Override
    public void onBackPressed() {
    }

    public Dialog showCommonDialog(String title, String content, String leftButton, String rightButton, String checkContent, boolean needCheckBox, final ICommonDialog iCommonDialog) {
        if (TextUtils.isEmpty(title)) {
            title = getString(R.string.tips_47);
        }
        if (mCommonDialogFactory != null) {
            mCommonDialogFactory.destory();
            mCommonDialogFactory = null;
        }
        mCommonDialogFactory = new BaseDialogFactory(this, R.layout.remove_device_dialog);
        Dialog mDialog = mCommonDialogFactory.createDialog();
        mCommonDialogFactory.setMarginLeftAndRight(46f);
        mDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {

            @Override
            public void onCancel(DialogInterface dialog) {
                iCommonDialog.onDialogCancel();
                mCommonDialogFactory = null;
            }
        });
        View view = mCommonDialogFactory.getDialogContentView();
        TextView btnOK = (TextView) view.findViewById(R.id.remove_device_dialog_ok);
        RelativeLayout okZone = (RelativeLayout) view.findViewById(R.id.remove_device_dialog_ok_zone);
        TextView btnCancle = (TextView) view.findViewById(R.id.remove_device_dialog_cancel);
        RelativeLayout cancleZone = (RelativeLayout) view.findViewById(R.id.remove_device_dialog_cancel_zone);
        TextView titleTv = (TextView) view.findViewById(R.id.remove_device_dialog_tips);
        TextView contentTv = (TextView) view.findViewById(R.id.remove_device_dialog_content);
        final CheckBox saveDataCb = (CheckBox) view.findViewById(R.id.cb_save_data);
        LinearLayout checkAreaLl = (LinearLayout) view.findViewById(R.id.ll_check_area);
        TextView checkContentTv = (TextView) view.findViewById(R.id.tv_check_content);
        View dividerView = findViewById(R.id.divider);
        if (TextUtils.isEmpty(title)) {
            titleTv.setVisibility(View.GONE);
        } else {
            titleTv.setText(title);
        }
        if (TextUtils.isEmpty(leftButton)) {
            Utils.ensureVisbility(View.GONE, okZone, dividerView);
            cancleZone.setBackgroundResource(R.drawable.pop_win_round_bg_left_right);
        } else {
            btnOK.setText(leftButton);
        }
        contentTv.setText(content);
        btnCancle.setText(rightButton);
        checkContentTv.setText(checkContent);

        checkAreaLl.setVisibility(needCheckBox ? View.VISIBLE : View.GONE);
        btnOK.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                mCommonDialogFactory.destory();
                iCommonDialog.onLeftButtonClick(saveDataCb.isChecked());
            }
        });
        btnCancle.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                mCommonDialogFactory.destory();
                iCommonDialog.onRightButtonClick(saveDataCb.isChecked());
            }
        });
        mCommonDialogFactory.show();
        return mDialog;
    }

    public interface ICommonDialog {
        public void onRightButtonClick(boolean isChecked);

        public void onLeftButtonClick(boolean isChecked);

        public void onDialogCancel();
    }

//    @Override
//    public void setContentView(int layoutResID) {
//        super.setContentView(layoutResID);
//        setStatusBar();
//    }
//
//    protected void setStatusBar() {
//        StatusBarUtil.setColor(this, getResources().getColor(R.color.white));
//    }

    private void hideBottomUIMenu() {
        //隐藏虚拟按键，并且全屏
        if (Build.VERSION.SDK_INT > 11 && Build.VERSION.SDK_INT < 19) { // lower api
            View v = this.getWindow().getDecorView();
            v.setSystemUiVisibility(View.GONE);
        } else if (Build.VERSION.SDK_INT >= 19) {
            //for new api versions.
            View decorView = getWindow().getDecorView();
            int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN;
            decorView.setSystemUiVisibility(uiOptions);
        }
    }
}
