package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by yanggang on 2016/5/12.
 */
public class FriendMessageInfoEntity implements Parcelable {
    public String type;
    public String time;
    public String message;
    public Data data;

    public static class Data implements Parcelable {
        public IpcInfo rqstIpcInfo;
        public IpcInfo rspsIpcInfo;
        public ReqUserInfo rqstUserInfo;

        public static final Parcelable.Creator<Data> CREATOR = new Parcelable.Creator<Data>() {
            @Override
            public Data createFromParcel(Parcel source) {
                return new Data(source);
            }

            @Override
            public Data[] newArray(int size) {
                return new Data[size];
            }
        };

        private Data(Parcel in) {
            rqstIpcInfo = (IpcInfo) in.readValue(IpcInfo.class.getClassLoader());
            rspsIpcInfo = (IpcInfo) in.readValue(IpcInfo.class.getClassLoader());
            rqstUserInfo = (ReqUserInfo) in.readValue(ReqUserInfo.class.getClassLoader());
        }

        @Override
        public void writeToParcel(Parcel out, int flags) {
            out.writeValue(rqstIpcInfo);
            out.writeValue(rspsIpcInfo);
            out.writeValue(rqstUserInfo);
        }

        @Override
        public int describeContents() {
            return 0;
        }
    }

    public static final Parcelable.Creator<FriendMessageInfoEntity> CREATOR = new Parcelable.Creator<FriendMessageInfoEntity>() {
        @Override
        public FriendMessageInfoEntity createFromParcel(Parcel source) {
            return new FriendMessageInfoEntity(source);
        }

        @Override
        public FriendMessageInfoEntity[] newArray(int size) {
            return new FriendMessageInfoEntity[size];
        }
    };

    private FriendMessageInfoEntity(Parcel in) {
        type = in.readString();
        time = in.readString();
        message = in.readString();
        data = (Data) in.readValue(Data.class.getClassLoader());
    }

    @Override
    public void writeToParcel(Parcel out, int flags) {
        out.writeString(type);
        out.writeString(time);
        out.writeString(message);
        out.writeValue(data);
    }

    @Override
    public int describeContents() {
        return 0;
    }
}
