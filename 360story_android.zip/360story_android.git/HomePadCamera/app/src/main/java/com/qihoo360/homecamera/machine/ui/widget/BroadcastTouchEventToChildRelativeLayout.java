package com.qihoo360.homecamera.machine.ui.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.RelativeLayout;

import java.util.ArrayList;

public class BroadcastTouchEventToChildRelativeLayout extends RelativeLayout{

    private ArrayList<OnParentTouchEventListener> listeners = new ArrayList<OnParentTouchEventListener>();

    public BroadcastTouchEventToChildRelativeLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    interface OnParentTouchEventListener {
        void onTouchEvent();
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        judgeEvent(ev);
        return super.onInterceptTouchEvent(ev);
    }

    private void judgeEvent(MotionEvent event) {
        final int action = event.getAction();
        final int actionMasked = action & MotionEvent.ACTION_MASK;
        if (actionMasked == MotionEvent.ACTION_DOWN) {
            broadcastOnTouchDown();
        }
    }

    public void register(OnParentTouchEventListener listener) {
        if (!listeners.contains(listener)) {
            listeners.add(listener);
        }
    }

    public void unregister(OnParentTouchEventListener listener) {
        listeners.remove(listener);
    }

    private void broadcastOnTouchDown() {
        for (OnParentTouchEventListener e : listeners) {
            e.onTouchEvent();
        }
    }
}
