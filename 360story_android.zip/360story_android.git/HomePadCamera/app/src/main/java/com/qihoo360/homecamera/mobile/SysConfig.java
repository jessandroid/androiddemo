
package com.qihoo360.homecamera.mobile;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Point;
import android.graphics.Typeface;
import android.os.Environment;
import android.util.DisplayMetrics;

import com.qihoo360.homecamera.mobile.utils.AndroidUtil;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.io.File;

public class SysConfig {
    public static String CHINESE_LANG = "zh";
    public static String CHINA = "CN";
    public static String APP_STORE_IMEI;
    public static int LOLLIPOP_VERSION_CODE = 20;
    public static String VERSION_NAME = "";
    public static int VERSION_CODE = 0;
    public static String DEV_ID;
    public static File DIR_JIA_DOWNLOAD = new File(Environment.getExternalStorageDirectory().getPath() + "/downloadFile");
    public final static File DIR_JIA_ROOT = new File(Environment.getExternalStorageDirectory(), "360jia");
    public final static File DIR_LOG_PATH = new File(DIR_JIA_ROOT, ".log");
    public static String SDCARD_PATH = Environment.getExternalStorageDirectory().getAbsolutePath()
            + File.separator;

    public static int BASE_SCREEN_WIDTH;
    public static int BASE_SCREEN_HEIGHT;
    public static int limitCacheSize;
    public static float DENSITY;
    public static int DENSITYDPI;

    public static String PHONE_MODEL;
    public static String ANDROID_OS_VER = android.os.Build.VERSION.RELEASE;
    public static String CHANNEL_ID = "channel-default"; //任何人都不要修改这个值。给qa打渠道包专用的字段。

    public final static File CRASH_FILE_PATH = new File(DIR_LOG_PATH, "crash.txt");

    public final static File APP_LOG_PATH = new File(DIR_LOG_PATH, "logcat.txt");
    private static DisplayMetrics dm;

    public static int screenHeight;
    public static int screenWidth;
    public static float density;
    public static int densityDPI;
    public static float xdpi;
    public static float ydpi;

    public static boolean isInitiativeLogin = true;

    private static Context mContext;

    public static boolean isDownloadUdate = false;//是否正在下载升级

    public static void setisInitiativeLogin(boolean stat) {
        isInitiativeLogin = stat;
    }

    public final static void init(Context context) {
        mContext = context;
        VERSION_NAME = AndroidUtil.getVersionName(context);
        VERSION_CODE = AndroidUtil.getVersionCode(context);
        DEV_ID = AndroidUtil.getDeviceId(context);
        PHONE_MODEL = AndroidUtil.getPhoneModel().replace(" ", "");
        APP_STORE_IMEI = Utils.getIMEI2(context);
        updateScreenDimension(context);
    }

    public static Point getScreenMetrics(Context context) {
        DisplayMetrics dm = context.getResources().getDisplayMetrics();
        int w_screen = dm.widthPixels;
        int h_screen = dm.heightPixels;
        return new Point(w_screen, h_screen);

    }

    public static float getScreenRate(Context context) {
        Point P = getScreenMetrics(context);
        float H = P.y;
        float W = P.x;
        return (H / W);
    }

    public final static void updateScreenDimension(Context context) {
        final DisplayMetrics m = context.getResources().getDisplayMetrics();

        Configuration configuration = context.getResources().getConfiguration(); //获取设置的配置信息
        if (configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            BASE_SCREEN_WIDTH = m.heightPixels;
            BASE_SCREEN_HEIGHT = m.widthPixels;
        } else {
            BASE_SCREEN_WIDTH = m.widthPixels;
            BASE_SCREEN_HEIGHT = m.heightPixels;
        }

        DENSITY = m.density;
        DENSITYDPI = m.densityDpi;
    }

    public static void getDisplayWidthAndHeight(Activity context) {
        screenHeight = 0;
        screenWidth = 0;
        density = 0;
        densityDPI = 0;
        xdpi = 0;
        ydpi = 0;
        dm = new DisplayMetrics();
        context.getWindowManager().getDefaultDisplay().getMetrics(dm);

        density = dm.density; // 屏幕密度（像素比例：0.75/1.0/1.5/2.0）
        densityDPI = dm.densityDpi; // 屏幕密度（每寸像素：120/160/240/320）
        xdpi = dm.xdpi;
        ydpi = dm.ydpi;

        if (density < 1.5) {
            screenWidth = (int) (dm.widthPixels * density + 0.5f); // 屏幕宽（px，如：480px）
            screenHeight = (int) (dm.heightPixels * density + 0.5f); // 屏幕高（px，如：800px）
        } else if (density >= 1.5) {
            screenWidth = (int) (dm.widthPixels / 1.5 + 0.5f); // 屏幕宽（px，如：480px）
            screenHeight = (int) (dm.heightPixels / 1.5 + 0.5f); // 屏幕高（px，如：800px）
        } else {
            screenWidth = dm.widthPixels; // 屏幕宽（像素，如：480px）
            screenHeight = dm.heightPixels; //
        }
        CLog.e(" DisplayMetrics", "screenWidth=" + screenWidth + "; screenHeight=" + screenHeight);

    }

    private static Typeface globalFont = null;

    public static Typeface GetGlobalFont() {
        if (globalFont == null) {
            globalFont = Typeface.createFromAsset(mContext.getAssets(), "fonts/ltxh.ttf");
        }
        return globalFont;
    }
}
