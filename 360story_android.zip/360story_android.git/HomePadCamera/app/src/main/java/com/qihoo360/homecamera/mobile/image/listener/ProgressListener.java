package com.qihoo360.homecamera.mobile.image.listener;

/**
 * tom
 */
public interface ProgressListener {
    void update(long bytesRead, long contentLength, boolean done);
}