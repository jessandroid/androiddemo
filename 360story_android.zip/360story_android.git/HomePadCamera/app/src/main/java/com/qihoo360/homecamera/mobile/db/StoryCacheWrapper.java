package com.qihoo360.homecamera.mobile.db;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

import com.google.gson.Gson;
import com.qihoo360.homecamera.mobile.entity.Story;
import com.qihoo360.homecamera.mobile.entity.StoryList;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;

import java.util.List;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/3/31
 * Time: 10:21
 * To change this template use File | Settings | File Templates.
 */
public class StoryCacheWrapper extends AbstractWrapper {


    private static StoryCacheWrapper storyCacheWrapper;
    private static final String TABLE_NAME = "story_cache";

    private StoryCacheWrapper() {

    }

    public synchronized static StoryCacheWrapper getInstance() {
        if (storyCacheWrapper == null) {
            storyCacheWrapper = new StoryCacheWrapper();
        }
        return storyCacheWrapper;
    }


    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int toVersion) {
        switch (toVersion) {
            case 2:
                break;
            default:
                break;
        }
    }

    @Override
    public void onOpen(SQLiteDatabase db) {

    }


    // FIXME: 2016/3/22 写入数据库
    public synchronized void write(List<Story> list, String sn, int title) {
        SQLiteDatabase db = GlobalManager.getInstance().config().db.getWritableDatabase();
        StoryList storyList = new StoryList();
        storyList.data = list;
        ContentValues values = new ContentValues();
        values.put(Field.KEY_SN, sn);
        values.put(Field.KEY_ITME, title);
        values.put(Field.C, storyList.toJson());
        try {
            if (exist(title)) {
                db.delete(TABLE_NAME,Field.KEY_ITME + "= ?", new String[]{String.valueOf(title)});
            }
            db.insert(TABLE_NAME, null, values);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private boolean exist(int code) throws Exception {
        boolean exist = false;
        if (code < 0) {
            throw new Exception("sn or code is null");
        }
        long queryRes = queryQidCount(code);
        if (queryRes > 0) {
            exist = true;
        }
        return exist;
    }


    public Long queryQidCount(int title) {
        SQLiteDatabase db = GlobalManager.getInstance().config().db.getWritableDatabase();
        long count = 0;
        StringBuffer sb = new StringBuffer("");
        sb.append("select count(_id) from ");
        sb.append(TABLE_NAME);
        sb.append(" where " + Field.KEY_ITME + " =" + title + "");
        try {
            SQLiteStatement statement = db.compileStatement(sb.toString());
            count = statement.simpleQueryForLong();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }
        return count;
    }

    /**
     * read cache
     *
     * @param title
     * @return
     */

    public List<Story> getStoryCache(int title) {
        SQLiteDatabase db = GlobalManager.getInstance().config().db.getReadableDatabase();
        StoryList storyList = new StoryList();
        Cursor cursor = null;
        Gson gson = new Gson();
        try {
            cursor = db.query(TABLE_NAME, null, Field.KEY_ITME + " = ?", new String[]{String.valueOf(title)}, null, null, null);
            while (cursor.moveToNext()) {
                String arg_1 = cursor.getString(cursor.getColumnIndex(Field.C));
                storyList = gson.fromJson(arg_1, StoryList.class);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return storyList.data;
    }


    public class Field {
        public static final String KEY_ID = "_id";
        public static final String KEY_ITME = "item";
        public static final String KEY_SN = "sn";
        public static final String C = "c";
        public static final String D = "d";
        public static final String E = "e";
        public static final String F = "f";
    }
}
