package com.qihoo360.homecamera.machine.config;

import com.qihoo360.homecamera.mobile.BuildConfig;

/**
 * 故事机统一配置
 * Created by zhangchao-pd on 2016/11/9.
 */

public class MachineDefaultClientConfig {
    // url 信息---------------------------------------------
    public static final String APP_SERVER_DOMAIN_DEFAULT = "https://q.kibot.360.cn";
    public static final String APP_SERVER_DOMAIN_TEST ="https://10.108.213.193"; // 新测试环境ip

    public static final String APP_SERVER_DOMAIN_HTTP_DEFAULT = "http://q.kibot.360.cn"; // 线上
    public static final String APP_SERVER_DOMAIN_HTTP_TEST ="http://10.108.213.193"; // 新测试环境ip

    public static String APP_SERVER_DOMAIN; // HTTPS线上
    public static String APP_SERVER_DOMAIN_HTTP; // HTTP

    static {
        if (BuildConfig.isDebug) {
            APP_SERVER_DOMAIN = APP_SERVER_DOMAIN_TEST;
        } else {
            APP_SERVER_DOMAIN = APP_SERVER_DOMAIN_DEFAULT;
        }
    }

    static {
        if (BuildConfig.isDebug) {
            APP_SERVER_DOMAIN_HTTP = APP_SERVER_DOMAIN_HTTP_TEST;
        } else {
            APP_SERVER_DOMAIN_HTTP = APP_SERVER_DOMAIN_HTTP_DEFAULT;
        }
    }

    /**
     * httpclient相关配置
     */
    public static final String DEFAULT_CLIENT_VERSION = "com.qihoo.storymachine";
    public static final String CLIENT_VERSION_HEADER = "User-Agent";
    public static final String HOST = "q.kibot.360.cn";
    public static final int TIMEOUT = 30;

    // 业务来源
    public static final String FROM = "mpc_360story_and";

    public static final String ACTION_COMMON_GLOBAL = "com.qihoo.jia.ACTION_COMMON_GLOBAL";

    // 服务器接口
    public static final String APP_LOGIN_URL = "/login/login"; // 登录
    public static final String APP_GETLIST_URL = "/app/getList"; // 获取设备列表
    public static final String APP_BIND = "/bind/bind"; // 绑定
    public static final String UN_BIND_DEVICE_URL = "/bind/unbind"; // 解绑
    public static final String STREAM_PLAY = "/stream/play"; // 请求流服务器地址
    public static final String STREAM_STOP = "/stream/stop"; //终止实时视频流

    public static final String APP_UPDATE_INFO_URL = "/app/updateInfo";
    public static final String APP_GET_INFO_URL = "/app/getInfo";
    public static final String SHARE_GET_LIST_URL = "/share/getList";
    public static final String SHARE_SHARE_URL = "/share/share";
	public static final String LOCAL_SETTING_URL = "/app/command";
	// 播放
    public static final String APP_PLAY = "/app/play";// 播放
    public static final String APP_PLAY_V2 = "/app/playV2";
    public static final String APP_CMD_SEND = "/cmd/appSend"; // 手机端发送指令
    public static final String APP_GETALBUM = "/app/getAlbum"; // 获取专辑信息

    public static final String URL_APP_CMD = "/app/cmd";

    // 播放公共摄像头
    public static final String URL_PUBLIC_GET_INFO_AND_PLAY = "/public/getInfoAndPlay";
    public static final String URL_PUBLIC_GET_INFO_AND_PLAY_V2 = "/public/getInfoAndPlayV2";

    public static final String APP_URL_GET_ALBUM_LIST = "http://kibot.360.cn/storyMaster/album/%s/%d.json";//%s专辑unique  %d翻页信息

    public static final String APP_URL_GET_BANNER_LIST = "http://kibot.360.cn/data/bind-carousel.json";//获取绑定轮播图


    //TODO 替换
    public static String CHILD_URL = "http://jia.360.cn/child/list.json";

    public static final String[] COMMAND = {
            "light", "sound", "resolution", "getInfo", "online",
            "offline", "check", "inversion", "mute", "moving", "overline", "upgrade", "face", "ir", "", "poweroff", "moving", "timezone","wakeup",
            "noise","cry", "fullscreen", "combine", "huajiao"
    };

    public static final int CMD_SETTING_RESOLUTION = 2;
}
