package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by zhaojunbo on 2016/2/16.
 * desc:
 */
public class ShareGetSharingEntity {


    /**
     * 用户id
     */
    public String qid;
    /**
     * 分享方式
     */
    public int type;
    /**
     * 手机号
     */
    public String phone;
    /**
     * 分享码
     */
    public String code;
    /**
     * 过期时间
     */
    public String expire;

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        out.writeString(qid);
        out.writeInt(type);
        out.writeString(phone);
        out.writeString(code);
        out.writeString(expire);
    }

    public static final Parcelable.Creator<ShareGetSharingEntity> CREATOR = new Parcelable.Creator<ShareGetSharingEntity>() {
        @Override
        public ShareGetSharingEntity createFromParcel(Parcel source) {
            return new ShareGetSharingEntity(source);
        }

        @Override
        public ShareGetSharingEntity[] newArray(int size) {
            return new ShareGetSharingEntity[size];
        }
    };

    private ShareGetSharingEntity(Parcel in) {
        qid = in.readString();
        type = in.readInt();
        phone = in.readString();
        code = in.readString();
        expire = in.readString();
    }

}
