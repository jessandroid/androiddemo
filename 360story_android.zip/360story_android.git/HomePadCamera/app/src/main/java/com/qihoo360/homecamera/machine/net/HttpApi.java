
package com.qihoo360.homecamera.machine.net;

import android.content.Context;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.config.Const;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.entity.Head;
import com.qihoo360.homecamera.mobile.exception.CameraAesException;
import com.qihoo360.homecamera.mobile.exception.CameraException;
import com.qihoo360.homecamera.mobile.http.OkHttpUtils;
import com.qihoo360.homecamera.mobile.http.builder.GetBuilder;
import com.qihoo360.homecamera.mobile.http.builder.PostStringBuilder;
import com.qihoo360.homecamera.mobile.http.request.RequestCall;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.Utils;

import org.apache.http.NameValuePair;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.protocol.HTTP;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.CookieHandler;
import java.net.CookiePolicy;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import javax.net.ssl.SSLException;

import static com.qihoo360.homecamera.machine.util.JSONUtils.gson;

@SuppressWarnings("deprecation")
public class HttpApi implements AbstractHttpApi {

    protected String mClientVersion;
    protected AccUtil mAccUtil;
    private boolean auth;

    private static long TIME_OUT = 15 * 1000; // 等待推送15秒
    private static ConcurrentHashMap<String, Head> requestMap = new ConcurrentHashMap<String, Head>();

    /**
     * @param Auth 是否用https请求
     * @throws Exception
     */
    public HttpApi(boolean Auth, String clientVersion) throws Exception {
        this.auth = Auth;
        this.mClientVersion = clientVersion;
        this.mAccUtil = AccUtil.getInstance();
        loadOkHttp();
    }

    public static void loadOkHttp() {
        java.net.CookieManager cookieManager = new java.net.CookieManager();
        cookieManager.setCookiePolicy(CookiePolicy.ACCEPT_ALL);
        CookieHandler.setDefault(cookieManager);
        CLog.d("loadOkHttp");
    }

    public static void pushArrived(Head pushValue) {
        String taskid = pushValue.taskid;
        if (TextUtils.isEmpty(taskid)) {
            CLog.d("push.taskid is null");
            return;
        }

        if (requestMap.containsKey(taskid)) {
            CLog.d(taskid + "开始put..");
            requestMap.put(taskid, pushValue);
            CLog.d(taskid + "put进去了..");
        } else {
            CLog.d(taskid + "过期推送...");
        }
    }

    @Override
    public HttpGet createHttpGet(String url, NameValuePair... nameValuePairs)
            throws CameraException {
        return null;
    }

    protected void processHeader(HttpPost httpPost) {
        // empty
    }

    @Override
    public HttpPost createHttpPost(String url, JSONObject params, boolean cookie)
            throws JSONException, CameraAesException {
        HttpPost httpPost = new HttpPost(url);
        processHeader(httpPost);

        httpPost.addHeader(Const.CLIENT_VERSION_HEADER, mClientVersion);
        if (params.has("Goto")) {
            String internalip = params.getString("Goto");
            if (internalip != null && !internalip.equals("")) {
                if (Const.DEBUG) {
                    httpPost.addHeader("Goto", internalip);
                }
            }
            params.remove("Goto");
        }
        if (cookie) {
            StringBuffer cookies = new StringBuffer();
            cookies.append("q").append("=").append(mAccUtil.getQ()).append(";");
            cookies.append("t").append("=").append(mAccUtil.getT()).append(";");
            cookies.append("qid").append("=").append(mAccUtil.getQID()).append(";");
            cookies.append("lang").append("=").append(Locale.getDefault().toString()).append(";");
            try {
                if (!TextUtils.isEmpty(mAccUtil.getSessionId())) {
                    cookies.append("sid").append("=")
                            .append(URLEncoder.encode(mAccUtil.getSessionId(), HTTP.UTF_8))
                            .append(";");
                }
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                CLog.d("--------------->");
            }
            httpPost.addHeader("cookie", cookies.toString());
            CLog.d("the COOKIES IS : " + cookies.toString());
        }
        String wifiName = "NONE";
        if (Const.DEBUG) {
            try {
                WifiManager wifiManager = (WifiManager) Utils.getContext().getSystemService(Context.WIFI_SERVICE);
                WifiInfo wifiInfo = wifiManager.getConnectionInfo();
                wifiName = (wifiInfo != null ? wifiInfo.getSSID() : "NONE");
            } catch (Exception e) {
                // empty
            }
        }
        JSONObject eparams = new JSONObject();
        eparams.put("parad", params.toString());
        eparams.put("from", Const.FROM);
        CLog.d("http Request: url=" + url + "  params=" + eparams.toString() + ", wifi name:" + wifiName);
        if (params != null) {
            StringEntity strentity = new StringEntity(eparams.toString(), HTTP.UTF_8);
            strentity.setContentType("application/json");
            strentity.setContentEncoding(HTTP.UTF_8);
            if (params.length() > 0) {
                httpPost.setEntity(strentity);
            }
        }
        return httpPost;
    }

    @Override
    public HttpURLConnection createHttpURLConnectionPost(URL url, String boundary) throws IOException {
        return null;
    }

    public <T extends Head> T executeHttpGetRequest(String url, Class<? extends T> clazz)
            throws InstantiationException, IllegalAccessException {

        GetBuilder pb = OkHttpUtils.get()
                .url(url);

        RequestCall request = pb.build();
        Gson gson = new Gson();
        String response = request.execute();
        return gson.fromJson(response, clazz);

    }

    public <T extends Head> T executeHttpRequest(String url, JSONObject params, Class<? extends T> clazz)
            throws InstantiationException, IllegalAccessException {
        StringBuffer cookies = new StringBuffer();
        if (auth) {
            cookies.append("q").append("=").append(AccUtil.getInstance().getQ()).append(";");
            cookies.append("t").append("=").append(AccUtil.getInstance().getT()).append(";");
            cookies.append("qid").append("=").append(AccUtil.getInstance().getQID()).append(";");
            cookies.append("lang").append("=").append(Locale.getDefault().toString()).append(";");
            try {
                if (!TextUtils.isEmpty(AccUtil.getInstance().getSessionId())) {
                    cookies.append("sid").append("=").append(URLEncoder.encode(AccUtil.getInstance()
                            .getSessionId(), "UTF-8"));
//                                .append(";");
                }
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                CLog.e("UnsupportedEncodingException");
            }
        }

        PostStringBuilder pb = OkHttpUtils.postString()
                .content(params.toString())
                .addHeader("cookie", cookies.toString())
                .addHeader(Const.CLIENT_VERSION_HEADER, mClientVersion)
                .url(url);
        if (!auth) {
            pb.withOutCookie();
        }
        RequestCall request = pb.build();
        String response = request.execute();

        return gson.fromJson(response, clazz);
    }

    /**
     * 异步请求
     *
     * @param url    请求地址
     * @param params 请求参数
     * @param clazz  bean.class
     * @return bean对象
     * @throws CameraAesException
     * @throws JSONException
     */
    @SuppressWarnings("unchecked")
    public <T extends Head> T executeAysnHttpRequest(String url, JSONObject params,
            Class<? extends T> clazz, boolean cookie) throws CameraAesException, JSONException,
            InstantiationException, IllegalAccessException {
        String taskid = "";
        if (params.has("taskid") == false) {
            taskid = UUID.randomUUID().toString();
            params.put("taskid", taskid);
        } else {
            taskid = params.getString("taskid");
        }

        HttpPost httpPost = createHttpPost(url, params, cookie);
        T head = clazz.newInstance();
        requestMap.put(taskid, head);

        String sn = null;
        if (params.has("sn")) {
            sn = params.getString("sn");
        }
        head = executeHttpRequest(url, params, clazz);

        if (head.getErrorCode() != Constants.Http.ERROR_CODE_SUCCEED) {

            if (requestMap.get(taskid).taskid == null) {
                CLog.d(taskid + "请求失败  " + " ErrorCode " + head.getErrorCode());
                requestMap.remove(taskid);
                return head;
            } else {
                CLog.d(taskid + "推送已经到达 ");
                head = (T) requestMap.get(taskid);
                head.setStatusCode(200);
                requestMap.remove(taskid);
                return head;
            }
        } else {
            CLog.d(taskid + "请求成功...等推送  ");
            long timestamp = System.currentTimeMillis();
            // 记超时
            while (requestMap.get(taskid).taskid == null
                    && (System.currentTimeMillis() - timestamp) < TIME_OUT) {
                try {
                    Thread.sleep(300);
                } catch (Exception e) {
                    // empty
                }
            }
            if (requestMap.get(taskid).taskid != null) {
                CLog.d(taskid + "推送到达 ");
                head = (T) requestMap.get(taskid);
                head.setStatusCode(200);
                requestMap.remove(taskid);
                return head;
            } else {
                CLog.d(taskid + "等推送超时 ");
                head = clazz.newInstance();
                head.setStatusCode(408);
                head.taskid = taskid;
                requestMap.remove(taskid);
                head.setErrorCode(Constants.Http.ERROR_CODE_PUSH_OVERTIME);
                head.setErrorMsg(Utils.getString(R.string.http_timeout));
                // TODO
                // LogUtil.getInstance().setTimestamp(taskid, LogUtil.TYPE2,
                // LogUtil.T3, System.currentTimeMillis());
                return head;
            }
        }
    }

    public int getExceptionCode(Exception e) {
        if (e instanceof JSONException) {
            return Constants.Http.ERROR_CODE_JSON;
        } else if (e instanceof UnsupportedEncodingException) {
            return Constants.Http.ERROR_CODE_ENCODING;
        } else if (e instanceof SSLException) {
            return Constants.Http.ERROR_CODE_SSL_HANDS;
        } else if (e instanceof IOException) {
            return Constants.Http.ERROR_CODE_IO;
        } else if (e instanceof CameraAesException) {
            return Constants.Http.ERROR_CODE_DES;
        } else if (e instanceof IllegalStateException) {
            if (Utils.isWapNetwork(Utils.getContext())) {
                return Constants.Http.ERROR_CODE_NET_WAP;
            }
            return Constants.Http.ERROR_CODE_ILLEGAL;
        }
        return -1;
    }

    public String executeHttpRequest4ReturnJson(String url) {
        return executeHttpRequest4ReturnJson(url, false);
    }

    public String executeHttpRequest4ReturnJson(String url, boolean withOKStatusCode) {
        return OkHttpUtils.get().url(url).build().execute();

    }
}
