package com.qihoo360.homecamera.mobile.entity;

import android.annotation.SuppressLint;

import java.util.ArrayList;

/**
 * Created by wangshiyuan on 2016/4/29.
 */
@SuppressLint("ParcelCreator")
public class SpaceInfoList extends Head {

    public ArrayList<SpaceInfo> data;

    public static class SpaceInfo {
        public final static String SPACE_INFO_TOTAL = "0";
        public final static String SPACE_INFO_TIME_HOUSE = "1";
        public final static String SPACE_INFO_RECORD_STORY = "3";

        public String stype;
        public long used;
        public int num;
        public int status;
    }
}
