package com.qihoo360.homecamera.machine.entity;

import android.os.Parcel;
import android.os.Parcelable;

import com.qihoo360.homecamera.mobile.core.manager.util.ActionPublisherBase;

/**
 * 故事机单曲实体类
 * Created by zhangchao-pd on 2016/11/18.
 */
public class MachinePlaySingle implements Parcelable {

    private SongEntity mediaInfo;//正在播放儿歌或者故事的信息

    private String unique;//所属专辑的unique

    private int pageId;  //属于专辑列表的第几页

    private String status;//播放状态  play表示播放新的歌曲，pause表示暂停，resume表示继续

    public SongEntity getMediaInfo() {
        return mediaInfo;
    }

    public void setMediaInfo(SongEntity mediaInfo) {
        this.mediaInfo = mediaInfo;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getPageId() {
        return pageId;
    }

    public void setPageId(int pageId) {
        this.pageId = pageId;
    }

    public String getUnique() {
        return unique;
    }

    public void setUnique(String unique) {
        this.unique = unique;
    }

    public MachinePlaySingle() {
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(this.mediaInfo, flags);
        dest.writeString(this.unique);
        dest.writeInt(this.pageId);
        dest.writeString(this.status);
    }

    protected MachinePlaySingle(Parcel in) {
        this.mediaInfo = in.readParcelable(SongEntity.class.getClassLoader());
        this.unique = in.readString();
        this.pageId = in.readInt();
        this.status = in.readString();
    }

    public static final Creator<MachinePlaySingle> CREATOR = new Creator<MachinePlaySingle>() {
        @Override
        public MachinePlaySingle createFromParcel(Parcel source) {
            return new MachinePlaySingle(source);
        }

        @Override
        public MachinePlaySingle[] newArray(int size) {
            return new MachinePlaySingle[size];
        }
    };
}
