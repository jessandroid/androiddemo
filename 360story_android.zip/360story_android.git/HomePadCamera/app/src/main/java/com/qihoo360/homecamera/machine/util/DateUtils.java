package com.qihoo360.homecamera.machine.util;

import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.Preferences;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * HomePadCamera
 * Description: 时间转换工具类
 * Created by liujunbin
 * on 2017/6/6.
 */

public class DateUtils {


    /**
     * 调用此方法输入所要转换的时间戳输入例如（1402733340）输出（"20140614"）
     *
     * @param time
     * @return
     */
    public static String getDate(String time) {
        SimpleDateFormat sdr = new SimpleDateFormat("yyyyMMdd");
        @SuppressWarnings("unused")
        long i = Long.parseLong(time);
        String times = sdr.format(new Date(i));
//        CLog.e("Mars","1_getDate: "+times);
        CLog.e("zt","1_getDate: "+times);
        return times;

    }

    /**
     * 返回int类型的日期
     *
     * @param time
     * @return
     */
    public static int getIntDate(String time) {
        String times = getDate(time);
        return Integer.valueOf(times);

    }

    /**
     * 返回int类型的日期
     *
     * @return
     */
    public static int getIntDate() {
        String time = System.currentTimeMillis() +"";
        String times = getDate(time);
        return Integer.valueOf(times);

    }



    public static boolean isDifferentDay(String time) {
        boolean isDifferent = false;
//        int date1 = getIntDate(time);
//        int date2 = getIntDate(Preferences.getLastNotificationShowTime()+"");
//        if (date1 > date2){
//            isDifferent = true;
//        }
        if (getIntDate(time) > getIntDate(Preferences.getLastNotificationShowTime() + "")) {
//            CLog.e("Mars","01_isDifferentDay_time: "+getIntDate(time));
//            CLog.e("Mars","02_isDifferentDay_getLastNotificationShowTime: " + getIntDate(Preferences.getLastNotificationShowTime()+""));

            isDifferent = true;
        }
        return isDifferent;
    }

    public static boolean isSameDay(String time) {
        boolean isSame = false;
        String longData = Preferences.getLastNotificationShowTime() + "";
        if (getIntDate(time) == getIntDate(longData)) {
            isSame = true;
        }
        return isSame;
    }

    public static String getDateString() {
        Date date = new Date();
        return Utils.DATE_FORMAT_5.format(date);
    }

    public static String getCurrentTime() {

        return Utils.DATE_FORMAT_3.format(new Date());

    }

    public static String getDatePoor(Date startDate, Date endDate) {

        long nd = 1000 * 24 * 60 * 60;
        long nh = 1000 * 60 * 60;
        long nm = 1000 * 60;
        // long ns = 1000;
        // 获得两个时间的毫秒时间差异
        long diff = endDate.getTime() - startDate.getTime();
        // 计算差多少天
        long day = diff / nd;
        // 计算差多少小时
        long hour = diff % nd / nh;
        // 计算差多少分钟
        long min = diff % nd % nh / nm;
        // 计算差多少秒//输出结果
        // long sec = diff % nd % nh % nm / ns;
        return day + "天" + hour + "小时" + min + "分钟";
    }

    public static Date stringToDate(String str) {
        DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = null;
        try {
            date = format.parse(str);
            date = java.sql.Date.valueOf(str);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date;
    }


}
