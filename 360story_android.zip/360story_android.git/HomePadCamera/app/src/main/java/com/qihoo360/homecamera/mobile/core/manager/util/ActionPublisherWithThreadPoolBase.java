
package com.qihoo360.homecamera.mobile.core.manager.util;


import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.workpool.AsyncJob;
import com.qihoo360.homecamera.mobile.core.manager.workpool.NamedThreadPool;
import com.qihoo360.homecamera.mobile.core.util.ManagedRuntimeException;

public abstract class ActionPublisherWithThreadPoolBase extends ActionPublisherBase {
    protected NamedThreadPool mThreadPool;

    public ActionPublisherWithThreadPoolBase() {
        mThreadPool = NamedThreadPool.getInstance();
    }

    public void submitAsyncJob(String poolName, String jobName, Object... args) {
        if (isStopped() == true) {
            return;
        }
        mThreadPool.submit(poolName, new NamedAsyncJob(jobName, args));
    }

    protected abstract void asyncDoNamedJob(String jobName, Object... args);

    public class NamedAsyncJob extends AsyncJob {
        private final String name;

        public NamedAsyncJob(String name, Object... args) {
            super(args);
            this.name = name;
        }

        @Override
        public void asyncRun(Object[] args) {
            if (isStopped() == true) {
                //TODO: think about this, may have delayes
                return;
            }
            try {
                asyncDoNamedJob(name, args);
            } catch (ManagedRuntimeException e) {
                publishAction(Actions.Misc.MANAGED_EXCEPTION, e, name, args);
            }
        }
    }

    @Override
    public void destroyNow() {
        super.destroyNow();
        mThreadPool = null;
    }
}
