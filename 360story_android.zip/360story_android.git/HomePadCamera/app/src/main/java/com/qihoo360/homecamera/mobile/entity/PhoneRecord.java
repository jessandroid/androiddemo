package com.qihoo360.homecamera.mobile.entity;

/**
 * Created by zhaojunbo on 2016/5/3.
 * desc:
 */
public class PhoneRecord {

    public String ID;
    public String SN;
    public String QID;
    public String START_CALL_TIME;
    public String START_CONNECT_TIME;
    public String END_TIME;
    public String INITIATIVE_TERMED;
    public String IS_OUT_GOING;
    public String IS_PROEDSSED;

    @Override
    public String toString() {
        return "ID:" + ID + ",SN:" + SN + ",QID:"  + QID + ",START_CALL_TIME:"  + START_CALL_TIME + ",START_CONNECT_TIME:"  + START_CONNECT_TIME
                + ",END_TIME:"  + END_TIME + ",INITIATIVE_TERMED:"  + INITIATIVE_TERMED + ",IS_OUT_GOING:"  + IS_OUT_GOING + ",IS_PROEDSSED:"  + IS_PROEDSSED;
    }
}
