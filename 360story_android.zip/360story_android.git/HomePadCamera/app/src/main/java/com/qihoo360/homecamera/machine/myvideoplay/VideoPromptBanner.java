package com.qihoo360.homecamera.machine.myvideoplay;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.ImageLoader;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.utils.Utils;

public class VideoPromptBanner extends FrameLayout {

    public final static int SHOW_DURATION_DEFAULT = 3 * 1000;

    private TextView mTitleTextView;
    private ImageButton mCloseButton;
    private Button mActionButton;
    private View mIconFrame;
    private ImageView mIcon;
    private ImageView mIconPlayCover;

    private ObjectAnimator mShowAnimator;
    private ObjectAnimator mHideAnimator;

    private View mRoot;

    public VideoPromptBanner(Context context) {
        super(context);
        init();
    }

    public VideoPromptBanner(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();

        initAfterInflated();
    }

    private void init() {
        View.inflate(getContext(), R.layout.video_prompt_banner_layout, this);
    }

    private void initAfterInflated() {
        mCloseButton = (ImageButton) findViewById(R.id.close_button);
        mActionButton = (Button) findViewById(R.id.button);
        mTitleTextView = (TextView) findViewById(R.id.title);
        mIcon = (ImageView) findViewById(R.id.icon);
        mIconPlayCover = (ImageView) findViewById(R.id.icon_play_cover);
        mIconFrame = findViewById(R.id.icon_frame);
        mRoot = findViewById(R.id.root_layout);
    }

    public void show(int titleStringResId) {
        this.show(null, false, null, getContext().getString(titleStringResId), null, null);
    }

    public void show(String title) {
        this.show(null, false, null, title, null, null);
    }

    public void show(String title, int duration) {
        this.show(null, false, null, title, null, null,null, duration);
    }

    public void show(String title, int duration, final  Runnable onCloseClickCallback) {
        this.show(null, false, null, title, null, null, onCloseClickCallback, duration);
    }

    public void show(String title, String actionText, final Runnable actionOnClick) {
        this.show(null, false, null, title, actionText, actionOnClick);
    }

    public void show(String title, String actionText, final Runnable actionOnClick, int duration) {
        this.show(null, false, null, title, actionText, actionOnClick, null, duration);
    }

    public void show(String imagePath, boolean withPlayCover, final Runnable imageOnClick, String title, String actionText, final Runnable actionOnClick) {
        show(imagePath, withPlayCover, imageOnClick, title, actionText, actionOnClick, null, SHOW_DURATION_DEFAULT);
    }

    public boolean isShowingTitle(String title) {
        if (this.getVisibility() == View.VISIBLE && TextUtils.equals(title, mTitleTextView.getText())) {
            return  true;
        } else {
            return false;
        }
    }

    public void show(String imagePath, boolean withPlayCover, final Runnable imageOnClick, String title, String actionText, final Runnable actionOnClick, final Runnable onCloseClick, int duration) {
        this.removeCallbacks(mHideRunnable);
        this.postDelayed(mHideRunnable, duration);
        // do not show repeat
        if (isShowingTitle(title)) {
            return;
        }

//        if (mShowAnimator != null && mShowAnimator.isRunning()) {
//            mShowAnimator.end();
//        }
//        if (mHideAnimator != null && mHideAnimator.isRunning()) {
//            mHideAnimator.end();
//        }
        mRoot.clearAnimation();

        if (TextUtils.isEmpty(imagePath)) {
            mIconFrame.setVisibility(View.GONE);
        } else {
            mIconFrame.setVisibility(View.VISIBLE);
            mIconFrame.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (imageOnClick != null) {
                        imageOnClick.run();
                    }
                    mHideRunnable.run();
                }
            });
            ImageLoader.getInstance().cancelDisplayTask(mIcon);
            ImageLoader.getInstance().displayImage(imagePath, mIcon);
            if (withPlayCover) {
                mIconPlayCover.setVisibility(View.VISIBLE);
            } else {
                mIconPlayCover.setVisibility(View.GONE);
            }
        }
        mTitleTextView.setText(title);
        if (!TextUtils.isEmpty(actionText)) {
            mActionButton.setVisibility(View.VISIBLE);
            mActionButton.setText(actionText);
            mActionButton.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (actionOnClick != null) {
                        actionOnClick.run();
                    }
                    mHideRunnable.run();
                }
            });
        } else {
            mActionButton.setVisibility(View.GONE);
        }

        mCloseButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onCloseClick != null) {
                    onCloseClick.run();
                }
                mHideRunnable.run();
            }
        });

        this.setVisibility(View.VISIBLE);
//        this.setAlpha(1f);
//        mRoot.setY(getMeasuredHeight());
//        PropertyValuesHolder vhAlpha = PropertyValuesHolder.ofFloat("alpha", 0.2f, 1f);
//        PropertyValuesHolder vhY = PropertyValuesHolder.ofFloat("Y", getMeasuredHeight(), 0f);
//        mShowAnimator = ObjectAnimator.ofPropertyValuesHolder(mRoot, vhAlpha, vhY);
//        mShowAnimator.setDuration(500);
//        mShowAnimator.start();
        Animation a = AnimationUtils.loadAnimation(Utils.getContext(),R.anim.banner_show);
        mRoot.startAnimation(a);

        this.postDelayed(mHideRunnable, duration);
    }

    private Runnable mHideRunnable = new Runnable() {
        @Override
        public void run() {
            if (VideoPromptBanner.this.getVisibility() == View.GONE) {
                return;
            }
//            if (mHideAnimator != null && mHideAnimator.isRunning()) {
//                mHideAnimator.end();
//            }
            mRoot.clearAnimation();

            VideoPromptBanner.this.removeCallbacks(mHideRunnable);
//            mRoot.setY(0);
//            PropertyValuesHolder vhAlpha = PropertyValuesHolder.ofFloat("alpha", 1f, 0.2f);
//            PropertyValuesHolder vhY = PropertyValuesHolder.ofFloat("Y", 0f, getMeasuredHeight());
//            mHideAnimator = ObjectAnimator.ofPropertyValuesHolder(mRoot, vhAlpha, vhY);
//            mHideAnimator.setDuration(500);
//            mHideAnimator.start();
//            mHideAnimator.addListener(new AnimatorListenerAdapter() {
//                @Override
//                public void onAnimationEnd(Animator animation) {
//                    super.onAnimationEnd(animation);
//                    VideoPromptBanner.this.setVisibility(View.GONE);
//                }
//            });
            Animation a = AnimationUtils.loadAnimation(Utils.getContext(),R.anim.banner_hidded);
            a.setAnimationListener(new Animation.AnimationListener() {
                @Override
                public void onAnimationStart(Animation animation) {

                }

                @Override
                public void onAnimationEnd(Animation animation) {
                    setVisibility(View.GONE);
                }

                @Override
                public void onAnimationRepeat(Animation animation) {

                }
            });
            mRoot.startAnimation(a);
        }
    };

    public void hide() {
        mHideRunnable.run();
    }
}
