package com.qihoo360.homecamera.machine.util;

import android.text.TextUtils;

import com.qihoo360.homecamera.machine.config.MachineDebugConfig;
import com.qihoo360.homecamera.machine.entity.Wifi;
import com.qihoo360.homecamera.mobile.db.PadInfoWrapper;
import com.qihoo360.homecamera.mobile.entity.DeviceInfo;

/**
 * Created by zhangchao-pd on 2016/11/11.
 */

public class MachineUtils {
    // wifi 加密类型
    public static int getAuth(Wifi wifi) {
        if (wifi.getAUTH().contains("Enterprise")) {
            return 4;
        } else if (wifi.getAUTH().contains("EAP")) {
            return 4;
        } else if (wifi.getAUTH().contains("WPA2")) {
            return 3;
        } else if (wifi.getAUTH().contains("WPA")) {
            return 2;
        } else if (wifi.getAUTH().contains("WEP")) {
            return 1;
        } else if (wifi.getAUTH().contains("WPS")) {
            return 0;
        } else if (wifi.getAUTH().equals("")) {
            return 0;
        }
        return 5;
    }

    private static String mLastCheckSn = "";
    private static DeviceInfo mLastCheckDeviceInfo = null;
    public static boolean isMachineMode(String sn){
        if (!MachineDebugConfig.DEBUG){
            return false;
        }

        DeviceInfo checkDeviceInfo = null;
        boolean isReloadDeviceInfo = true;
        if (!TextUtils.isEmpty(sn)){

            if (mLastCheckDeviceInfo != null && sn.equalsIgnoreCase(mLastCheckSn)){
                isReloadDeviceInfo = false;
                checkDeviceInfo = mLastCheckDeviceInfo;
            }
        }

        if (checkDeviceInfo != null || isReloadDeviceInfo){
            checkDeviceInfo = PadInfoWrapper.getInstance().getPadBySn(sn);
            mLastCheckDeviceInfo = checkDeviceInfo;
            mLastCheckSn = sn;
        }

        if (checkDeviceInfo != null){
            if (checkDeviceInfo.isStoryMachine()){
                return true;
            }
        }

        return false;
    }

    public static boolean isMachineMode(DeviceInfo deviceInfo){
        if (MachineDebugConfig.DEBUG){
            if (deviceInfo != null){
                if (deviceInfo.isStoryMachine()){
                    return true;
                }
            }
        }
        return false;
    }

}
