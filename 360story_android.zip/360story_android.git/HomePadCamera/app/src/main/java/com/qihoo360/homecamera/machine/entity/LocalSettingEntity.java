package com.qihoo360.homecamera.machine.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by zhangtao-iri on 2016/12/22.
 */
public class LocalSettingEntity implements Parcelable{

    public String circulation;           // single-单曲循环，list-列表循环

    public int childlock;             // 童锁开关，1-锁定，0--解锁

    public long shutdownDelaySeconds; //关闭为-1，0相当于立即关机

    public int volume_max;            // 0-100,故事机最大音量，app端应该有下限

    public int led_indicator;         // 故事机指示灯开关，0：关闭，1：打开

    public long getShutdownDelaySeconds() {
        return shutdownDelaySeconds;
    }

    public void setShutdownDelaySeconds(long shutdownDelaySeconds) {
        this.shutdownDelaySeconds = shutdownDelaySeconds;
    }

    public int getChildlock() {
        return childlock;
    }

    public void setChildlock(int childlock) {
        this.childlock = childlock;
    }

    public String getCirculation() {
        return circulation;
    }

    public void setCirculation(String circulation) {
        this.circulation = circulation;
    }

    public int getVolume_max() {
        return volume_max;
    }

    public void setVolume_max(int volume_max) {
        this.volume_max = volume_max;
    }

    public int getLed_indicator() {
        return led_indicator;
    }

    public void setLed_indicator(int led_indicator) {
        this.led_indicator = led_indicator;
    }

    public LocalSettingEntity() {
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.circulation);
        dest.writeInt(this.childlock);
        dest.writeLong(this.shutdownDelaySeconds);
        dest.writeInt(this.volume_max);
        dest.writeInt(this.led_indicator);
    }

    protected LocalSettingEntity(Parcel in) {
        this.circulation = in.readString();
        this.childlock = in.readInt();
        this.shutdownDelaySeconds = in.readLong();
        this.volume_max = in.readInt();
        this.led_indicator = in.readInt();
    }

    public static final Creator<LocalSettingEntity> CREATOR = new Creator<LocalSettingEntity>() {
        @Override
        public LocalSettingEntity createFromParcel(Parcel source) {
            return new LocalSettingEntity(source);
        }

        @Override
        public LocalSettingEntity[] newArray(int size) {
            return new LocalSettingEntity[size];
        }
    };
}
