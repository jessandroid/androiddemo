
package com.qihoo360.homecamera.machine.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.qihoo360.homecamera.machine.entity.Group;
import com.qihoo360.homecamera.machine.entity.Wifi;
import com.qihoo360.homecamera.machine.entity.WifiAdmin;
import com.qihoo360.homecamera.machine.util.MachineUtils;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.utils.Utils;

public class WifiAdapter extends BaseAdapter {

    private Group<Wifi> wifis;
    private LayoutInflater inflate;
    private String mSSID = "";

    public WifiAdapter() {
        this.wifis = new Group<Wifi>();
        this.inflate = LayoutInflater.from(Utils.getContext());
    }

    public Group<Wifi> getWifis() {
        return wifis;
    }

    public void setWifis(Group<Wifi> wifis) {
        this.wifis = wifis;
        WifiAdmin mWifiAdmin = new WifiAdmin(Utils.getContext());
        if (mWifiAdmin.getSSID() != null
                && !mWifiAdmin.getSSID().equals("NULL")) {
            mSSID = mWifiAdmin.getSSID();
        }
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        if (wifis != null)
            return wifis.size();
        return 0;
    }

    @Override
    public Wifi getItem(int arg0) {
        if (wifis != null && arg0 < getCount())
            return wifis.get(arg0);
        return new Wifi();
    }

    @Override
    public long getItemId(int arg0) {
        return arg0;
    }

    @Override
    public View getView(int arg0, View view, ViewGroup arg2) {
        ViewHolder holder;
        if (view == null) {
            holder = new ViewHolder();
            view = inflate.inflate(R.layout.wifi_list_adapter, null);
            holder.ssid = (TextView) view.findViewById(R.id.wifi_ssid);
            holder.signal = (ImageView) view.findViewById(R.id.wifi_signal);
            view.setTag(holder);
        } else {
            holder = (ViewHolder) view.getTag();
        }
        if (getItem(arg0).getAUTHTYPE() != 4 && getItem(arg0).getAUTHTYPE() != 5 && mSSID.equals(getItem(arg0).getSSID())) {//选中
            holder.ssid.setTextColor(Utils.getContext().getResources().getColor(
                    R.color.guide_green));
        } else {
            if (getItem(arg0).getAUTHTYPE() == 4 || getItem(arg0).getAUTHTYPE() == 5) {
                holder.ssid.setTextColor(Utils.getContext().getResources().getColor(
                        R.color.state_offLine_color));
            } else {
                holder.ssid.setTextColor(Utils.getContext().getResources().getColor(
                        R.color.text_dark));
            }

        }

        holder.ssid.setText(getItem(arg0).getSSID());
        holder.signal.setImageResource(getSignalRes(getItem(arg0)));
        return view;
    }

    class ViewHolder {
        TextView ssid;
        ImageView signal;
    }

    int getSignalRes(Wifi wifi) {
        int resId = R.drawable.ic_wifi_signal_1_light;
        boolean isSecure = MachineUtils.getAuth((wifi)) != 0;
        int level = wifi.getLevel();
        if (level >= 3) {
            resId = isSecure ? R.drawable.ic_wifi_lock_signal_4_light
                    : R.drawable.ic_wifi_signal_4_light;
        } else if (level == 2) {
            resId = isSecure ? R.drawable.ic_wifi_lock_signal_3_light
                    : R.drawable.ic_wifi_signal_3_light;
        } else if (level == 1) {
            resId = isSecure ? R.drawable.ic_wifi_lock_signal_2_light
                    : R.drawable.ic_wifi_signal_2_light;
        } else {
            resId = isSecure ? R.drawable.ic_wifi_lock_signal_1_light
                    : R.drawable.ic_wifi_signal_1_light;
        }
        return resId;
    }

}
