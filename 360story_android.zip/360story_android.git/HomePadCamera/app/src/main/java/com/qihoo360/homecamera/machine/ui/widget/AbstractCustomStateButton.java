package com.qihoo360.homecamera.machine.ui.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qihoo360.homecamera.machine.preferences.Preferences;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.utils.CLog;

/**
 * Created by zhaojunbo on 2015/11/5.
 * desc:
 */
public abstract class AbstractCustomStateButton extends RelativeLayout {
    public final static int MIC_NORMAL = 0;//麦克烦eg
    public final static int MIC_PRESS = 1;
    public final static int MIC_DISABLE = 2;

    public final static int PHONE_NORMAL = 3;
    public final static int PHONE_PRESS = 4;
    public final static int PHONE_DISABLE = 5;

    public final static int PHONE2MIC = 6;
    public final static int MIC2PHONE = 7;
    public final static int HANGUP = 8;

    public final static int PHONE_NOT_SUPPORT = 0;
    public final static int CAMERA_NOT_SUPPORT = 1;
    public final static int FIRMWORK_NEED_UPDATE = 2;
    public final static int IS_DEMO_CAMERA = 3;

    protected Context mContext;
    protected TextView mTipsTv;
    protected ImageView mCurrentFunBtn;
    protected ImageView mChangeBtn;
    protected View mChangeDevidedView;
    public int mButtonState = 0;
    protected int mDuration = 300;
    protected OnChangeStateListener onChangeStateListener;
    protected OnTalkButtonClickListener onTalkButtonClickListener;
    protected OnChangeStateErrorListener onChangeErrorListener;
    protected int mLastButtonState = 0;
    protected Animation mChangeBtnTranslateAnimation;
    protected Animation mCurrentFunBtnTranslateAnimation;
    protected boolean mIsChanging = false;

    protected boolean mIsPhoneSupport = true;
    protected boolean mIsfirmworkSupport = true;
    protected boolean mIsCameraSupport = true;
    public boolean mIsPhoneModeEnable = true;
    protected boolean mAlreadyInit = false;
    protected boolean mIsEnable = false;
    public boolean mIsReInitView = false;
    protected boolean mIsDemoCamera = false;
    protected boolean isLand;
    protected String mSn;

    public boolean needAlwaysPhoneMode = false;

    public AbstractCustomStateButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.AbstractCustomStateButton);
        try {
            mDuration = a.getInt(R.styleable.AbstractCustomStateButton_duration, 300);
        } finally {
            a.recycle();
        }
    }

    public void setmIsPhoneSupport(boolean mIsPhoneSupport) {
        this.mIsPhoneSupport = mIsPhoneSupport;
        setPhoneModeVisible(mIsPhoneSupport & mIsCameraSupport);
    }

    public void setmIsfirmworkSupport(boolean mIsfirmworkSupport) {
        this.mIsfirmworkSupport = mIsfirmworkSupport;
    }

    public void setmIsCameraSupport(boolean mIsCameraSupport) {
        this.mIsCameraSupport = mIsCameraSupport;
        setPhoneModeVisible(mIsPhoneSupport & mIsCameraSupport);
    }

    public void setOnTalkButtonClickListener(OnTalkButtonClickListener onTalkButtonClickListener) {
        this.onTalkButtonClickListener = onTalkButtonClickListener;
    }

    public void setOnChangeStateListener(OnChangeStateListener onChangeStateListener) {
        this.onChangeStateListener = onChangeStateListener;
    }

    public OnChangeStateListener getOnChangeStateListener() {
        return this.onChangeStateListener;
    }

    public void setOnChangeErrorListener(OnChangeStateErrorListener onChangeErrorListener) {
        this.onChangeErrorListener = onChangeErrorListener;
    }

    public interface OnChangeStateListener {
        void onChange(int state);
        void onCloseVideo();
    }

    public interface OnTalkButtonClickListener {
        void onClick(int state);
    }

    public interface OnChangeStateErrorListener {
        void onErrorMsg(int state);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    protected void initView() {
        findAllView(this);
        restoreLast(mSn);
    }

    public void resetAlreadyInit() {
        mAlreadyInit = false;
    }

    public void restoreLast(String sn) {
        if (!mAlreadyInit) {
//            if (mIsPhoneModeEnable) {
//                restoreLastState(Preferences.getIsMic(mSn) < 3 ?  MIC_NORMAL : PHONE_NORMAL);
//            }
            int btnState = 0;
            if (Preferences.getIsFirstMic(mSn) == false) {
                if (this.mIsCameraSupport == true && Preferences.getMicType() != 0) {
                    btnState = AbstractCustomStateButton.PHONE_NORMAL;
                } else {
                    btnState = AbstractCustomStateButton.MIC_NORMAL;
                }
                Preferences.setIsFirstMic(mSn, true);
            } else {
                btnState = Preferences.getIsMic(sn);
            }
            if (needAlwaysPhoneMode) {
                restoreLastState(3);
            } else {
                restoreLastState(btnState);
            }
            mAlreadyInit = true;
        }
        if (mIsReInitView && mButtonState < 3) {
            mTipsTv.setTextColor(mIsEnable ? 0xff718bca : 0xffa9a9a9);
            mIsReInitView = false;
        }
    }

    private void findAllView(ViewGroup view) {
        for (int i = 0; i < view.getChildCount(); i++) {
            Object v = view.getChildAt(i);
            if (v instanceof TextView) {
                mTipsTv = (TextView) v;
            }
            if (v instanceof ImageView) {
                if (((ImageView) v).getId() != R.id.iv_change) {
                    mCurrentFunBtn = (ImageView) v;
                }
            }
            if (v instanceof ViewGroup) {
                findAllView((ViewGroup) v);
            }
        }
    }

    protected void playAnim() {
        mChangeBtnTranslateAnimation.setDuration(mDuration);
        mChangeBtn.startAnimation(mChangeBtnTranslateAnimation);
        mChangeBtnTranslateAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                mIsChanging = false;
                mChangeBtn.setImageResource(mButtonState < 3 ? R.drawable.phone_state_drawable : R.drawable.mic_state_drawable);
                if (isLand) {
                    mCurrentFunBtn.setImageResource(mButtonState < 3 ? R.drawable.btn_video_pushtalk_land : R.drawable.btn_video_pushtalk_phone_land);
                }else{
                    mCurrentFunBtn.setImageResource(mButtonState < 3 ? R.drawable.btn_video_push_talk : R.drawable.btn_video_push_phone_talk);
                }
                mTipsTv.setText(mButtonState < 3 ? mContext.getString(R.string.talk_mic_normal) : mContext.getString(R.string.talk_phone_normal));
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

        mCurrentFunBtnTranslateAnimation.setDuration(mDuration);
        mCurrentFunBtn.startAnimation(mCurrentFunBtnTranslateAnimation);
        mCurrentFunBtnTranslateAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                mIsChanging = false;
                mChangeBtn.setImageResource(mButtonState < 3 ? R.drawable.phone_state_drawable : R.drawable.mic_state_drawable);
                if (isLand) {
                    mCurrentFunBtn.setImageResource(mButtonState < 3 ? R.drawable.btn_video_pushtalk_land : R.drawable.btn_video_pushtalk_phone_land);
                }else{
                    mCurrentFunBtn.setImageResource(mButtonState < 3 ? R.drawable.btn_video_push_talk : R.drawable.btn_video_push_phone_talk);
                }
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }

    @Override
    public void setEnabled(boolean enabled) {
        super.setEnabled(enabled);
        mChangeBtn.setEnabled(enabled);
        mIsEnable = enabled;
        CLog.d("cx_debug setEnabled:"+enabled);
    }

    public void setSn(String sn) {
        mSn = sn;
    }

    public abstract void restoreLastState(int state);

    public abstract void setPhoneModeVisible(boolean isVisible);

    public abstract boolean clickTalkBtn(View v, MotionEvent event, int action);

    public boolean isCustomEnabled() {
        return mIsEnable;
    }

    protected boolean inRangeOfView(View view, MotionEvent ev) {
        int[] location = new int[2];
        view.getLocationOnScreen(location);
        int x = 0;
        int y = 0;
        if (ev.getX() < x || ev.getX() > (x + view.getWidth()) || ev.getY() < y || ev.getY() > (y + view.getHeight())) {
            return false;
        }
        return true;
    }

    public void setmIsDemoCamera(boolean mIsDemoCamera) {
        this.mIsDemoCamera = mIsDemoCamera;
    }
}
