package com.qihoo360.homecamera.machine.myvideoplay;

public class Config {

    public final static boolean VIDEO_PLAY_SHOW_TIME = false;

    public final static boolean VIDEO_PLAY_SHOW_NIGHT_MODE_SETTING = false;

    public final static boolean VIDEO_PLAY_SHOW_STREAM_TEXT = false;
}
