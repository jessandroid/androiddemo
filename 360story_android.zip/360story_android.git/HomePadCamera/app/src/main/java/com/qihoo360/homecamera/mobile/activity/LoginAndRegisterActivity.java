
package com.qihoo360.homecamera.mobile.activity;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.MotionEvent;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.callback.ModelSwitcherCallback;
import com.qihoo360.homecamera.mobile.ui.fragment.LoginFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.NewLoginBeginFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.RegisterFragment;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.PhoneUtil;

/**
 * User: Administrator
 * Date: 2016/1/15
 * Time: 17:29
 * To change this template use File | Settings | File Templates.
 */
public class LoginAndRegisterActivity extends AccountActivity implements ModelSwitcherCallback {

    public static final String KEY_MODE = "mode";
    public static final String HAIWAI_MODE="haiwai";

    public static final int MODE_BEGIN = 0;
    public static final int MODE_LOGIN = 1;
    public static final int MODE_REGISTER = 2;

    public String shareCode;
    public int mOldMode = 0;
    private int mCurrentMode = 0;

    private FragmentManager mFragManager;

    private LoginFragment mLoginFragment;

    private RegisterFragment mRegisterFragment;
    private Fragment showFragment;

    private boolean isShowKeyBoard;
    boolean overseas;

    private ImageView mBgIv;
    private NewLoginBeginFragment mBeginFragment;

    private EditText mEditText;

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_and_register);
        mFragManager = getSupportFragmentManager();
        mBeginFragment = new NewLoginBeginFragment();
        mLoginFragment = LoginFragment.newInstance(null,null);
        mRegisterFragment = new RegisterFragment();

        if (getIntent().hasExtra("switch") && getIntent().getBooleanExtra("switch", false)) {
            mCurrentMode = MODE_LOGIN;
            if (getIntent().hasExtra("time") && getIntent().getLongExtra("time", -1) != -1)
            showCommonDialog("", getString(R.string.tips_dialog_content, PhoneUtil.getTitleDateString(false, (getIntent().getLongExtra("time", -1) * 1000) + "")), "", getString(R.string.tips_dialog_btn), "", false, new ICommonDialog() {
                @Override
                public void onRightButtonClick(boolean isChecked) {}

                @Override
                public void onLeftButtonClick(boolean isChecked) {}

                @Override
                public void onDialogCancel() {}
            }, false);
        }


        isShowKeyBoard = mCurrentMode != MODE_LOGIN;
        setMode(mCurrentMode);
    }

    @Override
    public void setMode(int mode) {
        mOldMode = mCurrentMode;
        mCurrentMode = mode;
        FragmentTransaction trans = mFragManager.beginTransaction();
        switch (mCurrentMode) {
            case MODE_BEGIN:
                hintKeyboard();
                trans.replace(R.id.main_frame, mBeginFragment);
                showFragment = mBeginFragment;
                break;
            case MODE_LOGIN:
                trans.replace(R.id.main_frame, mLoginFragment);
                showFragment = mLoginFragment;
                // mVideoView.isMeasure = false;
                break;
            case MODE_REGISTER:
                trans.replace(R.id.main_frame, mRegisterFragment);
                showFragment = mRegisterFragment;
                // mVideoView.isMeasure = false;
                break;
        }
        trans.commitAllowingStateLoss();
    }

    @Override
    public int getMode() {
        return mCurrentMode;
    }

    @Override
    public void toggleMode() {
        mCurrentMode = mCurrentMode == MODE_LOGIN ? MODE_REGISTER : MODE_LOGIN;
        setMode(mCurrentMode);
    }

    public void setEditText(EditText editText) {
        mEditText = editText;
        setViewEdit();
    }

    private void setViewEdit() {
        if (mEditText != null) {
            mEditText.setFocusable(true);
            mEditText.setFocusableInTouchMode(true);
            mEditText.requestFocus();

            if (!isShowKeyBoard) {
                isShowKeyBoard = true;
                return;
            }
            setKeyboardFocus(mEditText);
        }
    }

    private void setKeyboardFocus(final EditText primaryTextField) {
        (new Handler()).postDelayed(new Runnable() {
            @Override
            public void run() {
                MotionEvent motionDown =
                        MotionEvent.obtain(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(),
                                MotionEvent.ACTION_DOWN, 0, 0, 0);
                MotionEvent motionUp =
                        MotionEvent.obtain(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(),
                                MotionEvent.ACTION_UP, 0, 0, 0);

                primaryTextField.dispatchTouchEvent(motionDown);
                primaryTextField.dispatchTouchEvent(motionUp);

                motionDown.recycle();
                motionUp.recycle();

                primaryTextField.setSelection(primaryTextField.length());
            }
        }, 100);
    }


    public void goBack() {
        if (showFragment instanceof RegisterFragment) {
            if (mRegisterFragment.isWebviewIsHide() == false) {
                mRegisterFragment.onBackPressed();
            } else {
                this.setMode(mOldMode);
            }
        } else if (showFragment instanceof LoginFragment) {
            this.setMode(MODE_BEGIN);
        } else if (showFragment instanceof NewLoginBeginFragment) {
            super.onBackPressed();
        }
    }

    @Override
    public void onBackPressed() {
        goBack();
    }

    public void closeKeyboard() {
        hintKeyboard();
    }

    private void hintKeyboard() {
        if (mEditText != null) {
            CLog.e("login hideSoftInputFromWindow");
            mEditText.clearFocus();
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(mEditText.getWindowToken(), 0); // 强制隐藏键盘
        }
    }

}
