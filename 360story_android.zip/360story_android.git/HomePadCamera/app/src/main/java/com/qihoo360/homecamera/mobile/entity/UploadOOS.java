package com.qihoo360.homecamera.mobile.entity;

import com.google.gson.Gson;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/3/2
 * Time: 11:34
 * To change this template use File | Settings | File Templates.
 */
public class UploadOOS{


    /**
     * errorCode : 0
     * errorMsg : 成功
     * data : {"url":"http://up-shanghai.oss.yunpan.360.cn/Object.upload","token":"030f9838e84bbe8f0d364f1eb7c59a8e:87feb4de94b775200765d65600779597:eyJidWNrZXQiOiJwYWQtbWFzdGVyLWFsYnVtLXNoIiwib2JqZWN0IjoiMGFlYzRlZDZlOGMyYWVkMDZkNTFiODkyZDYzMjFkMzcuanBnIiwiZGVhZGxpbmUiOjE0NTY5MzEyNDgsImluc2VydE9ubHkiOjB9","post":{"bucket":"pad-master-album-sh","object":"0aec4ed6e8c2aed06d51b892d6321d37.jpg","deadline":1456931248,"insertOnly":0}}
     */

    public int errorCode;
    public String errorMsg;
    /**
     * url : http://up-shanghai.oss.yunpan.360.cn/Object.upload
     * token : 030f9838e84bbe8f0d364f1eb7c59a8e:87feb4de94b775200765d65600779597:eyJidWNrZXQiOiJwYWQtbWFzdGVyLWFsYnVtLXNoIiwib2JqZWN0IjoiMGFlYzRlZDZlOGMyYWVkMDZkNTFiODkyZDYzMjFkMzcuanBnIiwiZGVhZGxpbmUiOjE0NTY5MzEyNDgsImluc2VydE9ubHkiOjB9
     * post : {"bucket":"pad-master-album-sh","object":"0aec4ed6e8c2aed06d51b892d6321d37.jpg","deadline":1456931248,"insertOnly":0}
     */

    private DataEntity data;

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public void setData(DataEntity data) {
        this.data = data;
    }

    public int getErrorCode() {
        return errorCode;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public DataEntity getData() {
        return data;
    }

    public static class DataEntity {
        private String url;
        private String token;
        private String downUrl;
        private String uploadUrl;
        /**
         * bucket : pad-master-album-sh
         * object : 0aec4ed6e8c2aed06d51b892d6321d37.jpg
         * deadline : 1456931248
         * insertOnly : 0
         */

        private PostEntity post;

        public String getUploadUrl() {
            return uploadUrl;
        }

        public void setUploadUrl(String uploadUrl) {
            this.uploadUrl = uploadUrl;
        }

        public void setUrl(String url) {
            this.url = url;
        }

        public void setToken(String token) {
            this.token = token;
        }

        public void setPost(PostEntity post) {
            this.post = post;
        }

        public String getUrl() {
            //return url.replace("up-shanghai.oss.yunpan.360.cn","140.207.202.183");
            return  url;
        }

        public String getDownUrl() {
            return downUrl;
        }

        public void setDownUrl(String downUrl) {
            this.downUrl = downUrl;
        }

        public String getToken() {
            return token;
        }

        public PostEntity getPost() {
            return post;
        }

        public static class PostEntity {
            private String bucket;
            private String object;
            private int deadline;
            private int insertOnly;

            public void setBucket(String bucket) {
                this.bucket = bucket;
            }

            public void setObject(String object) {
                this.object = object;
            }

            public void setDeadline(int deadline) {
                this.deadline = deadline;
            }

            public void setInsertOnly(int insertOnly) {
                this.insertOnly = insertOnly;
            }

            public String getBucket() {
                return bucket;
            }

            public String getObject() {
                return object;
            }

            public int getDeadline() {
                return deadline;
            }

            public int getInsertOnly() {
                return insertOnly;
            }
        }
    }


    public String toJson(){
        Gson gson = new Gson();
        return gson.toJson(this);
    }

}
