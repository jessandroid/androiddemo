
package com.qihoo360.homecamera.mobile.entity;

import android.annotation.SuppressLint;

import com.qihoo360.homecamera.device.config.StoryMachineConsts;
import com.qihoo360.homecamera.mobile.BuildConfig;
import com.qihoo360.homecamera.mobile.utils.MediaType;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.util.HashMap;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/3/2
 * Time: 11:10
 * To change this template use File | Settings | File Templates.
 */
@SuppressLint("ParcelCreator")
public class UploadToken extends Head {

    /**
     * sn	IPC序列化	string	是
     * block 是否切片	int	是	1 是，默认否
     * fsize 文件大小	int	是
     * ftype 文件类型	int	是	0 图片 1 视频
     * fext 文件后缀名	string	是	例：jpg、mp4
     * parallel 切片传输时并发数量	int	否	切片上传时需要，不传默认为1
     * oriName 用户源文件名  string 	否	用户本地的图片名
     */

    public int _id;
    public String sn;
    public int block;
    public int fsize;
    public int ftype;
    public String fext;
    public int parallel;
    public String oriName;
    public File file;
    public String fhash;
    public String cover;
    public UploadOOS uploadOOS;
    public String name;
    public String localPath;
    public String duration;
    public String video_url;
    public boolean checked;
    public String storyId;

    public UploadToken(File file, String sn, boolean block, String oriName, String duration) {
        this.file = file;
        this.sn = sn;
        this.block = block ? 1 : 0;
        this.oriName = oriName;
        this.duration = duration;
    }

    public UploadToken() {

    }

    public HashMap<String, String> toFamilyGroupParam() throws IOException{
        HashMap<String, String> param = new HashMap();
        param.put("sn", String.valueOf(this.sn));
        long fz = fsize == 0 ? getFsize() : fsize;
        param.put("fsize", String.valueOf(fz));
        param.put("fext", "aac");
        param.put("device", "story");
        param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
        param.put("funcType", "chat");
        return param;
    }

    public HashMap<String, String> toRequesParam() throws IOException {
        HashMap<String, String> param = new HashMap();
        param.put("sn", String.valueOf(this.sn));
        param.put("block", String.valueOf(this.block));
        long fz = fsize == 0 ? getFsize() : fsize;
        param.put("fsize", String.valueOf(fz));
        param.put("fext", getFext());
        param.put("fileName ", oriName);
        param.put("cover", cover);
        param.put("name", name);
        param.put("ftype", String.valueOf(getFileType()));
        param.put("duration", duration);
        param.put("video_url", video_url);
        param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
        if (uploadOOS != null && uploadOOS.getData() != null && uploadOOS.getData().getPost() != null) {
            UploadOOS.DataEntity.PostEntity pse = uploadOOS.getData().getPost();
            param.put("bucket", pse.getBucket());
            param.put("fileName", pse.getObject());
        }
        return param;
    }

    public String getFext() {
        String filename = file.getName();
        if ((filename != null) && (filename.length() > 0)) {
            int dot = filename.lastIndexOf('.');
            if ((dot > -1) && (dot < (filename.length() - 1))) {
                return filename.substring(dot + 1);
            }
        }
        return filename;
    }

    public long getFsize() throws IOException {
        FileInputStream fis = new FileInputStream(file);
        FileChannel fc = fis.getChannel();
        return fc.size();
    }

    public UploadOOS getUploadOOS() {
        return uploadOOS;
    }

    public void setUploadOOS(UploadOOS uploadOOS) {
        this.uploadOOS = uploadOOS;
    }

    public int getFileType() {
        ftype = MediaType.isVideoFileType(file.getAbsolutePath());
        return ftype;
    }
}
