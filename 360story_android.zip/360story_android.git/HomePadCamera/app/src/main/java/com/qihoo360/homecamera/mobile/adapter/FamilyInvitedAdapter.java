package com.qihoo360.homecamera.mobile.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.qihoo360.accounts.ui.model.AddAccountsUtils;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.entity.ShareGetListEntity;
import com.qihoo360.homecamera.mobile.entity.ShareUserEntity;
import com.qihoo360.homecamera.mobile.image.my.GlideCircleTransform;
import com.qihoo360.homecamera.mobile.utils.MagicTextLengthWatcher;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.widget.TextViewWithFont;

/**
 * Created by zhaojunbo on 2016/2/16.
 * desc:
 */
public class FamilyInvitedAdapter extends BaseAdapter implements AdapterView.OnItemLongClickListener {

    private Context mContext;

    private ShareGetListEntity shareGetListEntity;

    private IOnClickItem iOnClickItem;

    public FamilyInvitedAdapter(Context context) {
        mContext = context;
    }

    public void setData(ShareGetListEntity shareGetListEntity) {
        this.shareGetListEntity = shareGetListEntity;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        if (shareGetListEntity != null && shareGetListEntity.data != null && shareGetListEntity.data.data != null)
            return shareGetListEntity.data.data.size();
        else
            return 0;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final ViewHolder viewHolder;
        if (null == convertView) {
            viewHolder = new ViewHolder();
            LayoutInflater mInflater = LayoutInflater.from(mContext);
            convertView = mInflater.inflate(R.layout.item_family_invited_item, null);
            //viewHolder.invitedFamilyNameTv = convertView.findViewById(R.id.)

            viewHolder.mAvatorIv = (ImageView) convertView.findViewById(R.id.iv_avator);
            viewHolder.mRobotIv = (ImageView) convertView.findViewById(R.id.iv_robot);
            viewHolder.mNickNameEt = (EditText) convertView.findViewById(R.id.et_nickname);
            viewHolder.mNickNameEt.addTextChangedListener(new MagicTextLengthWatcher(16, viewHolder.mNickNameEt));
            viewHolder.mNickNameTv = (TextViewWithFont) convertView.findViewById(R.id.tv_nickname);
            viewHolder.mVideoCallTimeTv = (TextViewWithFont) convertView.findViewById(R.id.tv_video_call_time);
            viewHolder.mLastWatchTv = (TextViewWithFont) convertView.findViewById(R.id.tv_last_watch_time);
            viewHolder.mEditNicknameIv = (ImageView) convertView.findViewById(R.id.iv_edit_nickname);
            viewHolder.mRightButtonTv = (TextViewWithFont) convertView.findViewById(R.id.tv_right_button);
            viewHolder.mDeleteShareIv = (ImageView) convertView.findViewById(R.id.iv_delete_share);
            viewHolder.mPhoneTv = (TextViewWithFont) convertView.findViewById(R.id.tv_phone);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        if (shareGetListEntity != null && shareGetListEntity.data != null && shareGetListEntity.data.data != null) {
            final ShareUserEntity shareUserEntity = shareGetListEntity.data.data.get(position);
            Glide.with(mContext)
                    .load(shareUserEntity.imgUrl)
                    .transform(new GlideCircleTransform(Utils.context))
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .error(R.drawable.icon_avator_empty)
                    .into(viewHolder.mAvatorIv);
//            Glide.with(mContext)
//                    .load(shareUserEntity.imgUrl)
//                    .placeholder(R.drawable.ic_launcher)
//                    .diskCacheStrategy(DiskCacheStrategy.ALL)
//                    .error(R.drawable.ic_launcher)
//                    .into(viewHolder.mAvatorIv);
            //平板好友显示机器人图标
            if (shareUserEntity.role.equals(String.valueOf(Constants.Role.FRIEND))) {
                String name = TextUtils.isEmpty(shareUserEntity.remarkName) ? shareUserEntity.nickName : shareUserEntity.remarkName;
                viewHolder.mNickNameTv.setText(name);
                viewHolder.mRobotIv.setVisibility(View.VISIBLE);
                viewHolder.mLastWatchTv.setText(shareUserEntity.playTime);
                viewHolder.mEditNicknameIv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        viewHolder.mNickNameEt.setVisibility(View.VISIBLE);
                        viewHolder.mRightButtonTv.setVisibility(View.VISIBLE);
                        viewHolder.mNickNameTv.setVisibility(View.GONE);
                        viewHolder.mPhoneTv.setVisibility(View.GONE);
                        viewHolder.mNickNameEt.setText(viewHolder.mNickNameTv.getText().toString());
                        viewHolder.mNickNameEt.requestFocus();
                        viewHolder.mEditNicknameIv.setVisibility(View.GONE);
                        //viewHolder.mDeleteShareIv.setVisibility(View.GONE);
                    }
                });
                viewHolder.mRightButtonTv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String oldRemark = viewHolder.mNickNameTv.getText().toString();
                        String newRemark = viewHolder.mNickNameEt.getText().toString();

                        if (!oldRemark.equals(newRemark)) {
                            newRemark = handleConflict(newRemark);
                            iOnClickItem.onEditRemarkItem(shareUserEntity.sn, shareUserEntity.qid, newRemark, oldRemark);
                        }

                        viewHolder.mNickNameEt.setVisibility(View.GONE);
                        viewHolder.mRightButtonTv.setVisibility(View.GONE);
                        viewHolder.mNickNameTv.setVisibility(View.VISIBLE);
                        viewHolder.mPhoneTv.setVisibility(View.VISIBLE);
                        viewHolder.mNickNameTv.setText(newRemark);
                        viewHolder.mEditNicknameIv.setVisibility(View.VISIBLE);
                        //viewHolder.mDeleteShareIv.setVisibility(View.VISIBLE);

                        AddAccountsUtils.hideSoftInput(mContext, viewHolder.mNickNameEt);
                    }
                });
            } else {
                String name = TextUtils.isEmpty(shareUserEntity.getRelation()) ? shareUserEntity.nickName : shareUserEntity.getRelation();
                viewHolder.mNickNameTv.setText(name);
                viewHolder.mRobotIv.setVisibility(View.GONE);
                viewHolder.mLastWatchTv.setText(shareUserEntity.playTime);
                viewHolder.mEditNicknameIv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
//                    viewHolder.mNickNameEt.setVisibility(View.VISIBLE);
//                    viewHolder.mRightButtonTv.setVisibility(View.VISIBLE);
//                    viewHolder.mNickNameTv.setVisibility(View.GONE);
//                    viewHolder.mNickNameEt.setText(viewHolder.mNickNameTv.getText().toString());
//                    viewHolder.mEditNicknameIv.setVisibility(View.GONE);
//                    viewHolder.mDeleteShareIv.setVisibility(View.GONE);
                      iOnClickItem.onEditRoleItem(shareUserEntity.sn, shareUserEntity.qid);
                    }
                });
//                viewHolder.mRightButtonTv.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//                        viewHolder.mNickNameEt.setVisibility(View.GONE);
//                        viewHolder.mRightButtonTv.setVisibility(View.GONE);
//                        viewHolder.mNickNameTv.setVisibility(View.VISIBLE);
//                        viewHolder.mNickNameTv.setText(viewHolder.mNickNameEt.getText().toString());
//                        viewHolder.mEditNicknameIv.setVisibility(View.VISIBLE);
//                        viewHolder.mDeleteShareIv.setVisibility(View.VISIBLE);
//                    }
//                });
            }
            viewHolder.mPhoneTv.setText(shareUserEntity.phone);
            viewHolder.mDeleteShareIv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    iOnClickItem.onDeleteItem(shareUserEntity.sn, shareUserEntity.qid, Integer.valueOf(shareUserEntity.role));
                }
            });
        }

        return convertView;
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
        ShareUserEntity shareUserEntity = shareGetListEntity.data.data.get(i);
        if (shareUserEntity != null) {
            iOnClickItem.onDeleteItem(shareUserEntity.sn, shareUserEntity.qid, Integer.valueOf(shareUserEntity.role));
        }
        return false;
    }

    class ViewHolder {
        ImageView mAvatorIv;
        ImageView mRobotIv;
        EditText mNickNameEt;
        TextViewWithFont mNickNameTv;
        TextViewWithFont mVideoCallTimeTv;
        TextViewWithFont mLastWatchTv;
        ImageView mEditNicknameIv;
        TextViewWithFont mRightButtonTv;
        ImageView mDeleteShareIv;
        TextViewWithFont mPhoneTv;
    }

    public interface IOnClickItem {
        void onEditRoleItem(String sn, String qid);
        void onEditRemarkItem(String sn, String qid, String newRemark, String oldRemark);
        void onDeleteItem(String sn, String qid, int role);
    }

    public void setiOnClickItem(IOnClickItem iOnClickItem) {
        this.iOnClickItem = iOnClickItem;
    }

    private String handleConflict(String name) {
        boolean bSame = false;
        int count = 0;
        int size = shareGetListEntity.data.data.size();
        String newName = name;
        do
        {
            bSame = false;
            for (int i = 0 ; i < size ; ++i)
            {
                ShareUserEntity entity = shareGetListEntity.data.data.get(i);
                if (entity != null && entity.role.equals(String.valueOf(Constants.Role.FRIEND)) ) {
                    String remarkName = TextUtils.isEmpty(entity.remarkName) ? entity.nickName : entity.remarkName;
                    if (remarkName.equals(newName))
                    {
                        bSame = true;
                        break;
                    }
                }
            }

            if (bSame)
            {
                newName = name + (++count);
            }

        } while (bSame);

        return newName;
    }
}
