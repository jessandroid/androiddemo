
package com.qihoo360.homecamera.machine.entity;

/**
 * Created by wangdan-qhwl on 2015/8/14.
 */
public class VoiceConf {
    public boolean enable_aec;
    public int mic_type;
    public int far_cache_size;
    public int far_adj;
    public int near_ns;
    public int near_adj;
    public int near_vad;
}
