
package com.qihoo360.homecamera.mobile.activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.gson.Gson;
import com.qihoo.sdk.report.QHStatAgent;
import com.qihoo360.homecamera.device.config.StoryMachineConsts;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.adapter.FamilyMemberAdapter;
import com.qihoo360.homecamera.mobile.config.Const;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.db.PadInfoWrapper;
import com.qihoo360.homecamera.mobile.db.PhoneRecordWrapper;
import com.qihoo360.homecamera.mobile.entity.AppGetInfoEntity;
import com.qihoo360.homecamera.mobile.entity.BabyInfoEntity;
import com.qihoo360.homecamera.mobile.entity.Contacts;
import com.qihoo360.homecamera.mobile.entity.DeviceCloudSettingSupport;
import com.qihoo360.homecamera.mobile.entity.DeviceInfo;
import com.qihoo360.homecamera.mobile.entity.Head;
import com.qihoo360.homecamera.mobile.entity.RelationInfoEntity;
import com.qihoo360.homecamera.mobile.entity.ShareGetListEntity;
import com.qihoo360.homecamera.mobile.entity.ShareUserEntity;
import com.qihoo360.homecamera.mobile.entity.ShareWayInfo;
import com.qihoo360.homecamera.mobile.http.OkHttpUtils;
import com.qihoo360.homecamera.mobile.image.my.GlideCircleTransform;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.ui.fragment.PadRelaxActivity;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.PhoneUtil;
import com.qihoo360.homecamera.mobile.utils.Preferences;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.widget.CamAlertDialog;
import com.qihoo360.homecamera.mobile.widget.SettingItem;
import com.qihoo360.homecamera.mobile.widget.TextViewWithFont;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/1/25
 * Time: 14:49
 * To change this template use File | Settings | File Templates.
 */
public class CameraSettingActivity extends BaseActivity implements View.OnClickListener, ActionListener {

    public final static int CHANGE_TITLE = 1001;
    public final static int EDIT_FAMILY = 1002;

    private DeviceInfo dev;
    private TextView del;
    private AppGetInfoEntity mAppGetInfoEntity;
    private BabyInfoEntity mBabyInfoEntity;
    private RelationInfoEntity mRelationInfoEntity;
    private ImageView mAvatorIv;
    private TextView mBabyNameTv;
    private TextView mBabySexTv;
    private TextView mBabyBirthTv;
    private TextView mBabyAgeTv;
    private TextView mRelaxTv;
    private int mSelect;

    private RecyclerView mMemberRecycle;
    private FamilyMemberAdapter mFamilyMemberAdapter;

    private ImageView mMasterIv;
    private TextView mMasterTv;
    private RelativeLayout mMemberMoreRl;
    private TextView mMemberMoreTv;
    private ImageView mMemberMoreIv;
    private boolean mIsMemberExpand = false;

    private CamAlertDialog camAlertDialog;
    private BroadcastReceiver refreshInvitedAndInvitingListReceiver;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cam_setting);
        if(getIntent()!=null){
            if(getIntent().hasExtra("dev")){
                dev = getIntent().getParcelableExtra("dev");
            }
        }
        if (dev == null || TextUtils.isEmpty(dev.sn)) {
            finish();
        }
        initView();
        showTipsDialog(getString(R.string.tips_loading), R.drawable.icon_loading, true);

        refreshInvitedAndInvitingListReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                refreshList();
            }
        };
        GlobalManager.getInstance().getCommonManager().registerActionListener(this);
        registerReceiver(refreshInvitedAndInvitingListReceiver, new IntentFilter(Const.BROADCAST_REFRESH_INVITED_AND_INVITING_LIST));
        GlobalManager.getInstance().getUserInfoManager().registerActionListener(this);
        GlobalManager.getInstance().getShareManager().registerActionListener(this);
        GlobalManager.getInstance().getNeverKillManager().registerActionListener(this);
        GlobalManager.getInstance().getCameraManager().registerActionListener(this);
    }

    @Override
    protected void onResume() {
        GlobalManager.getInstance().getUserInfoManager().asyncAppGetInfo(dev.getSn());
        super.onResume();
        QHStatAgent.onPageStart(this, "CameraSettingActivity");
        CLog.i("yanggang", "CameraSettingActivity onPageStart");
    }

    @Override
    protected void onPause() {
        super.onPause();
        QHStatAgent.onPageEnd(this, "CameraSettingActivity");
        CLog.i("yanggang", "CameraSettingActivity onPageEnd");
    }

    private void initView() {
        ImageView back_zone = (ImageView) findViewById(R.id.back_zone);
        Utils.ensuerSetOnclick(this, back_zone);

        TextViewWithFont title_string = (TextViewWithFont) findViewById(R.id.title_string);
        if (title_string != null) {
            title_string.setText(R.string.cam_setting_title);
        }

        RelativeLayout mBabyInfoRl = (RelativeLayout) findViewById(R.id.rl_baby_info);
        RelativeLayout mRelaxRl = (RelativeLayout) findViewById(R.id.rl_relax);

        mAvatorIv = (ImageView) findViewById(R.id.circle_image_view);
        mBabyNameTv = (TextView) findViewById(R.id.tv_baby_name);
        mBabySexTv = (TextView) findViewById(R.id.tv_baby_sex);
        mBabyBirthTv = (TextView) findViewById(R.id.tv_baby_birth);
        mBabyAgeTv = (TextView) findViewById(R.id.tv_baby_age);
        mBabyBirthTv.setText(Utils.DATE_FORMAT_5.format(System.currentTimeMillis()));
        mBabyAgeTv.setText(PhoneUtil.formatSecond(this, System.currentTimeMillis()));
        mRelaxTv = (TextView) findViewById(R.id.tv_relax);
        ImageView mInfoArrowIv = (ImageView) findViewById(R.id.iv_info_arrow);
        ImageView mArrowRelaxRightIv = (ImageView) findViewById(R.id.iv_arrow_relax_right);

        mMasterIv = (ImageView) findViewById(R.id.master_circle_image_view);
        mMasterTv = (TextView) findViewById(R.id.tv_master_name);
        mMemberMoreRl = (RelativeLayout) findViewById(R.id.rl_member_more);
        mMemberMoreRl.setOnClickListener(this);
        mMemberMoreRl.setVisibility(View.GONE);
        mMemberMoreTv = (TextView) findViewById(R.id.tv_member_more);
        mMemberMoreIv = (ImageView) findViewById(R.id.iv_member_more);

        SettingItem v7 = (SettingItem) findViewById(R.id.senven);
        SettingItem v8 = (SettingItem) findViewById(R.id.eight);
        Utils.ensuerSetOnclick(this, v7, v8, mBabyInfoRl, mRelaxRl);
        Utils.ensureVisbility(View.VISIBLE, mInfoArrowIv);
        Utils.ensureVisbility(View.INVISIBLE, mArrowRelaxRightIv);

       Utils.ensureVisbility(v8, dev.getRole()==1 ? View.VISIBLE : View.GONE);

        View delview = findViewById(R.id.del_device);
        if (delview != null) {
            del = (TextView) delview.findViewById(R.id.del_text);
            delview.setOnClickListener(this);
        }

        mFamilyMemberAdapter = new FamilyMemberAdapter(this, dev.getRole() == 1);
        mFamilyMemberAdapter.setOnViewClick(new FamilyMemberAdapter.OnViewClick() {
            @Override
            public void onNewFamily() {
                //camAlertDialog.show();
                showPopupWindow(mMemberRecycle);
            }

            @Override
            public void onEditFamily(ShareUserEntity deviceInfo) {
//                if (!TextUtils.isEmpty(deviceInfo.phone) && TextUtils.isEmpty(deviceInfo.qid)) {
//                    CameraToast.showToast(CameraSettingActivity.this, R.string.not_registed_user);
//                } else {
                Intent intent = new Intent(CameraSettingActivity.this, SettingDetialActivity.class);
                intent.putExtra("key", Constants.SettingCameraItem.PAD_EDIT_FAMILY_ITEM);
                intent.putExtra("shareUserEntity", deviceInfo);
                intent.putExtra(DeviceInfo.class.getSimpleName(), dev);
                startActivityForResult(intent, EDIT_FAMILY);
//                }
            }
        });
        mMemberRecycle = (RecyclerView) findViewById(R.id.member_recycle);
        //
        mMemberRecycle.setLayoutManager(new GridLayoutManager(this, 5));
        mMemberRecycle.setAdapter(mFamilyMemberAdapter);

        camAlertDialog = new CamAlertDialog(this, R.style.dialog_custom, false);
        View optionsView = LayoutInflater.from(this).inflate(R.layout.play_video_dialog_layout, null);
        TextView title = (TextView) optionsView.findViewById(R.id.title);
        title.setText(Utils.getString(R.string.invite_family_watch_together));
        ImageView close = (ImageView) optionsView.findViewById(R.id.close);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                camAlertDialog.dismiss();
            }
        });

        camAlertDialog.setContentView(optionsView);
        camAlertDialog.setCancelable(true);

        List<ShareWayInfo> list = new ArrayList<ShareWayInfo>() {
        };

        list.add(new ShareWayInfo(R.drawable.share_qr, "面对面扫码添加"));
        list.add(new ShareWayInfo(R.drawable.share_phone, "手机号添加"));
        list.add(new ShareWayInfo(R.drawable.share_robot, "机器人+机器人"));

        initPopupWindow(list, new IOnChooseCallback() {
            @Override
            public void onItemChoose(int pos) {
                switch (pos) {
                    case 0:
                        qrShare();
                        break;
                    case 1:
                        showBindPhone();
                        break;
                    case 2:
                        showInviteFriend();
                        break;
                }
            }
        });
    }


    @Override
    public void onClick(View view) {
        Intent intent = new Intent(CameraSettingActivity.this, SettingDetialActivity.class);
        intent.putExtra(DeviceInfo.class.getSimpleName(), dev);
        switch (view.getId()) {
            case R.id.back_zone: {
                OkHttpUtils.getInstance().cancelTag(this);
                finish();
                break;
            }
            case R.id.rl_relax:
            case R.id.rl_baby_info: {
                if (dev.getRole() == 1) {
                    intent.putExtra("appGetInfoEntity", mAppGetInfoEntity);
                    intent.putExtra("babyInfoEntity", mBabyInfoEntity);
                    intent.putExtra("relationInfoEntity", mRelationInfoEntity);
                    intent.putExtra("key", Constants.SettingCameraItem.PAD_HEAD_ITEM);
                    intent.putExtra("sn", dev.sn);
                    intent.putExtra("unset", isUnset());
                    startActivityForResult(intent, CHANGE_TITLE);
                } else {
                    Intent relaxIntent = new Intent(this, PadRelaxActivity.class);
                    relaxIntent.putExtra("relationInfoEntity", mRelationInfoEntity);
                    relaxIntent.putExtra("sn", dev.sn);
                    relaxIntent.putExtra("is_master", false);
                    relaxIntent.putExtra("unset", isUnset());
                    startActivityForResult(relaxIntent, 1005);
                }
                break;
            }
            case R.id.senven: {
                intent.putExtra("key", Constants.SettingCameraItem.PAD_ABOUT_ITEM);
                startActivity(intent);
                break;
            }
            case R.id.eight: {
                String supportStr = dev.support;
                CLog.e("hyuan", "supportStr=" + supportStr);
                Gson gson = new Gson();
                DeviceCloudSettingSupport ds = gson.fromJson(supportStr, DeviceCloudSettingSupport.class);
                CLog.e("hyuan", "ds=" + ds);
                if (ds != null && ds.getSetting_v1() == 1) {
                    CLog.e("hyuan", "setting_v1=" + ds.getSetting_v1());
//                    Intent intent1 = new Intent(CameraSettingActivity.this, KibotSettingActivity.class);
//                    intent1.putExtra("sn", dev.getSn());
//                    startActivity(intent1);
                    KibotSettingActivity.startActivity(CameraSettingActivity.this, dev);
                } else {
                    if (ds != null) {
                        CLog.e("hyuan", "setting_v1=" + ds != null ? ds.getSetting_v1() : "null");
                    }
                    showCustomToast(getResources().getString(R.string.remote_set_not_support), Toast.LENGTH_SHORT);
                }
                break;
            }
            case R.id.del_device: {
                if (dev != null) {
                    if (dev.getRole() != 1) {
                        showCommonDialog(getString(R.string.remove_device_dialog_tips), getString(dev.getRole() == 1 ? R.string.remove_device_dialog_content_1 : R.string.remove_device_dialog_content),
                                getString(R.string.remove_device_dialog_ok), getString(R.string.remove_device_dialog_cancel),
                                new ArrayList<String>() {{
                                    add(getString(R.string.check_tips));
                                    add(getString(R.string.check_tips_1));
                                }},
                                dev.getRole() == 1, new ICommonDialog() {
                                    @Override
                                    public void onRightButtonClick(boolean... isChecked) {

                                    }

                                    @Override
                                    public void onLeftButtonClick(boolean... isChecked) {
                                        if (dev.getRole() == 1) {
                                            GlobalManager.getInstance().getCameraManager().asyncLoadUnBindDevice(dev.getSn(), isChecked[0] ? "1" : "0", isChecked[1] ? "1" : "0");
                                        } else {
                                            GlobalManager.getInstance().getShareManager().asyncShareCancel(dev.getSn(), dev.getQid());
                                        }
                                        showTipsDialog(getString(R.string.tips_49), R.drawable.icon_loading, 10000, true);
                                    }

                                    @Override
                                    public void onDialogCancel() {

                                    }
                                });
                    } else {
                        Intent intent1 = new Intent(CameraSettingActivity.this, DeleteDeviceActivity.class);
                        intent1.putExtra(DeviceInfo.class.getSimpleName(), dev);
                        startActivity(intent1);
                    }
                } else {
                    CameraToast.show(this, "DEV 是空的", Toast.LENGTH_LONG);
                    finish();
                }
                break;
            }
            case R.id.rl_member_more: {
                mIsMemberExpand = !mIsMemberExpand;
                if (mIsMemberExpand) {
                    mMemberMoreIv.setImageResource(R.drawable.cam_setting_up_arrow);
                    mFamilyMemberAdapter.setMaxCount(0);
                } else {
                    mMemberMoreIv.setImageResource(R.drawable.cam_setting_down_arrow);
                    int maxCount = 10;
                    mFamilyMemberAdapter.setMaxCount((dev.getRole() == 1 ? maxCount - 1 : maxCount));
                }
                break;
            }
        }
    }

    public boolean isUnset() {
        if (mRelationInfoEntity == null || mBabyInfoEntity == null) {
            return true;
        }
        if (dev.getRole() == 1) {
            return TextUtils.isEmpty(mRelationInfoEntity.relation_title) || mBabyInfoEntity.babysex == -1;
        } else {
            return TextUtils.isEmpty(mRelationInfoEntity.relation_title);
        }
    }

    @Override
    public void finish() {
        if (camAlertDialog != null) {
            camAlertDialog.dismiss();
        }
        if (mBabyInfoEntity != null && !TextUtils.isEmpty(mBabyInfoEntity.babyname)) {
            Intent intent = new Intent();
            intent.putExtra("title", mBabyInfoEntity.babyname);
            setResult(MainActivity.CAMERA_SETTING_CHANGE, intent);
        }
        super.finish();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Constants.TAG_LIST.remove(8);
        Constants.TAG_LIST.add("其他");
        OkHttpUtils.getInstance().cancelTag(this);
        GlobalManager.getInstance().getCommonManager().removeActionListener(this);
        GlobalManager.getInstance().getUserInfoManager().removeActionListener(this);
        GlobalManager.getInstance().getShareManager().removeActionListener(this);
        GlobalManager.getInstance().getNeverKillManager().removeActionListener(this);
        GlobalManager.getInstance().getCameraManager().removeActionListener(this);
        unregisterReceiver(refreshInvitedAndInvitingListReceiver);
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case CHANGE_TITLE:
                if (data != null && !TextUtils.isEmpty(data.getStringExtra("babyInfo"))) {
                    String babyInfo = data.getStringExtra("babyInfo");
                    String filePath = data.getStringExtra("filePath");
                    Gson gson = new Gson();
                    mBabyInfoEntity = gson.fromJson(babyInfo, BabyInfoEntity.class);
                    if (mAppGetInfoEntity != null) {
                        if(!TextUtils.isEmpty(filePath)){
                            mAppGetInfoEntity.data.avatarUrl = filePath;
                        }
                        refreshView(mAppGetInfoEntity.data.avatarUrl);
                    }
                }
                break;
            case 1005:
                if (data != null) {
                    mSelect = data.getIntExtra("select", 0);
                    mRelaxTv.setText(Constants.TAG_LIST.get(mSelect));
                }
                break;
            case Constants.PHONE_LIST:
                if (data != null) {
                    final Contacts contact = (Contacts) data.getSerializableExtra("contact");
                    if (contact != null && !TextUtils.isEmpty(contact.getPhoneNumber())) {
                        showCommonDialog(getString(R.string.tips_21),
                                getString(R.string.tips_22, contact.getPhoneNumber()),
                                getString(R.string.tips_23), getString(R.string.tips_24), "", false, new ICommonDialog() {
                                    @Override
                                    public void onRightButtonClick(boolean... isChecked) {
                                        try {
                                            GlobalManager.getInstance().getShareManager().asyncShareShare(dev.getSn(), "3", Utils.checkPhoneNum(contact.getPhoneNumber()), Constants.DeviceType.KIBOTMACHINE);
                                            showTipsDialog(getString(R.string.tips_25), R.drawable.icon_loading, true);
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    }

                                    @Override
                                    public void onLeftButtonClick(boolean... isChecked) {

                                    }

                                    @Override
                                    public void onDialogCancel() {

                                    }
                                });
                    }
                }
                break;
            case EDIT_FAMILY:
                refreshList();
                break;
         /*   case PadHeadFragment.REQUEST_CROP_PHOTO: {
                if (mUserHeadBitmap != null) {
                    modifyUserHead(mUserHeadBitmap);
                    CameraToast.show("读取图片成功", Toast.LENGTH_SHORT);
                } else {
                    CameraToast.show("读取图片失败", Toast.LENGTH_SHORT);
                }
                break;
            }*/
            default:
                break;
        }
    }

    @Override
    public Object actionPerformed(int actionCode, Object... args) {
        switch (actionCode) {
            case  Actions.Common.EXIT:{
                finish();
                return Boolean.TRUE;
            }
            case Actions.UserInfo.APP_GET_INFO_SUCCESS: {
                mAppGetInfoEntity = (AppGetInfoEntity) args[0];
                String extend = mAppGetInfoEntity.data.babyInfo;
                Gson gson = new Gson();
                mBabyInfoEntity = gson.fromJson(extend, BabyInfoEntity.class);
                String relation = mAppGetInfoEntity.data.relation;
                mRelationInfoEntity = gson.fromJson(relation, RelationInfoEntity.class);
                refreshView(mAppGetInfoEntity.data.avatarUrl);

                refreshList();

                return Boolean.TRUE;
            }
            case Actions.UserInfo.APP_GET_INFO_FAIL: {
                mMemberMoreRl.setVisibility(View.GONE);
                hideTipsDialog();
                if (args == null || args.length == 0) {
//                    CameraToast.showErrorToast(this, "请求失败");
                } else {
                    CameraToast.showErrorToast((String) args[0]);
                }
                return Boolean.TRUE;
            }
            case Actions.Share.SHARE_GET_LIST_SUCCESS: {
                hideTipsDialog();
                ShareGetListEntity shareGetListEntity = (ShareGetListEntity) args[0];
                if (shareGetListEntity != null) {
                    int size = shareGetListEntity.data.data.size();
                    for (int i = 0; i < size; ++i) {
                        ShareUserEntity entity = shareGetListEntity.data.data.get(i);
                        if (entity.role.equals("1")) {
                            Glide.with(CameraSettingActivity.this)
                                    .load(entity.imgUrl)
                                    .transform(new GlideCircleTransform(Utils.context))
                                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                                    .error(R.drawable.icon_avator_empty)
                                    .into(mMasterIv);

                            String name = (entity.getRelationId() == 0 && entity.getRelation().equals("未设置")) ? entity.nickName : entity.getRelation();
                            name = TextUtils.isEmpty(name) ? entity.phone : name;
                            name = TextUtils.isEmpty(name) ? entity.userName : name;
                            if (entity.phone != null && entity.phone.equals(AccUtil.getInstance().getSecPhoneNumber())) {
                                name = "我(" + name + ")";
                            }

                            mMasterTv.setText(name);

                            shareGetListEntity.data.data.remove(entity);
                            break;
                        }
                    }

                    int maxCount = 10;
                    maxCount = (dev.getRole() == 1 ? maxCount - 1 : maxCount);
                    size = shareGetListEntity.data.data.size();
                    if (size > maxCount) {
                        mMemberMoreRl.setVisibility(View.VISIBLE);
                        mMemberMoreTv.setText(getString(R.string.member_more, size));
                        if (mIsMemberExpand) {
                            maxCount = size;
                        }
                    } else {
                        mMemberMoreRl.setVisibility(View.GONE);
                        maxCount = size;
                    }

                    mFamilyMemberAdapter.setData(shareGetListEntity, maxCount);
                    if (mFamilyMemberAdapter.getShareListCount() > maxCount) {
                        Utils.ensureVisbility(View.VISIBLE, mMemberMoreRl);
                    } else {
                        Utils.ensureVisbility(View.GONE, mMemberMoreRl);
                    }
                }
                return Boolean.TRUE;
            }
            case Actions.Share.SHARE_GET_LIST_FAIL: {
                hideTipsDialog();
                if (args == null || args.length == 0) {
                    CameraToast.showErrorToast(this, "发送请求失败");
                } else {
                    CameraToast.showErrorToast(args[0] + "");
                }
                return Boolean.TRUE;
            }
            case Actions.Share.SHARE_CANCEL_SUCCESS: {
                CameraToast.showToast(this, R.string.unbind_device_suc);
//                Preferences.saveSelectedPad("");
//                GlobalManager.getInstance().getCameraManager().asyncLoadMyCamera(0);
                hideTipsDialog();
                if (Preferences.getSelectedPad().equals(dev.getSn())) {
                    Preferences.saveSelectedPad("");
                }
                PadInfoWrapper.getInstance().deletePadBySnQid(dev.getSn(), AccUtil.getInstance().getQID());
                GlobalManager.getInstance().getCameraManager().publishAction(Actions.Camera.DELTET_SN, dev.getSn());
                GlobalManager.getInstance().getCommonManager().publishAction(Actions.Common.UNBIND_SUCCESS_UPDATE);
                finish();
                return Boolean.TRUE;
            }
            case Actions.Share.SHARE_CANCEL_FAIL: {
                CameraToast.showErrorToast(this, R.string.unbind_device_fail);
                hideTipsDialog();
                return Boolean.TRUE;
            }
            case Actions.Share.SHARE_RESPONSE_SUCCESS: {
                refreshList();
                return Boolean.TRUE;
            }
            case Actions.Camera.UN_BIND_DEVICE_SUCCESS: {
                PhoneRecordWrapper.getInstance(CameraSettingActivity.this).updatePhoneRecordStateBySn(dev.getSn());
                CameraToast.showToast(Utils.context, R.string.unbind_device_suc);
                hideTipsDialog();
                GlobalManager.getInstance().getCommonManager().publishAction(Actions.Common.EXIT);
                GlobalManager.getInstance().getCommonManager().publishAction(Actions.Common.UNBIND_SUCCESS_UPDATE);
                finish();
                return Boolean.TRUE;
            }
            case Actions.Camera.UN_BIND_DEVICE_FAIL: {
                CameraToast.showToast(Utils.context, R.string.unbind_device_fail);
                hideTipsDialog();
                return Boolean.TRUE;
            }
            case Actions.Share.SHARE_FRIEND_RESPONSE_SUCCESS: {
                String agree = (String) args[0];
                //刷新机器人成员管理列表
                if (agree.equals("1")) {
                    refreshList();
                }
                return Boolean.TRUE;
            }
        }
        return null;
    }

    private void refreshView(String url) {
        mBabyNameTv.setText(mBabyInfoEntity.babyname);
        if (mBabyInfoEntity.babysex != -1) {
            mBabySexTv.setText(mBabyInfoEntity.babysex == 0 ? getString(R.string.baby_sex_male) : getString(R.string.baby_sex_female));
        } else {
            mBabySexTv.setText(getString(R.string.tips_56));
        }

        mBabyBirthTv.setText(Utils.DATE_FORMAT_5.format(mBabyInfoEntity.babybirth * 1000));
        mBabyAgeTv.setText(PhoneUtil.formatSecond(this, mBabyInfoEntity.babybirth * 1000));
        if (mRelationInfoEntity == null) {
            mRelationInfoEntity = new RelationInfoEntity(mSelect, Constants.TAG_LIST.get(mSelect));
        }
        if (mRelationInfoEntity.relation_tag == 8) {
            Constants.TAG_LIST.remove(8);
            Constants.TAG_LIST.add(mRelationInfoEntity.relation_title);
        }
        if (dev.getRole() == 1) {
            mRelaxTv.setText(TextUtils.isEmpty(mRelationInfoEntity.relation_title) || mBabyInfoEntity.babysex == -1 ? getString(R.string.baby_relax_unset) : mRelationInfoEntity.relation_title);
        } else {
            mRelaxTv.setText(TextUtils.isEmpty(mRelationInfoEntity.relation_title) ? getString(R.string.baby_relax_unset) : mRelationInfoEntity.relation_title);
        }
        CLog.e("camera_setting", url);
//        Glide.with(CameraSettingActivity.this)
//                .load(url)
//                .transform(new GlideCircleTransform(Utils.context))
//                .diskCacheStrategy(DiskCacheStrategy.ALL)
//                .error(R.drawable.icon_avator_empty)
//                .into(new MyBitmapImageViewTarget(mAvatorIv));
        Glide.with(CameraSettingActivity.this)
                .load(url)
                .transform(new GlideCircleTransform(Utils.context))
                .centerCrop()
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .placeholder(R.drawable.icon_avator_empty)
                .into(mAvatorIv);
    }

    @Override
    public int getProperty() {
        return 0;
    }

    public String getSn() {
        return dev.getSn();
    }

    private void showInviteFriend() {
        // 平板加平板
        Intent intent = new Intent(this, BindDeviceFrameActivity.class);
        intent.putExtra("mode", BindDeviceFrameActivity.MODE_FRIEND_FIND);
        intent.putExtra("sn", dev.getSn());
        startActivity(intent);
    }

    private void showBindPhone() {
        // 手机号直接绑定
        Intent intent = new Intent(this, BindDeviceFrameActivity.class);
        intent.putExtra("mode", BindDeviceFrameActivity.MODE_BIND_PHONE);
        intent.putExtra("sn", dev.getSn());
        intent.putExtra(StoryMachineConsts.KEY_SET_DEVICE_TYPE,dev.deviceType);
        startActivity(intent);
    }

    private void sendtoWChat() {
        if (Utils.isNetworkAvailable(this)) {
            GlobalManager.getInstance().getShareManager().asyncShareShare(dev.getSn(), "2", "",  Constants.DeviceType.KIBOTMACHINE);
        } else {
            CameraToast.show(null, R.string.network_disabled, Toast.LENGTH_SHORT);
        }
    }

    private void sendtoSMS() {
        if (Utils.isNetworkAvailable(this)) {
            Intent intent = new Intent(this, ChooseContactActivity.class);
            intent.putExtra(Constants.SHARE_TYPE, Constants.ShareType.SHARE_TYPE_MOBILE);
            startActivityForResult(intent, Constants.PHONE_LIST);
        } else {
            CameraToast.show(null, R.string.network_disabled, Toast.LENGTH_SHORT);
        }
    }

    private void qrShare() {
        if (Utils.isNetworkAvailable(this)) {
            Intent intent = new Intent(this, ShareQRActivity.class);
            intent.putExtra("sn", dev.getSn());
            intent.putExtra(Constants.SHARE_TYPE, Constants.ShareType.SHARE_TYPE_QRCODE);
            startActivityForResult(intent, Constants.PHONE_QR);
        } else {
            CameraToast.show(null, R.string.network_disabled, Toast.LENGTH_SHORT);
        }
    }

    public void refreshList() {
        GlobalManager.getInstance().getShareManager().asyncShareGetList(dev.getSn(), "0", "50");
    }
}
