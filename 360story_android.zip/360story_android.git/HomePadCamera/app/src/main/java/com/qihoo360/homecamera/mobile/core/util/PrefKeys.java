
package com.qihoo360.homecamera.mobile.core.util;

public interface PrefKeys {
    
    
}
