
package com.qihoo360.homecamera.machine.activity;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.activity.BaseActivity;
import com.qihoo360.homecamera.mobile.utils.Utils;

public class AddCameraActivity extends MachineBaseActivity {
    boolean isFromSafe;
    TextView msg;

    @Override
    protected void onCreate(Bundle arg0) {
        super.onCreate(arg0);
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            isFromSafe = !TextUtils.isEmpty(bundle.getString("from", ""));
        }
        initView();
    }

    private void initView() {
        setTintManagerQWork(true);
        tintManager.setStatusBarTintColor(Color.parseColor("#0000aeff"));
        setContentView(R.layout.activity_add_machine);
        msg = (TextView) findViewById(R.id.subtitle);
        msg.setText(getString(R.string.add_only_3step_home_old));
        if (isFromSafe) {
            Utils.ensureVisbility(View.GONE, findViewById(R.id.btn_accept_camera));
        }
        //Utils.ensureVisbility(View.GONE, findViewById(R.id.btn_buy_camera));
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        finish();
        overridePendingTransition(R.anim.left_in, R.anim.right_out);
    }

    public void onNext(View v) {
        switch (v.getId()) {
            case R.id.btn_conn_camera:
                Intent intentCoon = new Intent(this, SetupGuideActivity.class);
                intentCoon.putExtra("directSource", 1);
                startActivity(intentCoon);
                overridePendingTransition(0, 0);
                break;
            case R.id.btn_buy_camera:
                String url = Utils.getContext().getResources().getString(R.string.name_camera_purchase_url); // web address
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                startActivity(intent);
                break;
            case R.id.btn_accept_camera:
                startActivity(new Intent(this, AcceptShareActivity.class));
                break;
            default:
                break;
        }
    }
}
