package com.qihoo360.homecamera.device.config;

/**
 * HomePadCamera
 * Description:
 * Created by liujunbin
 * on 2017/6/19.
 */

public class StoryMachineConsts {
    /**
     * WIFI
     */
    public static final String KEY_SET_WIFI_FROM = "key_set_wifi_from";
    public static final String VALUE_SET_WIFI_FROM_BIND = "set_wifi_from_bind";
    public static final String VALUE_SET_WIFI_FROM_WIFI = "set_wifi_from_wifi";

    /**
     * push message
     */
    public static final String KEY_PUSH_MESSAGE_ONLINE = "key_push_online_message";

    /**
     * 网上商城地址
     */
    public static final String E_SHOPPING_URL = "http://gushiji.360.cn";

    /**
     * WIFI
     */
    public static final String KEY_SET_DEVICE_TYPE = "key_set_device_type";
    public static final String VALUE_SET_MACHINE_TYPE_603 = "2";
    public static final String VALUE_SET_MACHINE_TYPE_605 = "3";

    /**
     * Push key
     */
    public static final String PUSH_KEY_SN = "sn";
    public static final String PUSH_KEY_FROM = "from";
    public static final String PUSH_KEY_DEVICE = "device";
    public static final String PUSH_KEY_TASKID = "taskId";
    public static final String PUSH_KEY_VER = "ver";
    public static final String PUSH_KEY_VERSION = "version";
    public static final String PUSH_VALUE_VERSION_ANDROID = "Android-";

    public static final String PUSH_VALUE_FROM_ANDROID = "mpc_pingmuban_and";
    public static final String PUSH_VALUE_DEVICE_STORY_APP = "story";
    public static final String PUSH_VALUE_DEVICE_KIBOT_APP = "kibot";

    public static final int SPLASH_START_TIME = 20170801;
    public static final int SPLASH_END_TIME = 20170807;



}
