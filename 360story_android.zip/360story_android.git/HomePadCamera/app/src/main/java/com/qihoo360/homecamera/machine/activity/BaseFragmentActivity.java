
package com.qihoo360.homecamera.machine.activity;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.activity.BaseActivity;

public abstract class BaseFragmentActivity extends MachineBaseActivity {

    private int status;
    private Bundle bundle;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTintManagerQWork(true);
        tintManager.setStatusBarTintColor(Color.parseColor("#00aeff"));
        setContentView(R.layout.activity_common_fragment);
        try {
            boolean hasCategory = getIntent().hasExtra("fragmentId");
            if (hasCategory == true) {
                status = getIntent().getIntExtra("fragmentId", 0);
            }
        } catch (Exception e) {
        }
        bundle = getIntent().getExtras();
        findViewById(R.id.common_fragment_title_orange).setVisibility(View.GONE);
        findViewById(R.id.common_fragment_title_white).setVisibility(View.GONE);
        // TODO 三级页入口区分
//        if (status == ThreeLevelActivity.BROAD_CAST_MESSAGE || status == ThreeLevelActivity.LIVE_TOPIC_SHARE || status == ThreeLevelActivity.HOEM_AD_URL) {
//            setReplaceFragment(getIntent().getStringExtra("url"));
//        } else {
            setReplaceFragment("");
//        }
    }


    protected void setTitleText(int tid) {
        TextView tvTitle = (TextView) ((findViewById(R.id.common_fragment_title_blue))
                .findViewById(R.id.common_title_text));
        tvTitle.setText(tid);
    }

    protected void setTitleText(String title) {
        TextView tvTitle = (TextView) ((findViewById(R.id.common_fragment_title_blue))
                .findViewById(R.id.common_title_text));
        tvTitle.setText(title);
    }

    protected void setRightBtnText(int rid) {
        Button btnRight = (Button) findViewById(R.id.common_fragment_title_blue)
                .findViewById(R.id.btn_right);
        btnRight.setVisibility(View.VISIBLE);
        btnRight.setText(rid);
    }

    public int getStatus() {
        return status;
    }

    public Bundle getBundle() {
        return bundle;
    }

    protected void replaseFragment(Fragment fragment) {
        FragmentTransaction beginTransaction = getSupportFragmentManager()
                .beginTransaction();
        beginTransaction.replace(R.id.common_fragment, fragment)
                .commitAllowingStateLoss();
        beginTransaction = null;
    }

    /*public void onBack(View v) {
        finish();
    }*/

    protected abstract void setReplaceFragment(String url);

}
