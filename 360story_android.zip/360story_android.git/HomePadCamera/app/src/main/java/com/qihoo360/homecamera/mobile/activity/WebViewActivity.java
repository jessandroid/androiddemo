
package com.qihoo360.homecamera.mobile.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnLongClickListener;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.DownloadListener;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.config.Const;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.widget.CommonWebView;
import com.qihoo360.homecamera.mobile.widget.listview.PullToRefreshBase;
import com.qihoo360.homecamera.mobile.widget.listview.PullToRefreshWebView;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 * Created by Administrator on 2014/11/10.
 */
public class WebViewActivity extends BaseActivity implements View.OnClickListener {

    private CommonWebView mWebContent;
    private PullToRefreshWebView pullWebV;
    private String mWebViewUrl;
    private boolean disableRefresh = false;
    private ProgressBar mPbWebView;
    private String errorHtml = "";
    private LinearLayout mErrorAreaLl;
    private TextView mRetryTv;
    private ImageView mBackIv;
    private TextView mTitleTv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mWebViewUrl = getIntent().getStringExtra("url");

        if (TextUtils.isEmpty(mWebViewUrl)) {
            finish();
        }
        disableRefresh = getIntent().getBooleanExtra("disableRefresh", true);

        setContentView(R.layout.fragment_web_purchase);
        LinearLayout linearLayout_webView = (LinearLayout) findViewById(R.id.linearLayout_webView);
        if (Const.FIND_PWD.equals(mWebViewUrl)) {
            linearLayout_webView.scrollBy(0, getResources()
                    .getDimensionPixelSize(R.dimen.webTitleHeight));
        }
        mErrorAreaLl = (LinearLayout) findViewById(R.id.ll_error_area);
        mRetryTv = (TextView) findViewById(R.id.tv_retry);
        mRetryTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mWebContent.clearCache(true);
                mWebContent.clearHistory();
                mWebContent.loadUrl(mWebViewUrl);
                Utils.ensureVisbility(View.GONE, mErrorAreaLl);
            }
        });
        mBackIv = (ImageView) findViewById(R.id.iv_back);
        mBackIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        mTitleTv = (TextView) findViewById(R.id.tv_title);
        mPbWebView = (ProgressBar) findViewById(R.id.pb);
        pullWebV = (PullToRefreshWebView) findViewById(R.id.webview);
        pullWebV.setPullToRefreshOverScrollEnabled(false);
        mWebContent = pullWebV.getRefreshableView();
        mWebContent.clearCache(true);
        mWebContent.clearHistory();
        pullWebV.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<CommonWebView>() {

            @Override
            public void onRefresh(PullToRefreshBase<CommonWebView> refreshView) {
                mWebContent.onPause();
                mWebContent.clearCache(true);
                mWebContent.clearHistory();
                mWebContent.loadUrl(mWebViewUrl);
            }
        });
        if (disableRefresh) {
            pullWebV.setMode(PullToRefreshBase.Mode.DISABLED);
        }

        mWebContent.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String s, String s1, String s2, String s3, long l) {
                Uri uri = Uri.parse(s);
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });
        mWebContent.getSettings().setJavaScriptEnabled(true);
        mWebContent.setWebViewClient(new WebViewViewClient());
        mWebContent.setWebChromeClient(new WebViewChromeClient());
        if (Utils.isHCOrLater())
            mWebContent.removeJavascriptInterface("searchBoxJavaBridge_");
        if (mWebViewUrl.startsWith("http://") || mWebViewUrl.startsWith("https://")) {
            synCookies(mWebViewUrl);
            mWebContent.loadUrl(mWebViewUrl);
        } else {
            //            pullWebV.setMode(PullToRefreshBase.Mode.DISABLED);
        }

        mWebContent.setOnLongClickListener(new OnLongClickListener() {

            @Override
            public boolean onLongClick(View arg0) {
                return true;
            }
        });
    }

    public void synCookies(String url) {
        CookieSyncManager.createInstance(Utils.getContext());
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.removeSessionCookie();//移除  
        cookieManager.setCookie("mall.360.com", "T=" + AccUtil.getInstance().getT());//
        cookieManager.setCookie("mall.360.com", "Q=" + AccUtil.getInstance().getQ());//
        cookieManager.setCookie("360pay.cn", "T=" + AccUtil.getInstance().getT());//
        cookieManager.setCookie("360pay.cn", "Q=" + AccUtil.getInstance().getQ());//
        cookieManager.setCookie(url, "T=" + AccUtil.getInstance().getT() + ";path=/; domain=360.cn; httponly");// cookies是在HttpClient中获得的cookie
        cookieManager.setCookie(url, "Q=" + AccUtil.getInstance().getQ() + ";path=/;domain=360.cn");
        CookieSyncManager.getInstance().sync();
    }

    @Override
    public void onBackPressed() {
        if (mWebContent.canGoBack()) {
            mWebContent.goBack();
            CLog.e("onBackPressed", mWebContent.getUrl());
            if (!mWebContent.getUrl().equals("file:///android_asset/error.html")) return;
        } else {
            finish();
        }
//        super.onBackPressed();
    }

    @Override
    public void onPause() {
        if (mWebContent != null) {
            mWebContent.reload();
        }
        super.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mWebContent != null) {
            mWebContent.onPause();
            mWebContent.destroy();
            mWebContent = null;
        }
    }

    public void doReloadWebView() {
        if (mWebContent != null) {
            mWebContent.reload();
        }
    }

    class WebViewViewClient extends WebViewClient {

        @Override
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            super.onReceivedError(view, errorCode, description, failingUrl);
            mPbWebView.setMax(100);
            pullWebV.onRefreshComplete();
            view.loadUrl(Utils.getCurrentLauguage().equals("zh") ? "file:///android_asset/error.html" : "file:///android_asset/error_en.html");
            CLog.d("--------------------->");
            Utils.ensureVisbility(View.VISIBLE, mPbWebView, mErrorAreaLl);
        }



    }

    class WebViewChromeClient extends WebChromeClient {

        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            mPbWebView.setProgress(newProgress);
            if (newProgress == 100) {
                mPbWebView.setVisibility(View.GONE);
                pullWebV.onRefreshComplete();
            }
            super.onProgressChanged(view, newProgress);
        }

        @Override
        public void onReceivedTitle(WebView view, String title) {
            super.onReceivedTitle(view, title);
            if (!mWebViewUrl.replace("http://", "").replace("https://", "").equals(title)) {
                mTitleTv.setText(title);
                CLog.e("aaaa", title);
            }
        }
    }

    @Override
    public void onClick(View v) {
        // if (v.getId() == R.id.btn_webvie_back) {
        // if (mWebContent.canGoBack()) {
        // mWebContent.goBack();
        // }
        // } else if (v.getId() == R.id.btn_webvie_refresh) {
        // mWebContent.reload();
        // } else if (v.getId() == R.id.btn_webvie_home) {
        // mWebContent.loadUrl(mWebViewUrl);
        // }
    }

    public String getFromAssets(String fileName) {
        try {
            InputStreamReader inputReader = new InputStreamReader(
                    getResources().getAssets().open(fileName));
            BufferedReader bufReader = new BufferedReader(inputReader);
            String line = "";
            String Result = "";
            while ((line = bufReader.readLine()) != null)
                Result += line;
            if (bufReader != null)
                bufReader.close();
            if (inputReader != null)
                inputReader.close();
            return Result;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
