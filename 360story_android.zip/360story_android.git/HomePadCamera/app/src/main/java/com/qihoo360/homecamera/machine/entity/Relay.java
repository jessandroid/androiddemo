package com.qihoo360.homecamera.machine.entity;

import android.os.Parcel;
import android.os.Parcelable;

import com.qihoo360.homecamera.mobile.entity.Head;

import java.util.List;

public class Relay extends Head {

    public Data data;

    public Data getData() {
        return data;
    }

    public static class Data{

        public String playKey = "";

        public RelayInfo relayInfo;


        public String getPlayKey() {
            return playKey;
        }

        public RelayInfo getRelayInfo() {
            return relayInfo;
        }

        public class RelayInfo implements Parcelable {

            public List<String> ipInfo;//Relay的ip地址--对应之前的relay
            public String sig;     //Relay的连接签名--relaySig和sig
            public String cluster; //Relay的机房--对应之前的relayId
            public String liveId;//Relay的流--对应之前的relayStream

            public List<String> getIpInfo() {
                return ipInfo;
            }

            public String getLiveId() {
                return liveId;
            }

            public String getSig() {
                return sig;
            }

            public String getCluster() {
                return cluster;
            }

            @Override
            public int describeContents() {
                return 0;
            }

            @Override
            public void writeToParcel(Parcel dest, int flags) {
                dest.writeStringList(this.ipInfo);
                dest.writeString(this.sig);
                dest.writeString(this.cluster);
                dest.writeString(this.liveId);
            }

            public RelayInfo() {
            }

            protected RelayInfo(Parcel in) {
                this.ipInfo = in.createStringArrayList();
                this.sig = in.readString();
                this.cluster = in.readString();
                this.liveId = in.readString();
            }

            public final Creator<RelayInfo> CREATOR = new Creator<RelayInfo>() {
                @Override
                public RelayInfo createFromParcel(Parcel source) {
                    return new RelayInfo(source);
                }

                @Override
                public RelayInfo[] newArray(int size) {
                    return new RelayInfo[size];
                }
            };

            @Override
            public String toString() {
                return "(ipInfo=" + ipInfo + ",sig=" + sig + ",cluster=" + cluster + ",liveId=" + liveId + ")";
            }
        }

        @Override
        public String toString() {
            return "(playKey=" + playKey + ",relayInfo=" + relayInfo + ")";
        }
    }

    @Override
    public String toString() {
        return "(data=" + data + ")";
    }
}
