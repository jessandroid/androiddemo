package com.qihoo360.homecamera.mobile.activity;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.ImageView;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.adapter.StoryHistoryFragmentAdapter;
import com.qihoo360.homecamera.mobile.entity.DeviceInfo;
import com.qihoo360.homecamera.mobile.ui.fragment.StoryHistoryFailFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.StoryHistorySuccFragment;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.widget.TextViewWithFont;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class StoryHistoryListAllActivity extends BaseActivity {

    @Bind(R.id.back_zone)
    public ImageView backZone;
    @Bind(R.id.title_string)
    public TextViewWithFont titleString;
    @Bind(R.id.tv_right_button)
    public TextViewWithFont tvRightButton;
    @Bind(R.id.tabs)
    public TabLayout mTabLayout;
    @Bind(R.id.viewpager)
    public ViewPager mViewPager;

    private String[] titles;
    private StoryHistoryFragmentAdapter mFragmentAdapteradapter;
    public DeviceInfo deviceInfo;
    private boolean check;
    public StoryHistorySuccFragment storyhistorysuccfragment;

    private StoryHistoryFailFragment storyhistoryfailfragment;

    private int selected = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle b = getIntent().getBundleExtra("Bundle");
        deviceInfo = b.getParcelable("deviceInfo");
        setContentView(R.layout.activity_story_list_all);
        ButterKnife.bind(this);
        initViewPager();
        tvRightButton.setText(R.string.choose);
        tvRightButton.setVisibility(View.GONE);
    }

    private void initViewPager() {
        titles = getResources().getStringArray(R.array.story_title_history);
        mTabLayout.setTabMode(TabLayout.MODE_FIXED);
        mTabLayout.setTabGravity(TabLayout.GRAVITY_FILL);
        final List<Fragment> fragments = new ArrayList<>();
        for (int i = 0; i < titles.length; i++) {
            switch (i) {
                case 0:
                    storyhistorysuccfragment = StoryHistorySuccFragment.newInstance();
                    fragments.add(storyhistorysuccfragment);
                    break;
                case 1:
                    storyhistoryfailfragment = StoryHistoryFailFragment.newInstance();
                    fragments.add(storyhistoryfailfragment);
                    break;
            }
        }
        for (int i = 0; i < mTabLayout.getTabCount(); i++) {
            TabLayout.Tab tab = mTabLayout.getTabAt(i);
            tab.setText(titles[i]);
        }
        mFragmentAdapteradapter = new StoryHistoryFragmentAdapter(getSupportFragmentManager(), fragments, titles);
        mViewPager.setAdapter(mFragmentAdapteradapter);
        mTabLayout.setupWithViewPager(mViewPager);
        mViewPager.setOffscreenPageLimit(0);

        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }

            @Override
            public void onPageSelected(int position) {
                selected = position;
                Utils.ensureVisbility(tvRightButton, View.VISIBLE);
                switch (position) {
                    case 0: {
                        int itemCount = 0;
                        if (storyhistorysuccfragment != null) {
                            if (storyhistorysuccfragment.linearAdapter != null) {
                                itemCount = storyhistorysuccfragment.linearAdapter.getItemCount();
                            }
                        }
                        if (itemCount - 2 <= 0) {
                            CLog.i("test2", "case 0 itemCount = " + itemCount);
                            Utils.ensureVisbility(tvRightButton, View.GONE);
                        }
                        if (storyhistorysuccfragment != null && storyhistorysuccfragment.isCheckModel()) {
                            if (storyhistorysuccfragment.swipeRefreshLayout != null) {
                                storyhistorysuccfragment.swipeRefreshLayout.setEnabled(false);
                            }
                            tvRightButton.setText(R.string.cancel);
                        } else {
                            tvRightButton.setText(R.string.choose);
                            if (storyhistorysuccfragment != null && storyhistorysuccfragment.swipeRefreshLayout != null) {
                                storyhistorysuccfragment.swipeRefreshLayout.setEnabled(true);
                            }
                        }
                        break;
                    }
                    case 1: {
                        int itemCount = 0;
                        if (storyhistoryfailfragment != null) {
                            if (storyhistoryfailfragment.linearAdapter != null) {
                                itemCount = storyhistoryfailfragment.linearAdapter.getItemCount();
                            }
                        }
                        if (itemCount - 1 <= 0) {
                            CLog.i("test2", "case 1 itemCount = " + itemCount);
                            Utils.ensureVisbility(tvRightButton, View.GONE);
                        }
                        if (storyhistoryfailfragment.isCheckModel()) {
                            tvRightButton.setText(R.string.cancel);
                            if (storyhistoryfailfragment != null && storyhistorysuccfragment.swipeRefreshLayout != null) {
                                storyhistoryfailfragment.swipeRefreshLayout.setEnabled(false);
                            }

                        } else {
                            tvRightButton.setText(R.string.choose);
                            if (storyhistoryfailfragment != null && storyhistoryfailfragment.swipeRefreshLayout != null)
                                storyhistoryfailfragment.swipeRefreshLayout.setEnabled(true);
                        }
                        break;
                    }
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        mTabLayout.setTabsFromPagerAdapter(mFragmentAdapteradapter);
    }

    @OnClick({R.id.back_zone, R.id.tv_right_button})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.back_zone:
                finish();
                break;
            case R.id.tv_right_button:
                switch (mViewPager.getCurrentItem()) {
                    case 0: {
                        check = !check;
                        storyhistorysuccfragment.setChooseModel(check);
                        if (storyhistorysuccfragment.linearAdapter.getCheckModel()) {
                            tvRightButton.setText(R.string.cancel);
                        } else {
                            storyhistorysuccfragment.mDelStory.setText("删除");
                            tvRightButton.setText(R.string.choose);
                        }
                        break;
                    }
                    case 1: {
                        check = !check;
                        storyhistoryfailfragment.setChooseModel(check);
                        if (storyhistoryfailfragment.linearAdapter.getCheckModel()) {
                            tvRightButton.setText(R.string.cancel);
                        } else {
                            storyhistoryfailfragment.mDelStory.setText("删除");
                            tvRightButton.setText(R.string.choose);
                        }
                        break;
                    }
                }

                break;

        }
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public void onBackPressed() {
        if (selected == 0) {
            if (storyhistorysuccfragment.isCheckModel()) {
                storyhistorysuccfragment.setChooseModel(false);
                tvRightButton.setText(R.string.choose);
            } else {
                super.onBackPressed();
            }
        } else if (selected == 1) {
            if (storyhistoryfailfragment.isCheckModel()) {
                storyhistoryfailfragment.setChooseModel(false);
                tvRightButton.setText(R.string.choose);
            } else {
                super.onBackPressed();
            }
        } else {
            super.onBackPressed();

        }
    }
}
