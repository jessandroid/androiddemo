package com.qihoo360.homecamera.mobile.db;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;

import com.qihoo360.homecamera.machine.entity.FamilyMessageEntity;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.Preferences;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * Created by zt
 * desc:
 */
public class FamilyGroupWrapper extends AbstractWrapper {

    public static final String TABLE_NAME = "family_group";
    private static FamilyGroupWrapper mInstance;

    public static FamilyGroupWrapper getInstance() {
        if (mInstance == null) {
            synchronized (FamilyGroupWrapper.class) {
                if (mInstance == null) {
                    mInstance = new FamilyGroupWrapper();

                }
            }
        }
        return mInstance;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int toVersion) {
        switch (toVersion){
            case  10:
                db.execSQL("CREATE TABLE IF NOT EXISTS family_group (_id INTEGER, sn varchar(255,0), msgId varchar(255,0), msgType INTEGER, relation varchar(255,0), avatarUrl varchar(255,0), owner INTEGER, content varchar(255,0),packageId varchar(255,0), cachePath varchar(255,0), msgState INTEGER, msgSize INTEGER, isPlaying INTEGER, sendTime INTEGER, hadRead INTEGER, uniqueId varchar(255,0),PRIMARY KEY(_id));");
                break;
        }
    }

    @Override
    public void onOpen(SQLiteDatabase db) {

    }

    //插入一条消息记录
    public synchronized boolean insertChatMsg(FamilyMessageEntity messageEntity){
        try{
            SQLiteDatabase sqLiteDatabase = GlobalManager.getInstance().config().db.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(Field.KEY_SN, messageEntity.getSn());
            values.put(Field.KEY_MSGTYPE, messageEntity.getMsgType());
            values.put(Field.KEY_AVATARURL, messageEntity.getAvatarUrl());
            values.put(Field.KEY_OWNER, messageEntity.getOwner());
            values.put(Field.KEY_RELATION, messageEntity.relation==null ? "" : messageEntity.getRelation());
            values.put(Field.KEY_CONTENT, messageEntity.getContent());
            values.put(Field.KEY_CACHEPATH, messageEntity.getCachePath()==null ? "" : messageEntity.getCachePath());
            values.put(Field.KEY_MSGSTATE, messageEntity.getMsgState());
            values.put(Field.KEY_MSGSIZE, messageEntity.getMsgSize());
            values.put(Field.KEY_SENDTIME, messageEntity.getSendTime());
            values.put(Field.KEY_HADREAD, messageEntity.getHadRead());
            values.put(Field.KEY_PACKAGEID, messageEntity.getPackageId()==null ? "" : messageEntity.getPackageId());
            values.put(Field.KEY_UNIQUEID, messageEntity.getUniqueId());
            values.put(Field.KEY_ISPLAYING, messageEntity.getIsPlaying());
            values.put(Field.KEY_MSGID, messageEntity.getMsgId()==null ? "" : messageEntity.getMsgId());
            long effectCount = sqLiteDatabase.insert(TABLE_NAME, null, values);
            return effectCount>0;
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
    }

    //更新某条消息的某个或者多个字段
    public synchronized long updateChatInfo(String sn, String uniqueId, HashMap<String, Object> param){
        long effectCount;
        Iterator<Map.Entry<String, Object>> iterator = null;
        try{
            SQLiteDatabase sqLiteDatabase = GlobalManager.getInstance().config().db.getWritableDatabase();
            ContentValues values = new ContentValues();
            if(param==null || param.isEmpty()){
                return 0;
            }
            iterator = param.entrySet().iterator();
            while(iterator.hasNext()){
                Map.Entry<String, Object> entry = iterator.next();
                if(entry.getValue() instanceof Integer){
                    values.put(entry.getKey(), (int) entry.getValue());
                }else if(entry.getValue() instanceof String){
                    values.put(entry.getKey(), (String)entry.getValue());
                }
            }
           effectCount =  sqLiteDatabase.update(TABLE_NAME, values, Field.KEY_SN +"=? and "+Field.KEY_UNIQUEID+"=?", new String[]{sn, uniqueId});
        }catch (Exception e){
            e.printStackTrace();
            effectCount =  0;
        }finally {
          if(iterator!=null){
              iterator = null;
          }
        }
        return effectCount;
    }

    //获取某个故事机的最近的30条聊天数据（按时间倒序）
    public ArrayList<FamilyMessageEntity> getChatListBySn(String sn, int start){
        Cursor cursor = null;
        try{
            SQLiteDatabase sqLiteDatabase = GlobalManager.getInstance().config().db.getWritableDatabase();
            ArrayList<FamilyMessageEntity> chatList = new ArrayList<>();
            String limit = "LIMIT 30 OFFSET "+ start;
            cursor = sqLiteDatabase.query(TABLE_NAME, null, "sn = ?", new String[]{sn}, null, null, Field.KEY_SENDTIME+" desc "+ limit);
            if(cursor.getCount()>0 && cursor.moveToLast()){
                FamilyMessageEntity entity = new FamilyMessageEntity();
                entity.setSn(cursor.getString(cursor.getColumnIndex(Field.KEY_SN)));
                entity.setRelation(cursor.getString(cursor.getColumnIndex(Field.KEY_RELATION)));
                entity.setAvatarUrl(cursor.getString(cursor.getColumnIndex(Field.KEY_AVATARURL)));
                entity.setOwner(cursor.getInt(cursor.getColumnIndex(Field.KEY_OWNER)));
                entity.setMsgType(cursor.getInt(cursor.getColumnIndex(Field.KEY_MSGTYPE)));
                entity.setContent(cursor.getString(cursor.getColumnIndex(Field.KEY_CONTENT)));
                entity.setCachePath(cursor.getString(cursor.getColumnIndex(Field.KEY_CACHEPATH)));
                entity.setMsgState(cursor.getInt(cursor.getColumnIndex(Field.KEY_MSGSTATE)));
                entity.setMsgSize(cursor.getInt(cursor.getColumnIndex(Field.KEY_MSGSIZE)));
                entity.setSendTime(cursor.getLong(cursor.getColumnIndex(Field.KEY_SENDTIME)));
                entity.setHadRead(cursor.getInt(cursor.getColumnIndex(Field.KEY_HADREAD)));
                entity.setPackageId(cursor.getString(cursor.getColumnIndex(Field.KEY_PACKAGEID)));
                entity.setUniqueId(cursor.getString(cursor.getColumnIndex(Field.KEY_UNIQUEID)));
                entity.setIsPlaying(cursor.getInt(cursor.getColumnIndex(Field.KEY_ISPLAYING)));
                entity.setMsgId(cursor.getString(cursor.getColumnIndex(Field.KEY_MSGID)));
                chatList.add(entity);
                while(cursor.moveToPrevious()){
                    FamilyMessageEntity entity1 = new FamilyMessageEntity();
                    entity1.setSn(cursor.getString(cursor.getColumnIndex(Field.KEY_SN)));
                    entity1.setRelation(cursor.getString(cursor.getColumnIndex(Field.KEY_RELATION)));
                    entity1.setAvatarUrl(cursor.getString(cursor.getColumnIndex(Field.KEY_AVATARURL)));
                    entity1.setOwner(cursor.getInt(cursor.getColumnIndex(Field.KEY_OWNER)));
                    entity1.setMsgType(cursor.getInt(cursor.getColumnIndex(Field.KEY_MSGTYPE)));
                    entity1.setContent(cursor.getString(cursor.getColumnIndex(Field.KEY_CONTENT)));
                    entity1.setCachePath(cursor.getString(cursor.getColumnIndex(Field.KEY_CACHEPATH)));
                    entity1.setMsgState(cursor.getInt(cursor.getColumnIndex(Field.KEY_MSGSTATE)));
                    entity1.setMsgSize(cursor.getInt(cursor.getColumnIndex(Field.KEY_MSGSIZE)));
                    entity1.setSendTime(cursor.getLong(cursor.getColumnIndex(Field.KEY_SENDTIME)));
                    entity1.setHadRead(cursor.getInt(cursor.getColumnIndex(Field.KEY_HADREAD)));
                    entity1.setPackageId(cursor.getString(cursor.getColumnIndex(Field.KEY_PACKAGEID)));
                    entity1.setUniqueId(cursor.getString(cursor.getColumnIndex(Field.KEY_UNIQUEID)));
                    entity.setIsPlaying(cursor.getInt(cursor.getColumnIndex(Field.KEY_ISPLAYING)));
                    entity.setMsgId(cursor.getString(cursor.getColumnIndex(Field.KEY_MSGID)));
                    chatList.add(entity1);
                }
            }
            CLog.e("zt","家庭群获取列表成功，总条数:"+chatList.size());
            return chatList;
        }catch(Exception e){
            e.printStackTrace();
            CLog.e("zt","家庭群获取列表失败:"+e.getMessage());
            e.getMessage();
            return null;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    //清除该sn下的所有数据
    public void cleanData(String sn){
        if(TextUtils.isEmpty(sn)){
            return;
        }
        try{
            SQLiteDatabase sqLiteDatabase = GlobalManager.getInstance().config().db.getWritableDatabase();
            int row = sqLiteDatabase.delete(TABLE_NAME, "sn = ?", new String[]{sn});
            CLog.e("zt","删除列表记录 row="+row);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    //删除数据库
    public void dropTable(){
        try{
            String sql = "drop table " + TABLE_NAME;
            SQLiteDatabase sqLiteDatabase = GlobalManager.getInstance().config().db.getWritableDatabase();
            sqLiteDatabase.execSQL(sql);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    //根据sn和msgId做去重判断
    public boolean msgIsExist(String sn, String msgId) {
        Cursor cursor = null;
        try {
            SQLiteDatabase sqLiteDatabase = GlobalManager.getInstance().config().db.getWritableDatabase();
            cursor = sqLiteDatabase.query(TABLE_NAME, null, "sn = ? and msgId = ?", new String[]{sn, msgId}, null, null, null);
            return cursor.getCount()>0;
        } catch (Exception e) {
            return false;
        }finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    private static final class Field {
        public static final String KEY_SN = "sn";
        public static final String KEY_MSGTYPE = "msgType";
        public static final String KEY_RELATION = "relation";
        public static final String KEY_AVATARURL = "avatarUrl";
        public static final String KEY_OWNER = "owner";
        public static final String KEY_CONTENT = "content";
        public static final String KEY_CACHEPATH = "cachePath";
        public static final String KEY_MSGSTATE = "msgState";
        public static final String KEY_MSGSIZE = "msgSize";
        public static final String KEY_SENDTIME = "sendTime";
        public static final String KEY_HADREAD = "hadRead";
        public static final String KEY_PACKAGEID = "packageId";
        public static final String KEY_UNIQUEID = "uniqueId";
        public static final String KEY_ISPLAYING = "isPlaying";
        public static final String KEY_MSGID = "msgId";
    }
}
