package com.qihoo360.homecamera.machine.entity;

import java.util.ArrayList;

/**
 * Created by zhangtao-iri on 2017/1/6.
 */
public class BindBannerEntity{

    public int total;

    public ArrayList<Banner> data;


    public static class Banner {

        public String imgUrl;

        public int action;       // 1:只展示图片 2：跳转到页面

        public String actionUrl; //只有action为2才有用
    }

}
