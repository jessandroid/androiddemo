
package com.qihoo360.homecamera.mobile.http.builder;

import com.qihoo360.homecamera.mobile.entity.UploadToken;
import com.qihoo360.homecamera.mobile.http.callback.UploadSuccCallBack;
import com.qihoo360.homecamera.mobile.upload.UploadConfiguration;
import com.qihoo360.homecamera.mobile.upload.UploadTaskImpl;
import com.qihoo360.homecamera.mobile.upload.VoiceUploadTaskImpl;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/3/2
 * Time: 15:57
 * To change this template use File | Settings | File Templates.
 */
public class PostFile2OOSBuilder {


    private ExecutorService mExecutorService;
    private static PostFile2OOSBuilder postFile2OOSBuilder;
    private UploadConfiguration mConfig;

    public static PostFile2OOSBuilder getInstance() {
        if (postFile2OOSBuilder == null) {
            postFile2OOSBuilder = new PostFile2OOSBuilder();
        }
        return postFile2OOSBuilder;
    }

    private PostFile2OOSBuilder() {
    }

    public void init(UploadConfiguration config){
        if (config.getThreadNum() > config.getMaxThreadNum()) {
            throw new IllegalArgumentException("thread num must < max thread num");
        }
        mConfig = config;
        mExecutorService = Executors.newFixedThreadPool(mConfig.getMaxThreadNum());
    }


    public void doUpload(UploadToken uploadToken, UploadSuccCallBack uploadSuccCallBack) {
        mExecutorService.execute(new UploadTaskImpl(uploadToken, uploadSuccCallBack));
    }

    public void doVioceUpload(UploadToken uploadToken, UploadSuccCallBack uploadSuccCallBack){
        mExecutorService.execute(new VoiceUploadTaskImpl(uploadToken, uploadSuccCallBack));
    }

}