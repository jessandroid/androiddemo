package com.qihoo360.homecamera.mobile.adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.TextView;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.entity.TestEntity;
import com.qihoo360.homecamera.mobile.utils.CameraToast;

import java.util.List;

/**
 * Created by zhaojunbo on 2016/3/3.
 * desc:
 */
public class QualityChangeAdapter extends BaseAdapter {

    private Context context;
    private List<TestEntity> list;
    private LayoutInflater inflater;

    public QualityChangeAdapter(Context context, List<TestEntity> list) {
        this.context = context;
        this.list = list;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final ViewHolder viewHolder;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.test_item, null);
            viewHolder = new ViewHolder();
            viewHolder.title = (TextView) convertView.findViewById(R.id.title);
            viewHolder.tvContent = (TextView) convertView.findViewById(R.id.tv_content);
            viewHolder.etContent = (EditText) convertView.findViewById(R.id.et_content);
            viewHolder.tvName = (TextView) convertView.findViewById(R.id.tv_name);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        viewHolder.title.setText(list.get(position).getTitle());
        viewHolder.tvContent.setVisibility(list.get(position).getData() != null ? View.VISIBLE : View.GONE);
        viewHolder.etContent.setVisibility(list.get(position).getData() == null ? View.VISIBLE : View.GONE);
        viewHolder.etContent.setText("" + list.get(position).getDefaultType());
        viewHolder.tvContent.setText("" + list.get(position).getDefaultType());
        viewHolder.tvContent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("select");
                builder.setItems(list.get(position).getStreamItems(), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int item) {
                        CameraToast.showToast(context, list.get(position).getData().get(list.get(position).getStreamItems()[item]) + ":" + list.get(position).getStreamItems()[item]);
                        viewHolder.tvName.setText("" + list.get(position).getStreamItems()[item]);
                        viewHolder.tvContent.setText("" + list.get(position).getData().get(list.get(position).getStreamItems()[item]));
                        list.get(position).setNewType(list.get(position).getData().get(list.get(position).getStreamItems()[item]));
                    }
                });
                AlertDialog alert = builder.create();
                alert.show();
            }
        });
        return convertView;
    }

    class ViewHolder {
        TextView title;
        TextView tvContent;
        EditText etContent;
        TextView tvName;
    }
}
