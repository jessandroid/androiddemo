package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by zhaojunbo on 2016/9/2.
 * desc:
 */
public class PrivateEntity implements Parcelable {

    public String remote_view;
    public String capture_video;

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.remote_view);
        dest.writeString(this.capture_video);
    }
    public PrivateEntity() {
    }

    protected PrivateEntity(Parcel in) {
        this.remote_view = in.readString();
        this.capture_video = in.readString();
    }

    public static final Creator<PrivateEntity> CREATOR = new Creator<PrivateEntity>() {
        @Override
        public PrivateEntity createFromParcel(Parcel source) {
            return new PrivateEntity(source);
        }

        @Override
        public PrivateEntity[] newArray(int size) {
            return new PrivateEntity[size];
        }
    };

}
