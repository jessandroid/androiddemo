
package com.qihoo360.homecamera.mobile.http.request;

import android.content.Context;
import android.os.Debug;
import android.text.TextUtils;
import android.util.DebugUtils;
import android.widget.Toast;

import com.google.gson.Gson;
import com.hp.hpl.sparta.Text;
import com.qihoo.pushsdk.message.Message;
import com.qihoo360.homecamera.mobile.ApplicationCamera;
import com.qihoo360.homecamera.mobile.BuildConfig;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.entity.Head;
import com.qihoo360.homecamera.mobile.entity.MessageInfoEntity;
import com.qihoo360.homecamera.mobile.http.OkHttpUtils;
import com.qihoo360.homecamera.mobile.http.callback.Callback;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CameraToast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * Created by zhy on 15/12/15.
 */
public class RequestCall {
    private OkHttpRequest okHttpRequest;
    private Request request;
    private volatile Call call;

    private long readTimeOut;
    private long writeTimeOut;
    private long connTimeOut;

    private OkHttpClient clone;

    private static ConcurrentHashMap<String, String> requestMap = new ConcurrentHashMap<>();
    private static ConcurrentHashMap<String, Long> timeMap = new ConcurrentHashMap<>();//同一种指令，记录上一次请求的时间，用来判断指令push是否已经过时
    public final static long COMMON_TIME_OUT = 15 * 1000;//一般指令15second超时
    public final static long UPGRADE_TIME_OUT = 5 * 60 * 1000;//如果是故事机固件升级超时是5minute
    public RequestCall(OkHttpRequest request) {
        this.okHttpRequest = request;
    }

    public RequestCall readTimeOut(long readTimeOut) {
        this.readTimeOut = readTimeOut;
        return this;
    }

    public RequestCall writeTimeOut(long writeTimeOut) {
        this.writeTimeOut = writeTimeOut;
        return this;
    }

    public RequestCall connTimeOut(long connTimeOut) {
        this.connTimeOut = connTimeOut;
        return this;
    }

    public Call generateCall(Callback callback) {
        request = generateRequest(callback);
        if (readTimeOut > 0 || writeTimeOut > 0 || connTimeOut > 0) {
            readTimeOut = readTimeOut > 0 ? readTimeOut : OkHttpUtils.CONNECT_MILLISECONDS;
            writeTimeOut = writeTimeOut > 0 ? writeTimeOut : OkHttpUtils.CONNECT_MILLISECONDS;
            connTimeOut = connTimeOut > 0 ? connTimeOut : OkHttpUtils.CONNECT_MILLISECONDS;
            clone = OkHttpUtils.getInstance().getOkHttpClient().newBuilder()
                    .readTimeout(readTimeOut, TimeUnit.MILLISECONDS)
                    .writeTimeout(writeTimeOut, TimeUnit.MILLISECONDS)
                    .connectTimeout(connTimeOut, TimeUnit.MILLISECONDS)
                    .build();
            call = clone.newCall(request);
        } else {
            call = OkHttpUtils.getInstance().getOkHttpClient().newCall(request);
        }
        return call;
    }

    private Request generateRequest(Callback callback) {
        return okHttpRequest.generateRequest(callback);
    }

    public Response execute(Callback callback) {
        generateCall(callback);

        if (callback != null) {
            callback.onBefore(request);
        }

        OkHttpUtils.getInstance().execute(this, callback);
        return null;
    }

    public Call getCall() {
        return call;
    }

    public Request getRequest() {
        return request;
    }

    public OkHttpRequest getOkHttpRequest() {
        return okHttpRequest;
    }

    private final static String HTTP_ERR_TAG = "http_err_";

    public String execute() {
        Head head = new Head();
        String rsp;
        String logInfo = "";
        try {
            generateCall(null);
            Response response = call.execute();
            if (!response.isSuccessful()) {
                head.statusCode = response.code();
                head.errorCode = -1;
                head.errorMsg = "网络异常，请检查网络";
                rsp = head.toJson();

                if (okHttpRequest != null){
                    logInfo = "Request = " + okHttpRequest.getUrl() + "\n\t";
                }
                CLog.justalkFile(HTTP_ERR_TAG, logInfo + "response = " + response.body().string());
            } else {
                ResponseBody res = response.body();
                rsp = res.string();
                res.close();
                if (TextUtils.isEmpty(rsp)) {
                    return head.toJson().toString();
                }
                Gson gson = new Gson();
                head = gson.fromJson(rsp, Head.class);
                if (head.errorCode != 0) {
                    if (head.errorCode == Constants.Http.SID_OUTDATE_ERROR || head.errorCode == Constants.Http.VERIFY_QT_ERROR) {
                        ApplicationCamera application = (ApplicationCamera) ApplicationCamera.sContext;
                        final Head finalHead = head;
                        application.logoutWithRequest(new ApplicationCamera.RequestErrorCallBack() {
                            @Override
                            public String geterror() {
                                return finalHead.toJson();
                            }
                        });
                        return head.toJson();
                    }
                }
                if (okHttpRequest != null){
                    logInfo = "Request = " + okHttpRequest.getUrl() + "\n\t";
                }
                CLog.justalkFile(HTTP_ERR_TAG, logInfo + "rsp = " + rsp);
            }
            return rsp;
        } catch (IOException e) {
            if (okHttpRequest != null){
                logInfo = "Request = " + okHttpRequest.getUrl() + "\n\t";
            }
            CLog.justalkFile(HTTP_ERR_TAG, logInfo + "IOException = " + e.getMessage());
            CLog.e(e);
            head.errorCode = -1;
            head.errorMsg = "网络异常，请检查网络";
            return head.toJson();
        }
    }

    //TODO  注意：异步执行，只用于cmd接口,其他的接口不要调用这个,会出问题
    public String excuteAysnRequest(Context context, long timeout){
        String taskid = "";
        String cmdString = "";
        Head head = new Head();
        String rsp;
        if (getOkHttpRequest().params.containsKey("content")) {
            JSONObject jo;
            try {
                jo = new JSONObject(getOkHttpRequest().params.get("content"));
                taskid = jo.getString("taskid");
                getOkHttpRequest().params.put("taskid", taskid);
                CLog.e("zt","taskid:"+ taskid);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        requestMap.put(taskid, "");
        if(getOkHttpRequest().params.containsKey("cmd")){
            cmdString = getOkHttpRequest().params.get("cmd");
            CLog.e("zt","本次指令的名称:"+cmdString);
        }
        rsp = execute();
        Gson gson = new Gson();
        head = gson.fromJson(rsp, Head.class);
        if(head.getErrorCode()!=0){
            if (!TextUtils.isEmpty(requestMap.get(taskid))) {
                CLog.d(taskid + "推送已经到达 ");
                rsp = requestMap.get(taskid);
                requestMap.remove(taskid);
                return rsp;
            } else {
                CLog.d(taskid + "请求失败  " + " ErrorCode " + head.getErrorCode());
                requestMap.remove(taskid);
                return rsp;
            }
        }else{

            JSONObject jsObject;
            try {
                jsObject = new JSONObject(rsp);
                JSONObject dataJo = jsObject.getJSONObject("data");
                if (!dataJo.getBoolean("online")) {
                    requestMap.remove(taskid);
                    head.errorCode = -20;//故事机离线了
                    head.errorMsg = context.getString(R.string.story_machine_offline);
                    return head.toJson();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

            CLog.d(taskid + "请求成功...等推送");
            long timestamp = System.currentTimeMillis();
            while (TextUtils.isEmpty(requestMap.get(taskid))
                    && (System.currentTimeMillis() - timestamp) < timeout) {
                try {
                    CLog.e("zt","timestamp:"+timestamp+"  当前系统时间:"+System.currentTimeMillis() +"  时间差:"+(System.currentTimeMillis() - timestamp));
                    Thread.sleep(300);
                } catch (Exception e) {
                    // empty
                }
            }

            if(!TextUtils.isEmpty(requestMap.get(taskid))){
                CLog.d("zt",taskid + "推送到达");
                //需要判断是否应该放弃
                rsp = requestMap.get(taskid);
                try{
                    JSONObject jsonObject = new JSONObject(rsp);
                    JSONObject dataJo = jsonObject.getJSONObject("data");
                    JSONObject contentJo = dataJo.getJSONObject("content");
                    long pushTime = contentJo.getLong("time");//获取固件端发出push的时间
                    //TODO 同一种指令需要判断是否过时
                    CLog.e("zt","固件端push回来的时间:"+pushTime+"---上一次的时间:"+timeMap.contains(cmdString));
                    if(timeMap.contains(cmdString)){
                        if(pushTime > timeMap.get(cmdString)){
                            timeMap.put(cmdString, pushTime);
                            requestMap.remove(taskid);
                            return rsp;
                        }else{
                            CLog.e("zt",taskid + "过时psuh");
                            head.errorCode = -18;
                            head.errorMsg = "这条push已经过时";
                            requestMap.remove(taskid);
                            return head.toJson();
                        }
                    }else{
                        //第一次，时间为空,将这次的时间作为上次到达时间
                        timeMap.put(cmdString, pushTime);
                        requestMap.remove(taskid);
                        return rsp;
                    }

                }catch (JSONException e) {
                    e.printStackTrace();
                }
            }else{
                CLog.e("zt",taskid + "等推送超时 ");
                head.errorCode = -14;
                head.errorMsg = "等待推送异步超时";
                requestMap.remove(taskid);
                return head.toJson();
            }
            requestMap.remove(taskid);
        }
        return rsp;
    }

    public static void pushArrived(String pushValue) {
        MessageInfoEntity messageInfoEntity = new Gson().fromJson(pushValue, MessageInfoEntity.class);
        if(messageInfoEntity==null || messageInfoEntity.data==null){
            CLog.d("push.taskid is null");
            return;
        }
        if (requestMap.containsKey(messageInfoEntity.data.content.taskid)) {
            CLog.d(messageInfoEntity.data.content.taskid + "开始put..");
            requestMap.put(messageInfoEntity.data.content.taskid, pushValue);
            CLog.d(messageInfoEntity.data.content.taskid + "put进去了..");
        } else {
            CLog.d(messageInfoEntity.data.content.taskid + "过期推送...");
        }
    }

    public Response executeImage() throws IOException {
        generateCall(null);
        Response response = call.execute();
        return response;
    }


    public void cancel() {
        if (call != null) {
            call.cancel();
        }
    }

}
