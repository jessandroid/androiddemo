package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/3/29
 * Time: 10:17
 * To change this template use File | Settings | File Templates.
 */
public class StoryAddress extends  Head {

    public String quality;
    public String lrc;
    public String video;
    public String downloadUrl;
    public String local;


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeString(this.quality);
        dest.writeString(this.lrc);
        dest.writeString(this.video);
        dest.writeString(this.downloadUrl);
        dest.writeString(this.local);
    }

    public StoryAddress() {
    }

    protected StoryAddress(Parcel in) {
        super(in);
        this.quality = in.readString();
        this.lrc = in.readString();
        this.video = in.readString();
        this.downloadUrl = in.readString();
        this.local = in.readString();
    }

    public static final Creator<StoryAddress> CREATOR = new Creator<StoryAddress>() {
        @Override
        public StoryAddress createFromParcel(Parcel source) {
            return new StoryAddress(source);
        }

        @Override
        public StoryAddress[] newArray(int size) {
            return new StoryAddress[size];
        }
    };

    @Override
    public String toJson() {
        return super.toJson();
    }
}
