
package com.qihoo360.homecamera.mobile.activity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Html;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.SysConfig;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.db.PadInfoWrapper;
import com.qihoo360.homecamera.mobile.entity.Camera;
import com.qihoo360.homecamera.mobile.entity.Contacts;
import com.qihoo360.homecamera.mobile.entity.ShareCode;
import com.qihoo360.homecamera.mobile.entity.ShareShareEntity;
import com.qihoo360.homecamera.mobile.entity.ShareUser;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.widget.CircleImageView;

import java.util.ArrayList;

/**
 * Created by Administrator on 2015/3/13.
 */
public class ShareCameraActivity extends BaseActivity implements OnClickListener, ActionListener {
    private static final int MSG_WHAT_GETSHARE_CODE = 1;
    private static final int MSG_WHAT_REF = 3;

    private ImageView btnback;
    private LinearLayout invlayout, sharesms, sharewechatlayout, shareqr, linearLayout2;

    private CircleImageView share_user_one, share_user_two, share_user_three;
    private ImageView share_user_more, bg;
    private ImageView share_arrow;
    private Bitmap bgBmp;

    private CircleImageView[] circleImageViews;

    private RelativeLayout shareHead;
    private TextView share_title_text;
    private DisplayImageOptions options;
    private Camera camera;
//    private IWXAPI api;
    private ArrayList<ShareUser> shareList = new ArrayList<ShareUser>();
    private ProgressDialog progressDialog;

    private ImageView mBackIv;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        GlobalManager.getInstance().getShareManager().registerActionListener(this);
        setContentView(R.layout.share_camera);
        setTintManagerQWork(true);
        tintManager.setStatusBarTintColor(Color.parseColor("#00000000"));
//        api = GlobalManager.getInstance().getShareToWeChatAndWeibo().getWXAPI();
        camera = getIntent().getExtras().getParcelable("camera");
        initialize();

        if (camera != null) {
            GlobalManager.getInstance().getShareManager().asyncShareGetSharingList(camera.sn);
        } else {
            finish();
        }
    }

    @Override
    public void onDestroy() {
        if (bgBmp != null) {
            bgBmp.recycle();
        }
        GlobalManager.getInstance().getShareManager().removeActionListener(this);
        super.onDestroy();
    }

    private void initialize() {

        btnback = (ImageView) findViewById(R.id.btn_back);
        invlayout = (LinearLayout) findViewById(R.id.inv_layout);

        bg = (ImageView) findViewById(R.id.invite_bg);
        bg.setMaxWidth(SysConfig.BASE_SCREEN_WIDTH);
        bg.setMaxHeight(SysConfig.BASE_SCREEN_HEIGHT);

        share_user_one = (CircleImageView) findViewById(R.id.share_user_one);
        share_user_two = (CircleImageView) findViewById(R.id.share_user_two);
        share_user_three = (CircleImageView) findViewById(R.id.share_user_three);
        share_user_more = (ImageView) findViewById(R.id.share_user_more);
        share_arrow = (ImageView) findViewById(R.id.share_arrow);

        circleImageViews = new CircleImageView[] {
                share_user_one, share_user_two, share_user_three
        };

        sharesms = (LinearLayout) findViewById(R.id.share_sms);
        sharesms.setOnClickListener(this);

        sharewechatlayout = (LinearLayout) findViewById(R.id.share_wechat_layout);
        sharewechatlayout.setOnClickListener(this);

        shareqr = (LinearLayout) findViewById(R.id.share_qr);
        shareqr.setOnClickListener(this);

        linearLayout2 = (LinearLayout) findViewById(R.id.linearLayout2);
        shareHead = (RelativeLayout) findViewById(R.id.share_count_title);
        shareHead.setOnClickListener(this);
        share_title_text = (TextView) findViewById(R.id.share_title_text);
        //shareList = (ArrayList<ShareUser>) ShareUserWrapper.getmInstance(this).getShareUserList(camera.getSN());
        setIconShow(shareList);
        mBackIv = (ImageView) findViewById(R.id.iv_back);
        mBackIv.setOnClickListener(this);
    }

    @Override
    protected void onResume() {
        if (bgBmp == null) {
            bgBmp = Utils.getBitmap(R.drawable.add_share_word_bg);
            bg.setImageBitmap(bgBmp);
        }
        if (camera != null) {
            GlobalManager.getInstance().getShareManager().asyncShareGetSharingList(camera.sn);
        } else {
            finish();
        }
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    public int getAcceptCount(ArrayList<ShareUser> shareList) {
        int shareCount = 0;
        for (int i = 0; i < shareList.size(); i++) {
            shareCount = shareList.get(i).getAccept() == ShareUser.ACCEPTED ? shareCount + 1 : shareCount;
        }
        return shareCount;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.share_sms:
                sendtoSMS();
                break;
            case R.id.share_wechat_layout:
                //TODO  分享出现卡死的状态
//                progressDialog = ProgressDialog.show(this, "", getString(R.string.share_latter));
//                progressDialog.setCancelable(true);
                getProgressDialog().show();
                //shareCameraManager.asyncGetShareCode(camera);
                GlobalManager.getInstance().getShareManager().asyncShareShare(camera.sn, "2", "", PadInfoWrapper.getInstance().getPadBySn(camera.sn).isStoryMachine()?Constants.DeviceType.STORYMACHINE:Constants.DeviceType.KIBOTMACHINE);
                break;
            case R.id.share_qr:
                qrShare();
                break;
            case R.id.share_count_title:
                intentToList(shareList.size());
                break;
            case R.id.iv_back:
                finish();
                break;
        }
    }

    public void intentToList(int count) {
        if (count > 0) {
            if (Utils.isNetworkAvailable(this)) {
                //TODO
//                Intent intent = new Intent(this, CameraShareUserListActivity.class);
//                Bundle bundle = new Bundle();
//                bundle.putParcelableArrayList("shareList", shareList);
//                bundle.putParcelable("camera", camera);
//                intent.putExtras(bundle);
//                startActivityForResult(intent, 30000);
            } else {
                CameraToast.show(this, R.string.network_disabled, Toast.LENGTH_SHORT);
            }
        }
    }

    private void qrShare() {
        if (Utils.isNetworkAvailable(this)) {
            Intent intent = new Intent(this, ShareQRActivity.class);
            intent.putExtra("sn", camera.sn);
            intent.putExtra(Constants.SHARE_TYPE, Constants.ShareType.SHARE_TYPE_QRCODE);
            startActivityForResult(intent, Constants.PHONE_QR);
        } else {
            CameraToast.show(null, R.string.network_disabled, Toast.LENGTH_SHORT);
        }
    }

    private void sendtoSMS() {
        if (Utils.isNetworkAvailable(this)) {
            Intent intent = new Intent(this, ChooseContactActivity.class);
            intent.putExtra("camera", camera);
            intent.putExtra(Constants.SHARE_TYPE, Constants.ShareType.SHARE_TYPE_MOBILE);
            startActivityForResult(intent, Constants.PHONE_LIST);
        } else {
            CameraToast.show(null, R.string.network_disabled, Toast.LENGTH_SHORT);
        }
    }

    /**
     * TODO 这里需要修改
     * @param actionCode 操作的action值
     * @param args 返回参数，使用的地方通过{@code args[0], args[1], args[2]...取参数}
     * <br>具体参数个数，依赖具体action操作
     * @return
     */
    @Override
    public Object actionPerformed(int actionCode, Object... args) {
        switch (actionCode) {
            case Actions.Share.SHARE_GET_SHARING_LIST_FAIL:
                if (args == null || args.length == 0) {
                } else {
                    CameraToast.showErrorToast((String) args[0]);
                }
                break;
            case Actions.Share.SHARE_GET_SHARING_LIST_SUCCESS:
                CLog.e("zhaojunbo", "SHARE_GET_SHARING_LIST_SUCCESS");
                //updateUI(((ShareGetSharingListEntitiy) args[0]).data.data);
                break;
            case Actions.Share.SHARE_SHARE_SUCCESS:
                ShareShareEntity shareShareEntity = (ShareShareEntity) args[0];
                CameraToast.show(shareShareEntity.data.code, Toast.LENGTH_SHORT);
                getProgressDialog().dismiss();
                return Boolean.TRUE;
            case Actions.Share.SHARE_SHARE_FAIL: {
                getProgressDialog().dismiss();
//                if (args == null || args.length == 0) {
//                    CameraToast.showErrorToast(ShareCameraActivity.this, R.string.load_camera_list_failed);
//                } else {
//                    CameraToast.showErrorToast((String) args[0]);
//                }
                return Boolean.TRUE;
            }
        }
        return Actions.ACTION_NOT_PROCESSED;
    }

    public void getShareSucc(final ShareCode shareCode) {
        if (shareCode.errorCode == 0 && !TextUtils.isEmpty(shareCode.getShareCode())) {
            Gson gson = new Gson();
            CLog.d(gson.toJson(shareCode));

        } else {
            CameraToast.show(ShareCameraActivity.this, shareCode.errorMsg, Toast.LENGTH_SHORT);
        }
        progressDialog.dismiss();
    }

    public void UpdateCode(final ShareCode shareCode) {

    }

    @SuppressLint("ResourceAsColor")
    public void updateUI(ArrayList<ShareUser> result) {
        shareList = result;
        if (result != null && result.size() > 0) {
            setIconShow(result);
        } else {
            shareHead.setBackgroundResource(R.drawable.share_item_bg_disable);
            share_title_text.setTextColor(getResources().getColor(R.color.text_gray));
            share_title_text.setText(R.string.none_user_accetp);
            shareList = new ArrayList<ShareUser>();
            share_title_text.setText(R.string.none_user_accetp);
            Utils.ensureVisbility(View.GONE, share_user_three, share_user_one, share_user_two, share_arrow,
                    share_user_more);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Constants.PHONE_LIST) {
            if (data != null) {
                Contacts contact = (Contacts) data.getSerializableExtra("contact");
                if (contact != null && !TextUtils.isEmpty(contact.getPhoneNumber())) {
                    Intent intent = new Intent(this, SendContactActivity.class);
                    intent.putExtra("contact", contact);
                    intent.putExtra(Constants.SHARE_TYPE, Constants.ShareType.SHARE_TYPE_MOBILE);
                    intent.putExtra("sn", camera.sn);
                    startActivityForResult(intent, 10000);
                }
            }
        } else if (requestCode == 10000) {
            intentToList(shareList.size());
        }
    }

    @SuppressLint("ResourceAsColor")
    public void setIconShow(ArrayList<ShareUser> shareList) {
        int count = 0;
        this.shareList = shareList;
        int shareCount = getAcceptCount(shareList);
        int showCount = shareCount > 99 ? 99 : shareCount;
        if (shareCount > 0) {
            share_title_text.setText(Html.fromHtml(getString(R.string.share_user_count, String.valueOf(showCount))));
            shareHead.setBackgroundResource(R.drawable.share_dialog_item_bg);
        } else if (shareList.size() > 0 && getAcceptCount(shareList) == 0) {
            share_title_text.setText(R.string.waiting_to_accept_title);
            shareHead.setBackgroundResource(R.drawable.share_dialog_item_bg);
            share_title_text.setTextColor(getResources().getColor(R.color.btn_text_black));
            Utils.ensureVisbility(View.VISIBLE, share_user_more, share_arrow);
        } else {
            shareHead.setBackgroundResource(R.drawable.share_item_bg_disable);
            share_title_text.setTextColor(getResources().getColor(R.color.text_gray));
            share_title_text.setText(R.string.none_user_accetp);
            Utils.ensureVisbility(View.GONE, share_user_more, share_arrow);
        }
        if (shareCount >= 3) {

            Utils.ensureVisbility(View.VISIBLE, share_user_three, share_user_one, share_user_two, share_arrow);
        } else {
            if (shareCount == 2) {
                Utils.ensureVisbility(View.VISIBLE, share_user_one, share_user_two, share_arrow);
                Utils.ensureVisbility(share_user_three, View.GONE);
            }
            if (shareCount == 1) {
                Utils.ensureVisbility(View.GONE, share_user_two, share_user_three);
                Utils.ensureVisbility(View.VISIBLE, share_user_one, share_arrow);
            }
        }
        if (shareCount >= circleImageViews.length) {
            count = circleImageViews.length;
        } else {
            count = shareCount;
        }
        for (int i = 0; i < count; i++) {
            ImageLoader.getInstance().cancelDisplayTask(circleImageViews[i]);
            ImageLoader.getInstance().displayImage(shareList.get(i).getImgUrl(), circleImageViews[i]);
        }
    }

    public interface ShareWxCallBack {
        void succ();

        void failed(String shareCode);
    }

    @Override
    public int getProperty() {
        // TODO Auto-generated method stub
        return 0;
    }
}
