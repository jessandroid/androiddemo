
package com.qihoo360.homecamera.mobile.manager;

import android.app.Application;
import android.text.TextUtils;

import com.qihoo360.homecamera.machine.config.MachineDebugConfig;
import com.qihoo360.homecamera.machine.util.MachineUtils;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionPublisherWithThreadPoolBase;
import com.qihoo360.homecamera.mobile.core.manager.workpool.PoolThreadFactory;
import com.qihoo360.homecamera.mobile.core.net.Api;
import com.qihoo360.homecamera.mobile.core.net.MachineApi;
import com.qihoo360.homecamera.mobile.db.PadInfoWrapper;
import com.qihoo360.homecamera.mobile.entity.AppBindEntity;
import com.qihoo360.homecamera.mobile.entity.DeviceInfo;
import com.qihoo360.homecamera.mobile.entity.DeviceInfoList;
import com.qihoo360.homecamera.mobile.entity.Head;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.Preferences;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.Executors;


public class CameraManager extends ActionPublisherWithThreadPoolBase {
    private final String mPoolNameHighPriority, mPoolNameLowPriority;
    private final Application mApp;

    public CameraManager(Application app) {
        this.mApp = app;
        mPoolNameHighPriority = "CameraManager-high-priority-" + Utils.DATE_FORMAT_3.format(new Date());
        mPoolNameLowPriority = "CameraManager-low-priority-" + Utils.DATE_FORMAT_3.format(new Date());
        mThreadPool.initPool(mPoolNameHighPriority, Executors.newFixedThreadPool(3));
        mThreadPool.initPool(mPoolNameLowPriority,
                Executors.newCachedThreadPool(new PoolThreadFactory(mPoolNameLowPriority)));
    }

    public void asyncLoadMyCamera(Integer page) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("LoadMyCamera", page));
    }

    //注意别的地方不要调用这个方法，此方法只在mainactivity中调用!!!
    public void asyncMainLoadMyCamera(Integer page) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("MainLoadMyCamera", page));
    }


    public void asyncLoadBindDevice(String activeCode, String bType) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("BindMyCamera", activeCode, bType));
    }

    public void asyncLoadUnBindDevice(String sn, String delCloudData, String delIpcData) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("UnBindMyCamera", sn, delCloudData, delIpcData));
    }

    public void asyncModifyTitleAndHeadView(String sn, String title) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("ModifyTitleAndHeadView", sn, title));
    }

    public void asyncLoadPadBySn(String sn) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("LoadPadBySn", sn));
    }

    public void asyncLoadAllPad() {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("LoadAllPad"));
    }

    private void doLoadAllPad(){
        ArrayList<DeviceInfo> deviceInfos = PadInfoWrapper.getInstance().getAllPad();
        GlobalManager.getInstance().getCameraManager().publishAction(Actions.Camera.ALL_DEVICE_LOADED, deviceInfos);
    }

    private void doLoadMyCamera(Integer page) {
        CLog.startTimer("doLoadMyCameraFirst");
        DeviceInfoList deviceInfoListNew = new DeviceInfoList();
        DeviceInfoList machineDeviceInfoList;
        DeviceInfoList dilRef = new DeviceInfoList();
        ArrayList<DeviceInfo> deviceInfos = PadInfoWrapper.getInstance().getAllPad();
        dilRef.data.device = deviceInfos;
        CLog.i("test3", "doLoadMyCamera CAMERA_LIST_ACTION 1");
        try {
            deviceInfoListNew = MachineApi.Machine.getMachineList(page);
            if (deviceInfoListNew.errorCode == 0) {
                PadInfoWrapper.getInstance().processPadInfo(deviceInfoListNew);
                String sn = Preferences.getSelectedPad();
                if (deviceInfoListNew.data.device.size() == 1) {
                    Preferences.saveSelectedPad(deviceInfoListNew.data.device.get(0).sn);
                } else {
                    if (!TextUtils.isEmpty(sn)) {
                        DeviceInfo saveD = PadInfoWrapper.getInstance().getPadBySn(sn);
                        if (saveD == null) {
                            Preferences.saveSelectedPad("");
                        }
                    } else {
                        if (deviceInfoListNew.data.device.size() == 1) {
                            Preferences.saveSelectedPad(deviceInfoListNew.data.device.get(0).sn);
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            publishAction(Actions.Camera.CAMERA_LIST_ACTION, deviceInfoListNew, page);
            CLog.i("test3", "doLoadMyCamera CAMERA_LIST_ACTION 2");
        }
    }

    //注意别的地方不要调用这个方法，此方法只在mainactivity中调用
    private void doMainLoadMyCamera(Integer page) {
        CLog.startTimer("doLoadMyCameraFirst");
        DeviceInfoList deviceInfoListNew = new DeviceInfoList();
        try {
            //获取全部设备列表
            deviceInfoListNew = MachineApi.Machine.getMachineList(page);
            if (deviceInfoListNew.errorCode == 0) {
                PadInfoWrapper.getInstance().processPadInfo(deviceInfoListNew);
                String sn = Preferences.getSelectedPad();
                if (deviceInfoListNew.data.device.size() == 1) {
                    Preferences.saveSelectedPad(deviceInfoListNew.data.device.get(0).sn);
                } else {
                    if (!TextUtils.isEmpty(sn)) {
                        DeviceInfo saveD = PadInfoWrapper.getInstance().getPadBySn(sn);
                        if (saveD == null) {
                            Preferences.saveSelectedPad("");
                        }
                    } else {
                        if (deviceInfoListNew.data.device.size() == 1) {
                            Preferences.saveSelectedPad(deviceInfoListNew.data.device.get(0).sn);
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            publishAction(Actions.Camera.CAMERA_LIST_ACTION, deviceInfoListNew, page);
            CLog.i("test3", "doLoadMyCamera CAMERA_LIST_ACTION 2");
        }
    }

    /**
     * 合并设备列表
     */
    private DeviceInfoList mergeDeviceList(DeviceInfoList cameraDeviceInfoList, DeviceInfoList machineDeviceInfoList) {
        if (!MachineDebugConfig.DEBUG) {
            return cameraDeviceInfoList;
        }
        if (cameraDeviceInfoList == null && machineDeviceInfoList == null) {
            return null;
        }
        if (cameraDeviceInfoList == null || cameraDeviceInfoList.data == null || cameraDeviceInfoList.data.device == null) {
            return machineDeviceInfoList;
        }
        if (machineDeviceInfoList == null || machineDeviceInfoList.data == null || machineDeviceInfoList.data.device == null) {
            return cameraDeviceInfoList;
        }
        cameraDeviceInfoList.data.device.addAll(machineDeviceInfoList.data.device);
        return cameraDeviceInfoList;
    }

    @Override
    protected void asyncDoNamedJob(String jobName, Object... args) {
        if (TextUtils.equals(jobName, "LoadMyCamera")) {
            doLoadMyCamera((Integer) args[0]);
        } else if(TextUtils.equals(jobName, "MainLoadMyCamera")){
            doMainLoadMyCamera((Integer) args[0]);
        }else if (TextUtils.equals(jobName, "LoadAllPad")) {
            doLoadAllPad();
        } else if (TextUtils.equals(jobName, "BindMyCamera")) {
            String acCode = (String) args[0];
            String bType = (String) args[1];
            doBindMyCamera(acCode, bType);
        } else if (TextUtils.equals(jobName, "UnBindMyCamera")) {
            doUnBindMyCamera((String) args[0], (String) args[1], (String) args[2]);
        } else if (TextUtils.equals(jobName, "ModifyTitleAndHeadView")) {
            String sn = (String) args[0];
            String title = (String) args[1];
            doModifyTitleAndHeadView(sn, title);
        } else if (TextUtils.equals(jobName, "LoadPadBySn")) {
            doLoadPadBySn((String) args[0]);
        }
    }

    private void doBindMyCamera(String activeCode, String type) {
        AppBindEntity appBindEntity;

        appBindEntity = Api.Camera.getBindDevice(activeCode, type);

        if (appBindEntity == null) {
            publishAction(Actions.Camera.BIND_DEVICE_FAIL);
        } else if (appBindEntity.errorCode == 8) {
            publishAction(Actions.Camera.BIND_DEVICE_ALREADY_BIND);
        } else if (appBindEntity.errorCode != 0) {
            publishAction(Actions.Camera.BIND_DEVICE_FAIL, appBindEntity.errorMsg);
        } else {
            publishAction(Actions.Camera.BIND_DEVICE_SUCCESS, appBindEntity.data.sn);
        }
    }

    private void doLoadPadBySn(String sn) {
        DeviceInfo mDeviceInfo = PadInfoWrapper.getInstance().getPadBySn(sn);
        publishAction(Actions.Camera.LOAD_PAD_BY_SN, mDeviceInfo);
    }

    private void doUnBindMyCamera(String sn, String delCloudData, String delIpcData) {
//        Head head = Api.Camera.getUnBindDevice(sn, delCloudData, delIpcData);
        Head head = null;
        head = MachineApi.Machine.getUnBindDevice(sn, delCloudData, delIpcData, PadInfoWrapper.getInstance().getPadBySn(sn).isStoryMachine() ? "story" : "kibot");

        if (head == null) {
            publishAction(Actions.Camera.UN_BIND_DEVICE_FAIL);
        } else if (head.errorCode != 0) {
            publishAction(Actions.Camera.UN_BIND_DEVICE_FAIL, head.errorCode);
        } else {
            PadInfoWrapper.getInstance().deletePadBySnQid(sn, AccUtil.getInstance().getQID());
            if (TextUtils.equals(Preferences.getSelectedPad(), sn)) {
                Preferences.saveSelectedPad("");
            }
            publishAction(Actions.Camera.UN_BIND_DEVICE_SUCCESS, sn);
        }
    }

    private void doModifyTitleAndHeadView(String sn, String title) {
        Head head = Api.Camera.updateTitleAndHeadView(sn, title);
        if (head == null) {
            publishAction(Actions.Camera.MODIFY_TITLE_HEAD_FAIL);
        } else if (head.errorCode != 0) {
            publishAction(Actions.Camera.MODIFY_TITLE_HEAD_FAIL, head.errorCode);
        } else {
            publishAction(Actions.Camera.MODIFY_TITLE_HEAD_SUCCESS, title);
        }
    }
}
