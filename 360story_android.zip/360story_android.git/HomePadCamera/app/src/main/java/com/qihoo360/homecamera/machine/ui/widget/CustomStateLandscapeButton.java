package com.qihoo360.homecamera.machine.ui.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;

import com.qihoo360.homecamera.machine.preferences.Preferences;
import com.qihoo360.homecamera.mobile.R;

/**
 * Created by zhaojunbo on 2015/11/5.
 * desc:
 */
public class CustomStateLandscapeButton extends AbstractCustomStateButton {

    private int uiType;

    public CustomStateLandscapeButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        isLand = true;
        mContext = context;

        LayoutInflater inflater = LayoutInflater.from(mContext);
        View view = inflater.inflate(R.layout.custom_state_landscape_button, null);
        addView(view, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        mChangeBtn = (ImageView) view.findViewById(R.id.iv_change);
        mChangeDevidedView = view.findViewById(R.id.iv_change_devided);
        mChangeBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mIsDemoCamera) {
                    onChangeErrorListener.onErrorMsg(IS_DEMO_CAMERA);
                    return;
                }
                if (!mIsCameraSupport) {
                    onChangeErrorListener.onErrorMsg(CAMERA_NOT_SUPPORT);
                    return;
                }
                if (!mIsPhoneSupport) {
                    onChangeErrorListener.onErrorMsg(PHONE_NOT_SUPPORT);
                    return;
                }
                if (!mIsfirmworkSupport) {
                    onChangeErrorListener.onErrorMsg(FIRMWORK_NEED_UPDATE);
                    return;
                }
                mButtonState = mButtonState < 3 ? PHONE_NORMAL : MIC_NORMAL;
                mChangeBtn.setImageResource(mButtonState < 3 ? R.drawable.phone_state_landscape_drawable : R.drawable.mic_state_landscape_drawable);
                if (isLand) {
                    if (uiType == 0) {
                        mCurrentFunBtn.setImageResource(mButtonState < 3 ? R.drawable.btn_video_pushtalk_land : R.drawable.btn_video_pushtalk_phone_land);
                    }else{
                        mCurrentFunBtn.setImageResource(mButtonState < 3 ? R.drawable.btn_video_pushtalk_land : R.drawable.btn_video_pushtalk_phone_land_pw);
                    }
                } else {
                    mCurrentFunBtn.setImageResource(mButtonState < 3 ? R.drawable.btn_video_push_talk : R.drawable.btn_video_push_phone_talk);
                }
                onChangeStateListener.onChange(mButtonState);
                onChangeStateListener.onChange(mButtonState < 3 ? PHONE2MIC : MIC2PHONE);

                mTipsTv.setTextColor(getResources().getColor(R.color.color_video_btn_push_talk_text));
//                setBackgroundResource(R.drawable.btn_video_land_bg);

                Preferences.setIsMic(mSn, mButtonState);
                setPressed(mButtonState <= 3 ? false : true);
                mLastButtonState = mButtonState;
            }
        });
        mChangeBtn.setImageResource(mButtonState < 3 ? R.drawable.phone_state_landscape_drawable : R.drawable.mic_state_landscape_drawable);
        setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (!mIsfirmworkSupport && mButtonState == AbstractCustomStateButton.PHONE_NORMAL) {
                    if (event.getAction() == MotionEvent.ACTION_DOWN) {
                        onChangeErrorListener.onErrorMsg(FIRMWORK_NEED_UPDATE);
                    }
                    return true;
                }
                return clickTalkBtn(v, event, event.getAction());
            }
        });
        setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mButtonState >= 3) {
                    if (mButtonState != PHONE_NORMAL) {
                        mTipsTv.setTextColor(0xff6692f7);
                        if (uiType == 0) {
                            mCurrentFunBtn.setImageResource(R.drawable.btn_video_pushtalk_normal_gogogo_land);
                            setBackgroundResource(R.drawable.btn_land_bg_normal);
                        }else{
                            mCurrentFunBtn.setImageResource(R.drawable.phone_normal_pw);
                            setBackgroundResource(R.drawable.btn_land_bg_normal_pg);
                        }
                    } else {
                        mTipsTv.setTextColor(0xffffffff);
                        if (uiType == 0) {
                            mCurrentFunBtn.setImageResource(R.drawable.btn_video_pushtalk_pressed_land);
                            setBackgroundResource(R.drawable.btn_land_bg_pressed);
                        }else{
                            mCurrentFunBtn.setImageResource(R.drawable.phone_press_pw);
                            setBackgroundResource(R.drawable.btn_land_bg_pressed_pg);
                        }
                    }
                    mButtonState = mButtonState == PHONE_NORMAL ? PHONE_PRESS : PHONE_NORMAL;
                    if (mLastButtonState != mButtonState) {
                        onChangeStateListener.onChange(mButtonState);
                    }
                    mLastButtonState = mButtonState;
                }
            }
        });
    }

    public void setBackgroundType(int type) {
        //0新UI，1老UI
        uiType = type;
    }

    public boolean clickTalkBtn(View v, MotionEvent event, int action) {
        if (mIsDemoCamera) {
            if (action == MotionEvent.ACTION_DOWN) {
                onChangeErrorListener.onErrorMsg(IS_DEMO_CAMERA);
            }
            return true;
        }
        if (action == MotionEvent.ACTION_DOWN) {
            onTalkButtonClickListener.onClick(mButtonState);
            if (mButtonState < 3) {
                //mic
                mTipsTv.setTextColor(0xffffffff);
               setPressed(true);
                mButtonState = MIC_PRESS;
            } else {
                //phone
                mTipsTv.setTextColor(0xffffffff);
                if (uiType == 0) {
                    mCurrentFunBtn.setImageResource(R.drawable.btn_video_pushtalk_pressed_land);
                    setBackgroundResource(R.drawable.btn_land_bg_pressed);
                } else {
                    mCurrentFunBtn.setImageResource(R.drawable.phone_press_pw);
                    setBackgroundResource(R.drawable.btn_land_bg_pressed_pg);
                }
                return false;
            }
        } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            if (mButtonState < 3) {
                mTipsTv.setTextColor(0xff6692f7);
                setPressed(false);
                mButtonState = MIC_NORMAL;
            } else {
                if (v != null && event != null && !inRangeOfView(v, event)) {
                    mTipsTv.setTextColor(0xff6692f7);
                    if (uiType == 0) {
                        mCurrentFunBtn.setImageResource(R.drawable.btn_video_pushtalk_normal_gogogo_land);
                        setBackgroundResource(R.drawable.btn_land_bg_normal);
                    } else {
                        mCurrentFunBtn.setImageResource(R.drawable.phone_normal_pw);
                        setBackgroundResource(R.drawable.btn_land_bg_normal_pg);
                    }
                    return true;
                }
                return false;
            }
        } else {
            return false;
        }
        if (mLastButtonState != mButtonState) {
            onChangeStateListener.onChange(mButtonState);
        }
        mLastButtonState = mButtonState;
        return true;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        initView();
    }

    @Override
    public void setPhoneModeVisible(boolean isVisible) {
        //Utils.ensureVisbility(isVisible ? View.VISIBLE : View.GONE, mChangeBtn, mChangeDevidedView);
        mIsPhoneModeEnable = isVisible;
    }

    @Override
    public void restoreLastState(int state) {
        mButtonState = state;
        mChangeBtn.setImageResource(mButtonState < 3 ? R.drawable.phone_state_landscape_drawable : R.drawable.mic_state_landscape_drawable);
        if (uiType == 0) {
            setBackgroundResource(R.drawable.btn_video_land_bg);
        }
        if (mButtonState >= 3) {
            updateBtnState();
        } else {
            if (isLand) {
                if (uiType == 0) {
                    mCurrentFunBtn.setImageResource(mButtonState < 3 ? R.drawable.btn_video_pushtalk_land : R.drawable.btn_video_pushtalk_phone_land);
                    mCurrentFunBtn.setImageResource(mButtonState < 3 ? R.drawable.btn_video_push_talk : R.drawable.btn_video_push_phone_talk);
                }else{
                    mCurrentFunBtn.setImageResource(mButtonState < 3 ? R.drawable.btn_video_pushtalk_land : R.drawable.btn_video_pushtalk_phone_land_pw);
                }
            } else {
                mCurrentFunBtn.setImageResource(mButtonState < 3 ? R.drawable.btn_video_push_talk : R.drawable.btn_video_push_phone_talk);
            }
            mTipsTv.setText(mButtonState < 3 ? mContext.getString(R.string.talk_mic_normal) : mContext.getString(R.string.talk_phone_normal));
            if (!mIsEnable) {
                mTipsTv.setTextColor(0xffa9a9a9);
            } else {
                mTipsTv.setTextColor(getResources().getColor(R.color.color_video_btn_push_talk_text));
            }
            setPressed(state == AbstractCustomStateButton.PHONE_PRESS ? true : false);
        }
        onChangeStateListener.onChange(mButtonState);
    }

    @Override
    public void setEnabled(boolean enabled) {
        super.setEnabled(enabled);
        if (mTipsTv != null) {
            mTipsTv.setTextColor(enabled ? 0xff6692f7 : 0xffa9a9a9);
        }
        if (mButtonState >= 3) {
            updateBtnState();
        }
    }

    private void updateBtnState() {
        if (!mIsEnable) {
            mTipsTv.setTextColor(0xffa9a9a9);
            if (uiType == 0) {
                mCurrentFunBtn.setImageResource(R.drawable.btn_video_pushtalk_disabled_land);
                setBackgroundResource(R.drawable.btn_land_bg_disabled);
            } else {
                mCurrentFunBtn.setImageResource(R.drawable.phone_disable_pw);
                setBackgroundResource(R.drawable.btn_land_bg_disabled_pg);
            }
        } else if (mButtonState == PHONE_NORMAL) {
            mTipsTv.setTextColor(0xff6692f7);
            if (uiType == 0) {
                mCurrentFunBtn.setImageResource(R.drawable.btn_video_pushtalk_normal_gogogo_land);
                setBackgroundResource(R.drawable.btn_land_bg_normal);
            } else {
                mCurrentFunBtn.setImageResource(R.drawable.phone_normal_pw);
                setBackgroundResource(R.drawable.btn_land_bg_normal_pg);
            }
        } else {
            mTipsTv.setTextColor(0xffffffff);
            if (uiType == 0) {
                mCurrentFunBtn.setImageResource(R.drawable.btn_video_pushtalk_pressed_land);
                setBackgroundResource(R.drawable.btn_land_bg_pressed);
            } else {
                mCurrentFunBtn.setImageResource(R.drawable.phone_press_pw);
                setBackgroundResource(R.drawable.btn_land_bg_pressed_pg);
            }
        }
    }
}
