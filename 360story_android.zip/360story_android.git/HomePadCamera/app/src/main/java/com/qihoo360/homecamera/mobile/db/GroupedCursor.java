
package com.qihoo360.homecamera.mobile.db;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.database.CharArrayBuffer;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.net.Uri;
import android.os.Bundle;
import android.util.Pair;

import com.qihoo360.homecamera.mobile.utils.Utils;

import java.util.ArrayList;

public class GroupedCursor<G> implements Cursor, IGroupedData<G, Cursor> {
    protected final Cursor mCursor;
    private ArrayList<Pair<G, Integer>> mGroups = new ArrayList<Pair<G, Integer>>(0);
    private int mCount;

    public GroupedCursor(Cursor cursor, IGrouper<G, Cursor> grouper, int count) {
        mCursor = cursor;
        updateGroupInfo(grouper);
        mCount = count;
    }

    protected void finalize() throws Throwable {
        try {
            Utils.close(mCursor);
        } catch (Exception e) {
        }
        super.finalize();
    }

    private final void updateGroupInfo(final IGrouper<G, Cursor> grouper) {
        final ArrayList<Pair<G, Integer>> groups = new ArrayList<Pair<G, Integer>>();
        final Cursor cursor = mCursor;
        cursor.move(-1);
        G lastGroup = null;
        int groupCount = 0;
        while (cursor.moveToNext() == true) {
            final G groupName = grouper.getGroupData(cursor);
            if (grouper.isSameGroup(lastGroup, groupName) == false) {
                if (groupCount == 0) {
                    // first group
                    lastGroup = groupName;
                    groupCount = 1;
                } else {
                    // new group
                    groups.add(new Pair<G, Integer>(lastGroup, groupCount));
                    lastGroup = groupName;
                    groupCount = 1;
                }
            } else {
                groupCount++;
            }
        }
        if (groupCount != 0) {
            groups.add(new Pair<G, Integer>(lastGroup, groupCount));
        }
        mGroups = groups;
        Utils.close(cursor);
    }

    @Override
    public String toString() {
        StringBuilder buf = new StringBuilder("Total Group " + getGroupCount() + "\n");
        for (int i = 0, len = getGroupCount(); i < len; i++) {
            buf.append("Group " + i + ": " + getGroupData(i) + ", children count: " + getGroupChildrenCount(i)).append("\n");
        }
        return buf.toString();
    }

    @Override
    public int getGroupCount() {
        return mGroups.size();
    }

    @Override
    public int getGroupChildrenCount(int groupIndex) {
        return mGroups.get(groupIndex).second;
    }

    @Override
    public G getGroupData(int groupIndex) {
        return mGroups.get(groupIndex).first;
    }

    @Override
    public Cursor getChildrenData(int groupIndex, int childrenIndex) {
        final ArrayList<Pair<G, Integer>> groups = mGroups;
        if (groupIndex >= groups.size()) {
            throw new ArrayIndexOutOfBoundsException("Has " + groups.size() + " groups. Requesting " + groupIndex + " groups");
        }
        int groupStart = 0;
        for (int i = 0; i < groupIndex; i++) {
            groupStart += groups.get(i).second;
        }
        mCursor.moveToPosition(groupStart + childrenIndex);
        return mCursor;
    }

    /**
     * Gets the underlying cursor that is wrapped by this instance.
     *
     * @return The wrapped cursor.
     */
    public Cursor getWrappedCursor() {
        return mCursor;
    }

    @Override
    public void close() {
        // in android 2.x, this called in ImageCursorFilter.finalize()
        // do not close cursor, it will crash, outside still in using
        // call closeCursor() to manual close cursor.
    }

    public void closeCursor() {
        Utils.close(mCursor);
    }

    @Override
    public boolean isClosed() {
        return mCursor.isClosed();
    }

    @Override
    public int getCount() {
        return mCount;
    }

    @Override
    public void deactivate() {
        mCursor.deactivate();
    }

    @Override
    public boolean moveToFirst() {
        return mCursor.moveToFirst();
    }

    @Override
    public int getColumnCount() {
        return mCursor.getColumnCount();
    }

    @Override
    public int getColumnIndex(String columnName) {
        return mCursor.getColumnIndex(columnName);
    }

    @Override
    public int getColumnIndexOrThrow(String columnName)
            throws IllegalArgumentException {
        return mCursor.getColumnIndexOrThrow(columnName);
    }

    @Override
    public String getColumnName(int columnIndex) {
        return mCursor.getColumnName(columnIndex);
    }

    @Override
    public String[] getColumnNames() {
        return mCursor.getColumnNames();
    }

    @Override
    public double getDouble(int columnIndex) {
        return mCursor.getDouble(columnIndex);
    }

    @Override
    public Bundle getExtras() {
        return mCursor.getExtras();
    }

    @Override
    public float getFloat(int columnIndex) {
        return mCursor.getFloat(columnIndex);
    }

    @Override
    public int getInt(int columnIndex) {
        return mCursor.getInt(columnIndex);
    }

    @Override
    public long getLong(int columnIndex) {
        return mCursor.getLong(columnIndex);
    }

    @Override
    public short getShort(int columnIndex) {
        return mCursor.getShort(columnIndex);
    }

    @Override
    public String getString(int columnIndex) {
        return mCursor.getString(columnIndex);
    }

    @Override
    public void copyStringToBuffer(int columnIndex, CharArrayBuffer buffer) {
        mCursor.copyStringToBuffer(columnIndex, buffer);
    }

    @Override
    public byte[] getBlob(int columnIndex) {
        return mCursor.getBlob(columnIndex);
    }

    @Override
    public boolean getWantsAllOnMoveCalls() {
        return mCursor.getWantsAllOnMoveCalls();
    }

    @Override
    public void setExtras(Bundle extras) {

    }

    @Override
    public boolean isAfterLast() {
        return mCursor.isAfterLast();
    }

    @Override
    public boolean isBeforeFirst() {
        return mCursor.isBeforeFirst();
    }

    @Override
    public boolean isFirst() {
        return mCursor.isFirst();
    }

    @Override
    public boolean isLast() {
        return mCursor.isLast();
    }

    @SuppressLint("NewApi")
    @Override
    public int getType(int columnIndex) {
        return mCursor.getType(columnIndex);
    }

    @Override
    public boolean isNull(int columnIndex) {
        return mCursor.isNull(columnIndex);
    }

    @Override
    public boolean moveToLast() {
        return mCursor.moveToLast();
    }

    @Override
    public boolean move(int offset) {
        return mCursor.move(offset);
    }

    @Override
    public boolean moveToPosition(int position) {
        return mCursor.moveToPosition(position);
    }

    @Override
    public boolean moveToNext() {
        return mCursor.moveToNext();
    }

    @Override
    public int getPosition() {
        return mCursor.getPosition();
    }

    @Override
    public boolean moveToPrevious() {
        return mCursor.moveToPrevious();
    }

    @Override
    public void registerContentObserver(ContentObserver observer) {
        mCursor.registerContentObserver(observer);
    }

    @Override
    public void registerDataSetObserver(DataSetObserver observer) {
        mCursor.registerDataSetObserver(observer);
    }

    @Override
    @SuppressWarnings("deprecation")
    public boolean requery() {
        return mCursor.requery();
    }

    @Override
    public Bundle respond(Bundle extras) {
        return mCursor.respond(extras);
    }

    @Override
    public void setNotificationUri(ContentResolver cr, Uri uri) {
        mCursor.setNotificationUri(cr, uri);
    }

    @Override
    public void unregisterContentObserver(ContentObserver observer) {
        mCursor.unregisterContentObserver(observer);
    }

    @Override
    public void unregisterDataSetObserver(DataSetObserver observer) {
        mCursor.unregisterDataSetObserver(observer);
    }

    @Override
    public Uri getNotificationUri() {
        // TODO Auto-generated method stub
        return null;
    }
}
