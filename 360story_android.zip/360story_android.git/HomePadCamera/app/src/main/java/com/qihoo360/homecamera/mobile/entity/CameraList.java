
package com.qihoo360.homecamera.mobile.entity;

import android.annotation.SuppressLint;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/1/18
 * Time: 18:54
 * To change this template use File | Settings | File Templates.
 */
@SuppressLint("ParcelCreator")
public class CameraList extends Head {
    @SerializedName("data")
    public List<Camera> cameras;
}
