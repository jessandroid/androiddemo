
package com.qihoo360.homecamera.mobile.exception;

/**
 * 异常基类，程序中所有自定义异常需继承此类
 * 
 *  @author shanxueyi
 */
public class CameraException extends Exception {
    private static final long serialVersionUID = 1L;
    //附加内容
    private String mExtra;

    public CameraException(String message) {
        super(message);
    }

    public CameraException(String message, String extra) {
        super(message);
        mExtra = extra;
    }
    
    public String getExtra() {
        return mExtra;
    }
}
