package com.qihoo360.homecamera.machine.entity;

/**
 * 领域对象基础接口
 */
public interface CameraType {
}
