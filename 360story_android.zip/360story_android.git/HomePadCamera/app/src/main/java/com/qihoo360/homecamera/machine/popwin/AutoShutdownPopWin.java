package com.qihoo360.homecamera.machine.popwin;


import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.qihoo360.homecamera.machine.fragment.StoryPlayerFragment;
import com.qihoo360.homecamera.mobile.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lixin3-s on 2016/11/15.
 */
public class AutoShutdownPopWin extends BasePopWin{

    public RadioGroup mRadioGroup;
    public List<String> mData;
    public AutoShutdownPopWin(StoryPlayerFragment fragment, View parent) {
        super(fragment.getActivity(), parent);
    }

    @Override
    int getLayoutId() {
        return R.layout.set_auto_shutdown_popwin;
    }

    @Override
    void initView() {
        mRadioGroup = (RadioGroup) contentView.findViewById(R.id.rg_auto_shutdown);
        mRadioGroup.check(R.id.rb_auto_shutdown_close);
        mRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (mOnSelectedTimeListener == null) {
                    return;
                }
            }
        });

        //点击确定
        mRlCancelArea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mOnSelectedTimeListener.onSure(getMinutesById(mRadioGroup.getCheckedRadioButtonId()));
            }
        });
    }

    public void setCurrentSected(int min){
        switch(min){
            case -1:
                mRadioGroup.check(R.id.rb_auto_shutdown_close);
                break;

            case 10:
                mRadioGroup.check(R.id.rb_auto_shutdown_10_min);
                break;

            case 20:
                mRadioGroup.check(R.id.rb_auto_shutdown_20_min);
                break;

            case 30:
                mRadioGroup.check(R.id.rb_auto_shutdown_30_min);
                break;

            case 60:
                mRadioGroup.check(R.id.rb_auto_shutdown_60_min);
                break;
        }
    }

    private int getMinutesById(int checkedId) {
        int minutes = -1;
        switch (checkedId) {
            case R.id.rb_auto_shutdown_close:
                minutes = -1;
                break;
            case R.id.rb_auto_shutdown_10_min:
                minutes = 10;
                break;
            case R.id.rb_auto_shutdown_20_min:
                minutes = 20;
                break;
            case R.id.rb_auto_shutdown_30_min:
                minutes = 30;
                break;
            case R.id.rb_auto_shutdown_60_min:
                minutes = 60;
                break;
        }
        return minutes;
    }


    static class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {
        public
        List<String> d;
        Context mContext;
        public Adapter(Context context, List<String> data) {
            d = data;
            mContext = context;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(mContext).inflate(android.R.layout.simple_list_item_1, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            holder.tv.setText(d.get(position));
        }

        @Override
        public int getItemCount() {
            return d.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView tv;
            public ViewHolder(View itemView) {
                super(itemView);
                tv = (TextView) itemView.findViewById(android.R.id.text1);
                tv.setTextColor(Color.BLACK);
            }
        }

    }

    public void setOnSelectedTimeListener(OnSelectedTimeListener onSelectedTimeListener) {
        this.mOnSelectedTimeListener = onSelectedTimeListener;
    }

    private OnSelectedTimeListener mOnSelectedTimeListener;

    public  interface OnSelectedTimeListener {
        void onSelectedTime(int minutes);
        void onSure(int minutes);
    }

}
