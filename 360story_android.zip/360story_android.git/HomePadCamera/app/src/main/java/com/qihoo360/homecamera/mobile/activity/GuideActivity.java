
package com.qihoo360.homecamera.mobile.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.qihoo.sdk.report.QHStatAgent;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.DensityUtil;
import com.qihoo360.homecamera.mobile.utils.Preferences;

import java.util.ArrayList;
import java.util.List;

public class GuideActivity extends Activity {

    private ViewPager mPager;
    private LinearLayout mDotsLayout;
    private ImageButton mBtn;

    private List<View> viewList;

    public static void startActivity(Context context) {
        Intent intent = new Intent(context, GuideActivity.class);
        context.startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guide);
        CLog.d("--------------->2222");
        mPager = (ViewPager) findViewById(R.id.guide_viewpager);
        mDotsLayout = (LinearLayout) findViewById(R.id.guide_dots);
        mBtn = (ImageButton) findViewById(R.id.guide_btn);
        findViewById(R.id.btnSkip).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                openHome();
            }
        });

        initPager();
        mPager.setAdapter(new ViewPagerAdapter(viewList));
        mPager.setOnPageChangeListener(new OnPageChangeListener() {

            @Override
            public void onPageSelected(int arg0) {
                // TODO Auto-generated method stub
                for (int i = 0; i < mDotsLayout.getChildCount(); i++) {
                    if (i == arg0) {
                        mDotsLayout.getChildAt(i).setSelected(true);
                    } else {
                        mDotsLayout.getChildAt(i).setSelected(false);
                    }
                }
                if (arg0 == mDotsLayout.getChildCount() - 1) {
                    mBtn.setVisibility(View.GONE);
                } else {
                    mBtn.setVisibility(View.GONE);
                }
            }

            @Override
            public void onPageScrolled(int arg0, float arg1, int arg2) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onPageScrollStateChanged(int arg0) {
                // TODO Auto-generated method stub

            }
        });

        mBtn.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                openHome();
            }
        });
        CLog.d("--------------->222--");
    }

    @Override
    protected void onResume() {
        super.onResume();
        QHStatAgent.onResume(this);
        QHStatAgent.onPageStart(this, this.getClass().getName());
    }

    @Override
    protected void onPause() {
        super.onPause();
        QHStatAgent.onPause(this);
        QHStatAgent.onPageEnd(this, this.getClass().getName());
    }

    private void initPager() {
        viewList = new ArrayList<View>();
        int[] images = new int[]{
                R.drawable.guide_1, R.drawable.guide_2, R.drawable.guide_3, R.drawable.guide_4,
        };
        int[] texts = new int[]{
                R.drawable.guide_text_1, R.drawable.guide_text_2, R.drawable.guide_text_3, R.drawable.guide_text_4
        };
//        for (int i = 0; i < images.length; i++) {
//            viewList.add(initView(images[i]));
//        }
        for (int i = 0; i < images.length; i++) {
            viewList.add(initView(images[i], texts[i], i == images.length - 1));
        }
        initDots(images.length);
    }

    private void initDots(int count) {
        for (int j = 0; j < count; j++) {
            mDotsLayout.addView(initDot(j));
        }
        mDotsLayout.getChildAt(0).setSelected(true);
    }

    private View initDot(int pos) {
        View view = LayoutInflater.from(getApplicationContext()).inflate(R.layout.layout_dot, null);
        ImageView dotIv = (ImageView) view.findViewById(R.id.iv_dot);
        switch (pos) {
            case 0:
                dotIv.setImageResource(R.drawable.point_1);
                break;
            case 1:
                dotIv.setImageResource(R.drawable.point_2);
                break;
            case 2:
                dotIv.setImageResource(R.drawable.point_3);
                break;
            case 3:
                dotIv.setImageResource(R.drawable.point_4);
                break;
        }
        return view;
    }

    private View initView(int res, int txtRes, boolean isFinal) {
        View view = LayoutInflater.from(getApplicationContext()).inflate(R.layout.item_guide, null);
        ImageView imageView = (ImageView) view.findViewById(R.id.iguide_img);
        ImageView textview = (ImageView) view.findViewById(R.id.iguide_text);
        ImageButton imageButton = (ImageButton) view.findViewById(R.id.guide_btn);
        imageView.setImageResource(res);
        textview.setImageResource(txtRes);
        if (!isFinal) {
            RelativeLayout.LayoutParams rl = (RelativeLayout.LayoutParams) textview.getLayoutParams();
            rl.bottomMargin = DensityUtil.dip2px(120);
            textview.setLayoutParams(rl);
            imageButton.setVisibility(View.GONE);
        } else {
            imageButton.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View view) {
                    openHome();
                }
            });
        }
        return view;
    }

    @Override
    public void finish() {
        super.finish();
    }

    private void openHome() {
        Preferences.hasShowGuide();
        finish();
//        Preferences.setShowGuide(true);
//        if (TextUtils.isEmpty(AccUtil.getInstance().getSessionId())) {
//            Intent intent = new Intent(this, NewLoginRegActivity.class);
//            intent.putExtra(NewLoginRegActivity.KEY_MODE, NewLoginRegActivity.MODE_BEGIN);
//            startActivity(intent);
//            finish();
//        } else {
//            Intent intent;
//            if (this.getIntent().getExtras() != null && !this.getIntent().getExtras().isEmpty()) {
//                intent = this.getIntent();
//            } else {
//                intent = new Intent();
//            }
//            intent.setClass(this, TabMainActivity.class);
//            startActivity(intent);
//            finish();
//        }
    }

    class ViewPagerAdapter extends PagerAdapter {

        private List<View> data;

        public ViewPagerAdapter(List<View> data) {
            super();
            this.data = data;
        }

        @Override
        public int getCount() {
            // TODO Auto-generated method stub
            return data.size();
        }

        @Override
        public boolean isViewFromObject(View arg0, Object arg1) {
            // TODO Auto-generated method stub
            return arg0 == arg1;
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            // TODO Auto-generated method stub
            container.addView(data.get(position));
            if (position == getCount() - 1) {
                data.get(position).setOnClickListener(new OnClickListener() {

                    @Override
                    public void onClick(View v) {
//                        openHome();
                    }
                });
            }
            return data.get(position);
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView(data.get(position));
        }

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
