package com.qihoo360.homecamera.mobile.db;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.qihoo360.homecamera.machine.business.PlayConfig;
import com.qihoo360.homecamera.machine.entity.MachineSong;
import com.qihoo360.homecamera.mobile.core.net.MachineApi;
import com.qihoo360.homecamera.mobile.entity.CamInfo;
import com.qihoo360.homecamera.mobile.entity.DeviceInfo;
import com.qihoo360.homecamera.mobile.entity.PrivateEntity;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.utils.CLog;

import java.util.ArrayList;

/**
 * Created by zhaojunbo on 2016/5/5.
 * desc:
 */
public class MachineSongWrapper extends AbstractWrapper {

    public static final String TABLE_NAME = "machine_song";
    private static MachineSongWrapper mInstance;

    public static MachineSongWrapper getInstance() {
        if (mInstance == null) {
            synchronized (MachineSongWrapper.class) {
                if (mInstance == null) {
                    mInstance = new MachineSongWrapper();

                }
            }
        }
        return mInstance;
    }

    //根据sn、type和unique来获取儿歌列表，（收藏列表和导入的列表,没有unique传空）
    public ArrayList<MachineSong> getMachineSongList(String sn, int typefrom, String unique){
        SQLiteDatabase sqLiteDatabase = GlobalManager.getInstance().config().db.getWritableDatabase();
        ArrayList<MachineSong> machineSongList = new ArrayList<>();
        Cursor cursor = null;
        try {
            if(typefrom == PlayConfig.ListType.INSERTLIST || typefrom == PlayConfig.ListType.FAVORLIST){
                cursor = sqLiteDatabase.query(TABLE_NAME, null, "sn=? and typefrom=?", new String[]{sn, String.valueOf(typefrom)}, null, null, null);
            }else{
                cursor = sqLiteDatabase.query(TABLE_NAME, null, "sn=? and typefrom=? and uniqueString=?", new String[]{sn, String.valueOf(typefrom), unique}, null, null, null);
            }
            CLog.e("zt", "数据库中该列表的数据：" + cursor.getCount());
            while (cursor.moveToNext()) {
                CLog.e("z", "sn:" + cursor.getString(cursor.getColumnIndex(Field.KEY_SN)));
                MachineSong machineSong = new MachineSong();
                machineSong.sn = cursor.getString(cursor.getColumnIndex(Field.KEY_SN));
                machineSong.unique = cursor.getString(cursor.getColumnIndex(Field.KEY_UNIQUE));
                machineSong.uniqueid = cursor.getString(cursor.getColumnIndex(Field.KEY_UNIQUEID));
                machineSong.title = cursor.getString(cursor.getColumnIndex(Field.KEY_TITLE));
                machineSong.mediaurl = cursor.getString(cursor.getColumnIndex(Field.KEY_MEDIAURL));
                machineSong.type = cursor.getInt(cursor.getColumnIndex(Field.KEY_TYPE));
                machineSong.srclogo = cursor.getString(cursor.getColumnIndex(Field.KEY_SRCLOGO));
                machineSong.src = cursor.getString(cursor.getColumnIndex(Field.KEY_SRC));
                machineSong.md5 = cursor.getString(cursor.getColumnIndex(Field.KEY_MD5));
                machineSong.volume = cursor.getString(cursor.getColumnIndex(Field.KEY_VOLUME));
                machineSong.typeFrom = cursor.getInt(cursor.getColumnIndex(Field.KEY_TYPEFROM));
                machineSongList.add(machineSong);
            }
        } catch (Exception e) {
            CLog.e(e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return machineSongList;
    }

    //更新一个列表，没有就插入
    public synchronized void updateSongList(ArrayList<MachineSong> songList){
        SQLiteDatabase sqLiteDatabase = GlobalManager.getInstance().config().db.getWritableDatabase();
        if(songList!=null && songList.size()>0){
            CLog.e("zt","typeFrom:"+songList.get(0).typeFrom);
            if(songList.get(0).typeFrom == PlayConfig.ListType.INSERTLIST || songList.get(0).typeFrom == PlayConfig.ListType.FAVORLIST){
                sqLiteDatabase.delete(TABLE_NAME, "sn=? and typefrom=?", new String[]{songList.get(0).sn, String.valueOf(songList.get(0).typeFrom)});
            }else{
                sqLiteDatabase.delete(TABLE_NAME, "sn=? and typefrom=? and uniqueString=?", new String[]{songList.get(0).sn, String.valueOf(songList.get(0).typeFrom), songList.get(0).unique});
            }

            for(int i=0; i<songList.size(); i++) {
                MachineSong song = songList.get(i);
                ContentValues values = new ContentValues();
                values.put(Field.KEY_SN, song.sn);
                values.put(Field.KEY_UNIQUE, song.unique);
                values.put(Field.KEY_UNIQUEID, song.uniqueid);
                values.put(Field.KEY_TITLE, song.title);
                values.put(Field.KEY_MEDIAURL, song.mediaurl);
                values.put(Field.KEY_TYPE, song.type);
                values.put(Field.KEY_SRCLOGO, song.srclogo);
                values.put(Field.KEY_SRC, song.src);
                values.put(Field.KEY_MD5, song.md5);
                values.put(Field.KEY_VOLUME, song.volume);
                values.put(Field.KEY_TYPEFROM, song.typeFrom);
                sqLiteDatabase.insert(TABLE_NAME, "", values);
            }
        }
    }

    public synchronized void clearTable(ArrayList<MachineSong> songList){
        SQLiteDatabase sqLiteDatabase = GlobalManager.getInstance().config().db.getWritableDatabase();
        if(songList.get(0).typeFrom == PlayConfig.ListType.INSERTLIST || songList.get(0).typeFrom == PlayConfig.ListType.FAVORLIST){
            sqLiteDatabase.delete(TABLE_NAME, "sn=? and typefrom=?", new String[]{songList.get(0).sn, String.valueOf(songList.get(0).typeFrom)});
        }else{
            sqLiteDatabase.delete(TABLE_NAME, "sn=? and typefrom=? and uniqueString=?", new String[]{songList.get(0).sn, String.valueOf(songList.get(0).typeFrom), songList.get(0).unique});
        }
    }

    public void deleteList(MachineSong song) {
        SQLiteDatabase sqLiteDatabase = GlobalManager.getInstance().config().db.getWritableDatabase();
        CLog.e("zt", "typeFrom:" + song.typeFrom);
        if (song.typeFrom == PlayConfig.ListType.INSERTLIST || song.typeFrom == PlayConfig.ListType.FAVORLIST) {
            sqLiteDatabase.delete(TABLE_NAME, "sn=? and typefrom=?", new String[]{song.sn, String.valueOf(song.typeFrom)});
        } else {
            sqLiteDatabase.delete(TABLE_NAME, "sn=? and typefrom=? and uniqueString=?", new String[]{song.sn, String.valueOf(song.typeFrom), song.unique});
        }
    }

   //判断儿歌是否收藏
   public boolean isSongFavor(String sn, String uniqueId){
       SQLiteDatabase sqLiteDatabase = GlobalManager.getInstance().config().db.getWritableDatabase();
       Cursor cursor = null;
       try{
           cursor = sqLiteDatabase.query(TABLE_NAME, null, "sn=? and typefrom=? and uniqueid=?", new String[]{sn, String.valueOf(PlayConfig.ListType.FAVORLIST), uniqueId}, null, null, null);
           if(cursor.getCount()>0){
               return true;
           }
       }catch (Exception e) {
           CLog.e(e);
       } finally {
           if (cursor != null) {
               cursor.close();
           }
       }
       return false;
   }

    //获取某个列表的md5值
    public String getLisMd5(String sn, int typefrom, String unique){
        SQLiteDatabase sqLiteDatabase = GlobalManager.getInstance().config().db.getWritableDatabase();

        Cursor cursor = null;
        try {
            if(typefrom == PlayConfig.ListType.INSERTLIST || typefrom == PlayConfig.ListType.FAVORLIST){
                cursor = sqLiteDatabase.query(TABLE_NAME, null, "sn=? and typefrom=?", new String[]{sn, String.valueOf(typefrom)}, null, null, null);
            }else{
                cursor = sqLiteDatabase.query(TABLE_NAME, null, "sn=? and typefrom=? and uniqueString=?", new String[]{sn, String.valueOf(typefrom), unique}, null, null, null);
            }
            CLog.e("zt", "cursor" + cursor.getCount());
            if(cursor.getCount()>0){
                cursor.moveToFirst();
                return cursor.getString(cursor.getColumnIndex(Field.KEY_MD5));
            }else{
                return "";
            }
        } catch (Exception e) {
            CLog.e(e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return "";
    }

    //清除该sn下的所有数据
    public void cleanSongData(String sn){
        if(TextUtils.isEmpty(sn)){
            return;
        }
        try{
            SQLiteDatabase sqLiteDatabase = GlobalManager.getInstance().config().db.getWritableDatabase();
            sqLiteDatabase.delete(TABLE_NAME, "sn = ?", new String[]{sn});
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int toVersion) {
        switch (toVersion){
            case  10:
                db.execSQL("CREATE TABLE IF NOT EXISTS machine_song (_id INTEGER, sn varchar(255,0), uniqueString varchar(255,0), uniqueid varchar(255,0), title varchar(255,0), mediaurl varchar(255,0), type INTEGER, typefrom INTEGER, srclogo varchar(255,0), volume varchar(255,0), src varchar(255,0), md5 varchar(255,0), PRIMARY KEY(_id));");
                break;
        }
    }

    @Override
    public void onOpen(SQLiteDatabase db) {

    }

    private static final class Field {
        public static final String KEY_SN = "sn";
        public static final String KEY_UNIQUE = "uniqueString";
        public static final String KEY_UNIQUEID = "uniqueid";
        public static final String KEY_TITLE = "title";
        public static final String KEY_MEDIAURL = "mediaurl";
        public static final String KEY_TYPE = "type";
        public static final String KEY_SRCLOGO = "srclogo";
        public static final String KEY_SRC = "src";
        public static final String KEY_MD5 = "md5";
        public static final String KEY_VOLUME = "volume";
        public static final String KEY_TYPEFROM = "typefrom";
    }
}
