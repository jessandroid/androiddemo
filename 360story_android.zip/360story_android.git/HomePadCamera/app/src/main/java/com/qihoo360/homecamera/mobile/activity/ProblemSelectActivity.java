package com.qihoo360.homecamera.mobile.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.config.Const;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.widget.SettingItem;

public class ProblemSelectActivity extends BaseActivity implements View.OnClickListener {

    private View kibotProblemZone;

    private View machineProblemZone;

    private ImageView machine_problem_arrow;

    private ImageView kibot_problem_arrow;

    private ImageView btnBack;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_problem_select);
        initView();
    }

    private void initView(){
        kibotProblemZone = findViewById(R.id.kibot_problem_zone);
        kibotProblemZone.setOnClickListener(this);
        machineProblemZone = findViewById(R.id.machine_problem_zone);
        machineProblemZone.setOnClickListener(this);

        kibot_problem_arrow = (ImageView) findViewById(R.id.kibot_problem_arrow);
        machine_problem_arrow = (ImageView) findViewById(R.id.machine_problem_arrow);
        btnBack = (ImageView) findViewById(R.id.btn_back);

        btnBack.setOnClickListener(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.kibot_problem_zone:
                kibot_problem_arrow.performClick();
                Intent intent = new Intent(this, WebViewActivity.class);
                intent.putExtra("url", Const.PROBLEM_URL);
                startActivity(intent);
                break;

            case R.id.machine_problem_zone:
                machine_problem_arrow.performClick();
                Intent intent2 = new Intent(this, WebViewActivity.class);
                intent2.putExtra("url", Const.MACHINE_PROBLEM_URL);
                startActivity(intent2);
                break;

            case R.id.btn_back:
                this.finish();
                break;
        }
    }

}
