package com.qihoo360.homecamera.machine.manager;

import com.qihoo360.homecamera.machine.entity.BindBannerEntity;
import com.qihoo360.homecamera.machine.entity.MachinePlaySingle;
import com.qihoo360.homecamera.machine.entity.SongEntity;
import com.qihoo360.homecamera.machine.entity.SongListResponse;
import com.qihoo360.homecamera.machine.log.MachineLogTag;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionPublisherWithThreadPoolBase;
import com.qihoo360.homecamera.mobile.core.manager.workpool.PoolThreadFactory;
import com.qihoo360.homecamera.mobile.core.net.MachineApi;
import com.qihoo360.homecamera.mobile.entity.Head;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.Utils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.Executors;

/**
 * Created by zhangchao-pd on 2016/11/14.
 */

public class MachineManager extends ActionPublisherWithThreadPoolBase {

    private static final String JOB_NAME_STREAM_PLAY = "StreamPlay";
    private static final String JOB_NAME_COMMAND = "Command";
    private static final String JOB_NAME_GET_ALBUM = "GetAlbum";
    private static final String JOB_NAME_GET_BANNER = "GetBanner";

    private final String mPoolNameHighPriority, mPoolNameLowPriority;

    public MachineManager() {
        mPoolNameHighPriority = "CameraManager-high-priority-" + Utils.DATE_FORMAT_3.format(new Date());
        mPoolNameLowPriority = "CameraManager-low-priority-" + Utils.DATE_FORMAT_3.format(new Date());
        mThreadPool.initPool(mPoolNameHighPriority, Executors.newFixedThreadPool(3));
        mThreadPool.initPool(mPoolNameLowPriority, Executors.newCachedThreadPool(new PoolThreadFactory(mPoolNameLowPriority)));
    }

    @Override
    protected void asyncDoNamedJob(String jobName, Object... args) {
        switch (jobName) {
            case JOB_NAME_STREAM_PLAY:
                if(args != null && args.length >= 1) {
                    doStreamPlay((String)args[0]);
                }
                break;

            case JOB_NAME_COMMAND:
                if(args != null && args.length >= 3) {
                    doCommand((String)args[0], (String)args[1], (String)args[2]);
                }
                break;

            case JOB_NAME_GET_ALBUM:
                if(args != null && args.length >= 3) {
                    doGetAlbum((String)args[0], (int)args[1], (int)args[2]);
                }
                break;

            case JOB_NAME_GET_BANNER:
                doGetBanner();
                break;

        }
    }

    /**
     * 同步执行app/play
      */
    private void doStreamPlay(String sn) {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        publishAction(Actions.Play.CONNECT_ENCRYPTION);
    }

    /**
     * 同步执行app/command
     * @param cmd
     * @param sn
     * @param content
     */
    private void doCommand(String cmd, String sn, String content) {
        CLog.i(MachineLogTag.LOG_TAG_MACHINE, "发起对故事机的命令,cmd=" + cmd + ",sn=" + sn + ",content=" + content);
        Head head = MachineApi.Machine.doCommand(cmd, sn, content);
    }

    /**
     * 同步执行app/getalbum
     * @param unique
     * @param pageId
     * @param token(0--专辑列表 1---播放列表)
     */
    private void doGetAlbum(String unique, int pageId, int token) {
        SongListResponse songListResponse = MachineApi.Machine.doGetAlbum(unique, pageId);
        publishAction(Actions.GlobalActionCode.GET_SONGLIST_LIST, songListResponse, token);
    }

    //获取轮播图
    private void doGetBanner(){
        BindBannerEntity bannerEntity = MachineApi.Machine.doGetBanner();
        publishAction(Actions.GlobalActionCode.GET_BIND_BANNER_LIST, bannerEntity);
    }

    /**
     * 异步执行app/play
     */
    public void asyncStreamPlay(String sn) {
        submitAsyncJob(mPoolNameHighPriority, JOB_NAME_STREAM_PLAY, sn);
    }


    /**
     * 获取专辑信息
     * @param unique
     * @param pageId
     * @param actionToken(0 1)
     */
    public void asyncGetAblum(String unique, int pageId, int actionToken) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob(JOB_NAME_GET_ALBUM, unique, pageId, actionToken));
    }

    /**
     * 获取绑定轮播图
     */
    public void asyncGetBanner() {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob(JOB_NAME_GET_BANNER));
    }
}
