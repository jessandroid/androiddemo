package com.qihoo360.homecamera.mobile.entity;

/**
 * Created by hyuan on 2016/9/27.
 */
public class CommandMessage {
    public String sn = "";
    public String qid = "";
    public String taskId = "";
    public String imagUrl = "";
    public int messageType = 0;
    public int sendOrReceive = 0;
    public int lockTime = 0;
    public long timeExecute;
    public String content = "";
    public String trickContent = "";
    public int sendState = 0;
    public boolean executeSuccess =false;
}
