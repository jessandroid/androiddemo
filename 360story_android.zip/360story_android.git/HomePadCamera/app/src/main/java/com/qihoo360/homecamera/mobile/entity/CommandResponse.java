package com.qihoo360.homecamera.mobile.entity;

/**
 * Created by hyuan on 2016/9/27.
 */
public class CommandResponse {
    public Data data;
    public static class Data{
        public boolean online;
    }
}
