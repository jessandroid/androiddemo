package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;

import com.google.gson.annotations.SerializedName;
import com.qihoo360.accounts.api.auth.model.UserTokenInfo;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by Administrator on 2014/11/27.
 */
public class CamUserInfo extends UserTokenInfo implements Parcelable {

    @SerializedName("sid")
    public String sessionId;
    public String pushKey;
    public String avator_local;
    public String streamId;
    public String streamPwd;
    public String token;

    public CamUserInfo() {}

    public String getAvator_local() {
        return avator_local;
    }

    public void setAvator_local(String avator_local) {
        this.avator_local = avator_local;
    }

    public String getLocalIcoPath() {
        String urlStr = TextUtils.isEmpty(mAvatorUrl)?"":mAvatorUrl;
        if (!TextUtils.isEmpty(urlStr)) {
            urlStr = urlStr.substring(urlStr.lastIndexOf("/") + 1, urlStr.length());
        }
        return urlStr;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.sessionId);
        dest.writeString(this.pushKey);
        dest.writeString(this.avator_local);
        dest.writeString(this.streamId);
        dest.writeString(this.streamPwd);
        dest.writeString(this.token);
    }

    protected CamUserInfo(Parcel in) {
        this.sessionId = in.readString();
        this.pushKey = in.readString();
        this.avator_local = in.readString();
        this.streamId = in.readString();
        this.streamPwd = in.readString();
        this.token = in.readString();
    }

    public static final Parcelable.Creator<CamUserInfo> CREATOR = new Parcelable.Creator<CamUserInfo>() {
        @Override
        public CamUserInfo createFromParcel(Parcel source) {
            return new CamUserInfo(source);
        }

        @Override
        public CamUserInfo[] newArray(int size) {
            return new CamUserInfo[size];
        }
    };

    public void setUserInfo2Me(UserTokenInfo userInfo2Me){
        this.u=userInfo2Me.u;
        this.qid=userInfo2Me.qid;
        this.q=userInfo2Me.q;
        this.t=userInfo2Me.t;
        this.mUsername=userInfo2Me.mUsername;
        this.mLoginEmail=userInfo2Me.mLoginEmail;
        this.mNickname=userInfo2Me.mNickname;
        this. mAvatorFlag=userInfo2Me.mAvatorFlag;
        this.mAvatorUrl=userInfo2Me.mAvatorUrl;
        this.mSecPhoneZone=userInfo2Me.mSecPhoneZone;
        this.mSecPhoneNumber=userInfo2Me.mSecPhoneNumber;
        this.mSecEmail=userInfo2Me.mSecEmail;
        this.orgInfo=userInfo2Me.orgInfo;
    }

    public String qidAndSessionId2Json(){
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("qid",qid);
            jsonObject.put("sessionId",sessionId);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return  jsonObject.toString();
    }

}
