package com.qihoo360.homecamera.machine.fragment;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsPromptResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.qihoo360.homecamera.device.config.StoryMachineConsts;
import com.qihoo360.homecamera.machine.activity.MachineAlbumActivity;
import com.qihoo360.homecamera.machine.activity.StoryPlayerActivity;
import com.qihoo360.homecamera.machine.activity.StorySearchActivity;
import com.qihoo360.homecamera.machine.business.JsonManager;
import com.qihoo360.homecamera.machine.business.PlayConfig;
import com.qihoo360.homecamera.machine.business.SettingTask;
import com.qihoo360.homecamera.machine.business.TaskExecutor;
import com.qihoo360.homecamera.machine.entity.FavorResultEntity;
import com.qihoo360.homecamera.machine.entity.MachinePlaySingle;
import com.qihoo360.homecamera.machine.entity.MachineSong;
import com.qihoo360.homecamera.machine.entity.SongEntity;
import com.qihoo360.homecamera.machine.entity.WebviewEntity;
import com.qihoo360.homecamera.machine.manager.MachinePlayInfoManager;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.config.DefaultClientConfig;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.db.MachineSongWrapper;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.ui.fragment.BaseFragment;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.Preferences;
import com.qihoo360.homecamera.mobile.utils.QHStatAgentHelper;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.widget.CommonWebView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.ref.SoftReference;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;


public class StorySearchFragment extends BaseFragment implements View.OnClickListener, ActionListener {

    private CommonWebView webView;
    private ImageView mImageViewPlayerEnter;
    private String webUrl;
    private MyHandler myHandler = new MyHandler(this);
    private boolean isOnline = true;
    private StorySearchActivity mMainActivity;
    private String device_type;

    private static class ActionType {
        public static String PLAYALBUM = "playAlbum";
        public static String PLAYSONG = "playSong";
        public static String COLLECTSONG = "collectSong";
        public static String PLAYSTATUS = "playStatus";
        public static String UID = "uid";
        public static String CATECHANGE = "cateChange";
        public static String COLLECTLIST = "collectList";
        public static String COLLECTJUMP = "collectJump";
        public static String ISONLINE = "online";
        public static String CANCLESEARCH = "searchCancel";
        public static String RELOAD = "reload";
    }

    private Gson gson;

    private StoryProxy mJavaScriptinterface;

    private String failUrl;

    @Override
    public boolean onTabSwitched() {
        return false;
    }

    public static StorySearchFragment newInstance(boolean isOnline) {
        StorySearchFragment fragment = new StorySearchFragment();
        Bundle args = new Bundle();
        args.putBoolean("isOnline", isOnline);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_story_search, null);
        device_type = (String)(getArguments().get(StoryMachineConsts.KEY_SET_DEVICE_TYPE));
//        Log.e("Mars1","search device_type: "+device_type);
        webView = (CommonWebView) view.findViewById(R.id.web_view_story_library);
        mImageViewPlayerEnter = (ImageView) view.findViewById(R.id.enter_player);
        Utils.ensuerSetOnclick(this, mImageViewPlayerEnter);
        gson = new Gson();
        webUrl = DefaultClientConfig.STORY_SEARCH_URL;
        MachinePlayInfoManager.getInstance().registerActionListener(this);
        GlobalManager.getInstance().getCameraManager().registerActionListener(this);
        if(getArguments()!=null){
            Bundle bundle = getArguments();
            isOnline = bundle.getBoolean("isOnline", false);
            if(isOnline){
                mImageViewPlayerEnter.setBackgroundResource(R.drawable.playing_big_animator);
                showPlayAnimation();
            }else{
                mImageViewPlayerEnter.setBackgroundResource(R.drawable.enter_player_offline);
            }
        }
        return view;
    }

    @Override
    public void onAttach(Activity activity) {
        mMainActivity = new SoftReference<>((StorySearchActivity) activity).get();
        super.onAttach(activity);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mJavaScriptinterface = new StoryProxy();
        WebSettings mSettings = webView.getSettings();
        saveData(mSettings);
        webView.setWebViewClient(new webViewClient());
        webView.setWebChromeClient(new MyWebChromeClient());
        if (Utils.isHCOrLater()){
            webView.removeJavascriptInterface("searchBoxJavaBridge_");
        }
        if (webUrl.startsWith("http://") || webUrl.startsWith("https://")) {
            synCookies(webUrl);
            webView.loadUrl(webUrl);
        }

        //请求收藏列表
        Observable.create(new Observable.OnSubscribe<String>(){
            @Override
            public void call(Subscriber<? super String> subscriber) {
                String md5 = MachineSongWrapper.getInstance().getLisMd5(Preferences.getSelectedPad(), PlayConfig.ListType.FAVORLIST, "");
                subscriber.onNext(md5);
                subscriber.onCompleted();
            }
        })
        .subscribeOn(Schedulers.io())
        .compose(this.<String>bindToLifecycle())
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Action1<String>() {
            @Override
            public void call(String s) {
                doGetFavor("", s);
            }
        });
    }

    /**
     * HTML5数据存储
     */
    private void saveData(WebSettings mSettings) {
        mSettings.setJavaScriptEnabled(true);//开启javascript
        mSettings.setDefaultTextEncodingName("utf-8");
        mSettings.setAllowFileAccess(true);
        mSettings.setSupportZoom(true);
        mSettings.setBuiltInZoomControls(false);
        mSettings.setUseWideViewPort(true);
        mSettings.setLoadWithOverviewMode(true);
        mSettings.setRenderPriority(WebSettings.RenderPriority.HIGH);
        mSettings.setBlockNetworkImage(true);
        webView.setHorizontalScrollBarEnabled(false);//水平不显示
        webView.setVerticalScrollBarEnabled(false); //垂直不显示

        mSettings.setDomStorageEnabled(true);
        mSettings.setDatabaseEnabled(true);
        mSettings.setAppCacheEnabled(true);
        String appCachePath = getActivity().getCacheDir().getAbsolutePath();
        mSettings.setAppCachePath(appCachePath);
    }

    public void synCookies(String url) {
        CookieSyncManager.createInstance(Utils.getContext());
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.removeSessionCookie();//移除
        cookieManager.setCookie(url, "T=" + AccUtil.getInstance().getT());
        cookieManager.setCookie(url, "Q=" + AccUtil.getInstance().getQ());
        CookieSyncManager.getInstance().sync();
    }

    @Override
    public void onDetach() {
        super.onDetach();
        MachinePlayInfoManager.getInstance().removeActionListener(this);
        GlobalManager.getInstance().getCameraManager().removeActionListener(this);
        if (webView != null) {
            webView.loadDataWithBaseURL(null, "", "text/html", "utf-8", null);
            webView.clearHistory();
            ((ViewGroup) webView.getParent()).removeView(webView);
            webView.destroy();
            webView = null;
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.enter_player:
                if(isOnline){
                    Intent intent = new Intent(getActivity(), StoryPlayerActivity.class);
                    startActivity(intent);
                    getActivity().overridePendingTransition(R.anim.up_in, 0);
                    mMainActivity.finish();
                }else{
                    CameraToast.show(getActivity(), getString(R.string.story_machine_offline), Toast.LENGTH_SHORT);
                }
            break;
        }
    }

    public class MyWebChromeClient extends WebChromeClient {

        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            super.onProgressChanged(view, newProgress);
        }

        @Override
        public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, JsPromptResult result) {
            result.cancel();
            try {
                String json = "";
                String functionName = "";
                Pattern pattern = Pattern.compile("MyApp:(\\{.+\\}?)");
                Matcher matcher = pattern.matcher(message);
                if (matcher.find()) {
                    json = matcher.group(1);
                    JSONObject dataJson = new JSONObject(json);
                    functionName = dataJson.getString("func");
                    JSONArray jsonArray = dataJson.getJSONArray("args");
                    json = jsonArray.get(0).toString();

                    if (functionName.equals("sendMsgToClient")) {
                        mJavaScriptinterface.sendMsgToClient(json);
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return true;
        }

        @Override
        public void onReceivedTitle(WebView view, String title) {
            super.onReceivedTitle(view, title);
        }
    }

    private class webViewClient extends WebViewClient {

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            CLog.e("zt", "回调shouldOverrideUrlLoading");
            view.loadUrl(url);
            return true;
        }

        @Override
        public void onLoadResource(WebView view, String url) {
            super.onLoadResource(view, url);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            view.getSettings().setBlockNetworkImage(false);
            //TODO  告诉native uid
            loadNativeMethod(genUidJson());
            //每次加载新页面都要调用
            webView.addJavascriptInterface(mJavaScriptinterface, "story");
        }


        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
        }

        @Override
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            super.onReceivedError(view, errorCode, description, failingUrl);
            failUrl = failingUrl;
            view.loadUrl("file:///android_asset/err.html");
        }

        @Override
        public void onScaleChanged(WebView view, float oldScale, float newScale) {
            super.onScaleChanged(view, oldScale, newScale);
            webView.requestFocus();
            webView.requestFocusFromTouch();
        }

    }

    /*
     *      H5调用Android端的接口
     *      只会回调sendMsgToClient一个方法
     *      参数为Json串
     */
    private class StoryProxy {

        @JavascriptInterface
        public void sendMsgToClient(String nativeJson) {
            if (TextUtils.isEmpty(nativeJson)) {
                return;
            }
            JSONObject jo = null;
            try {
                jo = new JSONObject(nativeJson);
                String action = jo.getString("action");
                if (TextUtils.isEmpty(action)) {
                    return;
                }
                handlerJson(action, nativeJson);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    //处理native返回的json串
    private void handlerJson(String action, String nativeJson) {CLog.e("zt", "nativeJson:" + nativeJson);
        if (TextUtils.equals(action, ActionType.PLAYALBUM)) {//播放专辑
            //TODO 收到专辑，跳转到专辑详情页
            WebviewEntity.PlayAlbum playAlbum = gson.fromJson(nativeJson, WebviewEntity.PlayAlbum.class);
            if (playAlbum != null && playAlbum.data != null) {
                MachineAlbumActivity.startMachineAlbumActivity(mMainActivity, isOnline, playAlbum.data.unique, MachineAlbumActivity.ALBUMLIST, playAlbum.data.name, playAlbum.data.total, playAlbum.data.coverurl, playAlbum.data.type,device_type);
            }

        } else if (TextUtils.equals(action, ActionType.PLAYSONG)) {//播放儿歌
            if(isOnline){
                WebviewEntity.PlaySong playSong = gson.fromJson(nativeJson, WebviewEntity.PlaySong.class);
                //TODO 发送播放指令
                CameraToast.show(getString(R.string.had_notify_machine), Toast.LENGTH_SHORT);
                doPlayCmd(playSong);
            }else{
                CameraToast.show(getActivity(), getString(R.string.story_machine_offline), Toast.LENGTH_SHORT);
            }

        } else if (TextUtils.equals(action, ActionType.COLLECTSONG)) {//收藏歌曲
            if(isOnline){
                WebviewEntity.CollectSong collectSong = new Gson().fromJson(nativeJson, WebviewEntity.CollectSong.class);
                //TODO 需要发送收藏或者取消收藏的指令
                doFavorCmd(collectSong);
            }else{
                CameraToast.show(getActivity(), getString(R.string.story_machine_offline), Toast.LENGTH_SHORT);
            }
        } else if (TextUtils.equals(action, ActionType.CATECHANGE)) {//跳转到儿歌列表页
            WebviewEntity.SongAlbum songAlbum = gson.fromJson(nativeJson, WebviewEntity.SongAlbum.class);
            //TODO 跳转到儿歌列表页面
            if (songAlbum != null && songAlbum.data != null) {
                MachineAlbumActivity.startMachineAlbumActivity(mMainActivity, isOnline, songAlbum.data.unique, MachineAlbumActivity.SONGLIST, songAlbum.data.title, songAlbum.data.total, songAlbum.data.coverurl, songAlbum.data.type,device_type);
            }
        } else if (TextUtils.equals(action, ActionType.COLLECTJUMP)) {
            //TODO 跳转到收藏页面
            MachineAlbumActivity.startMachineAlbumActivity2(mMainActivity, isOnline, MachineAlbumActivity.FAVORLIST,device_type);
        }else if(TextUtils.equals(action, ActionType.CANCLESEARCH)){
            //取消收藏
            mMainActivity.finish();
        }else if(TextUtils.equals(action, ActionType.RELOAD)){
            if(webView!=null && !TextUtils.isEmpty(failUrl)){
                webView.loadUrl(failUrl);
            }
        }
    }

    //-------------------------------向native发送Json串-------------------------------------------//
    /*
     *   Android调用H5端的接口
     *   需要传入一个json字符串作为参数
     */
    private void loadNativeMethod(final String webviewJson) {
        CLog.e("zt", "webviewJson:" + webviewJson);
        if(webView!=null){
            webView.post(new Runnable() {
                @Override
                public void run() {
                    webView.loadUrl("javascript:sendMsgToWebview('" + webviewJson + "')");
                }
            });
        }
    }

    //生成向native发送的播放状态的json串
    private String genPlayStatusJson(MachinePlaySingle playSingle) {
        WebviewEntity.PlayStatus playStatus = new WebviewEntity.PlayStatus();
        WebviewEntity.PlayStatus.Data data = new WebviewEntity.PlayStatus.Data();
        data.status = playSingle.getStatus();
        data.unique = playSingle.getUnique();
        data.pageid = playSingle.getPageId();

        data.uniqueid = playSingle.getMediaInfo().getUniqueid();
        data.title = playSingle.getMediaInfo().getTitle();
        data.mediaurl = playSingle.getMediaInfo().getMediaurl();
        data.srclogo = playSingle.getMediaInfo().getSrclogo();
        data.src = playSingle.getMediaInfo().getSrc();
        data.type = playSingle.getMediaInfo().getType();
        data.volume = playSingle.getMediaInfo().getVolume();

        playStatus.action = ActionType.PLAYSTATUS;
        playStatus.data = data;
        return gson.toJson(playStatus);
    }


    //生成向native发送UID的json串
    private String genUidJson() {
        WebviewEntity.PushUid pushUid = new WebviewEntity.PushUid();
        WebviewEntity.PushUid.Data data = new WebviewEntity.PushUid.Data();
        data.uid = AccUtil.getInstance().getQID();
        pushUid.action = ActionType.UID;
        pushUid.data = data;
        return gson.toJson(pushUid);
    }

    //生成向native发送收藏列表的json串
    private String genCollectListJson(ArrayList<MachineSong> songList) {
        JSONObject jo = new JSONObject();
        try {
            jo.put("action", ActionType.COLLECTLIST);
            JSONObject jo2 = new JSONObject();
            for (MachineSong song : songList) {
                jo2.put(song.getUniqueid(), 1);
            }
            jo.put("data", jo2);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jo.toString();
    }

    //生成通知native故事机是否在线的json串
    private String genOnlineJson(boolean isOnline) {
        JSONObject jo = new JSONObject();
        try {
            jo.put("action", ActionType.ISONLINE);
            JSONObject jo2 = new JSONObject();
            jo2.put("status", isOnline);
            jo.put("data", jo2);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jo.toString();
    }
    //------------------------------------------end----------------------------------------------//


    //-----------------------------------------指令请求失败--------------------------------------//
    //指令失败异常处理
    static class MyHandler extends Handler{

        WeakReference<StorySearchFragment> storyLibraryFragmentWeakReference;

        MyHandler(StorySearchFragment storyLibraryFragment) {
            storyLibraryFragmentWeakReference = new WeakReference<>(storyLibraryFragment);
        }

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if(storyLibraryFragmentWeakReference.get()!=null && storyLibraryFragmentWeakReference.get().isAdded()){
                storyLibraryFragmentWeakReference.get().handlerCmdExcept((String)msg.obj, msg.arg1);
            }
        }
    }

    private void handlerCmdExcept(String cmd, int errorCode){

        if(TextUtils.equals(cmd, PlayConfig.CommandType.GETPLAYSTATUS)){
            //获取播放信息失败
            if(errorCode==-20){//故事机离线
                loadNativeMethod(genOnlineJson(isOnline));
                isOnline = false;
                mImageViewPlayerEnter.setBackgroundResource(R.drawable.enter_player_offline);
            }
        }else if(TextUtils.equals(cmd, PlayConfig.CommandType.GETPLAYLIST)){
            //获取收藏列表失败
            //获取播放信息失败
            if(errorCode==-20){//故事机离线
                loadNativeMethod(genOnlineJson(isOnline));
                isOnline = false;
                mImageViewPlayerEnter.setBackgroundResource(R.drawable.enter_player_offline);
            }
        }else if(TextUtils.equals(cmd, PlayConfig.CommandType.PLAYCONTROL)){
            //播放儿歌失败
            CameraToast.show(mMainActivity, getString(R.string.play_failed_tip), Toast.LENGTH_SHORT);
        }else if(TextUtils.equals(cmd, PlayConfig.CommandType.DOFAVOR)){
            //收藏失败
            CameraToast.show(mMainActivity, getString(R.string.favor_failed_tip), Toast.LENGTH_SHORT);
        }
    }
//----------------------------------------------end-----------------------------------------------//


    @Override
    public Object actionPerformed(int actionCode, Object... args) {
        switch (actionCode) {

            //更新收藏列表
            case Actions.MachinePlayInfo.NOTIFY_LIST_UPDATE: {
                handlePlayListChange((int) args[0], (String) args[1]);
                return true;
            }

            //播放单曲变了
            case Actions.MachinePlayInfo.NOTIFY_SINGLEPLAY_LIST: {
                handlePlaySingleChange((MachinePlaySingle) args[0], (String) args[1], (String) args[2]);
                return true;
            }

            //单个收藏操作的回执
            case Actions.MachinePlayInfo.NOTIFY_FAVOR_RESULT_UPDATE: {
                handlerFavorResult((FavorResultEntity) args[0], (String) args[1]);
                return true;
            }

            case Actions.MachinePlayInfo.NATIVE_NOTIFY_FAVOR_LIST_UPDATE: {
                Observable.create(new Observable.OnSubscribe<ArrayList<MachineSong>>() {
                    @Override
                    public void call(Subscriber<? super ArrayList<MachineSong>> subscriber) {
                        subscriber.onNext(MachineSongWrapper.getInstance().getMachineSongList(Preferences.getSelectedPad(), PlayConfig.ListType.FAVORLIST, ""));
                    }
                }).subscribeOn(Schedulers.io())
                  .compose(this.<ArrayList<MachineSong>>bindToLifecycle())
                  .observeOn(AndroidSchedulers.mainThread())
                  .subscribe(new Action1<ArrayList<MachineSong>>() {
                      @Override
                      public void call(ArrayList<MachineSong> machineSongs) {
                          loadNativeMethod(genCollectListJson(machineSongs));
                      }
                  });
                return true;
            }

            case Actions.MachinePlayInfo.NOTIFY_MACHINE_BUSY: {
                handleBusy((String) args[0], (String) args[1]);
                return true;
            }

            //设备切换到故事机
            case Actions.Camera.SELECTED_CAMERA_M: {
                //获取新设备的收藏状态
                Observable.create(new Observable.OnSubscribe<String>(){
                    @Override
                    public void call(Subscriber<? super String> subscriber) {
                        String md5 = MachineSongWrapper.getInstance().getLisMd5(Preferences.getSelectedPad(), PlayConfig.ListType.FAVORLIST, "");
                        subscriber.onNext(md5);
                        subscriber.onCompleted();
                    }
                })
                .subscribeOn(Schedulers.io())
                .compose(this.<String>bindToLifecycle())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Action1<String>() {
                    @Override
                    public void call(String s) {
                        doGetFavor("", s);
                    }
                });

                //获取新设备的播放状态
                getPlayInfo();
                return true;
            }

            //故事机的在线状态发生变化
            case Actions.MachinePlayInfo.NOTIFY_MACHINE_ONLINE_STATE_CHANGED:{

                isOnline = (int)args[0] == 1;
                loadNativeMethod(genOnlineJson(isOnline));
                if(isOnline){
                    mImageViewPlayerEnter.setBackgroundResource(R.drawable.playing_big_animator);
                    showPlayAnimation();
                }else{
                    mImageViewPlayerEnter.setBackgroundResource(R.drawable.enter_player_offline);
                }
                return true;
            }
        }
        return null;
    }

    @Override
    public int getProperty() {
        return 0;
    }

    //---------------------------------    处理action   ------------------------------------------//
    //主动获取列表或者有点赞操作，都需要告诉native
    private void handlePlayListChange(int listType, String cmd) {
        //主动获取到列表
        if (listType == PlayConfig.ListType.FAVORLIST) {
            Observable.create(new Observable.OnSubscribe<ArrayList<MachineSong>>() {
                @Override
                public void call(Subscriber<? super ArrayList<MachineSong>> subscriber) {
                    subscriber.onNext(MachineSongWrapper.getInstance().getMachineSongList(Preferences.getSelectedPad(), PlayConfig.ListType.FAVORLIST, ""));
                    subscriber.onCompleted();
                }
            }).subscribeOn(Schedulers.io())
                    .compose(this.<ArrayList<MachineSong>>bindToLifecycle())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Action1<ArrayList<MachineSong>>() {
                        @Override
                        public void call(ArrayList<MachineSong> machineSongs) {
                            isOnline = true;
                            loadNativeMethod(genOnlineJson(isOnline));
                            showPlayAnimation();
                            loadNativeMethod(genCollectListJson(machineSongs));
                        }
                    });
        }
    }


    //处理收藏是否成功(resultCode: 0-成功，1-达到收藏上限，添加失败，2-删除失败，没有这条歌曲)
    private void handlerFavorResult(FavorResultEntity favorResult, String from) {
        if (TextUtils.equals(from, PlayConfig.CmdFrom.MAINPAGE)) {
            switch (favorResult.resultCode) {
                case 0:
                    Observable.create(new Observable.OnSubscribe<ArrayList<MachineSong>>() {
                        @Override
                        public void call(Subscriber<? super ArrayList<MachineSong>> subscriber) {
                            subscriber.onNext(MachineSongWrapper.getInstance().getMachineSongList(Preferences.getSelectedPad(), PlayConfig.ListType.FAVORLIST, ""));
                            subscriber.onCompleted();
                        }
                    }).subscribeOn(Schedulers.io())
                      .compose(this.<ArrayList<MachineSong>>bindToLifecycle())
                      .observeOn(AndroidSchedulers.mainThread())
                      .subscribe(new Action1<ArrayList<MachineSong>>() {
                          @Override
                          public void call(ArrayList<MachineSong> machineSongs) {
                              loadNativeMethod(genCollectListJson(machineSongs));
                          }
                      });
                    break;

                case 1://达到收藏上限，添加失败
                    //TODO 需要作出提示
                    CameraToast.show(mMainActivity, getString(R.string.favor_over_failed), Toast.LENGTH_SHORT);
                    break;

                case 2://删除失败，没有这条收藏
                    //TODO 需要作出提示
                    CameraToast.show(mMainActivity, getString(R.string.favor_del_failed), Toast.LENGTH_SHORT);
                    break;

                case 3://添加失败，歌曲已经存在
                    //TODO 需要作出提示
                    CameraToast.show(mMainActivity, getString(R.string.favor_again_failed), Toast.LENGTH_SHORT);
                    break;
            }
        }
    }

    private void handlePlaySingleChange(MachinePlaySingle playSingle, String cmd, String from) {
        //告知Native，native自己判断是不是播放首页的歌曲
        if (TextUtils.equals(cmd, PlayConfig.CommandType.PLAYCONTROL) || (TextUtils.equals(cmd, PlayConfig.CommandType.GETPLAYSTATUS) && TextUtils.equals(from, PlayConfig.CmdFrom.MAINPAGE))) {
            isOnline = true;
            loadNativeMethod(genOnlineJson(isOnline));
            mImageViewPlayerEnter.setBackgroundResource(R.drawable.playing_big_animator);
            showPlayAnimation();
            loadNativeMethod(genPlayStatusJson(playSingle));
        }
    }

    //处理故事忙，只有播放控制才有
    private void handleBusy(String cmd, String from) {
        //TODO 没在播放，忙着呢
        if (TextUtils.equals(from, PlayConfig.CmdFrom.MAINPAGE)) {
            if (TextUtils.equals(cmd, PlayConfig.CommandType.GETPLAYSTATUS)) {
                //TODO 获取播放状态,发现故事机在忙
            } else if (TextUtils.equals(cmd, PlayConfig.CommandType.PLAYCONTROL)) {
                //TODO 在播放页面点击播放，发现故事机正忙着，做出提示
                CameraToast.show(getString(R.string.machine_is_busy), Toast.LENGTH_SHORT);
            }
        }
    }
    //------------------------------------------end-----------------------------------------------//


    //-----------------------------------------发送指令-------------------------------------------//
    //发送收藏指令
    private void doFavorCmd(WebviewEntity.CollectSong collectSong) {
        String operate = collectSong.data.collect==1 ? PlayConfig.FavorType.ADDSONG : PlayConfig.FavorType.DELSONG;
        SongEntity songEntity = new SongEntity();
        songEntity.uniqueid = collectSong.data.uniqueid;
        songEntity.title = collectSong.data.title;
        songEntity.mediaurl = collectSong.data.mediaurl;
        songEntity.type = collectSong.data.type;
        songEntity.src = collectSong.data.src;
        songEntity.srclogo = collectSong.data.srclogo;
        songEntity.volume = collectSong.data.volume;
        TaskExecutor.Execute(new SettingTask(getActivity(), PlayConfig.CommandType.DOFAVOR, JsonManager.getStoryFavor(operate, songEntity, collectSong.data.unique, collectSong.data.pageid), myHandler, PlayConfig.CmdFrom.MAINPAGE));
        //打点收藏
        if(collectSong.data.collect==1){
            QHStatAgentHelper.doSongStoryStick(QHStatAgentHelper.getSongFavorMap(songEntity.getTitle()));
        }
    }

    //发送播放指令
    private void doPlayCmd(WebviewEntity.PlaySong playSong) {
        SongEntity songEntity = new SongEntity();
        songEntity.uniqueid = playSong.data.uniqueid;
        songEntity.title = playSong.data.title;
        songEntity.mediaurl = playSong.data.mediaurl;
        songEntity.type = playSong.data.type;
        songEntity.src = playSong.data.src;
        songEntity.srclogo = playSong.data.srclogo;
        songEntity.volume = playSong.data.volume;
        TaskExecutor.Execute(new SettingTask(getActivity(), PlayConfig.CommandType.PLAYCONTROL, JsonManager.getPlayControlContent(PlayConfig.PlayType.PLAYSONG, songEntity, playSong.data.unique, playSong.data.pageid), myHandler, PlayConfig.CmdFrom.MAINPAGE));
        //打点播放儿歌
        QHStatAgentHelper.doSongStoryStick(QHStatAgentHelper.getSongPlayMap(songEntity.getTitle(), songEntity.getUniqueid()));
    }

    //发送获取播放信息的指令
    private void getPlayInfo() {
        TaskExecutor.Execute(new SettingTask(getActivity(), PlayConfig.CommandType.GETPLAYSTATUS, JsonManager.getPlayStatusContent(), myHandler, PlayConfig.CmdFrom.MAINPAGE));
    }

    //发送获取收藏列表的指令
    private void doGetFavor(String unique, String md5) {
        TaskExecutor.Execute(new SettingTask(getActivity(), PlayConfig.CommandType.GETPLAYLIST, JsonManager.getPlayListContent(PlayConfig.ListType.FAVORLIST, unique, md5), myHandler, PlayConfig.CmdFrom.MAINPAGE));
    }
    //------------------------------------------end-----------------------------------------------//


    //实现播放动画
    private void showPlayAnimation(){
        final AnimationDrawable animationDrawable = (AnimationDrawable)mImageViewPlayerEnter.getBackground();
        if(animationDrawable!=null && !animationDrawable.isRunning()){
            myHandler.post(new Runnable() {
                @Override
                public void run() {
                    animationDrawable.start();
                }
            });
        }
    }

}
