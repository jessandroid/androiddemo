package com.qihoo360.homecamera.machine.net;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.config.Const;
import com.qihoo360.homecamera.mobile.utils.Utils;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.conn.ssl.SSLSocketFactory;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.Principal;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class CameraSSLSocketFactory extends SSLSocketFactory {

	SSLContext sslContext = SSLContext.getInstance("TLS");

	public CameraSSLSocketFactory(KeyStore keyStore)
			throws NoSuchAlgorithmException, KeyManagementException,
			KeyStoreException, UnrecoverableKeyException, IOException {
		super(keyStore);
		sslContext.init(null, new TrustManager[]{new X509TrustManager() {
			@Override
			public void checkClientTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
			}

			@Override
			public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
				if (!Const.HTTP_FLAG) {
					try {
						if (chain == null || chain.length == 0)
                                    throw new CertificateException(Utils.getString(R.string.ssl_socket_connect_failed));
						if (authType == null || authType.length() == 0)
                                    throw new CertificateException(Utils.getString(R.string.ssl_socket_connect_failed));

						boolean br = false;
						Principal principal = null;
						for (X509Certificate x509Certificate : chain) {
							principal = x509Certificate.getSubjectDN();
							if (principal != null && (StringUtils.contains(principal.getName(), "360.cn"))) {
								br = true;
								return;
							}
						}
						if (!br) {
                                    throw new CertificateException(Utils.getString(R.string.ssl_socket_connect_failed));
						}
					} catch (CertificateException ce) {
                                throw new CertificateException(Utils.getString(R.string.ssl_socket_connect_failed));
					}
				}
			}

			@Override
			public X509Certificate[] getAcceptedIssuers() {
				return new X509Certificate[0];
			}
		}}, null);

	}

	@Override
	public Socket createSocket(Socket socket, String host, int port,
							   boolean autoClose) throws IOException, UnknownHostException {
		return sslContext.getSocketFactory().createSocket(socket, host, port,
				autoClose);
	}

	@Override
	public Socket createSocket() throws IOException {
		return sslContext.getSocketFactory().createSocket();
	}


}
