package com.qihoo360.homecamera.mobile.download.architecture;

/**
 * Created by Tomcat on 2015/7/15.
 */
public interface DownloadStatusDelivery {

    void post(DownloadStatus status);

}
