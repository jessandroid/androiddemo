package com.qihoo360.homecamera.machine.fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.ImageView;

import com.qihoo360.homecamera.device.config.StoryMachineConsts;
import com.qihoo360.homecamera.machine.activity.MachineBaseActivity;
import com.qihoo360.homecamera.machine.activity.SetupGuideActivity;
import com.qihoo360.homecamera.machine.entity.BindBannerEntity;
import com.qihoo360.homecamera.machine.ui.adapter.BannerSubItemHolderView;
import com.qihoo360.homecamera.mobile.ApplicationCamera;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.activity.BindDeviceFrameActivity;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.ui.storyui.ConvenientBanner;
import com.qihoo360.homecamera.mobile.ui.storyui.holder.CBViewHolderCreator;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.util.ArrayList;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * Created by zhangtao-iri on 2017/1/5.
 */
public class CommonBindFragment extends MachineBaseFragment implements ActionListener{

    private Context mContext;

    @Bind(R.id.banner)
    ConvenientBanner convenientBanner;

    @Bind(R.id.bind_robit_arrow)
    ImageView bind_robit_arrow;

    @Bind(R.id.bind_machine_arrow)
    ImageView bind_machine_arrow;

    private ArrayList<BindBannerEntity.Banner>  banner;

    private long mExitAppTime;

    private MachineBaseActivity baseActivity;

    @Override
    public int getRootViewLayoutId() {
        return R.layout.fragment_common_bind;
    }

    @Override
    public boolean onTabSwitched() {
        return false;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if(context==null){
            return;
        }
        mContext = context;
        baseActivity = (MachineBaseActivity) context;
    }

    public static CommonBindFragment newInstance(){
        return new CommonBindFragment();
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ButterKnife.bind(this, mRootView);
        GlobalManager.getInstance().getMachineManager().registerActionListener(this);
    }

    //初始化轮播图
    private void initBanner(){
        banner = new ArrayList<>();
        GlobalManager.getInstance().getMachineManager().asyncGetBanner();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        initBanner();
    }

    @Override
    public void onDetach() {
        super.onDetach();
        GlobalManager.getInstance().getMachineManager().removeActionListener(this);
    }

    @OnClick(R.id.bind_robot_zone)
    public void onBindRobot(){
        bind_robit_arrow.performClick();
        Intent intent = new Intent(mContext, BindDeviceFrameActivity.class);
        startActivity(intent);
    }

    @OnClick(R.id.bind_machine_zone)
    public void onBindMachine(){
        bind_machine_arrow.performClick();
        Intent intent = new Intent(mContext, SetupGuideActivity.class);
        intent.putExtra(StoryMachineConsts.KEY_SET_WIFI_FROM,StoryMachineConsts.VALUE_SET_WIFI_FROM_BIND);
        startActivity(intent);
    }

    @Override
    public Object actionPerformed(int actionCode, Object... args) {
        switch(actionCode){
            case Actions.GlobalActionCode.GET_BIND_BANNER_LIST:
                handlerBanner((BindBannerEntity)args[0]);
                break;
        }
        return null;
    }

    @Override
    public int getProperty() {
        return 0;
    }

    private void handlerBanner(BindBannerEntity entity){

        if(entity==null){
            return;
        }

        //获取到轮播图信息
        banner = entity.data;

        if(banner!=null && banner.size()>0){
            convenientBanner.setPages(new CBViewHolderCreator<BannerSubItemHolderView>() {
                @Override
                public BannerSubItemHolderView createHolder() {
                    return new BannerSubItemHolderView();
                }
            }, banner).setPageIndicator(new int[]{R.drawable.ic_page_indicator, R.drawable.ic_page_indicator_focused});
            convenientBanner.startTurning(5000);
        }

    }

    @Override
    public boolean onBackPressed() {
        if (System.currentTimeMillis() - mExitAppTime < 2000) {
            ApplicationCamera applicationCamera = (ApplicationCamera) baseActivity.getApplication();
            CameraToast.hideToast();
            CameraToast.cleanToast();
            //非wifi网络弹窗提醒逻辑，在原基础上，将弹窗优化为toast，仅是toast提醒，不做暂停操作。
            //不弹窗 只toast
            //                Constants.HAS_SHOW_NET_TIPS = false;
            applicationCamera.AppExit();
        } else {
            mExitAppTime = System.currentTimeMillis();
            CameraToast.showToast(Utils.context, getString(R.string.kc_press_exit_app), false);
        }
        return super.onBackPressed();
    }
}
