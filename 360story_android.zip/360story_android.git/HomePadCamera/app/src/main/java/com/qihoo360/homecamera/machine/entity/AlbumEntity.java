package com.qihoo360.homecamera.machine.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by zhangtao-iri on 2016/12/19.
 */
public class AlbumEntity implements Parcelable{

    private String name;    //专辑名称
    private String unique;  //专辑唯一标示
    private String coverurl;//专辑封面
    private int total;      //

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public String getCoverurl() {
        return coverurl;
    }

    public void setCoverurl(String coverurl) {
        this.coverurl = coverurl;
    }

    public String getUnique() {
        return unique;
    }

    public void setUnique(String unique) {
        this.unique = unique;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.name);
        dest.writeString(this.unique);
        dest.writeInt(this.total);
        dest.writeString(this.coverurl);
    }

    public AlbumEntity() {
    }

    protected AlbumEntity(Parcel in) {
        this.name = in.readString();
        this.unique = in.readString();
        this.total = in.readInt();
        this.coverurl = in.readString();
    }

    public static final Creator<AlbumEntity> CREATOR = new Creator<AlbumEntity>() {
        @Override
        public AlbumEntity createFromParcel(Parcel source) {
            return new AlbumEntity(source);
        }

        @Override
        public AlbumEntity[] newArray(int size) {
            return new AlbumEntity[size];
        }
    };
}
