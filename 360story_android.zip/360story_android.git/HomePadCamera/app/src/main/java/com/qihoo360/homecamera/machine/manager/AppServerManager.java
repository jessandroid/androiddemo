
package com.qihoo360.homecamera.machine.manager;

import android.os.Build;

import com.google.gson.Gson;
import com.qihoo360.homecamera.machine.entity.AppMicType;
import com.qihoo360.homecamera.machine.net.CameraHttpApi;
import com.qihoo360.homecamera.machine.preferences.Preferences;
import com.qihoo360.homecamera.machine.util.JSONUtils;
import com.qihoo360.homecamera.mobile.config.Const;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionPublisherWithThreadPoolBase;
import com.qihoo360.homecamera.mobile.core.manager.workpool.PoolThreadFactory;
import com.qihoo360.homecamera.mobile.http.OkHttpUtils;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.Utils;

import org.json.JSONObject;

import java.util.Date;
import java.util.concurrent.Executors;

import okhttp3.MediaType;

/**
 * Created by wangdan-qhwl on 2015/8/14.
 */
public class AppServerManager extends ActionPublisherWithThreadPoolBase {

    public static final String GET_MIC_TYPE = "get_mic_type";
    public static final String GET_VOICE_CONF = "get_voice_conf";
    private String mPoolNameHighPriority;

    CameraHttpApi cameraHttpApi;

    public AppServerManager() {
        mPoolNameHighPriority = "AppServer-manager-" + Utils.DATE_FORMAT_3.format(new Date());
        // cameraHttpApi = new CameraHttpApi();
        cameraHttpApi = GlobalManager.getInstance().config().cameraHttpsApi;
        mThreadPool.initPool(mPoolNameHighPriority,
                Executors.newCachedThreadPool(new PoolThreadFactory(mPoolNameHighPriority)));
    }

    public void doMethod(String string, Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob(string, args));
    }

    @Override
    protected void asyncDoNamedJob(String jobName, Object... args) {
        if (GET_MIC_TYPE.equals(jobName)) {
            getMicType();
        } else if (GET_VOICE_CONF.equals(jobName)) {
            getVoiceConf();
        }
    }

    private void getMicType() {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("brand", Build.BRAND);
            jsonObject.put("model", Build.MODEL);
            jsonObject.put("device", Build.DEVICE);
            jsonObject.put("sdk_level", Build.VERSION.SDK_INT);
            String tmp = "https://q2.jia.360.cn" + CameraHttpApi.URL_APP_GET_MIC_TYPE;

            JSONObject eparams = new JSONObject();
            eparams.put("parad", jsonObject.toString());
            eparams.put("from", Const.FROM);

            String responseStr = OkHttpUtils.postString().content(eparams.toString()).mediaType(MediaType.parse("application/json;charset=utf-8")).isHttps(true).isStatic(true).headers(null).url(tmp).build().execute();
            Gson gson = new Gson();
            AppMicType result = gson.fromJson(responseStr, AppMicType.class);


            if (result != null && result.getErrorCode() == Constants.Http.ERROR_CODE_SUCCEED) {
                if (result != null) {
                    Preferences.setMicType(result.mic_type);
                    int ts = (int) (System.currentTimeMillis() / 1000L);
                    Preferences.setQueryMicTypeTimestamp(ts);
                    CLog.i("getMicType : " + result.mic_type);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void getVoiceConf() {
        try {
            CLog.i("play-v2","getVoiceConf running");
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("brand", Build.BRAND);
            jsonObject.put("model", Build.MODEL);
            String tmp = "https://q2.jia.360.cn" + CameraHttpApi.URL_APP_GET_VOICE_CONF;

            JSONObject eparams = new JSONObject();
            eparams.put("parad", jsonObject.toString());
            eparams.put("from", Const.FROM);

            String responseStr = OkHttpUtils.postString().content(eparams.toString()).mediaType(MediaType.parse("application/json;charset=utf-8")).isHttps(true).isStatic(true).headers(null).url(tmp).build().execute();
            Gson gson = new Gson();
            AppMicType result = gson.fromJson(responseStr, AppMicType.class);

//            AppMicType result = cameraHttpApi.doCommonRequest(jsonObject, tmp,
//                    AppMicType.class);
            if (result != null) {
                if (result.getErrorCode() == Constants.Http.ERROR_CODE_SUCCEED) {
                    Preferences.setVoiceConf(JSONUtils.toJson(result.result));
                    int ts = (int) (System.currentTimeMillis() / 1000L);
                    Preferences.setQueryMicTypeTimestamp(ts);
                    Preferences.setMicType(result.result.mic_type);
                    CLog.d("getVoiceConf : " + result.toJson());
                } else if (result.getErrorCode() == 624) {
                    Preferences.setVoiceConf("");
                    int ts = (int) (System.currentTimeMillis() / 1000L);
                    Preferences.setQueryMicTypeTimestamp(ts);
                    CLog.d("getVoiceConf : " + 624);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
