package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.Gson;

/**
 * Created by zhaojunbo on 2016/2/16.
 * desc:
 */
public class ShareUserEntity implements Parcelable {

    /**
     * IPC的序列化
     */
    public String sn;
    /**
     * 用户id
     */
    public String qid;
    /**
     * qid类型   1：qid 2：sn
     */
    public String qidtype;
    /**
     * 角色   1：主人 2 亲人 3 平板好友
     */
    public String role;
    /**
     * 备注名称
     */
    public String remarkName;
    /**
     * 用户关系
     */
    public String relation;
    /**
     * 播放次数
     */
    public String playNum;
    /**
     * 播放时间
     */
    public String playTime;
    /**
     * 创建时间
     */
    public String createTime;
    /**
     * 用户名
     */
    public String userName;
    /**
     * 手机号
     */
    public String phone;
    /**
     * 用户昵称
     */
    public String nickName;
    /**
     * 用户头像
     */
    public String imgUrl;
    public String aclInfo;

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        out.writeString(sn);
        out.writeString(qid);
        out.writeString(qidtype);
        out.writeString(role);
        out.writeString(remarkName);
        out.writeString(relation);
        out.writeString(playNum);
        out.writeString(playTime);
        out.writeString(createTime);
        out.writeString(userName);
        out.writeString(phone);
        out.writeString(nickName);
        out.writeString(imgUrl);
        out.writeString(aclInfo);
    }

    public static final Parcelable.Creator<ShareUserEntity> CREATOR = new Parcelable.Creator<ShareUserEntity>() {
        @Override
        public ShareUserEntity createFromParcel(Parcel source) {
            return new ShareUserEntity(source);
        }

        @Override
        public ShareUserEntity[] newArray(int size) {
            return new ShareUserEntity[size];
        }
    };

    private ShareUserEntity(Parcel in) {
        sn = in.readString();
        qid = in.readString();
        qidtype = in.readString();
        role = in.readString();
        remarkName = in.readString();
        relation = in.readString();
        playNum = in.readString();
        playTime = in.readString();
        createTime = in.readString();
        userName = in.readString();
        phone = in.readString();
        nickName = in.readString();
        imgUrl = in.readString();
        aclInfo = in.readString();
    }

    public ShareUserEntity() {

    }

    public String getRelation() {
        String relaTitle = "";
        try {
            Gson gson = new Gson();
            RelationInfoEntity relationInfoEntity = gson.fromJson(relation, RelationInfoEntity.class);
            if (relationInfoEntity != null) {
                relaTitle = relationInfoEntity.relation_title;
            } else {
                return relaTitle = "";
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            return relaTitle;
        }

    }

    public int getRelationId() {
        int relaID = -1;
        try {
            Gson gson = new Gson();
            RelationInfoEntity relationInfoEntity = gson.fromJson(relation, RelationInfoEntity.class);
            if (relationInfoEntity != null) {
                relaID = relationInfoEntity.relation_tag;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return relaID;
    }
}
