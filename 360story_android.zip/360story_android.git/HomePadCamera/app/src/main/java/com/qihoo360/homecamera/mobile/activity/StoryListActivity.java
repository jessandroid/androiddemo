package com.qihoo360.homecamera.mobile.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.qihoo360.homecamera.device.config.StoryMachineConsts;
import com.qihoo360.homecamera.mobile.BuildConfig;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.adapter.LinearLayoutAdapter;
import com.qihoo360.homecamera.mobile.config.DefaultClientConfig;
import com.qihoo360.homecamera.mobile.entity.DeviceInfo;
import com.qihoo360.homecamera.mobile.entity.Head;
import com.qihoo360.homecamera.mobile.entity.Story;
import com.qihoo360.homecamera.mobile.entity.StoryGrandfather;
import com.qihoo360.homecamera.mobile.entity.StoryList;
import com.qihoo360.homecamera.mobile.http.OkHttpUtils;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.widget.CamAlertDialog;
import com.qihoo360.homecamera.mobile.widget.TextViewWithFont;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

public class StoryListActivity extends BaseActivity implements View.OnClickListener, LinearLayoutAdapter.OnItemOption {

    private ImageView mBackZone;
    private TextViewWithFont mTitleString;
    private ImageView mIvAddPad;
    private TextViewWithFont mTvRightButton;
    private RecyclerView mListStory;
    private RelativeLayout mBottomBar;
    private Button mDelStory;
    private ImageButton mDownStory;
    private ImageButton mShareStory;
    private List<Story> storylist;
    private LinearLayoutAdapter linearAdapter;
    private boolean check = false;
    private SwipeRefreshLayout swipeRefreshLayout;
    private volatile int page = 1;
    private DeviceInfo deviceInfo;
    private View retry;
    private View empty_story;
    private ImageButton retry_button;
    private boolean choose = false;
    private CamAlertDialog delStoryAlertDialog;
    private boolean isScrollToLast;
    private GridLayoutManager gridLayoutManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_story_list);
        deviceInfo = getIntent().getParcelableExtra("deviceInfo");
        mBackZone = (ImageView) findViewById(R.id.back_zone);
        mBackZone.setOnClickListener(this);
        mTitleString = (TextViewWithFont) findViewById(R.id.title_string);
        mIvAddPad = (ImageView) findViewById(R.id.iv_add_pad);
        mIvAddPad.setOnClickListener(this);
        mTvRightButton = (TextViewWithFont) findViewById(R.id.tv_right_button);
        mTvRightButton.setOnClickListener(this);

        mListStory = (RecyclerView) findViewById(R.id.list_story);
        mBottomBar = (RelativeLayout) findViewById(R.id.bottom_bar);
        mBottomBar.setVisibility(View.GONE);

        mDelStory = (Button) findViewById(R.id.del_story);
        mDelStory.setOnClickListener(this);
        mDownStory = (ImageButton) findViewById(R.id.down_story);
        mDownStory.setOnClickListener(this);
        mShareStory = (ImageButton) findViewById(R.id.share_story);
        mShareStory.setOnClickListener(this);

        retry = findViewById(R.id.retry);
        retry_button = (ImageButton) findViewById(R.id.retry_button);
        retry_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                page = 1;
                loadData();
            }
        });

        swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipe_refresh);
        swipeRefreshLayout.setColorSchemeResources(android.R.color.holo_red_light, android.R.color.holo_green_light,
                android.R.color.holo_blue_bright, android.R.color.holo_orange_light);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                page = 1;
                loadData();
            }
        });


        empty_story = findViewById(R.id.empty_story);
        empty_story.setVisibility(View.GONE);

        mTvRightButton.setVisibility(View.VISIBLE);
        mTvRightButton.setText(R.string.choose);
        mTitleString.setText(R.string.record_story_title);

        storylist = new ArrayList<>();
        linearAdapter = new LinearLayoutAdapter(this, storylist, this, 3);
        gridLayoutManager = new GridLayoutManager(this, 2);
        mListStory.setLayoutManager(gridLayoutManager);
        mListStory.setAdapter(linearAdapter);
        gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                return linearAdapter.isHeader(position) ? gridLayoutManager.getSpanCount() : 1;
            }
        });
        mListStory.setAdapter(linearAdapter);
        mListStory.addOnScrollListener(
                new RecyclerView.OnScrollListener() {
                    @Override
                    public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                        if (dy > 0) {
                            // 大于0表示，正在向右滚动
                            isScrollToLast = true;
                        } else {
                            // 小于等于0 表示停止或向左滚动
                            isScrollToLast = false;
                        }
                    }

                    @Override
                    public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                        super.onScrollStateChanged(recyclerView, newState);
                        CLog.d("the newState:" + newState);
                        if (newState == RecyclerView.SCROLL_STATE_IDLE) {
                            Glide.with(StoryListActivity.this).resumeRequests();
                            int lastVisibleItem = gridLayoutManager.findLastCompletelyVisibleItemPosition();
                            int totalItemCount = gridLayoutManager.getItemCount();
                            if (lastVisibleItem == (totalItemCount - 1) && isScrollToLast) {
                                loadData();
                            }
                        } else {
                            Glide.with(StoryListActivity.this).pauseRequests();
                        }
                    }
                }
        );

        loadData();
    }


    public void showDelstoryalertdialog(int n) {
        delStoryAlertDialog = new CamAlertDialog.Builder(this).setTitle(R.string.tips_47).setMessage(getString(R.string.del_story_msg, n)).setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(final DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
                showTipsDialog(getString(R.string.del_story), R.drawable.icon_loading, true);
                Observable.create(new Observable.OnSubscribe<String>() {
                    @Override
                    public void call(Subscriber<? super String> subscriber) {
                        StringBuilder stringBuilder = new StringBuilder();
                        for (int i = 0; i < linearAdapter.checkedList.size(); i++) {
                            stringBuilder.append(linearAdapter.checkedList.get(i).id);
                            if (i < linearAdapter.checkedList.size() - 1) {
                                stringBuilder.append(",");
                            }
                        }
                        HashMap<String, String> param = new HashMap();
                        param.put("sn", deviceInfo.getSn());//todo  这里要给sn 赋值，现在是写死的
                        param.put("ids", stringBuilder.toString());
                        param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                        try {
                            String rp = OkHttpUtils.post().headers(null).params(param).url(DefaultClientConfig.DEL_RECORD_STORY_URL).build().execute();
                            subscriber.onNext(rp);
                        } finally {
                            subscriber.onCompleted();
                        }

                    }
                }).subscribeOn(Schedulers.io()).flatMap(new Func1<String, Observable<Map<String, String>>>() {
                    @Override
                    public Observable<Map<String, String>> call(String s) {
                        Gson gson = new Gson();
                        Head head = gson.fromJson(s, Head.class);
                        try {
                            JSONObject jsonObject = new JSONObject(s);
                            if (head.errorCode == 0 && head.statusCode == 0) {
                                Map<String, String> myMap = gson.fromJson(jsonObject.optJSONObject("data").toString(), new TypeToken<Map<String, String>>() {
                                }.getType());
                                return Observable.just(myMap);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Observable.error(new Throwable(s));
                        }
                        return Observable.error(new Throwable(s));
                    }
                }).flatMap(new Func1<Map<String, String>, Observable<Story>>() {
                    @Override
                    public Observable<Story> call(Map<String, String> stringStringMap) {
                        ArrayList<Story> a = new ArrayList();
                        for (int i = 0; i < storylist.size(); i++) {
                            if (stringStringMap.containsKey(storylist.get(i).id)) {
                                if (Integer.parseInt(stringStringMap.get(storylist.get(i).id).trim()) == 1) {
                                    a.add(storylist.get(i));
                                }
                            }
                        }
                        return Observable.from(a);
                    }

                }).observeOn(AndroidSchedulers.mainThread()).subscribe(new Subscriber<Story>() {
                    @Override
                    public void onCompleted() {
                        dialogInterface.dismiss();
                        hideTipsDialog();
                    }

                    @Override
                    public void onError(Throwable e) {
                        hideTipsDialog();
                        CLog.d(String.format("the error is :%s", e.getMessage()));
                    }

                    @Override
                    public void onNext(Story o) {
                        CLog.d(String.format("the o %s", o.toJson()));
                        linearAdapter.checkedList.clear();
                        storylist.remove(o);
                        linearAdapter.dataChanage(storylist);
                    }
                });
            }
        }).setCancelable(true).setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        }).create();
        delStoryAlertDialog.show();
    }

    public void setChooseModel(boolean chooseModel) {
        this.choose = chooseModel;
        int visiable = chooseModel ? View.VISIBLE : View.GONE;
        mBottomBar.setVisibility(visiable);
        linearAdapter.notifyDataSetChanged();
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.back_zone:
                finish();
                break;
            case R.id.del_story:
                showDelstoryalertdialog(linearAdapter.checkedList.size());
                break;
            case R.id.down_story:
                break;
            case R.id.share_story:
                break;
            case R.id.tv_right_button:
                check = !check;
                setChooseModel(check);
                if (linearAdapter.getCheckModel()) {
                    mBottomBar.setVisibility(View.VISIBLE);
                    mTvRightButton.setText(R.string.cancel);
                } else {
                    mTvRightButton.setText(R.string.choose);
                    mBottomBar.setVisibility(View.GONE);
                }
                break;
        }
    }

    public void loadData() {
        Observable.create(new Observable.OnSubscribe<StoryGrandfather>() {
            @Override
            public void call(Subscriber<? super StoryGrandfather> subscriber) {
                String json = null;
                HashMap<String, String> hashMap = new HashMap<String, String>();
                hashMap.put("sn", deviceInfo.getSn());
                hashMap.put("page", String.valueOf(page - 1));
                hashMap.put("count", String.valueOf(10));
                hashMap.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                json = OkHttpUtils.post().params(hashMap).isHttps(true).headers(null).url(DefaultClientConfig.RECORDED_URL).build().execute();
                CLog.json(json);

                StoryGrandfather storyGrandfather = null;
                Gson gson = new Gson();
                if (!TextUtils.isEmpty(json)) {
                    storyGrandfather = gson.fromJson(json, StoryGrandfather.class);
                }
                if (storyGrandfather.errorCode == 0) {
                    subscriber.onNext(storyGrandfather);
                } else {
                    subscriber.onError(new Throwable(json));
                }
                subscriber.onCompleted();
            }
        }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Subscriber<StoryGrandfather>() {
            @Override
            public void onCompleted() {
                swipeRefreshLayout.setRefreshing(false);
            }

            @Override
            public void onError(Throwable e) {
                if (swipeRefreshLayout != null) {
                    swipeRefreshLayout.setRefreshing(false);
                }
                CameraToast.show(Utils.context, e.getMessage(), Toast.LENGTH_SHORT);
                if (storylist != null && storylist.size() == 0) {
                    if (retry != null) {
                        retry.setVisibility(View.VISIBLE);
                    }
                }
            }

            @Override
            public void onNext(StoryGrandfather storyGrandfather) {
                StoryList storyList = storyGrandfather.storyList;
                if (storyList.errorCode==0) {
                    if (storyList.data.size() == 0) {
                        if (page==1) {
                            retry.setVisibility(View.GONE);
                            empty_story.setVisibility(View.VISIBLE);
                            mTvRightButton.setVisibility(View.GONE);
                            linearAdapter.setTotalCount(storyList.data.size());
                        }else {
                            retry.setVisibility(View.GONE);
                            empty_story.setVisibility(View.GONE);
                            mTvRightButton.setVisibility(View.GONE);
                        }
                    } else {
                        retry.setVisibility(View.GONE);
                        empty_story.setVisibility(View.GONE);
                        linearAdapter.setTotalCount(0);
                        mTvRightButton.setVisibility(View.VISIBLE);
                    }
                }else {
                    retry.setVisibility(View.VISIBLE);
                    empty_story.setVisibility(View.GONE);
                    linearAdapter.setTotalCount(storyList.data.size());
                }
                swipeRefreshLayout.setRefreshing(false);

                if (storyGrandfather.storyList.data.size() > 0) {
                    if (storyList != null) {
                        if (page > 1) {
                            storylist.addAll(storyList.data);
                        } else {
                            storylist = storyList.data;
                        }
                        linearAdapter.dataChanage(storylist);
                    }

                    page += 1;
                } else {
                    if (page == 1) {
//                        retry.setVisibility(View.VISIBLE);
                    }
                }
            }
        });
    }

    @Override
    public void clickStory(int po, Story st) {
        Intent intent = new Intent(this, PlayAndRecordStoryActivity.class);
        Bundle bundle = new Bundle();
        bundle.putParcelable("story", st);
        bundle.putParcelable("deviceInfo", deviceInfo);
        if (linearAdapter.getCheckModel()) {
            if (storylist.get(po).checked) {
                storylist.get(po).checked = false;
                linearAdapter.checkedList.remove(st);
            } else {
                storylist.get(po).checked = true;
                linearAdapter.checkedList.add(st);
            }
        } else {
            bundle.putBoolean("online", true);
            intent.putExtras(bundle);
            startActivity(intent);
        }
        linearAdapter.notifyItemChanged(po + 1);
//        mDelStory.setEnabled(linearAdapter.checkedList.size()<=10);
    }

    @Override
    public boolean isCheckModel() {
        if (choose) {
            return true;
        } else {
            for (int i = 0; i < storylist.size(); i++) {
                storylist.get(i).checked = false;
            }
            return false;
        }
    }

    @Override
    public List<Story> checkedStory() {
        return null;
    }

    @Override
    public void onBackPressed() {
        choose = false;
        if (linearAdapter.getCheckModel()) {
            setChooseModel(choose);
            mTvRightButton.setText(R.string.choose);
        } else {
            super.onBackPressed();
        }
    }
}
