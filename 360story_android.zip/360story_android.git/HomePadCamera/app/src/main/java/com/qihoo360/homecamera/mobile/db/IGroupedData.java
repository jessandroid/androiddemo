
package com.qihoo360.homecamera.mobile.db;

public interface IGroupedData<G, C> {
    int getGroupCount();

    int getGroupChildrenCount(int groupIndex);

    G getGroupData(int groupIndex);

    C getChildrenData(int groupIndex, int childrenIndex);

}
