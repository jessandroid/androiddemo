package com.qihoo360.homecamera.machine.activity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Gravity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
import android.widget.Toast;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.activity.BaseActivity;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.utils.CameraToast;

import java.lang.ref.WeakReference;

/**
 * Created by lixin3-s on 2016/11/5.
 */
public class MachineBaseActivity extends BaseActivity {

    static class AppBaseHandler extends Handler {

        WeakReference<MachineBaseActivity> appBaseActivityWeakReference;

        AppBaseHandler(MachineBaseActivity appBaseActivity) {
            appBaseActivityWeakReference = new WeakReference<MachineBaseActivity>(appBaseActivity);
        }

        @Override
        public void handleMessage(Message msg) {
            MachineBaseActivity machineBaseActivity = appBaseActivityWeakReference.get();
            if (machineBaseActivity != null) {
                switch (msg.what) {
                    case Constants.TaskState.ISRUNING:
                        if (machineBaseActivity.mProgressDialog != null
                                && !machineBaseActivity.mProgressDialog.isShowing()
                                && !machineBaseActivity.isFinishing())
                            machineBaseActivity.mProgressDialog.show();
                        break;
                    case Constants.TaskState.PAUSE:
                    case Constants.TaskState.SUCCESS:
                    case Constants.TaskState.FAILURE:
                        machineBaseActivity.dismissProcessDialog();
                        break;
                    case Constants.TaskState.EXCEPITON:
                        machineBaseActivity.dismissProcessDialog();
                        CameraToast.show(machineBaseActivity, machineBaseActivity.getString(R.string.req_exception),
                                Toast.LENGTH_SHORT);
                        break;

                    case 911:
                        // TODO 域名被劫持
                        //Toast.makeText(machineBaseActivity, Utils.getString(R.string.url_error_prompt, Const.APP_SERVER_DOMAIN), Toast.LENGTH_SHORT).show();

                    default:
                        break;
                }
                machineBaseActivity.doMessage(msg);
            }
        }
    }

    public Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        handler = new AppBaseHandler(this);
    }

    @Override
    protected void onDestroy() {
        handler = null;
        super.onDestroy();
    }

    @Override
    protected int getSharePopWinGravity() {
        return Gravity.CENTER;
    }

    protected void startTitleNextAnimation(final TextView textView, String firstTitle,
                                           final String secondTitle) {
        textView.setText(firstTitle);
        Animation a1 = AnimationUtils.loadAnimation(this, R.anim.left_out);
        final Animation a2 = AnimationUtils.loadAnimation(this, R.anim.right_in);

        a1.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                textView.setText(secondTitle);
                textView.startAnimation(a2);
            }
        });
        textView.startAnimation(a1);
    }

    protected void startTitlePreAnimation(final TextView textView, String firstTitle,
                                          final String secondTitle) {
        textView.setText(firstTitle);
        Animation a1 = AnimationUtils.loadAnimation(this, R.anim.right_out);
        final Animation a2 = AnimationUtils.loadAnimation(this, R.anim.left_in);

        a1.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                textView.setText(secondTitle);
                textView.startAnimation(a2);
            }
        });
        textView.startAnimation(a1);
    }

    public void onBack(View view) {
        onBackPressed();
    }

    protected void doMessage(Message msg) {
    }

    public Handler getHandler() {
        return handler;
    }
}
