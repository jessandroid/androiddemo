package com.qihoo360.homecamera.machine.entity;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

/**
 * 故事机播放信息
 * Created by zhangchao-pd on 2016/11/18.
 */

public class MachinePlayInfo implements Parcelable {

    /**
     * 当前播放的单曲(注currentMusic有可能不在album中，如果这种情况外部逻辑需要重新获取album)
     */
    private MachinePlaySingle currentMusic;

    private ArrayList<SongEntity> songList;//正在播的列表

    public MachinePlayInfo() {

    }

    public MachinePlaySingle getCurrentMusic() {
        return currentMusic;
    }

    public void setCurrentMusic(MachinePlaySingle currentMusic) {
        this.currentMusic = currentMusic;
    }

    public ArrayList<SongEntity> getSongList() {
        return songList;
    }

    public void setSongList(ArrayList<SongEntity> songList) {
        this.songList = songList;
    }

    /**
     * 判断single单曲是否正在播放
     * @param single 需要判断的单曲
     * @return
     */
    public boolean isSingleRunning(MachinePlaySingle single) {
        boolean isRunning = false;
        if(currentMusic != null) {
            isRunning = currentMusic.equals(single);
        }
        return isRunning;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(this.currentMusic, flags);
        dest.writeTypedList(this.songList);
    }

    protected MachinePlayInfo(Parcel in) {
        this.currentMusic = in.readParcelable(MachinePlaySingle.class.getClassLoader());
        this.songList = in.createTypedArrayList(SongEntity.CREATOR);
    }

    public static final Creator<MachinePlayInfo> CREATOR = new Creator<MachinePlayInfo>() {
        @Override
        public MachinePlayInfo createFromParcel(Parcel source) {
            return new MachinePlayInfo(source);
        }

        @Override
        public MachinePlayInfo[] newArray(int size) {
            return new MachinePlayInfo[size];
        }
    };
}
