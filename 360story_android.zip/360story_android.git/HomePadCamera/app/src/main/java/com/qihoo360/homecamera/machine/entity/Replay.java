
package com.qihoo360.homecamera.machine.entity;

import com.google.gson.annotations.SerializedName;
import com.qihoo360.homecamera.mobile.entity.Head;

import java.io.Serializable;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2015/8/7
 * Time: 21:16
 * To change this template use File | Settings | File Templates.
 */
public class Replay extends Head implements Serializable{
    private static final long serialVersionUID = -5883000816607558236L;
    @SerializedName("id")
    public String forshowId;//预告id
    @SerializedName("title")
    public String forShowTitle;//直播名称
    @SerializedName("description")
    public String forShowDescription;//直播描述
    @SerializedName("start")
    public String forShowstart;//活动开始时间    shengli保证给标准格式 yyyy-MM-dd HH:mm:ss
    @SerializedName("previewUrl")
    public String forShowPreviewUrl;//预告图片url
    @SerializedName("extends")
    public ForShowExt forShowExt;
    public String createTime;

    public long startTs;
    public long endTs;


    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getForShowDescription() {
        return forShowDescription;
    }

    public void setForShowDescription(String forShowDescription) {
        this.forShowDescription = forShowDescription;
    }

    public ForShowExt getForShowExt() {
        return forShowExt;
    }

    public void setForShowExt(ForShowExt forShowExt) {
        this.forShowExt = forShowExt;
    }

    public String getForshowId() {
        return forshowId;
    }

    public void setForshowId(String forshowId) {
        this.forshowId = forshowId;
    }

    public String getForShowPreviewUrl() {
        return forShowPreviewUrl;
    }

    public void setForShowPreviewUrl(String forShowPreviewUrl) {
        this.forShowPreviewUrl = forShowPreviewUrl;
    }

    public String getForShowstart() {
        return forShowstart;
    }

    public void setForShowstart(String forShowstart) {
        this.forShowstart = forShowstart;
    }

    public String getForShowTitle() {
        return forShowTitle;
    }

    public void setForShowTitle(String forShowTitle) {
        this.forShowTitle = forShowTitle;
    }


    public void synData(Replay camera) {
        setForShowTitle(camera.forShowTitle);
        setForShowDescription(camera.forShowDescription);
        setForShowExt(camera.getForShowExt());
    }
}
