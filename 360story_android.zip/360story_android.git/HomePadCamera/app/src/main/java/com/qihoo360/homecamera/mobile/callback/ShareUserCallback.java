package com.qihoo360.homecamera.mobile.callback;


import com.qihoo360.homecamera.mobile.entity.ShareUser;

/**
 * Created by Administrator on 2014/12/26.
 */
public interface ShareUserCallback {



    void onDelShare(ShareUser camera, int postion);

    void onRemarkNick(ShareUser shareUser, int position);

}
