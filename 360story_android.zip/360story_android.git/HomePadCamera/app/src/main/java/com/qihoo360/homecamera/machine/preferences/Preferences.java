
package com.qihoo360.homecamera.machine.preferences;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;
import android.text.TextUtils;

import com.qihoo360.homecamera.mobile.SysConfig;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.io.File;
import java.util.HashSet;
import java.util.Set;

/**
 * 程序Preferences服务类
 */
public class Preferences {

    public static Context context = Utils.getContext();
    public static final String PREFERENCE_ISNEXT_NO_HINT = "isnext_no_hint";
    public static final String PREFERENCE_ISFIRSTRUN = "IsFirstRun";
    public static final String PREFERENCE_ISFIRST_PLAY = "IsFirstPlay";
    public static final String PREFERENCE_ISFIRST_USE_TIMELINE = "IsFirstUseTimeLine";
    public static final String PREFERENCE_ISFIRST_USE_MOTION_CLIP = "IsFirstUseMotionClip";
    public static final String PREFERENCE_ISFIRST_USE_IMAGE_FILTER = "IsFirstUseImageFilter";
    public static final String PREFERENCE_TOKEN = "App_Sina_Token";
    public static final String PREFERENCE_EXPIRESTIME = "App_Sina_ExpiresTime";
    public static final String PREFERENCE_REFRESHTOKEN = "App_Sina_RefreshToken";
    public static final String PREFERENCE_UID = "App_Sina_Uid";
    public static final String PREFERENCE_URL = "UpDateUrl";
    public static final String PREFERENCE_VERSION = "UpDateVersion";
    public static final String PREFERENCE_SIZE = "UpDateSize";
    public static final String PREFERENCE_FORCE = "UpDateForce";
    public static final String PREFERENCE_DESCR = "UpDateDescr";
    public static final String PREFERENCE_MD5 = "UpDateMD5";
    public static final String PREFERENCE_MUTE = "mute";

    public static final String PREFERENCE_MY_CAM_FIRST = "my_first_play";
    public static final String PREFERENCE_SHOW_ADD = "my_add_show";
    public static final String PREFERENCE_HAVE_NEW_V = "new_v";

    public static final String PREFERENCE_NAME_CAMERA = "camera";
    public static final String PREFERENCE_NAME_WIFI = "wifi";
    public static final String PREFERENCE_EVENT_MESSAGEID = "EventMessageID";

    public static final String PARAM_SHOW_GUIDE = "PARAM_SHOW_GUIDE";

    public static final String PREFERENCE_CHANNEL = "360FAMILY_CHANNEL";
    public static final String PREFERENCE_UPDATE_ALL_DATE = "update_all_date";
    private static SharedPreferences searchPreference;
    private static Boolean hideHomeAd;

    /**
     * Gives us a chance to set some default preferences if this is the first install of the
     * application.
     */
    public static void setupDefaults(SharedPreferences preferences) {
        Editor editor = preferences.edit();

        if (!preferences.contains(PREFERENCE_ISFIRSTRUN)) {
            editor.putBoolean(PREFERENCE_ISFIRSTRUN, true);
        }

        if (!preferences.contains(PREFERENCE_ISNEXT_NO_HINT)) {
            editor.putBoolean(PREFERENCE_ISNEXT_NO_HINT, true);
        }

        editor.commit();
    }

//    public static void saveUpDate2Preferences(SharedPreferences preferences,
//                                              DownloadPackageInfo apkInfo) {
//        Editor editor = preferences.edit();
//        editor.putString(PREFERENCE_URL, apkInfo.getUrl());
//        editor.putString(PREFERENCE_VERSION, apkInfo.getVersion());
//        CLog.i(">>>>>>>>>>>>>>>>>>>>>>>:apkInfo.getVersion:" + apkInfo.getVersion());
//        editor.putInt(PREFERENCE_SIZE, apkInfo.getSize());
//        editor.putInt(PREFERENCE_FORCE, apkInfo.getForce());
//        editor.putString(PREFERENCE_DESCR, apkInfo.getDescription());
//        editor.putString(PREFERENCE_MD5, apkInfo.getMd5());
//        editor.commit();
//    }

    public static void saveCameraMuteStatus(String uid, boolean status) {
        SharedPreferences sp =
                context.getSharedPreferences(PREFERENCE_NAME_CAMERA, Context.MODE_PRIVATE);
        Editor editor = sp.edit();
        editor.putBoolean(uid + PREFERENCE_MUTE, status);
        editor.commit();
    }

    public static boolean getCameraCutestatus(String uid) {
        SharedPreferences sp =
                context.getSharedPreferences(PREFERENCE_NAME_CAMERA, Context.MODE_PRIVATE);
        return sp.getBoolean(uid + PREFERENCE_MUTE, true);
    }

    public static void saveWifiPassword(String key, String password) {
        SharedPreferences sp =
                context.getSharedPreferences(PREFERENCE_NAME_WIFI, Context.MODE_PRIVATE);
        Editor editor = sp.edit();
        editor.putString(key, Utils.encodeBase64(password));
        editor.commit();
    }

    public static String getWifiPassword(String key) {
        SharedPreferences sp =
                context.getSharedPreferences(PREFERENCE_NAME_WIFI, Context.MODE_PRIVATE);
        return Utils.decodeBase64(sp.getString(key, ""));
    }

    public static void saveEventMessageID(long id) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        Editor editor = sp.edit();
        editor.putLong(PREFERENCE_EVENT_MESSAGEID, id);
        editor.commit();
    }

    public static long getEventMessageID(Context context) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        return sp.getLong(PREFERENCE_EVENT_MESSAGEID, -1);
    }

    private static SharedPreferences getSPBySn(String sn) {
        return context.getSharedPreferences(AccUtil.getInstance().getQID() + sn,
                Context.MODE_PRIVATE);
    }

    private static SharedPreferences getSPByQID() {
        return context.getSharedPreferences(AccUtil.getInstance().getQID(),
                Context.MODE_PRIVATE);
    }

    public static SharedPreferences getAppSP() {
        return context.getSharedPreferences("jia_app", Context.MODE_PRIVATE);
    }

    public static SharedPreferences getShareCodeSP() {
        return context.getSharedPreferences("share_code", Context.MODE_PRIVATE);
    }

    public static SharedPreferences getLocationServerSP() {
        return context.getSharedPreferences("location_server", Context.MODE_APPEND);
    }

    public static boolean getFirstEnter() {
        SharedPreferences sp = context.getSharedPreferences(PREFERENCE_ISFIRSTRUN, Context.MODE_PRIVATE);
        return sp.getBoolean("first_enter_app", false);
    }

    public static void setFirstEnter() {
        SharedPreferences sp = context.getSharedPreferences(PREFERENCE_ISFIRSTRUN, Context.MODE_PRIVATE);
        Editor editor = sp.edit();
        editor.putBoolean("first_enter_app", true);
        editor.commit();
    }

    public static int getFirstEnterAppVersion() {
        SharedPreferences sp = context.getSharedPreferences(PREFERENCE_ISFIRSTRUN, Context.MODE_PRIVATE);
        return sp.getInt("first_enter_app_version", 0);
    }

    public static void setFirstEnterAppVersion(int versionCode) {
        SharedPreferences sp = context.getSharedPreferences(PREFERENCE_ISFIRSTRUN, Context.MODE_PRIVATE);
        Editor editor = sp.edit();
        editor.putInt("first_enter_app_version", SysConfig.VERSION_CODE);
        editor.commit();
    }

    public static void setUserLayoutPref(int count) {
        SharedPreferences sp = context.getSharedPreferences(PREFERENCE_ISFIRSTRUN, Context.MODE_PRIVATE);
        Editor editor = sp.edit();
        editor.putInt("first_enter_app_version", SysConfig.VERSION_CODE);
        editor.commit();
    }

    /**
     * 没办法做成同步的
     */
    public static void cleanSharedPreference() {
        // files
        File dirFile =
                new File(context.getFilesDir().getAbsolutePath().replace("/files", "")
                        + "/shared_prefs");
        if (dirFile.exists() && dirFile.isDirectory()) {
            for (File spFile : dirFile.listFiles()) {
                String spName = spFile.getName();
                if (spName.contains(AccUtil.getInstance().getQID())) {
//                    System.out.println("++++++++++++++++++delete++" + spName);
                    spFile.delete();
                }
            }
        }
    }

    public static void saveVideoMuted(String sn, boolean isMuted) {
        SharedPreferences sp = getSPBySn(sn);
        Editor editor = sp.edit();
        editor.putBoolean("isMuted", isMuted);
        editor.commit();
    }

    public static boolean getVideoMuted(String sn) {
        SharedPreferences sp = getSPBySn(sn);
        return sp.getBoolean("isMuted", false);
    }

    public static void saveVideoReso(String sn, int reso) {
        SharedPreferences sp = getSPBySn(sn);
        Editor editor = sp.edit();
        editor.putInt("Reso", reso);
        editor.commit();
    }

    public static int getVideoReso(String sn) {
        SharedPreferences sp = getSPBySn(sn);
        return sp.getInt("Reso", -1);
    }

    public static void saveDanmaIsShow(String sn, boolean isShow) {
        SharedPreferences sp = getSPBySn(sn);
        Editor editor = sp.edit();
        editor.putBoolean("DanmaIsShow", isShow);//默认值为全局偏好,个别偏好优先级更高
        editor.commit();
    }

    public static boolean getDanmaIsShow(String sn) {
        SharedPreferences sp = getSPBySn(sn);
        return sp.getBoolean("DanmaIsShow", getDanmaPreference());
    }

    public static void saveLastWatchP(String sn, int watchNum) {
        SharedPreferences sp = getSPBySn(sn);
        Editor editor = sp.edit();
        editor.putInt("LastWatchP", watchNum);
        editor.commit();
    }

    public static int getTimeZoneChoose(String sn) {
        SharedPreferences sp = getSPBySn(sn);
        return sp.getInt("timezonechoose", -1);
    }

    public static void saveTimezoneChoose(String sn, int choose) {
        SharedPreferences sp = getSPBySn(sn);
        Editor editor = sp.edit();
        editor.putInt("timezonechoose", choose);
        editor.commit();
    }

    /**
     * @param sn
     * @return 0云录 1卡录
     */
    public static int getLastWatchP(String sn) {
        SharedPreferences sp = getSPBySn(sn);
        return sp.getInt("LastWatchP", 0);
    }

    public static void saveDanmaPreference(boolean toggle) {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putBoolean("DanmaPreference", toggle);
        editor.commit();
    }

    public static boolean getDanmaPreference() {
        SharedPreferences sp = getAppSP();
        return sp.getBoolean("DanmaPreference", false);
    }

    public static void saveSplashPreference(boolean toggle) {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putBoolean("SplashPreference", toggle);
        editor.commit();
    }

    public static boolean getSplashPreference() {
        SharedPreferences sp = getAppSP();
        return sp.getBoolean("SplashPreference", true);
    }

    public static void saveSplashId(String strId) {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putString("SplashId", strId);
        editor.commit();
    }

    public static String getSplashId() {
        SharedPreferences sp = getAppSP();
        return sp.getString("SplashId", "");
    }

    public static void saveQihooAccountPreference(String jsonString) {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putString("qihoo_account_info", jsonString);
        editor.commit();
    }

    public static String getQihooAccountPreference() {
        SharedPreferences sp = getAppSP();
        return sp.getString("qihoo_account_info", null);
    }

    public static void savePhoneShareCode(String code) {
        SharedPreferences sp = getShareCodeSP();
        Editor editor = sp.edit();
        editor.clear();
        editor.commit();

        editor.putString("PhoneShareCode", code);
        editor.commit();

    }


//    public static ServerLocation getServerLocation() {
//        SharedPreferences sharedPreferences = getLocationServerSP();
//        String json = sharedPreferences.getString("L_S", "");
//        ServerLocation serverLocation = null;
//        if (!TextUtils.isEmpty(json)) {
//            Gson gson = new Gson();
//            serverLocation = gson.fromJson(json, ServerLocation.class);
//        }
//        return serverLocation;
//    }


    public static void saveLocationServer(String string) {
        SharedPreferences sharedPreferences = getLocationServerSP();
        Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.commit();
        editor.putString("L_S", string);
        editor.commit();
    }

    public static String getPhoneShareCode() {
        SharedPreferences sp = getShareCodeSP();
        return sp.getString("PhoneShareCode", "");
    }

    //是否更新过Event表Date字段
    public static void setDateUpdate(String sn, boolean isShow) {
        SharedPreferences sp = getSPBySn(sn);
        Editor editor = sp.edit();
        editor.putBoolean("PREFERENCE_UPDATE_ALL_DATE", isShow);
        editor.commit();
    }

    public static boolean getDateIsUpdate(String sn) {
        SharedPreferences sp = getSPBySn(sn);
        return sp.getBoolean("PREFERENCE_UPDATE_ALL_DATE", true);
    }

    //记录每一个摄像机直播页面 谈谈列表出现分享的次数
    public static int getShowTanTanShareNum(String sn) {
        SharedPreferences sp = getSPBySn(sn);
        return sp.getInt(sn + "_num", 0);
    }

    public static void setShowTanTanShareNum(String sn) {
        SharedPreferences sp = getSPBySn(sn);
        Editor editor = sp.edit();
        int shareNum = sp.getInt(sn + "_num", 0);
        editor.putInt(sn + "_num", shareNum + 1);
        editor.commit();
        shareNum = sp.getInt(sn + "_num", 0);
        setShowTanTanShareTime(sn);
    }

    public static void setShowDanmuku(boolean show) {
        SharedPreferences sp = getSPByQID();
        Editor editor = sp.edit();
        editor.putBoolean("account_show_danmuku", show);
        editor.commit();
    }

    public static boolean getShowDanmuku() {
        SharedPreferences sp = getSPByQID();
        return sp.getBoolean("account_show_danmuku", false);
    }

    public static void setFamilyGuide() {
        SharedPreferences sp = getSPByQID();
        Editor editor = sp.edit();
        editor.putInt("family_guide", 1);
        editor.commit();
    }

    public static int getFamilyGuide() {
        SharedPreferences sp = getSPByQID();
        return sp.getInt("family_guide", 0);
    }

    public static void clearShowTanTanShareNum(String sn) {
        SharedPreferences sp = getSPBySn(sn);
        Editor editor = sp.edit();
        editor.putInt(sn + "_num", 0);
        editor.commit();
    }

    public static long getShowTanTanShareTime(String sn) {
        SharedPreferences sp = getSPBySn(sn);
        return sp.getLong(sn + "_time", System.currentTimeMillis());
    }

    public static void setShowTanTanShareTime(String sn) {
        SharedPreferences sp = getSPBySn(sn);
        Editor editor = sp.edit();
        editor.putLong(sn + "_time", System.currentTimeMillis());
        editor.commit();
    }

    public static SharedPreferences getSearchPreference() {
        return context.getSharedPreferences("search_hit", Context.MODE_PRIVATE);
    }

    public static boolean getLiveFirstFollow() {
        SharedPreferences sp = getAppSP();
        return sp.getBoolean("IsLiveFirstFollow", true);
    }

    public static void setLiveFirstFollow(boolean isFirst) {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putBoolean("IsLiveFirstFollow", isFirst);
        editor.commit();
    }

    public static Boolean getShowGuide() {
        SharedPreferences sp = getAppSP();
        return sp.getBoolean(PARAM_SHOW_GUIDE, false);
    }

    public static void setShowGuide(boolean isShow) {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putBoolean(PARAM_SHOW_GUIDE, isShow);
        editor.commit();
    }

    public static boolean isFirstAnchorBrodcast() {
        SharedPreferences sp = getAppSP();
        return sp.getBoolean("FirstAnchorBrodcast", true);
    }

    public static void setFirstAnchorBrodcast(boolean isFirst) {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putBoolean("FirstAnchorBrodcast", isFirst);
        editor.commit();
    }

    /**
     * @return 0，需要显示点读机按钮的引导
     */
    public static int getFirstSoundGuide() {
        SharedPreferences sp = getAppSP();
        return sp.getInt("FirstSoundGuide", 0);
    }

    /**
     * 因为以后可能还要修改点读机，估计还要重新出现引导
     *
     * @param key
     */
    public static void setFirstSoundGuide(int key) {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putInt("FirstSoundGuide", key);
        editor.commit();
    }

    /**
     * @return 0，需要安防列表小红点
     */
    public static int getSafeVideoGuide() {
        SharedPreferences sp = getAppSP();
        return sp.getInt("FirstSafeVideoGuide", 0);
    }

    /**
     * 安防小红点已显示
     */
    public static void setSafeVideoGuide() {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putInt("FirstSafeVideoGuide", 1);
        editor.commit();
    }

    /**
     * @return 0，需要安防提示
     */
    public static int getHasShowVideoGuide() {
        SharedPreferences sp = getAppSP();
        return sp.getInt("ShowVideoGuide", 0);
    }

    /**
     * 显示安防提示
     */
    public static void setHasShowVideoGuide() {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putInt("ShowVideoGuide", 1);
        editor.commit();
    }

    /**
     * @return 0，需要显示全双工按钮的引导
     */
    public static int getFirstMic2PhoneGuide() {
        SharedPreferences sp = getAppSP();
        return sp.getInt("FirstMic2PhoneGuide", 0);
    }

    /**
     * 设置显示过全双工按钮的引导
     *
     * @param key
     */
    public static void setFirstMic2PhoneGuide(int key) {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putInt("FirstMic2PhoneGuide", key);
        editor.commit();
    }

    /**
     * @return 0，需要显示关闭摄像机提示
     */
    public static int getNeverShowCameraSwitchTip() {
        SharedPreferences sp = getAppSP();
        return sp.getInt("NeverShowCameraSwitch", 0);
    }

    /**
     * 设置不再显示关闭摄像机提示
     */
    public static void setNeverShowCameraSwitchTip(int key) {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putInt("NeverShowCameraSwitch", key);
        editor.commit();
    }

    public static boolean getIsFirstMic(String sn) {
        SharedPreferences sp = getSPBySn(sn);
        return sp.getBoolean("isFirstMicMode" + sn, false);
    }

    public static void setIsFirstMic(String sn, boolean isFirst) {
        SharedPreferences sp = getSPBySn(sn);
        Editor editor = sp.edit();
        editor.putBoolean("isFirstMicMode" + sn, isFirst);
        editor.commit();
    }

    /**
     * @return 0，对讲模式
     */
    public static int getIsMic(String sn) {
        SharedPreferences sp = getSPBySn(sn);
        return sp.getInt("isMicMode" + sn, 0);
    }

    /**
     * 对讲模式传0
     *
     * @param sn
     */
    public static void setIsMic(String sn, int value) {
        SharedPreferences sp = getSPBySn(sn);
        Editor editor = sp.edit();
        editor.putInt("isMicMode" + sn, value);
        editor.commit();
    }

    /**
     * @return 0，未切换过
     */
    public static int getHasMicForceOnce(String sn) {
        SharedPreferences sp = getSPBySn(sn);
        return sp.getInt("hasMicForceOnce" + sn, 0);
    }

    /**
     * 切换过一次传1
     *
     * @param sn
     */
    public static void setHasMicForceOnce(String sn, int value) {
        SharedPreferences sp = getSPBySn(sn);
        Editor editor = sp.edit();
        editor.putInt("hasMicForceOnce" + sn, value);
        editor.commit();
    }

    /**
     * @return 0，未开启过视频报警
     */
    public static int getHasOpenVideoSafe(String sn) {
        SharedPreferences sp = getSPBySn(sn);
        return sp.getInt("hasOpenVideoSafe" + sn, 0);
    }

    /**
     * 开启过视频报警传1
     *
     * @param sn
     */
    public static void setHasOpenVideoSafe(String sn, int value) {
        SharedPreferences sp = getSPBySn(sn);
        Editor editor = sp.edit();
        editor.putInt("hasOpenVideoSafe" + sn, value);
        editor.commit();
    }

    /**
     * @return 0，未进入过视频报警设置
     */
    public static int getHasEnterVideoSafePage() {
        SharedPreferences sp = getAppSP();
        return sp.getInt("hasEnterVideoSafePage", 0);
    }

    /**
     * 进入视频报警设置
     */
    public static void setHasEnterVideoSafePage() {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putInt("hasEnterVideoSafePage", 1);
        editor.commit();
    }

    /**
     * 设置显示过全双工竖屏通话按钮按钮的引导
     *
     * @param key
     */
    public static void setFirstPhoneGuide(int key) {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putInt("FirstNewPortraitPhoneGuide", key);
        editor.commit();
    }

    /**
     * @return 0，竖屏通话按钮
     */
    public static int getIsFirstPhoneGuide() {
        SharedPreferences sp = getAppSP();
        return 1;//sp.getInt("FirstNewPortraitPhoneGuide", 0);
    }

    /**
     * @return 用户提醒频率
     */
    public static int getAlarmFrenquency(String uid) {
        SharedPreferences sp = getAppSP();
        return sp.getInt("alarmFrenquency" + uid, 30);
    }

//    /**
//     * 用户提醒频率
//     *
//     * @param uid
//     * @param value
//     */
//    public static void setAlarmFrenquency(String uid, int value) {
//        MessageService.NOTIFY_INTERVAL = value * 1000 * 60;
//        SharedPreferences sp = getAppSP();
//        Editor editor = sp.edit();
//        editor.putInt("alarmFrenquency" + uid, value);
//        editor.commit();
//    }

    public static int getFirstSoundGuideHome() {
        SharedPreferences sp = getAppSP();
        return sp.getInt("FirstSoundGuideHome", 0);
    }

    public static void setFirstSoundGuideHome(int v) {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putInt("FirstSoundGuideHome", v);
        editor.commit();
    }

    public static long getNewestCheckedForeshowTime() {
        SharedPreferences sp = getAppSP();
        return sp.getLong("NewestCheckedForeshowTime", 0);
    }

    public static void setNewestCheckedForeshowTime(long v) {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putLong("NewestCheckedForeshowTime", v);
        editor.commit();
    }

    public static long getNewestForeshowTime() {
        SharedPreferences sp = getAppSP();
        return sp.getLong("NewestForeshowTime", 0);
    }

    public static void setNewestForeshowTime(long v) {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putLong("NewestForeshowTime", v);
        editor.commit();
    }

    public static boolean getIsFaceMoveGuideShow() {
        SharedPreferences sp = getAppSP();
        return sp.getBoolean("IsFaceMoveGuideShow", false);
    }

    public static void setIsFaceMoveGuideShow() {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putBoolean("IsFaceMoveGuideShow", true);
        editor.commit();
    }

    public static boolean getNeedSynSecureDate() {
        SharedPreferences sp = getAppSP();
        return sp.getBoolean("needSynSecureDate", false);
    }

    public static void setNeedSynSecureDate(boolean need) {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putBoolean("needSynSecureDate", need);
        editor.commit();
    }

    public static String getShowFirmwareUpDialogVersion() {
        SharedPreferences sp = getAppSP();
        return sp.getString("ShowFirmwareUpDialogVersion", null);
    }

    public static void setShowFirmwareUpDialogVersion(String ver) {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putString("ShowFirmwareUpDialogVersion", ver);
        editor.commit();
    }

    public static void setVipAccount(String qid, boolean isVip) {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putBoolean(qid + "_vip", isVip);
        editor.commit();
    }

//    public static boolean isVipAccount(String qid) {
//        if (!CommonManager.QIHOO_ACCOUNT_SWITCH) {
//            return false;
//        }
//        SharedPreferences sp = getAppSP();
//        return sp.getBoolean(qid + "_vip", false);
//    }

    public static void setLoginAccount(String account) {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putString("LoginAccount", account);
        editor.commit();
    }

    public static String getLoginAccount() {
        SharedPreferences sp = getAppSP();
        return sp.getString("LoginAccount", "");
    }

    public static void setMicType(int micType) {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putInt("AudioTalkMicType", micType);
        editor.commit();
    }

    public static int getMicType() {
        SharedPreferences sp = getAppSP();
        return sp.getInt("AudioTalkMicType", 0);
    }

    public static void setVoiceConf(String conf) {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putString("AudioTalkVoiceConf", conf);
        editor.commit();
    }

    public static String getVoiceConf() {
        SharedPreferences sp = getAppSP();
        return sp.getString("AudioTalkVoiceConf", "");
    }

    public static void setQueryMicTypeTimestamp(int ts) {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putInt("AudioTalkQueryMicTypeTs", ts);
        editor.commit();
    }

    public static int getQueryMicTypeTimestamp() {
        SharedPreferences sp = getAppSP();
        return sp.getInt("AudioTalkQueryMicTypeTs", 0);
    }

    public static Long getAnchorBroadcastTime(String sn) {
        SharedPreferences sp = getAppSP();
        return sp.getLong("AnchorBroadcastTime_" + sn, 0);
    }

    public static void setAnchorBroadcastTime(String sn, long timestamp) {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putLong("AnchorBroadcastTime_" + sn, timestamp);
        editor.commit();
    }

    public static boolean isShowPanel() {
        SharedPreferences sp = getAppSP();
        int count = sp.getInt("isShowPanel", 1);
        if (count > 5) {
            return false;
        } else {
            count++;
            Editor editor = sp.edit();
            editor.putInt("isShowPanel", count);
            editor.commit();
            return true;
        }
    }

    public static boolean getIsFirstUseForeshow() {
        SharedPreferences sp = getAppSP();
        return sp.getBoolean("IsFirstUseForeshow", true);
    }

    public static void setIsFirstUseForeshow() {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putBoolean("IsFirstUseForeshow", false);
        editor.commit();
    }

    public static boolean getIsFirstMiniGuideShow() {
        SharedPreferences sp = getAppSP();
        return sp.getBoolean("IsFirstMiniGuideShow", true);
    }

    public static void setIsFirstMiniGuideShow() {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putBoolean("IsFirstMiniGuideShow", false);
        editor.commit();
    }

    public static boolean getIsMiniGuideModeOn() {
        SharedPreferences sp = getAppSP();
        return sp.getBoolean("IsMiniGuideOn", true);
    }

    public static void setIsMiniGuideModeOn(boolean on) {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putBoolean("IsMiniGuideOn", on);
        editor.commit();
    }

    public static String getVoteStyleVersion() {
        SharedPreferences sp = getAppSP();
        return sp.getString("vote_style_version", null);
    }

    public static void setVoteStyleVersion(String md5) {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putString("vote_style_version", md5);
        editor.commit();
    }

    public static int getShowNewTagVersion() {
        SharedPreferences sp = getAppSP();
        return sp.getInt("show_new_tag_version", 0);
    }

    public static void setShowNewTagVersion(int version) {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putInt("show_new_tag_version", version);
        editor.commit();
    }

    public static boolean getshowDelPhotoShow() {
        SharedPreferences sp = getAppSP();
        return sp.getBoolean("show_del_safe_photo", false);
    }

    public static boolean getShowShareVideoPrompt() {
        SharedPreferences sp = getAppSP();
        return sp.getBoolean("show_share_video_prompt", false);
    }

    public static void setShowShareVideoPrompt() {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putBoolean("show_share_video_prompt", true);
        editor.commit();
    }

    public static void setDelPhotoShow() {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putBoolean("show_del_safe_photo", true);
        editor.commit();
    }

    public static void testPreferenceVersion() {
        String version = getPreferenceVersion();
        if (TextUtils.isEmpty(version) || !TextUtils.equals(version, SysConfig.VERSION_NAME)) {
            resetWhenVersionChange();
            setPreferenceVersion(SysConfig.VERSION_NAME);
        }
    }

    private static void resetWhenVersionChange() {
        setQueryMicTypeTimestamp(0);
    }

    private static String getPreferenceVersion() {
        SharedPreferences sp = getAppSP();
        return sp.getString("preference_version", null);
    }

    private static void setPreferenceVersion(String version) {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putString("preference_version", version);
        editor.commit();
    }

    public static String getMyAddress() {
        SharedPreferences sp = getAppSP();
        return sp.getString("my_address", null);
    }

    public static void setMyAddress(String myAddress) {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putString("my_address", myAddress);
        editor.commit();
    }

    public static boolean getBNFirstOn() {
        SharedPreferences sp = getAppSP();
        return sp.getBoolean("bn_already_play", false);
    }

    public static void setBNFirstOn() {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putBoolean("bn_already_play", true);
        editor.commit();
    }

    public static void setLikeVersion(int version) {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putInt("like_version", version);
        editor.commit();
    }

    public static boolean getHasShowVMSGuide() {
        SharedPreferences sp = getAppSP();
        return sp.getBoolean("has_show_vms_guide", false);
    }

    public static void setHasShowVMSGuide() {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putBoolean("has_show_vms_guide", true);
        editor.commit();

    }

    public static boolean getHasShowHomeShareGuide() {
        SharedPreferences sp = getAppSP();
        return sp.getBoolean("has_show_home_share_guide", false);
    }

    public static void setHasShowHomeShareGuide() {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putBoolean("has_show_home_share_guide", true);
        editor.commit();
    }

    public static boolean getHasShowHomeSwithchGuide() {
        SharedPreferences sp = getAppSP();
        return sp.getBoolean("has_show_home_swith_guide", false);
    }

    public static void setHasShowHomeSwitchGuide() {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putBoolean("has_show_home_swith_guide", true);
        editor.commit();
    }


    public static boolean getHasShowHomeShareGuide2() {
        SharedPreferences sp = getAppSP();
        return sp.getBoolean("has_show_home_share_guide2", false);
    }

    public static void setHasShowHomeShareGuide2() {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putBoolean("has_show_home_share_guide2", true);
        editor.commit();
    }

    public static boolean getPhoneWatchSound(String sn) {
        SharedPreferences sp = getSPBySn(sn);
        return sp.getBoolean("phone_watch_sound", true);
    }

    public static void setPhoneWatchSound(String sn, boolean sound) {
        SharedPreferences sp = getSPBySn(sn);
        Editor editor = sp.edit();
        editor.putBoolean("phone_watch_sound", sound);
        editor.commit();
    }

    public static boolean getFirstShowFN() {
        SharedPreferences sp = getAppSP();
        return sp.getBoolean("first_show_fn_tab", true);
    }

    public static void setFirstShowFN() {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putBoolean("first_show_fn_tab", false);
        editor.commit();
    }


    public static void setVideoScale(String sn, float scale) {
        SharedPreferences sp = getSPByQID();
        sp.edit().putFloat(sn + "video_scale", scale).commit();
    }

    public static float getVideoScale(String sn) {
        SharedPreferences sp = getSPByQID();
        return sp.getFloat(sn + "video_scale", -1.0f);
    }

//    public static void setVideoTranslation(String sn, int p) {
//        SharedPreferences sp = getSPByQID();
//        sp.edit().putFloat(sn + "video_Translation", p).commit();
//    }
//    public static int getVideoTranslation(String sn) {
//        SharedPreferences sp = getSPByQID();
//        return sp.getInt(sn + "video_Translation", -1);
//    }

    public static int getUserLayout() {
        SharedPreferences sp = getSPByQID();
        return sp.getInt("layout", 1);
    }

    public static void setUserLayout(int layout) {
        SharedPreferences sp = getSPByQID();
        Editor editor = sp.edit();
        editor.putInt("layout", layout);
        editor.commit();
    }

//    public static HomeAd getHomeAd() {
//        SharedPreferences sp = getSPByQID();
//        String homeAdStr = sp.getString("home_ad", "");
//        HomeAd homeAd = new HomeAd();
//        if (!TextUtils.isEmpty(homeAdStr)) {
//            Gson gson = new Gson();
//            homeAd = gson.fromJson(homeAdStr, HomeAd.class);
//        }
//        return homeAd;
//    }
//
//    public static void setHomeAd(HomeAd homeAdHide) {
//        if (homeAdHide != null) {
//            SharedPreferences sp = getSPByQID();
//            Editor editor = sp.edit();
//            editor.putString("home_ad", homeAdHide.toJson());
//            editor.commit();
//        }
//    }


    public static boolean HideHomeAd() {
        SharedPreferences sp = getSPByQID();
        boolean homeAdStr = sp.getBoolean("show_hide_ad", true);
        return homeAdStr;
    }

    public static void setHideOrShow(boolean show) {
        SharedPreferences sp = getSPByQID();
        Editor editor = sp.edit();
        editor.putBoolean("show_hide_ad", show);
        editor.commit();
    }

    //--------------------------------todo 保存网络读取的开关---------------------------------------/
    public static void saveCloud(String string) {
        CLog.i("test2", "--saveCloud-- = " + string);
        if (!TextUtils.isEmpty(string)) {
            SharedPreferences sp = getAppSP();
            Editor editor = sp.edit();
            editor.putString("config_cloud_turn", string);
            editor.commit();
        }
    }

//    public static Config.MobileI getCloud() {
//        SharedPreferences sp = getAppSP();
//        String homeAdStr = sp.getString("config_cloud_turn", "");
//        Log.i("test2", "--homeAdStr-- = " + homeAdStr);
//        Config.MobileI mobileI = new Config.MobileI();
//        if (!TextUtils.isEmpty(homeAdStr)) {
//            Gson gson = new Gson();
//            mobileI = gson.fromJson(homeAdStr, Config.MobileI.class);
//        }
//        com.qihoo.jia.util.log.CLog.json("tomcat", homeAdStr);
//        return mobileI;
//    }

    //--------------------------------todo  保存网络读取的开关---------------------------------------/


    public static void setIsShowFirmwareUpgradeTip(String sn, boolean isShow) {
        SharedPreferences sp = getSPByQID();
        Set<String> snSet = sp.getStringSet("is_show_firmware_upgrade_tip", null);
        if (snSet == null) {
            snSet = new HashSet<String>();
        }
        if (!isShow) {
            snSet.add(sn);
        } else {
            snSet.remove(sn);
        }
        Editor editor = sp.edit();
        editor.putStringSet("is_show_firmware_upgrade_tip", snSet);
        editor.apply();
    }

    public static boolean getIsShowFirmwareUpgradeTip(String sn) {
        SharedPreferences sp = getSPByQID();
        Set<String> snSet = sp.getStringSet("is_show_firmware_upgrade_tip", null);
        if (snSet == null) {
            return true;
        } else {
            return !snSet.contains(sn);
        }
    }

    public static void clearIsShowFirmwareUpgradeTip() {
        SharedPreferences sp = getSPByQID();
        sp.edit().remove("is_show_firmware_upgrade_tip").apply();
    }

    public static void setIsFirst(String key) {
        SharedPreferences sp = getAppSP();
        Editor editor = sp.edit();
        editor.putBoolean(key, false);
        editor.commit();
    }

    public static boolean getIsFirst(String key) {
        return getAppSP().getBoolean(key, true);
    }

    public static boolean getshareShow() {
        SharedPreferences sp = getSPByQID();
        return sp.getBoolean("share", false);
    }

    public static void putShareShow(boolean flag) {
        SharedPreferences sp = getSPByQID();
        sp.edit().putBoolean("share", flag).commit();
    }

    public static long getshareShowLaset() {
        SharedPreferences sp = getSPByQID();
        return sp.getLong("share_last_time", 0l);

    }

    public static void putShareLastShowTime() {
        SharedPreferences sp = getSPByQID();
        sp.edit().putLong("share_last_time", System.currentTimeMillis()).commit();

    }

    public static void setIsFirstShowTextMsgRedDot(boolean b){
        SharedPreferences sp = getSPByQID();
        sp.edit().putBoolean("is_first_show_text_msg_red_dot", b).apply();
    }

    public static boolean getIsFirstShowTextMsgRedDot(){
        SharedPreferences sp = getSPByQID();
        return sp.getBoolean("is_first_show_text_msg_red_dot", true);
    }

    public static void setIsFirstShowVideoMsgRedDot(boolean b){
        SharedPreferences sp = getSPByQID();
        sp.edit().putBoolean("is_first_show_video_msg_red_dot", b).apply();
    }

    public static boolean getIsFirstShowVideoMsgRedDot(){
        SharedPreferences sp = getSPByQID();
        return sp.getBoolean("is_first_show_video_msg_red_dot", true);
    }

    public static void setIsFirstShowAppNewRedDot(boolean b){
        SharedPreferences sp = getSPByQID();
        sp.edit().putBoolean("is_first_show_app_new_red_dot", b).apply();
    }

    public static boolean getIsFirstShowAppNewRedDot(){
        SharedPreferences sp = getSPByQID();
        return sp.getBoolean("is_first_show_app_new_red_dot", true);
    }

}
