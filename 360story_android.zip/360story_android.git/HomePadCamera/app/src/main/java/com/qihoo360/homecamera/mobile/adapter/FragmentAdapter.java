package com.qihoo360.homecamera.mobile.adapter;

import android.graphics.drawable.Drawable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ImageSpan;
import android.view.ViewGroup;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.ui.fragment.ListFragment;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.util.List;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/3/26
 * Time: 10:09
 * To change this template use File | Settings | File Templates.
 */
public class FragmentAdapter extends FragmentStatePagerAdapter {
    private List<Fragment> mFragments;
    private String[] mTitles;
    private int[] imageResId = {R.drawable.icon_like,
            R.drawable.icon_like,
            R.drawable.icon_like, R.drawable.icon_like};

    public FragmentAdapter(FragmentManager fm, List<Fragment> fragments, String[] titles) {
        super(fm);
        mFragments = fragments;
        mTitles = titles;
    }


    @Override
    public int getItemPosition(Object object) {
        return POSITION_NONE;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
//        super.destroyItem(container,position,object);
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        ListFragment f = (ListFragment) super.instantiateItem(container, position);
        return f;
    }

    @Override
    public Fragment getItem(int position) {
        return mFragments.get(position);
    }

    @Override
    public int getCount() {
        return mFragments.size();
    }


    @Override
    public CharSequence getPageTitle(int position) {
        Drawable image = Utils.getResources().getDrawable(imageResId[position]);
        image.setBounds(0, 0, image.getIntrinsicWidth(), image.getIntrinsicHeight());
        SpannableString sb = new SpannableString(" " + mTitles[position]);
        ImageSpan imageSpan = new ImageSpan(image, ImageSpan.ALIGN_BOTTOM);
        sb.setSpan(imageSpan, 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return sb;
    }

}
