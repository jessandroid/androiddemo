package com.qihoo360.homecamera.machine.myvideoplay;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.qihoo360.homecamera.machine.entity.Camera;
import com.qihoo360.homecamera.mobile.R;

import java.util.ArrayList;
import java.util.List;

public class TitleHeadListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private ArrayList<Camera> mData;

    public String getmCurrtSn() {
        return mCurrtSn;
    }

    public void setmCurrtSn(String mCurrtSn) {
        this.mCurrtSn = mCurrtSn;
    }

    private String mCurrtSn;

    protected Context mActivityContext;

    public interface Callback {
        public void onCameraItemClick(Camera camera);
    }

    private Callback mCallback;

    public TitleHeadListAdapter(Context context) {
        super();
        mActivityContext = context;
        mData = new ArrayList<Camera>();
    }

    public void setCallback(Callback callback) {
        mCallback = callback;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new CameraItemViewHolder((LayoutInflater.from(parent.getContext()).inflate(R.layout.video_play_camera_list_item, parent, false)));
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof CameraItemViewHolder) {
            final Camera camera = mData.get(position);
            CameraItemViewHolder rh = (CameraItemViewHolder) holder;
            rh.mTitleTxtView.setText(TextUtils.isEmpty(camera.getTitle()) ? camera.sn : camera.getTitle());
            rh.mTitleTxtView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mCallback != null) {
                        setmCurrtSn(camera.getSN());
                        mCallback.onCameraItemClick(camera);
                    }
                }
            });
            rh.mSelector.setVisibility(TextUtils.equals(camera.getSN(), getmCurrtSn()) ? View.VISIBLE : View.INVISIBLE);
        }
    }

    public void setData(List<Camera> data) {
        mData.clear();
        mData.addAll(data);
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public Camera getItem(int index) {
        return index < mData.size() ? mData.get(index) : null;
    }

    public int getPosition(Camera c) {
        return mData.indexOf(c);
    }

    public static class CameraItemViewHolder extends RecyclerView.ViewHolder {

        View mItemView;
        View mSelector;
        Button mTitleTxtView;

        public CameraItemViewHolder(View itemView) {
            super(itemView);
            mItemView = itemView;
            mTitleTxtView = (Button) itemView.findViewById(R.id.title);
            mSelector = itemView.findViewById(R.id.selector);
        }
    }
}
