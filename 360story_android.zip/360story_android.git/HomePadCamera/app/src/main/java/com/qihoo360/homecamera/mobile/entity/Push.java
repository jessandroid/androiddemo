package com.qihoo360.homecamera.mobile.entity;

import com.google.gson.JsonElement;

import java.io.Serializable;

/**
 * Created by zhucheng on 3/2/16.
 */
public class Push implements Serializable {

    private static final long serialVersionUID = -3289466334197887022L;

    public static final int TYPE_LOGIN = 1;
    public static final int TYPE_BIND = 2;//被绑定了
    public static final int TYPE_UNBIND = 3;//被解绑了
    public static final int TYPE_SHARE_SUC = 4;//分享成功
    public static final int TYPE_RESOLUTION = 5;//换清晰度
    public static final int TYPE_CHANGE_VOICE_CALL = 6;//切换语音通话

    public static final int RESOLUTION_SUPER_HD = 5001;//超清
    public static final int RESOLUTION_HIGH_HD = 5002;//高清
    public static final int RESOLUTION_SMOOTH_HD = 5003;//流畅

    public int type;
    public long time;
    public String message;
    public JsonElement data;
}
