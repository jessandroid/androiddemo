
package com.qihoo360.homecamera.mobile.core.manager.util;

/**
 * 每个使用此接口的地方都需要为新的ActionCode添加注释<br>
 * 注释格式：<br>
 *    <code>
 *    {@literal /**}<br>
 *    &nbsp*{@literal @see} {@literal
 *    {@literal @link ActionListener#actionPerformed(int, Object...)}}<br>
 *    &nbsp*此Action的作用是下载已完成<br>
 *    &nbsp*可变参数列表：{{@literal @link} Integer},{{@literal @link} String}<br>
 *    &nbsp*{@literal /}<br>
 *    &nbsppublic static final int ACTION_DOWNLOAD_FINISH = 1;
 *    </code>
 */
public interface ActionListener {
    /**
     * 操作回调接口
     * @param actionCode 操作的action值
     * @param args 返回参数，使用的地方通过{@code args[0],args[1],args[2]...取参数}
     * <br>具体参数个数，依赖具体action操作
     * @return
     */
    Object actionPerformed(int actionCode, Object... args);
    /**
     * @author changxiao-qhwl
     * 接受action的优先级
     * 值越大优先级越高
     */
    int getProperty();
}
