
package com.qihoo360.homecamera.mobile.exception;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

@SuppressWarnings("deprecation")
public class CrashAction {
    private final String TAG = "crashaction";

    private final String URL_INFO = "http://crash.browser.360.cn/interface/crashinfo/?";
    private final String URL_FILE = "http://crash.browser.360.cn/interface/dumpinfo/";

    private final int PRODUCT_ID = 23;
    private final String KEY = "jIaCaM.360.cn";

    private final String SRC = "src";
    private final String CVERIFY = "cverify";
    private final String VERSION = "version"; // version
    private final String PROCESS_TYPE = "process_type"; // build
    private final String SYSTEM_VERSION = "system_version"; // device
    private final String IE_VERSION = "ie_version"; // android version
    private final String PID = "pid";
    private final String ID = "id";
    private final String FILE = "file";

    private final String ZIP_FILENAME = "log.zip";

    private final String ENCODE = "utf-8";
    private final int Error = -1;

    public CrashAction() {
    }

    /**
     * 发送崩溃消息
     */
  /*  public int sendCrashMessage() {
        int ret = Error;
        DefaultHttpClient httpClient = null;

        try {
            HttpParams myParams = new BasicHttpParams();
            HttpConnectionParams.setConnectionTimeout(myParams, 30000);
            HttpConnectionParams.setSoTimeout(myParams, 30000);
            httpClient = new DefaultHttpClient(myParams);

            String dumpId = sendBaseInfo(httpClient);
            if (dumpId != null && !dumpId.isEmpty()) {
                ret = sendCrashFile(httpClient, dumpId);
            }
        } catch (Exception e) {
            CLog.i(TAG, e.toString());
        } finally {
            if (httpClient != null && httpClient.getConnectionManager() != null)
                httpClient.getConnectionManager().shutdown();
            File zipFile = new File(LogUtilDeprecated.EXCEPTION_LOG_DIR + ZIP_FILENAME);
            if (zipFile != null && zipFile.exists())
                zipFile.delete();
        }
        return ret;
    }

    private String sendBaseInfo(DefaultHttpClient httpClient) throws Exception {
        if (httpClient == null)
            return null;

        String ret = null;

        StringBuffer pubkey = new StringBuffer("");
        pubkey.append(SysConfig.VERSION_NAME + SysConfig.CHANNEL_ID + Build.MODEL + Build.VERSION.RELEASE);
        String cverify = MD5Util.getMD5code(pubkey.toString() + KEY);

        StringBuffer url = new StringBuffer(URL_INFO);
        url.append(SRC + "=" + PRODUCT_ID);
        url.append("&" + CVERIFY + "=" + cverify);
        url.append("&" + VERSION + "=" + SysConfig.VERSION_NAME);
        url.append("&" + PROCESS_TYPE + "=" + "0000");
        url.append("&" + SYSTEM_VERSION + "=" + Utils.GetURLEncoder(Utils.GetURLEncoder(Build.MODEL, ENCODE), ENCODE));
        url.append("&" + IE_VERSION + "=" + Utils.GetURLEncoder(Build.VERSION.RELEASE, ENCODE));
        url.append("&" + PID + "=" + SysConfig.CHANNEL_ID);

        HttpGet httpGet = new HttpGet(url.toString());

        HttpResponse response = null;
        HttpEntity resEntity = null;
        BufferedReader reader = null;
        StringBuffer sb = new StringBuffer("");

        response = httpClient.execute(httpGet);
        if (response != null) {
            resEntity = response.getEntity();
            if (resEntity != null) {
                reader = new BufferedReader(new InputStreamReader(resEntity.getContent(), Const.ENCODING));
                String line = null;
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
                CLog.d(TAG, "crashinfo=" + sb);
                JSONObject jsonObject = null;
                jsonObject = new JSONObject(sb.toString());
                if (jsonObject != null) {
                    ret = jsonObject.getString("dumpid");
                }
            }
        }

        return ret;
    }

    private int sendCrashFile(DefaultHttpClient httpClient, String dump_id) throws Exception {
        if (httpClient == null)
            return Error;

        int ret = Error;

        File zipFile = null;
        if (SysConfig.DIR_LOG_PATH.exists()) {
            zipFile = new File(LogUtilDeprecated.EXCEPTION_LOG_DIR + ZIP_FILENAME);
            File[] resFiles = {
                    SysConfig.CRASH_FILE_PATH, SysConfig.APP_LOG_PATH
            };
            if (new ZipFileUtil().zipFiles(resFiles, zipFile) == false) {
                return ret;
            }
        }
        else {
            return ret;
        }

        byte[] fileContent = readFile(zipFile);
        if (fileContent == null) {
            return ret;
        }

        HttpResponse response = null;
        HttpPost httpPost = null;
        HttpEntity resEntity = null;
        BufferedReader reader = null;
        StringBuffer sb = null;

        httpPost = new HttpPost(URL_FILE);
        MultipartEntity entity = new MultipartEntity();
        entity.addPart(SRC, new StringBody(Integer.toString(PRODUCT_ID)));
        entity.addPart(ID, new StringBody(dump_id));
        entity.addPart(FILE, new FileBody(zipFile));
        byte[] content = byteMerger(fileContent, dump_id.getBytes(), KEY.getBytes());
        entity.addPart(CVERIFY, new StringBody(MD5Util.getMD5code(content)));
        httpPost.setEntity(entity);

        response = httpClient.execute(httpPost);
        if (response != null) {
            resEntity = response.getEntity();
            if (resEntity != null) {
                reader = new BufferedReader(new InputStreamReader(resEntity.getContent(), Const.ENCODING));
                String line = null;
                sb = new StringBuffer("");
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
                CLog.d(TAG, "dumpinfo=" + sb);
                JSONObject jsonObject = null;
                jsonObject = new JSONObject(sb.toString());
                if (jsonObject != null) {
                    ret = jsonObject.getInt("status");
                    if (ret == 1)
                        ret = 0;
                }
            }
        }

        return ret;
    }*/

    private byte[] readFile(File file) {
        if (!file.exists() || file.length() <= 0)
            return null;

        InputStream in = null;
        byte[] buffer = null;

        byte[] ret = null;
        ByteArrayOutputStream bos = null;
        try {
            in = new FileInputStream(file);
            if (in != null) {
                bos = new ByteArrayOutputStream();
                buffer = new byte[1024];
                int readLength = 0;
                while ((readLength = in.read(buffer)) != -1) {
                    bos.write(buffer, 0, readLength);
                }
                ret = bos.toByteArray();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (bos != null)
                    bos.close();
                if (in != null)
                    in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return ret;
    }

    private byte[] byteMerger(byte[] byte_1, byte[] byte_2, byte[] byte_3) {
        byte[] byte_ret = new byte[byte_1.length + byte_2.length + byte_3.length];
        System.arraycopy(byte_1, 0, byte_ret, 0, byte_1.length);
        System.arraycopy(byte_2, 0, byte_ret, byte_1.length, byte_2.length);
        System.arraycopy(byte_3, 0, byte_ret, byte_1.length + byte_2.length, byte_3.length);
        return byte_ret;
    }
}
