
package com.qihoo360.homecamera.machine.entity;

import com.qihoo360.homecamera.mobile.entity.Head;

/**
 * Created by wdynetposa on 2015/5/6.
 */
public class PlayPublicInfo extends Head {
    private static final long serialVersionUID = -5007573715906853866L;
    private Relay playInfo;
    private PublicCamera publicInfo;

    public Relay getPlayInfo() {
        return playInfo;
    }

    public void setPlayInfo(Relay playInfo) {
        this.playInfo = playInfo;
    }

    public PublicCamera getPublicInfo() {
        return publicInfo;
    }

    public void setPublicInfo(PublicCamera publicInfo) {
        this.publicInfo = publicInfo;
    }
}
