package com.qihoo360.homecamera.machine.fragment;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.qihoo360.homecamera.device.config.StoryMachineConsts;
import com.qihoo360.homecamera.machine.activity.MachineAlbumActivity;
import com.qihoo360.homecamera.machine.activity.StoryPlayerActivity;
import com.qihoo360.homecamera.machine.business.JsonManager;
import com.qihoo360.homecamera.machine.business.PlayConfig;
import com.qihoo360.homecamera.machine.business.SettingTask;
import com.qihoo360.homecamera.machine.business.TaskExecutor;
import com.qihoo360.homecamera.machine.entity.FavorResultEntity;
import com.qihoo360.homecamera.machine.entity.MachinePlaySingle;
import com.qihoo360.homecamera.machine.entity.MachineSong;
import com.qihoo360.homecamera.machine.entity.SongEntity;
import com.qihoo360.homecamera.machine.entity.SongListResponse;
import com.qihoo360.homecamera.machine.manager.MachinePlayInfoManager;
import com.qihoo360.homecamera.machine.ui.adapter.SongListAdapter;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.db.MachineSongWrapper;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.ui.storyui.VerticalSwipeRefreshLayout;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.Preferences;
import com.qihoo360.homecamera.mobile.utils.QHStatAgentHelper;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.widget.CenteredImageSpan;
import com.qihoo360.homecamera.mobile.widget.RoundImageView;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import jp.wasabeef.glide.transformations.BlurTransformation;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.functions.Func1;
import rx.schedulers.Schedulers;

/**
 * Created by zhangtao-iri on 2016/10/31.
 */
public class SongListFragment extends MachineBaseFragment implements SongListAdapter.ItemClickListener, ActionListener{

    @Bind(R.id.btn_back)
    ImageView btnBack;

    @Bind(R.id.title_zone)
    LinearLayout titleZone;

    @Bind(R.id.top_bg)
    ImageView topBg;

    @Bind(R.id.top_bg_zone)
    FrameLayout tipBgZone;

    @Bind(R.id.top_zone)
    RelativeLayout topZone;//只有专辑的儿歌列表才显示

    @Bind(R.id.frag_title)
    TextView fTitle;

    @Bind(R.id.story_cover)
    RoundImageView storyCover;

    @Bind(R.id.album_name)
    TextView albumName;

    @Bind(R.id.album_num)
    TextView albumNum;

    @Bind(R.id.song_num_zone)
    RelativeLayout songNumZone;

    @Bind(R.id.song_num)
    TextView sognNum;

    @Bind(R.id.video_list)
    RecyclerView mListView;

    @Bind(R.id.enter_player)
    ImageView enterPlayer;

    @Bind(R.id.swipe_container)
    VerticalSwipeRefreshLayout swipeRefreshLayout;

    @Bind(R.id.foot_loading)
    View loading;

    @Bind(R.id.empty_view)
    View emptyView;

    @Bind(R.id.try_text)
    TextView tryText;

    @Bind(R.id.no_favor_text)
    TextView noFavorText;

    @Bind(R.id.no_content_view)
    View noContentView;

    private SongListAdapter adapter;
    private LinearLayoutManager mListLayoutManager;

    private int pageId = 1;//默认从第一页开始加�?

    private int totalCount;//列表总数

    private MachineAlbumActivity parentActivity;

    private CopyOnWriteArrayList<SongEntity> dataList;

    private String albumUnique;//专辑唯一标识
    private String mAlbumTitle;//儿歌\专辑\收藏
    private int mLstType;//儿歌\专辑\收藏
    private int mSongTotal;
    private String mCoverUrl;
    private int mType;

    private MachinePlaySingle mPlaySingle;

    private boolean isFirst = true;

    private MyHandler handler = new MyHandler(this);

    private boolean isOnline;

    private long preTime = 0;
    private MyRunnable runnable;
    private String device_type;


    public static SongListFragment newInstance(){
        SongListFragment songListFragment = new SongListFragment();
        Bundle bundle = new Bundle();
        songListFragment.setArguments(bundle);
        return songListFragment;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        parentActivity = (MachineAlbumActivity)context;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        device_type = (String)(getArguments().get(StoryMachineConsts.KEY_SET_DEVICE_TYPE));
//        Log.e("Mars1","device_type_lib: "+device_type);
        ButterKnife.bind(this, mRootView);
        initViews();

        return mRootView;
    }

    @Override
    public void onDestroyView() {
        GlobalManager.getInstance().getMachineManager().removeActionListener(this);
        MachinePlayInfoManager.getInstance().removeActionListener(this);
        super.onDestroyView();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if(mLstType == MachineAlbumActivity.ALBUMLIST || mLstType == MachineAlbumActivity.SONGLIST){
            getData(albumUnique, pageId);
        }else if(mLstType == MachineAlbumActivity.FAVORLIST){
            //获取收藏列表
            getFavorList("collect");
            getPlayInfo();
        }
    }

    @Override
    public int getRootViewLayoutId() {
        return R.layout.fragment_story_list;
    }

    protected void initViews() {
        MachinePlayInfoManager.getInstance().registerActionListener(this);
        GlobalManager.getInstance().getMachineManager().registerActionListener(this);

        mLstType = parentActivity.listType;
        if(mLstType == MachineAlbumActivity.FAVORLIST){
            mType = PlayConfig.ListType.FAVORLIST;
        }else{
            albumUnique = parentActivity.unique;
            mAlbumTitle = parentActivity.albumTitle;
            mSongTotal = parentActivity.songTotal;
            mCoverUrl = parentActivity.coverUrl;
            mType = parentActivity.type;
        }
        swipeRefreshLayout.setEnabled(false);//关闭刷新功能
        dataList = new CopyOnWriteArrayList<>();
        adapter = new SongListAdapter(mLstType, this, parentActivity);
        mListLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        mListView.setLayoutManager(mListLayoutManager);
        mListView.setAdapter(adapter);
        mListView.setItemAnimator(null);
        mListView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
            }

            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                if(mLstType != MachineAlbumActivity.FAVORLIST){//收藏列表不需要加载更�?
                    if (newState == RecyclerView.SCROLL_STATE_IDLE) {
                        if (mListLayoutManager.findLastCompletelyVisibleItemPosition() == (adapter.getItemCount() - 1)) {
                            //TODO  加载下一�?
                            if(dataList.size()==totalCount){
                                //TODO 数据已经加载完毕,不需要做操作
                            }else{
                                Utils.ensureVisbility(loading, View.VISIBLE);
                                pageId++;
                                getData(albumUnique, pageId);
                            }
                        }
                    }
                }
            }
        });

        //区分是专辑儿歌列表还是儿歌列�?
        Utils.ensureVisbility(topZone, (mLstType== MachineAlbumActivity.ALBUMLIST) ? View.VISIBLE : View.GONE);
        Utils.ensureVisbility(tipBgZone, (mLstType== MachineAlbumActivity.ALBUMLIST) ? View.VISIBLE : View.GONE);
        Utils.ensureVisbility(songNumZone, (mLstType== MachineAlbumActivity.ALBUMLIST) ? View.GONE : View.VISIBLE);
        if(mLstType== MachineAlbumActivity.ALBUMLIST){
            albumName.setText(mAlbumTitle);
            storyCover.setType(1);
            //加载封面�?
            Glide.with(parentActivity)
                    .load(mCoverUrl)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .priority(Priority.HIGH)
                    .error(R.drawable.video_default)
                    .into(storyCover);

            //加载背景并做高斯模糊处理
            Glide.with(parentActivity)
                    .load(mCoverUrl)
                    .bitmapTransform(new BlurTransformation(getActivity(), 20))
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .priority(Priority.HIGH)
                    .error(R.drawable.badilong_black)
                    .into(topBg);

            fTitle.setText(mAlbumTitle);
        }else{
            if(mLstType== MachineAlbumActivity.FAVORLIST){
                fTitle.setText(getString(R.string.my_favor));
                SpannableString spannableString = new SpannableString(getString(R.string.favor_no_content));
                CenteredImageSpan imgSpanLeft = new CenteredImageSpan(parentActivity, R.drawable.delete);
                spannableString.setSpan(imgSpanLeft, 2, 3, Spanned.SPAN_INCLUSIVE_EXCLUSIVE);
                noFavorText.setText(spannableString);
            }else{
                fTitle.setText(mAlbumTitle);
            }
            titleZone.setBackgroundColor(Color.parseColor("#ff495c"));
        }
        tryText.setText(Html.fromHtml(getString(R.string.video_tip_no_network)));
        isOnline = parentActivity.isOnline;
        if(isOnline){
            enterPlayer.setBackgroundResource(R.drawable.playing_big_animator);
            showPlayAnimation();
        }else{
            enterPlayer.setBackgroundResource(R.drawable.enter_player_offline);
        }
    }

    @OnClick(R.id.try_text)
    public void onTryAgain(){
        Utils.ensureVisbility(swipeRefreshLayout, View.VISIBLE);
        Utils.ensureVisbility(emptyView, View.GONE);
        if(mLstType == MachineAlbumActivity.ALBUMLIST || mLstType == MachineAlbumActivity.SONGLIST){
            getData(albumUnique, pageId);
        }else if(mLstType == MachineAlbumActivity.FAVORLIST){
            //获取收藏列表
            getFavorList("collect");
        }
    }

    @OnClick(R.id.enter_player)
    public void onEnterPlayer(){
        if(!isOnline){
            CameraToast.show(getActivity(), getString(R.string.story_machine_offline), Toast.LENGTH_SHORT);
        }else{
            Intent intent = new Intent(getActivity(), StoryPlayerActivity.class);
            startActivity(intent);
            getActivity().overridePendingTransition(R.anim.up_in, 0);
        }
    }

    @OnClick(R.id.btn_back)
    public void onGoBack(){
        getActivity().finish();
    }

    @Override
    public void click(final int pos) {
        if(isOnline){
            //TODO 点击进行播放(防止连续播放多首歌曲)
            long currentTime = System.currentTimeMillis();//当前时间
            if(preTime == 0){
                preTime = currentTime;
                handler.postDelayed(runnable = new MyRunnable(pos), 500);
            }else{
                if(currentTime - preTime <= 500){
                    handler.removeCallbacks(runnable);
                    handler.postDelayed(runnable = new MyRunnable(pos), 500);
                }else{
                    preTime = currentTime;
                    handler.postDelayed(runnable = new MyRunnable(pos), 500);
                }
            }
        }else{
            CameraToast.show(getActivity(), getString(R.string.story_machine_offline), Toast.LENGTH_SHORT);
        }

    }

    class MyRunnable implements Runnable{

        private int pos;

        MyRunnable(int p){
            pos = p;
        }

        @Override
        public void run() {
            CameraToast.show(parentActivity, getString(R.string.had_notify_machine), Toast.LENGTH_SHORT);
            sendPlayCmd(pos);
        }
    }

    private void sendPlayCmd(int pos){
        SongEntity song = adapter.getItem(pos);
        TaskExecutor.Execute(new SettingTask(getActivity(), PlayConfig.CommandType.PLAYCONTROL, JsonManager.getPlayControlContent("play", song, albumUnique, song.page), handler, PlayConfig.CmdFrom.LISTPAGE));
        //播放儿歌打点
        QHStatAgentHelper.doSongStoryStick(QHStatAgentHelper.getSongPlayMap(song.getTitle(), albumUnique));
    }

    //isFacor为本次的操作
    @Override
    public void doFavor(boolean isFavor, int pos) {
        if(isOnline){
            String operate = isFavor ? PlayConfig.FavorType.ADDSONG : PlayConfig.FavorType.DELSONG;
            SongEntity songEntity = dataList.get(pos);
            //收藏打点
            if(isFavor){
                QHStatAgentHelper.doSongStoryStick(QHStatAgentHelper.getSongFavorMap(songEntity.getTitle()));
            }
            TaskExecutor.Execute(new SettingTask(getActivity(), PlayConfig.CommandType.DOFAVOR, JsonManager.getStoryFavor(operate, songEntity, albumUnique, pageId), handler, PlayConfig.CmdFrom.LISTPAGE));
        }else{
            CameraToast.show(getActivity(), getString(R.string.story_machine_offline), Toast.LENGTH_SHORT);
            adapter.notifyDataSetChanged();
        }
    }

    private void getData(String unique, int page){
        GlobalManager.getInstance().getMachineManager().asyncGetAblum(unique, page, 0);
    }

    private void getFavorList(final String unique){
        //请求收藏列表
        Observable.create(new Observable.OnSubscribe<String>() {
            @Override
            public void call(Subscriber<? super String> subscriber) {
                String md5 = MachineSongWrapper.getInstance().getLisMd5(Preferences.getSelectedPad(), PlayConfig.ListType.FAVORLIST, "");
                subscriber.onNext(md5);
                subscriber.onCompleted();
            }
        })
        .subscribeOn(Schedulers.io())
        .compose(this.<String>bindToLifecycle())
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Action1<String>() {
            @Override
            public void call(String s) {
                doGetFavor(unique, s);
            }
        });
    }

    @Override
    public Object actionPerformed(int actionCode, Object... args) {
        switch(actionCode){

            //处理列表加载
            case Actions.GlobalActionCode.GET_SONGLIST_LIST:{
                int token = (int)args[1];
                if(token==0){
                    Utils.ensureVisbility(loading, View.GONE);
                    SongListResponse response = (SongListResponse)args[0];
                    if(response.errorCode==0){
                        Utils.ensureVisbility(swipeRefreshLayout, View.VISIBLE);
                        Utils.ensureVisbility(emptyView, View.GONE);
                        if(isFirst){
                            if(mLstType== MachineAlbumActivity.ALBUMLIST){
                                albumNum.setText(String.format(getString(R.string.story_num), response.total));
                            }else if(mLstType== MachineAlbumActivity.SONGLIST){
                                sognNum.setText(String.format(getString(R.string.story_num), response.total));
                            }
                            getPlayInfo();
                            getFavorList(albumUnique);
                            isFirst = false;
                        }
                        if(response.data!=null && response.data.size()>0){
                            for(SongEntity songEntity : response.data){
                                songEntity.page = pageId;
                                songEntity.type = mType;
                            }
                            dataList.addAll(response.data);
                            totalCount = response.total;

                            handlerDataChange(new Action1<CopyOnWriteArrayList<SongEntity>>() {
                                @Override
                                public void call(CopyOnWriteArrayList<SongEntity> songEntities) {
                                     adapter.setData(dataList);
                                      if(mPlaySingle!=null){
                                          adapter.setSelectSong(mPlaySingle.getMediaInfo().getUniqueid(), mPlaySingle.getMediaInfo().getType());
                                      }
                                }
                            });

                        }else if(dataList.size()==totalCount){
                            //已经加载完毕�?
                            //TODO 数据已经加载完毕,不需要做操作
                        }
                    }else{
                        getPlayInfo();
                        //TODO 获取列表失败
                        if(pageId>1){
                            pageId--;
                        }
                        if(dataList.size()==0){
                            Utils.ensureVisbility(swipeRefreshLayout, View.GONE);
                            Utils.ensureVisbility(emptyView, View.VISIBLE);
                        }else{
                            CameraToast.showToast(parentActivity, "数据加载失败，请检查网络!");
                        }
                    }
                }
                return true;
            }

            //播放单曲变了
            case Actions.MachinePlayInfo.NOTIFY_SINGLEPLAY_LIST:{
                handlePlaySingleChange((MachinePlaySingle)args[0],(String)args[1], (String)args[2]);
                return true;
            }

            //更新收藏列表
            case Actions.MachinePlayInfo.NOTIFY_LIST_UPDATE:{
                handlePlayListChange((int)args[0], (String)args[1], (String)args[2]);
                return true;
            }

            //固件端收藏列表有变化
            case Actions.MachinePlayInfo.NATIVE_NOTIFY_FAVOR_LIST_UPDATE: {
                if(dataList!=null){
                    if(mLstType == MachineAlbumActivity.FAVORLIST){
                        //收藏列表需要更新数�?
                        Observable.create(new Observable.OnSubscribe<ArrayList<MachineSong>>() {
                            @Override
                            public void call(Subscriber<? super ArrayList<MachineSong>> subscriber) {
                                subscriber.onNext(MachineSongWrapper.getInstance().getMachineSongList(Preferences.getSelectedPad(), PlayConfig.ListType.FAVORLIST, ""));
                                subscriber.onCompleted();
                            }
                        }).subscribeOn(Schedulers.io())
                                .compose(this.<ArrayList<MachineSong>>bindToLifecycle())
                                .observeOn(AndroidSchedulers.mainThread())
                                .subscribe(new Action1<ArrayList<MachineSong>>() {
                                    @Override
                                    public void call(ArrayList<MachineSong> machineSongs) {
                                        dataList.clear();
                                        if(machineSongs!=null && machineSongs.size()>0){
                                            Utils.ensureVisbility(noContentView, View.GONE);
                                            for(MachineSong machineSong : machineSongs){
                                                dataList.add(machineSong);
                                            }
                                            albumUnique = machineSongs.get(0).unique;
                                            sognNum.setText(String.format(getString(R.string.story_num), dataList.size()));

                                            handlerDataChange(new Action1<CopyOnWriteArrayList<SongEntity>>() {
                                                @Override
                                                public void call(CopyOnWriteArrayList<SongEntity> songEntities) {
                                                    adapter.setData(dataList);
                                                }
                                            });
                                        }else{
                                            Utils.ensureVisbility(noContentView, View.VISIBLE);
                                            sognNum.setText(String.format(getString(R.string.story_num), 0));
                                            adapter.setData(dataList);
                                        }
                                    }
                                });
                    }else{
                        //其他列表只需要更新状�?
                        setNotifyChange();
                    }
                }
                return true;
            }

            case Actions.MachinePlayInfo.NOTIFY_FAVOR_RESULT_UPDATE:{
                handlerFavorResult((FavorResultEntity)args[0], (String)args[1]);
                return true;
            }

            case Actions.MachinePlayInfo.NOTIFY_MACHINE_BUSY:{
                handleBusy((String)args[0], (String)args[1]);
                return true;
            }

            //故事机的在线状态发生变�?
            case Actions.MachinePlayInfo.NOTIFY_MACHINE_ONLINE_STATE_CHANGED:{

                isOnline = (int)args[0] == 1;
                if(isOnline){
                    enterPlayer.setBackgroundResource(R.drawable.playing_big_animator);
                    showPlayAnimation();
                }else{
                    enterPlayer.setBackgroundResource(R.drawable.enter_player_offline);
                    //如果列表有正在播放状态，需要清�?
                    adapter.setSelectSong("", mPlaySingle.getMediaInfo().getType());
                }
                return true;
            }

        }
        return null;
    }

    @Override
    public int getProperty() {
        return 0;
    }

    //点赞以后，收藏列表会推送更�?, 通知列表更新收藏状�?
    private void handlePlayListChange(int listType, String cmd, String from){
      if(listType == PlayConfig.ListType.FAVORLIST){
            //主动获取到列�?
          if(TextUtils.equals(from, PlayConfig.CmdFrom.LISTPAGE)){
              if(mLstType == MachineAlbumActivity.FAVORLIST){
                  Utils.ensureVisbility(swipeRefreshLayout, View.VISIBLE);
                  Utils.ensureVisbility(emptyView, View.GONE);
                  dataList.clear();
                  ArrayList<MachineSong> tmplist = MachineSongWrapper.getInstance().getMachineSongList(Preferences.getSelectedPad(), PlayConfig.ListType.FAVORLIST, "");
                  if(tmplist!=null && tmplist.size()>0){
                      Utils.ensureVisbility(noContentView, View.GONE);
                      for(MachineSong machineSong : tmplist){
                          dataList.add(machineSong);
                      }
                      albumUnique = tmplist.get(0).unique;
                      sognNum.setText(String.format(getString(R.string.story_num), dataList.size()));
                      handlerDataChange(new Action1<CopyOnWriteArrayList<SongEntity>>() {
                          @Override
                          public void call(CopyOnWriteArrayList<SongEntity> songEntities) {
                              adapter.setData(dataList);
                          }
                      });
                  } else{
                      //TODO 展示空页面，提示暂无收藏内容
                      sognNum.setText(String.format(getString(R.string.story_num), 0));
                      Utils.ensureVisbility(noContentView, View.VISIBLE);
                  }
              }else{
                  setNotifyChange();
              }
          }else{
              setNotifyChange();
          }
        }
    }

    //播放变了
    private void handlePlaySingleChange(MachinePlaySingle playSingle, String cmd, String from){

        if(TextUtils.equals(cmd, PlayConfig.CommandType.PLAYCONTROL) || (TextUtils.equals(cmd, PlayConfig.CommandType.GETPLAYSTATUS) && TextUtils.equals(from, PlayConfig.CmdFrom.LISTPAGE))){
            CLog.e("zt","收到播放变化的push");
            isOnline = true;
            enterPlayer.setBackgroundResource(R.drawable.playing_big_animator);
            showPlayAnimation();

            //判断是否属于该列表，如果播放的不是这个列表，那么就需要取消已有播�?
            boolean isSmae =false;
            mPlaySingle = playSingle;
            //同一个专辑和同一个分�?
            if(mLstType == MachineAlbumActivity.FAVORLIST){
                if(TextUtils.equals(mPlaySingle.getUnique(), PlayConfig.FAVORUNIQUE)){
                    isSmae = true;
                }
            }else{
                if(mPlaySingle.getMediaInfo().getType() == dataList.get(0).getType() && TextUtils.equals(albumUnique, mPlaySingle.getUnique())){
                    isSmae = true;
                }
            }

            if(isSmae){
                adapter.setSelectSong(mPlaySingle.getMediaInfo().getUniqueid(), mPlaySingle.getMediaInfo().getType());
            }else{
                adapter.setSelectSong("", mPlaySingle.getMediaInfo().getType());
            }
        }

    }

    //处理收藏是否成功(resultCode: 0-成功�?1-达到收藏上限，添加失败，2-删除失败，没有这条歌�?)
    private void handlerFavorResult(FavorResultEntity favorResult, String from){
        if(TextUtils.equals(from, PlayConfig.CmdFrom.LISTPAGE)){
            switch(favorResult.resultCode){
                case 0:
                    //无需处理
                    break;

                case 1://达到收藏上限，添加失�?
                    //TODO 需要作出提�?
                    CameraToast.show(parentActivity, getString(R.string.favor_over_failed), Toast.LENGTH_SHORT);
                    break;

                case 2://删除失败，没有这条收�?
                    //TODO 需要作出提�?
                    CameraToast.show(parentActivity, getString(R.string.favor_del_failed), Toast.LENGTH_SHORT);
                    break;

                case 3://添加失败，歌曲已经存�?
                    //TODO 需要作出提�?
                    CameraToast.show(parentActivity, getString(R.string.favor_again_failed), Toast.LENGTH_SHORT);
                    break;
            }
        }
    }

    //处理故事忙，只有播放控制才有
    private void handleBusy(String cmd, String from){
        //TODO 没在播放，忙着�?
        if(TextUtils.equals(from, PlayConfig.CmdFrom.LISTPAGE)){
            if(TextUtils.equals(cmd, PlayConfig.CommandType.GETPLAYSTATUS)){
                //TODO 获取播放状�?,发现故事机在�?
            }else if(TextUtils.equals(cmd, PlayConfig.CommandType.PLAYCONTROL)){
                //TODO 在播放页面点击播放，发现故事机正忙着，做出提�?
                CameraToast.show(getString(R.string.machine_is_busy), Toast.LENGTH_SHORT);
            }

        }
    }

    //发送获取下播放信息的指�?
    private void getPlayInfo(){
        TaskExecutor.Execute(new SettingTask(getActivity(), PlayConfig.CommandType.GETPLAYSTATUS, JsonManager.getPlayStatusContent(), handler, PlayConfig.CmdFrom.LISTPAGE));
    }

    //发送获取收藏列表的指令
    private void doGetFavor(String unique, String md5){
        TaskExecutor.Execute(new SettingTask(getActivity(), PlayConfig.CommandType.GETPLAYLIST, JsonManager.getPlayListContent(PlayConfig.ListType.FAVORLIST, unique, md5), handler, PlayConfig.CmdFrom.LISTPAGE));
    }

    //指令失败异常处理
    static class MyHandler extends Handler{

        WeakReference<SongListFragment> songListFragmentWeakReference;

        MyHandler(SongListFragment songListFragment) {
            songListFragmentWeakReference = new WeakReference<>(songListFragment);
        }

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if(songListFragmentWeakReference.get()!=null){
                songListFragmentWeakReference.get().handlerCmdExcept((String)msg.obj, msg.arg1);
            }
        }
    }

    private void handlerCmdExcept(String cmd, int errorCode){

        if(TextUtils.equals(cmd, PlayConfig.CommandType.GETPLAYSTATUS)){
            //获取播放信息失败
        }else if(TextUtils.equals(cmd, PlayConfig.CommandType.GETPLAYLIST)){

            if(mLstType == MachineAlbumActivity.FAVORLIST){
                //TODO 从固件端拉取收藏列表成功,加载数据库中的收藏列表，如果数据库为空，则显示收藏列表为�?
                dataList.clear();
                Observable.create(new Observable.OnSubscribe<ArrayList<MachineSong>>() {
                    @Override
                    public void call(Subscriber<? super ArrayList<MachineSong>> subscriber) {
                        subscriber.onNext(MachineSongWrapper.getInstance().getMachineSongList(Preferences.getSelectedPad(), PlayConfig.ListType.FAVORLIST, ""));
                        subscriber.onCompleted();
                    }
                }).subscribeOn(Schedulers.io())
                  .compose(this.<ArrayList<MachineSong>>bindToLifecycle())
                  .observeOn(AndroidSchedulers.mainThread())
                  .subscribe(new Action1<ArrayList<MachineSong>>() {
                      @Override
                      public void call(ArrayList<MachineSong> machineSongs) {
                          if(machineSongs!=null && machineSongs.size()>0) {
                              Utils.ensureVisbility(swipeRefreshLayout, View.VISIBLE);
                              Utils.ensureVisbility(emptyView, View.GONE);
                              for (MachineSong machineSong : machineSongs) {
                                  dataList.add(machineSong);
                              }
                              albumUnique = machineSongs.get(0).unique;
                              sognNum.setText(String.format(getString(R.string.story_num), dataList.size()));
                              handlerDataChange(new Action1<CopyOnWriteArrayList<SongEntity>>() {
                                  @Override
                                  public void call(CopyOnWriteArrayList<SongEntity> songEntities) {
                                      adapter.setData(dataList);
                                  }
                              });
                          }else{
                              Utils.ensureVisbility(swipeRefreshLayout, View.GONE);
                              Utils.ensureVisbility(emptyView, View.VISIBLE);
                          }
                      }
                  });
            }else{
                //TODO 如果是专辑列表和儿歌列表获取手暗藏收藏列表失败，则不�?
            }
        }else if(TextUtils.equals(cmd, PlayConfig.CommandType.PLAYCONTROL)){
            //播放儿歌失败
            if(this.isAdded()){
                CameraToast.show(parentActivity, getString(R.string.play_failed_tip), Toast.LENGTH_SHORT);
            }
        }else if(TextUtils.equals(cmd, PlayConfig.CommandType.DOFAVOR)){
            setNotifyChange();
            //收藏失败
            if(this.isAdded()){
                CameraToast.show(parentActivity, getString(R.string.play_failed_tip), Toast.LENGTH_SHORT);
            }
        }
    }

    //实现播放动画
    private void showPlayAnimation(){
        final AnimationDrawable animationDrawable = (AnimationDrawable)enterPlayer.getBackground();
        if(animationDrawable!=null && !animationDrawable.isRunning()){
            handler.post(new Runnable() {
                @Override
                public void run() {
                    animationDrawable.start();
                }
            });
        }
    }

    private void setNotifyChange(){
        handlerDataChange(new Action1<CopyOnWriteArrayList<SongEntity>>() {
            @Override
            public void call(CopyOnWriteArrayList<SongEntity> songEntities) {
                adapter.notifyDataSetChanged();
            }
        });
    }

    //统一进行收藏状态处�?
    private void handlerDataChange(Action1<CopyOnWriteArrayList<SongEntity>> action){
        Observable.just(dataList)
                .observeOn(Schedulers.io())
                .compose(this.<CopyOnWriteArrayList<SongEntity>>bindToLifecycle())
                .map(new Func1<CopyOnWriteArrayList<SongEntity>, CopyOnWriteArrayList<SongEntity>>() {
                    @Override
                    public CopyOnWriteArrayList<SongEntity> call(CopyOnWriteArrayList<SongEntity> songEntities) {
                        CopyOnWriteArrayList<SongEntity> tmp = songEntities;
                        for (SongEntity songEntity : tmp) {
                            songEntity.isFavor = MachineSongWrapper.getInstance().isSongFavor(Preferences.getSelectedPad(), songEntity.getUniqueid());
                        }
                        return dataList;
                    }
                })
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(action);
    }
}
