
package com.qihoo360.homecamera.mobile.http.builder;

import com.qihoo360.homecamera.machine.config.MachineDebugConfig;
import com.qihoo360.homecamera.mobile.BuildConfig;
import com.qihoo360.homecamera.mobile.config.DefaultClientConfig;
import com.qihoo360.homecamera.mobile.http.request.RequestCall;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.CLog;

import java.net.URLEncoder;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

public abstract class OkHttpRequestBuilder {
    protected String url;
    protected Object tag;
    protected Map<String, String> headers;
    protected Map<String, String> params;
    protected boolean cookie = true;
    protected boolean debug = true;
    protected boolean https = true;
    protected boolean isStatic = false;

    public abstract OkHttpRequestBuilder url(String url);

    public abstract OkHttpRequestBuilder isStatic(boolean isStatic);


    public OkHttpRequestBuilder tag(Object tag) {
        if (tag != null) {
            this.tag = tag;
        } else {
            this.tag = this.url;
        }
        return this;
    }

    public OkHttpRequestBuilder params(Map<String, String> params) {
        if (params != null) {
            this.params = params;
        } else {
            this.params = new HashMap<String, String>();
        }
        if (!this.params.containsKey("taskid")) {
            String taskid = UUID.randomUUID().toString();
            this.params.put("taskid", taskid);
        }
        if (!this.params.containsKey("from")) {
            this.params.put("from", DefaultClientConfig.FROM);
        }
        if(MachineDebugConfig.DEBUG) {
            if (!this.params.containsKey("qid")) {
                this.params.put("qid", AccUtil.getInstance().getQID());
            }
        }
        this.params.put("ver", BuildConfig.VERSION_NAME);
        return this;
    }

    public OkHttpRequestBuilder withOutCookie() {
        this.cookie = false;
        return this;
    }

    public abstract OkHttpRequestBuilder addParams(String key, String val);

    public OkHttpRequestBuilder headers(Map<String, String> headers) {
        if (headers != null) {
            this.headers = headers;
        } else {
            this.headers = new LinkedHashMap<String, String>();
        }
        String host = getHost();
        if (BuildConfig.isDebug && debug) {
            if (!this.headers.containsKey("host")) {
                this.headers.put("host", host);
            }
        }
        if (cookie) {
            StringBuffer sb = new StringBuffer();
            sb.append("qid=").append(AccUtil.getInstance().getQID()).append(";");
            sb.append("q=").append(URLEncoder.encode(AccUtil.getInstance().getQ())).append(";");
            sb.append("t=").append(URLEncoder.encode(AccUtil.getInstance().getT())).append(";");
            String sid = getSessionId();
            sb.append("sid=").append(sid).append(";");
            this.headers.put("cookie", sb.toString());
            CLog.d("q:"+AccUtil.getInstance().getQ());
            CLog.d("t:" +AccUtil.getInstance().getT());
        }
        return this;
    }

    protected String getSessionId() {
        return AccUtil.getInstance().getSessionId();
    }

    protected String getHost() {
        return DefaultClientConfig.HOST;
    }

    public abstract OkHttpRequestBuilder addHeader(String key, String val);

    public abstract RequestCall build();

    public abstract OkHttpRequestBuilder isDebug(boolean debug);

    public abstract OkHttpRequestBuilder isHttps(boolean https);

    public abstract OkHttpRequestBuilder isLogUpload(String up);

}
