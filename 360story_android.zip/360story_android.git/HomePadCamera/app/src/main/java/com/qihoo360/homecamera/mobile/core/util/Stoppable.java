
package com.qihoo360.homecamera.mobile.core.util;

public interface Stoppable {

    /**
     * Requested by parent to terminate immediately. 
     * After this method call, should terminate all network, file, database operation.
     * And stop any thing else that may use the phone's resources. 
     * 
     * Do not set anything to null here. This will be done in {{@link #destroy()}
     * 
     */
    void stopNow();

    boolean isStopped();

    /**
     * Last method called in the object, release/close all the resources. Set every this to null if needed.
     */
    void destroyNow();
}
