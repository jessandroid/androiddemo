
package com.qihoo360.homecamera.mobile.core.manager;

public interface Actions {
    int SECTION_MASK = 0xFFFF0000;
    Object ACTION_NOT_PROCESSED = new Object();

    /**
     * Returning this object from action listener call, the action event will not be propagated any further.
     */
    Object ACTION_STOP_PROPAGATION = new Object();

    interface Activity {
        int SECTION_BASE = 1004 << 16;
        int BACK_PRESSED = SECTION_BASE | 1;
        int SEARCH_MODE_EXIT = SECTION_BASE | 2;
        int SEARCH_REQUESTED = SECTION_BASE | 3;
        int SEARCH_MODE_ENTER = SECTION_BASE | 4;
        int SELECT_SIZE_CHANGE = SECTION_BASE | 5;
        int SELECT_SIZE_HIDE = SECTION_BASE | 6;
        int SCREEN_HEIGHT_CHANGED = SECTION_BASE | 7;
        int SHOW_MIC_ERROR_TOAST = SECTION_BASE | 8;
    }

    interface Misc {
        int SECTION_BASE = 1007 << 16;
        int MANAGED_EXCEPTION = SECTION_BASE | 1;
        int CLOUD_ALBUM = SECTION_BASE | 2;
        int GALLERY_TAPPED = SECTION_BASE | 3;
        int GALLERY_THUMB_LOADED = SECTION_BASE | 4;
        int SERVER_MAINTENACE = SECTION_BASE | 5;
        int SHOW_UPDATE_DIALOG = SECTION_BASE | 6;
        int SHOW_FIRMWARE_UPDATE_DIALOG = SECTION_BASE | 7;
        int SHOW_LOADING_BOTTOM_BAR = SECTION_BASE | 8;
        int HIDE_LOADING_BOTTOM_BAR = SECTION_BASE | 9;
        int NEED_SHOW_NOT_ENOUGH_SPACE_SIZE = SECTION_BASE | 10;
        int NEED_SHOW_CHAT_FRAG_GUIDE = SECTION_BASE | 11;
    }

    interface Camera {
        int SECTION_BASE = 1006 << 16;
        int CAMERA_LIST_ACTION = SECTION_BASE | 1;
        int CAMERA_LIST_NEED_SHOW_PURCHASE = SECTION_BASE | 2;
        int CAMERA_LIST_ACTION_FAIL = SECTION_BASE | 3;
        int BIND_DEVICE_SUCCESS = SECTION_BASE | 4;
        int BIND_DEVICE_FAIL = SECTION_BASE | 5;
        int UN_BIND_DEVICE_SUCCESS = SECTION_BASE | 6;
        int UN_BIND_DEVICE_FAIL = SECTION_BASE | 7;
        int MODIFY_TITLE_HEAD_SUCCESS = SECTION_BASE | 8;
        int MODIFY_TITLE_HEAD_FAIL = SECTION_BASE | 9;
        int CLOSED_CAMERA_PREVIEW = SECTION_BASE | 10;
        int BIND_DEVICE_ALREADY_BIND = SECTION_BASE | 11;
        int SELECTED_CAMERA = SECTION_BASE | 12;
        int LOAD_OK = SECTION_BASE | 13;
        int LOAD_OK_EMPTY = SECTION_BASE | 14;
        int SET_VIEW2_CLICKABLE = SECTION_BASE | 15;
        int LOAD_PAD_BY_SN = SECTION_BASE | 16;
        int DELTET_SN = SECTION_BASE | 17;
        int REFRESH_STATE = SECTION_BASE | 18;
        int DEVICE_LIST_EMPTY = SECTION_BASE | 19;
        int ALL_DEVICE_LOADED = SECTION_BASE | 20;
        int SWITCH_TO_STORY_TAB = SECTION_BASE | 21;
        int LOAD_CAMERA_LIST_DO_ACTION = SECTION_BASE | 22;
        int SELECTED_CAMERA_M = SECTION_BASE | 23;
        int UPDATE_FAMILY_GROUP_DATA = SECTION_BASE | 24;
        int CHANGE_TO_STORY_MACHINE = SECTION_BASE | 25;
        int CHANGE_TO_OTHER_DEVICE = SECTION_BASE | 26;
    }

    interface Local {
        int SECTION_BASE = 1010 << 16;
        int IMG_QUEUE_LOADED = SECTION_BASE | 1;
        int UPLOAD_ALL_ALBUM_SHOW = SECTION_BASE | 2;
        int UPLOAD_ALBUM_ENTER = SECTION_BASE | 3;
        int UPLOAD_ALBUM_ERROR = SECTION_BASE | 4;
        int UPLOAD_ALBUM_AVATAR_CHOOSE = SECTION_BASE | 5;
    }

    interface Share {
        int SECTION_BASE = 1011 << 16;
        int SHARE_SHARE_SUCCESS = SECTION_BASE | 1;
        int SHARE_SHARE_FAIL = SECTION_BASE | 2;
        int SHARE_ACCEPT_SUCCESS = SECTION_BASE | 3;
        int SHARE_ACCEPT_FAIL = SECTION_BASE | 4;
        int SHARE_GET_SHARING_LIST_SUCCESS = SECTION_BASE | 5;
        int SHARE_GET_SHARING_LIST_FAIL = SECTION_BASE | 6;
        int SHARE_GET_SHARING_INFO_SUCCESS = SECTION_BASE | 7;
        int SHARE_GET_SHARING_INFO_FAIL = SECTION_BASE | 8;
        int SHARE_CANCEL_FAIL = SECTION_BASE | 9;
        int SHARE_CANCEL_SUCCESS = SECTION_BASE | 10;
        int SHARE_RESPONSE_FAIL = SECTION_BASE | 11;
        int SHARE_RESPONSE_SUCCESS = SECTION_BASE | 12;
        int SHARE_GET_LIST_FAIL = SECTION_BASE | 13;
        int SHARE_GET_LIST_SUCCESS = SECTION_BASE | 14;
        int SHARE_CANCEL_SHARING_SUCCESS = SECTION_BASE | 15;
        int SHARE_CANCEL_SHARING_FAIL = SECTION_BASE | 16;
        int SHARE_FRIEND_SUCCESS = SECTION_BASE | 17;
        int SHARE_FRIEND_FAIL = SECTION_BASE | 18;
        int SHARE_FRIEND_RESPONSE_SUCCESS = SECTION_BASE | 19;
        int SHARE_FRIEND_RESPONSE_FAIL = SECTION_BASE | 20;
        int SHARE_FRIEND_CANCEL_SUCCESS = SECTION_BASE | 21;
        int SHARE_FRIEND_CANCEL_FAIL = SECTION_BASE | 22;
        int SHARE_SET_REMARK_SUCCESS = SECTION_BASE | 23;
        int SHARE_SET_REMARK_FAIL = SECTION_BASE | 24;
        int SHARE_SHOW_SHARE_DIALOG = SECTION_BASE | 25;
        int NEW_DEVICE_ARRIVED = SECTION_BASE | 26;
    }

    interface Album {
        int SECTION_BASE = 1012 << 16;
        public final static int APP_ALBUM_LIST_SUCCESS = SECTION_BASE | 1;
        public final static int APP_ALBUM_LIST_FAIL = SECTION_BASE | 2;
        public final static int ONE_DAY_ALBUM_LIST_SUCCESS = SECTION_BASE | 3;
        public final static int ONE_DAY_ALBUM_LIST_FAIL = SECTION_BASE | 4;
        public final static int DELETE_ALBUM_FILE_LIST_SUCCESS = SECTION_BASE | 5;
        public final static int DELETE_ALBUM_FILE_LIST_FAIL = SECTION_BASE | 6;
        public final static int DELETE_ALBUM_ONE_FILE_SUCCESS = SECTION_BASE | 7;
        public final static int DELETE_ALBUM_ONE_FILE_FAIL = SECTION_BASE | 8;
        public final static int GET_ALBUM_NEWEST_SUCCESS = SECTION_BASE | 9;
        public final static int GET_ALBUM_NEWEST_FAIL = SECTION_BASE | 10;
    }

    interface Call {
        int SECTION_BASE = 1013 << 16;
        int SHOW_TOAST_WHEN_BE_HANGUP = SECTION_BASE | 1;
    }

    interface SearchWord {
        int SECTION_BASE = 1014 << 16;

        public final static int SEARCH_WORD_KEY_SUCCESS = SECTION_BASE | 1;
        public final static int SEARCH_WORD_KEY_FAIL = SECTION_BASE | 2;
        public final static int SEARCH_WORD_SUCCESS = SECTION_BASE | 3;
        public final static int SEARCH_WORD_FAIL = SECTION_BASE | 4;

    }

    interface Story {
        int SECTION_BASE = 1015 << 16;

        public final static int GET_STORY_SUCCESS = SECTION_BASE | 1;
        public final static int GET_STORY_FAIL = SECTION_BASE | 2;
        public final static int VOICE_IDIOM = SECTION_BASE | 3;
        public final static int VOICE_ALLEGORY = SECTION_BASE | 4;
        public final static int VOICE_FAIRYTALE = SECTION_BASE | 5;

        public final static int CHOOSE_MODEL = SECTION_BASE | 6;
        public final static int UNCHOOSE_MODEL = SECTION_BASE | 7;
        public final static int UPLOAD_STORY = SECTION_BASE | 8;

    }

    public static interface AlbumShare {
        public final static int SECTION_BASE = 1016 << 16;
        public final static int DOWN_LOAD_IMAGE_2_SHARE = SECTION_BASE | 1;
    }

    public static interface UserInfo {
        public final static int SECTION_BASE = 1017 << 16;
        public final static int APP_GET_INFO_SUCCESS = SECTION_BASE | 1;
        public final static int APP_GET_INFO_FAIL = SECTION_BASE | 2;
        public final static int APP_UPDATE_INFO_SUCCESS = SECTION_BASE | 3;
        public final static int APP_UPDATE_INFO_FAIL = SECTION_BASE | 4;
        public final static int LOGOUT_SUCC = SECTION_BASE | 5;
        public final static int SHARE_SET_RELATION_SUCCESS = SECTION_BASE | 6;
        public final static int SHARE_SET_RELATION_FAIL = SECTION_BASE | 7;
        public final static int SET_USER_SETTING_SUCCESS = SECTION_BASE | 8;
        public final static int SET_USER_SETTING_FAIL = SECTION_BASE | 9;
        public final static int GET_USER_SETTING_SUCCESS = SECTION_BASE | 10;
        public final static int GET_USER_SETTING_FAIL = SECTION_BASE | 11;
        public final static int GET_SPACE_INFO_SUCCESS = SECTION_BASE | 12;
        public final static int GET_SPACE_INFO_FAIL = SECTION_BASE | 13;
        public final static int CLEAR_CACHE_SUCCESS = SECTION_BASE | 14;
        public final static int CLEAR_CACHE_FAIL = SECTION_BASE | 15;
        public final static int CALCULATE_CACHE_SUCCESS = SECTION_BASE | 16;
        public final static int LOAD_AVATAR_CACHE_FILE = SECTION_BASE | 17;
    }

    interface Push {
        public final static int SECTION_BASE = 1018 << 16;
        public final static int MASTER_REFUES = SECTION_BASE | 1;
    }

    interface PadSetting {
        public final static int SECTION_BASE = 1019 << 16;
        public final static int GET_SETTING_SUCCESS = SECTION_BASE | 1;
        public final static int GET_SETTING_FAIL = SECTION_BASE | 2;
        public final static int SET_SETTING_SUCCESS = SECTION_BASE | 3;
        public final static int SET_SETTING_FAIL = SECTION_BASE | 4;
        public final static int SET_ACL_SUCCESS = SECTION_BASE | 5;
        public final static int SET_ACL_FAIL = SECTION_BASE | 6;
        public final static int SET_SETTING_PASSWORD_SUCCESS = SECTION_BASE | 7;
        public final static int SET_SETTING_PASSWORD_FAIL = SECTION_BASE | 8;
        public final static int GET_SETTING_NULL = SECTION_BASE | 9;
    }

    interface CommandMessage {
        public final static int SECTION_BASE = 1020 << 16;
        public final static int GET_LIST_SUCCESS = SECTION_BASE | 1;
        public final static int GET_LIST_FAIL = SECTION_BASE | 2;
        public final static int SET_INSTANCE_SUCCESS = SECTION_BASE | 3;
        public final static int SET_INSTANCE_FAIL = SECTION_BASE | 4;
        public final static int GET_INSTANCE_SUCCESS = SECTION_BASE | 5;
        public final static int GET_INSTANCE_FAIL = SECTION_BASE | 6;
        public final static int SEND_COMMAND = SECTION_BASE | 7;
        public final static int UPDATE_COMMAND = SECTION_BASE | 8;
    }

    final class MediaLibrary {
        public final static int SECTION_BASE = 2300 << 16;

        public final static int PHOTO_ALBUMS_LOADED = SECTION_BASE | 1;
        public final static int VIDEOS_LOADED = SECTION_BASE | 2;
        public final static int COMBINED_DATA_LOADED = SECTION_BASE | 3;
        public final static int FILES_LOADED_OVER = SECTION_BASE | 4;
        public final static int PHOTO_SINGLE_LOADED = SECTION_BASE | 5;
        public final static int PHOTO_DATA_LOADED = SECTION_BASE | 6;
    }

    interface UploadToAlbum {
        int SECTION_BASE = 4100 << 16;
        int CREATE_ALBUM = SECTION_BASE | 1;
        int CHOOSE_ALBUM = SECTION_BASE | 2;
    }

    interface FileListMenu {
        int SECTION_BASE = 6200 << 16;

        int EXIT_MULITI = SECTION_BASE | 1;
        int SELECT_ALL = SECTION_BASE | 2;
        int UNSELECT_ALL = SECTION_BASE | 3;

    }

    interface Application {
        int SECTION_BASE = 6200 << 17;

        int SESSION_ERROR = SECTION_BASE | 1;
        int SELECT_ALL = SECTION_BASE | 2;
        int UNSELECT_ALL = SECTION_BASE | 3;

    }

    public static interface Common {
        public static final int SECTION_BASE = 6200 << 18;
        public static final int UPDATE = SECTION_BASE | 10;
        public static final int DOWNLOAD_SUCC = SECTION_BASE | 11;
        public static final int DOWNLOAD_NOW = SECTION_BASE | 12;
        public static final int IS_THE_NEWEST = SECTION_BASE | 13;
        public static final int GET_UPDATE_FAILED = SECTION_BASE | 14;
        public static final int IGNOREDVERSION = SECTION_BASE | 15;
        public static final int FORCE_UPDATE = SECTION_BASE | 16;
        public static final int EXIT = SECTION_BASE | 17;
        public static final int CHANGE_TOPBAR_TITLE = SECTION_BASE | 18;
        public static final int BIND_SUCCESS_UPDATE = SECTION_BASE | 19;
        public static final int GET_FM_UPGRADE_INFO = SECTION_BASE | 20;
        public static final int UNBIND_SUCCESS_UPDATE = SECTION_BASE | 21;
        public static final int NOTIFY_FM_UPDATE = SECTION_BASE | 22;
        public static final int HAS_UNBINDED_UPDATE = SECTION_BASE | 23;//被解绑
        public static final int HAS_UNBINDED_UPDATE_VIDEOPLAY = SECTION_BASE | 24;//被解绑
    }

    public static interface ChangePwd {
        public final static int SECTION_BASE = 8100 << 16;
        public final static int GET_RD_SUC = SECTION_BASE | 1;
        public final static int GET_RD_FAIL = SECTION_BASE | 2;
        public final static int CHANGE_PWD_SUC = SECTION_BASE | 3;
    }

    public static interface DownloadVideo {
        public final static int SECTION_BASE = 9601 << 16;
        public final static int CREATE_JOB_DONE = SECTION_BASE | 1;
        public final static int PROGRESS_HAS_CHANGED = SECTION_BASE | 2;
        public final static int FINISH_JOB_DONE = SECTION_BASE | 3;
        public final static int JOB_FAIL = SECTION_BASE | 4;
        public final static int JOB_START = SECTION_BASE | 5;
        public final static int LOAD_LOACL_PATH_DONE = SECTION_BASE | 6;
        public final static int COPY_DOWNLOAD_DONE = SECTION_BASE | 99;
    }

    // 故事机 begin
    public static interface Sound {
        public final static int SECTION_BASE = 8000 << 16;
        public final static int SOUND_LIST = SECTION_BASE | 1;
        public final static int SOUND_PUSH = SECTION_BASE | 2;
        public final static int SOUND_REFRESH = SECTION_BASE | 3;
        public final static int SOUND_ERROR = SECTION_BASE | 4;
    }

    public static interface GlobalActionCode {
        public final static int SECTION_BASE = 9401 << 16;
        public final static int WAP_NET_ERROR = SECTION_BASE | 1;
        public final static int DISABLE_RE_SLIDE = SECTION_BASE | 2;
        public final static int RESUME_RE_SLIDE = SECTION_BASE | 3;
        public final static int RESUME_OPEN_RE_SLIDE = SECTION_BASE | 4;
        public final static int RESUME_CLOSE_RE_SLIDE = SECTION_BASE | 5;
        public final static int GET_SONGLIST_LIST = SECTION_BASE | 6;
        public final static int GET_BIND_BANNER_LIST = SECTION_BASE | 7;
        public final static int SETTING_MACHINE_VIDEO_CAPTRUE = SECTION_BASE | 8;
        public final static int GETTING_MACHINE_VIDEO_CAPTRUE = SECTION_BASE | 9;
    }

    interface Play {
        int SECTION_BASE = 9600 << 16;
        int UPDATE_PLAY_STATUS = SECTION_BASE | 1;
        int UPDATE_CMD_RESULT = SECTION_BASE | 2;
        int UPDATE_SNAP_SHOT = SECTION_BASE | 3;
        int UPDATE_RESO_MODE = SECTION_BASE | 4;
        int UPDATE_MUTE_STATUS = SECTION_BASE | 5;
        int UPDATE_STREAM_FLOW = SECTION_BASE | 6;
        int UPDATE_PLAY_TIME = SECTION_BASE | 7;
        int UPDATE_RECORD_STATUS = SECTION_BASE | 8;
        int UPDATE_RECORD_TIME = SECTION_BASE | 9;
        int UPDATE_TALK_VOLUME = SECTION_BASE | 10;
        int NOTIFY_STREAM_BRAKE = SECTION_BASE | 11;
        int UPDATE_PLAYBACK_TIME = SECTION_BASE | 12;
        int UPDATE_CLOUD_STATUS = SECTION_BASE | 13;
        int STOP_DRAW_RESULT = SECTION_BASE | 14;
        int UPDATE_DOWNLOAD_PROGRESS = SECTION_BASE | 15;
        int CONNECT_ENCRYPTION = SECTION_BASE | 16;
        int NOTIFY_TALK_NO_VOICE = SECTION_BASE | 17;
        int NOTIFY_VIDEO_TIMEOUT = SECTION_BASE | 18;
    }

    public static interface Record {
        public final static int SECTION_BASE = 9004 << 16;
        public final static int UPDATE_RECORDS = SECTION_BASE | 1;
        public final static int UPDATE_SET_RECORD_TIME_RESULT = SECTION_BASE | 2;
        public final static int UPDATE_EVENT_TIME_AREA = SECTION_BASE | 3;
    }

    public static interface MachinePlayInfo {
        public final static int SECTION_BASE = 9005 << 16;
        public final static int NOTIFY_PLAYLIST_CHANGE = SECTION_BASE | 1;
        public final static int NOTIFY_SINGLEPLAY_LIST = SECTION_BASE | 2;
        public final static int NOTIFY_LIST_UPDATE = SECTION_BASE | 3;
        public final static int NOTIFY_MACHINE_BUSY = SECTION_BASE | 4;
        public final static int NOTIFY_LOCAL_SETTING_UPDATE = SECTION_BASE | 5;
        public final static int NOTIFY_LIST_IS_NEWEST = SECTION_BASE | 6;
        public final static int NATIVE_NOTIFY_FAVOR_LIST_UPDATE = SECTION_BASE | 7;
        public final static int NOTIFY_FAVOR_RESULT_UPDATE = SECTION_BASE | 8;
        public final static int NATIVE_NOTIFY_INSERT_LIST_UPDATE = SECTION_BASE | 9;
        public final static int NOTIFY_MACHINE_IS_FREE = SECTION_BASE | 10;
        public final static int NOTIFY_MACHINE_DEVICE_INFO = SECTION_BASE | 11;
        public final static int NOTIFY_PLAY_LIST_EMPTY = SECTION_BASE | 12;
        public final static int NOTIFY_GET_UPGRADE_RECEIPT = SECTION_BASE | 13;
        public final static int NOTIFY_MACHINE_ONLINE_STATE_CHANGED = SECTION_BASE | 14;
        public final static int NOTIFY_CHAT_MESSAGE_REACHED = SECTION_BASE | 15;
        public final static int NOTIFY_FAMILY_GROUP_MESSAGE_REACHED = SECTION_BASE | 16;
    }

    public static interface CameraSetting {
        public final static int SECTION_BASE = 7700 << 16;
        public final static int ERROR_RESULT = SECTION_BASE | 1;
        public final static int CAMERA_INFO = SECTION_BASE | 2;
        public final static int SET_RESULT = SECTION_BASE | 3;
        public final static int FIND_FIRMWARE_RESULT = SECTION_BASE | 4;
        public final static int SEND_UPGRADE_FIRMWARE_RESULT = SECTION_BASE | 5;
        public final static int GET_SETTING_FROM_DB_RESULT = SECTION_BASE | 6;
        public final static int CAMERA_CLOUD_SETTING_INFO = SECTION_BASE | 7;
        public final static int CAMERA_CLOUD_RECORD_SETTING = SECTION_BASE | 8;
        public final static int UNBIND_CAMERA_RESULT = SECTION_BASE | 9;
        public final static int UNBIND_CAMERA_RELOAD = SECTION_BASE | 10;
        public final static int PLAYER_MUTE = SECTION_BASE | 11;
        public final static int PLAYER_UN_MUTE = SECTION_BASE | 12;
        public final static int CAMERA_SWITCH_SETTING = SECTION_BASE | 13;
        public final static int CHANGE_MODE = SECTION_BASE | 14;
        public final static int CHANGE_ALARM_TIME = SECTION_BASE | 15;
    }

    // 故事机 end
}
