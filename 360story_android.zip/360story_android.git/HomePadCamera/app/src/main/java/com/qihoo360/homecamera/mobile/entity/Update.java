package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/4/18
 * Time: 18:52
 * To change this template use File | Settings | File Templates.
 */
public class Update extends Head implements Parcelable {
    /**
     * 强制升级
     */
    public static final int FORCE_TYPE_FORCE = 0;
    /**
     * 正常
     */
    public static final int FORCE_TYPE_NORMAL = 1;
    /**
     * 静默升级
     */
    public static final int FORCE_TYPE_SLIENCE = 2;
    /**
     * 弹窗升级
     */
    public static final int FORCE_TYPE_POPUP = 3;

    public UpdateInfo result;

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        result.writeToParcel(dest, flags);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Update> CREATOR = new Creator<Update>() {
        @Override
        public Update createFromParcel(Parcel in) {
            return new Update();
        }

        @Override
        public Update[] newArray(int size) {
            return new Update[size];
        }
    };

    public UpdateInfo getResult() {
        return result;
    }

    public void setResult(UpdateInfo result) {
        this.result = result;
    }


}


