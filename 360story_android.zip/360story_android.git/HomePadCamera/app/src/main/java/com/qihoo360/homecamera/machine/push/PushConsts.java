package com.qihoo360.homecamera.machine.push;

public class PushConsts {
	
	public interface Type {
		// 故事机指令
		public static int PUSH_CMD = 17;
	}
}
