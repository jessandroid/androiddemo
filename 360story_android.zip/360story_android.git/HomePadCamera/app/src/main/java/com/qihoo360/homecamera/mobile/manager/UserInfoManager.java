package com.qihoo360.homecamera.mobile.manager;

import android.app.Application;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.qihoo360.homecamera.device.config.StoryMachineConsts;
import com.qihoo360.homecamera.machine.config.MachineDebugConfig;
import com.qihoo360.homecamera.mobile.BuildConfig;
import com.qihoo360.homecamera.mobile.config.DefaultClientConfig;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionPublisherWithThreadPoolBase;
import com.qihoo360.homecamera.mobile.core.manager.workpool.PoolThreadFactory;
import com.qihoo360.homecamera.mobile.core.net.Api;
import com.qihoo360.homecamera.mobile.core.net.MachineApi;
import com.qihoo360.homecamera.mobile.db.CommonWrapper;
import com.qihoo360.homecamera.mobile.entity.AppGetInfoEntity;
import com.qihoo360.homecamera.mobile.entity.DeviceInfo;
import com.qihoo360.homecamera.mobile.entity.Head;
import com.qihoo360.homecamera.mobile.entity.SpaceInfoList;
import com.qihoo360.homecamera.mobile.entity.UserSetting;
import com.qihoo360.homecamera.mobile.http.OkHttpUtils;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.util.Date;
import java.util.HashMap;
import java.util.concurrent.Executors;

/**
 * Created by zhaojunbo on 2016/4/6.
 * desc:
 */
public class UserInfoManager extends ActionPublisherWithThreadPoolBase {
    private final String mPoolNameHighPriority, mPoolNameLowPriority;
    private final Application mApp;

    public UserInfoManager(Application app) {
        this.mApp = app;
        mPoolNameHighPriority = "UserInfoManager-high-priority-" + Utils.DATE_FORMAT_3.format(new Date());
        mPoolNameLowPriority = "UserInfoManager-low-priority-" + Utils.DATE_FORMAT_3.format(new Date());
        mThreadPool.initPool(mPoolNameHighPriority, Executors.newFixedThreadPool(3));
        mThreadPool.initPool(mPoolNameLowPriority,
                Executors.newCachedThreadPool(new PoolThreadFactory(mPoolNameLowPriority)));
    }

    public void asyncAppGetInfo(String sn) {
        mThreadPool.submit(mPoolNameHighPriority, new ActionPublisherWithThreadPoolBase.NamedAsyncJob("AppGetInfo", sn));
    }

    public void asyncAppUpdateInfo(String sn, String qid, String relation, String title, String babyInfo, String fileName, String filePath, Boolean bRunInBackground) {
        mThreadPool.submit(mPoolNameHighPriority, new ActionPublisherWithThreadPoolBase.NamedAsyncJob("AppUpdateInfo", sn, qid, relation, title, babyInfo, fileName, filePath, bRunInBackground));
    }

    public void asyncShareSetRelation(String sn, String relation, String sqid) {
        mThreadPool.submit(mPoolNameHighPriority, new ActionPublisherWithThreadPoolBase.NamedAsyncJob("ShareSetRelation", sn, relation, sqid));
    }

    public void asyncLogoutApp() {
        mThreadPool.submit(mPoolNameHighPriority, new ActionPublisherWithThreadPoolBase.NamedAsyncJob("LogOut"));
    }

    public void asyncSetUserSetting(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("SetUserSetting", args));
    }

    public void asyncGetUserSetting(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("GetUserSetting", args));
    }

    public void asyncGetSpaceInfo(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("GetSpaceInfo", args));
    }

    public void asyncClearCache(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("ClearCache", args));
    }

    public void asyncCalculateCache(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("CalculateCache", args));
    }

    @Override
    protected void asyncDoNamedJob(String jobName, Object... args) {
        if (TextUtils.equals(jobName, "AppGetInfo")) {
            doAppGetInfo((String) args[0]);
        } else if (TextUtils.equals(jobName, "AppUpdateInfo")) {
            doAppUpdateInfo((String) args[0], (String) args[1], (String) args[2], (String) args[3], (String) args[4], (String) args[5], (String) args[6], (Boolean) args[7]);
        } else if (TextUtils.equals(jobName, "LogOut")) {
            doLogout();
        } else if (TextUtils.equals(jobName, "ShareSetRelation")) {
            shareSetRelation((String) args[0], (String) args[1], (String) args[2]);
        } else if (TextUtils.equals(jobName, "SetUserSetting")) {
            doSetPersonSetting((Integer) args[0]);
        } else if (TextUtils.equals(jobName, "GetUserSetting")) {
            doGetPersonSetting();
        } else if (TextUtils.equals(jobName, "GetSpaceInfo")) {
            doGetSpaceInfo((String) args[0]);
        } else if (TextUtils.equals(jobName, "ClearCache")) {
            doClearCache();
        } else if (TextUtils.equals(jobName, "CalculateCache")) {
            asyncCalculateCache();
        }
    }

    private void doLogout() {
        Head head = new Head();
        HashMap<String, String> param = new HashMap<String, String>();
        param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
        String string = OkHttpUtils.post().headers(null).url(DefaultClientConfig.APP_LOGOUT_URL).params(param).build().execute();
        Gson gson = new Gson();
        head = gson.fromJson(string, Head.class);
        publishAction(Actions.UserInfo.LOGOUT_SUCC, head);
    }

    private void shareSetRelation(String sn, String relation, String sqid) {
        Head head = Api.UserInfo.postShareSetRelation(sn, relation, sqid);
        if (head == null) {
            publishAction(Actions.UserInfo.SHARE_SET_RELATION_FAIL);
        } else if (head.errorCode != 0) {
            publishAction(Actions.UserInfo.SHARE_SET_RELATION_FAIL, head.errorCode + head.errorMsg);
        } else {
            publishAction(Actions.UserInfo.SHARE_SET_RELATION_SUCCESS);
        }
    }

    private void doAppGetInfo(String sn) {
        try {
            AppGetInfoEntity appGetInfoEntity = CommonWrapper.getInstance(this.mApp).getLocalToClazz(sn, CommonWrapper.TYPE_APP_GET_INFO, AppGetInfoEntity.class);
            if (appGetInfoEntity != null) {
                publishAction(Actions.UserInfo.APP_GET_INFO_SUCCESS, appGetInfoEntity);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        AppGetInfoEntity appGetInfoEntity;
//        if (MachineDebugConfig.DEBUG && DeviceInfo.isStoryMachine(sn)) {
//            appGetInfoEntity = MachineApi.UserInfo.postAppGetInfo(sn);
//        } else {
            appGetInfoEntity = Api.UserInfo.postAppGetInfo(sn);
//        }
        if (appGetInfoEntity == null) {
            publishAction(Actions.UserInfo.APP_GET_INFO_FAIL);
        } else if (appGetInfoEntity.errorCode != 0) {
            publishAction(Actions.UserInfo.APP_GET_INFO_FAIL, appGetInfoEntity.errorMsg);
        } else {
            if (appGetInfoEntity.errorCode == 0) {
                CommonWrapper.getInstance(this.mApp).writeBySnWithType(sn, appGetInfoEntity.toJson(), CommonWrapper.TYPE_APP_GET_INFO);
            }
            publishAction(Actions.UserInfo.APP_GET_INFO_SUCCESS, appGetInfoEntity);
        }
    }

    private void doAppUpdateInfo(String sn, String qid, String relation, String title, String babyInfo, String fileName, String filePath, Boolean bRunInBackgroung) {
        Head head;
//        if (MachineDebugConfig.DEBUG && DeviceInfo.isStoryMachine(sn)) {
//            head = MachineApi.UserInfo.postAppUpdateInfo(sn, qid, relation, title, babyInfo, fileName, filePath);
//        } else {
            head = Api.UserInfo.postAppUpdateInfo(sn, qid, relation, title, babyInfo, fileName, filePath);
//        }
        if (!bRunInBackgroung) {
            if (head == null) {
                publishAction(Actions.UserInfo.APP_UPDATE_INFO_FAIL);
            } else if (head.errorCode != 0) {
                publishAction(Actions.UserInfo.APP_UPDATE_INFO_FAIL, head.errorCode + head.errorMsg);
            } else {
                publishAction(Actions.UserInfo.APP_UPDATE_INFO_SUCCESS, babyInfo, filePath);
            }
        }
    }

    public void doSetPersonSetting(Integer val) {
        //服务端0=开启，1=关闭
        Head personSetting = Api.UserInfo.postSetPersonSetting(String.valueOf(val.intValue() > 0 ? 0 : 1));
        if (personSetting == null) {
            publishAction(Actions.UserInfo.SET_USER_SETTING_FAIL);
        } else if (personSetting.errorCode != 0) {
            publishAction(Actions.UserInfo.SET_USER_SETTING_FAIL);
        } else {
            publishAction(Actions.UserInfo.SET_USER_SETTING_SUCCESS, val);
        }
    }

    public void doGetPersonSetting() {
        UserSetting personSetting = Api.UserInfo.postGetPersonSetting();
        if (personSetting == null) {
            publishAction(Actions.UserInfo.GET_USER_SETTING_FAIL);
        } else if (personSetting.errorCode != 0) {
            publishAction(Actions.UserInfo.GET_USER_SETTING_FAIL);
        } else {
            publishAction(Actions.UserInfo.GET_USER_SETTING_SUCCESS, personSetting);
        }
    }

    private void doGetSpaceInfo(String sn) {
        SpaceInfoList spaceInfoList = Api.UserInfo.getSpaceInfoList(sn);
        if (spaceInfoList == null) {
            publishAction(Actions.UserInfo.GET_SPACE_INFO_FAIL);
        } else if (spaceInfoList.errorCode != 0) {
            publishAction(Actions.UserInfo.GET_SPACE_INFO_FAIL);
        } else {
            publishAction(Actions.UserInfo.GET_SPACE_INFO_SUCCESS, spaceInfoList);
        }
    }

    private void doClearCache() {
        //清空缓存操作
        if (Api.UserInfo.clearCache()) {
            publishAction(Actions.UserInfo.CLEAR_CACHE_SUCCESS);
        } else {
            publishAction(Actions.UserInfo.CLEAR_CACHE_FAIL);
        }
    }

    private void asyncCalculateCache() {
        //计算缓存操作
        long size = Api.UserInfo.calculateCache();
        publishAction(Actions.UserInfo.CALCULATE_CACHE_SUCCESS, new Long(size));
    }

}
