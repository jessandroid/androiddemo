
package com.qihoo360.homecamera.mobile.core.manager.util;

public interface ActionPublisher extends ActionPublisherSimple {

    void registerActionListener(ActionListener listener, int... caredActions);

    void removeActionListener(ActionListener listener);

    void publishAction(int actionCode, Object... args);

}
