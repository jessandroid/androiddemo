package com.qihoo360.homecamera.mobile.manager;

import android.app.Application;
import android.text.TextUtils;

import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionPublisherWithThreadPoolBase;
import com.qihoo360.homecamera.mobile.core.manager.workpool.PoolThreadFactory;
import com.qihoo360.homecamera.mobile.core.net.Api;
import com.qihoo360.homecamera.mobile.entity.Head;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.util.Date;
import java.util.concurrent.Executors;

/**
 * Created by zhaojunbo on 2016/1/29.
 * desc:
 */
public class NeverKillManager extends ActionPublisherWithThreadPoolBase {

    private final String mPoolNameHighPriority, mPoolNameLowPriority;
    private final Application mApp;

    public NeverKillManager(Application app) {
        this.mApp = app;
        mPoolNameHighPriority = "NeverKillManager-high-priority-" + Utils.DATE_FORMAT_3.format(new Date());
        mPoolNameLowPriority = "NeverKillManager-low-priority-" + Utils.DATE_FORMAT_3.format(new Date());
        mThreadPool.initPool(mPoolNameHighPriority, Executors.newFixedThreadPool(3));
        mThreadPool.initPool(mPoolNameLowPriority,
                Executors.newCachedThreadPool(new PoolThreadFactory(mPoolNameLowPriority)));
    }

    public void asyncShareResponse(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("ShareResponse", args));
    }

    public void asyncShareCancel(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("ShareCancel", args));
    }

    public void asyncShareFriendResponse(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("ShareFriendResponse", args));
    }

    public void asyncPostLog(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("PostLog", args));
    }

    @Override
    protected void asyncDoNamedJob(String jobName, Object... args) {
        if (TextUtils.equals(jobName, "ShareResponse")) {
            doShareResponse((String)args[0], (String)args[1], (String)args[2]);
        }
        else if (TextUtils.equals(jobName, "ShareCancel")) {
            doShareCancel((String) args[0], (String) args[1]);
        }
        else if (TextUtils.equals(jobName, "ShareFriendResponse")) {
            doShareFriendResponse((String) args[0], (String) args[1], (String) args[2]);
        }
        else if (TextUtils.equals(jobName, "PostLog")) {
            doPostLog();
        }
    }

    public void doShareResponse(String sn, String sqid, String agree) {
        Head head = Api.Camera.postShareResponse(sn, sqid, agree);
        if (head == null) {
            publishAction(Actions.Share.SHARE_RESPONSE_FAIL);
        } else if (head.errorCode != 0) {
            publishAction(Actions.Share.SHARE_RESPONSE_FAIL, head.errorMsg, agree);
        } else {
            publishAction(Actions.Share.SHARE_RESPONSE_SUCCESS, head, agree);
        }
    }

    public void doShareCancel(String sn, String shareQid) {
        Head deviceInfo = Api.Camera.postShareCancel(sn, shareQid, "");
        if (deviceInfo == null) {
            publishAction(Actions.Share.SHARE_CANCEL_FAIL);
        } else if (deviceInfo.errorCode != 0) {
            publishAction(Actions.Share.SHARE_CANCEL_FAIL, deviceInfo.errorCode);
        } else {
            publishAction(Actions.Share.SHARE_CANCEL_SUCCESS,sn);
        }
    }

    public void doShareFriendResponse(String rspsSN, String rqstSN, String agree) {
        Head head = Api.Camera.postShareFriendResponse(rspsSN, rqstSN, agree);
        if (head == null) {
            publishAction(Actions.Share.SHARE_FRIEND_RESPONSE_FAIL);
        } else if (head.errorCode != 0) {
            publishAction(Actions.Share.SHARE_FRIEND_RESPONSE_FAIL, head.errorMsg);
        } else {
            publishAction(Actions.Share.SHARE_FRIEND_RESPONSE_SUCCESS, agree);
        }
    }

    public void doPostLog() {
        Api.Camera.postLog();
    }
}
