package com.qihoo360.homecamera.mobile.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.entity.DeviceCloudSettingSupport;
import com.qihoo360.homecamera.mobile.entity.DeviceInfo;
import com.qihoo360.homecamera.mobile.entity.EyeProtectionEntity;
import com.qihoo360.homecamera.mobile.entity.IpcAllEntity;
import com.qihoo360.homecamera.mobile.entity.NightRestEntity;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.QHStatAgentHelper;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.widget.CamAlertDialog;
import com.qihoo360.homecamera.mobile.widget.SettingItem;
import com.qihoo360.homecamera.mobile.widget.numberpicker.NumberPicker;

import java.util.HashMap;

/**
 * Created by zhaojunbo on 2016/8/29.
 * desc:
 */
public class KibotSettingActivity extends BaseActivity implements View.OnClickListener, SettingItem.ISwitchListener, ActionListener {

    private final static String TAG = "KibotSettingActivity";

    private RelativeLayout mAreaRl1;
    private RelativeLayout mAreaRl2;
    private RelativeLayout mAreaRl5;
    private SettingItem mFirst;
    private SettingItem mSecond;
    private SettingItem mThird;
    private SettingItem mForth;
    private TextView mTitleTv;
    private TextView mRightTv;
    private ImageView mBackIv;
    private PopupWindow mProtectedPopupWindow;
    private PopupWindow mResetPopupWindow;
    private int mWatchTime = 2;
    private int mResetTime = 0;
    private int mSleepHour = 21;
    private int mSleepMinute = 30;
    private int mWeekHour = 7;
    private int mWeekMinute = 0;
    private int mWatchTimeTemp = mWatchTime;
    private int mResetTimeTemp = mResetTime;
    private int mSleepHourTemp = mSleepHour;
    private int mSleepMinuteTemp = mSleepMinute;
    private int mWeekHourTemp = mWeekHour;
    private int mWeekMinuteTemp = mWeekMinute;
    private String mSn = "";
    private TextView mWatchTv;
    private TextView mResetTv;
    private TextView mSleepTv;
    private TextView mWakeTv;
    private IpcAllEntity mIpcAllEntity;
    private NumberPicker mChooseTimePicker;
    private NumberPicker mChooseHourPicker;
    private NumberPicker mChooseMinutePicker;
    private boolean mChanged = false;
    private boolean bExitFinishSetting = false;
    private boolean bUpdate = false;

    private DeviceInfo dev;

    public static void startActivity(Context cxt, DeviceInfo dev){
        Intent intent = new Intent(cxt, KibotSettingActivity.class);
        intent.putExtra("dev", dev);
        cxt.startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acitivtiy_kibot_setting);
        if(getIntent()!=null){
            if(getIntent().hasExtra("dev")){
                dev = getIntent().getParcelableExtra("dev");
                mSn = dev.sn;
            }
        }
        if (dev == null || TextUtils.isEmpty(dev.sn)) {
            finish();
        }

        mAreaRl1 = (RelativeLayout) findViewById(R.id.rl_area_1);
        mAreaRl2 = (RelativeLayout) findViewById(R.id.rl_area_2);
        mAreaRl5 = (RelativeLayout) findViewById(R.id.rl_area_5);
        mFirst = (SettingItem) findViewById(R.id.first);
        mSecond = (SettingItem) findViewById(R.id.second);
        mThird = (SettingItem) findViewById(R.id.thrid);
        mForth = (SettingItem) findViewById(R.id.forth);

        mTitleTv = (TextView) findViewById(R.id.title_string);
        mRightTv = (TextView) findViewById(R.id.tv_right_button);
        mBackIv = (ImageView) findViewById(R.id.back_zone);
        mWatchTv = (TextView) findViewById(R.id.tv_watch_time);
        mResetTv = (TextView) findViewById(R.id.tv_reset_time);
        mSleepTv = (TextView) findViewById(R.id.tv_sleep_time);
        mWakeTv = (TextView) findViewById(R.id.tv_week_time);
        mRightTv.setText(getString(R.string.tips_97));
        mRightTv.setVisibility(View.VISIBLE);
        mTitleTv.setText(getString(R.string.tips_96));
        mFirst.setSwitchChangeListener(this);
        mSecond.setSwitchChangeListener(this);
        mThird.setSwitchChangeListener(this);
        mForth.setSwitchChangeListener(this);

        Utils.ensuerSetOnclick(this, mAreaRl1, mAreaRl2, mRightTv, mBackIv, mAreaRl5);
        initProtectedPickerWindow();
        initResetPickerWindow();
        GlobalManager.getInstance().getPadSettingManager().registerActionListener(this);
        GlobalManager.getInstance().getPadSettingManager().asyncGetIpcAll(mSn);
        mChanged = false;
        QHStatAgentHelper.commitCommonEvent("enterRobotSet");
    }

    @Override
    public void onBackPressed() {
        back();
    }

    @Override
    public void onResume(){
        super.onResume();
        GlobalManager.getInstance().getPadSettingManager().asyncGetIpcAll(mSn);
    }

    private void back(){
        if (mChanged) {
            CamAlertDialog.Builder builder = new CamAlertDialog.Builder(KibotSettingActivity.this);
            builder.setMessage("还没有保存设置哦，确认放弃保存吗？");
            builder.setPositiveButton("保存", new CamAlertDialog.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    saveChange(true);
                }
            });
            builder.setNegativeButton("放弃", new CamAlertDialog.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            });
            builder.show();
        }
        else{
            finish();
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.rl_area_1:
                showProtectPickerWindow(view);
                break;
            case R.id.rl_area_2:
                showResetPickerWindow(view);
                break;
            case R.id.tv_right_button:
                saveChange(false);
                break;
            case R.id.back_zone:
                back();
                break;
            case R.id.rl_area_5:
                resetPassword();
                break;
        }
    }

    private void saveChange(boolean exit){
        bExitFinishSetting = exit;
        if (Utils.isNetworkAvailable(this)) {
            showTipsDialog("设置中，请稍后...", R.drawable.icon_loading, true);
            GlobalManager.getInstance().getPadSettingManager().asyncSetIpcAll(mSn,
                    String.format("{\"night_rest\":{\"wakeupTime\":\"%1$02d:%2$02d\",\"sleepTime\":\"%3$02d:%4$02d\",\"isOpen\":\"%5$d\"}," +
                                    "\"capture_video\":\"%6$d\",\"remote_view\":\"%7$d\",\"eye_protection\":{\"usingTime\":%8$02d,\"restTime\":%9$02d," +
                                    "\"isOpen\":\"%10$d\"}}", mWeekHour, mWeekMinute, mSleepHour, mSleepMinute, mSecond.getChecked() ? 1 : 0
                            , mForth.getChecked() ? 1 : 0, mThird.getChecked() ? 1 : 0, (mWatchTime + 1) * 10, (mResetTime + 1) * 10, mFirst.getChecked() ? 1 : 0)
                    , mWeekHour, mWeekMinute, mSleepHour, mSleepMinute, mSecond.getChecked() ? 1 : 0
                    , mForth.getChecked() ? 1 : 0, mThird.getChecked() ? 1 : 0, (mWatchTime + 1) * 10, (mResetTime + 1) * 10, mFirst.getChecked() ? 1 : 0);
            QHStatAgentHelper.commitCommonEvent("saveRobotSet");
        } else {
            CameraToast.showToast(this, R.string.network_disabled);
        }
    }

    @Override
    public void onSwitchChange(View v, boolean b) {
        if (!bUpdate) return;
        switch (v.getId()) {
            case R.id.first:{
                mAreaRl1.setVisibility(b ? View.VISIBLE : View.GONE);
                HashMap<String, String> map = new HashMap<String, String>();
                map.put("eyeProtectTimer", mFirst.getChecked() ? "on":"off");
                if(mFirst.getChecked()){
                    mFirst.showDivideLine();
                }else{
                    mFirst.hideDivideLine();
                }
                QHStatAgentHelper.commitCommonEventHash("setRobot",map);
                break;
            }
            case R.id.second:{
                mAreaRl2.setVisibility(b ? View.VISIBLE : View.GONE);
                HashMap<String, String> map = new HashMap<String, String>();
                map.put("nightMode", mSecond.getChecked() ? "on":"off");
                if(mSecond.getChecked()){
                    mSecond.showDivideLine();
                }else{
                    mSecond.hideDivideLine();
                }
                QHStatAgentHelper.commitCommonEventHash("setRobot",map);
                break;
            }
            case R.id.thrid:{
                HashMap<String, String> map = new HashMap<String, String>();
                map.put("remoteView", mThird.getChecked() ? "on":"off");
                QHStatAgentHelper.commitCommonEventHash("setRobot",map);
                break;
            }
            case R.id.forth:{
                HashMap<String, String> map = new HashMap<String, String>();
                map.put("captureVideo", mForth.getChecked() ? "on":"off");
                QHStatAgentHelper.commitCommonEventHash("setRobot",map);
                break;
            }
        }
        mChanged = true;
    }

    @Override
    public void onSwitchClick(View v, boolean b) {

    }

    public void initProtectedPickerWindow() {
        LayoutInflater inflater = LayoutInflater.from(this);
        View view = inflater.inflate(R.layout.protect_picker, null);
        mProtectedPopupWindow = new PopupWindow(view,
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        mProtectedPopupWindow.setBackgroundDrawable(new BitmapDrawable());
        mProtectedPopupWindow.setAnimationStyle(R.style.popu_animation);
        mProtectedPopupWindow.setFocusable(true);
        mProtectedPopupWindow.setOutsideTouchable(true);
        mProtectedPopupWindow.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        mProtectedPopupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
            }
        });
        TextView btnOk = (TextView) view.findViewById(R.id.tv_ok);
        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mChanged = true;
                mWatchTime = mWatchTimeTemp;
                mResetTime = mResetTimeTemp;
                mWatchTv.setText(String.format("%1$02d分钟", (mWatchTime + 1) * 10));
                mResetTv.setText(String.format("%1$02d分钟", (mResetTime + 1) * 10));
                if (mProtectedPopupWindow != null) {
                    mProtectedPopupWindow.dismiss();
                }
            }
        });
        TextView btnCancel = (TextView) view.findViewById(R.id.tv_cancel);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mProtectedPopupWindow != null) {
                    mProtectedPopupWindow.dismiss();
                }
            }
        });
        final NumberPicker mChooseTypePicker = (NumberPicker) view.findViewById(R.id.choose_type);
        mChooseTypePicker.setMinValue(0);
        mChooseTypePicker.setMaxValue(1);
        mChooseTypePicker.setValue(0);
        mChooseTypePicker.setFormatter(NumberPicker.getCustomFormatter("使用时长", "休息时长"));
        mChooseTypePicker.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);
        mChooseTimePicker = (NumberPicker) view.findViewById(R.id.choose_time);
        mChooseTimePicker.setMinValue(0);
        mChooseTimePicker.setMaxValue(5);
        mChooseTimePicker.setValue(mWatchTime);
        mChooseTimePicker.setFormatter(NumberPicker.getCustomFormatter("10", "20", "30", "40", "50", "60"));
        mChooseTimePicker.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);
        mChooseTypePicker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
                switch (newVal) {
                    case 0:
                        mChooseTimePicker.setValue(mWatchTimeTemp);
                        break;
                    case 1:
                        mChooseTimePicker.setValue(mResetTimeTemp);
                        break;
                }
            }
        });
        mChooseTimePicker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
                switch (mChooseTypePicker.getValue()) {
                    case 0:
                        mWatchTimeTemp = newVal;
                        break;
                    case 1:
                        mResetTimeTemp = newVal;
                        break;
                }
            }
        });
    }

    public void initResetPickerWindow() {
        LayoutInflater inflater = LayoutInflater.from(this);
        View view = inflater.inflate(R.layout.free_picker, null);
        mResetPopupWindow = new PopupWindow(view,
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        mResetPopupWindow.setBackgroundDrawable(new BitmapDrawable());
        mResetPopupWindow.setAnimationStyle(R.style.popu_animation);
        mResetPopupWindow.setFocusable(true);
        mResetPopupWindow.setOutsideTouchable(true);
        mResetPopupWindow.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        mResetPopupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
            }
        });
        TextView btnOk = (TextView) view.findViewById(R.id.tv_ok);
        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mChanged = true;
                mSleepHour = mSleepHourTemp;
                mSleepMinute = mSleepMinuteTemp;
                mWeekHour = mWeekHourTemp;
                mWeekMinute = mWeekMinuteTemp;
                mSleepTv.setText(String.format("%1$02d:%2$02d", mSleepHour, mSleepMinute));
                mWakeTv.setText(String.format("%1$02d:%2$02d", mWeekHour, mWeekMinute));
                if (mResetPopupWindow != null) {
                    mResetPopupWindow.dismiss();
                }
            }
        });
        TextView btnCancel = (TextView) view.findViewById(R.id.tv_cancel);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mResetPopupWindow != null) {
                    mResetPopupWindow.dismiss();
                }
            }
        });
        final NumberPicker mChooseTypePicker = (NumberPicker) view.findViewById(R.id.choose_type);
        mChooseTypePicker.setMinValue(0);
        mChooseTypePicker.setMaxValue(1);
        mChooseTypePicker.setValue(0);
        mChooseTypePicker.setFormatter(NumberPicker.getCustomFormatter("睡觉时间", "起床时间"));
        mChooseTypePicker.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);
        mChooseHourPicker = (NumberPicker) view.findViewById(R.id.choose_hour);
        mChooseHourPicker.setMinValue(0);
        mChooseHourPicker.setMaxValue(23);
        mChooseHourPicker.setValue(mSleepHour);
        mChooseHourPicker.setFormatter(NumberPicker.getTwoDigitFormatter());
        mChooseHourPicker.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);
        mChooseMinutePicker = (NumberPicker) view.findViewById(R.id.choose_minute);
        mChooseMinutePicker.setMinValue(0);
        mChooseMinutePicker.setMaxValue(59);
        mChooseMinutePicker.setValue(mSleepMinute);
        mChooseMinutePicker.setFormatter(NumberPicker.getTwoDigitFormatter());
        mChooseMinutePicker.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);
        mChooseTypePicker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
                switch (mChooseTypePicker.getValue()) {
                    case 0:
                        mChooseHourPicker.setValue(mSleepHourTemp);
                        mChooseMinutePicker.setValue(mSleepMinuteTemp);
                        break;
                    case 1:
                        mChooseHourPicker.setValue(mWeekHourTemp);
                        mChooseMinutePicker.setValue(mWeekMinuteTemp);
                        break;
                }
            }
        });
        mChooseHourPicker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
                switch (mChooseTypePicker.getValue()) {
                    case 0:
                        mSleepHourTemp = newVal;
                        break;
                    case 1:
                        mWeekHourTemp = newVal;
                        break;
                }
            }
        });
        mChooseMinutePicker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
                switch (mChooseTypePicker.getValue()) {
                    case 0:
                        mSleepMinuteTemp = newVal;
                        break;
                    case 1:
                        mWeekMinuteTemp = newVal;
                        break;
                }
            }
        });
    }

    public void showProtectPickerWindow(View v) {
        mProtectedPopupWindow.showAtLocation(v, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0);
    }

    public void showResetPickerWindow(View v) {
        mResetPopupWindow.showAtLocation(v, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0);
    }

    @Override
    public Object actionPerformed(int actionCode, Object... args) {
        switch (actionCode) {
            case Actions.PadSetting.GET_SETTING_SUCCESS: {
                mIpcAllEntity = (IpcAllEntity) args[0];
                updateView(mIpcAllEntity);
                return Boolean.TRUE;
            }
            case Actions.PadSetting.GET_SETTING_FAIL: {
                bUpdate = true;
                return Boolean.TRUE;
            }
            //服务端返回的为空，之前没有设置过，默认打开
            case Actions.PadSetting.GET_SETTING_NULL:{
                mFirst.setChecked(true);
                mSecond.setChecked(true);
                mThird.setChecked(true);
                mForth.setChecked(true);
                bUpdate = true;
                return Boolean.TRUE;
            }

            case Actions.PadSetting.SET_SETTING_SUCCESS: {
                GlobalManager.getInstance().getPadSettingManager().asyncGetIpcAll(mSn);
                hideTipsDialog();
                CameraToast.show("设置成功", Toast.LENGTH_SHORT);
                mChanged = false;
                if (bExitFinishSetting){
                    finish();
                    bExitFinishSetting = false;
                }
                return Boolean.TRUE;
            }
            case Actions.PadSetting.SET_SETTING_FAIL: {
                hideTipsDialog();
                updateView(mIpcAllEntity);
                return Boolean.TRUE;
            }
        }
        return null;
    }

    private void updateView(IpcAllEntity ipcAllEntity) {
        bUpdate = false;
        mThird.setChecked(ipcAllEntity.data.settings.remote_view.equals("1"));
        mForth.setChecked(ipcAllEntity.data.settings.capture_video.equals("1"));
        Gson gson = new Gson();
        NightRestEntity nightRestEntity = gson.fromJson(ipcAllEntity.data.settings.night_rest, NightRestEntity.class);
        String[] wakeUpArr = nightRestEntity.wakeupTime.split(":");
        String[] sleepArr = nightRestEntity.sleepTime.split(":");
        mSecond.setChecked(nightRestEntity.isOpen.equals("1"));
        mSleepHourTemp = processStartWithZero(sleepArr[0], mSleepHourTemp);
        mSleepMinuteTemp = processStartWithZero(sleepArr[1], mSleepMinuteTemp);
        mWeekHourTemp = processStartWithZero(wakeUpArr[0], mWeekHourTemp);
        mWeekMinuteTemp = processStartWithZero(wakeUpArr[1], mWeekMinuteTemp);
        mSleepHour = mSleepHourTemp;
        mSleepMinute = mSleepMinuteTemp;
        mWeekHour = mWeekHourTemp;
        mWeekMinute = mWeekMinuteTemp;
        mSleepTv.setText(String.format("%1$02d:%2$02d", mSleepHour, mSleepMinute));
        mWakeTv.setText(String.format("%1$02d:%2$02d", mWeekHour, mWeekMinute));


        EyeProtectionEntity eyeProtectionEntity = gson.fromJson(ipcAllEntity.data.settings.eye_protection, EyeProtectionEntity.class);
        mFirst.setChecked(eyeProtectionEntity.isOpen.equals("1"));
        mWatchTimeTemp = processStartWithZero(eyeProtectionEntity.usingTime, mWatchTimeTemp) / 10 - 1;
        mResetTimeTemp = processStartWithZero(eyeProtectionEntity.restTime, mResetTimeTemp) / 10 - 1;
        mWatchTime = mWatchTimeTemp;
        mResetTime = mResetTimeTemp;
        mWatchTv.setText(String.format("%1$02d分钟", (mWatchTime + 1) * 10));
        mResetTv.setText(String.format("%1$02d分钟", (mResetTime + 1) * 10));

        mChooseTimePicker.setValue(mWatchTime);
        mChooseHourPicker.setValue(mSleepHour);
        CLog.i("test3", "mSleepMinute = "+mSleepMinute);
        mChooseMinutePicker.setValue(mSleepMinute);
        mChanged = false;
        bUpdate = true;

        //解决 护眼和夜间模式关闭的，再次进入设置页不应该展开时间项
        mAreaRl1.setVisibility(mFirst.getChecked() ? View.VISIBLE : View.GONE);
        mAreaRl2.setVisibility(mSecond.getChecked() ? View.VISIBLE : View.GONE);
        if(mFirst.getChecked()){
            mFirst.showDivideLine();
        }else{
            mFirst.hideDivideLine();
        }

        if(mSecond.getChecked()){
            mSecond.showDivideLine();
        }else{
            mSecond.hideDivideLine();
        }
    }

    private int processStartWithZero(String temp, int defaultValue) {
        if (temp.startsWith("0")) {
            temp = temp.substring(1, temp.length());
        }
        return Integer.valueOf(temp.replaceAll("\\D+", "").replaceAll("\r", "").replaceAll("\n", "").trim());
    }

    private void resetPassword(){
        if (dev == null){
            showCustomToast(getResources().getString(R.string.remote_set_not_support), Toast.LENGTH_SHORT);
            return;
        }

        String supportStr = dev.support;
        CLog.e(TAG, "resetPassword- supportStr=" + supportStr);
        Gson gson = new Gson();
        DeviceCloudSettingSupport ds = gson.fromJson(supportStr, DeviceCloudSettingSupport.class);
        CLog.e(TAG, "ds=" + ds);
        if (ds != null && ds.getChange_pwd() == 1) {
            CLog.e(TAG, "change_pwd=" + ds.getChange_pwd());

            Intent intent = new Intent(this, ResetPasswordActivity.class);
            intent.putExtra("sn", mSn);
            startActivity(intent);

        } else {
            showCustomToast(getResources().getString(R.string.remote_set_not_support), Toast.LENGTH_SHORT);
        }
    }

    @Override
    public int getProperty() {
        return 0;
    }

    @Override
    protected void onDestroy() {
        GlobalManager.getInstance().getPadSettingManager().removeActionListener(this);
        super.onDestroy();
    }
}
