package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by zhaojunbo on 2016/4/6.
 * desc:
 */
public class AppGetInfoEntity extends Head{

    public Data data;

    public static class Data implements Parcelable {
        public String babyInfo;
        public String avatarUrl;
        public String relation;

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(this.babyInfo);
            dest.writeString(this.avatarUrl);
        }

        public Data() {
        }

        protected Data(Parcel in) {
            this.babyInfo = in.readString();
            this.avatarUrl = in.readString();
        }

        public static final Creator<Data> CREATOR = new Creator<Data>() {
            @Override
            public Data createFromParcel(Parcel source) {
                return new Data(source);
            }

            @Override
            public Data[] newArray(int size) {
                return new Data[size];
            }
        };
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(this.data, flags);
    }

    public AppGetInfoEntity() {
    }

    protected AppGetInfoEntity(Parcel in) {
        this.data = in.readParcelable(Data.class.getClassLoader());
    }

    public static final Creator<AppGetInfoEntity> CREATOR = new Creator<AppGetInfoEntity>() {
        @Override
        public AppGetInfoEntity createFromParcel(Parcel source) {
            return new AppGetInfoEntity(source);
        }

        @Override
        public AppGetInfoEntity[] newArray(int size) {
            return new AppGetInfoEntity[size];
        }
    };
}
