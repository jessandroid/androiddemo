package com.qihoo360.homecamera.machine.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.activity.BaseActivity;
import com.qihoo360.homecamera.mobile.activity.BindDeviceFrameActivity;

/**
 * Created by zhangtao-iri on 2016/11/10.
 */

public class ChooseDeviceActivity extends MachineBaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_device);

        findViewById(R.id.bind_robot).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ChooseDeviceActivity.this, BindDeviceFrameActivity.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.bind_machine).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ChooseDeviceActivity.this, AddCameraActivity.class);
                startActivity(intent);
            }
        });

    }
}
