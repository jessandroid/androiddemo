package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/4/18
 * Time: 18:52
 * To change this template use File | Settings | File Templates.
 */
public class UpdateBatch extends Head implements Parcelable {
    /**
     * 强制升级
     */
    public static final int FORCE_TYPE_FORCE = 0;
    /**
     * 正常
     */
    public static final int FORCE_TYPE_NORMAL = 1;
    /**
     * 静默升级
     */
    public static final int FORCE_TYPE_SLIENCE = 2;
    /**
     * 弹窗升级
     */
    public static final int FORCE_TYPE_POPUP = 3;

    public ArrayList<UpdateInfo> result;

    public ArrayList<UpdateInfo> getResult() {
        return result;
    }

    public void setResult(ArrayList<UpdateInfo> result) {
        this.result = result;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeTypedList(this.result);
    }

    public UpdateBatch() {
    }

    protected UpdateBatch(Parcel in) {
        super(in);
        this.result = in.createTypedArrayList(UpdateInfo.CREATOR);
    }

    public static final Creator<UpdateBatch> CREATOR = new Creator<UpdateBatch>() {
        @Override
        public UpdateBatch createFromParcel(Parcel source) {
            return new UpdateBatch(source);
        }

        @Override
        public UpdateBatch[] newArray(int size) {
            return new UpdateBatch[size];
        }
    };
}


