
package com.qihoo360.homecamera.mobile.core.beans;

import android.net.Uri;
import android.provider.MediaStore.Images.Media;
import android.provider.MediaStore.Video;

import java.io.Serializable;

/**
 * 相册相关实体类
 * 
 * @author zhangjinhui
 * 
 */
// TODO: to refactor with PhotoAlbumGroup
public class PhotoAlbum implements Serializable {

    private static final long serialVersionUID = 7765089204757154553L;
    /**
     * 备份表唯一ID，暂无用
     */
    public int id = -1;
    /**
     * 相册ID
     */
    public int _id = -1;
    /**
     * 相册组ID
     */
    public String bucket_id = "";
    /**
     * 相册组名称
     */
    public String bucket_display_name = "";
    /**
     * 相册图片的path
     */
    public String _data = "";
    /**
     * 相册图片的path
     */
    public String _data_remote = "";
    /**
     * 生成时间
     */
    public String date_added = "";
    /**
     * 变更时间
     */
    public String date_modified = "";
    /**
     * 拍摄时间
     */
    public String datetaken = "";
    /**
     * 图片显示名称
     */
    public String _display_name = "";
    /**
     * 图片大小, 注意从媒体库取出来的大小是不准确的，准确的需要获取文件属性
     */
    public long _size = 0;
    public String nid = "";
    public String pid = "";
    public String mime_type = "";
    public long date;
    /**
     * 视频或音频的时长
     */
    public long duration = 0;
    /**
     * 状态
     */
    public int status = -9999;

    /**
     * 正在上传
     */
    public boolean uploading;

    /**
     * 是否备份过(手动备份专用)
     */
    public boolean isStore = false;

    public boolean isVideo;

    public String getVideoThumbnailUri() {
        return Video.Thumbnails.EXTERNAL_CONTENT_URI + "/" + _id;
    }

    public String getThumbnailUri() {
        return Media.EXTERNAL_CONTENT_URI + "/" + _id;
    }

    public String getVideoUri() {
        return Uri.withAppendedPath(Video.Media.EXTERNAL_CONTENT_URI, Long.toString(_id)).toString();
    }
}
