
package com.qihoo360.homecamera.mobile.activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Html;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.db.PadInfoWrapper;
import com.qihoo360.homecamera.mobile.entity.Contacts;
import com.qihoo360.homecamera.mobile.entity.ShareShareEntity;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.widget.CamAlertDialog;

/**
 * Created by Administrator on 2015/3/15.
 */
public class SendContactActivity extends BaseActivity implements ActionListener {

    String sn;
    Contacts contact;
    int type = 0;
    private ImageView btnback;
    private LinearLayout mailbgiv;
    private RelativeLayout relativeLayout2;
    private Button mSendInviteBt;
    private TextView title;
    private TextView send_contact_text;

    @Override
    protected void onCreate(Bundle arg0) {
        super.onCreate(arg0);
        setTintManagerQWork(true);
        tintManager.setStatusBarTintColor(Color.parseColor("#0000aeff"));
        setContentView(R.layout.send_contact_layout);
        Intent intent = getIntent();
        contact = (Contacts) intent.getSerializableExtra("contact");
        type = intent.getIntExtra(Constants.SHARE_TYPE, 0);
        sn = intent.getStringExtra("sn");
        initialize();
    }

    private void initialize() {
        send_contact_text = (TextView) findViewById(R.id.send_contact_text);
        btnback = (ImageView) findViewById(R.id.btn_back);
        title = (TextView) findViewById(R.id.title);
        mailbgiv = (LinearLayout) findViewById(R.id.mail_bg_iv);
        relativeLayout2 = (RelativeLayout) findViewById(R.id.relativeLayout2);
        mSendInviteBt = (Button) findViewById(R.id.bt_send_invite);
        title.setText(getString(R.string.share_name_title, contact.getName()));
        GlobalManager.getInstance().getShareManager().registerActionListener(this);
        GlobalManager.getInstance().getShareManager().asyncShareGetSharingList(sn);
        mSendInviteBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (contact != null && !TextUtils.isEmpty(sn)) {
                    try {
                        GlobalManager.getInstance().getShareManager().asyncShareShare(sn, "3", Utils.checkPhoneNum(contact.getPhoneNumber()), PadInfoWrapper.getInstance().getPadBySn(sn).isStoryMachine()?Constants.DeviceType.STORYMACHINE:Constants.DeviceType.KIBOTMACHINE);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    private void showDialog(String title, String content, boolean html) {
        LayoutInflater inflater = LayoutInflater.from(this);
        View viewDialog = inflater.inflate(R.layout.share_phone_success_result, null);
        TextView titleTextview = (TextView) viewDialog.findViewById(R.id.share_phone_title);
        titleTextview.setText(title);
        TextView share_phone_content = (TextView) viewDialog.findViewById(R.id.share_phone_content);
        if (html) {
            share_phone_content.setText(Html.fromHtml(getString(R.string.send_share_succ_content, content)));
        } else {
            share_phone_content.setText(content);
        }
        Button su = (Button) viewDialog.findViewById(R.id.share_phone_button);

        final CamAlertDialog camAlertDialog = new CamAlertDialog(this, R.style.Dialog_Fullscreen);
        camAlertDialog.setContentView(viewDialog);
        camAlertDialog.show();
        su.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                camAlertDialog.dismiss();
                setResult(10000, getIntent());
                finish();

            }
        });
    }

    @SuppressWarnings("unchecked")
    @Override
    public Object actionPerformed(int actionCode, Object... args) {
        switch (actionCode) {
            case Actions.Share.SHARE_SHARE_SUCCESS:
                ShareShareEntity shareShareEntity = (ShareShareEntity) args[0];
                if (shareShareEntity.data.isRegUser.equals("1")) {
                    showDialog(getString(R.string.send_share_succ_title), contact.getName(), true);
                } else if (shareShareEntity.data.isRegUser.equals("0")) {
                    showDialog(getString(R.string.send_msm_title), getString(R.string.send_msm_content), false);
                }
                return Boolean.TRUE;
            case Actions.Share.SHARE_SHARE_FAIL: {
                getProgressDialog().dismiss();
//                if (args == null || args.length == 0) {
//                    CameraToast.showErrorToast(SendContactActivity.this, "分享失败，请稍后再试");
//                } else {
//                    CameraToast.showToast(SendContactActivity.this, "分享失败，请稍后再试");
//                }
                return Boolean.TRUE;
            }
        }
        return null;
    }

    @Override
    public int getProperty() {
        return 0;
    }

    @Override
    protected void onDestroy() {
        GlobalManager.getInstance().getShareManager().removeActionListener(this);
        super.onDestroy();
    }
}
