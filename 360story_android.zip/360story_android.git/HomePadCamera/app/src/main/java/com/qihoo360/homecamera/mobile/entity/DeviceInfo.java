package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;

import com.qihoo360.homecamera.device.config.DeviceConsts;
import com.qihoo360.homecamera.mobile.ui.fragment.NewDeviceFragment;


/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/1/14
 * Time: 11:52
 * To change this template use File | Settings | File Templates.
 */
public class DeviceInfo extends Head implements Parcelable {

    public  String sn;
    // 标题
    // @SerializedName(value = "title")
    public String title = "宝贝";

    // 是否是主人 是 1:主人 2：家人
    public int role = 0;

    // 授权给多少人
    public int shareNum = 0;

    // 封面图URL,不要直接获取，使用get方法
    private String coverUrl = "";

    // 已绑定360用户头像
    public String imageUrl = "";

    // 已绑定360用户名称
    public String nickName = "";

    //qid
    public String qid = "";

    //本地截图
    public String localCoverImg = "";

    public boolean checked = false;

    public String avatarUrl = "";

    public boolean hasNotAcceptCall = false;

    public Relation relation;
    public String support = "";
    //public DeviceCloudSettingSupport deviceSettingSupport = new DeviceCloudSettingSupport();

    public String hardware = "";
    public String version = "";

    public String deviceType = "";

    public int isOnline = NewDeviceFragment.ONLINE;

    public PrivateEntity aclInfo = new PrivateEntity();

    public static class Relation implements Parcelable {
        public int relation_tag = 0;
        public String relation_title = "";

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeInt(this.relation_tag);
            dest.writeString(this.relation_title);
        }

        public Relation() {
        }

        protected Relation(Parcel in) {
            this.relation_tag = in.readInt();
            this.relation_title = in.readString();
        }

        public static final Creator<Relation> CREATOR = new Creator<Relation>() {
            @Override
            public Relation createFromParcel(Parcel source) {
                return new Relation(source);
            }

            @Override
            public Relation[] newArray(int size) {
                return new Relation[size];
            }
        };
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public DeviceInfo() {

    }

    public DeviceInfo(String sn, String title, int role, int shareNum, String coverUrl, String imageUrl, String nickName, String qid) {
        this.sn = sn;
        this.title = title;
        this.role = role;
        this.shareNum = shareNum;
        this.coverUrl = coverUrl;
        this.imageUrl = imageUrl;
        this.nickName = nickName;
        this.qid = qid;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.sn);
        dest.writeString(this.title);
        dest.writeInt(this.role);
        dest.writeInt(this.shareNum);
        dest.writeString(this.coverUrl);
        dest.writeString(this.imageUrl);
        dest.writeString(this.nickName);
        dest.writeString(this.qid);
        dest.writeString(this.avatarUrl);
        dest.writeParcelable(this.relation, flags);
        dest.writeParcelable(this.aclInfo, flags);
        dest.writeString(this.support);
        dest.writeString(this.deviceType);
        //dest.writeParcelable(this.deviceSettingSupport, flags);
    }

    protected DeviceInfo(Parcel in) {
        this.sn = in.readString();
        this.title = in.readString();
        this.role = in.readInt();
        this.shareNum = in.readInt();
        this.coverUrl = in.readString();
        this.imageUrl = in.readString();
        this.nickName = in.readString();
        this.qid = in.readString();
        this.avatarUrl = in.readString();
        this.relation = in.readParcelable(Relation.class.getClassLoader());
        this.aclInfo = in.readParcelable(PrivateEntity.class.getClassLoader());
        this.support = in.readString();
        this.deviceType = in.readString();
        //this.deviceSettingSupport = in.readParcelable(DeviceCloudSettingSupport.class.getClassLoader());
    }

    public static final Parcelable.Creator<DeviceInfo> CREATOR = new Parcelable.Creator<DeviceInfo>() {
        @Override
        public DeviceInfo createFromParcel(Parcel source) {
            return new DeviceInfo(source);
        }

        @Override
        public DeviceInfo[] newArray(int size) {
            return new DeviceInfo[size];
        }
    };

    public String getSn() {
        return sn;
    }

    public String getRelationTitle() {
        return relation == null ? "" : relation.relation_title;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }

    public String getTitle() {
        return TextUtils.isEmpty(title) ? "宝贝" : title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getRole() {
        return role;
    }

    public void setRole(int role) {
        this.role = role;
    }

    public int getShareNum() {
        return shareNum;
    }

    public void setShareNum(int shareNum) {
        this.shareNum = shareNum;
    }

    public String getCoverUrl() {
        String result = coverUrl;
        return result;
    }

    public void setCoverUrl(String coverUrl) {
        this.coverUrl = coverUrl;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getQid() {
        return qid;
    }

    public void setQid(String qid) {
        this.qid = qid;
    }

    public String getLocalCoverImg() {
        return localCoverImg;
    }

    public void setLocalCoverImg(String localCoverImg) {
        this.localCoverImg = localCoverImg;
    }

    public String getAvatarUrl() {
        return avatarUrl;
    }

    public void setAvatarUrl(String avatarUrl) {
        this.avatarUrl = avatarUrl;
    }

    public String getSupport() {
        return support;
    }

    public void setSupport(String support) {
        this.support = support;
    }


    public boolean isAllowRemoteView() {
        if (aclInfo != null && !TextUtils.isEmpty(aclInfo.remote_view)) {
            if (aclInfo.remote_view.equals("1")) {
                return true;
            } else {
                return false;
            }
        } else {
            return true;
        }
    }

    public boolean isAllowCaptureVideo() {
        if (aclInfo != null && !TextUtils.isEmpty(aclInfo.capture_video)) {
            if (aclInfo.capture_video.equals("1")) {
                return true;
            } else {
                return false;
            }
        } else {
            return true;
        }
    }

    public boolean isStoryMachine() {
        if (deviceType == null) {
            return false;
        }
        return DeviceConsts.DEVICE_TYPE_STORYMACHINE_603.equals(deviceType)
                || DeviceConsts.DEVICE_TYPE_STORYMACHINE_605.equals(deviceType);
    }


    public String getDeviceType(){
        if (deviceType == null) {
            return DeviceConsts.DEVICE_TYPE_DEFAULT;
        } else{
            return deviceType;
        }
    }


    /**
     * 是否是管理员
     * @return
     */
    public boolean isAdmin() {
        return (role == 1);
    }

    @Override
    public String toString() {
        if (TextUtils.isEmpty(title)) {
            return getSn();
        }
        return getTitle();
    }
}
