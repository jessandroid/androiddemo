package com.qihoo360.homecamera.machine.manager;

import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;

import com.qihoo360.homecamera.mobile.download.CallBack;
import com.qihoo360.homecamera.mobile.download.DownloadException;
import com.qihoo360.homecamera.mobile.download.DownloadManager;
import com.qihoo360.homecamera.mobile.download.DownloadRequest;
import com.qihoo360.homecamera.mobile.http.OkHttpUtils;
import com.qihoo360.homecamera.mobile.utils.CLog;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;
/**
 * Created by zhangtao-iri on 2017/2/18.
 */
public class AudioHandlerManager {

    private Context mContext;

    //录音处理
    private MediaRecorder mMediaRecorder;

    //播放处理
    private MediaPlayer mMediaPlayer;

    private DownloadManager downloadManager;

    private int BASE = 600;


    public AudioHandlerManager(Context context) {
        this.mContext = context;
        initAudioMode();
    }

    private void initAudioMode() {
        mMediaPlayer = new MediaPlayer();
        mMediaRecorder = new MediaRecorder();
        downloadManager = DownloadManager.getInstance();
    }

    //播放(每次都是重新播放)
    public synchronized void startPlayAudio(String filePath, MediaPlayer.OnCompletionListener listener) {
        if (mMediaPlayer != null) {
            if (mMediaPlayer.isPlaying()) {
                mMediaPlayer.stop();
            }
            try {
                mMediaPlayer.reset();
                mMediaPlayer.setDataSource(filePath);
                mMediaPlayer.prepare();
                mMediaPlayer.seekTo(0);
                mMediaPlayer.setOnCompletionListener(listener);
                mMediaPlayer.start();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public synchronized void startPlayExpress(int fileId, MediaPlayer.OnCompletionListener listener){
        if (mMediaPlayer != null) {
            if (mMediaPlayer.isPlaying()) {
                mMediaPlayer.stop();
            }
            try {
                mMediaPlayer.reset();
                mMediaPlayer = MediaPlayer.create(mContext, fileId);
                mMediaPlayer.setOnCompletionListener(listener);
                mMediaPlayer.start();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    //释放播放器
    public void closeMediaPlayer() {
        try{
            if (mMediaPlayer != null) {
                if (mMediaPlayer.isPlaying()) {
                    mMediaPlayer.stop();
                }
                mMediaPlayer.release();
                mMediaPlayer = null;
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void pauseMediaPlayer() {
        if (mMediaPlayer != null) {
            if (mMediaPlayer.isPlaying()) {
                mMediaPlayer.stop();
            }
        }
    }

    //是否正在播放声音
    public boolean isPlayAudio(){
        if (mMediaPlayer != null) {
            try{
                if (mMediaPlayer.isPlaying()) {
                    return true;
                }
            }catch (Exception e){
                return false;
            }
        }
        return false;
    }

    //开始录制音频
    public synchronized String startRedord(MediaRecorder.OnInfoListener infoListener) {
        if(mMediaRecorder!=null){
            mMediaRecorder.reset();
        }
        mMediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);  //录入设备
        mMediaRecorder.setAudioSamplingRate(44100);
        mMediaRecorder.setAudioEncodingBitRate(44100);
        mMediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.AAC_ADTS);
        mMediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
        String tmpPath = getDiskCachePath(mContext) + "/" + System.currentTimeMillis() + ".aac";
        mMediaRecorder.setOutputFile(tmpPath);
        mMediaRecorder.setMaxDuration(30*1000);//最大录制时间为30秒
        mMediaRecorder.setOnInfoListener(infoListener);
        try {
            mMediaRecorder.prepare();
            mMediaRecorder.start();
        } catch (Exception e) {
            e.printStackTrace();
            CLog.e("test", "录音失败：" + e.getMessage());
        }
        return tmpPath;
    }

    public int getRatio(){
        if(mMediaRecorder!=null){
            return mMediaRecorder.getMaxAmplitude() / BASE;
        }
        return 0;
    }

    //完成本次录制
    public boolean completeRecord() {
        if (mMediaRecorder != null) {
            try{
                mMediaRecorder.stop();
                mMediaRecorder.reset();
                return true;
            }catch(Exception e){
                return false;
            }
        }else{
            return false;
        }
    }

    //释放录音设备
    public void closeMediaRecord() {
        if (mMediaRecorder != null) {
            mMediaRecorder.release();
            mMediaRecorder = null;
        }
    }

    //获取音频存储地址（外部缓存或者内部缓存）
    public static String getDiskCachePath(Context context) {
        if (Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState()) || !Environment.isExternalStorageRemovable()) {
            File file = new File(context.getExternalCacheDir().getPath() + "/familygroup");
            if (!file.exists()) {
                file.mkdirs();
            }
            return file.getAbsolutePath();
        } else {
            File file = new File(context.getCacheDir().getPath() + "/familygroup");
            if (!file.exists()) {
                file.mkdirs();
            }
            return file.getAbsolutePath();
        }
    }

    //获取音频文件的时长
    public static int getAudioDuration(String path){
        MediaPlayer player = new MediaPlayer();
        int duration = 0;
        try {
            player.setDataSource(path);  //recordingFilePath（）为音频文件的路径
            player.prepare();
            duration = player.getDuration();//获取音频的时间
            CLog.e("duration", "duration:" + duration);
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            player.release();
        }
        return duration;
    }

    //从云端下载
    public void downVoiceFromCloud(final String downUrl, final DownloadInterface downloadInterface) {
        Observable.create(new Observable.OnSubscribe<String>() {
            @Override
            public void call(Subscriber<? super String> subscriber) {
                String downloadJson = OkHttpUtils.get().isStatic(true).url(downUrl).build().execute();
                CLog.e("zt","downloadJson:"+downloadJson);
                if (!TextUtils.isEmpty(downloadJson)) {
                    try {
                        JSONObject jo = new JSONObject(downloadJson);
                        String realUrl = jo.getString("downloadUrl");
                        subscriber.onNext(realUrl);
                        subscriber.onCompleted();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                } else {
                    subscriber.onNext("");
                }
            }
        }).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Action1<String>() {
                    @Override
                    public void call(String s) {
                        if (!TextUtils.isEmpty(s)) {
                           final DownloadRequest request = new DownloadRequest.Builder()
                                    .setTitle(System.currentTimeMillis()+".aac")
                                    .setUri(s)
                                    .setFolder(new File(AudioHandlerManager.getDiskCachePath(mContext)))
                                    .setNeedCookie(false)
                                    .build();
                            downloadManager.download(request, "voice", new CallBack() {
                                @Override
                                public void onStarted() {

                                }

                                @Override
                                public void onConnecting() {

                                }

                                @Override
                                public void onConnected(long total, boolean isRangeSupport) {

                                }

                                @Override
                                public void onProgress(long finished, long total, int progress) {

                                }

                                @Override
                                public void onCompleted() {
                                    //下载完成
                                    String loaclPath = AudioHandlerManager.getDiskCachePath(mContext) +"/"+request.getTitle();
                                    CLog.e("zt", "下载云端音频，并保存在本地的地址："+loaclPath);
                                    downloadInterface.loadSucc(loaclPath);
                                }

                                @Override
                                public void onDownloadPaused() {

                                }

                                @Override
                                public void onDownloadCanceled() {

                                }

                                @Override
                                public void onFailed(DownloadException e) {
                                    //下载失败
                                    CLog.e("zt", "下载云端音频失败:"+e.getMessage());
                                    downloadInterface.loadFailed();
                                }
                            });
                        }
                    }
                });
    }

    //从云端下载
    public void downVoiceFromCloud2(final String realUrl, final DownloadInterface downloadInterface) {
        {
            final DownloadRequest request = new DownloadRequest.Builder()
                    .setTitle(System.currentTimeMillis()+".aac")
                    .setUri(realUrl)
                    .setFolder(new File(AudioHandlerManager.getDiskCachePath(mContext)))
                    .setNeedCookie(false)
                    .build();
            downloadManager.download(request, "voice", new CallBack() {
                @Override
                public void onStarted() {

                }

                @Override
                public void onConnecting() {

                }

                @Override
                public void onConnected(long total, boolean isRangeSupport) {

                }

                @Override
                public void onProgress(long finished, long total, int progress) {

                }

                @Override
                public void onCompleted() {
                    //下载完成
                    String loaclPath = AudioHandlerManager.getDiskCachePath(mContext) +"/"+request.getTitle();
                    CLog.e("zt", "下载云端音频，并保存在本地的地址："+loaclPath);
                    downloadInterface.loadSucc(loaclPath);
                }

                @Override
                public void onDownloadPaused() {

                }

                @Override
                public void onDownloadCanceled() {

                }

                @Override
                public void onFailed(DownloadException e) {
                    //下载失败
                    CLog.e("zt", "下载云端音频失败:"+e.getMessage());
                    downloadInterface.loadFailed();
                }
            });
        }
    }

    public  static final int STATE_RECORDING = -1;
    public  static final int STATE_NO_PERMISSION = -2;
    public  static final int STATE_SUCCESS = 1;

    public static int getRecordState() {
        int index = 1;
        boolean hasPermission = false;
        int minBuffer = AudioRecord.getMinBufferSize(44100, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        AudioRecord audioRecord = new AudioRecord(MediaRecorder.AudioSource.DEFAULT, 44100, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, (minBuffer * 100));
        short[] point = new short[minBuffer];
        int readSize = 0;
        try {
            audioRecord.startRecording();//检测是否可以进入初始化状态
        } catch (Exception e) {
            if (audioRecord != null) {
                audioRecord.release();
                audioRecord = null;
                CLog.d("CheckAudioPermission","无法进入录音初始状态");
            }
            return STATE_NO_PERMISSION;
        }
        if (audioRecord.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) {
            //6.0以下机型都会返回此状态，故使用时需要判断bulid版本
            //检测是否在录音中
            if (audioRecord != null) {
                audioRecord.release();
                audioRecord = null;
                CLog.d("CheckAudioPermission","录音机被占用");
            }
            return STATE_NO_PERMISSION;
        } else {
            //检测是否可以获取录音结果
            while(index<5){
                readSize = audioRecord.read(point, 0, point.length);
                if (readSize <=0) {
                    if (audioRecord != null) {
                        audioRecord.stop();
                        audioRecord.release();
                        audioRecord = null;
                    }
                    index++;
                    CLog.d("CheckAudioPermission","录音的结果为空");
                } else{
                    hasPermission = true;
                    break;
                }
            }
            if (audioRecord != null) {
                audioRecord.stop();
                audioRecord.release();
                audioRecord = null;
            }
            if(hasPermission){
                return STATE_SUCCESS;
            }else{
                return STATE_NO_PERMISSION;
            }
        }
    }

    public interface DownloadInterface{
        public void loadSucc(String localpath);
        public void loadFailed();
    }

}
