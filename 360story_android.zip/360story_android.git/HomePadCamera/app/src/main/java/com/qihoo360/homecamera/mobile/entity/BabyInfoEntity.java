package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by zhaojunbo on 2016/4/7.
 * desc:
 */
public class BabyInfoEntity implements Parcelable{

    public String babyname;
    public long babybirth;
    public int babysex;

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.babyname);
        dest.writeLong(this.babybirth);
        dest.writeInt(this.babysex);
    }

    public BabyInfoEntity(String babyname, long babybirth, int babysex) {
        this.babyname = babyname;
        this.babybirth = babybirth;
        this.babysex = babysex;
    }

    protected BabyInfoEntity(Parcel in) {
        this.babyname = in.readString();
        this.babybirth = in.readLong();
        this.babysex = in.readInt();
    }

    public static final Creator<BabyInfoEntity> CREATOR = new Creator<BabyInfoEntity>() {
        @Override
        public BabyInfoEntity createFromParcel(Parcel source) {
            return new BabyInfoEntity(source);
        }

        @Override
        public BabyInfoEntity[] newArray(int size) {
            return new BabyInfoEntity[size];
        }
    };

    @Override
    public String toString() {
        return String.format("{\"babyname\": \"%1$s\",\"babybirth\": %2$s,\"babysex\": %3$d}", babyname, babybirth, babysex);
    }
}
