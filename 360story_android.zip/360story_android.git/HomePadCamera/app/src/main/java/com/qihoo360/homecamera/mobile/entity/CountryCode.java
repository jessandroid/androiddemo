package com.qihoo360.homecamera.mobile.entity;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2015/11/20
 * Time: 11:38
 * To change this template use File | Settings | File Templates.
 */
public class CountryCode implements Serializable {
    private static final long serialVersionUID = -2699408753689809708L;
    @SerializedName("state")
    private String mCountryName="中国大陆";
    @SerializedName("zone")
    private String mCountryCode="+86";
    @SerializedName("pattern")
    private String pattern;

    private String sortLetters;  //显示数据拼音的首字母

    public CountryCode() {
    }

    public CountryCode(String countryName, String countryCode, String partern) {
        mCountryName = countryName;
        mCountryCode = countryCode;
        this.pattern = partern;
    }

    public String getCountryName() {
        return mCountryName;
    }

    public void setCountryName(String countryName) {
        mCountryName = countryName;
    }

    public String getCountryCode() {
        return mCountryCode;
    }

    public void setCountryCode(String countryCode) {
        mCountryCode = countryCode;
    }

    public String getPattern() {
        return pattern;
    }

    public void setPattern(String pattern) {
        this.pattern = pattern;
    }

    public String getSortLetters() {
        return sortLetters;
    }

    public void setSortLetters(String sortLetters) {
        this.sortLetters = sortLetters;
    }



}
