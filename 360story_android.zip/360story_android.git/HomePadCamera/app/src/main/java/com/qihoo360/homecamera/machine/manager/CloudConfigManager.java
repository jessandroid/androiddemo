package com.qihoo360.homecamera.machine.manager;

import android.os.AsyncTask;
import android.os.Handler;
import android.text.TextUtils;

import com.qihoo360.homecamera.machine.entity.Config;
import com.qihoo360.homecamera.machine.net.CameraHttpApi;
import com.qihoo360.homecamera.machine.preferences.Preferences;
import com.qihoo360.homecamera.machine.util.JSONUtils;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.config.Const;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.util.ArrayList;
import java.util.List;

public class CloudConfigManager {

    private final static String CACHE_NAME = "cloud_config.cache";

    private static CloudConfigManager INSTANCE;

    private Config globalConfig;

    private SyncScheduler syncScheduler;

    private CloudConfigManager() {
        syncScheduler = new SyncScheduler();
        onGlobalConfigChangedListeners = new ArrayList<OnGlobalConfigChangedListener>();
    }

    public interface OnGlobalConfigChangedListener {
        public void onGlobalConfigChanged(Config oldConfig, Config newConfig);
    }

    private List<OnGlobalConfigChangedListener> onGlobalConfigChangedListeners;

    public static synchronized CloudConfigManager getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new CloudConfigManager();
        }
        return INSTANCE;
    }

    public Config getGlobalConfig() {
        return globalConfig;
    }

    public void registerOnGlobalConfigChangedListener(OnGlobalConfigChangedListener listener) {
        if (!onGlobalConfigChangedListeners.contains(listener)) {
            onGlobalConfigChangedListeners.add(listener);
        }
    }

    public void unRegisterOnGlobalConfigChangedListener(OnGlobalConfigChangedListener listener) {
        onGlobalConfigChangedListeners.remove(listener);
    }

    public void startSyncFromServer() {
        syncScheduler.nextSchedule();
    }

    private void invokeChange(Config oldConfig, Config newConfig) {
        for (OnGlobalConfigChangedListener listener : onGlobalConfigChangedListeners) {
            if (listener != null) {
                listener.onGlobalConfigChanged(oldConfig, newConfig);
            }
        }
    }

    public void clean() {
        onGlobalConfigChangedListeners.clear();
    }

    public class SyncScheduler {

        final static int MAX_RETRY_COUNT = 5;

        private int retryCount;

        private Handler handler;

        private long lastScheduleRequestedTime;

        private UpdateTask currentTask;

        private CameraHttpApi cameraHttpApi;

        private boolean ignoreCache;

        SyncScheduler() {
            handler = new Handler(Utils.getContext().getMainLooper());
            cameraHttpApi = new CameraHttpApi(false);
            new ReadConfigCacheTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR);
        }

        public void nextSchedule() {
            CLog.d("nextSchedule retryCount:" + retryCount + ", isExecuting:" + (currentTask != null ? currentTask.configSyncTask.getStatus() : -1));
            if (currentTask != null && currentTask.configSyncTask.getStatus() != AsyncTask.Status.FINISHED) {
                return;
            }
            if (System.currentTimeMillis() - lastScheduleRequestedTime < 2 * 60 * 1000
                    && !Const.DEBUG) {
                CLog.d("nextSchedule is not time to sync.");
                return;
            }
            retryCount = 0;
            if (currentTask != null) {
                handler.removeCallbacks(currentTask);
            }
            currentTask = new UpdateTask();
            lastScheduleRequestedTime = System.currentTimeMillis();
            handler.post(currentTask);
        }

        private boolean retry() {
            CLog.d("retry retryCount:" + retryCount);
            if (retryCount >= MAX_RETRY_COUNT) {
                return false;
            }
            if (currentTask != null) {
                handler.removeCallbacks(currentTask);
            }
            ++retryCount;
            currentTask = new UpdateTask();
            handler.postDelayed(currentTask, retryCount * (retryCount * retryCount * 60 * 1000));
            return true;
        }

        private class UpdateTask implements Runnable {

            ConfigSyncTask configSyncTask;

            public UpdateTask() {
                configSyncTask = new ConfigSyncTask();
            }

            @Override
            public void run() {
                configSyncTask.execute();
            }
        }

        private class ReadConfigCacheTask extends AsyncTask<Void, Void, Config> {
            @Override
            protected Config doInBackground(Void... params) {
                Config config = null;
                try {
                    String cachedString = JSONCacheManager.getInstance().readCache(CACHE_NAME);
                    CLog.d("read cache string:" + cachedString);
                    if (!TextUtils.isEmpty(cachedString)) {
                        config = JSONUtils.fromJson(Config.class, cachedString);
                        CLog.d("read cache config:" + config);
                    }
                } catch(Throwable e) {
                    CLog.e(e.toString());
                }
                return config;
            }

            @Override
            protected void onPostExecute(Config config) {
                super.onPostExecute(config);
                if (!ignoreCache && config != null && config.isValid()) {
                    globalConfig = config;
                    invokeChange(null, globalConfig);
                }
            }
        }

        private class ConfigSyncTask extends AsyncTask<Void, Void, Config> {
            @Override
            protected Config doInBackground(Void... params) {
                Config config = null;
                try {
                    String string = cameraHttpApi.doJsonRequestWithStatusCode(Utils.getContext().getString(R.string.name_conf_v1));
                    config = JSONUtils.fromJson(Config.class, string);
                    if (config != null) {
                        config.jsonFullString = string;
                    }
                    CLog.d("Sync config:" + config + ", oldConfig:" + globalConfig);
                } catch (Exception e) {
                    CLog.e("ConfigSyncTask", "ConfigSyncTask fail.", e);
                }
                return config;
            }

            @Override
            protected void onPostExecute(Config config) {
                super.onPostExecute(config);
                if (config != null) {
                    if (config.isValid()) {
                        if (!config.equals(globalConfig)) {
                            Config oldConfig = globalConfig;
                            globalConfig = config;
                            invokeChange(oldConfig, globalConfig);
                            ignoreCache = true;
                            JSONCacheManager.getInstance().saveCache(CACHE_NAME, JSONUtils.toJson(globalConfig));
                        } else {
                            CLog.d("Sync config no changed");
                        }
                        currentTask = null;
                    } else {
                        retry();
                    }
                    if (config.mobileI != null){
                        CLog.json("tomcat",config.toJson());
                        Preferences.saveCloud(config.mobileI.toString());
                        CLog.i("test2", "saveCloud called");
                    }
                } else {
                    currentTask = null;
                }
            }
        }
    }
}
