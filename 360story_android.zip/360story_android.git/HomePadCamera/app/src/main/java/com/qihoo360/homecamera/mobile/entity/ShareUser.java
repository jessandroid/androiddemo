package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;


public class ShareUser extends Head implements Parcelable {


    private static final long serialVersionUID = 1L;



    public static final int ACCEPTED = 1;
	public static final int WAITING = 0;
	public static final int REJECTED = 2;


    @SerializedName("nickName")
    private String nickName;
    @SerializedName("accept")
    private int accept;
    @SerializedName("sqid")
    private String sqid;
    @SerializedName("imgUrl")
    private String imgUrl;
    @SerializedName("lastTime")
    private String lastTime;
    @SerializedName("totleNum")
    private int totleNum;
    @SerializedName("acceptTime")
    private String acceptTime;
    @SerializedName("shareCode")
    private String shareCode;
    @SerializedName("type")
    private int type;
    @SerializedName("nameType")
    private int nameType;
    @SerializedName("telephone")
    private String telephone;

    @SerializedName("loginEmail")
    private String loginEmail;
    @SerializedName("userName")
    private String userName;

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public int getAccept() {
        return accept;
    }

    public void setAccept(int accept) {
        this.accept = accept;
    }


    public String getSqid() {
        return sqid;
    }

    public void setSqid(String sqid) {
        this.sqid = sqid;
    }


    public String getLastTime() {
        return lastTime;
    }

    public void setLastTime(String lastTime) {
        this.lastTime = lastTime;
    }

    public int getTotleNum() {
        return totleNum;
    }

    public void setTotleNum(int totleNum) {
        this.totleNum = totleNum;
    }


    public String getAcceptTime() {
        return acceptTime;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public void setAcceptTime(String acceptTime) {
        this.acceptTime = acceptTime;
    }

    public String getShareCode() {
        return shareCode;
    }

    public void setShareCode(String shareCode) {
        this.shareCode = shareCode;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getNameType() {
        return nameType;
    }

    public void setNameType(int nameType) {
        this.nameType = nameType;
    }

    public String getLoginEmail() {
        return loginEmail;
    }

    public void setLoginEmail(String loginEmail) {
        this.loginEmail = loginEmail;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public ShareUser() {
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.nickName);
        dest.writeInt(this.accept);
        dest.writeString(this.sqid);
        dest.writeString(this.imgUrl);
        dest.writeString(this.lastTime);
        dest.writeInt(this.totleNum);
        dest.writeString(this.acceptTime);
        dest.writeString(this.shareCode);
        dest.writeInt(this.type);
        dest.writeInt(this.nameType);
    }

    protected ShareUser(Parcel in) {
        this.nickName = in.readString();
        this.accept = in.readInt();
        this.sqid = in.readString();
        this.imgUrl = in.readString();
        this.lastTime = in.readString();
        this.totleNum = in.readInt();
        this.acceptTime = in.readString();
        this.shareCode = in.readString();
        this.type = in.readInt();
        this.nameType = in.readInt();
    }

    public static final Creator<ShareUser> CREATOR = new Creator<ShareUser>() {
        public ShareUser createFromParcel(Parcel source) {
            return new ShareUser(source);
        }

        public ShareUser[] newArray(int size) {
            return new ShareUser[size];
        }
    };
}
