
package com.qihoo360.homecamera.mobile.db;

public interface IGrouper<GroupData, Entry> {
    GroupData getGroupData(Entry entry);

    boolean isSameGroup(GroupData lastEntryGroupData, GroupData currentEntryGroupData);
}
