package com.qihoo360.homecamera.machine.entity;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2015/7/28
 * Time: 16:24
 * To change this template use File | Settings | File Templates.
 */
public class ForShowExt implements Serializable{
    /**
     * 
     */
    private static final long serialVersionUID = -2847295575469572799L;
    @SerializedName("replayUrl")
    public String url;
}
