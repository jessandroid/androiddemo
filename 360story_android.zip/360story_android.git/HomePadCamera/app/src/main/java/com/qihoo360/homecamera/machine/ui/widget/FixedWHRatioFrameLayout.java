package com.qihoo360.homecamera.machine.ui.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.qihoo360.homecamera.mobile.utils.CLog;

public class FixedWHRatioFrameLayout extends FrameLayout {

    public final static float DEFAULT_SCALE_RATIO = 9f / 16f;

    private float mScaleRatio = DEFAULT_SCALE_RATIO;

    public FixedWHRatioFrameLayout(Context context) {
        super(context);
    }

    public FixedWHRatioFrameLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        if (getTag() != null) {
            try {
                mScaleRatio = Float.parseFloat(getTag().toString());
            } catch (NumberFormatException e) {
                mScaleRatio = DEFAULT_SCALE_RATIO;
            }
        }
    }

    @Override
    public void setTag(Object tag) {
        super.setTag(tag);
        CLog.e("setTag(tag="+tag+")");
        if(tag instanceof String){
            try{
                mScaleRatio = Float.parseFloat((String)tag);
                CLog.e("mScaleRatio = "+mScaleRatio);
                requestLayout();
            }catch (NumberFormatException e){
                CLog.e("setTag() e="+e);
            }
        }
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        heightMeasureSpec = MeasureSpec.makeMeasureSpec((int) (width * mScaleRatio), MeasureSpec.EXACTLY);
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        updateChildImageViewMaxSize();
    }

    private void updateChildImageViewMaxSize() {
        for (int i = 0; i < getChildCount(); ++i) {
            if (getChildAt(i) instanceof ImageView) {
                ((ImageView)getChildAt(i)).setMaxWidth(getMeasuredWidth());
                ((ImageView) getChildAt(i)).setMaxHeight(getMeasuredHeight());
            }
        }
    }

    public void setScaleRatio(float scaleRatio) {
        mScaleRatio = scaleRatio;
    }
}
