package com.qihoo360.homecamera.mobile.entity;

import com.google.gson.annotations.SerializedName;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/3/28
 * Time: 20:10
 * To change this template use File | Settings | File Templates.
 */
public class StoryGrandfather extends Head {

    @SerializedName("data")
    public StoryList storyList;
    @SerializedName("pageSize")
    public int pageSize;
}
