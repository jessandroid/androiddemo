
package com.qihoo360.homecamera.mobile.activity;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.Dialog;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.text.method.ScrollingMovementMethod;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.justalk.cloud.lemon.MtcApi;
import com.justalk.cloud.lemon.MtcCallConstants;
import com.qihoo.sdk.report.QHStatAgent;
import com.qihoo360.homecamera.mobile.ApplicationCamera;
import com.qihoo360.homecamera.mobile.BuildConfig;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.adapter.ChooseInviteWaysAdapter;
import com.qihoo360.homecamera.mobile.config.Const;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.db.AppUpdateWrapper;
import com.qihoo360.homecamera.mobile.db.PadInfoWrapper;
import com.qihoo360.homecamera.mobile.download.CallBack;
import com.qihoo360.homecamera.mobile.download.DownloadException;
import com.qihoo360.homecamera.mobile.download.DownloadManager;
import com.qihoo360.homecamera.mobile.download.DownloadRequest;
import com.qihoo360.homecamera.mobile.entity.CommonMessageEntity;
import com.qihoo360.homecamera.mobile.entity.DeviceCloudSettingSupport;
import com.qihoo360.homecamera.mobile.entity.FriendMessageInfoEntity;
import com.qihoo360.homecamera.mobile.entity.InnerMsg;
import com.qihoo360.homecamera.mobile.entity.MessageInfoEntity;
import com.qihoo360.homecamera.mobile.entity.ShareWayInfo;
import com.qihoo360.homecamera.mobile.entity.Update;
import com.qihoo360.homecamera.mobile.entity.UpdateInfo;
import com.qihoo360.homecamera.mobile.interfaces.IComm;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.ui.SystemBarTintManager;
import com.qihoo360.homecamera.mobile.ui.dialog.BaseDialogFactory;
import com.qihoo360.homecamera.mobile.ui.fragment.BaseFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.PadHeadFragment;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.DensityUtil;
import com.qihoo360.homecamera.mobile.utils.FileUtil;
import com.qihoo360.homecamera.mobile.utils.MD5Util;
import com.qihoo360.homecamera.mobile.utils.PhoneUtil;
import com.qihoo360.homecamera.mobile.utils.Preferences;
import com.qihoo360.homecamera.mobile.utils.UpdateUtil;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.widget.CamAlertDialog;
import com.qihoo360.homecamera.mobile.widget.JiaProgressDialog;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public abstract class BaseActivity extends AppCompatActivity implements IComm {

    protected final String TAG = this.getClass().getSimpleName();

    private ApplicationCamera mCamApplication;
    protected SystemBarTintManager tintManager;
    protected JiaProgressDialog mProgressDialog;
    private CamAlertDialog credentialsDialog;
    private List<CamAlertDialog> alertList = new ArrayList<CamAlertDialog>();
    private BroadcastReceiver credentialsReceiver;
    private BroadcastReceiver familyRequestReceiver;
    private BroadcastReceiver friendRequestReceiver;    //TODO:后续根据需求，看看能不能合并到familyRequestReceiver中
    private BroadcastReceiver masterAgreeAndrefreshListReceiver;
    private BroadcastReceiver lowBatteryReceiver;
    private BroadcastReceiver robotLockScreenReceiptReceiver;
    public CamAlertDialog tipsDialog;
    private CamAlertDialog customToast;
    private Handler mShowTipsDialogHandler = new Handler();
    private IOnTipsDialogDismiss mIOnTipsDialogDismiss;
    private TextView mToastTv;
    private ImageView mIconIv;
    private Runnable mDelayRunnable;
    protected HashMap<String, Dialog> mCamAlertDialogMap = new HashMap<String, Dialog>();
    private NotificationManager mNotifyManager;
    private BaseDialogFactory mCommonDialogFactory;
    private boolean mIsAllowFastClick = true;
    private boolean registFlag = false;
    public Bitmap mUserHeadBitmap;
    public String mUserHeadPath;
    public Uri mUserHeadUri;
    public File avatarCrop = null;
    private CamAlertDialog howlingDialog;
    //app升级
    protected CamAlertDialog updateAlertDialog;
    protected CamAlertDialog camAlertDialog;
    protected DownloadManager downloadManager;
    protected Update update;
    protected CamAlertDialog netDialog;
    protected CamAlertDialog progressDialog;
    protected ProgressBar progressBar;
    protected TextView cancleLoad;
    protected TextView updateTip;

    protected void switchMode(boolean speaker_mode) {
        CLog.d(TAG, "switchMode user speaker:" + speaker_mode);
        AudioManager audioManager = (AudioManager) this.getSystemService(Context.AUDIO_SERVICE);
        audioManager.setSpeakerphoneOn(speaker_mode);
    }

    protected void switchModeDefault() {
        AudioManager audioManager = (AudioManager) this.getSystemService(Context.AUDIO_SERVICE);
        audioManager.setSpeakerphoneOn(!audioManager.isWiredHeadsetOn());
        audioManager.setStreamVolume(AudioManager.STREAM_VOICE_CALL, audioManager.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL) / 2, 0);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Glide.get(this).clearMemory();

        mCamApplication = (ApplicationCamera) getApplication();
        mCamApplication.addActivity(this);
        mProgressDialog = new JiaProgressDialog(this);
        mProgressDialog.setCanceledOnTouchOutside(false);
        mProgressDialog.setMessage(getString(R.string.waiting));

        credentialsReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (credentialsDialog == null || !credentialsDialog.isShowing()) {
                    AccUtil.getInstance().removeUserToken();
//                    showCredentialsFailedDialog(11);
                }
            }
        };

        familyRequestReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String contextString = context.toString();
                contextString = contextString.substring(0, contextString.indexOf("@"));
                if (!TextUtils.isEmpty(Constants.TopActivityName) && Constants.TopActivityName.equals(contextString)) {
                    String json = intent.getStringExtra("message");
                    Gson gson = new Gson();
                    Type type = new TypeToken<CommonMessageEntity<MessageInfoEntity>>() {
                    }.getType();
                    CommonMessageEntity imageInfoListEntity = gson.fromJson(json, type);
                    showFamilyRequest(imageInfoListEntity);

//                    NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(BaseActivity.this);
//                    PendingIntent pendingIntent = PendingIntent.getActivity(BaseActivity.this, 0, getIntent(), 0);
//                    mBuilder.setSmallIcon(R.drawable.ic_launcher)
//                            .setTicker(imageInfoListEntity.data.reqUserInfo.nickName + "向您申请绑定" + imageInfoListEntity.data.ipcInfo.title + "的平板")
//                            .setContentTitle("申请绑定")
//                            .setContentText(imageInfoListEntity.data.reqUserInfo.nickName + "向您申请绑定" + imageInfoListEntity.data.ipcInfo.title + "的平板")
//                            .setContentIntent(pendingIntent);
//                    Notification mNotification = mBuilder.build();
//                    mNotification.icon = R.drawable.ic_launcher;
//                    mNotification.flags = Notification.FLAG_AUTO_CANCEL | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED;
//                    mNotification.when = System.currentTimeMillis();
//                    mNotifyManager.notify(1, mNotification);


                }
            }
        };

        friendRequestReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String contextString = context.toString();
                contextString = contextString.substring(0, contextString.indexOf("@"));
                if (!TextUtils.isEmpty(Constants.TopActivityName) && Constants.TopActivityName.equals(contextString)) {
                    String json = intent.getStringExtra("message");
                    Gson gson = new Gson();
                    Type type = new TypeToken<CommonMessageEntity<FriendMessageInfoEntity>>() {
                    }.getType();
                    CommonMessageEntity imageInfoListEntity = gson.fromJson(json, type);
                    showFriendRequest(imageInfoListEntity);
                }
            }
        };

        masterAgreeAndrefreshListReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
//                GlobalManager.getInstance().getCameraManager().asyncLoadMyCamera(0);
//                Intent relaxIntent = new Intent(MainActivity.this, PadRelaxActivity.class);
//                relaxIntent.putExtra("sn", intent.getExtras().getString("sn"));
//                relaxIntent.putExtra("is_master", false);
//                startActivity(relaxIntent);
                String contextString = context.toString();
                contextString = contextString.substring(0, contextString.indexOf("@"));
                if (!TextUtils.isEmpty(Constants.TopActivityName) && Constants.TopActivityName.equals(contextString)) {
                    Bundle bundle = intent.getExtras();
                    int mMessageType = bundle.getInt("message_type", -1);
                    MessageInfoEntity messageInfoEntity = bundle.getParcelable("message");
                    CommonMessageEntity<MessageInfoEntity> commonMessageEntity = new CommonMessageEntity<MessageInfoEntity>();
                    commonMessageEntity.id = Constants.CommonMessageList.size();
                    commonMessageEntity.data = messageInfoEntity;
                    switch (mMessageType) {
                        case CommonMessageEntity.MASTER_AGREE: {
                            commonMessageEntity.messageType = CommonMessageEntity.MASTER_AGREE;
                            showCommonMessageDialog(commonMessageEntity);
                            break;
                        }
                        case CommonMessageEntity.MASTER_ADD: {
                            commonMessageEntity.messageType = CommonMessageEntity.MASTER_ADD;
                            showCommonMessageDialog(commonMessageEntity);
                            break;
                        }
                        case CommonMessageEntity.KIBOT_UNBIND: {
                            commonMessageEntity.messageType = CommonMessageEntity.KIBOT_UNBIND;
                            if (Constants.TopActivityName.equals(VideoCallInnerActivity.class.getName())
                                    || Constants.TopActivityName.equals(OutgoingCallActivity.class.getName())) {
                                commonMessageEntity.hasShow = true;
                            } else {
                                showCommonMessageDialog(commonMessageEntity);
                            }
                            pushMessageNotify(commonMessageEntity);
                            break;
                        }
                        case CommonMessageEntity.ALREADY_BIND: {
                            commonMessageEntity.messageType = CommonMessageEntity.ALREADY_BIND;
                            showCommonMessageDialog(commonMessageEntity);
                            break;
                        }
                        case CommonMessageEntity.CANCEL_SHARE: {
                            commonMessageEntity.messageType = CommonMessageEntity.CANCEL_SHARE;
                            if (Constants.TopActivityName.equals(VideoCallInnerActivity.class.getName())
                                    || Constants.TopActivityName.equals(OutgoingCallActivity.class.getName())) {
                                commonMessageEntity.hasShow = true;
                            } else {
                                showCommonMessageDialog(commonMessageEntity);
                            }
                            pushMessageNotify(commonMessageEntity);
                            break;
                        }
                        case CommonMessageEntity.MASTER_REFUSE: {
                            commonMessageEntity.messageType = CommonMessageEntity.MASTER_REFUSE;
                            showMasterRefuse(commonMessageEntity);
                            break;
                        }
                        case CommonMessageEntity.FRIEND_AGREE: {
                            MessageInfoEntity friendResponseEntity = bundle.getParcelable("message");
                            commonMessageEntity.messageType = CommonMessageEntity.FRIEND_AGREE;
                            showFriendAgree(commonMessageEntity);
                        }
                        break;
                        case CommonMessageEntity.FRIEND_REJECT: {
                            MessageInfoEntity friendRejectEntity = bundle.getParcelable("message");
                            commonMessageEntity.messageType = CommonMessageEntity.FRIEND_AGREE;
                            showFriendReject(commonMessageEntity);
                        }
                        break;
                        case CommonMessageEntity.FRIEND_CANCEL: {
                            MessageInfoEntity friendCancelEntity = bundle.getParcelable("message");
                            commonMessageEntity.messageType = CommonMessageEntity.FRIEND_CANCEL;
                            showFriendCancel(commonMessageEntity);
                        }
                        break;
                    }
                }
            }
        };

        lowBatteryReceiver =  new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String contextString = context.toString();
                contextString = contextString.substring(0, contextString.indexOf("@"));
                if (!TextUtils.isEmpty(Constants.TopActivityName) && Constants.TopActivityName.equals(contextString)) {
                    Bundle bundle = intent.getExtras();
                    int mMessageType = bundle.getInt("message_type", -1);
                    MessageInfoEntity messageInfoEntity = bundle.getParcelable("message");
                    CommonMessageEntity<MessageInfoEntity> commonMessageEntity = new CommonMessageEntity<MessageInfoEntity>();
                    commonMessageEntity.id = Constants.CommonMessageList.size();
                    commonMessageEntity.data = messageInfoEntity;
                    showBatteryLowDialog(messageInfoEntity.message);
                }
            }
        };

        robotLockScreenReceiptReceiver =  new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String contextString = context.toString();
                contextString = contextString.substring(0, contextString.indexOf("@"));
                if (!TextUtils.isEmpty(Constants.TopActivityName) && Constants.TopActivityName.equals(contextString)) {
                    Bundle bundle = intent.getExtras();
                    int mMessageType = bundle.getInt("message_type", -1);
                    if (mMessageType == CommonMessageEntity.ROBOT_LOCK_SCREEN_RECEIPT){
                        MessageInfoEntity messageInfoEntity = bundle.getParcelable("message");
                        CommonMessageEntity<MessageInfoEntity> commonMessageEntity = new CommonMessageEntity<MessageInfoEntity>();
                        commonMessageEntity.id = Constants.CommonMessageList.size();
                        commonMessageEntity.data = messageInfoEntity;
                        commonMessageEntity.messageType = CommonMessageEntity.ROBOT_LOCK_SCREEN_RECEIPT;
                        pushMessageNotify(commonMessageEntity);
                    }
                }
            }
        };

        registerReceiver(familyRequestReceiver, new IntentFilter(Const.BROADCAST_FAMILY_REQUEST));
        registerReceiver(friendRequestReceiver, new IntentFilter(Const.BROADCAST_FRIEND_REQUEST));
        registerReceiver(masterAgreeAndrefreshListReceiver, new IntentFilter(Const.BROADCAST_MASTER_AGREE_AND_REFRESH_LIST));
        registerReceiver(lowBatteryReceiver, new IntentFilter(Const.BROADCAST_BATTERY_LOW));
        registerReceiver(robotLockScreenReceiptReceiver, new IntentFilter(Const.ROBOT_LOCK_SCREEN_RECEIPT));

        customToast =
                new CamAlertDialog(BaseActivity.this, R.style.CustomToast, true);

        mDelayRunnable = new Runnable() {
            @Override
            public void run() {
                if (tipsDialog != null) {
                    tipsDialog.dismiss();
                }
                if (mIOnTipsDialogDismiss != null) {
                    mIOnTipsDialogDismiss.onDismiss();
                }
            }
        };

        mNotifyManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
    }

    protected void pushMessageNotify(CommonMessageEntity messageEntity){
        return;
    }

    public void saveTopActivityName() {
        String contextString = this.toString();
        Constants.TopActivityName = contextString.substring(0, contextString.indexOf("@"));
    }

    public boolean isTaskTop() {
        String contextString = this.toString();
        String current = contextString.substring(0, contextString.indexOf("@"));
        return isTopActivy(current);
    }

    /**
     * 检测某ActivityUpdate是否在当前Task的栈顶
     */
    public boolean isTopActivy(String cmdName) {
        ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        List runningTaskInfos = manager.getRunningTasks(1);
        String cmpNameTemp = null;
        if (null != runningTaskInfos) {
            cmpNameTemp = manager.getRunningTasks(1).get(0).topActivity.getClassName();
        }

        if (null == cmpNameTemp)
            return false;
        return cmpNameTemp.equals(cmdName);
    }

    @Override
    public void onMessage(InnerMsg imsg) {
        if (isFinishing()) {
            return;
        }
    }

    public void setTintManagerQWork(boolean work) {
        tintManager = new SystemBarTintManager(this);
        tintManager.setStatusBarTintEnabled(work);
        tintManager.setNavigationBarTintEnabled(work);
        if (work == true) {
            tintManager.setTintColor(Color.parseColor("#00000000"));
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (familyRequestReceiver != null)
            unregisterReceiver(familyRequestReceiver);
        if (friendRequestReceiver != null)
            unregisterReceiver(friendRequestReceiver);
        if (masterAgreeAndrefreshListReceiver != null)
            unregisterReceiver(masterAgreeAndrefreshListReceiver);
        if (lowBatteryReceiver != null)
            unregisterReceiver(lowBatteryReceiver);
        if (robotLockScreenReceiptReceiver != null)
            unregisterReceiver(robotLockScreenReceiptReceiver);
        if (mProgressDialog != null) {
            mProgressDialog.dismiss();
            mProgressDialog = null;
        }
        if (tipsDialog != null) {
            tipsDialog.dismiss();
            tipsDialog = null;
        }
        if (popuWindow != null) {
            popuWindow.dismiss();
        }
        if (mCommonDialogFactory != null) {
            mCommonDialogFactory.destory();
            mCommonDialogFactory = null;
        }
        if (howlingDialog != null){
            howlingDialog.dismiss();
            howlingDialog = null;
        }
        if(updateAlertDialog!=null){
            updateAlertDialog.dismiss();
            updateAlertDialog=null;
        }
        for (int i = 0; i < alertList.size(); i++) {
            CamAlertDialog failedDialog = alertList.get(i);
            if (failedDialog != null) {
                failedDialog.dismiss();
            }
        }
        Iterator iter = mCamAlertDialogMap.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry entry = (Map.Entry) iter.next();
            Dialog camAlertDialog = (Dialog) entry.getValue();
            if (camAlertDialog != null) {
                camAlertDialog.dismiss();
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        QHStatAgent.onPause(this);
        if (registFlag) {
            unregisterReceiver(credentialsReceiver);
            registFlag = false;
        }
    }


    public JiaProgressDialog getProgressDialog() {
        return mProgressDialog;
    }

    public void dismissProcessDialog() {
        if (mProgressDialog != null) {
            if (mProgressDialog.isShowing() && !isFinishing()) {
                mProgressDialog.dismiss();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        QHStatAgent.onResume(this);
        String contextString = this.toString();
        contextString = contextString.substring(0, contextString.indexOf("@"));
        Constants.TopActivityName = contextString;
        registerReceiver(credentialsReceiver, new IntentFilter(Const.BROADCAST_APP_AGAIN));
        registFlag = true;
    }

    public void showCredentialsFailedDialog(int errorCode) {
        if (credentialsDialog == null) {
            CamAlertDialog.Builder builder = new CamAlertDialog.Builder(this);
            builder.setIsError(false);
            builder.setCancelable(false);
            builder.setMessage("[" + errorCode + "] " + getString(R.string.credentials_failed));
            builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface arg0, int arg1) {
                    mCamApplication.setJiaApplicationExit(true);
                    Intent i = new Intent(BaseActivity.this, LoginAndRegisterActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    mCamApplication.logout();
                    startActivity(i);
                }
            });
            credentialsDialog = builder.show();
            credentialsDialog.setOnKeyListener(new DialogInterface.OnKeyListener() {

                @Override
                public boolean onKey(DialogInterface arg0, int keyCode, KeyEvent event) {
                    if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                        if (credentialsDialog != null && credentialsDialog.isShowing()) {
                            credentialsDialog.dismiss();
                        }
                        mCamApplication.setJiaApplicationExit(true);
                        Intent i = new Intent(BaseActivity.this, LoginAndRegisterActivity.class);
                        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        mCamApplication.logout();
                        startActivity(i);
                        return true;
                    }
                    return false;
                }
            });
        }
    }

    public void showFailedDialog(String msg) {
        final CamAlertDialog.Builder builder = new CamAlertDialog.Builder(BaseActivity.this);
        builder.setIsError(false);
        builder.setCancelable(false);
        builder.setMessage(msg);
        builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg0, int arg1) {

            }
        });
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                final CamAlertDialog failedDialog = builder.show();
                alertList.add(failedDialog);
                failedDialog.setOnKeyListener(new DialogInterface.OnKeyListener() {

                    @Override
                    public boolean onKey(DialogInterface arg0, int keyCode, KeyEvent event) {
                        if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                            if (failedDialog != null && failedDialog.isShowing()) {
                                alertList.remove(failedDialog);
                                failedDialog.dismiss();
                            }
                            mCamApplication.setJiaApplicationExit(true);
                            return true;
                        }
                        return false;
                    }
                });
            }
        });
    }

    public void showBatteryLowDialog(String msg) {
        if (howlingDialog != null && howlingDialog.isShowing())
            return;
        CamAlertDialog.Builder builder = new CamAlertDialog.Builder(BaseActivity.this);
        builder.setMessage(msg);
        builder.setPositiveButton("我知道了", new CamAlertDialog.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        howlingDialog = builder.show();
    }


    public void onBack() {
        finish();
    }

    public void setFont(View... args) {
        /*for (int i = 0; i < args.length; i++) {
            if (args[i] instanceof TextView) {
                ((TextView) args[i]).setTypeface(SysConfig.GetGlobalFont());
            }
        }*/
    }

    private int setting_v1 = -1;

    public void showFamilyRequest(final CommonMessageEntity commonMessageEntity) {
        final MessageInfoEntity imageInfoListEntity = (MessageInfoEntity) commonMessageEntity.data;
        final String key = imageInfoListEntity.data.ipcInfo.sn + imageInfoListEntity.data.reqUserInfo.qid;
        CamAlertDialog.Builder builder = new CamAlertDialog.Builder(this);
        CamAlertDialog camAlertDialog = builder.show();
        camAlertDialog.setContentView(R.layout.remove_device_dialog);
        LinearLayout detailTipsLl = (LinearLayout) camAlertDialog.findViewById(R.id.ll_detail_tips);
        detailTipsLl.setVisibility(View.VISIBLE);
        TextView btnOK = (TextView) camAlertDialog.findViewById(R.id.remove_device_dialog_cancel);
        TextView titleTv = (TextView) camAlertDialog.findViewById(R.id.remove_device_dialog_tips);
        TextView contentTv = (TextView) camAlertDialog.findViewById(R.id.remove_device_dialog_content);
        contentTv.setText(getString(R.string.con_family, PhoneUtil.getPhoneContacts(this, imageInfoListEntity.data.reqUserInfo.phone, ((MessageInfoEntity) commonMessageEntity.data).data.getRelationTitle()), TextUtils.isEmpty(imageInfoListEntity.data.ipcInfo.title) ? "宝贝" : imageInfoListEntity.data.ipcInfo.title));
        titleTv.setText(getString(R.string.con_family_title));
        String supportStr = PadInfoWrapper.getInstance().getPadBySn(imageInfoListEntity.data.ipcInfo.sn).getSupport();
        Gson gson = new Gson();
        DeviceCloudSettingSupport ds = gson.fromJson(supportStr, DeviceCloudSettingSupport.class);
        if (!TextUtils.isEmpty(supportStr) && ds != null){
            setting_v1 = ds.getSetting_v1();
        }
        btnOK.setText(setting_v1 == 1 ? R.string.accept_apply_and_set : R.string.accept_apply);
        btnOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CLog.e("hyuan", "setting_v1=" + setting_v1 + ",Constants.IS_CALLING_OR_INNER:" + Constants.IS_CALLING_OR_INNER +
                        ",Constants.IS_CALLING:" + Constants.IS_CALLING  + ",Constants.IS_INNER" + Constants.IS_INNER);
                if (setting_v1 == 1){
                    if (Constants.IS_CALLING_OR_INNER || Constants.IS_CALLING || Constants.IS_INNER)
                    {
                        CamAlertDialog.Builder builder = new CamAlertDialog.Builder(BaseActivity.this);
                        builder.setMessage("即将跳转到其他页面，请确认是否结束当前会话。");
                        builder.setPositiveButton("确认", new CamAlertDialog.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //Intent intent = new Intent(BaseActivity.this, MainActivity.class);
                                //intent.putExtra(PrivateActivity.class.getSimpleName() + "Addfamily", true);
                                Intent intent = new Intent(BaseActivity.this, PrivateActivity.class);
                                intent.putExtra("sn", imageInfoListEntity.data.ipcInfo.sn);
                                intent.putExtra("qid", imageInfoListEntity.data.reqUserInfo.qid);
                                startActivity(intent);
                                GlobalManager.getInstance().getCommonManager().publishAction(Actions.Common.EXIT);
                                //finish();
                            }
                        });
                        builder.setNegativeButton("取消", new CamAlertDialog.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        });
                        builder.show();
                    } else {
                        //Intent intent = new Intent(BaseActivity.this, MainActivity.class);
                        //intent.putExtra(PrivateActivity.class.getSimpleName() + "Addfamily", true);
                        Intent intent = new Intent(BaseActivity.this, PrivateActivity.class);
                        intent.putExtra("sn", imageInfoListEntity.data.ipcInfo.sn);
                        intent.putExtra("qid", imageInfoListEntity.data.reqUserInfo.qid);
                        startActivity(intent);
                    }
                }
                GlobalManager.getInstance().getNeverKillManager().asyncShareResponse(imageInfoListEntity.data.ipcInfo.sn, imageInfoListEntity.data.reqUserInfo.qid, "1");
                /*Intent intent = new Intent(BaseActivity.this, SettingDetialActivity.class);
                intent.putExtra("key", Constants.SettingCameraItem.PAD_EDIT_FAMILY_ITEM);
                intent.putExtra("shareUserEntity", deviceInfo);
                startActivityForResult(intent, EDIT_FAMILY);*/

                Dialog camAlertDialog = mCamAlertDialogMap.get(key);
                if (camAlertDialog != null) {
                    camAlertDialog.dismiss();
                }
                if (mCamAlertDialogMap.containsKey(key)) {
                    mCamAlertDialogMap.remove(key);
                }
                close();
            }
        });
        TextView btnCancle = (TextView) camAlertDialog.findViewById(R.id.remove_device_dialog_ok);
        btnCancle.setText(R.string.refuse_apply);
        btnCancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GlobalManager.getInstance().getNeverKillManager().asyncShareResponse(imageInfoListEntity.data.ipcInfo.sn, imageInfoListEntity.data.reqUserInfo.qid, "0");
                Dialog camAlertDialog = mCamAlertDialogMap.get(key);
                if (camAlertDialog != null) {
                    camAlertDialog.dismiss();
                }
                mCamAlertDialogMap.remove(key);
                close();
            }
        });
        commonMessageEntity.hasShow = true;
        camAlertDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                mNotifyManager.cancel(commonMessageEntity.getId());
            }
        });
        if (mCamAlertDialogMap.containsKey(key)) {
            Dialog camAlertDialog1 = mCamAlertDialogMap.get(key);
            if (camAlertDialog1 != null) {
                camAlertDialog1.dismiss();
            }
        }
        mCamAlertDialogMap.put(imageInfoListEntity.data.ipcInfo.sn + imageInfoListEntity.data.reqUserInfo.qid, camAlertDialog);
    }

    public void showFriendRequest(final CommonMessageEntity commonMessageEntity) {
        //实现平板加平板的确认流程
        final FriendMessageInfoEntity friendMessageInfoEntity = (FriendMessageInfoEntity) commonMessageEntity.data;
        final String key = friendMessageInfoEntity.data.rqstIpcInfo.sn + friendMessageInfoEntity.data.rspsIpcInfo.sn + friendMessageInfoEntity.data.rqstUserInfo.qid;
        CamAlertDialog.Builder builder = new CamAlertDialog.Builder(this);
        builder.setTipMessage(getString(R.string.friend_request_content_1, PhoneUtil.getPhoneContacts(this, friendMessageInfoEntity.data.rqstUserInfo.phone, ""), TextUtils.isEmpty(friendMessageInfoEntity.data.rqstIpcInfo.title) ? "宝贝" : friendMessageInfoEntity.data.rqstIpcInfo.title, TextUtils.isEmpty(friendMessageInfoEntity.data.rspsIpcInfo.title) ? "宝贝" : friendMessageInfoEntity.data.rspsIpcInfo.title));
        builder.setTipMessageColor(0xFF666666);
        builder.setTitle(getString(R.string.tips_80));
        builder.setPositiveButton(R.string.accept,
                new CamAlertDialog.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        GlobalManager.getInstance().getNeverKillManager().asyncShareFriendResponse(friendMessageInfoEntity.data.rspsIpcInfo.sn, friendMessageInfoEntity.data.rqstIpcInfo.sn, "1");
                        Dialog camAlertDialog = mCamAlertDialogMap.get(key);
                        if (camAlertDialog != null) {
                            camAlertDialog.dismiss();
                        }
                        if (mCamAlertDialogMap.containsKey(key)) {
                            mCamAlertDialogMap.remove(key);
                        }
                        close();
                    }
                });
        builder.setNegativeButton(R.string.refuse,
                new CamAlertDialog.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        GlobalManager.getInstance().getNeverKillManager().asyncShareFriendResponse(friendMessageInfoEntity.data.rspsIpcInfo.sn, friendMessageInfoEntity.data.rqstIpcInfo.sn, "0");
                        Dialog camAlertDialog = mCamAlertDialogMap.get(key);
                        if (camAlertDialog != null) {
                            camAlertDialog.dismiss();
                        }
                        mCamAlertDialogMap.remove(key);
                        close();
                    }
                });
        CamAlertDialog camAlertDialog = builder.show();
        commonMessageEntity.hasShow = true;
        camAlertDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                mNotifyManager.cancel(commonMessageEntity.getId());
            }
        });
        if (mCamAlertDialogMap.containsKey(key)) {
            Dialog camAlertDialog1 = mCamAlertDialogMap.get(key);
            if (camAlertDialog1 != null) {
                camAlertDialog1.dismiss();
            }
        } else {
            mCamAlertDialogMap.put(friendMessageInfoEntity.data.rqstIpcInfo.sn + friendMessageInfoEntity.data.rspsIpcInfo.sn + friendMessageInfoEntity.data.rqstUserInfo.qid, camAlertDialog);
        }
    }

    public void showCommonMessageDialog(final CommonMessageEntity commonMessageEntity) {
        final MessageInfoEntity imageInfoListEntity = (MessageInfoEntity) commonMessageEntity.data;
        final String key = imageInfoListEntity.data.sn;
        Dialog dialog = showCommonDialog(imageInfoListEntity.title, imageInfoListEntity.message, "", getString(R.string.tips_29), "", false, new ICommonDialog() {
            @Override
            public void onRightButtonClick(boolean... isChecked) {
//                Intent relaxIntent = new Intent(BaseActivity.this, PadRelaxActivity.class);
//                relaxIntent.putExtra("sn", key);
//                relaxIntent.putExtra("is_master", false);
//                startActivity(relaxIntent);
                Dialog camAlertDialog = mCamAlertDialogMap.get(key);
                if (camAlertDialog != null) {
                    camAlertDialog.dismiss();
                }
                if (mCamAlertDialogMap.containsKey(key)) {
                    mCamAlertDialogMap.remove(key);
                }
                close();
            }

            @Override
            public void onLeftButtonClick(boolean... isChecked) {
            }

            @Override
            public void onDialogCancel() {
                mNotifyManager.cancel(commonMessageEntity.getId());
            }
        });
        dialog.setCancelable(false);
        commonMessageEntity.hasShow = true;
        if (mCamAlertDialogMap.containsKey(key)) {
            Dialog camAlertDialog1 = mCamAlertDialogMap.get(key);
            if (camAlertDialog1 != null) {
                camAlertDialog1.dismiss();
            }
        }
        mCamAlertDialogMap.put(imageInfoListEntity.data.sn, dialog);
    }

    public void showMasterRefuse(final CommonMessageEntity commonMessageEntity) {
        final MessageInfoEntity imageInfoListEntity = (MessageInfoEntity) commonMessageEntity.data;
        final String key = imageInfoListEntity.data.sn;
        Dialog dialog = showCommonDialog(getString(R.string.tips_68), imageInfoListEntity.message, "", getString(R.string.tips_29), "", false, new ICommonDialog() {
            @Override
            public void onRightButtonClick(boolean... isChecked) {
//                Intent relaxIntent = new Intent(BaseActivity.this, PadRelaxActivity.class);
//                relaxIntent.putExtra("sn", key);
//                relaxIntent.putExtra("is_master", false);
//                startActivity(relaxIntent);
                Dialog camAlertDialog = mCamAlertDialogMap.get(key);
                if (camAlertDialog != null) {
                    camAlertDialog.dismiss();
                }
                if (mCamAlertDialogMap.containsKey(key)) {
                    mCamAlertDialogMap.remove(key);
                }
                close();
            }

            @Override
            public void onLeftButtonClick(boolean... isChecked) {
            }

            @Override
            public void onDialogCancel() {
                mNotifyManager.cancel(commonMessageEntity.getId());
            }
        });
        dialog.setCancelable(false);
        commonMessageEntity.hasShow = true;
        if (mCamAlertDialogMap.containsKey(key)) {
            Dialog camAlertDialog1 = mCamAlertDialogMap.get(key);
            if (camAlertDialog1 != null) {
                camAlertDialog1.dismiss();
            }
        }
        mCamAlertDialogMap.put(imageInfoListEntity.data.sn, dialog);
    }

    public void showFriendAgree(final CommonMessageEntity commonMessageEntity) {
        final MessageInfoEntity friendResponseEntity = (MessageInfoEntity) commonMessageEntity.data;
        final String key = friendResponseEntity.data.rspsIpcInfo.title + friendResponseEntity.data.rqstIpcInfo.title + "1";

        Dialog dialog = showCommonDialog(getString(R.string.tips_81), getString(R.string.friend_agree_content, TextUtils.isEmpty(friendResponseEntity.data.rspsIpcInfo.title) ? "宝贝" : friendResponseEntity.data.rspsIpcInfo.title, TextUtils.isEmpty(friendResponseEntity.data.rqstIpcInfo.title) ? "宝贝" : friendResponseEntity.data.rqstIpcInfo.title), "", getString(R.string.share_success_know_label), "", false, new ICommonDialog() {
            @Override
            public void onRightButtonClick(boolean... isChecked) {
                Dialog camAlertDialog = mCamAlertDialogMap.get(key);
                if (camAlertDialog != null) {
                    camAlertDialog.dismiss();
                }
                if (mCamAlertDialogMap.containsKey(key)) {
                    mCamAlertDialogMap.remove(key);
                }
                close();
            }

            @Override
            public void onLeftButtonClick(boolean... isChecked) {
            }

            @Override
            public void onDialogCancel() {
                mNotifyManager.cancel(commonMessageEntity.getId());
            }
        });
        commonMessageEntity.hasShow = true;
        if (mCamAlertDialogMap.containsKey(key)) {
            Dialog camAlertDialog1 = mCamAlertDialogMap.get(key);
            if (camAlertDialog1 != null) {
                camAlertDialog1.dismiss();
            }
        }
        mCamAlertDialogMap.put(key, dialog);
    }

    public void showFriendReject(final CommonMessageEntity commonMessageEntity) {
        final MessageInfoEntity friendResponseEntity = (MessageInfoEntity) commonMessageEntity.data;
        final String key = friendResponseEntity.data.rspsIpcInfo.title + friendResponseEntity.data.rqstIpcInfo.title + "0";

        Dialog dialog = showCommonDialog(getString(R.string.tips_82), getString(R.string.friend_reject_content, TextUtils.isEmpty(friendResponseEntity.data.rspsIpcInfo.title) ? "宝贝" : friendResponseEntity.data.rspsIpcInfo.title, TextUtils.isEmpty(friendResponseEntity.data.rqstIpcInfo.title) ? "宝贝" : friendResponseEntity.data.rqstIpcInfo.title), "", getString(R.string.share_success_know_label), "", false, new ICommonDialog() {
            @Override
            public void onRightButtonClick(boolean... isChecked) {
                Dialog camAlertDialog = mCamAlertDialogMap.get(key);
                if (camAlertDialog != null) {
                    camAlertDialog.dismiss();
                }
                if (mCamAlertDialogMap.containsKey(key)) {
                    mCamAlertDialogMap.remove(key);
                }
                close();
            }

            @Override
            public void onLeftButtonClick(boolean... isChecked) {
            }

            @Override
            public void onDialogCancel() {
                mNotifyManager.cancel(commonMessageEntity.getId());
            }
        });
        commonMessageEntity.hasShow = true;
        if (mCamAlertDialogMap.containsKey(key)) {
            Dialog camAlertDialog1 = mCamAlertDialogMap.get(key);
            if (camAlertDialog1 != null) {
                camAlertDialog1.dismiss();
            }
        }
        mCamAlertDialogMap.put(key, dialog);
    }

    public void showFriendCancel(final CommonMessageEntity commonMessageEntity) {
        final MessageInfoEntity friendResponseEntity = (MessageInfoEntity) commonMessageEntity.data;
        final String key = friendResponseEntity.data.rspsIpcInfo.title + friendResponseEntity.data.rqstIpcInfo.title + "2";

        Dialog dialog = showCommonDialog("", getString(R.string.friend_cancel_content, TextUtils.isEmpty(friendResponseEntity.data.rspsIpcInfo.title) ? "宝贝" : friendResponseEntity.data.rspsIpcInfo.title, TextUtils.isEmpty(friendResponseEntity.data.rqstIpcInfo.title) ? "宝贝" : friendResponseEntity.data.rqstIpcInfo.title), "", getString(R.string.share_success_know_label), "", false, new ICommonDialog() {
            @Override
            public void onRightButtonClick(boolean... isChecked) {
                Dialog camAlertDialog = mCamAlertDialogMap.get(key);
                if (camAlertDialog != null) {
                    camAlertDialog.dismiss();
                }
                if (mCamAlertDialogMap.containsKey(key)) {
                    mCamAlertDialogMap.remove(key);
                }
                close();
            }

            @Override
            public void onLeftButtonClick(boolean... isChecked) {
            }

            @Override
            public void onDialogCancel() {
                mNotifyManager.cancel(commonMessageEntity.getId());
            }
        });
        commonMessageEntity.hasShow = true;
        if (mCamAlertDialogMap.containsKey(key)) {
            Dialog camAlertDialog1 = mCamAlertDialogMap.get(key);
            if (camAlertDialog1 != null) {
                camAlertDialog1.dismiss();
            }
        }
        mCamAlertDialogMap.put(key, dialog);
    }

    public void close() {

    }

    public void hideTipsDialog() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (tipsDialog != null) {
                    mShowTipsDialogHandler.removeCallbacks(mDelayRunnable);
                    tipsDialog.dismiss();
                }
            }
        });
    }

    public void showTipsDialog(String msg, int icon, int delay, boolean rotate) {
        showTipsDialog(msg, icon, delay);
        if (rotate) {
            Animation anim = AnimationUtils.loadAnimation(this, R.anim.rotate_icon);
            mIconIv.startAnimation(anim);
        }
    }

    public void showTipsDialog(String msg, int icon, int delay, boolean rotate, IOnTipsDialogDismiss iOnTipsDialogDismiss) {
        mIOnTipsDialogDismiss = iOnTipsDialogDismiss;
        showTipsDialog(msg, icon, delay);
        if (rotate) {
            Animation anim = AnimationUtils.loadAnimation(this, R.anim.rotate_icon);
            mIconIv.startAnimation(anim);
        }
    }

    public void showTipsDialog(String msg, int icon, boolean rotate) {
        showTipsDialog(msg, icon);
        if (rotate) {
            Animation anim = AnimationUtils.loadAnimation(this, R.anim.rotate_icon);
            mIconIv.startAnimation(anim);
        }
    }

    public void showTipsDialogDontDismiss(final String msg, final int icon, boolean rotate) {
        showTipsDialogDontDismiss(msg, icon, rotate, -80);
    }

    public void showTipsDialogDontDismiss(final String msg, final int icon, boolean rotate, final int nOffset) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (tipsDialog != null) {
                    tipsDialog.dismiss();
                }
                tipsDialog =
                        new CamAlertDialog(BaseActivity.this, R.style.NewDialog, true);
                Window w = tipsDialog.getWindow();
                WindowManager.LayoutParams lp = w.getAttributes();

                if (nOffset > 0) {
                    lp.y = DensityUtil.dip2px(nOffset);
                } else {
                    lp.y = -DensityUtil.dip2px(Math.abs(nOffset));
                }

                View content = getLayoutInflater().inflate(R.layout.tips_toast_dialog, null);
                mToastTv = (TextView) content.findViewById(R.id.stv_toast);
                mIconIv = (ImageView) content.findViewById(R.id.iv_icon);
                mToastTv.setText(msg);
                mIconIv.setImageResource(icon);
                tipsDialog.setContentView(content);
                tipsDialog.setCancelable(false);
                tipsDialog.setCanceledOnTouchOutside(false);
                tipsDialog.show();
            }
        });

        if (rotate) {
            Animation anim = AnimationUtils.loadAnimation(this, R.anim.rotate_icon);
            mIconIv.startAnimation(anim);
        }
    }


    public void showTipsDialog(String msg, int icon, int delay) {
        showTipsDialog(msg, icon);
        mShowTipsDialogHandler.postDelayed(mDelayRunnable, delay);
    }

    public void showTipsDialog(final String msg, final int icon) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (tipsDialog != null) {
                    tipsDialog.dismiss();
                }
                tipsDialog =
                        new CamAlertDialog(BaseActivity.this, R.style.NewDialog, true);
                Window w = tipsDialog.getWindow();
                WindowManager.LayoutParams lp = w.getAttributes();
                lp.y = -DensityUtil.dip2px(80);
                View content = getLayoutInflater().inflate(R.layout.tips_toast_dialog, null);
                mToastTv = (TextView) content.findViewById(R.id.stv_toast);
                mIconIv = (ImageView) content.findViewById(R.id.iv_icon);
                mToastTv.setText(msg);
                mIconIv.setImageResource(icon);
                tipsDialog.setContentView(content);
                tipsDialog.setCancelable(true);
                tipsDialog.setCanceledOnTouchOutside(false);
                tipsDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                    @Override
                    public void onCancel(DialogInterface dialogInterface) {
                        mShowTipsDialogHandler.removeCallbacks(mDelayRunnable);
                    }
                });
                tipsDialog.show();
            }
        });

    }

    public void showHowlingDialog(){
        if (howlingDialog != null && howlingDialog.isShowing())
            return;
        CamAlertDialog.Builder builder = new CamAlertDialog.Builder(BaseActivity.this);
        builder.setMessage(R.string.tips_70);
        builder.setPositiveButton("我知道了", new CamAlertDialog.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Preferences.setIsShowHowlingTips(true);
            }
        });
        howlingDialog = builder.show();
    }

    public void setTipsDialogText(String msg) {
        mToastTv.setText(msg);
    }


    public void showCustomToast(final String msg, final int duration) {
        if (!TextUtils.isEmpty(msg)) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    View content = LayoutInflater.from(BaseActivity.this).inflate(R.layout.custom_toast, null);
                    TextView toastTv = (TextView) content.findViewById(R.id.tv_msg);
                    toastTv.setText(msg);
                    Toast toast = new Toast(BaseActivity.this);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.setDuration(duration);
                    toast.setView(content);
                    toast.show();
                }
            });
        }
    }

    public interface IOnTipsDialogDismiss {
        public void onDismiss();
    }

    protected void setWindow() {
        try {
            Window window = getWindow();
            WindowManager.LayoutParams attrs = window.getAttributes();
            attrs.flags |= WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                    | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                    | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                    | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED;
            attrs.systemUiVisibility = View.SYSTEM_UI_FLAG_LOW_PROFILE;
            window.setAttributes(attrs);

            final int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            window.getDecorView().setSystemUiVisibility(flags);


            final View decorView = window.getDecorView();
            decorView
                    .setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener() {

                        @Override
                        public void onSystemUiVisibilityChange(int visibility) {
                            if ((visibility & View.SYSTEM_UI_FLAG_FULLSCREEN) == 0) {
                                decorView.setSystemUiVisibility(flags);
                            }
                        }
                    });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected boolean judgeNeedProcess(Intent intent, int mCallId) {
        boolean result = true;
        try {
            String info = intent.getStringExtra(MtcApi.EXTRA_INFO);
            CLog.json("phone_call", info);
            JSONObject json = (JSONObject) new JSONTokener(info).nextValue();
            int callId = json.getInt(MtcCallConstants.MtcCallIdKey);
            if (callId != mCallId) {
                CLog.justalkFile("judgeNeedProcess，callId不符舍弃消息" + callId + "：" + mCallId);
                return false;
            }
        } catch (JSONException e) {
            e.printStackTrace();
        } finally {
            return result;
        }
    }

    public Dialog showCommonDialog(String title, String content, String leftButton, String rightButton, final String checkContent, boolean needCheckBox, final ICommonDialog iCommonDialog) {
        return showCommonDialog(title, content, leftButton, rightButton, new ArrayList<String>() {{
            add(checkContent);
        }}, needCheckBox, iCommonDialog);
    }

    public Dialog showCommonDialog(String title, String content, String leftButton, String rightButton, List<String> checkContent, boolean needCheckBox, final ICommonDialog iCommonDialog) {
        if (TextUtils.isEmpty(title)) {
            title = getString(R.string.tips_47);
        }
        if (mCommonDialogFactory != null) {
            mCommonDialogFactory.destory();
            mCommonDialogFactory = null;
        }
        mCommonDialogFactory = new BaseDialogFactory(this, R.layout.remove_device_dialog);
        Dialog mDialog = mCommonDialogFactory.createDialog();
        mCommonDialogFactory.setMarginLeftAndRight(46f);
        mDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {

            @Override
            public void onCancel(DialogInterface dialog) {
                iCommonDialog.onDialogCancel();
                mCommonDialogFactory = null;
            }
        });
        View view = mCommonDialogFactory.getDialogContentView();
        RelativeLayout okZone = (RelativeLayout) view.findViewById(R.id.remove_device_dialog_ok_zone);
        TextView btnOK = (TextView) view.findViewById(R.id.remove_device_dialog_ok);
        RelativeLayout cancleZone = (RelativeLayout) view.findViewById(R.id.remove_device_dialog_cancel_zone);
        TextView btnCancle = (TextView) view.findViewById(R.id.remove_device_dialog_cancel);
        TextView titleTv = (TextView) view.findViewById(R.id.remove_device_dialog_tips);
        TextView contentTv = (TextView) view.findViewById(R.id.remove_device_dialog_content);
        final CheckBox saveDataCb = (CheckBox) view.findViewById(R.id.cb_save_data);
        LinearLayout checkAreaLl = (LinearLayout) view.findViewById(R.id.ll_check_area);
        TextView checkContentTv = (TextView) view.findViewById(R.id.tv_check_content);
        final CheckBox saveDataCb1 = (CheckBox) view.findViewById(R.id.cb_save_data_1);
        LinearLayout checkAreaLl1 = (LinearLayout) view.findViewById(R.id.ll_check_area_1);
        TextView checkContentTv1 = (TextView) view.findViewById(R.id.tv_check_content_1);
        View dividerView = findViewById(R.id.divider);
        if (TextUtils.isEmpty(title)) {
            titleTv.setVisibility(View.GONE);
        } else {
            titleTv.setText(title);
        }
        if (TextUtils.isEmpty(leftButton)) {
            Utils.ensureVisbility(View.GONE, okZone, dividerView);
            cancleZone.setBackgroundResource(R.drawable.pop_win_round_bg_left_right);
        } else {
            btnOK.setText(leftButton);
        }
        contentTv.setText(content);
        btnCancle.setText(rightButton);
        if (checkContent.size() > 0) {
            checkContentTv.setText(checkContent.get(0));
            checkAreaLl.setVisibility(needCheckBox ? View.VISIBLE : View.GONE);
            if (checkContent.size() > 1) {
                checkContentTv1.setText(checkContent.get(1));
                checkAreaLl1.setVisibility(needCheckBox ? View.VISIBLE : View.GONE);
            }
        }

        btnOK.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                mCommonDialogFactory.destory();
                iCommonDialog.onLeftButtonClick(saveDataCb.isChecked(), saveDataCb1.isChecked());
            }
        });
        btnCancle.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                mCommonDialogFactory.destory();
                iCommonDialog.onRightButtonClick(saveDataCb.isChecked(), saveDataCb1.isChecked());
            }
        });
        mCommonDialogFactory.show();
        return mDialog;
    }

    public interface ICommonDialog {

        public void onRightButtonClick(boolean... isChecked);

        public void onLeftButtonClick(boolean... isChecked);

        public void onDialogCancel();
    }

    private View mOutsideTouchArea;
    private RelativeLayout mRlCancelArea;
    private View contentView;
    private PopupWindow popuWindow;

    public interface IOnChooseCallback {
        public void onItemChoose(int pos);
    }

    @Override
    public void onBackPressed() {
        if (popuWindow != null && popuWindow.isShowing()) {
            popuWindow.dismiss();
        } else {
            super.onBackPressed();
        }
    }

    public void initPopupWindow(List<ShareWayInfo> list, final IOnChooseCallback iOnChooseCallback) {

        if (popuWindow == null) {
            LayoutInflater mLayoutInflater = LayoutInflater.from(this);
            contentView = mLayoutInflater.inflate(getSharePopWinLayoutId(), null);
            popuWindow = new PopupWindow(contentView, ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT, true);
        }
        mOutsideTouchArea = contentView.findViewById(R.id.outside_touch_area);
        mRlCancelArea = (RelativeLayout) contentView.findViewById(R.id.rl_cancel_area);
        GridView cameraShareGv = (GridView) contentView.findViewById(R.id.video_share_grid_layout);
        mOutsideTouchArea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popuWindow.dismiss();
            }
        });
        mRlCancelArea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                popuWindow.dismiss();
            }
        });
        popuWindow.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        final ChooseInviteWaysAdapter adapter = new ChooseInviteWaysAdapter(this, list, list.size());
        cameraShareGv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                iOnChooseCallback.onItemChoose(i);
                popuWindow.dismiss();
            }
        });
        cameraShareGv.setNumColumns(list.size());
        cameraShareGv.setAdapter(adapter);
    }

    private int getSharePopWinLayoutId() {
        //获取添加成员方式的弹窗位置
        return R.layout.select_share_style;
    }

    protected int getSharePopWinGravity() {
        return Gravity.BOTTOM;
    }

    public void showPopupWindow(View parent) {
        popuWindow.setAnimationStyle(R.style.PopupWindowAnim);
        popuWindow.setOutsideTouchable(true);
        popuWindow.setFocusable(true);
        popuWindow.showAtLocation((View) parent.getParent(), Gravity.CENTER | Gravity.CENTER_HORIZONTAL, 0, 0);
        popuWindow.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        popuWindow.update();
        popuWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                backgroundAlpha(1f);
            }
        });
        backgroundAlpha(0.6f);
    }

    public void backgroundAlpha(float bgAlpha) {
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.alpha = bgAlpha; //0.0-1.0
        getWindow().setAttributes(lp);
    }

    private long mLastClickTime;

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        try {
            if (!mIsAllowFastClick) {
                if (ev.getAction() == MotionEvent.ACTION_DOWN || ev.getAction() == MotionEvent.ACTION_POINTER_UP
                        || ev.getAction() == 261 || ev.getAction() == 262) {
                    long currTime = System.currentTimeMillis();
                    if (currTime > mLastClickTime) {
                        if (currTime - mLastClickTime > 300) {
                            mLastClickTime = currTime;
                        } else {
                            ev.setAction(MotionEvent.ACTION_CANCEL);
                        }
                    } else {
                        mLastClickTime = currTime;
                    }
                    return super.dispatchTouchEvent(ev);
                }
            } else {
                return super.dispatchTouchEvent(ev);
            }
            return super.dispatchTouchEvent(ev);
        } catch (Exception e) {
            e.printStackTrace();
            return true;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case BaseFragment.REQUEST_CHANGE_AVATAR: {
                if (resultCode == Activity.RESULT_OK && data != null) {
                    String fileName = data.getStringExtra("result");
                    if (!TextUtils.isEmpty(fileName)) {
                        // Uri uri = Uri.fromFile(new File(fileName));
                        File tmp = new File(fileName);

                        String dir = tmp.getParentFile().getAbsolutePath();
                        String oldName = tmp.getName();
                        String newTmp = oldName + System.currentTimeMillis();

                        File tmpFile = new File(dir, newTmp);
                        avatarCrop = tmpFile;
                        intoImageCROP(getImageContentUri(getApplicationContext(), fileName), tmpFile.getAbsolutePath());
                    }
                }
                break;
            }
            case PadHeadFragment.REQUEST_CROP_PHOTO: {
                if (mUserHeadUri != null && resultCode == RESULT_OK) {
                        mUserHeadPath = mUserHeadUri.getPath();
                    }



//                if (resultCode == Activity.RESULT_OK && data != null) {
//                    Bundle extras = data.getExtras();
//                    if (extras != null) {
//                        if (data.getParcelableExtra("data") instanceof Bitmap) {
//                            mUserHeadBitmap = data.getParcelableExtra("data");
//                        } else {
//                            File file = new File(data.getStringExtra("data"));
//                            try {
//                                mUserHeadBitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(Uri.fromFile(file)));
//                            } catch (FileNotFoundException e) {
//                                e.printStackTrace();
//                            } catch (Exception e) {
//                                e.printStackTrace();
//                            }
//                        }
//                    } else {
//                        if (android.os.Build.VERSION.SDK_INT >= 21) {
//                            String tmpPath = data.getDataString();
//                            if (!TextUtils.isEmpty(tmpPath)) {
//                                Uri u = Uri.parse(tmpPath);
//                                String path = u.getPath();
//                                try {
//                                    mUserHeadBitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(u));
//                                } catch (FileNotFoundException e) {
//                                    e.printStackTrace();
//                                } catch (Exception e) {
//                                    e.printStackTrace();
//                                }
//                            }
//                        }
//                    }
//                }
                break;
            }
            default:
                break;
        }
    }

    protected void intoImageCROP(Uri uri, String path) {
        mUserHeadUri = Uri.fromFile(new File(path));
        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.setDataAndType(uri, "image/*");
        // 下面这个crop=true是设置在开启的Intent中设置显示的VIEW可裁剪
        intent.putExtra("crop", "true");
        // aspectX aspectY 是宽高的比例
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);
        // outputX outputY 是裁剪图片宽高
        intent.putExtra("outputX", 100);
        intent.putExtra("outputY", 100);
        intent.putExtra("return-data", false);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, mUserHeadUri); // pass temp file
//        if (android.os.Build.VERSION.SDK_INT >= 21) {
//        }

        if (Utils.isIntentSafe(intent)) {
            startActivityForResult(intent, PadHeadFragment.REQUEST_CROP_PHOTO);
        } else {
            CameraToast.show("您的手机暂不支持裁剪，将后续支持，请谅解！", Toast.LENGTH_SHORT);
        }
    }

    public static Uri getImageContentUri(Context context, String absPath) {
        Uri resultUri = null;
        CLog.i("test2", "getImageContentUri: " + absPath);
        Cursor cursor = null;
        try {
            cursor = context.getContentResolver().query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                    , new String[]{
                            MediaStore.Images.Media._ID
                    }, MediaStore.Images.Media.DATA + "=? "
                    , new String[]{
                            absPath
                    }, null);

            if (cursor != null && cursor.moveToFirst()) {
                int id = cursor.getInt(cursor.getColumnIndex(MediaStore.MediaColumns._ID));
                resultUri = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, Integer.toString(id));
                return resultUri;

            } else if (!absPath.isEmpty()) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DATA, absPath);
                return resultUri = context.getContentResolver().insert(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            Utils.close(cursor);
        }
        return resultUri;

    }

    //app升级
    @TargetApi(Build.VERSION_CODES.M)
    public void showUpdateDailog(final Update update) {
        updateAlertDialog = new CamAlertDialog.Builder(this).create();
        View view = LayoutInflater.from(Utils.context).inflate(R.layout.update_layout, null);
        updateAlertDialog.setContentView(view);
        updateAlertDialog.setCancelable(false);

        TextView desTextVeiw = (TextView) view.findViewById(R.id.desc);
        TextView updateText = (TextView) view.findViewById(R.id.update_name);
        desTextVeiw.setMovementMethod(new ScrollingMovementMethod());
        updateText.setText(getString(R.string.last_version, update.result.version));
        desTextVeiw.setText(update.result.getDescription());

        final RelativeLayout sure = (RelativeLayout) view.findViewById(R.id.sure);
        final RelativeLayout cancel = (RelativeLayout) view.findViewById(R.id.cancel);
        final TextView negativeTip = (TextView) view.findViewById(R.id.negative_btn);
        final TextView positionTip = (TextView) view.findViewById(R.id.positive_btn);

        // 强制升级的时候，显示退出应用
        if (update.result.getIsForce() == Update.FORCE_TYPE_FORCE) {
            negativeTip.setText("退出应用");
        } else {
            negativeTip.setText("以后再说");
        }

        sure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                updateAlertDialog.dismiss();

                if (!TextUtils.isEmpty(update.result.getLocalpath())) {//之前已经下载过

                    //先进行md5检验
                    try {
                        if (TextUtils.equals(MD5Util.md5Hex(new File(update.result.getLocalpath())),
                                update.result.getMd5())) {
                            Intent intent = new Intent();
                            intent.setAction(android.content.Intent.ACTION_VIEW);
                            intent.setDataAndType(Uri.parse("file://" + update.result.getLocalpath()),
                                    "application/vnd.android.package-archive");
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                        } else {
                            CameraToast.show("安装包已损坏，请到官网下载安装！", Toast.LENGTH_SHORT);
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {//如果没有下载好，有弹窗了，那就是wap网络下或者强制升级
                    if (update.result.isForce == Update.FORCE_TYPE_FORCE) {//强制升级
                        if (Utils.isNetworkAvailable(BaseActivity.this)) {
                            if (Utils.isWifi(Utils.context)) {
                                downLoadApk(update);
                            } else {
                                //如果是wap网络，则需要弹窗提示用户继续使用wap网络下载
                                showWapLoad(update);
                            }
                        } else {
                            showLoadDialog();
                            updateTip.setText("下载过程遇到问题");
                        }
                    } else {
                        if (Utils.isNetworkAvailable(BaseActivity.this)) {
                            if (Utils.isWifi(Utils.context)) {//正常不会走这一步
                                //TODO 开启服务下载
                                UpdateUtil updateUtil = new UpdateUtil(BaseActivity.this, update);
                                updateUtil.downLoadApk();
                            } else {
                                //如果是wap网络，则需要弹窗提示用户继续使用wap网络下载
                                showWapLoad(update);
                            }
                        } else {
                            CameraToast.show(getString(R.string.network_disabled), Toast.LENGTH_SHORT);
                        }
                    }
                }
            }
        });

        //以后再说
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateAlertDialog.dismiss();
                // 强制升级的时候，退出应用
                if (update.getResult().isForce == Update.FORCE_TYPE_FORCE) {
                    ((ApplicationCamera) Utils.context).AppExit();
                }
            }
        });
        updateAlertDialog.show();
    }

    public void showWapLoad(final Update update) {

        if (!Constants.HAS_SHOW_NET_TIPS) {
            Dialog dialog = showCommonDialog("", getString(R.string.tips_44), getString(R.string.tips_45),
                    getString(R.string.tips_46), "", false,
                    new BaseActivity.ICommonDialog() {
                        @Override
                        public void onRightButtonClick(boolean... isChecked) {
                            Constants.HAS_SHOW_NET_TIPS = true;
                            if (update.getResult().isForce == Update.FORCE_TYPE_FORCE) {//强制升级
                                downLoadApk(update);
                            } else {
                                UpdateUtil upUtil = new UpdateUtil(BaseActivity.this, update);
                                upUtil.downLoadApk();
                            }
                        }

                        @Override
                        public void onLeftButtonClick(boolean... isChecked) {

                        }

                        @Override
                        public void onDialogCancel() {
                        }
                    });
            dialog.setCancelable(false);
        } else {
            if (update.getResult().isForce == Update.FORCE_TYPE_FORCE) {//强制升级
                downLoadApk(update);
            } else {
                UpdateUtil upUtil = new UpdateUtil(BaseActivity.this, update);
                upUtil.downLoadApk();
            }
        }

    }

    public void downLoadApk(Update update) {
        UpdateInfo info = update.result;
        Preferences.saveNewVersion(update.getResult().getVersion() + "&" + BuildConfig.VERSION_CODE);//保存更新信息
        if (!TextUtils.isEmpty(info.downUrl)) {
            DownloadRequest request = new DownloadRequest.Builder()
                    .setTitle(update.result.getTitle())
                    .setUri(info.downUrl)
                    .setFolder(FileUtil.getInstance().getDownloadFile())
                    .setNeedCookie(false)
                    .build();
            downloadManager = DownloadManager.getInstance();
            downloadManager.download(request, "apk", new DownloadCallback(update));
        }
    }

    private class DownloadCallback implements CallBack {
        Update update;

        public DownloadCallback(Update update) {
            this.update = update;
        }

        @Override
        public void onStarted() {
            CLog.e("zt", "mainactivity down onStarted");
            if (update.getResult().isForce == Update.FORCE_TYPE_FORCE) {
                showLoadDialog();
            }
        }

        @Override
        public void onConnecting() {
        }

        @Override
        public void onConnected(long total, boolean isRangeSupport) {

        }

        @Override
        public void onProgress(long finished, long total, int progress) {
            CLog.e("zt", "down progress:" + progress);
            if (update.getResult().isForce == Update.FORCE_TYPE_FORCE) {
                progressBar.setProgress(progress);
                updateTip.setText("正在下载" + progress + "%");
            }
        }

        @Override
        public void onCompleted() {

            if (update.getResult().isForce == Update.FORCE_TYPE_FORCE) {
                progressDialog.dismiss();
                update.getResult().setLocalpath(
                        FileUtil.getInstance().getDownloadFile().getAbsolutePath() + "/" + update.result.getTitle());
                String path = FileUtil.getInstance().getDownloadFile().getAbsolutePath() + "/"
                        + update.result.getTitle();
                //进行MD5验证
                try {
                    if (TextUtils.equals(MD5Util.md5Hex(new File(update.result.getLocalpath())),
                            update.result.getMd5())) {
                        // 写入db todo
                        Intent intent = new Intent();
                        intent.setAction(android.content.Intent.ACTION_VIEW);
                        intent.setDataAndType(Uri.parse("file://" + path), "application/vnd.android.package-archive");
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                    } else {
                        ((ApplicationCamera) Utils.context).AppExit();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
                update.getResult().setLocalpath(
                        FileUtil.getInstance().getDownloadFile().getAbsolutePath() + "/" + update.result.getTitle());
                AppUpdateWrapper.getInstance().deleteInfo();
                AppUpdateWrapper.getInstance().write(update);
            }
        }

        @Override
        public void onDownloadPaused() {

        }

        @Override
        public void onDownloadCanceled() {

        }

        @Override
        public void onFailed(DownloadException e) {
            CLog.e("zt", "error is :" + e.getErrorMessage());
        }
    }

    private void showLoadDialog() {
        progressDialog = new CamAlertDialog.Builder(BaseActivity.this).create();
        progressDialog.getWindow().setGravity(Gravity.CENTER);
        View view = LayoutInflater.from(Utils.context).inflate(R.layout.update_item, null);
        progressDialog.setContentView(view);
        progressDialog.setCancelable(false);
        progressBar = (ProgressBar) view.findViewById(R.id.load_progress);
        updateTip = (TextView) view.findViewById(R.id.load_tip);
        cancleLoad = (TextView) view.findViewById(R.id.cancle_load);
        cancleLoad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.dismiss();
                downloadManager.cancel("apk");
                ((ApplicationCamera) Utils.context).AppExit();
            }
        });
        progressDialog.show();
    }
}
