package com.qihoo360.homecamera.machine.popwin;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;

import com.qihoo360.homecamera.machine.fragment.StoryPlayerFragment;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.widget.TextViewWithFont;

/**
 * Created by lixin3-s on 2016/11/15.
 */
public abstract class BasePopWin {

    private PopupWindow mPopuWindow;
    private StoryPlayerFragment mFragment;
    protected View contentView;
    private View mOutsideTouchArea;
    protected Activity context;
    protected View mRlCancelArea;
    private View mParentView;

    public BasePopWin(Activity context, View parent) {
        this.context = context;
        this.mParentView = parent;
        initPopupWindow();
    }

    protected void initPopupWindow() {
        if (mPopuWindow == null) {
            LayoutInflater mLayoutInflater = LayoutInflater.from(context);
            contentView = mLayoutInflater.inflate(getLayoutId(), null);
            mPopuWindow = new PopupWindow(contentView, ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT);
        }

        ColorDrawable cd = new ColorDrawable(0x000000);
        mPopuWindow.setBackgroundDrawable(cd);
        mPopuWindow.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        mPopuWindow.setOutsideTouchable(true);
        mPopuWindow.setFocusable(true);
        mPopuWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                backgroundAlpha(1f);
            }
        });
//        mPopuWindow.showAtLocation((View) parent.getParent(), Gravity.CENTER | Gravity.CENTER_HORIZONTAL, 0, 0);
//        mPopuWindow.update();

        mOutsideTouchArea = contentView.findViewById(R.id.outside_touch_area);
        mRlCancelArea =  contentView.findViewById(R.id.rl_cancel_area);
        mOutsideTouchArea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mPopuWindow.dismiss();
            }
        });
        mRlCancelArea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mPopuWindow.dismiss();
            }
        });
        initView();
    }
    public void backgroundAlpha(float bgAlpha) {
        WindowManager.LayoutParams lp = context.getWindow().getAttributes();
        lp.alpha = bgAlpha; //0.0-1.0
        context.getWindow().setAttributes(lp);
    }

    public void showPopWin() {
        mPopuWindow.showAtLocation((View) mParentView.getParent(), Gravity.CENTER | Gravity.CENTER_HORIZONTAL, 0, 0);
        mPopuWindow.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        mPopuWindow.update();
        backgroundAlpha(0.6f);
    }

    public void dismiss() {
        mPopuWindow.dismiss();
    }

    public boolean isShowing() {
       return  mPopuWindow.isShowing();
    }

    abstract int getLayoutId() ;
    abstract void initView() ;

}
