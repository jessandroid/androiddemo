package com.qihoo360.homecamera.mobile.activity;

import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.drawable.AnimationDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.PowerManager;
import android.support.v4.app.FragmentTransaction;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.qihoo360.homecamera.mobile.BuildConfig;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.entity.CommonMessageEntity;
import com.qihoo360.homecamera.mobile.entity.DeviceInfo;
import com.qihoo360.homecamera.mobile.entity.SpaceInfoList;
import com.qihoo360.homecamera.mobile.entity.Story;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.player.Mux;
import com.qihoo360.homecamera.mobile.player.Player;
import com.qihoo360.homecamera.mobile.ui.dialog.BaseDialogFactory;
import com.qihoo360.homecamera.mobile.ui.fragment.RecordStoryFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.ReplayOnlineStoryFragment;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.FileUtil;
import com.qihoo360.homecamera.mobile.utils.QHStatAgentHelper;
import com.qihoo360.homecamera.mobile.utils.ToastUtil;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.widget.CamAlertDialog;
import com.qihoo360.homecamera.mobile.widget.lrc.LrcViewNew;

import java.io.File;
import java.lang.ref.WeakReference;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.TimeZone;

import rx.Observable;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;

public class PlayAndRecordStoryActivity extends BaseActivity implements SurfaceHolder.Callback,
        OnClickListener, RecordStoryFragment.OnFragmentInteractionListener, ActionListener {

    private PowerManager.WakeLock wake_lock;
    public Player player;
    private LrcViewNew lrc;
    private Story story;
    public Mux mux;
    private float mWHRatio = 16.f / 9.f;
    private SurfaceView sv;
    private SurfaceHolder sh;
    private RelativeLayout mVideoViewLayout;
    public ProgressBar sb;
    private TextView tv;
    private View view;
    private TextView progressText;
    private ProgressBar progressDown;
    public RelativeLayout relativeLayout3;
    private ImageView back_button;
    private TextView play_story_title;
    public TextView time_long_one;
    private File mp4File;
    private BaseDialogFactory dialogFactory;
    private File lrcfile;
    private int PLAY_STATE;
    private File mDownloadDir = FileUtil.getInstance().getStoryFile();
    private CamAlertDialog camAlertDialog;
    public ImageView defa;
    private boolean replay = false;
    private boolean flag = false;
    public TextView down_progress;
    public ImageView im;
    public View download;
    public AnimationDrawable rocketAnimation;
    public View headset_id;
    private HeadsetReceiver headsetReceiver;
    private int i = 0;
    public View black_surface;
    private WeakReference<PlayAndRecordStoryActivity> weakReference;
    public DeviceInfo deviceInfo;
    public Animation translateAnimation;
    private boolean online = false;
    private RecordStoryFragment recordStoryFragment;
    private FragmentTransaction fragmentTransaction;

    public boolean withHearSet = false;
    public float totalduration = 0;
    public float postionNow = 0;
    private ReplayOnlineStoryFragment recordStoryFragmentOl;
    private int viewWidth;
    private int viewHeight;
    public View timer_layout;
    public ImageView timer;
    public AnimationDrawable timerAn;
    public ImageView try_view;
    private boolean bHasShowNoDiscAlert = false;
    public AnimationDrawable animationDrawable4SB;
    public TextView proTxt4sb;
    public Dialog camAlertDialog4Sb;
    private TelephonyManager tm;
    private PhoneStateListener callStateListener;


    @Override
    public void onFragmentInteraction(Uri uri) {

    }

    @Override
    public void download() {

    }

    @Override
    public void play() {

    }

    @Override
    public void pause() {

    }

    public int PLAYING = 1;
    public int PAUSE = 2;
    public int STOP = 3;

    public boolean isPause;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        headsetReceiver = new HeadsetReceiver();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        Bundle bundle = getIntent().getBundleExtra("Bundle");
        story = bundle.getParcelable("story");
        deviceInfo = bundle.getParcelable("deviceInfo");
        GlobalManager.getInstance().getUserInfoManager().registerActionListener(this);

        online = bundle.getBoolean("online");

        if (!online) {
            if (story == null || TextUtils.isEmpty(story.video_url)) {
                CLog.e("the story is null");
                finish();
                return;
            }
            callStateListener = new CallStateListener();
            tm = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
            tm.listen(callStateListener, PhoneStateListener.LISTEN_CALL_STATE);
        } else {
            if (story == null || TextUtils.isEmpty(story.storyUrl.getUrl())) {
                CLog.e("the story is null");
                finish();
                return;
            }
        }
        try {
            Player.init(this);
        } catch (Exception e) {
            CLog.e(String.format("the e is %s ", e.getMessage()));
            finish();
            return;
        }
        setContentView(R.layout.play_and_record_story_layout);
        player = new Player();
        player.setAudioSpeaker(this, true);


        fragmentTransaction = getSupportFragmentManager().beginTransaction();
        if (!online) {

            recordStoryFragment = RecordStoryFragment.newInstance(story, deviceInfo);
            fragmentTransaction.add(recordStoryFragment, "recordStory");
            fragmentTransaction.replace(R.id.play_fragment, recordStoryFragment).commit();
            player.setStateChangedListener(recordStoryFragment);
            player.setErrorListener(recordStoryFragment);
            try {
                mux = new Mux();
                mux.natvieMux(recordStoryFragment);
            } catch (Exception e) {
                CLog.e(String.format("the e is %s ", e.getMessage()));
                finish();
            }

        } else {
            recordStoryFragmentOl = ReplayOnlineStoryFragment.newInstance(story, deviceInfo);
            fragmentTransaction.add(recordStoryFragmentOl, "replay-online-story");
            fragmentTransaction.replace(R.id.play_fragment, recordStoryFragmentOl).commit();
            player.setStateChangedListener(recordStoryFragmentOl);
            player.setErrorListener(recordStoryFragmentOl);
        }

        weakReference = new WeakReference<>(this);
        player.setEndOfStreamListener(new Player.EndOfStreamListener() {
            @Override
            public void endOfStream(Player player) {
                Observable.just(player).observeOn(AndroidSchedulers.mainThread()).subscribe(new Action1<Player>() {
                    @Override
                    public void call(Player player) {
                        if (!online) {
                            if (recordStoryFragment.trial_button.getVisibility() == View.GONE) {
                                PLAY_STATE = STOP;
                                if (mux != null)
                                    mux.natvieStopAndMux();
                                showUploadAn("正在合成中，请稍候…");
                                Utils.ensureVisbility(View.VISIBLE, defa);
                                recordStoryFragment.lrc.updateTime(0);
                                recordStoryFragment.play.setButton_text(getString(R.string.save_story));
                                recordStoryFragment.play.setButton_image(getResources().getDrawable(R.drawable.icon_save));
                                recordStoryFragment.re_record.setVisibility(View.VISIBLE);
                                recordStoryFragment.trial_button.setVisibility(View.VISIBLE);
                                QHStatAgentHelper.commitCommonEvent("S_Record_xw005");
                            }
                            recordStoryFragment.trial_button.setText(getString(R.string.trial));
                        }
                    }
                });
            }
        });


        player.setPositionUpdatedListener(new Player.PositionUpdatedListener() {
            public void positionUpdated(Player player, final long position) {
                postionNow = position / 1000000;
                Observable.just(position).observeOn(AndroidSchedulers.mainThread()).subscribe(new Action1<Long>() {
                    @Override
                    public void call(Long position) {
                        sb.setProgress((int) (position / 1000000));
                        if (!online) {
                            if (recordStoryFragment != null) {
                                if (recordStoryFragment.lrc != null) {
                                    recordStoryFragment.lrc.updateTime((position / 1000000));
                                }
                            }
                        }
                        updateTimeWidget();
                    }
                });
            }
        });

        player.setDurationChangedListener(new Player.DurationChangedListener() {

            public void durationChanged(Player player, final long duration) {
                totalduration = duration / 1000000;
                runOnUiThread(new Runnable() {
                    public void run() {
                        sb.setMax((int) (duration / 1000000));
                        updateTimeWidget();
                    }
                });
            }
        });

        mp4File = new File(mDownloadDir, story.unique + ".mp4");
        lrcfile = new File(mDownloadDir, story.unique + ".lrc");
        initView();
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wake_lock = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK, "Family Play");
        wake_lock.setReferenceCounted(false);
        Glide.with(PlayAndRecordStoryActivity.this)
                .load(TextUtils.isEmpty(story.cover_url) ? story.cover : story.cover_url)
                .placeholder(R.drawable.moren_icon_story_on_line)
                .dontAnimate()
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(defa);

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.HEADSET_PLUG");
        registerReceiver(headsetReceiver, intentFilter);
        translateAnimation = AnimationUtils.loadAnimation(this, R.anim.headset_an);
        GlobalManager.getInstance().getUserInfoManager().asyncGetSpaceInfo(deviceInfo.sn);
    }

    public void dotranslateAnimation() {
        if (headset_id.getVisibility() == View.VISIBLE) {
            headset_id.startAnimation(translateAnimation);
            headset_id.setVisibility(View.GONE);
            QHStatAgentHelper.commitCommonEvent("S_Record_xh015");//外放录制
        } else {
            QHStatAgentHelper.commitCommonEvent("S_Record_xh014");//插耳机录制
        }
    }

    @Override
    protected void onResume() {
        CLog.d("------------------>onrusume");
        super.onResume();
    }

    public void cancleRecord() {
        CLog.i("test2", "cancleRecord");
        if (player != null) {
            player.pause();
        }
        if (mux != null) {
            mux.nativePause();
        }
        double progress = BuildConfig.DEBUG ? 0.2 : 0.8;
        if (postionNow / totalduration < progress) {
            tipsDialog = new CamAlertDialog.Builder(weakReference.get()).setCancelable(false).setTitle(R.string.tips_47).setMessage(R.string.cancle_story_tips)
                    .setNegativeButton(R.string.record_story_gameover_string, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                            HashMap hashMap = new HashMap();
                            hashMap.put("playTime", postionNow);
                            hashMap.put("totalTime", totalduration);
                            hashMap.put("id", story.id);
                            hashMap.put("name", story.name);
                            hashMap.put("story", story.toJson());
                            hashMap.put("playPer", String.valueOf((float) postionNow / (float) totalduration));
                            QHStatAgentHelper.commitCommonEventHash("S_Record_xw013", hashMap);
                            finish();
                        }
                    }).setPositiveButton(R.string.continue_record, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                            if (TextUtils.equals(recordStoryFragment.play.getExampleString(), getString(R.string.start))) {
                                recordStoryFragment.showTimeCount();
                            }
                            player.play();
                            if (mux != null)
                                mux.nativePlay();
                        }
                    }).show();
        } else {
            tipsDialog = new CamAlertDialog.Builder(weakReference.get()).setCancelable(false).setTitle(R.string.tips_47).setMessage(R.string.eight_per)
                    //狠心放弃、有始有终
                    .setPositiveButton(R.string.keep_record_story, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                            PLAY_STATE = PLAYING;
                            player.play();
                            if (mux != null)
                                mux.nativePlay();

                        }
                    }).setNegativeButton(R.string.record_story_gameover_string_2, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                            PLAY_STATE = STOP;

                            if (mux != null)
                                mux.natvieStopAndMux();
                            sb.setProgress(0);
                            showUploadAn("正在合成中，请稍候...");
                            recordStoryFragment.play.setButton_text(getString(R.string.save_story));
                            recordStoryFragment.play.setButton_image(getResources().getDrawable(R.drawable.icon_save));


                            recordStoryFragment.re_record.setVisibility(View.VISIBLE);

                            recordStoryFragment.trial_button.setVisibility(View.VISIBLE);
                            recordStoryFragment.trial_button.setText(getString(R.string.trial));
                            QHStatAgentHelper.commitCommonEvent("S_Record_xw004");
                        }
                    }).show();
        }
    }


    public void onDestroy() {
        CLog.startTimer("onDestroy");
        CLog.d("-------------------------->");
        if (!online) {
            if (mux != null) {
                mux.nativePause();
                mux.nativeFinalize();
                mux = null;
            }
        }

        if (player != null) {
            player.setPositionUpdatedListener(null);
            player.setDurationChangedListener(null);
            player.setStateChangedListener(null);
            player.setEndOfStreamListener(null);
            player.setVideoDownloadCompleteListener(null);
            player.close();
            player = null;
        }
        if (rocketAnimation != null) {
            rocketAnimation.stop();
            rocketAnimation = null;
        }

        GlobalManager.getInstance().getUserInfoManager().removeActionListener(this);
        if (tipsDialog != null) {
            tipsDialog.dismiss();
            tipsDialog = null;
        }
        if (!online && tm != null && callStateListener != null) {
            tm.listen(callStateListener, PhoneStateListener.LISTEN_NONE);
        }
        callStateListener = null;


        recordStoryFragmentOl = null;
        recordStoryFragment = null;
        unregisterReceiver(headsetReceiver);
        super.onDestroy();
        CLog.i("test3", "prs des cost = " + CLog.endTimer("onDestroy"));
    }

    private void updateTimeWidget() {
        int pos = sb.getProgress();
        int max = sb.getMax();
        SimpleDateFormat df = new SimpleDateFormat("mm:ss");
        df.setTimeZone(TimeZone.getTimeZone("UTC"));
        tv.setText(df.format(new Date(max)));
        time_long_one.setText(df.format(new Date(pos)));
    }

    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        CLog.d("------------------>1");
        player.setSurface(holder.getSurface());
    }

    public void surfaceCreated(SurfaceHolder holder) {
        CLog.d("------------------>2");

//        player.setSurface(holder.getSurface());

    }

    public void surfaceDestroyed(SurfaceHolder holder) {
        CLog.d("------------------>3");

//        player.setSurface(holder.getSurface());
    }


    private void initView() {
        lrc = (LrcViewNew) findViewById(R.id.lrc);
        back_button = (ImageView) findViewById(R.id.back_button);
        back_button.setOnClickListener(this);

        black_surface = findViewById(R.id.black_surface);
        sv = (SurfaceView) this.findViewById(R.id.surfaceView);
        sh = sv.getHolder();
        sh.addCallback(this);
        mVideoViewLayout = (RelativeLayout) findViewById(R.id.shu);


        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int screenWidth = dm.widthPixels;
        viewWidth = screenWidth;
        viewHeight = (int) (viewWidth / mWHRatio);
        CLog.d("viewWidth:" + viewWidth + "viewHeight:" + viewHeight);
        RelativeLayout.LayoutParams linearP = new RelativeLayout.LayoutParams(viewWidth, viewHeight);
        mVideoViewLayout.setLayoutParams(linearP);
        CLog.d("width:" + mVideoViewLayout.getLayoutParams().width + "  height:" + mVideoViewLayout.getLayoutParams().height);
        sb = (ProgressBar) findViewById(R.id.progressBar);
        tv = (TextView) findViewById(R.id.textview_time);
        relativeLayout3 = (RelativeLayout) findViewById(R.id.relativeLayout3);
        play_story_title = (TextView) findViewById(R.id.play_story_title);
        play_story_title.setText(story.name);
        time_long_one = (TextView) findViewById(R.id.time_long_one);
        tv.setText(story.duration);

        defa = (ImageView) findViewById(R.id.defa);
        defa.setVisibility(View.VISIBLE);

        download = findViewById(R.id.download);
        download.setVisibility(View.GONE);

        im = (ImageView) findViewById(R.id.image_h);
        im.setBackgroundResource(R.drawable.dragon_an);

        timer_layout = findViewById(R.id.timer_layout);
        timer_layout.setVisibility(View.GONE);

        timer = (ImageView) findViewById(R.id.timer);
        timer.setBackgroundResource(R.drawable.countdown_bg);
        timerAn = (AnimationDrawable) timer.getBackground();


        rocketAnimation = (AnimationDrawable) im.getBackground();
        rocketAnimation.start();

        down_progress = (TextView) findViewById(R.id.down_progress);

        headset_id = findViewById(R.id.headset_id);
        headset_id.setVisibility(View.GONE);

        black_surface.setVisibility(View.GONE);

        try_view = (ImageView) findViewById(R.id.try_view);
        try_view.setVisibility(View.VISIBLE);


    }

    public void showUploadAn(String s) {
        View v = LayoutInflater.from(this).inflate(R.layout.uploading_4sb, null);
        proTxt4sb = (TextView) v.findViewById(R.id.proTxt4sb);
        proTxt4sb.setText(s);
        animationDrawable4SB = (AnimationDrawable) v.findViewById(R.id.image_h).getBackground();
        camAlertDialog4Sb = new Dialog(this, R.style.MyDialog);
        animationDrawable4SB.start();
        camAlertDialog4Sb.setCancelable(false);
        camAlertDialog4Sb.setContentView(v);
        camAlertDialog4Sb.show();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.back_button:
                onBackPressed();
                break;
        }
    }

    public void playVideo() {
        if (player != null) {
            if (mp4File.exists()) {
                Uri uri = Uri.fromFile(mp4File);
                player.setUri(uri.toString());
                player.setMute(true);
                player.play();
                if (mux != null)
                    mux.nativePlay();
            } else {
                ToastUtil.showToast(Utils.context, "文件不存在", Toast.LENGTH_SHORT);
            }
        }
    }


    @Override
    public void onBackPressed() {
        if (!online) {
            if (!recordStoryFragment.isRecordFinish) {
                if (!recordStoryFragment.upload) {
                    if (TextUtils.equals(recordStoryFragment.play.getExampleString(), getString(R.string.record_story_end))) {
                        cancleRecord();
                    } else {
                        finish();
                    }
                } else {
                    finish();
                }
            } else {
                if (TextUtils.equals(recordStoryFragment.trial_button.getText(), getString(R.string.gameover))) {
                    player.pause();
                }
                tipsDialog = new CamAlertDialog.Builder(weakReference.get()).setCancelable(false).setTitle(R.string.tips_47).setMessage(R.string.give_up_save_story)
                        .setNegativeButton(R.string.save_story_tip, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                QHStatAgentHelper.commitCommonEvent("S_Record_xw014");//录完未保存退出
                                dialogInterface.dismiss();
                                player.stop();
                                finish();
                            }
                        }).setPositiveButton(R.string.save_story_no, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        }).show();
            }

        } else {
            QHStatAgentHelper.commitCommonEvent("S_Record_xw012");//退出故事内页
            finish();
        }
    }


    @Override
    public void finish() {
        CLog.d("------------------>");
        if (recordStoryFragment != null) {
            if (recordStoryFragment.downloadManager != null) {
                recordStoryFragment.downloadManager.cancelAll();
            }
        }
        super.finish();
    }


    @Override
    protected void onStop() {
        super.onStop();
        if (player == null) {
            player.pause();
        }
        if (!online) {
            if (mux != null) {
                mux.nativePause();
            }
        }
        CLog.d("Debug", "----------->onstop");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        isPause = false;
        if (!online) {
            if (TextUtils.equals(recordStoryFragment.play.getExampleString(), getString(R.string.record_story_end))) {
                if (tipsDialog == null || tipsDialog != null && !tipsDialog.isShowing()) {
                    cancleRecord();
                }
            } else if (TextUtils.equals(recordStoryFragment.play.getExampleString(), getString(R.string.story_record))) {
                if (recordStoryFragment.show) {
                    playVideo();
                }
            } else {
                if (recordStoryFragment.trial_button.getVisibility() == View.VISIBLE) {
                    if (TextUtils.equals(recordStoryFragment.trial_button.getText(), getString(R.string.gameover))) {
                        if(recordStoryFragment.isUploading == false){
                            player.play();
                        }
                    } else {
                        player.pause();
                    }
                }
            }
        } else {
            if (TextUtils.equals(recordStoryFragmentOl.play.getExampleString(), getString(R.string.pause))) {
                player.play();
            }
        }
    }

    @Override
    protected void pushMessageNotify(CommonMessageEntity messageEntity){
        if (messageEntity.messageType == CommonMessageEntity.CANCEL_SHARE ||
                messageEntity.messageType == CommonMessageEntity.KIBOT_UNBIND){
            new Handler().postDelayed(new Runnable(){
                public void run() {
                    finish();
                }
            }, 1500);
        }
    }

    @Override
    protected void onPause() {
        CLog.d("Debug", "enter -------------onPause");
        if (player != null) {
            player.pause();
        }
        if (!online) {
            if (mux != null) {
                mux.nativePause();
            }
        }
        isPause = true;
        CLog.d("Debug", "34!enter -------------onPause");
        super.onPause();
    }

    public class HeadsetReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (!online) {
                if (0 == intent.getIntExtra("state", 0)) {
                    /*withHearSet = false;
                    if (recordStoryFragment.isplaying) {
                        headset_id.setVisibility(View.GONE);
                    } else {
                        headset_id.setVisibility(View.VISIBLE);
                    }*/
                } else if (1 == intent.getIntExtra("state", 0)) {
                    withHearSet = true;
                    if (headset_id.getVisibility() != View.GONE) {
                        headset_id.startAnimation(translateAnimation);
                    }
                    headset_id.setVisibility(View.GONE);
                }
            } else {
                headset_id.setVisibility(View.GONE);
            }
        }
    }

    private class CallStateListener extends PhoneStateListener {
        @Override
        public void onCallStateChanged(int state, String incomingNumber) {
            switch (state) {
                case TelephonyManager.CALL_STATE_RINGING:
                    onPause();
                    if (!online) {
                        if (TextUtils.equals(recordStoryFragment.play.getExampleString(), "结束录制")) {
                            cancleRecord();
                        }
                    }
                    break;
            }
        }
    }


    @Override
    public Object actionPerformed(int actionCode, Object... args) {
        switch (actionCode) {
            case Actions.UserInfo.GET_SPACE_INFO_SUCCESS: {
                SpaceInfoList mSpaceInfoList = (SpaceInfoList) args[0];
                if (mSpaceInfoList != null) {
                    if (mSpaceInfoList.data != null) {
                        if (mSpaceInfoList.data.size() > 0) {
                            SpaceInfoList.SpaceInfo mSpaceInfo = mSpaceInfoList.data.get(0);
                            if (mSpaceInfo.stype.equals("0")) {
                                if (mSpaceInfo.status > 0) {
                                    String content = "";
                                    if (mSpaceInfo.status == 1) {
                                        // full
                                        content = getString(R.string.already_not_enough_cloud_space_size_title);
                                    } else if (mSpaceInfo.status == 2) {
                                        //almost full
                                        content = getString(R.string.almost_not_enough_cloud_space_size_title);
                                    }
                                    if (bHasShowNoDiscAlert)
                                        return Boolean.TRUE;

                                    CamAlertDialog.Builder builder = new CamAlertDialog.Builder(this);
                                    builder.setTitle(content);
                                    builder.setTipMessage(getString(R.string.not_enough_cloud_space_size_msg));
                                    builder.setTipMessageColor(0xFF666666);
                                    builder.setPositiveButton(R.string.already_know,
                                            new CamAlertDialog.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dialog, int which) {
                                                    close();
                                                }
                                            });
                                    camAlertDialog = builder.show();
                                    camAlertDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                                        @Override
                                        public void onDismiss(DialogInterface dialog) {
                                            bHasShowNoDiscAlert = false;
                                        }
                                    });
                                    bHasShowNoDiscAlert = true;
                                }
                            }

                        }
                    }
                }
                return Boolean.TRUE;
            }
        }
        return null;
    }


    public void showMicerrorDialog() {
        if (tipsDialog != null && tipsDialog.isShowing()) {
            tipsDialog.dismiss();
        }
        tipsDialog = new CamAlertDialog.Builder(this).setCancelable(false).setTitle("提示")
                .setMessage(R.string.micerror_contant).setPositiveButton(R.string.i_know, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                        PlayAndRecordStoryActivity.this.finish();
                    }
                }).show();
    }

    @Override
    public int getProperty() {
        return 0;
    }

}