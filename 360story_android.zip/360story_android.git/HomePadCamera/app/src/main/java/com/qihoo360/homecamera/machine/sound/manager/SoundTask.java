package com.qihoo360.homecamera.machine.sound.manager;

import android.os.Handler;
import android.os.Message;

import com.qihoo360.homecamera.machine.config.MachineDefaultClientConfig;
import com.qihoo360.homecamera.machine.net.CameraHttpApi;
import com.qihoo360.homecamera.mobile.config.Const;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.entity.Head;
import com.qihoo360.homecamera.mobile.utils.CLog;

import org.json.JSONException;
import org.json.JSONObject;

public class SoundTask implements Runnable {
	
	private static final String TAG = SoundTask.class.getSimpleName();
	
	public final static int  SOUND_QUERY_KEY = 1;//向服务器询问状态的key值
	
	public static long  SOUND_SEND_KEY = 0;//向服务器发送的key,每次发送都自增
	
	public static long  SOUND_RECEIVE_KEY = -1;//从服务器接收到的值
	
	
	/**
	 * 空闲
	 */
	/*public final static int SOUND_NOTHING = 0;*/
	/**
	 * 开始播放
	 */
	public final static int SOUND_PLAY = 1;
	/**
	 * 暂停播放
	 */
	public final static int SOUND_PAUSE = 2;
	/**
	 * 继续播放
	 */
	public final static int SOUND_CONTINUE = 3;
	
	/**
	 * 停止
	 */
	public final static int SOUND_STOP = 4;
	
	/**
	 * 像摄像头询问播放状态
	 */
	public final static int SOUND_QUERY = 11;
	
	/**
	 * 摄像头端网络很差，需要弹窗
	 */
	public final static int SOUND_SHOW_CAMERA_NET_SLOW = 12;
	
	
	String url;
	int fileType;
	long fileSize;
	String fileMd5;
	int state;
	long sendCode;
	
    private final String command = "playurl";
    private final Class<? extends Head> clazz;
    private final Handler handler;
    private final String cameraSn;

    public SoundTask(String url, int state, String fileMd5, int fileType,
					 long fileSize, long sendCode, Class<? extends Head> clazz,
					 Handler handler, String cameraSn) {
    	this.url = url;
		this.state = state;
		this.fileMd5 = fileMd5;
		this.fileType = fileType;
		this.fileSize = fileSize;
        this.clazz = clazz;
        this.handler = handler;
        this.cameraSn = cameraSn;
        this.sendCode = sendCode;
    }

    @Override
    public void run() {
        try {
            Message successMsg = handler.obtainMessage();
            successMsg.what = Constants.TaskState.SUCCESS;
            JSONObject params = new JSONObject();
            params.put("url", url);
			params.put("fileType", fileType);
			params.put("fileSize", fileSize);
			params.put("fileMd5", fileMd5);
			params.put("key", sendCode);
			params.put("state", state);
            params.put("command", command);
            params.put("sn", cameraSn);
			CLog.d(TAG, "start 联网");
			CLog.i("play-v2","called playurl url = --"+ url);
			CameraHttpApi cameraHttpApi = new CameraHttpApi();
			Head head =
					cameraHttpApi.doAysnCommonRequest(params, MachineDefaultClientConfig.URL_APP_CMD, clazz);
			if (Const.DEBUG)
				CLog.d(TAG, head.errorCode +"=="+head.statusCode+"==="+params.toString());
            /*if (head.getErrorCode() == Constants.Http.ERROR_CODE_SUCCEED) {
            	
            }*/
            //暂时先不判断结果了
            if(Const.DEBUG)
            	CLog.d(TAG,"doAysnCommonRequest");
            successMsg.obj = head;
            handler.sendMessage(successMsg);
        } catch (JSONException e) {
            e.printStackTrace();
            handler.obtainMessage(Constants.TaskState.EXCEPITON).sendToTarget();
        }
    }
}
