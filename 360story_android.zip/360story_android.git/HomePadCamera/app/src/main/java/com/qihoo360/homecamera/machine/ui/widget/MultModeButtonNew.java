
package com.qihoo360.homecamera.machine.ui.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.ImageView;

import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.utils.Utils;

/**
 * TODO 有时间把资源数组写到配置文件去 多状态按钮
 *
 * @author Administrator
 *
 */
public class MultModeButtonNew extends ImageView {

    private int[] img_res;
    private int mode;

    public MultModeButtonNew(Context context, AttributeSet attrs) {
        super(context, attrs);
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.MultMode);
        int id = a.getResourceId(R.styleable.MultMode_drawable_array_index, 0);
        if (id != 0) {
            img_res = getResourceIds(id);
        }
        a.recycle();
    }

    private int[] getResourceIds(int id) {
        TypedArray ta = Utils.getContext().getResources().obtainTypedArray(id);
        int[] array = new int[ta.length()];
        for (int i = 0; i < ta.length(); i++) {
            array[i] = ta.getResourceId(i, R.string.ok);
        }
        ta.recycle();
        return array;
    }

    /**
     * 
     * @param mode >= 0
     */
    public void setMode(int mode) {
        if (mode >= 0) {
            this.mode = mode;
            if (img_res != null && mode < img_res.length) {
                setBackgroundResource(img_res[mode]);
            }
        }
    }
    public int getMode() {
        return mode;
    }
}
