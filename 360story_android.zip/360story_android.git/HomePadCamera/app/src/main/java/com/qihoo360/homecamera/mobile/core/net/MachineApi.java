package com.qihoo360.homecamera.mobile.core.net;

import android.text.TextUtils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.qihoo360.homecamera.device.config.StoryMachineConsts;
import com.qihoo360.homecamera.machine.config.MachineDefaultClientConfig;
import com.qihoo360.homecamera.machine.entity.BindBannerEntity;
import com.qihoo360.homecamera.machine.entity.BindResult;
import com.qihoo360.homecamera.machine.entity.Relay;
import com.qihoo360.homecamera.machine.entity.SongListResponse;
import com.qihoo360.homecamera.machine.log.MachineLogTag;
import com.qihoo360.homecamera.mobile.BuildConfig;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.config.DefaultClientConfig;
import com.qihoo360.homecamera.mobile.db.CommonWrapper;
import com.qihoo360.homecamera.mobile.entity.AppBindEntity;
import com.qihoo360.homecamera.mobile.entity.AppGetInfoEntity;
import com.qihoo360.homecamera.mobile.entity.DeviceInfo;
import com.qihoo360.homecamera.mobile.entity.DeviceInfoList;
import com.qihoo360.homecamera.mobile.entity.Head;
import com.qihoo360.homecamera.mobile.entity.ImageInfoListEntity;
import com.qihoo360.homecamera.mobile.entity.IpcAllEntity;
import com.qihoo360.homecamera.mobile.entity.ShareGetListEntity;
import com.qihoo360.homecamera.mobile.entity.ShareShareEntity;
import com.qihoo360.homecamera.mobile.http.OkHttpUtils;
import com.qihoo360.homecamera.mobile.utils.CLog;

import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Created by lixin3-s on 2016/11/10.
 */
public class MachineApi {
    public static class Machine {
        /**
         * 获取所有设备列表
         *
         * @return
         */
        public static DeviceInfoList getMachineList(int page) {
            DeviceInfoList deviceInfoList = null;
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("page", page + "");
                param.put("count", "50");
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.machinePost().params(param).headers(null).url(MachineDefaultClientConfig.APP_GETLIST_URL).build().execute();
                Gson gson = new Gson();
                deviceInfoList = gson.fromJson(responseStr, DeviceInfoList.class);
//                deviceInfoList.removeDirtyData(); // 移除不支持的设备
                if (deviceInfoList.data.device.size() > 0) {
                    DeviceInfo df = deviceInfoList.data.device.get(0);
                    CLog.e("lix", df.support);
                }
                return deviceInfoList;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }


        /**
         * 机器人绑定设备
         *
         * @return
         */
        public static AppBindEntity getBindDevice(String activeCode, String bindType) {
            //type 1=输入码，2=二维码
            AppBindEntity deviceInfo;
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("funcType", "activecode");//wave：声波绑定 activecode：注册码绑定
                param.put("activeCode", activeCode);
                param.put("type", bindType);//新接口中无此参数
                param.put("device", "kibot");
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.machinePost().params(param).headers(null).url(MachineDefaultClientConfig.APP_BIND).build().execute();
                Gson gson = new Gson();
                deviceInfo = gson.fromJson(responseStr, AppBindEntity.class);
                return deviceInfo;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        /**
         * 故事机绑定
         * @param ts
         * @return
         */
        public static BindResult doAppBind(long ts) {
            BindResult bindResult = null;
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("funcType", "wave");//wave：声波绑定 activecode：注册码绑定
                param.put("ts", "" + ts);
                param.put("device", "story");
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                long timeOutMills = 5000;
                String responseStr = OkHttpUtils.machinePost().params(param).headers(null)
                        .url(MachineDefaultClientConfig.APP_BIND).build().connTimeOut(timeOutMills)
                        .writeTimeOut(timeOutMills).readTimeOut(timeOutMills).execute();
                Gson gson = new Gson();
                bindResult = gson.fromJson(responseStr, BindResult.class);
            } catch (Exception e) {
                e.printStackTrace();
            }

            return bindResult;
        }

        /**
         * 解绑设备
         *
         * @return
         */
        public static Head getUnBindDevice(String sn, String delCloudData, String delIpcData, String device) {
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("sn", sn);
                param.put("delCloudData", delCloudData);
                param.put("delIpcData", delIpcData);
                param.put("device", device);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.machinePost().params(param).headers(null).url(MachineDefaultClientConfig.UN_BIND_DEVICE_URL).build().execute();
                Gson gson = new Gson();
                Head head = gson.fromJson(responseStr, Head.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        public static ShareShareEntity postShareShare(String sn, String type, String phone, String relation, String Acl) {
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("sn", sn);
                param.put("type", type);
                param.put("phone", phone);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                if (!TextUtils.isEmpty(relation)) {
                    param.put("relation", relation);
                }
                if (!TextUtils.isEmpty(Acl)) {
                    param.put("aclInfo", Acl);
                }
                String responseStr = OkHttpUtils.machinePost().params(param).headers(null).url(MachineDefaultClientConfig.SHARE_SHARE_URL).build().execute();
                CLog.e("lix", "postShareShare:" + responseStr);
                Gson gson = new Gson();
                ShareShareEntity head = gson.fromJson(responseStr, ShareShareEntity.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        public static ShareGetListEntity postShareGetList(String sn, String page, String count) {
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("sn", sn);
                param.put("page", page);
                param.put("count", count);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.machinePost().params(param).headers(null).url(MachineDefaultClientConfig.SHARE_GET_LIST_URL).build().execute();
                CLog.e("lix", "postShareGetList:" + responseStr);
                Gson gson = new Gson();
                ShareGetListEntity head = gson.fromJson(responseStr, ShareGetListEntity.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        public static Relay doStreamPlay(String sn, String deviceType) {
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("sn", sn);
                param.put("device", "story");
                param.put("funcType", "stream");
                param.put("type",deviceType);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.machinePost().params(param).headers(null).url(MachineDefaultClientConfig.STREAM_PLAY).build().execute();
                CLog.i(MachineLogTag.LOG_TAG_MACHINE, "doStreamPlay:" + responseStr);
                Gson gson = new Gson();
                Relay head = gson.fromJson(responseStr, Relay.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        public static void doStreamStop(String sn){
            try {
                Map<String, String> param = new HashMap<>();
                param.put("sn", sn);
                param.put("device", "story");
                param.put("funcType", "stream");
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                OkHttpUtils.machinePost().params(param).headers(null).url(MachineDefaultClientConfig.STREAM_STOP).build().execute();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        /**
         * 设置故事机的小视频抓拍
         *
         * @return
         */
        public static Head setMachineVideoCatch(String settings, String sn) {
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("device", "story");
                param.put("funcType", "setting");
                param.put("sn", sn);
                param.put("settings", settings);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.post().params(param).isHttps(true).headers(null).url(DefaultClientConfig.SET_SETTING_SETIPCSOME).build().execute();
                CLog.e("zt", "postSetPersonSetting:" + responseStr);
                Gson gson = new Gson();
                Head head = gson.fromJson(responseStr, Head.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        public static IpcAllEntity getMachineVideoCatch(String sn){
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("device", "story");
                param.put("funcType", "setting");
                param.put("sn", sn);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.post().params(param).isHttps(true).headers(null).url(DefaultClientConfig.GET_IPC_ALL).build().execute();
                CLog.e("zt", "getPersonSetting:" + responseStr);
                Gson gson = new Gson();
                IpcAllEntity head = gson.fromJson(responseStr, IpcAllEntity.class);
                if(head.getErrorCode()!=0){
                    return null;
                }
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        public static Head doCommand(String cmd, String sn, String content) {
            JSONObject jsonObject = new JSONObject();
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("sn", sn);
                param.put("cmd", cmd);
                param.put("content", content);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.machinePost().params(param).headers(null).url(MachineDefaultClientConfig.APP_CMD_SEND).build().execute();
                CLog.i(MachineLogTag.LOG_TAG_MACHINE, "doCommand:" + responseStr);
                Gson gson = new Gson();
                Head head = gson.fromJson(responseStr, Head.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        //获取专辑里面儿歌列表信息
        public static SongListResponse doGetAlbum(String unique, int pageId) {
            String requestUrl = String.format(MachineDefaultClientConfig.APP_URL_GET_ALBUM_LIST, unique, pageId);
            CLog.e("zt","获取儿歌列表URL:"+requestUrl);
            String responseStr = OkHttpUtils.get().isStatic(true).withOutCookie().isHttps(false).params(null).isDebug(false).headers(null).url(requestUrl).build().execute();
            return new Gson().fromJson(responseStr, SongListResponse.class);
        }

        public static BindBannerEntity doGetBanner(){
            String responseStr = OkHttpUtils.get().isStatic(true).withOutCookie().isHttps(false).params(null).isDebug(false).headers(null).url(MachineDefaultClientConfig.APP_URL_GET_BANNER_LIST).build().execute();
            if(TextUtils.isEmpty(responseStr)){
                return null;
            }
            return new Gson().fromJson(responseStr, BindBannerEntity.class);
        }
    }

    public static class UserInfo {

        public static AppGetInfoEntity postAppGetInfo(String sn) {
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("sn", sn);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.machinePost().params(param).headers(null).url(MachineDefaultClientConfig.APP_GET_INFO_URL).build().execute();
                CLog.json("lix", "postAppGetInfo:" + responseStr);
                Gson gson = new Gson();
                AppGetInfoEntity head = gson.fromJson(responseStr, AppGetInfoEntity.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        public static Head postAppUpdateInfo(String sn, String qid, String relation, String title, String babyInfo, String fileName, String filePath) {
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("sn", sn);
                param.put("qid", qid);
                param.put("title", title);
                param.put("relation", relation);
                param.put("babyInfo", babyInfo);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                File file = new File(filePath);
//                File tmpFile = new File(FileUtil.getInstance().getAvatorFile().getAbsolutePath(), "/new_avator.png");
                String responseStr = "";
                //头像上传功能服务端还没做
//                if (file.exists()) {
//                    responseStr = OkHttpUtils.machinePost().addFile("imageData", fileName, file).params(param).headers(null).url(MachineDefaultClientConfig.APP_UPDATE_INFO_URL).build().execute();
//                } else {
                    responseStr = OkHttpUtils.machinePost().params(param).headers(null).url(MachineDefaultClientConfig.APP_UPDATE_INFO_URL).build().execute();
//                }

                CLog.e("lix", "postAppUpdateInfo:" + responseStr);
                Gson gson = new Gson();
                Head head = gson.fromJson(responseStr, Head.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }
    }

    public static class Command {
        public static Head localSetting(String sn, Map<String,String> settingItems) {
            try {
                Map<String, String> param = createCommand("settings", sn, settingItems);
                String responseStr = OkHttpUtils.machinePost().params(param).headers(null).url(MachineDefaultClientConfig.LOCAL_SETTING_URL).build().execute();
                CLog.json("lix", "localSetting:" + responseStr);
                Gson gson = new Gson();
                AppGetInfoEntity head = gson.fromJson(responseStr, AppGetInfoEntity.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        private static Map<String, String> createCommand(String cmd, String sn, Map<String,String> settingItems) {
            Map<String, String> param = new HashMap<String, String>();
            param.put("sn", sn);
            param.put("cmd", cmd);
            param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
            JsonObject contentJson = new JsonObject();
            String taskid = UUID.randomUUID().toString();

            JsonObject settingsJson = new JsonObject();
            if (settingItems != null) {
                Set<String> keySet = settingItems.keySet();
                if (keySet != null) {
                    String value;
                    for (String key : keySet) {
                        value = settingItems.get(key);
                        settingsJson.addProperty(key,value);
                    }
                }
            }
            contentJson.addProperty("taskid",taskid);
            contentJson.add("settings", settingsJson);
            param.put("content", contentJson.toString());
            return param;
        }
    }

    public final static class Album {

        public final static int ALBUM_LOAD_NUM_PER_PAGE = 20;

        /**
         * 查询相册
         *
         * @param sn
         * @param page
         * @return
         */
        public static ImageInfoListEntity getAppAlbumList(String sn, String page) {
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("sn", sn);
                param.put("page", page);
                param.put("pageSize", "" + ALBUM_LOAD_NUM_PER_PAGE);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.machinePost().params(param).headers(null).url(DefaultClientConfig.APP_VIDEO_LIST_URL).build().execute();
                //模拟的假数据
                //String responseStr = Constants.TEMP_JSON;
                CLog.i("test2", "getAppAlbumList sn :" + sn);
                Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
                ImageInfoListEntity head = gson.fromJson(responseStr, ImageInfoListEntity.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        /**
         * 删除文件
         *
         * @param sn
         * @param imageIdList 待删除文件列表
         * @return
         */
        public static Head deleteAlbumFile(String sn, ArrayList<Long> imageIdList) {
            try {
                if (imageIdList == null || imageIdList.size() == 0) {
                    return null;
                }

                StringBuffer stringBuffer = new StringBuffer();
                for (int i = 0; i < imageIdList.size(); i++) {
                    stringBuffer.append(imageIdList.get(i));
                    if (i < imageIdList.size() - 1) {
                        stringBuffer.append(",");
                    }
                }

                Map<String, String> param = new HashMap<String, String>();
                param.put("sn", sn);
                param.put("imageId", "" + stringBuffer.toString());
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.machinePost().params(param).headers(null).url(DefaultClientConfig.APP_VIDEO_DELETE_URL).build().execute();
                Gson gson = new Gson();
                Head head = gson.fromJson(responseStr, Head.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }
    }

    public static Head chatSendMsg(String sn, String subType, String content){
        try{
            Map<String, String> param = new HashMap<>();
            param.put("sn", sn);
            param.put("subType", subType);
            param.put("content", content);
            param.put("device", "story");
            param.put("funcType", "chat");
            param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
            String responseStr = OkHttpUtils.machinePost().params(param).headers(null).url(DefaultClientConfig.CHAT_SEND_MSG).build().execute();
            Head head = new Gson().fromJson(responseStr, Head.class);
            return head;
        }catch (Exception e){
            e.printStackTrace();
            Head head = new Head();
            head.setErrorCode(-1);
            head.setErrorMsg("发送失败");
            return null;
        }
    }
}
