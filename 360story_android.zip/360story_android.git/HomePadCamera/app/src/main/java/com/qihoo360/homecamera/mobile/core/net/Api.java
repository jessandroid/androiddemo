
package com.qihoo360.homecamera.mobile.core.net;

import android.os.Environment;
import android.text.TextUtils;
import android.util.Base64;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.qihoo360.homecamera.device.config.StoryMachineConsts;
import com.qihoo360.homecamera.mobile.BuildConfig;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.config.DefaultClientConfig;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.db.PadInfoWrapper;
import com.qihoo360.homecamera.mobile.entity.AppBindEntity;
import com.qihoo360.homecamera.mobile.entity.AppGetInfoEntity;
import com.qihoo360.homecamera.mobile.entity.CommandResponse;
import com.qihoo360.homecamera.mobile.entity.DeviceInfo;
import com.qihoo360.homecamera.mobile.entity.DeviceInfoList;
import com.qihoo360.homecamera.mobile.entity.Head;
import com.qihoo360.homecamera.mobile.entity.ImageInfoListEntity;
import com.qihoo360.homecamera.mobile.entity.IpcAllEntity;
import com.qihoo360.homecamera.mobile.entity.RecordStoryEntity;
import com.qihoo360.homecamera.mobile.entity.SearchWordEntity;
import com.qihoo360.homecamera.mobile.entity.ShareAcceptEntity;
import com.qihoo360.homecamera.mobile.entity.ShareGetInfoEntity;
import com.qihoo360.homecamera.mobile.entity.ShareGetListEntity;
import com.qihoo360.homecamera.mobile.entity.ShareGetSharingListEntitiy;
import com.qihoo360.homecamera.mobile.entity.ShareShareEntity;
import com.qihoo360.homecamera.mobile.entity.SpaceInfoList;
import com.qihoo360.homecamera.mobile.entity.UserSetting;
import com.qihoo360.homecamera.mobile.env.AppEnv;
import com.qihoo360.homecamera.mobile.http.OkHttpUtils;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.FileUtil;
import com.qihoo360.homecamera.mobile.utils.MD5Util;
import com.qihoo360.homecamera.mobile.utils.MyX509TrustManager;
import com.qihoo360.homecamera.mobile.utils.PhoneUtil;
import com.qihoo360.homecamera.mobile.utils.ZipUtils;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;

public class Api {
    public static final boolean DEBUG = AppEnv.DEBUG;

    public final static class Camera {

        /**
         * 获取所有设备列表
         *
         * @return
         */
        public static DeviceInfoList getCameraList(int page) {
            DeviceInfoList deviceInfoList = null;
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("page", page + "");
                param.put("count", "50");
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.post().params(param).headers(null).url(DefaultClientConfig.APP_GETLIST_URL).build().execute();
                CLog.debugJustalkFile("online_state_", responseStr);
                Gson gson = new Gson();
                deviceInfoList = gson.fromJson(responseStr, DeviceInfoList.class);
                if(deviceInfoList.data.device.size()>0){
                    DeviceInfo df = deviceInfoList.data.device.get(0);
                    CLog.e("hyuan", df.support);
                }
//                for (int i = 0; i < deviceInfoList.data.device.size(); i++){
//                    DeviceInfo df = deviceInfoList.data.device.get(i);
//                    DeviceCloudSettingSupport ds = gson.fromJson(df.support, DeviceCloudSettingSupport.class);
//                    deviceInfoList.data.device.get(i).deviceSettingSupport = ds;
//                    CLog.e("hyuan", "test:" + ds.getTest() + ",setting_v1:" + ds.getSetting_v1());
//                }
                return deviceInfoList;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        /**
         * 分享
         *    新增 device (机器人:'kibot'  故事机:'story' )
         * @return
         */
        public static ShareShareEntity postShareShare(String sn, String type, String phone, String relation, String Acl, String device) {
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("sn", sn);
                setFuncType(param, type);
                param.put("phone", phone);
                if (!TextUtils.isEmpty(relation)) {
                    param.put("relation", relation);
                }
                if (!TextUtils.isEmpty(Acl)) {
                    param.put("aclInfo", Acl);
                }
                param.put("device", device);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.post().params(param).headers(null).url(DefaultClientConfig.SHARE_SHARE_URL).build().execute();
                CLog.e("zhaojunbo", "postShareShare:" + responseStr);
                Gson gson = new Gson();
                ShareShareEntity head = gson.fromJson(responseStr, ShareShareEntity.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        private static void setFuncType( Map<String, String> param, String type){
            if(TextUtils.equals(type, "1")){
                param.put("funcType", Constants.FuncType.QRCODE);
            }else if(TextUtils.equals(type, "2")){
            }else if(TextUtils.equals(type, "3")){//已经废弃
                param.put("funcType", Constants.FuncType.MOBILE);
            }else if(TextUtils.equals(type, "4")){
                param.put("funcType", Constants.FuncType.IPC);
            }else if(TextUtils.equals(type, "5")){
                param.put("funcType", Constants.FuncType.KIBOTFRIEND);
            }else{
                param.put("funcType", Constants.FuncType.BASE);
            }
        }
        /**
         * 响应分享
         *
         * @return
         */
        public static ShareShareEntity postShareResponse(String sn, String sqid, String agree) {
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("sn", sn);
                param.put("sqid", sqid);
                param.put("agree", agree);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.post().params(param).headers(null).url(DefaultClientConfig.SHARE_RESPONSE_URL).build().execute();
                CLog.e("zhaojunbo", "postShareResponse:" + responseStr);
                Gson gson = new Gson();
                ShareShareEntity head = gson.fromJson(responseStr, ShareShareEntity.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        /**
         * 获取管理员信息
         *
         * @return
         */
        public static ShareGetInfoEntity postShareGetInfo(String shareCode) {
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("code", shareCode);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.post().params(param).headers(null).url(DefaultClientConfig.SHARE_GETINFO_URL).build().execute();
                CLog.e("zhaojunbo", "postShareGetInfo:" + responseStr);
                Gson gson = new Gson();
                ShareGetInfoEntity head = gson.fromJson(responseStr, ShareGetInfoEntity.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        /**
         * 接受分享
         *
         * @return
         */
        public static ShareAcceptEntity postShareAccept(String sn, String code, String relation, String startAt, String source) {
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("sn", sn);
                param.put("code", code);
                if (!TextUtils.isEmpty(relation)) {
                    param.put("relation", relation);
                }
                param.put("startAt", startAt);
                param.put("source", source);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.post().params(param).headers(null).url(DefaultClientConfig.SHARE_ACCEPT_URL).build().execute();
                CLog.e("zhaojunbo", "postShareAccept:" + responseStr);
                Gson gson = new Gson();
                ShareAcceptEntity head = gson.fromJson(responseStr, ShareAcceptEntity.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        /**
         * 取消分享
         *
         * @return
         */
        public static Head postShareCancel(String sn, String shareQid, String phone) {
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("sn", sn);
                param.put("device", PadInfoWrapper.getInstance().getPadBySn(sn).isStoryMachine() ?  "story" : "kibot");
                param.put("shareQid", shareQid);
                if (!TextUtils.isEmpty(phone)) {
                    param.put("phone", phone);
                }
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.post().params(param).headers(null).url(DefaultClientConfig.SHARE_CANCEL_URL).build().execute();
                CLog.e("zhaojunbo", "postShareCancel:" + responseStr);
                Gson gson = new Gson();
                Head head = gson.fromJson(responseStr, Head.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        /**
         * 取消分享  (TODO 该接口已经废弃)
         *
         * @return
         */
        public static Head postShareCancelSharing(String sn, String code) {
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("sn", sn);
                param.put("code", code);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.post().params(param).headers(null).url(DefaultClientConfig.SHARE_CANCEL_SHARING_URL).build().execute();
                Gson gson = new Gson();
                Head head = gson.fromJson(responseStr, Head.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        /**
         * 获取分享列表
         *
         * @return
         */
        public static ShareGetListEntity postShareGetList(String sn, String page, String count) {
            String responseStr = "";

            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("sn", sn);
                param.put("page", page);
                param.put("count", count);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                responseStr = OkHttpUtils.post().params(param).headers(null).url(DefaultClientConfig.SHARE_GET_LIST_URL).build().execute();
                CLog.e("zhaojunbo", "postShareGetList:" + responseStr);
                Gson gson = new Gson();
                ShareGetListEntity head = gson.fromJson(responseStr, ShareGetListEntity.class);
                return head;
            } catch (Exception e) {
                if (e != null){
                    CLog.justalkFile("http_app_getList_", "Exception = " + e.toString());
                }

                CLog.justalkFile("http_app_getList_", "responseStr = " + responseStr);

                e.printStackTrace();
                return null;
            }
        }

        /**
         * 获取分享中的列表 (TODO 该接口已经废弃)
         *
         * @return
         */
        public static ShareGetSharingListEntitiy postShareGetSharingList(String sn) {
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("sn", sn);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.post().params(param).headers(null).url(DefaultClientConfig.SHARE_GET_SHARING_LIST_URL).build().execute();
                CLog.e("zhaojunbo", "postShareGetSharingList:" + responseStr);
                Gson gson = new Gson();
                ShareGetSharingListEntitiy head = gson.fromJson(responseStr, ShareGetSharingListEntitiy.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }


        /**
         * 绑定设备
         *
         * @return
         */

        public static AppBindEntity getBindDevice(String activeCode, String bindType) {
            //type 1=输入码，2=二维码
            AppBindEntity deviceInfo;
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("activeCode", activeCode);
                param.put("type", bindType);
                param.put("device", "kibot");
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.post().params(param).headers(null).url(DefaultClientConfig.BIND_DEVICE_URL).build().execute();
                Gson gson = new Gson();
                deviceInfo = gson.fromJson(responseStr, AppBindEntity.class);
                return deviceInfo;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        /**
         * 解绑设备
         *
         * @return
         */
        public static Head getUnBindDevice(String sn, String delCloudData, String delIpcData) {
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("sn", sn);
                param.put("delCloudData", delCloudData);
                param.put("delIpcData", delIpcData);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.post().params(param).headers(null).url(DefaultClientConfig.UN_BIND_DEVICE_URL).build().execute();
                Gson gson = new Gson();
                Head head = gson.fromJson(responseStr, Head.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        /**
         * 修改设备标题和头像
         *
         * @param sn
         * @param title
         * @return
         */
        public static Head updateTitleAndHeadView(String sn, String title) {
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("sn", sn);
                param.put("title", title);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.post().params(param).headers(null).url(DefaultClientConfig.UPDATE_TITLE_HEAD_URL).build().execute();
                CLog.i("lvpeng", "updateTitleAndHeadView:" + responseStr);
                Gson gson = new Gson();
                Head head = gson.fromJson(responseStr, Head.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        /**
         * 申请好友的平板
         *
         * @param sn
         * @return
         */
        public static Head postShareFriendDevice(String sn, String shareCode) {
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("sn", sn);
                param.put("code", shareCode);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.post().params(param).headers(null).url(DefaultClientConfig.SHARE_REQUEST_URL).build().execute();
                CLog.i("yanggang", "postShareFriendDevice:" + responseStr);
                Gson gson = new Gson();
                Head head = gson.fromJson(responseStr, Head.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        /**
         * 响应申请好友申请
         *
         * @param rspsSN
         * @param rqstSN
         * @param agree
         * @return
         */
        public static Head postShareFriendResponse(String rspsSN, String rqstSN, String agree) {
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("sn", rspsSN);
                param.put("sqid", rqstSN);
                param.put("sqidType", "2");
                param.put("agree", agree);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.post().params(param).headers(null).url(DefaultClientConfig.SHARE_RESPONSE_URL).build().execute();
                CLog.e("yanggang", "postShareFriendResponse:" + responseStr);
                Gson gson = new Gson();
                Head head = gson.fromJson(responseStr, Head.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        public static void postLog() {
            sendLog();
        }

        private static String getSign(long time, String fileName) {
            StringBuilder argsToMd5 = new StringBuilder();
            argsToMd5.append("clientId" + "6");
            argsToMd5.append("fileName" + fileName);
            argsToMd5.append("fileTypeId" + "11");
            argsToMd5.append("itemId" + "3");
            argsToMd5.append("time" + time);
            argsToMd5.append("3db7eaf6ebfbb8a62af5b4895bcdce33");
            CLog.e("feedback", argsToMd5.toString());
            return MD5Util.getMD5code(argsToMd5.toString());
        }

        private static int sendLog() {
            Set<File> set = new HashSet<File>();
            HashSet<String> setFiles = new HashSet<String>();
            set.add(new File(FileUtil.getmSDCacheDir() + "/mtc/"));
            FileUtil.enumFilesUnderDir(Environment.getExternalStorageDirectory() + "/360Log/", setFiles);
            for (String filePath : setFiles) {
                Pattern pattern = Pattern.compile("(push_log_kibot)", Pattern.CASE_INSENSITIVE);
                Matcher matcher = pattern.matcher(filePath);
                if (matcher.find()) {
                    set.add(new File(filePath));
                }
            }
            //set.add(new File(Environment.getExternalStorageDirectory() + "/360Log/push_log_kibot.txt"));
            set.add(FileUtil.getInstance().getErrorLog());
            try {
                ZipUtils.zipFiles(set, new File(FileUtil.getmSDCacheDir() + "/errorLog.zip"));
            } catch (IOException e) {
                e.printStackTrace();
            }
            int ret = -1;
            String json = null;
            try {
//                String data = Base64.encodeToString(buffer, 0, length,
//                        Base64.DEFAULT);
                ByteArrayOutputStream dos = new ByteArrayOutputStream();
                InputStream is = null;
                ByteArrayOutputStream fileos = new ByteArrayOutputStream();
                is = new FileInputStream(FileUtil.getmSDCacheDir() + "/errorLog.zip");
                byte[] bytes = new byte[1024 * 1024];
                int len = 0;
                while ((len = is.read(bytes)) != -1) {
                    fileos.write(bytes, 0, len);
                }
                is.close();
                long time = System.currentTimeMillis();
                String fileName = AccUtil.getInstance().getSecPhoneNumber() + "_" + AccUtil.getInstance().getQID() + "_" + PhoneUtil.getDetailDate() + "_log.zip";
                //fileName = AESUtil.decryptStandardBase64(Constants.UPLOAD_AEC_KEY, fileName);
                String sign = getSign(time, fileName);
                String data = new String(Base64.encode(fileos.toByteArray(), Base64.DEFAULT), "utf-8");
                HashMap<String, String> hashMap = new HashMap<String, String>();
                hashMap.put("clientId", "6");
                hashMap.put("fileName", fileName);
                hashMap.put("fileTypeId", "11");
                hashMap.put("itemId", "3");
                hashMap.put("_data", data);
                hashMap.put("time", time + "");
                hashMap.put("_sign", sign);
                CLog.e("feedback", "clientId:" + "6");
                CLog.e("feedback", "fileName:" + "errorLog.zip");
                CLog.e("feedback", "fileTypeId:" + "11");
                CLog.e("feedback", "itemId:" + "3");
                CLog.e("feedback", "time:" + time);
                CLog.e("feedback", sign);
                Gson gson = new Gson();

                HashMap<String, String> headHashMap = new HashMap<String, String>();
                headHashMap.put("host", "log.jia.360.cn");

//                json = OkHttpUtils.postString().mediaType(okhttp3.MediaType.parse("application/json")).params(hashMap)
//                        .content(gson.toJson(hashMap)).withOutCookie().addHeader("host", "log.jia.360.cn").isLogUpload("http://10.108.213.193/file/upload")
//                        .url("http://10.108.213.193/file/upload").build().execute();
//                CLog.e("feedback", json);
//                if (!TextUtils.isEmpty(json)) {
//                    FeedBack feedback = gson.fromJson(json, FeedBack.class);
//                    if (feedback != null && feedback.errmsg != null) {
//                        if (feedback.errno == 0) {
//                            ret = feedback.errno;
//                        } else {
//                        }
//                    }
//                }

                logUpload(gson.toJson(hashMap));

                File file = new File(FileUtil.getmSDCacheDir() + "/errorLog.zip");
                file.delete();
                return ret;
            } catch (Exception e) {
                e.printStackTrace();
            }
            return ret;
        }

        private static void logUpload(String json) {
//            try {
//                URL url = new URL("https://log.jia.360.cn/file/upload");
//                HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
//                conn.setConnectTimeout(10000);
//                conn.setReadTimeout(30000);
//                conn.setDoInput(true); // 允许输入流
//                conn.setDoOutput(true); // 允许输出流
//                conn.setUseCaches(false); // 不允许使用缓存
//                conn.setRequestMethod("POST");
//                conn.setRequestProperty("Charset", "utf-8");
//                conn.setRequestProperty("connection", "keep-alive");
//                conn.setRequestProperty("Content-Type",
//                        "application/json");
//
//                DataOutputStream dos = new DataOutputStream(conn.getOutputStream());
//                dos.write(json.getBytes());
//                dos.flush();
//                dos.close();
//
//                int res = conn.getResponseCode();
//                CLog.e("feedback","uploadFileV2 ResponseCode:" + res);
//                if (res == 200) {
//                    InputStream input = conn.getInputStream();
//                    StringBuffer sb1 = new StringBuffer();
//                    int ss;
//                    while ((ss = input.read()) != -1) {
//                        sb1.append((char) ss);
//                    }
//                    String result = sb1.toString();
//                    result = new String(result.getBytes("utf-8"), "utf-8");
//                    CLog.e("feedback",result);// result不是合法的json格式
//                }
//            } catch (IOException e) {
//                e.printStackTrace();
//            }


            try {
                // 创建SSLContext对象，并使用我们指定的信任管理器初始化
                TrustManager[] tm = {new MyX509TrustManager()};
                SSLContext sslContext = SSLContext.getInstance("TLS");

                sslContext.init(null, tm, new java.security.SecureRandom());
                // 从上述SSLContext对象中得到SSLSocketFactory对象
                SSLSocketFactory ssf = sslContext.getSocketFactory();
                // 创建URL对象
                URL myURL = new URL("https://log.jia.360.cn/file/upload");
                // 创建HttpsURLConnection对象，并设置其SSLSocketFactory对象
                HttpsURLConnection conn = (HttpsURLConnection) myURL.openConnection();
                conn.setConnectTimeout(30000);
                conn.setReadTimeout(30000);
                conn.setDoInput(true); // 允许输入流
                conn.setDoOutput(true); // 允许输出流
                conn.setUseCaches(false); // 不允许使用缓存
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Charset", "utf-8");
                conn.setRequestProperty("connection", "keep-alive");
                conn.setRequestProperty("Content-Type",
                        "application/json");
                conn.setSSLSocketFactory(ssf);


                DataOutputStream dos = new DataOutputStream(conn.getOutputStream());
                dos.write(json.getBytes());
                dos.flush();
                dos.close();

                int res = conn.getResponseCode();
                CLog.e("feedback", "uploadFileV2 ResponseCode:" + res);
                if (res == 200) {
                    InputStream input = conn.getInputStream();
                    StringBuffer sb1 = new StringBuffer();
                    int ss;
                    while ((ss = input.read()) != -1) {
                        sb1.append((char) ss);
                    }
                    String result = sb1.toString();
                    result = new String(result.getBytes("utf-8"), "utf-8");
                    CLog.e("feedback", result);// result不是合法的json格式
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }


        /**
         * 取消好友
         *
         * @param rspsSN
         * @param rqstSN
         * @return
         */
        public static Head postShareFriendCancel(String rspsSN, String rqstSN) {
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("sn", rspsSN);
                param.put("shareQid", rqstSN);
                param.put("shareQidType", "2");
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.post().params(param).headers(null).url(DefaultClientConfig.SHARE_CANCEL_URL).build().execute();
                CLog.e("yanggang", "postShareFriendCancel:" + responseStr);
                Gson gson = new Gson();
                Head head = gson.fromJson(responseStr, Head.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        /**
         * 设置备注
         *
         * @return
         */
        public static Head postShareSetRemark(String sn, String sqid, String newRemark) {
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("sn", sn);
                param.put("sqid", sqid);
                param.put("remarkName", newRemark);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.post().params(param).headers(null).url(DefaultClientConfig.SHARE_SET_REMARK_URL).build().execute();
                CLog.e("yanggang", "postShareFriendCancel:" + responseStr);
                Gson gson = new Gson();
                Head head = gson.fromJson(responseStr, Head.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }
    }

    public final static class Album {

        public final static int ALBUM_LOAD_NUM_PER_PAGE = 20;

        /**
         * 查询相册
         *
         * @param sn
         * @param page
         * @return
         */
        public static ImageInfoListEntity getAppAlbumList(String sn, String page, String device) {
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("sn", sn);
                param.put("page", page);
                param.put("pageSize", "" + ALBUM_LOAD_NUM_PER_PAGE);
                param.put("device", device);
                param.put("funcType","videoClip");//写死就行
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.post().params(param).headers(null).url(DefaultClientConfig.APP_VIDEO_LIST_URL).build().execute();
                //模拟的假数据
                //String responseStr = Constants.TEMP_JSON;
                CLog.i("test2", "getAppAlbumList sn :" + sn);
                Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
                ImageInfoListEntity head = gson.fromJson(responseStr, ImageInfoListEntity.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        /**
         * 删除文件
         *
         * @param sn
         * @param imageIdList 待删除文件列表
         * @return
         */
        public static Head deleteAlbumFile(String sn, ArrayList<Long> imageIdList, String device) {
            try {
                if (imageIdList == null || imageIdList.size() == 0) {
                    return null;
                }

                StringBuffer stringBuffer = new StringBuffer();
                for (int i = 0; i < imageIdList.size(); i++) {
                    stringBuffer.append(imageIdList.get(i));
                    if (i < imageIdList.size() - 1) {
                        stringBuffer.append(",");
                    }
                }

                Map<String, String> param = new HashMap<String, String>();
                param.put("sn", sn);
                param.put("imageId", "" + stringBuffer.toString());
                param.put("funcType", "videoClip");
                param.put("device", device);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.post().params(param).headers(null).url(DefaultClientConfig.APP_VIDEO_DELETE_URL).build().execute();
                Gson gson = new Gson();
                Head head = gson.fromJson(responseStr, Head.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        public static ImageInfoListEntity getOneDayAlbumList(String sn, String page) {
            try {
                Gson gson = new Gson();
                ImageInfoListEntity head = gson.fromJson(Constants.json1, ImageInfoListEntity.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }
    }


    public final static class SearchWord {
        public static SearchWordEntity postSearchWord(String key) {
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("content", key);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.post().params(param).headers(null).url(DefaultClientConfig.SEARCH_WORD_KEY_URL).build().execute();
                //模拟的假数据
                //responseStr = "{\"errorCode\": 0, \"errorMsg\": \"OK\", \"data\": [\"\\u7f8a\\u8001\\u5e08\\u7684\\u602a\\u62db\", \"\\u7f8a\\u4e0e\\u5403\\u9971\\u4e86\\u7684\\u72fc\"]}";
                CLog.e("zhaojunbo", "getAppAlbumList:" + responseStr);
                Gson gson = new Gson();
                SearchWordEntity head = gson.fromJson(responseStr, SearchWordEntity.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        public static SearchWordEntity postSearch(String key) {
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("content", key);
                param.put("from", "mpc_pingmuban_and");
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.post().params(param).headers(null).url(DefaultClientConfig.SEARCH_WORD_URL).build().execute();
                //模拟的假数据
                //responseStr = "{\"errorCode\": 0, \"errorMsg\": \"OK\", \"data\": [\"\\u7f8a\\u8001\\u5e08\\u7684\\u602a\\u62db\", \"\\u7f8a\\u4e0e\\u5403\\u9971\\u4e86\\u7684\\u72fc\"]}";
                CLog.e("zhaojunbo", "getAppAlbumList:" + responseStr);
                Gson gson = new Gson();
                SearchWordEntity head = gson.fromJson(responseStr, SearchWordEntity.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }
    }

    public final static class UserInfo {
        public static AppGetInfoEntity postAppGetInfo(String sn) {
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("sn", sn);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.post().params(param).headers(null).url(DefaultClientConfig.APP_GET_INFO_URL).build().execute();
                CLog.json("zhaojunbo", "postAppGetInfo:" + responseStr);
                Gson gson = new Gson();
                AppGetInfoEntity head = gson.fromJson(responseStr, AppGetInfoEntity.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        public static Head postAppUpdateInfo(String sn, String qid, String relation, String title, String babyInfo, String fileName, String filePath) {
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("sn", sn);
                param.put("qid", qid);
                param.put("title", title);
                param.put("relation", relation);
                param.put("babyInfo", babyInfo);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                File file = new File(filePath);
//                File tmpFile = new File(FileUtil.getInstance().getAvatorFile().getAbsolutePath(), "/new_avator.png");
                String responseStr = "";
                if (file.exists()) {
                    responseStr = OkHttpUtils.post().addFile("imageData", fileName, file).params(param).headers(null).url(DefaultClientConfig.APP_UPDATE_INFO_URL).build().execute();
                } else {
                    responseStr = OkHttpUtils.post().params(param).headers(null).url(DefaultClientConfig.APP_UPDATE_INFO_URL).build().execute();
                }

                CLog.e("zhaojunbo", "postAppUpdateInfo:" + responseStr);
                Gson gson = new Gson();
                Head head = gson.fromJson(responseStr, Head.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        public static Head postShareSetRelation(String sn, String relation, String sqid) {
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("sn", sn);
                param.put("relation", relation);
                if (TextUtils.isEmpty(sqid)) {
                    param.put("sqid", AccUtil.getInstance().getQID());
                } else {
                    param.put("sqid", sqid);
                }
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.post().params(param).headers(null).url(DefaultClientConfig.SHARE_SET_RELATION_URL).build().execute();
                CLog.e("zhaojunbo", "postShareSetRelation:" + responseStr);
                Gson gson = new Gson();
                Head head = gson.fromJson(responseStr, Head.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        /**
         * 设置个人中心用户相册提醒设置
         *
         * @return
         */
        public static Head postSetPersonSetting(String val) {
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("stype", String.valueOf(2));
                param.put("key", "all_notify");
                param.put("val", val);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.post().params(param).isHttps(true).headers(null).url(DefaultClientConfig.PERSION_SET_SETTING).build().execute();
                CLog.e("yanggang", "postSetPersonSetting:" + responseStr);
                Gson gson = new Gson();
                Head head = gson.fromJson(responseStr, Head.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        /**
         * 获取个人中心用户相册提醒设置
         *
         * @return
         */
        public static UserSetting postGetPersonSetting() {
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("stype", String.valueOf(2));
                param.put("key", "all_notify");//所有消息的总开关
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.post().params(param).isHttps(true).headers(null).url(DefaultClientConfig.PERSION_GET_SETTING).build().execute();
                CLog.e("yanggang", "postGetPersonSetting:" + responseStr);
                Gson gson = new Gson();
                UserSetting persionSetting = gson.fromJson(responseStr, UserSetting.class);
                return persionSetting;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        public static SpaceInfoList getSpaceInfoList(String sn) {
            try {
                SpaceInfoList mSpaceInfoList = new SpaceInfoList();
                Map<String, String> param = new HashMap<String, String>();
                param.put("sn", sn);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.post().params(param).headers(null).url(DefaultClientConfig.PERSION_GET_SPACE_INFO).build().execute();
                CLog.e("wsy", "getSpaceInfoList:" + responseStr);
                Gson gson = new Gson();
                Head head = gson.fromJson(responseStr, Head.class);
                if(head.errorCode == 0){
                    mSpaceInfoList = gson.fromJson(responseStr, SpaceInfoList.class);
                }
                return mSpaceInfoList;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        public static boolean clearCache() {
            try {
                ArrayList<File> delList = new ArrayList<File>();

                File videoCacheDir = FileUtil.getInstance().getmSDCacheDir();
                if (videoCacheDir.isDirectory()) {
                    for (File item : videoCacheDir.listFiles()) {
                        if (item.isFile() && item.getName().startsWith("com.qihoo360.kibot-")) {
                            delList.add(item);
                        }
                    }
                }
                File imgCacheDir = new File(FileUtil.getInstance().getmSDCacheDir(), ".cache_dir_name");
                if (imgCacheDir.isDirectory()) {
                    for (File item : imgCacheDir.listFiles()) {
                        if (item.isFile()) {
                            delList.add(item);
                        }
                    }
                }

                File downloadDir = FileUtil.getInstance().getStoryFile();
                if (downloadDir.isDirectory()) {
                    for (File item : downloadDir.listFiles()) {
                        delList.add(item);
                    }
                }

                for (File file : delList) {
                    if (file.exists()) {
                        file.delete();
                    } else {
                        continue;
                    }
                }
                return true;
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
//            File downloadDir = FileUtil.getInstance().getStoryFile();
//            if (downloadDir != null)
//                return FileUtil.deleteDirectory(downloadDir);


        }

        public static long calculateCache() {
            long dashSize = 0;
            File videoCacheDir = FileUtil.getInstance().getmSDCacheDir();
            if (videoCacheDir.isDirectory()) {
                for (File item : videoCacheDir.listFiles()) {
                    if (item.isFile() && item.getName().startsWith("com.qihoo360.kibot-")) {
                        dashSize += item.length();
                    }
                }
            }

            File imgCacheDir = new File(FileUtil.getInstance().getmSDCacheDir(), ".cache_dir_name");
            if (imgCacheDir != null)
                dashSize += FileUtil.getDirectorySize(imgCacheDir);

            File downloadDir = FileUtil.getInstance().getStoryFile();
            if (downloadDir != null)
                dashSize += FileUtil.getDirectorySize(downloadDir);

            return dashSize;
        }
    }

    public final static class RecordStory {
        public static RecordStoryEntity postRecordStory(Integer type, Integer page) {
            String url = "";
            switch (type) {
                case Actions.Story.VOICE_IDIOM:
                    url = String.format(DefaultClientConfig.VOICE_IDIOM_URL, page);
                    break;
                case Actions.Story.VOICE_ALLEGORY:
                    url = String.format(DefaultClientConfig.VOICE_ALLEGORY_URL, page);
                    break;
                case Actions.Story.VOICE_FAIRYTALE:
                    url = String.format(DefaultClientConfig.VOICE_FAIRYTALE_URL, page);
                    break;
                default:
                    url = String.format(DefaultClientConfig.VOICE_IDIOM_URL, page);
                    break;
            }
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.post().params(param).headers(null).url(url).build().execute();
                CLog.e("zhaojunbo", "postRecordStory:" + responseStr);
                Gson gson = new Gson();
                RecordStoryEntity head = gson.fromJson(responseStr, RecordStoryEntity.class);
                head.type = type;
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }
    }

    public final static class Command {
        /**
         * command send
         *
         * @return
         */
        public static CommandResponse postCommand(String cmd, String content, String qid,
                                                  int expire, long time, String recvSn) {
            try {
                CLog.e("cmd", "cmd:" + cmd  + ",content:" + content + ",qid:" + qid + ", expire:" + expire + ", time:" + time + ", recvSn:" + recvSn);
                Map<String, String> param = new HashMap<String, String>();
                param.put("cmd", cmd);
                param.put("content", content);
                param.put("qid", qid);
                param.put("expire", expire + "");
                param.put("recvSn", recvSn);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                CLog.e("cmd", "param:" + param.toString());
                String responseStr = OkHttpUtils.post().params(param).headers(null).url(DefaultClientConfig.COMMAND_MESSAGE).build().execute();
                CLog.e("cmd", "postCommand:" + responseStr);
                Gson gson = new Gson();
                CommandResponse head = gson.fromJson(responseStr, CommandResponse.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }
    }

    public final static class PadSetting {

        public static IpcAllEntity getAllPadSetting(String sn) {
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("sn", sn);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.post().params(param).headers(null).url(DefaultClientConfig.GET_IPC_ALL).build().execute();
                CLog.e("zhaojunbo", "getAllPadSetting:" + responseStr);
                Gson gson = new Gson();
                IpcAllEntity head = gson.fromJson(responseStr, IpcAllEntity.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        public static Head setSetting(String sn, String settingJson) {
            try {
                CLog.e("zhaojunbo", "getAllPadSetting settingJson = " + settingJson);
                Map<String, String> param = new HashMap<String, String>();
                param.put("sn", sn);
                param.put("settings", settingJson);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.post().params(param).headers(null).url(DefaultClientConfig.SET_SETTING_SETIPCSOME).build().execute();
                CLog.e("zhaojunbo", "getAllPadSetting:" + responseStr);
                Gson gson = new Gson();
                Head head = gson.fromJson(responseStr, Head.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        public static Head setDoSetAcl(String sqid, String sn, String aclInfo) {
            try {
                Map<String, String> param = new HashMap<String, String>();
                param.put("sqid", sqid);
                param.put("sn", sn);
                param.put("aclInfo", aclInfo);
                param.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
                String responseStr = OkHttpUtils.post().params(param).headers(null).url(DefaultClientConfig.SET_ACL).build().execute();
                CLog.e("zhaojunbo", "setDoSetAcl:" + responseStr);
                Gson gson = new Gson();
                Head head = gson.fromJson(responseStr, Head.class);
                return head;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }
    }
}
