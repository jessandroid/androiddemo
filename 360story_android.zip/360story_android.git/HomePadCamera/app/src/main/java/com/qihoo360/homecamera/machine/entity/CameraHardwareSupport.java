
package com.qihoo360.homecamera.machine.entity;

public class CameraHardwareSupport {
   public String angle;
   public int distort;
   public int no_mic;//是否有麦克风
   public int no_light;//是否有指示灯
   public int no_speaker;//是否能通话
 }
