
package com.qihoo360.homecamera.mobile.core.db;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.debug.DebugUtil;
import com.qihoo360.homecamera.mobile.core.util.Stoppable;

public class Db implements Stoppable {
    private SQLiteOpenHelper mSqlHelper;
    private boolean mIsStopped = false;

    public Db(SQLiteOpenHelper sqlHelper) {
        mSqlHelper = sqlHelper;
    }

    public SQLiteDatabase getWritableDb() {
        return mSqlHelper.getWritableDatabase();
    }

    public SQLiteDatabase getReadableDb() {
        return mSqlHelper.getReadableDatabase();
    }

    public String dumpTable(String tableName) {
        Cursor cursor = getWritableDb().query(tableName, null, null, null, null, null, null);
        return DebugUtil.dumpCursor(cursor);
    }

    public void deleteTableContent(String tableName) {
        getWritableDb().execSQL("delete from " + tableName);
    }

    @Override
    public void stopNow() {
        mIsStopped = true;
        mSqlHelper.close();
    }

    @Override
    public boolean isStopped() {
        return mIsStopped;
    }

    @Override
    public void destroyNow() {
        mSqlHelper = null;
    }
}
