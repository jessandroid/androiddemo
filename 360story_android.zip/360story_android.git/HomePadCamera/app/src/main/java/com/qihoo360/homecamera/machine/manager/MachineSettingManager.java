package com.qihoo360.homecamera.machine.manager;

import android.app.Application;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.qihoo360.homecamera.mobile.config.DefaultClientConfig;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionPublisherWithThreadPoolBase;
import com.qihoo360.homecamera.mobile.core.manager.workpool.PoolThreadFactory;
import com.qihoo360.homecamera.mobile.core.net.Api;
import com.qihoo360.homecamera.mobile.core.net.MachineApi;
import com.qihoo360.homecamera.mobile.db.CommonWrapper;
import com.qihoo360.homecamera.mobile.entity.Head;
import com.qihoo360.homecamera.mobile.entity.IpcAllEntity;
import com.qihoo360.homecamera.mobile.http.OkHttpUtils;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;


public class MachineSettingManager extends ActionPublisherWithThreadPoolBase {
    private final String mPoolNameHighPriority, mPoolNameLowPriority;
    private final Application mApp;

    public MachineSettingManager(Application app) {
        this.mApp = app;
        mPoolNameHighPriority = "PadSettingManager-high-priority-" + Utils.DATE_FORMAT_3.format(new Date());
        mPoolNameLowPriority = "PadSettingManager-low-priority-" + Utils.DATE_FORMAT_3.format(new Date());
        mThreadPool.initPool(mPoolNameHighPriority, Executors.newFixedThreadPool(3));
        mThreadPool.initPool(mPoolNameLowPriority,
                Executors.newCachedThreadPool(new PoolThreadFactory(mPoolNameLowPriority)));
    }

    //设置故事机小视频开关
    public void asynSetMachineVideoCatch(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("SetVideoCatch", args));
    }

    //得到故事机小视频抓怕开关状态
    public void aysnGetMachineVideoCatch(Object... args){
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("GetVideoCatch", args));
    }

    @Override
    protected void asyncDoNamedJob(String jobName, Object... args) {
        if (TextUtils.equals(jobName, "SetVideoCatch")) {
            doSetMachineVideoCatch((String)args[0], (String)args[1]);
        }else if(TextUtils.equals(jobName, "GetVideoCatch")){
            doGetMachineVideoCatch((String)args[0]);
        }
    }

    private void doSetMachineVideoCatch(String setting, String sn){
        Head head = MachineApi.Machine.setMachineVideoCatch(setting, sn);
        publishAction(Actions.GlobalActionCode.SETTING_MACHINE_VIDEO_CAPTRUE, head);
    }

    private void doGetMachineVideoCatch(String sn){
        publishAction(Actions.GlobalActionCode.GETTING_MACHINE_VIDEO_CAPTRUE, MachineApi.Machine.getMachineVideoCatch(sn));
    }
}

