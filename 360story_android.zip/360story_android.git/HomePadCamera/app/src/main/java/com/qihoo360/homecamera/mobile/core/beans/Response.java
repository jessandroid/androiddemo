
package com.qihoo360.homecamera.mobile.core.beans;

import java.util.HashMap;
import java.util.Map.Entry;

public class Response {
    private final static byte[] ZeroByte = new byte[0];
    public int httpStatus;
    public String stringContent = "";
    public byte[] byteContent = ZeroByte;
    public HashMap<String, String> cookies;
    public HashMap<String, String> headers;

    public String errorMessage = null;
    public int errorNumber = 0;

    public String requestUrl;

    @Override
    public String toString() {
        StringBuilder buf = new StringBuilder();
        buf.append("## StringContent:");
        buf.append('\n');
        buf.append(stringContent);
        buf.append('\n');

        if (cookies != null && cookies.size() != 0) {
            buf.append("## Cookies:");
            buf.append('\n');
            for (Entry<String, String> entry : cookies.entrySet()) {
                buf.append("c+" + entry.getKey());
                buf.append('=');
                buf.append(entry.getValue());
                buf.append('\n');
            }
        }
        if (headers != null && headers.size() != 0) {
            buf.append("## Headers:");
            for (Entry<String, String> entry : headers.entrySet()) {
                buf.append(entry.getKey());
                buf.append('=');
                buf.append(entry.getValue());
                buf.append('\n');
            }
        }
        return buf.toString();
    }
}
