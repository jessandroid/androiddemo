package com.qihoo360.homecamera.mobile.db;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.qihoo360.homecamera.mobile.entity.ImageInfoListEntity;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;

/**
 * Created by wangshiyuan on 2016/6/23.
 */
public class VideoCacheWrapper extends AbstractWrapper {

    private static VideoCacheWrapper videoCacheWrapper;
    private static final String TABLE_NAME = "video_cache";

    private VideoCacheWrapper() {

    }

    public synchronized static VideoCacheWrapper getInstance() {
        if (videoCacheWrapper == null) {
            videoCacheWrapper = new VideoCacheWrapper();
        }
        return videoCacheWrapper;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int toVersion) {

    }

    @Override
    public void onOpen(SQLiteDatabase db) {

    }


    public synchronized void saveVideoCache(String sn, ImageInfoListEntity.Data data) {
        if (TextUtils.isEmpty(sn)){
            return;
        }

        if (data == null) {
            return;
        }

        SQLiteDatabase db = GlobalManager.getInstance().config().db.getWritableDatabase();
        ContentValues values = new ContentValues();

        Gson gson = new Gson();
        String dataStr = gson.toJson(data);

        values.put(Field.KEY_SN, sn);
        values.put(Field.B, dataStr);
        try {
            if (exist(sn)) {
                db.delete(TABLE_NAME, Field.KEY_SN + "= ?", new String[]{String.valueOf(sn)});
            }
            db.insert(TABLE_NAME, null, values);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean exist(String sn) throws Exception {
        boolean exist = false;
        if (TextUtils.isEmpty(sn)) {
            return false;
        }
        long queryRes = queryQidCount(sn);
        if (queryRes > 0) {
            exist = true;
        }
        return exist;
    }

    private Long queryQidCount(String sn) {
        if (TextUtils.isEmpty(sn)){
            long count = 0;
            return count;
        }

        SQLiteDatabase db = GlobalManager.getInstance().config().db.getWritableDatabase();
        long count = 0;
        StringBuffer sb = new StringBuffer("");
        sb.append("select count(_id) from ");
        sb.append(TABLE_NAME);
        sb.append(" where " + Field.KEY_SN + " ='" + sn + "'");
        try {
            SQLiteStatement statement = db.compileStatement(sb.toString());
            count = statement.simpleQueryForLong();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }
        return count;
    }

    public ImageInfoListEntity.Data getVideoCache(String sn) {

        if (TextUtils.isEmpty(sn)){
            return null;
        }

        SQLiteDatabase db = GlobalManager.getInstance().config().db.getReadableDatabase();
        ImageInfoListEntity.Data data = null;
        Cursor cursor = null;
        Gson gson = new Gson();
        try {
            cursor = db.query(TABLE_NAME, null, Field.KEY_SN + " = ?", new String[]{sn}, null, null, null);
            while (cursor.moveToNext()) {
                String result = cursor.getString(cursor.getColumnIndex(Field.B));
                if (!TextUtils.isEmpty(result)){
                    data = gson.fromJson(result, ImageInfoListEntity.Data.class);
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return data;
    }

    public class Field {
        public static final String KEY_ID = "_id";
        public static final String KEY_SN = "sn";
        public static final String B = "b";
        public static final String C = "c";
        public static final String D = "d";
        public static final String E = "e";
        public static final String F = "f";
        public static final String G = "g";
    }
}
