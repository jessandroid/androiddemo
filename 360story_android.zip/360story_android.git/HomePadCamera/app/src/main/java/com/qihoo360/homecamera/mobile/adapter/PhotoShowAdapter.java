package com.qihoo360.homecamera.mobile.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.drawable.GlideDrawable;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.entity.ImageInfoEntity;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.ImageCache;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.widget.CustomVideoItem;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by zhaojunbo on 2016/3/29.
 * desc:
 */
public class PhotoShowAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private Context mContext;
    private static final int TYPE_NONE = 0;
    private static final int TYPE_TITLE = 1;
    private static final int TYPE_LINE = 2;
    private static final int TYPE_FOOTER = 3;
    private static final int TYPE_NO_MORE = 4;
    private boolean mSelectable = false;

    private ConcurrentHashMap<String, ArrayList<ImageInfoEntity>> mNewDataMap = new ConcurrentHashMap<String, ArrayList<ImageInfoEntity>>();
    private ArrayList<String> mTimeList = new ArrayList<String>();
    private IOnSelectItem iOnSelectItem;
    private ArrayList<ImageInfoEntity> mImageInfoList;
    private IOnCheckListener mOnCheckListener;

    private ArrayList<ItemInfo> mItemInfoList = new ArrayList<>();
    private int mItemInfoTotal = 0;

    private boolean mLoadToTheEnd = true;

    private final static int ITEM_LINE_NUM = 3;

    private int mVideoCount = 0;
    private int mPhotoCount = 0;
    private boolean isStoryMachine;


    public PhotoShowAdapter(Context context, boolean isStory) {
        this.mContext = context;
        this.isStoryMachine = isStory;
    }

    public synchronized void addData(ArrayList<ImageInfoEntity> imageInfoList) {
        if (imageInfoList != null) {
            mImageInfoList = imageInfoList;
//            sortList(mImageInfoList);
            for (int i = 0; i < imageInfoList.size(); i++) {
                Date data = imageInfoList.get(i).getDate();
                String title = "";
                if (data != null) {
                    title = Utils.DATE_FORMAT_5.format(data);
                }

                if (mNewDataMap.containsKey(title)) {
                    ArrayList<ImageInfoEntity> arrayList = mNewDataMap.get(title);
                    arrayList.add(imageInfoList.get(i));
                    mNewDataMap.put(title, arrayList);
                } else {
                    ArrayList<ImageInfoEntity> arrayList = new ArrayList<>();
                    arrayList.add(imageInfoList.get(i));
                    mNewDataMap.put(title, arrayList);
                    mTimeList.add(title);
                }

                //统计视频和照片个数
                if (imageInfoList.get(i) != null) {
                    //0 图片
                    if (imageInfoList.get(i).ftype == 0) {
                        mPhotoCount++;
                    }
                    //1 视频
                    else {
                        mVideoCount++;
                    }
                }
            }

            calcItemInfoList();

            notifyDataSetChanged();
        }
    }

    private void sortList(ArrayList<ImageInfoEntity> list) {
        if (list == null || list.size() == 0) {
            return;
        }

        ImageInfoEntity imageInfoEntity = null;

        for (int i = 0; i < list.size(); i++) {
            imageInfoEntity = list.get(i);
            for (int j = i; j < list.size(); j++) {
                if (list.get(j).getDate().compareTo(imageInfoEntity.getDate()) == 1) {
                    imageInfoEntity = list.get(j);
                }
            }

            list.remove(imageInfoEntity);
            list.add(i, imageInfoEntity);
        }
    }

    private void calcItemInfoList() {
        //清空sum

        mItemInfoTotal = 0;
        mItemInfoList.clear();
        for (int i = 0; i < mTimeList.size(); i++) {
            ArrayList<ImageInfoEntity> arrayList = mNewDataMap.get(mTimeList.get(i));

            ItemInfo titleItemInfo = getItemInfo();
            titleItemInfo.mType = ItemInfo.ITEM_INFO_TYPE_TITLE;
            titleItemInfo.mTitleIndex = i;
            titleItemInfo.mItemIndex = 0;
            titleItemInfo.mPosition = mItemInfoTotal;
            titleItemInfo.mTitlePosition = -1;
            mItemInfoTotal++;

            for (int j = 0; j < arrayList.size(); j++) {
                if (j % ITEM_LINE_NUM == 0) {
                    ItemInfo lineItemInfo = getItemInfo();
                    lineItemInfo.mType = ItemInfo.ITEM_INFO_TYPE_LINE;
                    lineItemInfo.mTitleIndex = i;
                    lineItemInfo.mItemIndex = j;
                    lineItemInfo.mPosition = mItemInfoTotal;
                    lineItemInfo.mTitlePosition = titleItemInfo.mPosition;
                    mItemInfoTotal++;
                }
            }
        }

        addNoMoreItem();
    }

    private boolean addNoMoreItem() {
        //到最后了 并且总数>6个显示 太少了 不显示no more
        if (mLoadToTheEnd && mItemInfoTotal > 6) {
            ItemInfo lineItemInfo = getItemInfo();
            lineItemInfo.mType = ItemInfo.ITEM_INFO_TYPE_NO_MORE;
            mItemInfoTotal++;

            return true;
        }
        return false;
    }


    private ItemInfo getItemInfo() {
        ItemInfo itemInfo = new ItemInfo();
        mItemInfoList.add(itemInfo);
        return itemInfo;
    }

    public void setData(ArrayList<ImageInfoEntity> imageInfoList) {
        mNewDataMap.clear();
        mTimeList.clear();
        mItemInfoTotal = 0;
        mItemInfoList.clear();

        //统计照片和视频个数
        mVideoCount = 0;
        mPhotoCount = 0;

        addData(imageInfoList);
    }

    @Override
    public int getItemViewType(int position) {
        int nItemType = mItemInfoList.get(position).mType;
        if (nItemType == ItemInfo.ITEM_INFO_TYPE_TITLE) {
            return TYPE_TITLE;
        } else if (nItemType == ItemInfo.ITEM_INFO_TYPE_LINE) {
            return TYPE_LINE;
        } else if (nItemType == ItemInfo.ITEM_INFO_TYPE_NO_MORE) {
            return TYPE_NO_MORE;
        }

        return TYPE_NONE;
    }

    @Override
    public int getItemCount() {
        return mItemInfoTotal;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        if (viewType == TYPE_LINE) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item, parent, false);
            return new ViewHolderLine(view);
        } else if (viewType == TYPE_TITLE) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.header_item, parent, false);
            return new ViewHolderTitle(view);
        } else if (viewType == TYPE_NO_MORE) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.video_no_more, parent, false);
            return new ViewHolderItemNoMore(view);
        } else {
            return null;
        }
    }

    private boolean onBind;

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {

        if (holder instanceof ViewHolderTitle) {
            final ViewHolderTitle viewHolderHead = (ViewHolderTitle) holder;

            final ItemInfo itemInfo = mItemInfoList.get(position);

            //保护代码
            if (itemInfo.mTitleIndex >= mTimeList.size()) {
                return;
            }

            boolean hasUnSelected = false;
            ArrayList<ImageInfoEntity> imageInfoEntityArrayList = mNewDataMap.get(mTimeList.get(itemInfo.mTitleIndex));

            //保护代码
            if (imageInfoEntityArrayList == null) {
                return;
            }

            if (imageInfoEntityArrayList != null && imageInfoEntityArrayList.size() > 0) {
//                String title = getTitleDateString(imageInfoEntityArrayList.get(0).getDate())
//                        + "（" + imageInfoEntityArrayList.size() + "）";

                //去掉日期旁边的数据

                String title = getTitleDateString(imageInfoEntityArrayList.get(0).getDate());
//                if(mLoadToTheEnd){
//                    title = dateStr + "（" + imageInfoEntityArrayList.size() + "）";
//                }else {
//                    title = dateStr;
//                }

                viewHolderHead.mTitleTv.setText(title);
            } else {
                viewHolderHead.mTitleTv.setText(mTimeList.get(itemInfo.mTitleIndex));
            }

            for (int i = 0; i < imageInfoEntityArrayList.size(); i++) {
                if (!imageInfoEntityArrayList.get(i).isChecked) {
                    hasUnSelected = true;
                }
            }
            onBind = true;
            viewHolderHead.mSelectOnedayCb.setVisibility(mSelectable ? View.VISIBLE : View.INVISIBLE);
            viewHolderHead.mSelectOnedayCb.setChecked(!hasUnSelected);
            viewHolderHead.mSelectOnedayCb.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ArrayList<ImageInfoEntity> imageInfoEntityArrayList = mNewDataMap.get(mTimeList.get(itemInfo.mTitleIndex));
                    for (int i = 0; i < imageInfoEntityArrayList.size(); i++) {
                        imageInfoEntityArrayList.get(i).isChecked = viewHolderHead.mSelectOnedayCb.isChecked();
                    }

                    for (int i = position + 1; i < mItemInfoList.size(); i++) {
                        if (mItemInfoList.get(i).mType == ItemInfo.ITEM_INFO_TYPE_LINE) {
                            notifyItemChanged(i);
                        } else {
                            break;
                        }
                    }

                    if (mOnCheckListener != null) {
                        mOnCheckListener.updateCheckNum(getDeleteFileNum());
                    }
                }
            });
            onBind = false;
            viewHolderHead.mSelectOnedayCb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                    if (isChecked) {
//                        ArrayList<ImageInfoEntity> imageInfoEntityArrayList = mNewDataMap.get(mTimeList.get(position / 2));
//                        for (int i = 0; i < imageInfoEntityArrayList.size(); i++) {
//                            imageInfoEntityArrayList.get(i).isChecked = isChecked;
//                        }
//                        if (!onBind) {
//                            notifyDataSetChanged();
//                        }
                    }
                }
            });
        } else if (holder instanceof ViewHolderLine) {

            ViewHolderLine viewHolderLine = (ViewHolderLine) holder;

            ItemInfo itemInfo = mItemInfoList.get(position);
            int nTitleIndex = itemInfo.mTitleIndex;
            int nItemIndex = itemInfo.mItemIndex;

            if (nTitleIndex < 0 || nItemIndex < 0) {
                return;
            }

            String title = "";
            ImageInfoEntity imageInfoEntity = null;

            for (int i = 0; i < viewHolderLine.mAlbumList.size(); i++) {

                title = "";
                imageInfoEntity = null;

                if (nTitleIndex < mTimeList.size()) {
                    title = mTimeList.get(nTitleIndex);
                }

                int nIndex = nItemIndex + i;

                if (!TextUtils.isEmpty(title)) {
                    if (mNewDataMap.get(title) != null) {
                        if (nIndex < mNewDataMap.get(title).size()) {
                            imageInfoEntity = mNewDataMap.get(title).get(nIndex);
                        }
                    }
                }

                boolean bResult = setAlbumItem(viewHolderLine.mAlbumList.get(i), imageInfoEntity, itemInfo, nIndex);
                if (bResult) {
                    viewHolderLine.mAlbumList.get(i).setVisibility(View.VISIBLE);
                } else {
                    viewHolderLine.mAlbumList.get(i).setVisibility(View.GONE);
                }
            }

        } else if (holder instanceof ViewHolderItemNoMore) {
            ViewHolderItemNoMore viewHolder = (ViewHolderItemNoMore) holder;
            int nVisibility = View.GONE;
            if (mLoadToTheEnd) {
                nVisibility = View.VISIBLE;
                if(isStoryMachine){//故事机都是视频
                    viewHolder.mVideoStats.setText(mContext.getString(R.string.story_video_type_stats, mVideoCount));
                }else{
                    viewHolder.mVideoStats.setText(mContext.getString(R.string.video_type_stats, mVideoCount, mPhotoCount));
                }
            }

            viewHolder.mView.setVisibility(nVisibility);
        }
    }

    public void setLoadToEnd(boolean isEnd) {
        if (mLoadToTheEnd == isEnd) {
            return;
        }

        mLoadToTheEnd = isEnd;

        if (mItemInfoList.size() == 0) {
            return;
        }

        if (mItemInfoTotal > mItemInfoList.size()) {
            return;
        }

        if (mItemInfoTotal - 1 < 0) {
            return;
        }

        ItemInfo lastItemInfo = mItemInfoList.get(mItemInfoTotal - 1);

        boolean isNeedUpdate = true;

        if (isEnd) {
            if (lastItemInfo.mType == ItemInfo.ITEM_INFO_TYPE_NO_MORE) {
                isNeedUpdate = false;
            } else {
                isNeedUpdate = addNoMoreItem();
            }
        } else {
            if (lastItemInfo.mType == ItemInfo.ITEM_INFO_TYPE_NO_MORE) {
                mItemInfoTotal--;
            } else {
                isNeedUpdate = false;
            }
        }

        if (isNeedUpdate) {
            notifyDataSetChanged();
        }

    }

    public boolean isLoadToEnd() {
        return mLoadToTheEnd;
    }


    private boolean setAlbumItem(final CustomVideoItem albumItem, final ImageInfoEntity imageInfoEntity, final ItemInfo itemInfo, final int nItemIndex) {

        if (albumItem == null || imageInfoEntity == null) {
            return false;
        }


        //初始化时 不显示 视频黑条
        albumItem.setIsVideo(false, "");

        albumItem.setSelectedNoCover(imageInfoEntity.isChecked);
        albumItem.setSelectItemVisible(mSelectable);

        albumItem.getmCheckBox().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                imageInfoEntity.isChecked = albumItem.getmCheckBox().isChecked();

                if (mOnCheckListener != null) {
                    mOnCheckListener.updateCheckNum(getDeleteFileNum());
                }

                if (itemInfo.mTitlePosition >= 0) {
                    notifyItemChanged(itemInfo.mTitlePosition);
                } else {
                    notifyDataSetChanged();
                }
            }
        });

        albumItem.getmBgIv().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int sum = 0;
                for (int i = 0; i < itemInfo.mTitleIndex; i++) {
                    sum += mNewDataMap.get(mTimeList.get(i)).size();
                }
                CLog.e("select", sum + ":" + nItemIndex);

                //选择态 点击进行选择操作
                if (mSelectable) {
                    albumItem.getmCheckBox().performClick();

                } else {
                    //非选择态 点击进入详情页
                    iOnSelectItem.onSelect(sum + nItemIndex);
                }

            }
        });

        String filePath = ImageCache.getInstance().checkCache(imageInfoEntity.fileName, ImageCache.THUMBNAIL);

        if (!TextUtils.isEmpty(filePath)) {
            Glide.with(mContext)
                    .load(new File(filePath))
//                    .placeholder(R.drawable.video_default)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .error(R.drawable.video_default)
                    .into(albumItem.getmBgIv());

            boolean isVideo = (imageInfoEntity.ftype == 1);
            albumItem.setIsVideo(isVideo, imageInfoEntity.getHourAndMinString());
        } else {
            Glide.with(mContext)
                    .load(imageInfoEntity.thumbnail.url + "&Authorization=" + imageInfoEntity.thumbnail.token)
                    .listener(new RequestListener<String, GlideDrawable>() {
                        @Override
                        public boolean onException(Exception e, String model, Target<GlideDrawable> target, boolean isFirstResource) {
                            return false;
                        }

                        @Override
                        public boolean onResourceReady(GlideDrawable resource, String model, Target<GlideDrawable> target, boolean isFromMemoryCache, boolean isFirstResource) {
                            //加载成功后 若为视频类型 则显示视频黑条
                            boolean isVideo = (imageInfoEntity.ftype == 1);
                            albumItem.setIsVideo(isVideo, imageInfoEntity.getHourAndMinString());

                            ImageCache.getInstance().cacheImage(imageInfoEntity, ImageCache.THUMBNAIL);

                            return false;
                        }
                    })
                    .placeholder(R.drawable.video_default)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .error(R.drawable.video_default)
                    .into(albumItem.getmBgIv());
        }

        return true;

    }

    private String getTitleDateString(Date date) {
        long curTime = System.currentTimeMillis();
        long calcTime = date.getTime();

        String curDay = Utils.DATE_FORMAT_5.format(curTime);
        String calcDay = Utils.DATE_FORMAT_5.format(calcTime);

        String[] curSplit = curDay.split("-");
        String[] calcSplit = calcDay.split("-");

        if (curSplit.length != 3 || calcSplit.length != 3) {
            return "";
        }

        if (calcDay.equals(curDay)) {
            return "今天";
        } else if (Utils.DATE_FORMAT_5.format(curTime - 24 * 60 * 60 * 1000).equals(calcDay)) {
            return "昨天";
        }

        //年不同
        if (!curSplit[0].equalsIgnoreCase(calcSplit[0])) {
            return Utils.DATE_FORMAT_2.format(date);
        }

        return Utils.DATE_FORMAT_8.format(date);
    }


    public class ViewHolderTitle extends RecyclerView.ViewHolder {
        public TextView mTitleTv;
        public CheckBox mSelectOnedayCb;

        public ViewHolderTitle(View view) {
            super(view);
            mTitleTv = (TextView) view.findViewById(R.id.textItem);
            mSelectOnedayCb = (CheckBox) view.findViewById(R.id.cb_select_one_day);
        }

    }

    public class ViewHolderLine extends RecyclerView.ViewHolder {
        public ArrayList<CustomVideoItem> mAlbumList = new ArrayList<>();
        public CustomVideoItem mAlbumItem1;
        public CustomVideoItem mAlbumItem2;
        public CustomVideoItem mAlbumItem3;

        public ViewHolderLine(View view) {
            super(view);
            mAlbumItem1 = (CustomVideoItem) view.findViewById(R.id.album_item1);
            mAlbumItem2 = (CustomVideoItem) view.findViewById(R.id.album_item2);
            mAlbumItem3 = (CustomVideoItem) view.findViewById(R.id.album_item3);
            mAlbumList.add(mAlbumItem1);
            mAlbumList.add(mAlbumItem2);
            mAlbumList.add(mAlbumItem3);
        }

    }

    public class ViewHolderItemNoMore extends RecyclerView.ViewHolder {
        public View mView;
        //小视频类型统计
        public TextView mVideoStats;

        public ViewHolderItemNoMore(View view) {
            super(view);
            mView = view;

            mVideoStats = (TextView) view.findViewById(R.id.video_type_statistics);
        }
    }


    public interface IOnCheckListener {
        //        public void setCheck(boolean isCheck, boolean isUpdateView, boolean isReset);
//        public void reset();
        public void updateCheckNum(int nCheckNum);
    }

    public void setCheckListener(IOnCheckListener iOnCheckListener) {
        mOnCheckListener = iOnCheckListener;
    }

    public interface IRefresh {
        public void onRefresh();
    }

    public interface IOnSelectItem {
        public void onSelect(int pos);
    }

    public void setIOnSelectItem(IOnSelectItem iOnSelectItem) {
        this.iOnSelectItem = iOnSelectItem;
    }

    public void refresh() {
        notifyDataSetChanged();
    }

    public void setmSelectable(boolean mSelectable) {
        this.mSelectable = mSelectable;
        notifyDataSetChanged();
    }

    public void clearSelectedState() {
        for (int i = 0; i < mTimeList.size(); i++) {
            ArrayList<ImageInfoEntity> imageInfoEntityArrayList = mNewDataMap.get(mTimeList.get(i));
            for (int j = 0; j < imageInfoEntityArrayList.size(); j++) {
                imageInfoEntityArrayList.get(j).isChecked = false;
            }
        }

        if (!onBind) {
            notifyDataSetChanged();
        }
    }

    public int getDeleteFileNum() {
        int nDelNum = 0;
        for (int i = 0; i < mTimeList.size(); i++) {
            ArrayList<ImageInfoEntity> imageInfoEntityArrayList = mNewDataMap.get(mTimeList.get(i));
            for (int j = 0; j < imageInfoEntityArrayList.size(); j++) {
                if (imageInfoEntityArrayList.get(j).isChecked) {
                    nDelNum++;
                }
            }
        }

        return nDelNum;
    }

    public ArrayList<ImageInfoEntity> getDeleteFileList() {
        ArrayList<ImageInfoEntity> delList = new ArrayList<>();

        for (int i = 0; i < mTimeList.size(); i++) {
            ArrayList<ImageInfoEntity> imageInfoEntityArrayList = mNewDataMap.get(mTimeList.get(i));
            for (int j = 0; j < imageInfoEntityArrayList.size(); j++) {
                if (imageInfoEntityArrayList.get(j).isChecked) {
                    delList.add(imageInfoEntityArrayList.get(j));
                }
            }
        }

        return delList;

    }

    public void printMap() {
        for (int i = 0; i < mTimeList.size(); i++) {
            String sum = "";
            ArrayList<ImageInfoEntity> imageInfoEntityArrayList = mNewDataMap.get(mTimeList.get(i));
            for (int j = 0; j < imageInfoEntityArrayList.size(); j++) {
                sum += (j + ":" + imageInfoEntityArrayList.get(j).isChecked + "    ");
            }
            CLog.e("adapterMap", i + "---->" + sum);

        }
        CLog.e("adapterMap", "-------------------------------");
    }

    public void deleteOneFile(ImageInfoEntity imageInfoEntity) {
        deleteFile(imageInfoEntity);

        calcItemInfoList();

        notifyDataSetChanged();
    }

    private void deleteFile(ImageInfoEntity imageInfoEntity) {
        ArrayList<String> preDeleteTimeList = new ArrayList<String>();

        mImageInfoList.remove(imageInfoEntity);

        if (imageInfoEntity.isPhoto()) {
            if (mPhotoCount > 0) {
                mPhotoCount--;
            }
        } else {
            if (mVideoCount > 0) {
                mVideoCount--;
            }
        }

        for (int i = 0; i < mTimeList.size(); i++) {
            ArrayList<ImageInfoEntity> imageInfoEntityArrayList = mNewDataMap.get(mTimeList.get(i));
            imageInfoEntityArrayList.remove(imageInfoEntity);
            if (imageInfoEntityArrayList.size() <= 0) {
                preDeleteTimeList.add(mTimeList.get(i));
            }
        }
        for (int i = 0; i < preDeleteTimeList.size(); i++) {
            mTimeList.remove(preDeleteTimeList.get(i));
        }
    }

    public void deleteFile() {

    }

    public void deleteFileList(ArrayList<ImageInfoEntity> imageInfoList) {
        if (imageInfoList == null) {
            return;
        }
        if (imageInfoList.size() == 0) {
            return;
        }

        for (int i = 0; i < imageInfoList.size(); i++) {
            deleteFile(imageInfoList.get(i));
        }

        calcItemInfoList();

        notifyDataSetChanged();
    }

    public ArrayList<ImageInfoEntity> getImageInfoEntityListArray() {

        ArrayList<ImageInfoEntity> result = new ArrayList<ImageInfoEntity>();
        for (int i = 0; i < mTimeList.size(); i++) {
            ArrayList<ImageInfoEntity> imageInfoEntityArrayList = mNewDataMap.get(mTimeList.get(i));
            for (int j = 0; j < imageInfoEntityArrayList.size(); j++) {
                if (imageInfoEntityArrayList.get(j).isChecked) {
                    result.add(imageInfoEntityArrayList.get(j));
                }
            }
        }
        return result;
    }

    public boolean ismSelectable() {
        return mSelectable;
    }

    public boolean hasItems() {
        if (mTimeList.size() > 0 && mNewDataMap.size() > 0) {
            return true;
        }
        return false;
    }

    public static class ItemInfo {
        public int mType;
        public int mTitleIndex;//在mTimeList中的index
        public int mItemIndex;//在mNewDataMap的ArrayList<ImageInfoEntity>的index
        public int mPosition;//自己在mItemInfoList的index
        public int mTitlePosition;//title在mTimeList中的index

        public final static int ITEM_INFO_TYPE_TITLE = 0;
        public final static int ITEM_INFO_TYPE_LINE = 1;
        public final static int ITEM_INFO_TYPE_NO_MORE = 2;

    }
}