package com.qihoo360.homecamera.mobile.db;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.qihoo360.homecamera.mobile.entity.CommandMessage;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.utils.CLog;

import java.util.ArrayList;

/**
 * Created by hyuan on 2016/9/27.
 */
public class CommandMessageWraper extends AbstractWrapper {

    public static final String TABLE_NAME = "command_message";
    private static CommandMessageWraper mInstance;

    public static CommandMessageWraper getInstance() {
        if (mInstance == null) {
            synchronized (CamInfoWrapper.class) {
                if (mInstance == null) {
                    mInstance = new CommandMessageWraper();
                }
            }
        }
        return mInstance;
    }

    public long setCommandMessage(CommandMessage cmdMsg, boolean update) {
        SQLiteDatabase sqLiteDatabase = GlobalManager.getInstance().config().db.getWritableDatabase();
        return insertCommandMessage(sqLiteDatabase,cmdMsg, update);
    }

    private long insertCommandMessage(SQLiteDatabase sqLiteDatabase, CommandMessage cmdMsg, boolean update) {
        long effectCount = 0;
        ContentValues values = new ContentValues();
        values.put(Field.KEY_TASK_ID, cmdMsg.taskId);
        values.put(Field.KEY_CONTENT, cmdMsg.content);
        values.put(Field.KEY_EXE_SUCCESS, cmdMsg.executeSuccess ? 1 : 0);
        values.put(Field.KEY_SEND_RCV, cmdMsg.sendOrReceive);
        values.put(Field.KEY_SEND_STATE, cmdMsg.sendState);
        values.put(Field.KEY_TIME, cmdMsg.timeExecute);
        values.put(Field.KEY_QID, cmdMsg.qid);
        values.put(Field.KEY_MESSAGE_TYPE, cmdMsg.messageType);
        values.put(Field.KEY_SN, cmdMsg.sn);
        values.put(Field.KEY_IMAGE, cmdMsg.imagUrl);
        values.put(Field.KEY_LOCK_TIME, cmdMsg.lockTime);
        try {
            if (update){
                String taskId = cmdMsg.taskId;
                effectCount = sqLiteDatabase.update(TABLE_NAME, values,
                        "taskId=? and sendOrReceive=1",
                        new String[]{taskId});// and sendOrReceive=1
                CLog.e("cmd","update effect:" + effectCount);
                CLog.justalkFile("update effect:" + effectCount);
            } else{
                effectCount = sqLiteDatabase.insert(TABLE_NAME, "", values);
                CLog.e("cmd","insert effect:" + effectCount);
                CLog.justalkFile("insert effect:" + effectCount);

            }
        } catch (Exception e) {
            CLog.justalkFile("insert exception:" + e.getMessage());
        }

        return effectCount;
    }

    public CommandMessage getCommandMessage(String taskId, String sn, String qid) {
        SQLiteDatabase sqLiteDatabase = GlobalManager.getInstance().config().db.getWritableDatabase();
        CommandMessage cmdMsg = new CommandMessage();
        Cursor cursor = null;
        try {
            cursor = sqLiteDatabase.query(TABLE_NAME, null, "taskId = ? and sn = ? and qid = ?", new String[]{taskId, sn, qid}, null, null, null);
            while (cursor.moveToNext()) {
                cmdMsg.taskId = taskId;
                cmdMsg.content = cursor.getString(cursor.getColumnIndex(Field.KEY_CONTENT));
                cmdMsg.executeSuccess = cursor.getInt(cursor.getColumnIndex(Field.KEY_EXE_SUCCESS)) == 1;
                cmdMsg.sendState = cursor.getInt(cursor.getColumnIndex(Field.KEY_SEND_STATE));
                cmdMsg.sendOrReceive = cursor.getInt(cursor.getColumnIndex(Field.KEY_SEND_RCV));
                cmdMsg.timeExecute = cursor.getLong(cursor.getColumnIndex(Field.KEY_TIME));
                cmdMsg.messageType = cursor.getInt(cursor.getColumnIndex(Field.KEY_MESSAGE_TYPE));
                cmdMsg.sn = cursor.getString(cursor.getColumnIndex(Field.KEY_SN));
                cmdMsg.qid = cursor.getString(cursor.getColumnIndex(Field.KEY_QID));
                cmdMsg.imagUrl = cursor.getString(cursor.getColumnIndex(Field.KEY_IMAGE));
                cmdMsg.lockTime = cursor.getInt(cursor.getColumnIndex(Field.KEY_LOCK_TIME));
            }
        } catch (Exception e) {
            CLog.e(e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return cmdMsg;
    }

    public ArrayList<CommandMessage> getCommandMessageList(String sn, String qid, int sum) {
        SQLiteDatabase sqLiteDatabase = GlobalManager.getInstance().config().db.getWritableDatabase();
        ArrayList<CommandMessage> allList = new ArrayList<>();
        Cursor cursor = null;
        try {
            String sql = "select * from " + TABLE_NAME + " where sn='" + sn +  "' and qid='" + qid + "' order by _id desc" + " limit 0," + sum;
            cursor = sqLiteDatabase.rawQuery(sql, null);
            //cursor = sqLiteDatabase.query(TABLE_NAME, null, "sn = ? and qid = ?", new String[]{sn, qid}, null, null, null);
            while (cursor.moveToNext()) {
                CommandMessage cmdMsg = new CommandMessage();
                cmdMsg.taskId = cursor.getString(cursor.getColumnIndex(Field.KEY_TASK_ID));
                cmdMsg.content = cursor.getString(cursor.getColumnIndex(Field.KEY_CONTENT));
                cmdMsg.executeSuccess = cursor.getInt(cursor.getColumnIndex(Field.KEY_EXE_SUCCESS)) == 1;
                cmdMsg.sendState = cursor.getInt(cursor.getColumnIndex(Field.KEY_SEND_STATE));
                cmdMsg.sendOrReceive = cursor.getInt(cursor.getColumnIndex(Field.KEY_SEND_RCV));
                cmdMsg.timeExecute = cursor.getLong(cursor.getColumnIndex(Field.KEY_TIME));
                cmdMsg.messageType = cursor.getInt(cursor.getColumnIndex(Field.KEY_MESSAGE_TYPE));
                cmdMsg.sn = cursor.getString(cursor.getColumnIndex(Field.KEY_SN));
                cmdMsg.qid = cursor.getString(cursor.getColumnIndex(Field.KEY_QID));
                cmdMsg.imagUrl = cursor.getString(cursor.getColumnIndex(Field.KEY_IMAGE));
                cmdMsg.lockTime = cursor.getInt(cursor.getColumnIndex(Field.KEY_LOCK_TIME));
                allList.add(cmdMsg);
            }
        } catch (Exception e) {
            CLog.e("select",e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return allList;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int toVersion) {
        switch (toVersion){
            case 7:{
                try {
                    String sql = "CREATE TABLE IF NOT EXISTS command_message (_id INTEGER, sn varchar(255,0), " +
                            "messageType INTEGER default 0, qid varchar(255,0), image varchar(255,0), " +
                            "taskId varchar(255,0), sendOrReceive INTEGER default -1, " +
                            "timeExecute INTEGER default 0, content varchar(255,0), " +
                            "sendState INTEGER default 0, executeSuccess INTEGER default 0, " +
                            "lockTime INTEGER default 0, PRIMARY KEY(_id))";
                    db.execSQL(sql);
                } catch (Exception e) {
                    e.printStackTrace();
                    CLog.justalkFile("create command_message" + e.getMessage());
                }
                break;
            }
            default:
                break;
        }
    }

    @Override
    public void onOpen(SQLiteDatabase db) {

    }

    private static final class Field {
        public static final String KEY_QID = "qid";
        public static final String KEY_MESSAGE_TYPE = "messageType";
        public static final String KEY_TASK_ID = "taskId";
        public static final String KEY_SEND_RCV = "sendOrReceive";
        public static final String KEY_TIME = "timeExecute";
        public static final String KEY_CONTENT = "content";
        public static final String KEY_SEND_STATE = "sendState";
        public static final String KEY_EXE_SUCCESS = "executeSuccess";
        public static final String KEY_SN = "sn";
        public static final String KEY_IMAGE = "image";
        public static final String KEY_LOCK_TIME = "lockTime";
    }
}
