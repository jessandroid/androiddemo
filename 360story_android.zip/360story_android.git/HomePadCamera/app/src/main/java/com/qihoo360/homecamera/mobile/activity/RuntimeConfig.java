
package com.qihoo360.homecamera.mobile.activity;

import android.content.ContentResolver;
import android.content.SharedPreferences;
import android.content.res.Resources;

import com.qihoo360.homecamera.machine.net.CameraHttpApi;
import com.qihoo360.homecamera.mobile.core.util.PrefUtil;
import com.qihoo360.homecamera.mobile.core.util.Stoppable;
import com.qihoo360.homecamera.mobile.db.LocalDB;
import com.qihoo360.homecamera.mobile.utils.CLog;

import java.io.File;

public class RuntimeConfig implements Stoppable {
    public final static String TAG = "RuntimeConfig";
    public LocalDB db;
    public LocalDB commonDB;
    public PrefUtil userPref;
    public Resources resources;
    public File USER_DIR;
    public File DIR_CACHE;
    public File DIR_IMAGE_CACHE;
    public File DIR_FILE_CACHE;

    public CameraHttpApi cameraHttpApi;
    public CameraHttpApi cameraHttpsApi;
    public CameraHttpApi liveHttpsApi;

    // Do not use it unless you know what you are doing, parse db operation to business logics.
    public ContentResolver contentResolver;

    /**
     * This is application-wise preference, does not relate to any user
     */
    public SharedPreferences applicationPref;

    @Override
    public void destroyNow() {
        CLog.d(TAG, "--destroyNow--");
        db = null;
        commonDB = null;
        userPref = null;
        resources = null;
        USER_DIR = null;
        DIR_CACHE = null;
        DIR_IMAGE_CACHE = null;
        DIR_FILE_CACHE = null;
        applicationPref = null;
        contentResolver = null;

        cameraHttpApi = null;
        cameraHttpsApi = null;
        liveHttpsApi = null;
    }

//    public boolean isReady() {
//        return user != null && mIsStopped == false;
//    }

    private boolean mIsStopped = false;

    @Override
    public void stopNow() {
        mIsStopped = true;
    }

    @Override
    public boolean isStopped() {
        return mIsStopped;
    }
}
