package com.qihoo360.homecamera.mobile.adapter;

import android.content.Context;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.entity.Story;
import com.qihoo360.homecamera.mobile.utils.CLog;

import java.util.ArrayList;
import java.util.List;


public class LinearLayoutAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<Story> list = new ArrayList<>();
    private Context context;
    private OnItemOption onItemOption;
    private int itemCount = 0;
    public List<Story> checkedList = new ArrayList<>();
    private boolean onBind;

    private static final int TYPE_HEADER = 0;
    private static final int TYPE_ITEM = 1;
    private static final int TYPE_FOOTER = 2;
    public int totalCount = 0;
    private boolean showMore = false;


    public LinearLayoutAdapter(Context context, List<Story> list, OnItemOption onItemOption, int itemCount) {
        this.context = context;
        this.list = list;
        this.onItemOption = onItemOption;
        this.itemCount = itemCount;
    }


    public boolean getCheckModel() {
        return onItemOption.isCheckModel();
    }

    public void clearCheckList() {
        checkedList.clear();
    }

    public void dataChanage(List data) {
        this.list = data;
        notifyDataSetChanged();
    }

    public int getTotalCount() {
        return totalCount;
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == TYPE_ITEM) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_linear_layout, parent, false);
            return new ViewHolderItem(view, list);
        } else if (viewType == TYPE_HEADER) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.sotry_list_head, parent, false);
            return new ViewHolderHead(view);
        } else if (viewType == TYPE_FOOTER) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.no_more_layout, parent, false);
            return new ViewHolderItemFooter(view);
        }
        return null;
    }


    public void showNoMore(boolean flag) {
        showMore = flag;
        notifyDataSetChanged();
    }


    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        if (holder instanceof ViewHolderItem) {
            int temp = position;
            if (itemCount == 3) {
                temp -= 1;
            }
            ViewHolderItem viewHolder = (ViewHolderItem) holder;
            if (getCheckModel()) {
                viewHolder.ch.setVisibility(View.VISIBLE);
            } else {
                viewHolder.ch.setVisibility(View.GONE);
                checkedList.clear();
            }
            final int finalTemp = temp;
            viewHolder.card_item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    onItemOption.clickStory(finalTemp, list.get(finalTemp));
                }
            });
            onBind = true;
            if (list.get(temp) != null) {
                viewHolder.ch.setChecked(list.get(temp).checked);
            }
            viewHolder.ch.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onItemOption.clickStory(finalTemp, list.get(finalTemp));
                }
            });
            onBind = false;
            viewHolder.story_time_long.setText(list.get(temp).duration);
            viewHolder.info_text.setText(list.get(temp).name);
            viewHolder.creat_time.setVisibility(View.VISIBLE);
            viewHolder.creat_time.setText(getDateFormate(list.get(temp).getCreate_time()));
            Glide.clear(viewHolder.image_head);
            Glide.with(context).load(TextUtils.isEmpty(list.get(temp).listCover_url) ? list.get(temp).cover : list.get(temp).listCover_url)
                    .placeholder(R.drawable.moren_icon_story_on_line)
                    .diskCacheStrategy(DiskCacheStrategy.RESULT)
                    .error(R.drawable.moren_icon_story_on_line)
                    .priority(Priority.LOW)
                    .crossFade()
                    .thumbnail(0.1f)
                    .centerCrop()
                    .into(viewHolder.image_head);
        } else if (holder instanceof ViewHolderHead) {
            ViewHolderHead viewHolderHead = (ViewHolderHead) holder;
            if (totalCount == 0) {
                viewHolderHead.mView.setVisibility(View.GONE);
            } else {
                viewHolderHead.mView.setVisibility(View.VISIBLE);
            }
            String exchange = context.getResources().getString(R.string.story_with_sound_all, totalCount);
            viewHolderHead.textView.setText(Html.fromHtml(exchange));
        } else if (holder instanceof ViewHolderItemFooter) {
            ViewHolderItemFooter viewHolder = (ViewHolderItemFooter) holder;
            int v = list.size() > 5 && showMore ? View.VISIBLE : View.GONE;
            viewHolder.mView.setVisibility(v);
        }

    }

    public String getDateFormate(String date) {
        return context.getResources().getString(R.string.upload_date_formate, date);
    }

    @Override
    public int getItemCount() {
        int count = list.size();
        if (isPositionFooter(count + 1)) {
            count += 1;
        }
        if (isPositionHeader(0)) {
            count += 1;
        }
        return count;
    }

    public boolean isHeader(int position) {
        if (position == 0 && itemCount == 3)
            return true;
        else
            return false;
    }

    public boolean isFooter(int position) {
        return isPositionFooter(position);
    }

    public void setTotalCount(int total) {
        totalCount = total;
        if (itemCount == 3) {
            notifyItemChanged(0);
        }
    }

    public class ViewHolderItem extends RecyclerView.ViewHolder implements CompoundButton.OnCheckedChangeListener {
        public View mView;
        public TextView info_text;
        public ImageView image_head;
        public CardView card_item;
        public TextView story_time_long;
        public CheckBox ch;
        public List<Story> list;
        public TextView creat_time;
        public TextView story_time_;

        public ViewHolderItem(View view, List<Story> list) {
            super(view);
            mView = view;
            this.list = list;
            info_text = (TextView) view.findViewById(R.id.info_text);
            card_item = (CardView) view.findViewById(R.id.card_item);
            story_time_long = (TextView) view.findViewById(R.id.story_time_long);
            image_head = (ImageView) view.findViewById(R.id.image_head);
            ch = (CheckBox) view.findViewById(R.id.checkbox);
            creat_time = (TextView) view.findViewById(R.id.creat_time);
        }

        @Override
        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
            CLog.d("the b is :" + b);
            if (onBind) {
                notifyDataSetChanged();
            }
        }
    }


    public class ViewHolderItemFooter extends RecyclerView.ViewHolder {
        public View mView;

        public ViewHolderItemFooter(View view) {
            super(view);
            mView = view;

        }
    }


    public class ViewHolderHead extends RecyclerView.ViewHolder {
        public final View mView;
        public TextView textView;

        public ViewHolderHead(View view) {
            super(view);
            mView = view.findViewById(R.id.story_sound_all);
            textView = (TextView) view.findViewById(R.id.story_sound_title);
        }

    }


    @Override
    public int getItemViewType(int position) {
        if (isPositionHeader(position)) {
            return TYPE_HEADER;
        } else if (isPositionFooter(position)) {
            return TYPE_FOOTER;
        } else {
            return TYPE_ITEM;
        }
    }


    private boolean isPositionHeader(int position) {
        if (itemCount == 3) {
            return position == 0;
        } else {
            return false;
        }
    }

    private boolean isPositionFooter(int position) {
        return position == list.size() + 1;
    }


    public interface OnItemOption {

        public void clickStory(int po, Story st);

        public boolean isCheckModel();

        public List<Story> checkedStory();
    }

    @Override
    public void onViewDetachedFromWindow(RecyclerView.ViewHolder holder) {
        super.onViewDetachedFromWindow(holder);
        if (holder instanceof ViewHolderItem) {
            Glide.clear(((ViewHolderItem) holder).image_head);
        }
    }
}

