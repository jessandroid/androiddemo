package com.qihoo360.homecamera.machine.myvideoplay;

import android.app.ActivityManager;
import android.content.Context;
import android.os.Handler;
import android.text.TextUtils;

import com.qihoo.jia.play.jnibase.JPlayer;
import com.qihoo360.homecamera.mobile.config.Const;
import com.qihoo360.homecamera.mobile.utils.AESUtil;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.MD5Util;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.util.List;

public class P2PManager {

    private final static int CHECK_INTERVAL = 5 * 1000;

    private final static boolean LOG = Const.DEBUG;

    private Handler mHandler;

    private ActivityManager mActivityManager;

    private String mPkgName;

    private LoginInfo mLoginInfo;

    public P2PManager(Context context) {
        mHandler = new Handler(context.getMainLooper());
        mActivityManager = (ActivityManager) context.getSystemService( Context.ACTIVITY_SERVICE );
        mPkgName = context.getPackageName();
    }

    public void startCheckForeground() {
        CLog.e("Foreground App startCheckForeground " + mPkgName);
        mHandler.removeCallbacks(checkForegroundTask);
        mHandler.post(checkForegroundTask);
    }

    public Runnable checkForegroundTask = new Runnable() {
        @Override
        public void run() {
            List<ActivityManager.RunningAppProcessInfo> appProcesses = mActivityManager.getRunningAppProcesses();
            boolean isForeground = false;
            if (appProcesses != null) {
                for (ActivityManager.RunningAppProcessInfo appProcess : appProcesses) {
                    if (appProcess.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                        CLog.e("Foreground App", appProcess.processName);
                        if (TextUtils.equals(mPkgName, appProcess.processName)) {
                            isForeground = true;
                            break;
                        }
                    }
                }
            }
            if (isForeground) {
                mHandler.postDelayed(this, CHECK_INTERVAL);
            } else {
                logout();
            }
            if (LOG) {
                CLog.e("isForeground:" + isForeground);
            }
        }
    };

    public boolean setLoginInfo(String selfId, String trackerIp, int port) {
        boolean changed = false;
        if (mLoginInfo != null && TextUtils.equals(mLoginInfo.selfId, selfId)
                && TextUtils.equals(mLoginInfo.trackerIp, trackerIp)
                && mLoginInfo.port == port) {
            changed = false;
        } else {
            mLoginInfo = new LoginInfo(selfId, trackerIp, port);
            changed = true;
        }
        return changed;
    }

    public void login() {
        if (mLoginInfo != null) {
            JPlayer.p2pLogin(mLoginInfo.selfId, mLoginInfo.trackerIp, mLoginInfo.port);
        }
    }

    public void logout() {
        mHandler.removeCallbacks(checkForegroundTask);
        JPlayer.p2pLogout();
    }

    public static class LoginInfo {
        public String selfId;
        public String trackerIp;
        public int port;

        public LoginInfo(String selfId, String trackerIp, int port) {
            this.selfId = selfId;
            this.trackerIp = trackerIp;
            this.port = port;
        }
    }

    public static String getSelfId(String sn) {
        String selfId = null;
        try {
            selfId = AESUtil.SHA1(android.os.Process.myPid() + AccUtil.getInstance().getQID())
                    + AESUtil.SHA1(android.os.Process.myPid() + Utils.getDeviceID());
            CLog.e("SHA1 ok:" + selfId);
        } catch (Exception e) {
            selfId = MD5Util.getMD5code(sn)
                    + MD5Util.getMD5code(AccUtil.getInstance().getQID());
            CLog.e("SHA1 fail. " + selfId);
        }
        return selfId;
    }
}
