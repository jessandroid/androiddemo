package com.qihoo360.homecamera.mobile.db;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.text.TextUtils;

import com.qihoo360.homecamera.mobile.entity.ImageInfoEntity;
import com.qihoo360.homecamera.mobile.entity.Story;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.utils.Utils;

/**
 * Created with Android Studio.
 * User: Administrator
 * Date: 2016/7/2
 * Time: 10:53
 * To change this template use File | Settings | File Templates.
 */
public class StoryAndVideoCacheWrapper extends AbstractWrapper {

    private static StoryAndVideoCacheWrapper videoCacheWrapper;
    private static final String TABLE_NAME = "story_little_video_path_cache";

    private StoryAndVideoCacheWrapper() {

    }

    public static StoryAndVideoCacheWrapper getInstance() {
        synchronized (StoryAndVideoCacheWrapper.class) {
            if (videoCacheWrapper == null) {
                videoCacheWrapper = new StoryAndVideoCacheWrapper();
            }
        }
        return videoCacheWrapper;
    }


    public synchronized boolean remove(String sn, String downloadUrl) {
        if (TextUtils.isEmpty(sn) || TextUtils.isEmpty(downloadUrl)) {
            return false;
        }
        SQLiteDatabase db = GlobalManager.getInstance().config().db.getWritableDatabase();
        long count = 0;
        StringBuffer sb = new StringBuffer("");
        sb.append("delete from ");
        sb.append(TABLE_NAME);
        sb.append(" where " + Field.KEY_SN + " = '" + sn + "' and " + Field.B + " = '" + downloadUrl + "'");
        try {
            SQLiteStatement statement = db.compileStatement(sb.toString());
            count = statement.simpleQueryForLong();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            return count > 0;
        }
    }


    public synchronized void saveVideoCache(String sn, String path, Object story) {
        if (TextUtils.isEmpty(sn)) {
            return;
        }

        if (story == null) {
            return;
        }

        SQLiteDatabase db = GlobalManager.getInstance().config().db.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(Field.KEY_SN, sn);
        values.put(Field.B, path);
        String key = story instanceof Story ? "story" : "video";
        if (story instanceof Story) {
            key = "story" + "_" + ((Story) story).id;
        } else if (story instanceof ImageInfoEntity) {
            key = "video" + "_" + ((ImageInfoEntity) story).imageId;
        }
        values.put(Field.C, key);
        try {
            if (exist(sn, key)) {
                db.delete(TABLE_NAME, Field.KEY_SN + "= ?", new String[]{String.valueOf(sn)});
            }
            db.insert(TABLE_NAME, null, values);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean exist(String sn, String key) throws Exception {
        boolean exist = false;
        if (TextUtils.isEmpty(sn) || TextUtils.isEmpty(key)) {
            return false;
        }
        long queryRes = queryQidCount(sn, key);
        if (queryRes > 0) {
            exist = true;
        }
        return exist;
    }


    private Long queryQidCount(String sn, String key) {
        if (TextUtils.isEmpty(sn)) {
            long count = 0;
            return count;
        }

        SQLiteDatabase db = GlobalManager.getInstance().config().db.getWritableDatabase();
        long count = 0;
        StringBuffer sb = new StringBuffer("");
        sb.append("select count(_id) from ");
        sb.append(TABLE_NAME);
        sb.append(" where " + Field.KEY_SN + " ='" + sn + "' and " + Field.C + " = '" + key + "'");
        try {
            SQLiteStatement statement = db.compileStatement(sb.toString());
            count = statement.simpleQueryForLong();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }
        return count;
    }


    public String getVideoCache(String sn, Object st) {
        if (TextUtils.isEmpty(sn) || st == null) {
            return null;
        }
        SQLiteDatabase db = GlobalManager.getInstance().config().db.getReadableDatabase();
        String data = null;
        String key = null;
        if (st instanceof Story) {
            key = "story" + "_" + ((Story) st).id;
        } else if (st instanceof ImageInfoEntity) {
            key = "video" + "_" + ((ImageInfoEntity) st).imageId;
        }
        Cursor cursor = null;
        try {
            if (exist(sn, key)) {
                cursor = db.query(TABLE_NAME, null, Field.KEY_SN + " = ? and " + Field.C + " = ? ", new String[]{sn, key}, null, null, null);
                while (cursor.moveToNext()) {
                    data = cursor.getString(cursor.getColumnIndex(Field.B));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            Utils.close(cursor);
        }
        return data;
    }


    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int toVersion) {
        switch (toVersion) {
            case 3:
                db.execSQL("CREATE TABLE IF NOT EXISTS story_little_video_path_cache (_id INTEGER, sn varchar(255,0), b TEXT, c varchar(255,0), d varchar(255,0), e varchar(255,0), f varchar(255,0), g varchar(255,0), PRIMARY KEY(_id));");
                break;
        }
    }

    @Override
    public void onOpen(SQLiteDatabase db) {

    }


    public class Field {
        public static final String KEY_ID = "_id";
        public static final String KEY_SN = "sn";
        public static final String B = "b";
        public static final String C = "c";
        public static final String D = "d";
        public static final String E = "e";
        public static final String F = "f";
        public static final String G = "g";
    }
}
