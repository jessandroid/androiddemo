package com.qihoo360.homecamera.mobile.manager;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.qihoo360.homecamera.device.config.StoryMachineConsts;
import com.qihoo360.homecamera.machine.business.JsonManager;
import com.qihoo360.homecamera.machine.business.PlayConfig;
import com.qihoo360.homecamera.machine.business.SettingTask;
import com.qihoo360.homecamera.machine.business.TaskExecutor;
import com.qihoo360.homecamera.mobile.BuildConfig;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.config.DefaultClientConfig;
import com.qihoo360.homecamera.mobile.entity.Update;
import com.qihoo360.homecamera.mobile.entity.UpdateBatch;
import com.qihoo360.homecamera.mobile.entity.UpdateInfo;
import com.qihoo360.homecamera.mobile.http.OkHttpUtils;
import com.qihoo360.homecamera.mobile.utils.AccUtil;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.Preferences;
import com.qihoo360.homecamera.mobile.utils.Utils;
import com.qihoo360.homecamera.mobile.widget.CamAlertDialog;
import com.qihoo360.homecamera.mobile.widget.TextViewWithFont;

import org.json.JSONArray;
import org.w3c.dom.Text;

import java.util.HashMap;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import rx.Observable;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;
import rx.subscriptions.CompositeSubscription;

/**
 * 更新需要调用执行的逻辑
 */

public class VersionManager {
    /**
     * 进入主界面时主动触发的更新检测
     */
    public static final int REQUEST_SOURCE_MAIN = 1;
    /**
     * 在个人中心中，主动点击在线更新检测
     */
    public static final int REQUEST_SOURCE_PERSONAL = 2;
    /**
     * 闪屏界面主动检测更新
     */
    public static final int REQUEST_SOURCE_SPLASH = 3;

    private Context mContext;

    private String mSn;

    private String mFrom;

    private int mCodeFrom;

    private CamAlertDialog fmUpdateDialog;//固件升级对话框

    private CamAlertDialog fmFailedDialog;//固件升级失败对话框

    private CamAlertDialog fmLoadingDialog;//固件正在升级对话框

    private Handler mHandler;

    private ObjectAnimator objectAnimator;
    private TextView loadProgress;//进度，需要模拟
    private int progress;// 固件升级进度
    private int stepSum;
    private int currentStep;
    private int step;
    private SuccessCallBackInterface mSuccessCallBackInterface;
    private Random random;

    private CompositeSubscription mLoadDataSubscription;
    private Subscription subcription;

    public VersionManager(Context context){
        this.mContext = context;
        mLoadDataSubscription = new CompositeSubscription();
    }

    public VersionManager(Context context, String sn, int codeFrom, String from, Handler handler){
        this.mContext = context;
        this.mSn = sn;
        this.mFrom = from;
        this.mCodeFrom = codeFrom;
        this.mHandler = handler;
        random = new Random();
        mLoadDataSubscription = new CompositeSubscription();
    }

    /**
     * 执行app检测更新
     */
    public static Update checkVersion(int requestSource) {
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("from", "mpc_and"); // 固定写法
        hashMap.put("taskId", UUID.randomUUID().toString()); // 生成唯一标识就行
        hashMap.put("projectId", "3"); // 与后台网站申请的一样
        hashMap.put("appId", "360kibot_m_android");
        hashMap.put("appType", "1"); // 1表示软件版本（app），2表示硬件版本（固件等）
        hashMap.put("version", BuildConfig.VERSION_NAME);
        hashMap.put("versionCode", String.valueOf(BuildConfig.VERSION_CODE));
        hashMap.put("deviceId", Utils.getIMEI(Utils.getContext()));
        hashMap.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);

        String  response = OkHttpUtils.post().isStatic(true).url(DefaultClientConfig.APP_UPDATE)
                    .withOutCookie().isDebug(false).params(hashMap).headers(null).build().execute();
//        String response = "{\"errorCode\":0,\"errorMsg\":\"成功\",\"result\":{\"title\":\"360kibot_sz_1.1.1.0.apk\",\"version\":\"1.1.1.0\",\"versionCode\":\"345\",\"size\":38218482,\"md5\":\"fc6bb2b9ad7dcb9c752746cd287be40d\",\"downUrl\":\"http:\\/\\/down.360safe.com\\/kibot\\/360kibot_sz_1.1.1.0.apk\",\"description\":\"测试更新\\n1、更新环境测试\\n2、更新协议测试\",\"recommand\":\"90\",\"hasNew\":1,\"isForce\":\"3\",\"extend\":\"[]\",\"publishTime\":\"2016-11-08 17:13:57\"}}";
        CLog.e("zt", "app升级检测response:" + response);
        Update updateNew = new Gson().fromJson(response, Update.class);
        return updateNew;
    }

    /*
     *检测故事机固件升级
     */
    public static Update checkFMVersion(String version, int versionCode, String sn){
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("from", "mpc_and"); // 固定写法
        hashMap.put("taskId", UUID.randomUUID().toString()); // 生成唯一标识就行,用于排查问题
        hashMap.put("projectId", "4"); // 项目id,与后台网站申请的一样
        hashMap.put("appId", "360Smartstory_fm_update");//appid
        hashMap.put("appType", "2"); // 1表示软件版本（app），2表示硬件版本（固件等）
        hashMap.put("version", version);
        hashMap.put("versionCode", String.valueOf(versionCode));
        hashMap.put("deviceId", sn);
        hashMap.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
        String response = OkHttpUtils.post().isStatic(true).url(DefaultClientConfig.APP_UPDATE).withOutCookie().isDebug(false).params(hashMap).headers(null).build().execute();
        CLog.e("zt", "故事机固件升级检测response:" + response);
        Update updateNew = new Gson().fromJson(response, Update.class);
        return updateNew;
    }
    /*
     *批量检测故事机固件升级
     */
    public static UpdateBatch checkFmVersionBatch(JSONArray paramArray){
        HashMap<String, String> hashMap = new HashMap<>();
        hashMap.put("data", paramArray.toString());
        hashMap.put(StoryMachineConsts.PUSH_KEY_VERSION,StoryMachineConsts.PUSH_VALUE_VERSION_ANDROID + BuildConfig.VERSION_NAME);
        String response = OkHttpUtils.post().isStatic(true).url(DefaultClientConfig.FM_UPDATE_BATCH).withOutCookie().isDebug(false).params(hashMap).headers(null).build().execute();
        CLog.e("zt", "故事机固件批量升级检测response:" + response);
        UpdateBatch updateBatch = new Gson().fromJson(response, UpdateBatch.class);
        return updateBatch;
    }

    //故事机固件升级处理的通用逻辑
    public void handlerFMUpdate(UpdateInfo updateInfo){
        showFMUpdateDialog(updateInfo);
    }

    public void showFMUpdateDialog(final UpdateInfo updateInfo) {
        CamAlertDialog.Builder builder = new CamAlertDialog.Builder(mContext);
        fmUpdateDialog = builder.create();

        View view = LayoutInflater.from(mContext).inflate(R.layout.layout_machne_fm_upgrade, null);
        fmUpdateDialog.setContentView(view);
        fmUpdateDialog.setCancelable(false);

        TextViewWithFont btnCancle = (TextViewWithFont) view.findViewById(R.id.text_machine_dialog_cancel);
        TextViewWithFont btnSure = (TextViewWithFont) view.findViewById(R.id.text_machine_dialog_ok);
        TextView update_name = (TextView) view.findViewById(R.id.update_name);
        update_name.setText("最新版本"+updateInfo.getVersion());

        TextView dec = (TextView) view.findViewById(R.id.desc);
        dec.setMovementMethod(new ScrollingMovementMethod());
        dec.setText(updateInfo.getDescription());

        btnCancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fmUpdateDialog.dismiss();
            }
        });

        btnSure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fmUpdateDialog.dismiss();
                sendUpgradeCmd(updateInfo);
                showUpgradeLoading();
            }
        });

        fmUpdateDialog.show();
    }

    //向固件端发送升级固件的指令
    private void sendUpgradeCmd(UpdateInfo updateInfo){
        TaskExecutor.Execute(new SettingTask(mContext, mSn, PlayConfig.CommandType.NOTIFYFMUPGRADE, JsonManager.getSendFMUpgrade(mCodeFrom, updateInfo.getVersionCode()), mHandler, mFrom));
    }

    //固件升级失败弹窗
    public void showFailedDialog(){
        CamAlertDialog.Builder builder = new CamAlertDialog.Builder(mContext);
        fmFailedDialog = builder.create();
        View contentView = LayoutInflater.from(mContext).inflate(R.layout.layout_fm_upgrade_failed, null);
        fmFailedDialog.setContentView(contentView);
        fmFailedDialog.setCancelable(false);

        TextViewWithFont btnClose = (TextViewWithFont) contentView.findViewById(R.id.text_machine_close);

        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fmFailedDialog.dismiss();
            }
        });
        fmFailedDialog.show();
    }

    //加载进度框
    private void showUpgradeLoading(){
        CamAlertDialog.Builder builder = new CamAlertDialog.Builder(mContext);
        fmLoadingDialog = builder.create();
        View contentView = LayoutInflater.from(mContext).inflate(R.layout.layout_fm_upgrade_loading, null);
        fmLoadingDialog.setContentView(contentView);
        fmLoadingDialog.setCancelable(false);

        ImageView loadImg = (ImageView) contentView.findViewById(R.id.loading_img);
        loadProgress = (TextView) contentView.findViewById(R.id.load_progress);

        objectAnimator = ObjectAnimator.ofFloat(loadImg, "rotation", 0.0f, 360.0f);
        objectAnimator.setInterpolator(new LinearInterpolator());
        objectAnimator.setRepeatMode(ValueAnimator.RESTART);
        objectAnimator.setRepeatCount(Animation.INFINITE);
        objectAnimator.setDuration(1000);
        objectAnimator.start();

        fmLoadingDialog.show();

        thread.start();
    }

    public void closeFmLoadingDialog(){
        if(fmLoadingDialog!=null && fmLoadingDialog.isShowing()){
            if(objectAnimator!=null && objectAnimator.isRunning()){
                objectAnimator.cancel();
            }
            fmLoadingDialog.dismiss();
        }
    }

    //更新加载进度
    public void setProgress(int p){
        progress = p;
        if(progress>=100){
            //
            if(thread!=null){
                loadHandler.removeCallbacks(thread);
            }
            if(thread!=null && thread.isAlive()){
                thread.stop();
            }
            loadProgress.setText("100%");
            closeFmLoadingDialog();
        }else{
            loadProgress.setText(p+"%");
        }
    }

    //升级成功后，进度条的处理(500毫秒涨一次)
    public void setUpdateSuccess(SuccessCallBackInterface successCallBackInterface){
        if(thread!=null){
            loadHandler.removeCallbacks(thread);
        }
        if(thread!=null && thread.isAlive()){
            thread.stop();
        }
        mSuccessCallBackInterface = successCallBackInterface;
        currentStep = 0;
        int last = 100 - progress;
        if(progress>=90){
            //TODO一秒升级到100
            stepSum = 2;
        }else if(progress>=70){
            //TODO两秒升级到100
            stepSum = 4;
        }else{
            //TODO三秒升级到100
            stepSum = 6;
        }
        step = last/stepSum;
        loadHandler.postDelayed(myRunable, 500);
    }

    Runnable myRunable = new Runnable() {
        @Override
        public void run() {
            currentStep++;
            if(currentStep<stepSum){
                loadProgress.setText(getNextProgress()+"%");
                loadHandler.postDelayed(this, 500);
            }else if(currentStep==stepSum){
                progress = 100;
                loadProgress.setText(progress+"%");
                loadHandler.removeCallbacks(this);
                Observable.timer(500, TimeUnit.MILLISECONDS).observeOn(AndroidSchedulers.mainThread())
                        .subscribe(new Action1<Long>() {
                            @Override
                            public void call(Long aLong) {
                                closeFmLoadingDialog();
                                mSuccessCallBackInterface.updateSuccessCallBack();
                            }
                        });
            }
        }
    };

    private int getNextProgress(){
        progress += step;
        if (progress > 99) {
            progress = 100;
        }
        return progress;
    }

    public interface SuccessCallBackInterface{
        void updateSuccessCallBack();
    }

    Thread thread = new Thread() {
        @Override
        public void run() {
            int pro = random.nextInt(5);
            int new_Pro = getProgress(pro);
            if (progress == 99) {
                loadHandler.removeCallbacks(this);
            } else {
                loadHandler.postDelayed(this, 5000);
            }
            Message message = new Message();
            message.obj = new_Pro;
            message.what = 101;
            loadHandler.sendMessage(message);
        }
    };

    private int getProgress(int addValue) {
        progress += addValue;
        if (progress > 99) {
            progress = 99;
        }
        return progress;
    }

    final Handler loadHandler = new Handler() {
        @Override
        public void handleMessage(Message message) {
            switch (message.what){
                case 101:
                    setProgress((int)message.obj);
                    break;
            }
        }
    };
}
