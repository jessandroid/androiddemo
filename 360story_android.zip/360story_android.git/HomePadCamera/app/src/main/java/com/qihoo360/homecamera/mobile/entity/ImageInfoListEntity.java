package com.qihoo360.homecamera.mobile.entity;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

/**
 * Created by zhaojunbo on 2016/1/20.
 * desc:
 */
public class ImageInfoListEntity extends Head {

    public Data data;

    public static class Data {
        public String captureVideo = "";
        public ArrayList<ImageInfoEntity> list;
    }

    public static final Parcelable.Creator<ImageInfoListEntity> CREATOR = new Parcelable.Creator<ImageInfoListEntity>() {
        @Override
        public ImageInfoListEntity createFromParcel(Parcel source) {
            return new ImageInfoListEntity(source);
        }

        @Override
        public ImageInfoListEntity[] newArray(int size) {
            return new ImageInfoListEntity[size];
        }
    };

    private ImageInfoListEntity(Parcel in) {
        data = (Data) in.readValue(Data.class.getClassLoader());
    }

    @Override
    public void writeToParcel(Parcel out, int flags) {
        out.writeValue(data);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public void addData(ImageInfoListEntity imageInfoListEntity) {
        if (data.list == null || data.list.size() == 0) {
            data = imageInfoListEntity.data;
        } else {
            data.list.addAll(imageInfoListEntity.data.list);

//            int nAddIndex = -1;
//            ImageInfoEntity imageInfoEntity = null;
//            for (int i = 0; i < imageInfoListEntity.data.list.size(); i++){
//
//                nAddIndex = -1;
//                imageInfoEntity = imageInfoListEntity.data.list.get(i);
//
//                for (int j = 0; j < data.list.size(); j++){
//                    if (imageInfoEntity.getDate().compareTo(data.list.get(j).getDate()) == 1){
//                        nAddIndex = j;
//                        br
//                    }
//                }
//
//                if (nAddIndex != -1){
//                    data.list.add(nAddIndex, imageInfoEntity);
//                }else {
//                    data.list.add(imageInfoEntity);
//                }
//            }
        }
    }

//    /**
//     * 按照triggerTime排序data.list
//     */
//    public void sortList(){
//        if (data.list == null || data.list.size() == 0) {
//            return;
//        }
//
//        ImageInfoEntity imageInfoEntity = null;
//
//        for (int i = 0; i < data.list.size(); i++){
//            imageInfoEntity = data.list.get(i);
//            for (int j = i; j < data.list.size(); j++){
//                if (data.list.get(j).getDate().compareTo(imageInfoEntity.getDate()) == 1){
//                    imageInfoEntity = data.list.get(j);
//                }
//            }
//
//            data.list.remove(imageInfoEntity);
//            data.list.add(i, imageInfoEntity);
//        }
//    }
}
