package com.qihoo360.homecamera.mobile.callback;

/**
 * Created by Administrator on 2014/11/10.
 */
public interface ModelSwitcherCallback {

    void setMode(int mode);
    int getMode();
    void toggleMode();
}
