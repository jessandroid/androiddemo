package com.qihoo360.homecamera.mobile.manager;

import android.app.Application;
import android.text.TextUtils;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionPublisherWithThreadPoolBase;
import com.qihoo360.homecamera.mobile.core.manager.workpool.PoolThreadFactory;
import com.qihoo360.homecamera.mobile.core.net.Api;
import com.qihoo360.homecamera.mobile.db.CommonWrapper;
import com.qihoo360.homecamera.mobile.entity.Head;
import com.qihoo360.homecamera.mobile.entity.ImageInfoEntity;
import com.qihoo360.homecamera.mobile.entity.ImageInfoListEntity;
import com.qihoo360.homecamera.mobile.utils.Utils;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.Executors;

/**
 * desc:
 */
public class AlbumManager extends ActionPublisherWithThreadPoolBase {

    private final String mPoolNameHighPriority, mPoolNameLowPriority;
    private final Application mApp;

    public AlbumManager(Application app) {
        this.mApp = app;
        mPoolNameHighPriority = "AlbumManager-high-priority-" + Utils.DATE_FORMAT_3.format(new Date());
        mPoolNameLowPriority = "AlbumManager-low-priority-" + Utils.DATE_FORMAT_3.format(new Date());
        mThreadPool.initPool(mPoolNameHighPriority, Executors.newFixedThreadPool(3));
        mThreadPool.initPool(mPoolNameLowPriority,
                Executors.newCachedThreadPool(new PoolThreadFactory(mPoolNameLowPriority)));
    }

    public void asyncAppAlbumList(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("AppAlbumList", args));
    }

    public void loadNewestAlbumList(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("getNewestAlbum", args));
    }

    public void asyncOneDayAlbumList(Object... args) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("OneDayAlbumList", args));
    }

    public void asyncDeleteAlbumFileList(String sn, ArrayList<ImageInfoEntity> imageIdList, String device) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("deleteAlbumFileList", sn, imageIdList, device));
    }

    public void asyncDeleteAlbumOneFile(String sn, ArrayList<ImageInfoEntity> imageIdList, String device) {
        mThreadPool.submit(mPoolNameHighPriority, new NamedAsyncJob("deleteAlbumOneFile", sn, imageIdList, device));
    }

    @Override
    protected void asyncDoNamedJob(String jobName, Object... args) {
        if (TextUtils.equals(jobName, "AppAlbumList")) {
            doAppAlbumList((String) args[0], (String) args[1], (String)args[2]);
        } else if (TextUtils.equals(jobName, "OneDayAlbumList")) {
            doOneDayAlbumList((String) args[0], (String) args[1]);
        } else if (TextUtils.equals(jobName, "deleteAlbumFileList")) {
            doDeleteAlbumFileList((String) args[0], (ArrayList<ImageInfoEntity>) args[1], (String)args[2]);
        } else if (TextUtils.equals(jobName, "deleteAlbumOneFile")) {
            doDeleteAlbumOneFile((String) args[0], (ArrayList<ImageInfoEntity>) args[1], (String)args[2]);
        } else if (TextUtils.equals(jobName, "getNewestAlbum")) {
            doLoadLastVideo((String) args[0], (String) args[1], (String)args[2]);
        }
    }

    private void doAppAlbumList(String sn, String page, String device) {
        ImageInfoListEntity head = Api.Album.getAppAlbumList(sn, page, device);
        if (head == null) {
            publishAction(Actions.Album.APP_ALBUM_LIST_FAIL);
        } else if (head.errorCode == 18) {
        } else if (head.errorCode != 0) {
            publishAction(Actions.Album.APP_ALBUM_LIST_FAIL, head, page);
        } else {
            publishAction(Actions.Album.APP_ALBUM_LIST_SUCCESS, head, page);
        }
    }

    public void doLoadLastVideo(String sn, String page, String device) {
        ImageInfoListEntity headDB = CommonWrapper.getInstance(mApp).getFirstTinyVideo(sn);
        if (headDB != null && headDB.data != null && headDB.data.list != null) {
            publishAction(Actions.Album.GET_ALBUM_NEWEST_SUCCESS, headDB, page);
        }
        if (!Utils.isNetworkAvailable(mApp)) {
            return;
        }

        ImageInfoListEntity head = Api.Album.getAppAlbumList(sn, page, device);

        if (head != null) {
            CommonWrapper.getInstance(mApp).writeFirstTinyVideo(sn, head);
        }
        if (head == null || head.errorCode == 18) {
            publishAction(Actions.Album.GET_ALBUM_NEWEST_FAIL, head, page);
        } else if (head.errorCode != 0) {
            publishAction(Actions.Album.GET_ALBUM_NEWEST_FAIL, head, page);
        } else {
            publishAction(Actions.Album.GET_ALBUM_NEWEST_SUCCESS, head, page);
        }
    }

    private void doOneDayAlbumList(String sn, String page) {
        ImageInfoListEntity head = Api.Album.getOneDayAlbumList(sn, page);
        if (head == null) {
            publishAction(Actions.Album.ONE_DAY_ALBUM_LIST_FAIL);
        } else if (head.errorCode != 0) {
            publishAction(Actions.Album.ONE_DAY_ALBUM_LIST_FAIL, head.errorMsg);
        } else {
            publishAction(Actions.Album.ONE_DAY_ALBUM_LIST_SUCCESS, head);
        }
    }

    private void doDeleteAlbumFileList(String sn, ArrayList<ImageInfoEntity> deleteList, String device) {
        ArrayList<Long> imageIdList = new ArrayList<>();
        for (int i = 0; i < deleteList.size(); i++) {
            imageIdList.add(deleteList.get(i).imageId);
        }

        Head head = Api.Album.deleteAlbumFile(sn, imageIdList, device);

        if (head == null) {
            publishAction(Actions.Album.DELETE_ALBUM_FILE_LIST_FAIL);
        } else if (head.errorCode != 0) {
            publishAction(Actions.Album.DELETE_ALBUM_FILE_LIST_FAIL, head.errorMsg);
        } else {
            publishAction(Actions.Album.DELETE_ALBUM_FILE_LIST_SUCCESS, head, deleteList);
        }
    }

    private void doDeleteAlbumOneFile(String sn, ArrayList<ImageInfoEntity> deleteList, String device) {
        ArrayList<Long> imageIdList = new ArrayList<>();
        for (int i = 0; i < deleteList.size(); i++) {
            imageIdList.add(deleteList.get(i).imageId);
        }

        Head head = Api.Album.deleteAlbumFile(sn, imageIdList, device);


        if (head == null) {
            publishAction(Actions.Album.DELETE_ALBUM_ONE_FILE_FAIL);
        } else if (head.errorCode != 0) {
            publishAction(Actions.Album.DELETE_ALBUM_ONE_FILE_FAIL, head.errorMsg);
        } else {
            publishAction(Actions.Album.DELETE_ALBUM_ONE_FILE_SUCCESS, head, deleteList);
        }
    }
}
