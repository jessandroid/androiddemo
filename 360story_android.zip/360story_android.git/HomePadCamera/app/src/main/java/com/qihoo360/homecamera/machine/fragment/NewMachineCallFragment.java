
package com.qihoo360.homecamera.machine.fragment;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.Rect;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.VideoView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.gson.Gson;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;
import com.qihoo360.homecamera.machine.activity.VideoPlayActivity;
import com.qihoo360.homecamera.machine.config.MachineConsts;
import com.qihoo360.homecamera.machine.entity.Camera;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.activity.BaseActivity;
import com.qihoo360.homecamera.mobile.activity.BindDeviceFrameActivity;
import com.qihoo360.homecamera.mobile.activity.EventPagerActivity;
import com.qihoo360.homecamera.mobile.activity.KibotSettingActivity;
import com.qihoo360.homecamera.mobile.activity.MainActivity;
import com.qihoo360.homecamera.mobile.activity.WebViewActivity;
import com.qihoo360.homecamera.mobile.adapter.DeviceNewSmallVideoAdapter;
import com.qihoo360.homecamera.mobile.config.Const;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.core.manager.Actions;
import com.qihoo360.homecamera.mobile.core.manager.util.ActionListener;
import com.qihoo360.homecamera.mobile.db.PadInfoWrapper;
import com.qihoo360.homecamera.mobile.db.PhoneRecordWrapper;
import com.qihoo360.homecamera.mobile.entity.DeviceCloudSettingSupport;
import com.qihoo360.homecamera.mobile.entity.DeviceInfo;
import com.qihoo360.homecamera.mobile.entity.ImageInfoEntity;
import com.qihoo360.homecamera.mobile.entity.ImageInfoListEntity;
import com.qihoo360.homecamera.mobile.entity.PhoneRecord;
import com.qihoo360.homecamera.mobile.manager.GlobalManager;
import com.qihoo360.homecamera.mobile.model.DeviceInfoModel;
import com.qihoo360.homecamera.mobile.ui.NewSwitchView;
import com.qihoo360.homecamera.mobile.ui.fragment.BaseFragment;
import com.qihoo360.homecamera.mobile.ui.fragment.NewDeviceFragment;
import com.qihoo360.homecamera.mobile.ui.storyui.VerticalSwipeRefreshLayout;
import com.qihoo360.homecamera.mobile.ui.storyui.view.ImageWithIcon;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.CameraToast;
import com.qihoo360.homecamera.mobile.utils.DensityUtil;
import com.qihoo360.homecamera.mobile.utils.ImageCache;
import com.qihoo360.homecamera.mobile.utils.NetOptHelper;
import com.qihoo360.homecamera.mobile.utils.PhoneUtil;
import com.qihoo360.homecamera.mobile.utils.Preferences;
import com.qihoo360.homecamera.mobile.utils.Utils;
import java.lang.ref.SoftReference;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import butterknife.ButterKnife;
import butterknife.OnClick;
import rx.Observable;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.functions.Func1;

public class NewMachineCallFragment extends BaseFragment
        implements ActionListener, DeviceNewSmallVideoAdapter.OnItemClick {

    public final static int OFFLINE = 0;
    public final static int ONLINE = 1;
    public final static int UNKNOWN = 2;

    public SoftReference<MainActivity> softReference;
    public static final String NEW_DEVICE_ARG = "param1";

    private String mParam1;
    private NewDeviceFragment.OnFragmentInteractionListener mListener;
    private MainActivity mainActivity;

    private View mCloseCaptureImgZone;
    ImageWithIcon devcieImage;
    public ImageView videoCoverImageIv, mCloseCaptureImg;
    RelativeLayout relativeLayout5;
    TextView NoVideoTextShow;
    public VideoView videoPlay;
    public boolean isClickPlay = false;
    Button addCam;
    Button buyCam;
    RelativeLayout showWhenHaveRob;
    ImageButton homeplayM;
    LinearLayout emptyShow;
    public NewSwitchView switchView;
    private float mWHRatio = 4 / 3;

    public DeviceNewSmallVideoAdapter deviceNewSmallVideoAdapter;
    public ArrayList<ImageInfoEntity> imageInfoEntityArrayList;
    public RelativeLayout mPhoneRecordRl;
    public TextView mCallName;
    public TextView mTimeTv;
    public TextView mRecordNum;
    public VerticalSwipeRefreshLayout swipe_refresh;

    protected boolean isVisible = false;
    protected boolean isEnter = false;
    private int viewWidth;
    private int viewHeight;
    private RelativeLayout.LayoutParams linearP;
    private boolean mStartMonitor = false;
    private boolean hasVideoPrepared = false;
    public int videoPos = 0;
    private ArrayList<DeviceInfo> mLoadedDevList;
    private ImageView mOnlineState;

    private boolean mIsAllowCapture = true;
    private ImageView smallVideoRecycle;
    private RelativeLayout relativeLayout;
    private LinearLayout image_layout;

    public NewMachineCallFragment() {
    }

    public static NewMachineCallFragment newInstance(String param1, String param2) {
        NewMachineCallFragment fragment = new NewMachineCallFragment();
        Bundle args = new Bundle();
        args.putString(NEW_DEVICE_ARG, param1);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onAttach(Context context) {
        softReference = new SoftReference<>((MainActivity) context);
        mainActivity = softReference.get();
        super.onAttach(context);
        if (context instanceof NewDeviceFragment.OnFragmentInteractionListener) {
            mListener = (NewDeviceFragment.OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(NEW_DEVICE_ARG);
        }
        GlobalManager.getInstance().getCameraManager().registerActionListener(this);
    }

    @Override
    public void onResume() {
        mStartMonitor = false;
        if (isVisible) {
            onEnter();
        }
        super.onResume();
        queryPhoneCall();

    }

    @Override
    public void onPause() {
        isClickPlay = false;
        if (isVisible) {
            onLeave();
        }
        super.onPause();
    }

    @Override
    public boolean onTabSwitched() {
        if (videoPlay != null) {
            videoPlay.clearFocus();
        }
        return true;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_new_machine_call, container, false);
        ButterKnife.bind(this, view);
        DisplayMetrics dm = new DisplayMetrics();
        mainActivity.getWindowManager().getDefaultDisplay().getMetrics(dm);
        viewWidth = dm.widthPixels;
        viewHeight = (int) (viewWidth / mWHRatio);
        CLog.d("viewWidth:" + viewWidth + "viewHeight:" + viewHeight);
        viewHeight = DensityUtil.getHeight4vs3(mainActivity, viewWidth);
        linearP = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, viewHeight);

        videoCoverImageIv = (ImageView) view.findViewById(R.id.video_cover_image);
        devcieImage = (ImageWithIcon) view.findViewById(R.id.devcie_image);
        devcieImage.setLayoutParams(linearP);
        switchView = (NewSwitchView) view.findViewById(R.id.inner_switch);
        relativeLayout5 = (RelativeLayout) view.findViewById(R.id.relativeLayout5);
        mCloseCaptureImgZone = view.findViewById(R.id.device_close_capture_img_zone);
        mCloseCaptureImg = (ImageView) view.findViewById(R.id.device_close_capture_img);

        NoVideoTextShow = (TextView) view.findViewById(R.id.novideotextshow);
        videoPlay = (VideoView) view.findViewById(R.id.video_play);
        image_layout = (LinearLayout) view.findViewById(R.id.image_layout);
        smallVideoRecycle = (ImageView) view.findViewById(R.id.small_video_recycle);
        Glide.with(this).load(R.drawable.pic).into(smallVideoRecycle);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT, viewHeight);
        layoutParams.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        layoutParams.addRule(RelativeLayout.ALIGN_PARENT_TOP);
        layoutParams.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
        layoutParams.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
        videoPlay.setLayoutParams(layoutParams);
        addCam = (Button) view.findViewById(R.id.add_cam);
        buyCam = (Button) view.findViewById(R.id.buy_cam);

        showWhenHaveRob = (RelativeLayout) view.findViewById(R.id.showWhenHaveRob);
        homeplayM = (ImageButton) view.findViewById(R.id.homeplay_m);
        homeplayM.setImageResource(R.drawable.home_play_btn_m);
        emptyShow = (LinearLayout) view.findViewById(R.id.empty_show);
        swipe_refresh = (VerticalSwipeRefreshLayout) view.findViewById(R.id.swipe_refresh);
        swipe_refresh.setColorSchemeResources(android.R.color.holo_red_light, android.R.color.holo_red_light,
                android.R.color.holo_red_light, android.R.color.holo_red_light);
        if (!TextUtils.isEmpty(mainActivity.deviceInfo.sn)) {
            swipe_refresh.setEnabled(true);
        } else {
            swipe_refresh.setEnabled(false);
        }
        swipe_refresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if (mainActivity.deviceInfo != null && !TextUtils.isEmpty(mainActivity.deviceInfo.sn)) {
                    GlobalManager.getInstance().getCommonManager().publishAction(Actions.Camera.SET_VIEW2_CLICKABLE,
                            false);
                    GlobalManager.getInstance().getCameraManager().asyncLoadMyCamera(0);
                }
            }
        });
        mCallName = (TextView) view.findViewById(R.id.tv_call_name);
        mTimeTv = (TextView) view.findViewById(R.id.tv_time);
        mRecordNum = (TextView) view.findViewById(R.id.tv_record_num);
        mPhoneRecordRl = (RelativeLayout) view.findViewById(R.id.rl_phone_record);
        mPhoneRecordRl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clearRedPot();
            }
        });
        imageInfoEntityArrayList = new ArrayList<>();
        deviceNewSmallVideoAdapter = new DeviceNewSmallVideoAdapter(mainActivity, imageInfoEntityArrayList, this);
        GlobalManager.getInstance().getCameraManager().asyncLoadMyCamera(0);
        mOnlineState = (ImageView) view.findViewById(R.id.online_tips);
        Uri myVideoUri = Uri.parse(
                "android.resource://" + mainActivity.getApplication().getPackageName() + "//" + R.raw.xiaopingguo);
        videoPlay.setDrawingCacheEnabled(true);
        videoPlay.setVideoURI(myVideoUri);
        videoPlay.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                mp.setLooping(false);
                videoPlay.setBackgroundColor(Color.TRANSPARENT);
                videoPos = 0;
                videoPlay.seekTo(videoPos);
                videoPlay.pause();
                Utils.ensureVisbility(videoPos == 0 ? View.VISIBLE : View.GONE, videoCoverImageIv);
            }
        });
        if (!TextUtils.isEmpty(mainActivity.deviceInfo.sn)) {
            setDevieImage(false);
        }
        return view;
    }

    private void clearRedPot() {
        Utils.ensureVisbility(View.GONE, mPhoneRecordRl);
        PhoneRecordWrapper.getInstance(getActivity()).updatePhoneRecordStateBySn(mainActivity.deviceInfo.sn);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (switchView != null) {
            switchView.setOnCheckedChangeListener(new NewSwitchView.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(boolean isChecked) {
                    CLog.d(mainActivity.deviceInfo.toJson());
                    if (!isChecked) {
                        return;
                    }
                    clearRedPot();
                    judgeCallNetWorkType(true);
                }
            });
        }
        final Point point = new Point();
        int w = View.MeasureSpec.makeMeasureSpec(0,
                View.MeasureSpec.UNSPECIFIED);
        int h = View.MeasureSpec.makeMeasureSpec(0,
                View.MeasureSpec.UNSPECIFIED);
        relativeLayout5.measure(w, h);
        final int height = relativeLayout5.getMeasuredHeight();
        final int[] ss = new int[2];
        getActivity().getWindowManager().getDefaultDisplay().getSize(point);
        relativeLayout5.post(new Runnable() {
            @Override
            public void run() {
                Rect viewRect = new Rect();
                relativeLayout5.getLocalVisibleRect(viewRect);
                relativeLayout5.getLocationInWindow(ss);
                int h = point.y - (ss[1] + height + Utils.convertDpToPixel(46));
                image_layout
                        .setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h));
            }
        });
    }

    private void judgeCallNetWorkType(final boolean talk) {
        if (NetOptHelper.getCurNetType(getActivity()) == NetOptHelper.MOBILE_NET_TYPE) {
            if (!Constants.HAS_SHOW_NET_TIPS) {
                Dialog dialog = ((BaseActivity) getActivity()).showCommonDialog("", getString(R.string.tips_44),
                        getString(R.string.tips_45), getString(R.string.tips_46), "", false,
                        new BaseActivity.ICommonDialog() {
                            @Override
                            public void onRightButtonClick(boolean... isChecked) {
                                Constants.HAS_SHOW_NET_TIPS = true;
                                startCall(talk);
                            }

                            @Override
                            public void onLeftButtonClick(boolean... isChecked) {
                                switchView.setChecked(true);
                            }

                            @Override
                            public void onDialogCancel() {
                                switchView.setChecked(true);
                            }
                        });
                dialog.setCancelable(false);
            } else {
                startCall(talk);
            }
        } else {
            startCall(talk);
        }
    }

    private void startCall(Boolean startCall) {
        Intent intent = new Intent(getActivity(), VideoPlayActivity.class);
        Gson gson = new Gson();
        String xx = "{\"aclInfo\":{\"acl1\":1,\"acl2\":1,\"acl3\":1},\"category\":\"360摄像机\",\"cloudStatus\":2,\"public\":1,\"compel\":0,\"createtime\":0,\"description\":\"我的摄像机\",\"extend\":{\"image_time\":1483945324,\"scene\":999,\"sensitive\":0,\"soft_switch\":1,\"still\":0},\"firmware\":{\"compel\":0,\"createTime\":\"\",\"fileSize\":0,\"hardware\":\"\",\"md5\":\"\",\"model\":\"\",\"recommand\":0,\"status\":0,\"errorCode\":-1,\"serverStateCode\":-1,\"statusCode\":-1},\"gifStatus\":1,\"hardware\":\"{\\\"ir\\\":1,\\\"angle\\\":150,\\\"distort\\\":1}\",\"id\":0,\"ipcType\":0,\"isDemo\":0,\"isFirstMyCamera\":false,\"location\":\"\",\"locationId\":\"\",\"owner\":\"\",\"p2pInfo\":{\"port\":80},\"role\":0,\"share\":1,\"state\":1,\"status\":0,\"support\":\"{\\\"secure_hd\\\":1,\\\"secure\\\":1,\\\"secure_work_hd\\\":1,\\\"secure_work\\\":1,\\\"secure_both_hd\\\":1,\\\"secure_both\\\":1,\\\"record_hd\\\":1,\\\"record\\\":1,\\\"face_hd\\\":1,\\\"face\\\":1,\\\"playurl_hd\\\":1,\\\"playurl\\\":1,\\\"public_hd\\\":1,\\\"public\\\":1,\\\"ir_hd\\\":1,\\\"ir\\\":1,\\\"voice_ppt_hd\\\":1,\\\"voice_ppt\\\":1,\\\"cloud_hd\\\":1,\\\"cloud\\\":1,\\\"soft_switch_hd\\\":1,\\\"soft_switch\\\":1,\\\"video_hd\\\":1,\\\"video\\\":1,\\\"stream_v2_hd\\\":1,\\\"stream_v2\\\":1,\\\"video_msg_hd\\\":1,\\\"video_msg\\\":1,\\\"family_face_hd\\\":1,\\\"family_face\\\":1,\\\"face_video_hd\\\":1,\\\"face_video\\\":1,\\\"noice_detect_hd\\\":1,\\\"noice_detect\\\":1,\\\"motion_elder_hd\\\":1,\\\"motion_elder\\\":1,\\\"motion_split_hd\\\":1,\\\"motion_split\\\":1,\\\"batch_cmd_hd\\\":1,\\\"batch_cmd\\\":1,\\\"p2p_hd\\\":1,\\\"p2p\\\":1,\\\"stream_ts_hd\\\":1,\\\"stream_ts\\\":1}\",\"supportFace\":1,\"supportRecord\":1,\"supportSecure\":1,\"test\":1,\"thumbnail\":\"https://q2.jia.360.cn/app/viewImage?imgKey\\u003d114f68a55e314c137701cfaa34306ad0f96027cb-1-1-5-736-414.jpg\\u0026sn\\u003d36060700000\",\"thumbnail_local\":\"\",\"title\":\"宝贝\",\"titlePhone\":\"我的看家手机\",\"updateNumber\":0,\"upfSucc\":0,\"upgrade\":0,\"url\":\"\",\"errorCode\":-1,\"serverStateCode\":-1,\"sn\":\"36060700000\",\"statusCode\":-1}";
        Camera camera = gson.fromJson(xx, Camera.class);
        camera.title = mainActivity.deviceInfo.title;
        camera.sn = ((MainActivity) getActivity()).deviceInfo.sn;
        camera.role = 0;
        Bundle bundle = new Bundle();
        bundle.putParcelable("camera", camera);
        bundle.putBoolean("call", startCall);
        bundle.putParcelable(MachineConsts.DEVICEINFO, ((MainActivity) getActivity()).deviceInfo);

        intent.putExtra("bundle", bundle);
//        intent.putExtra("camera", camera);
//        intent.putExtra(MachineConsts.DEVICEINFO, ((MainActivity) getActivity()).deviceInfo);
        startActivity(intent);
        if(switchView!=null){
            Observable.timer(1, TimeUnit.SECONDS).observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Action1<Long>() {
                        @Override
                        public void call(Long aLong) {
                            switchView.setChecked(false);
                        }
                    });
        }
    }

    public void loadData() {
        DeviceInfoModel sources = new DeviceInfoModel();
        Observable<DeviceInfo> source = Observable.concat(
                sources.memory(),
                sources.network()).filter(new Func1<DeviceInfo, Boolean>() {
                    @Override
                    public Boolean call(DeviceInfo deviceInfo) {
                        return deviceInfo != null;
                    }
                });
        source.doOnNext(new Action1<DeviceInfo>() {
            @Override
            public void call(DeviceInfo deviceInfo) {
            }
        });
    }

    @Override
    public void onDetach() {
        super.onDetach();
        videoPlay.destroyDrawingCache();
        GlobalManager.getInstance().getCameraManager().removeActionListener(this);
        mainActivity = null;
        softReference.clear();
        mListener = null;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ButterKnife.unbind(this);
    }

    private void queryPhoneCall() {
        if (mainActivity.deviceInfo != null) {
            ArrayList<PhoneRecord> phoneRecordList = PhoneRecordWrapper.getInstance(getActivity())
                    .getAllNotProcessedwPhoneRecordBySn(mainActivity.deviceInfo.sn);
            if (phoneRecordList != null && phoneRecordList.size() > 0) {
                mRecordNum.setText((phoneRecordList.size() > 99 ? 99 : phoneRecordList.size()) + "");
                Utils.ensureVisbility(View.VISIBLE, mPhoneRecordRl);
                mCallName.setText(
                        TextUtils.isEmpty(mainActivity.deviceInfo.title) ? "宝贝" : mainActivity.deviceInfo.title);
                mTimeTv.setText(PhoneUtil.getTitleDateString(false, phoneRecordList.get(0).START_CALL_TIME));
            } else {
                Utils.ensureVisbility(View.GONE, mPhoneRecordRl);
            }
            ArrayList<PhoneRecord> newPhoneRecordList = PhoneRecordWrapper.getInstance(getActivity())
                    .getAllPhoneRecordBySn(mainActivity.deviceInfo.sn);
            for (int i = 0; i < newPhoneRecordList.size(); i++) {
                PhoneRecord phoneRecord = newPhoneRecordList.get(i);
                CLog.i("phone_record", phoneRecord.toString());

            }
        } else {
            Utils.ensureVisbility(View.GONE, mPhoneRecordRl);
        }

    }

    @Override
    public Object actionPerformed(int actionCode, Object... args) {
        switch (actionCode) {
            case Actions.Camera.SELECTED_CAMERA_M: {
                setDevieImage(false);
                queryPhoneCall();
                refreshState();
                return Boolean.TRUE;
            }
            case Actions.Call.SHOW_TOAST_WHEN_BE_HANGUP: {
                CameraToast.showToast(Utils.context, (String) args[0]);
                return Boolean.TRUE;
            }
            case Actions.Camera.LOAD_OK: {
                queryPhoneCall();
                swipe_refresh.setRefreshing(false);
                setDevieImage(args.length == 0);
                GlobalManager.getInstance().getCommonManager().publishAction(Actions.Camera.SET_VIEW2_CLICKABLE, true);
                ArrayList<DeviceInfo> deviceInfos = PadInfoWrapper.getInstance().getAllPad();
                mLoadedDevList = deviceInfos;
                Utils.ensureVisbility(View.GONE, devcieImage);
                if (!deviceInfos.isEmpty()) {
                    swipe_refresh.setEnabled(true);
                    Utils.ensureVisbility(View.GONE, videoPlay, emptyShow, homeplayM);
                    Utils.ensureVisbility(View.VISIBLE, devcieImage, showWhenHaveRob);
                    ((MainActivity) getActivity()).showAvator(true);
                } else {
                    Utils.ensureVisbility(View.GONE, showWhenHaveRob);
                    swipe_refresh.setEnabled(false);
                    ((MainActivity) getActivity()).showAvator(false);
                    Utils.ensureVisbility(View.VISIBLE, videoPlay, emptyShow);

                    if (isClickPlay == false) {
                        Utils.ensureVisbility(View.VISIBLE, homeplayM);
                        Utils.ensureVisbility(View.GONE, devcieImage);
                        Glide.with(this)
                                .load(mainActivity.deviceInfo.getCoverUrl())
                                .error(R.drawable.device_moren_icon)
                                .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                                .priority(Priority.IMMEDIATE)
                                .dontAnimate()
                                .into(devcieImage);
                    }

                    videoPlay.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                        @Override
                        public void onCompletion(MediaPlayer mp) {
                            if (mLoadedDevList != null && mLoadedDevList.size() > 0) {
                            }
                            if (mLoadedDevList == null || mLoadedDevList.size() == 0) {
                                Utils.ensureVisbility(View.VISIBLE, homeplayM);
                                videoPos = 0;
                                videoPlay.seekTo(videoPos);
                                Utils.ensureVisbility(View.VISIBLE, videoCoverImageIv);
                            }
                        }
                    });

                }
                refreshState();
                return Boolean.TRUE;
            }
            case Actions.Camera.CAMERA_LIST_NEED_SHOW_PURCHASE: {
                return Boolean.TRUE;
            }

            case Actions.Camera.UN_BIND_DEVICE_SUCCESS: {
                String sn = (String) args[0];
                if (TextUtils.equals(Preferences.getSelectedPad(), sn)) {
                    Preferences.saveSelectedPad("");
                }
                mainActivity.deviceInfo = new DeviceInfo();
                PhoneRecordWrapper.getInstance(Utils.getContext()).updatePhoneRecordStateBySn(sn);
                queryPhoneCall();
                return Boolean.TRUE;
            }
            case Actions.Camera.UN_BIND_DEVICE_FAIL: {
                return Boolean.TRUE;
            }
            case Actions.Album.GET_ALBUM_NEWEST_SUCCESS: {
                ImageInfoListEntity mImageInfoListEntity = (ImageInfoListEntity) args[0];
                String page = (String) args[1];

                if (mImageInfoListEntity != null && mImageInfoListEntity.data != null) {
                    if (mImageInfoListEntity.data.captureVideo.equals("1")) {
                        mIsAllowCapture = true;
                    } else if (mImageInfoListEntity.data.captureVideo.equals("0")) {
                        mIsAllowCapture = false;
                    }
                }

                if (mImageInfoListEntity.data.list.size() > 0) {
                    Utils.ensureVisbility(View.GONE, NoVideoTextShow, mCloseCaptureImgZone);
                    if (page.equals("0")) {
                        if (!isDataSame(imageInfoEntityArrayList, mImageInfoListEntity.data.list)) {
                            imageInfoEntityArrayList.clear();
                            imageInfoEntityArrayList.addAll(mImageInfoListEntity.data.list);
                            deviceNewSmallVideoAdapter.dataChanage(imageInfoEntityArrayList);
                        }
                    }

                } else {
                    if (mIsAllowCapture == false) {
                        if (mainActivity != null) {
                            if (mainActivity.deviceInfo != null) {
                                if (mainActivity.deviceInfo.role == 1) {
                                    mCloseCaptureImg.setImageResource(R.drawable.capture_f_off_admin);
                                } else if (mainActivity.deviceInfo.role == 2) {
                                    mCloseCaptureImg.setImageResource(R.drawable.capture_f_off_guest);
                                }
                            }
                        }
                        Utils.ensureVisbility(View.VISIBLE, mCloseCaptureImgZone);
                        Utils.ensureVisbility(View.GONE/*, smallVideoRecycle*/, NoVideoTextShow);
                    } else {
                        Utils.ensureVisbility(View.VISIBLE, NoVideoTextShow);
                        Utils.ensureVisbility(View.GONE, /*smallVideoRecycle,*/ mCloseCaptureImgZone);
                    }
                }
                return Boolean.TRUE;
            }
            case Actions.Album.GET_ALBUM_NEWEST_FAIL: {
                ImageInfoListEntity iil = (ImageInfoListEntity) args[0];
                if (iil != null) {
                    if (iil.errorCode == 88) {
                        Utils.ensureVisbility(View.VISIBLE, NoVideoTextShow);
                        Utils.ensureVisbility(View.GONE, /*smallVideoRecycle,*/ mCloseCaptureImgZone);
                    }
                    if (!TextUtils.isEmpty(iil.errorMsg)) {
                        if (iil.errorCode != 88) {
                            CameraToast.showErrorToast(iil.errorMsg);
                        }
                    }
                }
                return Boolean.TRUE;
            }
            default:
                break;
        }
        return Actions.ACTION_NOT_PROCESSED;
    }

    private boolean isDataSame(ArrayList<ImageInfoEntity> srcList, ArrayList<ImageInfoEntity> addList) {
        if (srcList == null || addList == null) {
            return false;
        }
        //请求添加的数据为空时 判断为不同 需要重新刷新页面
        if (addList.size() == 0) {
            return false;
        }

        if (srcList.size() < addList.size()) {
            return false;
        }

        for (int i = 0; i < addList.size(); i++) {
            if (!srcList.get(i).isEqualWith(addList.get(i))) {
                return false;
            }
        }

        return true;
    }

    @Override
    public int getProperty() {
        return 0;
    }

    @Override
    public void onGrayClick(int i) {
        mainActivity.switchTabIndex(1);
    }

    @Override
    public void onItemClick(int i) {
        EventPagerActivity.startActivity(imageInfoEntityArrayList,
                getActivity(), i, new EventPagerActivity.IDeleteCallback() {
                    @Override
                    public void onDelete(ImageInfoEntity imageInfoEntity) {

                    }
                }, true);
    }

    @OnClick({
            R.id.add_cam, R.id.buy_cam, R.id.homeplay_m, R.id.devcie_image, R.id.video_play,
            R.id.device_close_capture_img_zone
    })
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.device_close_capture_img_zone:
                if (mainActivity.deviceInfo.role == 1) {
                    String supportStr = mainActivity.deviceInfo.support;
                    Gson gson = new Gson();
                    DeviceCloudSettingSupport ds = gson.fromJson(supportStr, DeviceCloudSettingSupport.class);
                    if (ds != null && ds.getSetting_v1() == 1) {
                        KibotSettingActivity.startActivity(getActivity(), mainActivity.deviceInfo);
                    } else {
                        CameraToast.showToast(getActivity(), R.string.remote_set_not_support);
                    }
                }
                break;
            case R.id.video_play:
                if (videoPlay.isPlaying()) {
                    videoPlay.pause();
                    isClickPlay = false;
                } else {
                    videoPlay.start();
                    Utils.ensureVisbility(View.GONE, videoCoverImageIv);
                    isClickPlay = true;
                }
                break;

            case R.id.add_cam: {
                Intent intent = new Intent(mainActivity, BindDeviceFrameActivity.class);
                startActivity(intent);
                break;
            }

            case R.id.buy_cam:
                Intent intent = new Intent(getActivity(), WebViewActivity.class);
                intent.putExtra("url", Const.KIBOT_OFFICAL);
                startActivity(intent);
                break;

            case R.id.homeplay_m:
                videoPlay.start();
                Utils.ensureVisbility(View.GONE, videoCoverImageIv);
                isClickPlay = true;
                Utils.ensureVisbility(View.GONE, devcieImage, homeplayM);
                Utils.ensureVisbility(View.VISIBLE, videoPlay);
                break;

            case R.id.devcie_image: {
                if (!TextUtils.isEmpty(mainActivity.deviceInfo.sn)) {
                    judgeMonitorNetWorkType();
                    SharedPreferences sp = Preferences.getAppSP();
                    SharedPreferences.Editor editor = sp.edit();
                    editor.putBoolean("is_used_single_call", true);
                    editor.commit();
                    if (devcieImage != null) {
                        devcieImage.invalidate();
                    }
                }
                break;
            }
        }
    }

    private void judgeMonitorNetWorkType() {
        if (NetOptHelper.getCurNetType(getActivity()) == NetOptHelper.MOBILE_NET_TYPE) {
            if (!Constants.HAS_SHOW_NET_TIPS) {
                Dialog dialog = ((BaseActivity) getActivity()).showCommonDialog("", "您正在使用非wifi网络，将会产生手机流量。", "取消",
                        "继续", "", false, new BaseActivity.ICommonDialog() {
                            @Override
                            public void onRightButtonClick(boolean... isChecked) {
                                Constants.HAS_SHOW_NET_TIPS = true;
                                startMonitor();
                            }

                            @Override
                            public void onLeftButtonClick(boolean... isChecked) {
                            }

                            @Override
                            public void onDialogCancel() {
                            }
                        });
                dialog.setCancelable(false);
            } else {
                startMonitor();
            }
        } else {
            startMonitor();
        }
    }

    private void startMonitor() {
        if (!mStartMonitor) {
            if (mainActivity.deviceInfo.isAllowRemoteView() == false) {
                CameraToast.showToast(this.getActivity(), R.string.remote_view_need_auth);
                return;
            }
            mStartMonitor = true;
            startCall(false);
        }
    }

    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(Uri uri);
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        isVisible = isVisibleToUser;
        if (isVisibleToUser) {
            onEnter();
        } else {
            onLeave();
        }
    }

    /**
     * 进入这个页面，代替onResume
     */
    public void onEnter() {
        if (!isEnter) {
            //            QHStatAgent.onPageStart(getActivity(), "NewDeviceFragment");
            isEnter = true;
        }
    }

    /**
     * 退出这个页面，代替onPause
     */
    public void onLeave() {
        if (isEnter) {
            //            QHStatAgent.onPageEnd(getActivity(), "NewDeviceFragment");
            if (videoPlay.getVisibility() == View.VISIBLE) {
                videoPlay.pause();
                videoPos = videoPlay.getCurrentPosition();
                isClickPlay = false;
                Utils.ensureVisbility(View.VISIBLE, homeplayM);
            }

            isEnter = false;
        }
    }

    public void setDevieImage(boolean newDataArrived) {
        synchronized (this) {
            if (mainActivity == null || mainActivity.deviceInfo == null) {
                return;
            }
            boolean isAllowRemote = mainActivity.deviceInfo.isAllowRemoteView();
            if (devcieImage != null) {
                devcieImage.setAllowRemote(isAllowRemote);
                if (isAllowRemote == false) {
                    devcieImage.setImageResource(R.drawable.not_allow_remote_watch);
                    if(switchView!=null){
                        switchView.setoffLine(isAllowRemote);
                    }
                    return;
                }
            }

            String deviceSN = mainActivity.deviceInfo.getSn();
            if (TextUtils.isEmpty(deviceSN)) {
                return;
            }
            if(switchView!=null){
                switchView.setoffLine(true);
            }
            String previewPath = ImageCache.getInstance().checkCoverImg(deviceSN);
            if (!TextUtils.isEmpty(previewPath) && !newDataArrived) {
                ImageLoader.getInstance().displayImage(previewPath, devcieImage);
            } else {
                Glide.with(this)
                        .load(TextUtils.isEmpty(mainActivity.deviceInfo.getCoverUrl())
                                ? mainActivity.deviceInfo.isAllowRemoteView() ? R.drawable.device_moren_icon
                                : R.drawable.not_allow_remote_watch
                                : mainActivity.deviceInfo.getCoverUrl())
                        .override(viewWidth, viewHeight)
                        .error(R.drawable.moren_icon)
                        .into(devcieImage);

                if (mainActivity == null || mainActivity.deviceInfo == null
                        || TextUtils.isEmpty(mainActivity.deviceInfo.getCoverUrl()))
                    return;
                final String deviceSn = mainActivity.deviceInfo.getSn();

                ImageLoader.getInstance().loadImage(mainActivity.deviceInfo.getCoverUrl(),
                        new SimpleImageLoadingListener() {
                            public void onLoadingComplete(String imageUri, android.view.View view,
                                    android.graphics.Bitmap loadedImage) {
                                ImageCache.getInstance().cacheCoverImg(loadedImage, deviceSn);
                            }

                            @Override
                            public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
                                super.onLoadingFailed(imageUri, view, failReason);
                            }
                        });
            }
        }

    }

    private void refreshState() {
        if (mOnlineState != null) {
            if (mainActivity != null && mainActivity.deviceInfo != null
                    && !TextUtils.isEmpty(mainActivity.deviceInfo.getSn())) {
                mOnlineState.setVisibility(View.VISIBLE);
                switch (mainActivity.deviceInfo.isOnline) {
                    case OFFLINE:
                        mOnlineState.setImageResource(R.drawable.pad_offline);
                        break;
                    case ONLINE:
                        mOnlineState.setImageResource(R.drawable.pad_online);
                        break;
                }
            } else {
                mOnlineState.setVisibility(View.GONE);
            }
        }
    }

}
