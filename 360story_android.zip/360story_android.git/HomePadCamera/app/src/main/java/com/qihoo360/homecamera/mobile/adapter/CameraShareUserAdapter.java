package com.qihoo360.homecamera.mobile.adapter;

import android.content.Context;
import android.text.Html;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.qihoo360.homecamera.mobile.R;
import com.qihoo360.homecamera.mobile.callback.ShareUserCallback;
import com.qihoo360.homecamera.mobile.config.Constants;
import com.qihoo360.homecamera.mobile.entity.Camera;
import com.qihoo360.homecamera.mobile.entity.ShareUser;
import com.qihoo360.homecamera.mobile.utils.CLog;
import com.qihoo360.homecamera.mobile.utils.Utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;


/**
 * Created by Administrator on 2014/11/14.
 */
public class CameraShareUserAdapter extends BaseAdapter {

    private Context context;
    private List<ShareUser> userList;

    public static final int TYPE_USER = 1;
    public static final int TYPE_NONE = 2;
    public static final int TYPE_TITLE = 3;
    public static final int TYPE_WAITING = 4;
    public static final int TYPE_TOTLE_CATEGORY = 5;

    private DisplayImageOptions displayImageOptions;
    private ShareUserCallback shareUserCallback;
    private Camera camera;

    public CameraShareUserAdapter(Context context, List<ShareUser> userList,
                                  DisplayImageOptions displayImageOptions, Camera camera) {
        this.context = context;
        this.userList = userList;
        this.displayImageOptions = displayImageOptions;
        this.shareUserCallback = (ShareUserCallback) context;
        this.camera = camera;
    }

    public void updateData(List<ShareUser> userList) {
        this.userList = userList;
        notifyDataSetChanged();
    }

    public int getAcceptCount() {
//        int userList.size()-1
        int shareCount = 0;
        for (int i = 0; i < userList.size(); i++) {
            shareCount = userList.get(i).getAccept() == ShareUser.ACCEPTED ? shareCount + 1 : shareCount;
        }
        return shareCount;
    }

    @Override
    public int getCount() {
        if (userList != null) {
            return userList.size();
        }
        return 0;
    }

    @Override
    public ShareUser getItem(int arg0) {
        if (arg0 < userList.size() && userList.size() > 0) {
            return userList.get(arg0);
        }
        return null;
    }

    @Override
    public long getItemId(int arg0) {
        if (arg0 < userList.size()) {
            if (TextUtils.isEmpty(userList.get(arg0).getSqid())) return arg0;
            return Long.parseLong(userList.get(arg0).getSqid());
        } else {
            return 0;
        }
    }

    public String getInvUserCount() {
        String l = Utils.getString(R.string.invite_family_count_prompt);
        int count = 0;
        for (int i = 0; i < userList.size(); i++) {
            if (!TextUtils.isEmpty(userList.get(i).getSqid())) {
                count += 1;
            }
        }
        if (count > 0) {
            l = String.format(l, count);
        } else {
            l = "";
        }
        return l;
    }

    @Override
    public int getViewTypeCount() {
        return TYPE_TOTLE_CATEGORY;
    }

    @Override
    public int getItemViewType(int position) {
        int type = 0;
        if (position == 0) {
            type = TYPE_TITLE;
        } else {
            if (getItem(position) != null && !TextUtils.isEmpty(getItem(position).getSqid())) {
                if (getItem(position).getAccept() == ShareUser.ACCEPTED) {
                    type = TYPE_USER;
                } else if (getItem(position).getAccept() == ShareUser.WAITING) {
                    type = TYPE_WAITING;
                } else {
                    type = TYPE_NONE;
                }
            } else {
                type = TYPE_NONE;
            }
        }
        return type;
    }


    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final ViewHolder holder;
        int type = getItemViewType(position);
        if (convertView == null) {
            holder = new ViewHolder();
            switch (type) {
                case TYPE_TITLE:
                    convertView =
                            LayoutInflater.from(context).inflate(R.layout.item_share_user_title,
                                    null);
                    holder.shareCountText =
                            (TextView) convertView.findViewById(R.id.share_count_text);
                    holder.shareCountText.setText(Html.fromHtml(context.getString(R.string.my_camera_share_count, getAcceptCount())));
                    holder.waiting_to_accept_title = (TextView) convertView.findViewById(R.id.waiting_to_accept_title);
                    if (userList.size() - getAcceptCount() - 1 == 0) {
                        holder.waiting_to_accept_title.setVisibility(View.GONE);
                    } else {
                        holder.waiting_to_accept_title.setVisibility(View.VISIBLE);
                        holder.waiting_to_accept_title.setText(context.getString(R.string.waiting_to_accept, userList.size() - getAcceptCount() - 1));
                    }
                    break;
                case TYPE_NONE:
                    convertView =
                            LayoutInflater.from(context).inflate(R.layout.public_add_share_user,
                                    null);
                    holder.none_head = (ImageView) convertView.findViewById(R.id.none_head);
                    holder.sendText = (TextView) convertView.findViewById(R.id.send_again_text);
                    holder.textView = (TextView) convertView.findViewById(R.id.textView);
                    holder.textView2 = (TextView) convertView.findViewById(R.id.textView2);
                    holder.shareAdicon = (ImageView) convertView.findViewById(R.id.share_ad_icon);
                    holder.inv_state = (TextView) convertView.findViewById(R.id.inv_state);
                    holder.textView.setText(getItem(position).getNickName());
                    if (TextUtils.equals(getItem(position).getNickName(), context.getString(R.string.inv_parent_title))) {
                        holder.none_head.setImageResource(R.drawable.share_user_parents);
                    } else {
                        holder.none_head.setImageResource(R.drawable.img_user);
                    }
                    break;

                case TYPE_WAITING:
                    convertView = LayoutInflater.from(context).inflate(R.layout.public_add_share_user_waiting, null);
                    holder.del_wating_share = (Button) convertView.findViewById(R.id.del_wating_share);
                    holder.del_wating_share.setOnClickListener(new ManageImpl(position));
                    holder.camera_share_waiting_t = (TextView) convertView.findViewById(R.id.camera_share_waiting_t);
                    holder.share_waiting_type_icon = (ImageView) convertView.findViewById(R.id.share_waiting_type_icon);

                    holder.share_waiting_title = (TextView) convertView.findViewById(R.id.share_waiting_title);
                    holder.share_waiting_content = (TextView) convertView.findViewById(R.id.share_waiting_content);

                    if (userList.get(position).getType() == Constants.ShareType.SHARE_TYPE_WEIXIN || userList.get(position).getType() == 0) {
//                        holder.share_waiting_type_icon.setImageResource(R.drawable.share_wechat);
                        holder.share_waiting_title.setText(R.string.share_weixin_title);
                        holder.share_waiting_content.setText(R.string.share_weixin_content);
                    } else if (userList.get(position).getType() == Constants.ShareType.SHARE_TYPE_MOBILE) {
//                        holder.share_waiting_type_icon.setImageResource(R.drawable.share_phone);
                        holder.share_waiting_title.setText(R.string.share_phone_title);
                        holder.share_waiting_content.setText(R.string.share_phone_content);
                    } else if (userList.get(position).getType() == Constants.ShareType.SHARE_TYPE_QRCODE) {
//                        holder.share_waiting_type_icon.setImageResource(R.drawable.share_erweima);
                        holder.share_waiting_title.setText(R.string.share_qrcode_title);
                        holder.share_waiting_content.setText(R.string.share_qrcode_content);
                    }
                    break;
                case TYPE_USER:
                    convertView =
                            LayoutInflater.from(context).inflate(R.layout.share_user_list_item,
                                    null);
                    holder.edite_layout = (LinearLayout) convertView.findViewById(R.id.edite_layout);
                    holder.Management_button =
                            (TextView) convertView.findViewById(R.id.Management_button);
                    holder.shareUserHead = (ImageView) convertView.findViewById(R.id.shareUserHead);
                    holder.shareUserNick = (TextView) convertView.findViewById(R.id.shareUserNick);
                    holder.edite_layout.setOnClickListener(new ModiyfyRemark(position));
                    holder.shareUserPhone = (TextView) convertView.findViewById(R.id.shareUserPhone);
                    holder.shareUserLastWatch =
                            (TextView) convertView.findViewById(R.id.shareUserLastWatch);
                    holder.share_user_watch_count = (TextView) convertView.findViewById(R.id.shareUserWatchCount);
                    String nick = "修改备注名称";
                    if (getItem(position).getNameType() == 1) {
                        nick = TextUtils.isEmpty(getItem(position).getNickName()) ? getItem(position).getNickName() : getItem(position).getNickName();
                    } else {
                        nick = TextUtils.isEmpty(getItem(position).getNickName()) ? Utils.getString(R.string.modify_remarks_prompt) : getItem(position).getNickName();
                    }
                    holder.shareUserNick.setText(nick);
                    holder.shareUserPhone.setText(showName(getItem(position)));
                    holder.share_user_watch_count.setText(Utils.getString(R.string.watch_count_prompt, userList.get(position).getTotleNum()));
                    holder.Management_button.setOnClickListener(new ManageImpl(position));

                    if (userList.get(position).getLastTime().startsWith("00")) {
                        holder.shareUserLastWatch.setText(context.getString(R.string.last_watch_time_null));
                    } else {
                        holder.shareUserLastWatch.setText(formatDateTime(userList.get(position).getLastTime()));
                    }
                    ImageLoader.getInstance().cancelDisplayTask(holder.shareUserHead);
                    ImageLoader.getInstance().displayImage(getItem(position).getImgUrl(),
                            holder.shareUserHead, displayImageOptions);
                    break;
            }
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
            if (type == TYPE_USER) {
                holder.edite_layout = (LinearLayout) convertView.findViewById(R.id.edite_layout);
                String nick = Utils.getString(R.string.modify_remarks_prompt);
                if (getItem(position).getNameType() == 1) {
                    nick = TextUtils.isEmpty(getItem(position).getNickName()) ? getItem(position).getNickName() : getItem(position).getNickName();
                    if (TextUtils.isEmpty(nick)) {
                        nick = Utils.getString(R.string.modify_remarks_prompt);
                    }
                } else {
                    nick = TextUtils.isEmpty(getItem(position).getNickName()) ? Utils.getString(R.string.modify_remarks_prompt) : getItem(position).getNickName();
                }

                holder.shareUserNick.setText(nick);
                holder.shareUserPhone.setText(showName(getItem(position)));
                if (userList.get(position).getLastTime().startsWith("00")) {
                    holder.shareUserLastWatch.setText(context.getString(R.string.last_watch_time_null));
                } else {
                    holder.shareUserLastWatch.setText(formatDateTime(userList.get(position).getLastTime()));
                }
                holder.edite_layout.setOnClickListener(new ModiyfyRemark(position));
                holder.Management_button.setOnClickListener(new ManageImpl(position));
                holder.share_user_watch_count.setText(Utils.getString(R.string.watch_count_prompt, userList.get(position).getTotleNum()));
                ImageLoader.getInstance().cancelDisplayTask(holder.shareUserHead);
                ImageLoader.getInstance().displayImage(getItem(position).getImgUrl(),
                        holder.shareUserHead, displayImageOptions);
            } else if (type == TYPE_NONE) {
                holder.sendText = (TextView) convertView.findViewById(R.id.send_again_text);
                holder.textView = (TextView) convertView.findViewById(R.id.textView);
                holder.textView2 = (TextView) convertView.findViewById(R.id.textView2);
                holder.shareAdicon = (ImageView) convertView.findViewById(R.id.share_ad_icon);
                holder.inv_state = (TextView) convertView.findViewById(R.id.inv_state);
                CLog.d("nick is :" + getItem(position).getNickName());
                holder.textView.setText(getItem(position).getNickName());
                holder.none_head = (ImageView) convertView.findViewById(R.id.none_head);
                if (TextUtils.equals(getItem(position).getNickName(), context.getString(R.string.inv_parent_title))) {
                    holder.none_head.setImageResource(R.drawable.share_user_parents);
                } else {
                    holder.none_head.setImageResource(R.drawable.img_user);
                }
            } else if (type == TYPE_TITLE) {
                holder.shareCountText = (TextView) convertView.findViewById(R.id.share_count_text);
                holder.shareCountText.setText(Html.fromHtml(context.getString(R.string.my_camera_share_count, getAcceptCount())));
                holder.waiting_to_accept_title = (TextView) convertView.findViewById(R.id.waiting_to_accept_title);
                if (userList.size() - getAcceptCount() - 1 == 0) {
                    holder.waiting_to_accept_title.setVisibility(View.GONE);
                } else {
                    holder.waiting_to_accept_title.setVisibility(View.VISIBLE);
                    holder.waiting_to_accept_title.setText(context.getString(R.string.waiting_to_accept, userList.size() - getAcceptCount() - 1));
                }

            } else if (type == TYPE_WAITING) {
                holder.del_wating_share = (Button) convertView.findViewById(R.id.del_wating_share);
                holder.del_wating_share.setOnClickListener(new ManageImpl(position));
                holder.camera_share_waiting_t = (TextView) convertView.findViewById(R.id.camera_share_waiting_t);
                CLog.d("type :" + userList.get(position).getType());
                if (userList.get(position).getType() == Constants.ShareType.SHARE_TYPE_WEIXIN || userList.get(position).getType() == 0) {

//                    holder.share_waiting_type_icon.setImageResource(R.drawable.share_wechat);
                    holder.share_waiting_title.setText(R.string.share_weixin_title);
                    holder.share_waiting_content.setText(R.string.share_weixin_content);
                } else if (userList.get(position).getType() == Constants.ShareType.SHARE_TYPE_MOBILE) {
//                    holder.share_waiting_type_icon.setImageResource(R.drawable.share_phone);
                    holder.share_waiting_title.setText(R.string.share_phone_title);
                    holder.share_waiting_content.setText(R.string.share_phone_content);
                } else if (userList.get(position).getType() == Constants.ShareType.SHARE_TYPE_QRCODE) {
//                    holder.share_waiting_type_icon.setImageResource(R.drawable.share_erweima);
                    holder.share_waiting_title.setText(R.string.share_qrcode_title);
                    holder.share_waiting_content.setText(R.string.share_qrcode_content);
                }
            }
        }
        return convertView;
    }

    class ViewHolder {
        TextView shareCountText;
        TextView waiting_to_accept_title;
        TextView sendText;
        TextView textView;
        TextView textView2;
        ImageView shareAdicon;
        TextView inv_state;
        ImageView shareUserHead;
        TextView shareUserNick;
        TextView shareUserLastWatch;
        TextView Management_button;
        Button del_wating_share;
        TextView camera_share_waiting_t;
        ImageView none_head;
        ImageView share_waiting_type_icon;
        TextView share_waiting_title;
        TextView share_waiting_content;
        TextView share_user_watch_count;
        TextView shareUserPhone;
        LinearLayout edite_layout;
    }

    abstract class CameraHandlerListener implements View.OnClickListener {
        protected int position;

        public CameraHandlerListener(int position) {
            super();
            this.position = position;
        }
    }

    class ManageImpl extends CameraHandlerListener {

        int position;

        public ManageImpl(int position) {
            super(position);
            this.position = position;
        }


        @Override
        public void onClick(View view) {
            shareUserCallback.onDelShare(getItem(position), position);
        }
    }

    class ModiyfyRemark extends CameraHandlerListener {

        public ModiyfyRemark(int position) {
            super(position);
        }

        @Override
        public void onClick(View view) {
            shareUserCallback.onRemarkNick(getItem(position), position);
        }
    }


    // 判断今天昨天明天
    private String formatDateTime(String time) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        if (time == null || "".equals(time)) {
            return "";
        }
        Date date = null;
        try {
            date = format.parse(time);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        Calendar current = Calendar.getInstance();

        Calendar today = Calendar.getInstance();    //今天

        today.set(Calendar.YEAR, current.get(Calendar.YEAR));
        today.set(Calendar.MONTH, current.get(Calendar.MONTH));
        today.set(Calendar.DAY_OF_MONTH, current.get(Calendar.DAY_OF_MONTH));
        //  Calendar.HOUR——12小时制的小时数 Calendar.HOUR_OF_DAY——24小时制的小时数
        today.set(Calendar.HOUR_OF_DAY, 0);
        today.set(Calendar.MINUTE, 0);
        today.set(Calendar.SECOND, 0);

        Calendar yesterday = Calendar.getInstance();    //昨天

        yesterday.set(Calendar.YEAR, current.get(Calendar.YEAR));
        yesterday.set(Calendar.MONTH, current.get(Calendar.MONTH));
        yesterday.set(Calendar.DAY_OF_MONTH, current.get(Calendar.DAY_OF_MONTH) - 1);
        yesterday.set(Calendar.HOUR_OF_DAY, 0);
        yesterday.set(Calendar.MINUTE, 0);
        yesterday.set(Calendar.SECOND, 0);

        current.setTime(date);

        if (current.after(today)) {
            return "今天 " + time.split(" ")[1];
        } else if (current.before(today) && current.after(yesterday)) {

            return "昨天 " + time.split(" ")[1];
        } else {
            int index = time.indexOf("-") + 1;
            return time.substring(index, time.length());
        }
    }


    public String showName(ShareUser shareUser) {
        if (!TextUtils.isEmpty(shareUser.getTelephone())) {
            return shareUser.getTelephone();
        } else {
            if (!TextUtils.isEmpty(shareUser.getLoginEmail())) {
                return shareUser.getLoginEmail();
            } else {
                if (!TextUtils.isEmpty(shareUser.getUserName())) {
                    return shareUser.getUserName();
                } else {
                    return "";
                }
            }
        }
    }


}
