var collectList = {};

//APP端在加载完页面后执行初始化方法
window.initJSCall = function(){
        //命名空间&&&自定义协议名称
        var ns = "story";
        //创建命名空间
        var nsObj = window[ns] = {};
        //要支持的方法们
        var funs = ["sendMsgToClient","sendMsgToWebview"];
        /* 遍历并实现JS接口 */
        for(var i=0; funName=funs[i]; i++){
        	nsObj[funName]=(function(fn){
        		return function(jsonStr){
        			location.href=ns+"://"+fn+"?"+encodeURIComponent(jsonStr);
        		};
        	})(funName);
        }
    };

/*APP端将指令发送到H5的方法,会识别是obj还是字符串，后转换成json对象
json对象格式如下：
	{	
		action:"playStatus|playStatusClear|online|..."
		data:{
			相应的数据
		}
	}
*/
window.sendMsgToWebview = function(obj){
	if(window.story){
		try{
			var json = typeof(obj)=='object'?obj:JSON.parse(obj);
			switch(json.action){
				//H5页面对于不同action的处理方法，可自己实现
				case 'playStatus':
					var status = json.data.status;
					var uniqueid = json.data.uniqueid;
					$('.single-item').removeClass('play').removeClass('pause');
					$("[data-uniqueid='"+uniqueid+"']").addClass(status);
				break;
				case 'playStatusClear':
					$('.single-item').removeClass('play').removeClass('pause');
				break;
				case 'online':
					var status = json.data.status;
					console.log(status);
					status?$('.statusCon').addClass('on').removeClass('off'):$('.statusCon').addClass('off').removeClass('on');
				break;
				case 'collectList':
					collectList = json.data;
					Server.setLocalStorage('collectList',collectList,true);
					$.each(Server.itemList,function(key,item){
						collectList[item.uniqueid]?$('.like-btn').eq(key).addClass('active'):$('.like-btn').eq(key).removeClass('active');;
					});
					for(id in collectList){
						$('[data-uniqueid='+id+']').find('.like-btn').addClass('active');
					}
				break;
			}
		}catch(err){
			console.log(err);
		}
	}
}

/*H5端将数据发送到端的方法,json参数为object对象
*调用实例——播放专辑：
	var data = {};
    data.action = 'playAlbum';
    data.data = {};
    data.data.name = '专辑名称';
    data.data.unique = '专辑的唯一id';
    data.data.coverurl = '专辑封面图地址';
    data.data.category = '专辑所属大分类';
    sendMsgToClient(data);
*/
window.sendMsgToClient = function(json){
	console.log(json);
	if(window.story){
		try{
			window.story['sendMsgToClient'](JSON.stringify(json));
		}catch(err){
			console.log(err);
		}
	}
}